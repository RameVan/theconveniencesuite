# Cookie Denier

A Chrome extension (Manifest V3) that automatically rejects cookie consent banners.

## Install

1. Open `chrome://extensions`.
2. Turn on **Developer mode** (top right).
3. Click **Load unpacked** and choose this `CookieDenier` folder.
4. Pin the extension if you want to see the ✓ badge when it handles a banner.

After editing any file, press the reload icon on the extension's card and reload the page you're testing.

## How it works

`content.js` runs in every page and frame for the first 30 seconds after load, rescanning whenever the DOM changes:

1. **Known consent platforms**: OneTrust, Cookiebot, Didomi, Usercentrics, Google Funding Choices, Quantcast, TrustArc, CookieYes, Complianz, Osano, Klaro, iubenda, Borlabs, consentmanager, Axeptio, Sourcepoint, Termly, HubSpot, Shopify, Wix and others are recognised by their own selectors.
2. **Unknown banners**: buttons whose text means "reject" (in English, Dutch, German, French, Spanish, Italian, Portuguese, Nordic languages and Polish), such as "Reject all", "Alleen noodzakelijke cookies" or "Alle ablehnen", are clicked, but only when the surrounding element talks about cookies or consent. Accept buttons and links that leave the page (like "Reject and subscribe") are never clicked.
3. **Preferences**: when a banner has no reject button, or it mentions partners, vendors or "legitimate interest" (IAB TCF banners, where "Reject all" often leaves legitimate interest switched on), the script opens its settings ("More options", "Manage options", "Cookie settings", ...) and then, screen by screen:
   - clicks every "Reject all", "Object all" and "Disagree to all" button;
   - switches off every purpose, vendor and legitimate-interest toggle;
   - visits each Partners / Vendors / Legitimate interest screen and does the same there, going Back when needed;
   - saves with "Save & exit", "Confirm choices", "Save preferences" or similar (never "Accept all").

   Banners that show switches right on the first screen get the same treatment. If the preferences can't be completed, the script falls back to the first-screen reject button, or hides the banner.
4. **Fallback**: if a banner offers no way to refuse, it is hidden after 5 seconds and page scrolling is unlocked. You can turn this off in the popup.

The script looks inside shadow DOM (including closed shadow roots) and iframes, and stops after handling one banner per frame.

## Popup

- Turn the extension on or off everywhere, or only for the current site.
- Turn "Also refuse all vendors and legitimate interest" on or off. When it's off, banners with a "Reject all" button are only rejected on the first screen, which is faster.
- Turn the hide fallback on or off.
- See what was done on the current page and how many banners have been denied in total.

## Adding a site that isn't handled

Add an entry to `CMPS` in `content.js`:

```js
{ name: 'Example CMP', detect: '#example-banner', reject: ['#example-reject-button'] },
```

`detect` is optional: without it, the reject selector itself is used to detect the banner.
