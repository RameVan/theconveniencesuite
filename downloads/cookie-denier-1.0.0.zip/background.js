// Records what the content script did per tab (badge + popup status) and keeps a running total.

let totalUpdate = Promise.resolve();

function bumpTotal() {
  // Chained so reports from several frames at once don't overwrite each other.
  totalUpdate = totalUpdate.then(async () => {
    const { total } = await chrome.storage.local.get({ total: 0 });
    await chrome.storage.local.set({ total: total + 1 });
  });
}

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg?.type !== 'denied' || !sender.tab) return;
  const tabId = sender.tab.id;
  chrome.action.setBadgeBackgroundColor({ tabId, color: msg.method === 'hidden' ? '#757575' : '#2e7d32' });
  chrome.action.setBadgeText({ tabId, text: '✓' });
  chrome.storage.session.set({ [`tab_${tabId}`]: { cmp: msg.cmp, method: msg.method } });
  bumpTotal();
});

chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status !== 'loading') return;
  chrome.action.setBadgeText({ tabId, text: '' });
  chrome.storage.session.remove(`tab_${tabId}`);
});

chrome.tabs.onRemoved.addListener((tabId) => chrome.storage.session.remove(`tab_${tabId}`));
