# Opt Out

Finds the mailing lists in a Gmail inbox, sorts them into categories, protects important mail, and
unsubscribes in bulk with honest status reporting. A web app and a Chrome extension share one backend.

- **Web app** (`web/`): React. Overview, subscriptions with search, filters and bulk selection, accounts,
  activity and settings.
- **Backend** (`server/`): Fastify + PostgreSQL (embedded PGlite in development). Gmail API integration,
  discovery engine, classification, unsubscribe engine and a persistent job queue. It owns all data.
- **Extension** (`extension/`): Manifest V3 popup. Shows top senders, unsubscribes, runs quick
  (partial) scans and helps finish web-page unsubscribes. Uses the same API and data.
- **Breach monitoring**: shows which companies that email you were breached, and (opt-in) which
  breaches your addresses appear in, with the leaked data types and what to do. Free by default via
  XposedOrNot; uses Have I Been Pwned when an API key is set.

Status, with evidence: [docs/STATUS.md](docs/STATUS.md). Architecture: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).
Setup and deployment: [docs/SETUP.md](docs/SETUP.md). Data handling: [docs/PRIVACY.md](docs/PRIVACY.md).

## Quick start (development, no Google account needed)

```bash
npm install
cp server/.env.example server/.env    # then set DEV_FAKE_PROVIDER=true
npm run build                         # builds the web app, which the server serves
npm start                             # http://localhost:8790
```

Choose **Use development fixture mailbox** on the sign-in page. It loads a built-in test mailbox
(30 senders, about 1,750 messages), labelled as fixture data everywhere it appears. Live Gmail needs the
Google Cloud setup in [docs/SETUP.md](docs/SETUP.md).

For UI work with hot reload, run `npm run dev:server` and `npm run dev:web` (Vite on :5180, proxied to the API).

## Tests

```bash
npm test                              # 110 backend tests: parsing (incl. fuzzing), classification, scans, unsubscribe
                                      # engine (36 HTTPS sender behaviours, bulk with 3 workers), breaches, API
npm run test:crash --workspace server # kills a live worker process 3 times mid-run and checks the outcome
npm run typecheck
node tools/e2e-extension.mjs          # with the dev server running: extension <-> web app, in headless Chrome
```

## Safety defaults

- `UNSUBSCRIBE_MODE=dry_run` is the default. Requests are validated and recorded, but nothing is sent
  to senders. Set `live` only after reviewing the tests and approving live sending.
- Banking, security, authentication, password reset, payment, order, shipping, booking, insurance,
  medical and government mail is excluded from bulk unsubscribes unless the user overrides it twice.
- A request the sender accepted is shown as *submitted*. It becomes *unsubscribed* only after mail
  from that list stops for the verification period.
