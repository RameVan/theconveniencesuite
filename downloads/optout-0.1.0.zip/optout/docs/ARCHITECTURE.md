# Architecture

Opt Out is a **modular monolith**: one Node.js process (API + embedded worker, or the
two split into separate processes with the same code), one PostgreSQL database, a React web
app and a Manifest V3 Chrome extension. The database is the only source of truth.

```
 ┌──────────────┐   cookie session   ┌───────────────────────────────────────────┐
 │  Web app     │ ─────────────────▶ │  server (Fastify)                          │
 │  React/Vite  │                    │   modules/                                 │
 └──────────────┘                    │     auth        Google sign-in, sessions,  │
 ┌──────────────┐   bearer token     │                 extension tokens           │
 │  Extension   │ ─────────────────▶ │     accounts    connected Gmail accounts   │
 │  MV3 popup   │                    │     providers   Gmail API client (+ fake)  │
 └──────────────┘                    │     discovery   scan → sender identities   │
                                     │     classify    rules, categories, protect │
                                     │     unsubscribe RFC 8058, mailto, web      │
                                     │     jobs        Postgres job queue+worker  │
                                     │     privacy     export / delete / revoke   │
                                     └──────────────────┬────────────────────────┘
                                                        │ Drizzle ORM
                                              ┌─────────▼─────────┐
                                              │ PostgreSQL        │
                                              │ (PGlite in dev)   │
                                              └───────────────────┘
```

## Stack and the reasoning behind it

| Concern | Choice | Why |
|---|---|---|
| Language | TypeScript everywhere, run natively by Node 24 (type stripping) | Same as the sibling projects in this workspace; no build step for the server. |
| HTTP | Fastify 5 | Mature, fast, schema-friendly, good plugin ecosystem (cookies, static, rate limit). |
| Database | PostgreSQL. **PGlite** (Postgres compiled to WASM) for local dev and tests | Docker/Postgres are not installed on the build machine. PGlite is real Postgres, so partial unique indexes, `FOR UPDATE SKIP LOCKED` and JSONB behave identically. Production sets `DATABASE_URL` and uses `pg`. |
| ORM / migrations | Drizzle ORM + drizzle-kit SQL migrations | Type-safe, thin, SQL-shaped, supports both drivers with one schema. |
| Background jobs | Table-backed queue in Postgres (`jobs`) with leases | Avoids adding Redis. Jobs survive restarts; leases expire so a crashed worker's job is picked up again. `SKIP LOCKED` makes multiple workers safe. Can be swapped for pg-boss/BullMQ later behind the same `enqueue`/handler interface. |
| Web | React 18, Vite 6, TanStack Query, React Router | Query cache + refetch-on-focus gives cheap cross-interface sync. |
| Extension | MV3, plain ES modules, no bundler | Small surface; it is a thin client of the API. |
| Tests | `node:test` | Built in; matches the workspace. |

## Data model (summary)

- `users`, `sessions`, `api_tokens` (extension; stored as SHA-256 hashes).
- `mail_accounts` – one per connected Gmail account. OAuth tokens encrypted with AES-256-GCM
  (`TOKEN_ENCRYPTION_KEY`). Stores `history_id` for incremental sync and granted scopes.
- `sender_identities` – **the subscription record**. Key is `list:<List-Id>` when a List-Id
  exists, otherwise `addr:<from-address>`. So `news@shop.com` and `orders@shop.com` stay
  separate, and two List-Ids from one address stay separate too. Holds counts, first/last
  seen, unsubscribe methods, category, confidence, protection flags and status.
- `messages` – minimal per-message rows (provider id, identity, date, a few flags). **No
  bodies, no subjects** are stored per message; only the latest subject per identity.
- `categories` – system categories plus user-defined ones; merge reassigns identities.
- `unsubscribe_requests` – one row per attempt, with the state machine below and an event
  log (`unsubscribe_events`). A partial unique index allows only one *active* request per
  identity, which is what stops the web app and the extension double-executing.
- `jobs` – persistent queue (scan, unsubscribe, verify).
- `preferences` – per-user settings.

## Unsubscribe state machine

```
discovered → eligible → awaiting_approval → queued → processing ─┬→ request_submitted → verification_pending ─┬→ unsubscribed (verified: no mail since)
                                                                 ├→ awaiting_confirmation (sender page needs a click)   └→ failed (still receiving)
                                                                 ├→ requires_manual_action (web form, CAPTCHA, login)    └→ verification_unavailable
                                                                 └→ failed
```

`request_submitted` is *never* shown as success. An identity only becomes `unsubscribed`
after the verification job finds no new mail from it for the configured window
(default 7 days after the grace period). If the sender gives no signal and mail volume is
too low to judge, the result is `verification_unavailable`, shown as such.

## Unsubscribe method priority

1. RFC 8058 one-click: requires `List-Unsubscribe` with an `https:` URI **and**
   `List-Unsubscribe-Post: List-Unsubscribe=One-Click`. Sent as POST with body
   `List-Unsubscribe=One-Click`; never downgraded to GET. Destination checked against SSRF
   rules (public IP only, https only, no credentials in URL, redirects re-validated).
2. `mailto:` – needs the optional `gmail.send` scope, requested only when the user enables it.
3. Official HTTPS unsubscribe URL without one-click – opened for the user
   (browser-assisted). Not automated: the server does not drive a headless browser.
4. Nothing usable → manual instructions.

## Why not more infrastructure

No Redis, no queue broker, no microservices: one Postgres covers persistence, locking and
queueing at the scale of a single-tenant-per-user SaaS until proven otherwise. Modules only
talk through their exported functions, so `unsubscribe` or `discovery` can be lifted into a
separate worker service by running `src/worker.ts` alone (already supported).

## Provider abstraction

`providers/types.ts` defines `MailProvider` (list, get metadata, history, send). Gmail is the
only real implementation. Outlook is deliberately **not** started (spec rule: Gmail first,
until Gmail passes live acceptance tests, which need Google credentials).
