# Data handling

## What is accessed

| Data | Source | Why |
|---|---|---|
| Google account email, name, picture, account ID | Google sign-in (`openid email profile`) | Identify the user |
| Message headers: From, Subject, Date, List-Id, List-Unsubscribe, List-Unsubscribe-Post, Precedence, Auto-Submitted, Feedback-ID, Return-Path; Gmail label IDs | `gmail.metadata` | Group mail into senders and lists, find unsubscribe methods, classify |
| Ability to send email | `gmail.send` (optional, per account) | Send the unsubscribe email a sender asks for in its `mailto:` link |
| Public breach catalogue | XposedOrNot or Have I Been Pwned | Match companies that email the user against known breaches. Downloading it sends no user data |
| Which breaches the user's addresses appear in | The same provider, **only after the user opts in** | Show where their address leaked. Sends the sign-in address and connected mailbox addresses, nothing else |

Message bodies and attachments are never requested; `gmail.metadata` cannot read them.

## What is stored, where and for how long

All data lives in the application's PostgreSQL database (PGlite files in development).

| Stored | Retention |
|---|---|
| Per sender/list: address, display name, domain, List-Id, unsubscribe URIs, latest subject line, counts, dates, category, flags | Until the mail account is disconnected or the user is deleted |
| Per message: Gmail message ID, received date, the sender it belongs to | Same; needed to avoid re-downloading and to verify unsubscribes |
| Google tokens | AES-256-GCM encrypted; deleted and revoked at Google on disconnect |
| Unsubscribe requests and their event history | Until account deletion |
| Breach lookup results (which breaches each address is in, when it was checked) | Until the user turns address checks off (then deleted at once) or deletes the account |
| Public breach catalogue | Refreshed daily; contains no user data |
| Finished background jobs | 30 days |
| Sessions | 30 days, or until sign-out |

Subjects of individual messages are not stored, only the latest subject per sender (shown in the UI).

## Where it is processed

On the application server only. Nothing is sent to third parties. No email data goes to AI services
(classification is rule-based on metadata). Exceptions the user controls:
- Unsubscribing contacts the sender's own unsubscribe URL or address, which is the purpose.
- Address breach checks (off by default) send the user's own addresses to XposedOrNot
  (api.xposedornot.com) or, if configured, Have I Been Pwned. Breach logos load from those services.
- The optional "Show sender logos" setting (off by default, stored only in the browser) loads icons
  from DuckDuckGo's icon service, which then sees the sender domains being viewed.

## User controls

- **Export**: Settings → Export (JSON of everything held).
- **Disconnect a mailbox**: revokes the Google token and deletes all derived data for that mailbox.
- **Delete account**: revokes every Google token and deletes all rows for the user (database
  cascades). Verified by an automated test.
- **Revoke the extension**: Settings → Browser extension.

## Security measures

- OAuth 2.0 authorisation-code flow with PKCE and single-use `state`; least-privilege scopes;
  `gmail.send` only through incremental consent.
- Tokens encrypted at rest; session and extension tokens stored only as SHA-256 hashes.
- Session cookie `HttpOnly`, `SameSite=Lax`, `Secure` on HTTPS. Cookie-authenticated writes require a
  custom header and a same-origin `Origin`, which blocks CSRF.
- Every query is scoped to the signed-in user; covered by an isolation test.
- Outgoing unsubscribe requests: HTTPS only, no credentials in URLs, standard port, public IP
  addresses only (checked at connection time against DNS rebinding), redirects re-validated. This
  stops server-side request forgery through malicious List-Unsubscribe headers.
- Logs redact email addresses, tokens and URL query strings.
- Content-Security-Policy, `X-Frame-Options: DENY`, `nosniff`, HSTS on HTTPS.
- No advertising and no sale of data, in line with Google's Limited Use requirements.
