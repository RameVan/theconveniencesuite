# Setup, configuration and deployment

## 1. What is missing before live Gmail works

The code for the Gmail integration is complete and tested against a mock provider. Running it against
real mailboxes needs things only you can create:

| Needed | Why | Where |
|---|---|---|
| Google Cloud project with the **Gmail API** enabled | All mailbox access | console.cloud.google.com |
| **OAuth client ID** (type: Web application) | Sign-in and Gmail consent | APIs & Services → Credentials |
| **OAuth consent screen** with the scopes below | Google shows it to users | APIs & Services → OAuth consent screen |
| Test users (while unverified) | Unverified apps only work for listed users (max 100) | consent screen → Test users |
| `TOKEN_ENCRYPTION_KEY` | Encrypts stored Google tokens | generate (below) |
| A public HTTPS origin (production) | Google requires HTTPS redirect URIs outside localhost | your host |

## 2. Google Cloud, step by step

1. Create a project at https://console.cloud.google.com/.
2. **APIs & Services → Library**: enable **Gmail API**.
3. **OAuth consent screen**: user type *External*. Fill in the app name (*Opt Out*), support email, and (for
   production) homepage, privacy policy and terms URLs. Add the scopes:
   - `openid`, `.../auth/userinfo.email`, `.../auth/userinfo.profile`
   - `https://www.googleapis.com/auth/gmail.metadata` (restricted)
   - `https://www.googleapis.com/auth/gmail.send` (sensitive; optional feature)
   Add your own Gmail address(es) under **Test users**.
4. **Credentials → Create credentials → OAuth client ID → Web application**.
   - Authorised JavaScript origin: `http://localhost:8790` (and your production origin)
   - Authorised redirect URI: `http://localhost:8790/auth/google/callback`
     (and `https://YOUR-DOMAIN/auth/google/callback`)
5. Run the setup command. It asks for the client ID and secret (the secret isn't shown as you
   type), checks them with Google, and writes them to `server/.env`:

```bash
npm run setup:google --workspace server
```

   Or edit `server/.env` by hand:

```bash
GOOGLE_CLIENT_ID=1234-abc.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=GOCSPX-...
APP_ORIGIN=http://localhost:8790
DEV_FAKE_PROVIDER=false
```

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

Put that value in `TOKEN_ENCRYPTION_KEY`. Keep it safe: losing it means every user must reconnect.

### While the app is in "Testing"

- Only the test users listed on the consent screen can sign in; others get "access blocked".
- Google shows an "unverified app" warning; choose *Continue*.
- **Refresh tokens expire after 7 days** for apps in Testing. The account then shows *Needs
  reconnecting*; press *Reconnect*. This goes away once the app is published.
- Sign-in and connecting Gmail are two consent screens: the first asks only who you are, the
  second asks for read access to email metadata (least privilege).

### Google verification before public launch

- `gmail.metadata` is a **restricted** scope. A public app (more than 100 users, or not in *Testing*)
  needs Google's OAuth verification **and** an annual third-party security assessment (CASA) for
  restricted scopes. Plan weeks for this, plus the assessment cost.
- `gmail.send` is **sensitive**: it needs verification but no security assessment. It is requested
  only when a user turns on email unsubscribes, through incremental authorisation.
- Google's Limited Use policy applies: the data may only power user-facing features of this app. The
  code follows this (no ads, no sale, no transfer, no AI processing).
- Until verified, users see an "unverified app" warning and only listed test users can connect.

## 3. Environment variables (`server/.env`)

| Variable | Default | Meaning |
|---|---|---|
| `NODE_ENV` | development | `production` enforces keys, secure cookies, disables fixtures |
| `PORT` | 8790 | HTTP port |
| `APP_ORIGIN` | http://localhost:8790 | Public origin; used for redirects and origin checks |
| `DATABASE_URL` | empty | Postgres URL. Empty = embedded PGlite in `DATA_DIR` |
| `DATA_DIR` | ./data | PGlite files and the development key file |
| `TOKEN_ENCRYPTION_KEY` | dev: auto-generated file | 32 bytes, base64. **Required in production** |
| `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` | empty | OAuth client |
| `UNSUBSCRIBE_MODE` | dry_run | `live` actually sends unsubscribe requests |
| `EMBEDDED_WORKER` | true | Run jobs in the API process. `false` + `npm run worker` to split |
| `WORKER_CONCURRENCY` | 4 | Parallel jobs per worker |
| `BULK_MAX` | 250 | Maximum senders per bulk request |
| `DEV_FAKE_PROVIDER` | false | Development fixture mailbox and sign-in. Refused in production |
| `BREACH_PROVIDER` | auto | `auto`: HIBP if a key is set, else free XposedOrNot. Or force `hibp` / `xposedornot` |
| `HIBP_API_KEY` | empty | Optional paid key from https://haveibeenpwned.com/API/Key |

## 3a. Breach checks

Works out of the box at no cost: the **free XposedOrNot** API needs no key and no sign-up. Two parts:

- *Companies that email you and were breached*: the public breach list is downloaded daily and
  matched against sender domains on the server. No user data is sent.
- *Your addresses*: only after the user turns it on (Breaches page). Their sign-in address and
  connected mailboxes are sent to the provider once a day; turning it off deletes the results.

Optionally set `HIBP_API_KEY` (paid, about US$4.50 a month at the time of writing) to use Have I Been
Pwned instead, the most widely trusted source. Lookups are spaced 6.5 s apart for its cheapest plan
(2 s for XposedOrNot). Switching provider never mixes the two datasets; each keeps its own catalogue.
Neither service returns breaches flagged as sensitive (for example adult sites) in address lookups.

## 4. Turning on live unsubscribing

1. Run `npm test`; every test must pass.
2. Connect a **test** Gmail account you control, subscribed to a few lists you created for testing
   (for example your own Mailchimp or Buttondown list). Do not use real subscriptions as test data.
3. Set `UNSUBSCRIBE_MODE=live`, restart, unsubscribe from one test list, and check the request moves
   to *Submitted, verifying* and the list provider shows the address as unsubscribed.
4. Only then use bulk unsubscribing.

## 5. Deploying

The app is one Node process plus a database.

- **Single instance (simplest):** `docker build -t unsubscriber .` and run it with a volume for
  `DATA_DIR` (PGlite), behind an HTTPS reverse proxy, `NODE_ENV=production`, the variables above.
- **With Postgres (recommended for production):** set `DATABASE_URL`. Migrations run automatically at
  start. To scale, run more API containers with `EMBEDDED_WORKER=false` and one or more
  `npm run worker` containers; jobs use `FOR UPDATE SKIP LOCKED`, so workers never collide.
  A separate worker process needs Postgres: PGlite cannot be shared between processes.
- Back up the database and keep `TOKEN_ENCRYPTION_KEY` in a secret manager.
- Put the server behind TLS. Cookies become `Secure` automatically when `APP_ORIGIN` is https.

## 6. The Chrome extension

Development (talks to `http://localhost:8790`): open `chrome://extensions`, enable Developer mode,
**Load unpacked** → the `extension/` folder. Click the toolbar icon → **Connect**: a tab opens on the
web app, which hands the extension a revocable key. (You must be signed in to the web app.)

Production: `node tools/build-extension.mjs https://YOUR-DOMAIN` writes `extension-dist/` with the
right host permissions, ready to zip for the Chrome Web Store. Revoke a linked extension under
Settings → Browser extension.
