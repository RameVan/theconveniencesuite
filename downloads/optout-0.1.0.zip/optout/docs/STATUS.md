# Development status

Last updated 2026-11-08. Evidence: `npm test` (110/110 pass), `npm run test:crash --workspace server` (3/3), `npm run typecheck` (clean),
`node tools/e2e-extension.mjs` (8/8 pass, run twice), plus manual checks of the web app in a browser
(desktop, mobile 375 px, light and dark), all against the **development fixture mailbox**.

Legend: **Tested** = implemented with automated tests or a recorded manual check. **Awaiting external
configuration** = code complete, but it has never run against the real service because credentials do
not exist yet. Nothing here has been run against a real Gmail account.

## Acceptance criteria

| # | Criterion | Status | Evidence / notes |
|---|---|---|---|
| 1 | Standalone application | Tested | All five sections plus sign-in and extension linking; checked in the browser |
| 2 | Gmail OAuth integration | Tested (simulated Google) · **awaiting your credentials** | Auth-code + PKCE, state bound to the browser, incremental `gmail.send`, token refresh, `invalid_grant` handling, revocation. Needs a Google OAuth client (docs/SETUP.md) |
| 3 | Gmail mailbox scanning | Tested (mock) · awaiting configuration (live) | Full, incremental (History API), partial; resumable; rate-limit deferral; history-expiry fallback; 25,000 messages in ~4 s locally |
| 4 | Reliable sender identification | Tested | Identity = List-Id, else sender address; RFC 2047 names |
| 5 | Mailing-list identification | Tested | Two lists and an order address from one company stay separate |
| 6 | Categorisation | Tested | 20 system categories, rules on metadata, confidence scores, custom categories, rename, merge, protect |
| 7 | Search and filtering | Tested | Search, category, account, type, method, status, hide kept/protected; four sorts; pagination |
| 8 | Individual unsubscribe | Tested (mock sender) | RFC 8058 POST verified byte-for-byte against a local server |
| 9 | Safe bulk unsubscribe | Tested | Server-side preview, explicit confirm, `BULK_MAX`, protected/kept exclusion, double confirmation to override |
| 10 | Persistent background processing | Tested | Postgres queue with leases; crash recovery, pause/resume/cancel, restart (server restarted mid-session) |
| 11 | Accurate unsubscribe status | Tested | Full state machine with event log; "unsubscribed" only after verified silence |
| 12 | Unsubscribe history | Tested | Activity page and per-sender timeline |
| 13 | Multiple account support | Tested | Two mailboxes, account filter, isolated disconnect |
| 14 | Browser extension | Tested | MV3 popup in headless Chrome: link, list, confirm, unsubscribe, quick scan, web-page completion |
| 15 | Shared backend and database | Tested | The extension has no data store of its own (token only) |
| 16 | Cross-interface synchronisation | Tested | Extension request visible in the web app; web whitelist visible in the extension; duplicates refused by a DB constraint |
| 17 | Security and privacy controls | Tested | Isolation, CSRF, SSRF guard, encryption, redacted logs, export, full deletion (docs/PRIVACY.md) |
| 18 | Automated tests | Tested | 110 server tests, process-kill crash test, extension E2E |
| 19 | Deployment documentation | Written | docs/SETUP.md, Dockerfile. The Docker image has **not been built** here (Docker isn't installed) |
| 20 | External configuration instructions | Written | docs/SETUP.md §1–2 |

## Google OAuth (2026-11-08)

`test/oauth.test.ts` (11 tests) runs every flow against a simulated Google that enforces the
protocol: single-use codes, PKCE, client secret, redirect URI, refresh, revocation, granular consent.
It also runs a simulated Gmail REST API, so the real Gmail client (paging, metadata-only format,
history, send) is exercised end to end, from connecting the account through the background scan.

Covered:
- sign-in asks for identity only;
- connecting Gmail requests offline metadata access, and send permission only later through
  incremental consent;
- tokens are stored encrypted, never in plain text;
- expired access tokens refresh; a revoked grant shows *Needs reconnecting*;
- disconnecting or deleting the account revokes the token at Google;
- cancelled, wrong-audience, unverified-email and denied-permission paths;
- missing refresh token, and reconnecting in place.

Fixed while testing:
1. **Login CSRF:** the OAuth state was not tied to the browser that started the flow, so someone
   could make you finish their sign-in and then capture a mailbox you connected. It is now bound
   to a short-lived cookie.
2. Granting send permission while picking a different Google account added that other mailbox. It
   is now refused (`wrong_account`).

Live check: Google rejects a fake client with `invalid_client`, which the setup command uses to
catch a mistyped secret. **Still awaiting your credentials** for a run against your real Gmail.

## Unsubscribe testing campaign (2026-11-08)

Run against simulated senders, not real subscriptions (the spec requires explicit approval and a
controlled mailbox for live tests). Results:

| Suite | What it covers | Result |
|---|---|---|
| `test/headers-realworld.test.ts` | List-Unsubscribe in Mailchimp, SendGrid, Klaviyo, Amazon SES, Salesforce MC and HubSpot formats; folded, bare, uppercase and malformed variants; mailto injection; **fuzz of 20,000 inputs**; pathological sizes | 24/24 |
| `test/unsubscribe-matrix.test.ts` | **36 sender behaviours over real HTTPS** (test CA): 2xx, confirmation pages, CAPTCHAs, 301/302/303/307/308, redirect loops, redirects to private IPs, http or bad schemes, 4xx, 405, 408, 429 with Retry-After, 5xx, flaky senders, slow, trickling and reset connections, 5 MB bodies, untrusted certificates; mailto encoding, failures, rate limits, revoked permission; dry run; crash mid-send | 12/12 |
| `test/unsubscribe-bulk.test.ts` | 250 senders across 50 companies, **3 workers × 4 slots in parallel**, repeat clicks from the extension mid-run, per-company spacing | Exact request count for every sender; 0 duplicates from clicks; spacing held |
| `npm run test:crash` | Real child process with an on-disk database, **killed hard 3 times** mid-run and restarted | 3/3 runs passed: 150/150 settled, 0 missed, 0 emails sent twice, repeated one-click POSTs ≤ the 12 possible in flight |
| Full suite | `npm test`, run 3 times in a row | 99/99 each time |

Defects found and fixed during the campaign:
1. An `http://` link listed before the `https://` one hid one-click support.
2. Bare (unbracketed) List-Unsubscribe URIs were ignored.
3. Bare `mailto:` URIs were ignored.
4. A sender trickling bytes kept a job running forever: there was no total deadline, only an idle
   timeout.
5. Untrusted TLS certificates were retried 4 times; they now fail at once.
6. Web-page unsubscribe links using `http://` were marked failed, though the user opens them, not the server.
7. A one-click link answering 405 was a dead end; it now goes to the user as a page to finish.
8. A crash between state writes could leave a request stuck in "submitted" with no verification
   scheduled, or a sender showing the wrong status. State changes are now atomic, and a repair step
   fixes any leftovers.
9. A crash during an email send could have resent the email after restart. The new in-flight
   marker prevents that and reports "may or may not have been sent".
10. A verification job started early could judge too soon; it now waits for its due date.

Known and accepted: a crash while a one-click request is on the wire repeats that request after
restart (at-least-once delivery). Unsubscribing twice is harmless, and it is noted in the
request's history.

Not covered: real senders' endpoints. Their behaviour is modelled by the simulator; a controlled
live test (SETUP.md §4) is still needed before enabling `UNSUBSCRIBE_MODE=live`.

## Breach monitoring (added after the original spec)

| Part | Status | Evidence |
|---|---|---|
| Companies that email you and were breached (domain match, no user data sent) | Tested | Unit tests; live catalogue fetched from both providers (HIBP 1,049 breaches, XposedOrNot 797) |
| Your addresses in breaches, **free** (XposedOrNot, no key) | Tested, including live | Unit tests; live lookup of the public `test@example.com` (215 breaches resolved to full details); dev server run end to end against the live API |
| Your addresses in breaches, HIBP (paid key) | Tested (mock) · **awaiting external configuration** | Client tested with a mocked API; needs `HIBP_API_KEY` for a live run |
| Consent, daily refresh, rate-limit spacing, deletion on opt-out, per-user isolation | Tested | `test/breaches.test.ts` (10 tests) |
| Breaches page, drawer notice, mobile layout | Checked in the browser | Desktop and 375 px, fixture and live provider |

## By component

### Implemented and tested
- Header parsing (From, List-Id, List-Unsubscribe, RFC 8058 Post, mailto with injection stripping).
- Classification and protected-communication detection per list, not per company.
- Discovery engine: idempotent ingest (no double counting across retries, rescans or crashes).
- Job queue: leases, `SKIP LOCKED`, dedupe keys, exponential backoff, defer without consuming attempts,
  pause/resume/cancel, stranded-request reconciliation, periodic incremental sync, 30-day job retention.
- Unsubscribe engine:
  - one-click POST (never GET), 307/308 kept as POST, 3xx treated as received
  - transient retries capped at 4; 4xx fails at once
  - CAPTCHA and confirmation pages handed to the user
  - per-domain spacing; SSRF guard
  - mailto through Gmail send, which waits for permission and is never blindly retried
  - web-only and no-link senders become manual tasks
  - dry-run mode
  - verification by silence (verified / unverifiable / still receiving)
- API: auth via session cookie or extension bearer token, CSRF, user isolation, export, deletion.
- Web app: overview, subscriptions (lazy loading, bulk bar, drawer), accounts (scan progress and
  controls), activity, settings, light/dark/system theme, responsive layout.
- Extension: linking through `externally_connectable`, badge for pending tasks, top senders, search,
  bulk select with server-side preview, activity with manual completion, current-tab detection of a
  pending unsubscribe page, quick (partial, clearly labelled) scan.

### Awaiting external configuration
- **Everything that talks to Google** (OAuth, Gmail API, token refresh and revocation, sending). The
  client is written against Google's documented REST API and tested only with a mock. Needs the Google
  Cloud setup in docs/SETUP.md, then a controlled live test with a test account.
- **Live unsubscribing.** `UNSUBSCRIBE_MODE=live` is implemented and tested against a local mock
  sender. It has not been turned on against real senders, by design: it needs your explicit approval
  and a test mailbox with lists you control (SETUP.md §4).
- Production Postgres. The same migrations run on PGlite, which is real Postgres compiled to WASM, but
  no `pg` server has been used here.

### Simulated (development only)
- **Fixture mailbox** (`DEV_FAKE_PROVIDER=true`): 30 synthetic senders, about 1,750 messages. Labelled
  "Fixture mailbox" in Accounts and with a warning banner on Overview. Refused when
  `NODE_ENV=production`.

### Partially implemented
- **Logos**: optional via DuckDuckGo's icon service, off by default for privacy; monogram otherwise.
- **Provider rate limits** are enforced per worker process (Gmail client backoff) plus database-wide
  per-domain spacing. With many worker processes, Gmail per-user quota is shared only through
  Google's 429 responses.

### Not started (deliberately)
- **Outlook / Microsoft 365.** The spec allows it only after Gmail passes live acceptance, which
  needs the Google setup first. `providers/types.ts` is the extension point.

### Unsupported (by decision)
- **Automated completion of unsubscribe web pages** (headless browser filling forms). These pages
  vary widely and often need logins or CAPTCHAs, which the spec forbids bypassing. They are
  browser-assisted instead: the page opens for the user, and the user marks the result.
- **Detecting mailing lists inside the Gmail web UI** from the extension. That would mean scraping
  Gmail's undocumented DOM, which the spec forbids. The extension uses the API and recognises open
  unsubscribe pages instead.
- **AI classification.** Not implemented; rules only. No email data leaves the server.

## Known limitations
- The verification job checks for silence after a 2-day grace period plus the user's verification
  window (default 7 days). Senders that mail less than about monthly end as "Sent, unverifiable".
- An identity whose newest message lacks unsubscribe headers keeps the methods from its last message
  that had them.
- `drizzle-kit` (dev-only migration generator) pulls in an old esbuild with a published dev-server
  advisory. It is not used at runtime or in the production image.
