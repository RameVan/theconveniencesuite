CREATE TABLE "api_tokens" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" uuid NOT NULL,
	"token_hash" text NOT NULL,
	"label" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"last_used_at" timestamp with time zone,
	"revoked_at" timestamp with time zone,
	CONSTRAINT "api_tokens_token_hash_unique" UNIQUE("token_hash")
);
--> statement-breakpoint
CREATE TABLE "categories" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" uuid NOT NULL,
	"slug" text NOT NULL,
	"name" text NOT NULL,
	"is_system" boolean DEFAULT false NOT NULL,
	"is_protected" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "domain_throttle" (
	"domain" text NOT NULL,
	"scope" text NOT NULL,
	"next_allowed_at" timestamp with time zone NOT NULL,
	CONSTRAINT "domain_throttle_domain_scope_pk" PRIMARY KEY("domain","scope")
);
--> statement-breakpoint
CREATE TABLE "jobs" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"type" text NOT NULL,
	"payload" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"status" text DEFAULT 'queued' NOT NULL,
	"run_at" timestamp with time zone DEFAULT now() NOT NULL,
	"attempts" integer DEFAULT 0 NOT NULL,
	"max_attempts" integer DEFAULT 5 NOT NULL,
	"lease_until" timestamp with time zone,
	"locked_by" text,
	"last_error" text,
	"progress" jsonb,
	"user_id" uuid,
	"account_id" uuid,
	"dedupe_key" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"finished_at" timestamp with time zone
);
--> statement-breakpoint
CREATE TABLE "mail_accounts" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" uuid NOT NULL,
	"provider" text NOT NULL,
	"email" text NOT NULL,
	"provider_account_id" text,
	"access_token_enc" text,
	"refresh_token_enc" text,
	"token_expires_at" timestamp with time zone,
	"scopes" text DEFAULT '' NOT NULL,
	"history_id" text,
	"status" text DEFAULT 'active' NOT NULL,
	"status_detail" text,
	"messages_scanned" integer DEFAULT 0 NOT NULL,
	"last_sync_at" timestamp with time zone,
	"full_scan_completed_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "messages" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"account_id" uuid NOT NULL,
	"identity_id" uuid NOT NULL,
	"provider_message_id" text NOT NULL,
	"received_at" timestamp with time zone NOT NULL
);
--> statement-breakpoint
CREATE TABLE "oauth_states" (
	"state" text PRIMARY KEY NOT NULL,
	"purpose" text NOT NULL,
	"user_id" uuid,
	"account_id" uuid,
	"code_verifier" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"expires_at" timestamp with time zone NOT NULL
);
--> statement-breakpoint
CREATE TABLE "preferences" (
	"user_id" uuid PRIMARY KEY NOT NULL,
	"theme" text DEFAULT 'system' NOT NULL,
	"verification_days" integer DEFAULT 7 NOT NULL,
	"mailto_enabled" boolean DEFAULT false NOT NULL,
	"scan_max_messages" integer DEFAULT 20000 NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sender_identities" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" uuid NOT NULL,
	"account_id" uuid NOT NULL,
	"identity_key" text NOT NULL,
	"from_address" text NOT NULL,
	"from_name" text,
	"domain" text NOT NULL,
	"list_id" text,
	"last_subject" text,
	"message_count" integer DEFAULT 0 NOT NULL,
	"first_seen_at" timestamp with time zone NOT NULL,
	"last_seen_at" timestamp with time zone NOT NULL,
	"unsub_http" text,
	"unsub_mailto" text,
	"one_click" boolean DEFAULT false NOT NULL,
	"signals" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"category_id" uuid,
	"category_source" text DEFAULT 'rule' NOT NULL,
	"confidence" real DEFAULT 0 NOT NULL,
	"kind" text DEFAULT 'unknown' NOT NULL,
	"is_protected" boolean DEFAULT false NOT NULL,
	"protection_reason" text,
	"protection_source" text,
	"whitelisted" boolean DEFAULT false NOT NULL,
	"unsub_state" text,
	"unsub_state_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sessions" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" uuid NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"user_agent" text
);
--> statement-breakpoint
CREATE TABLE "unsubscribe_events" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"request_id" uuid NOT NULL,
	"at" timestamp with time zone DEFAULT now() NOT NULL,
	"from_state" text,
	"to_state" text NOT NULL,
	"detail" text
);
--> statement-breakpoint
CREATE TABLE "unsubscribe_requests" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" uuid NOT NULL,
	"account_id" uuid NOT NULL,
	"identity_id" uuid NOT NULL,
	"method" text NOT NULL,
	"target" text,
	"state" text NOT NULL,
	"source" text NOT NULL,
	"batch_id" uuid,
	"dry_run" boolean DEFAULT false NOT NULL,
	"attempts" integer DEFAULT 0 NOT NULL,
	"http_status" integer,
	"last_error" text,
	"submitted_at" timestamp with time zone,
	"verify_after" timestamp with time zone,
	"verified_at" timestamp with time zone,
	"baseline_last_seen_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"email" text NOT NULL,
	"name" text,
	"google_sub" text,
	"avatar_url" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "users_email_unique" UNIQUE("email"),
	CONSTRAINT "users_google_sub_unique" UNIQUE("google_sub")
);
--> statement-breakpoint
ALTER TABLE "api_tokens" ADD CONSTRAINT "api_tokens_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "categories" ADD CONSTRAINT "categories_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "jobs" ADD CONSTRAINT "jobs_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "jobs" ADD CONSTRAINT "jobs_account_id_mail_accounts_id_fk" FOREIGN KEY ("account_id") REFERENCES "public"."mail_accounts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "mail_accounts" ADD CONSTRAINT "mail_accounts_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "messages" ADD CONSTRAINT "messages_account_id_mail_accounts_id_fk" FOREIGN KEY ("account_id") REFERENCES "public"."mail_accounts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "messages" ADD CONSTRAINT "messages_identity_id_sender_identities_id_fk" FOREIGN KEY ("identity_id") REFERENCES "public"."sender_identities"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "oauth_states" ADD CONSTRAINT "oauth_states_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "preferences" ADD CONSTRAINT "preferences_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "sender_identities" ADD CONSTRAINT "sender_identities_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "sender_identities" ADD CONSTRAINT "sender_identities_account_id_mail_accounts_id_fk" FOREIGN KEY ("account_id") REFERENCES "public"."mail_accounts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "sender_identities" ADD CONSTRAINT "sender_identities_category_id_categories_id_fk" FOREIGN KEY ("category_id") REFERENCES "public"."categories"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "sessions" ADD CONSTRAINT "sessions_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "unsubscribe_events" ADD CONSTRAINT "unsubscribe_events_request_id_unsubscribe_requests_id_fk" FOREIGN KEY ("request_id") REFERENCES "public"."unsubscribe_requests"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "unsubscribe_requests" ADD CONSTRAINT "unsubscribe_requests_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "unsubscribe_requests" ADD CONSTRAINT "unsubscribe_requests_account_id_mail_accounts_id_fk" FOREIGN KEY ("account_id") REFERENCES "public"."mail_accounts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "unsubscribe_requests" ADD CONSTRAINT "unsubscribe_requests_identity_id_sender_identities_id_fk" FOREIGN KEY ("identity_id") REFERENCES "public"."sender_identities"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "categories_user_slug" ON "categories" USING btree ("user_id","slug");--> statement-breakpoint
CREATE INDEX "jobs_claim" ON "jobs" USING btree ("status","run_at");--> statement-breakpoint
CREATE INDEX "jobs_user" ON "jobs" USING btree ("user_id","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "jobs_dedupe_open" ON "jobs" USING btree ("dedupe_key") WHERE status in ('queued','running','paused');--> statement-breakpoint
CREATE UNIQUE INDEX "mail_accounts_user_email" ON "mail_accounts" USING btree ("user_id","email");--> statement-breakpoint
CREATE UNIQUE INDEX "messages_account_provider_id" ON "messages" USING btree ("account_id","provider_message_id");--> statement-breakpoint
CREATE INDEX "messages_identity_received" ON "messages" USING btree ("identity_id","received_at");--> statement-breakpoint
CREATE UNIQUE INDEX "identities_account_key" ON "sender_identities" USING btree ("account_id","identity_key");--> statement-breakpoint
CREATE INDEX "identities_user_last_seen" ON "sender_identities" USING btree ("user_id","last_seen_at");--> statement-breakpoint
CREATE INDEX "identities_user_count" ON "sender_identities" USING btree ("user_id","message_count");--> statement-breakpoint
CREATE INDEX "identities_user_category" ON "sender_identities" USING btree ("user_id","category_id");--> statement-breakpoint
CREATE INDEX "identities_user_domain" ON "sender_identities" USING btree ("user_id","domain");--> statement-breakpoint
CREATE INDEX "sessions_user_idx" ON "sessions" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "unsub_events_request" ON "unsubscribe_events" USING btree ("request_id");--> statement-breakpoint
CREATE UNIQUE INDEX "unsub_one_active_per_identity" ON "unsubscribe_requests" USING btree ("identity_id") WHERE state in ('awaiting_approval','queued','processing','awaiting_confirmation','request_submitted','verification_pending','requires_manual_action');--> statement-breakpoint
CREATE INDEX "unsub_user_created" ON "unsubscribe_requests" USING btree ("user_id","created_at");--> statement-breakpoint
CREATE INDEX "unsub_batch" ON "unsubscribe_requests" USING btree ("batch_id");