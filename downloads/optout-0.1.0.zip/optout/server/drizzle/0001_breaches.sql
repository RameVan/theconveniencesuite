CREATE TABLE "breach_checks" (
	"user_id" uuid NOT NULL,
	"email" text NOT NULL,
	"status" text NOT NULL,
	"error" text,
	"checked_at" timestamp with time zone NOT NULL,
	CONSTRAINT "breach_checks_user_id_email_pk" PRIMARY KEY("user_id","email")
);
--> statement-breakpoint
CREATE TABLE "breach_hits" (
	"user_id" uuid NOT NULL,
	"email" text NOT NULL,
	"breach_name" text NOT NULL,
	"first_seen_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "breach_hits_user_id_email_breach_name_pk" PRIMARY KEY("user_id","email","breach_name")
);
--> statement-breakpoint
CREATE TABLE "breaches" (
	"name" text PRIMARY KEY NOT NULL,
	"title" text NOT NULL,
	"domain" text DEFAULT '' NOT NULL,
	"breach_date" text,
	"added_date" timestamp with time zone,
	"pwn_count" bigint DEFAULT 0 NOT NULL,
	"data_classes" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"logo_path" text,
	"is_verified" boolean DEFAULT true NOT NULL,
	"is_sensitive" boolean DEFAULT false NOT NULL,
	"is_spam_list" boolean DEFAULT false NOT NULL,
	"is_fabricated" boolean DEFAULT false NOT NULL,
	"source" text DEFAULT 'hibp' NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "preferences" ADD COLUMN "breach_consent" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "breach_checks" ADD CONSTRAINT "breach_checks_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "breach_hits" ADD CONSTRAINT "breach_hits_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "breaches_domain" ON "breaches" USING btree ("domain");