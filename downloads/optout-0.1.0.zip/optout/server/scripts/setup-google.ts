// Interactive setup for Google OAuth credentials:
//   npm run setup:google --workspace server
// Asks for the client ID and secret (secret is not echoed), checks them with Google, and
// writes them to server/.env. Nothing is printed or logged.
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { createInterface } from 'node:readline';
import { Writable } from 'node:stream';

const envPath = resolve(import.meta.dirname, '../.env');
const examplePath = resolve(import.meta.dirname, '../.env.example');

function ask(question: string, hidden = false): Promise<string> {
  let muted = false;
  const output = new Writable({ write(chunk, _enc, cb) { if (!muted) process.stdout.write(chunk); cb(); } });
  const rl = createInterface({ input: process.stdin, output, terminal: true });
  return new Promise((done) => {
    rl.question(question, (answer) => { rl.close(); if (hidden) process.stdout.write('\n'); done(answer.trim()); });
    muted = hidden;
  });
}

function readEnv(): string {
  if (existsSync(envPath)) return readFileSync(envPath, 'utf8');
  return existsSync(examplePath) ? readFileSync(examplePath, 'utf8') : '';
}

function setVar(env: string, key: string, value: string): string {
  const line = `${key}=${value}`;
  const re = new RegExp(`^${key}=.*$`, 'm');
  return re.test(env) ? env.replace(re, line) : `${env.replace(/\n?$/, '\n')}${line}\n`;
}

/** Google answers a bogus code with invalid_grant for a valid client, invalid_client otherwise. */
async function checkWithGoogle(clientId: string, secret: string, redirect: string): Promise<'ok' | 'bad_client' | 'unreachable'> {
  try {
    const res = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ client_id: clientId, client_secret: secret, code: 'setup-check', grant_type: 'authorization_code', redirect_uri: redirect, code_verifier: 'x'.repeat(43) }),
    });
    const body = await res.json().catch(() => ({})) as { error?: string };
    return body.error === 'invalid_client' || body.error === 'unauthorized_client' ? 'bad_client' : 'ok';
  } catch {
    return 'unreachable';
  }
}

let env = readEnv();
const origin = (/^APP_ORIGIN=(.*)$/m.exec(env)?.[1] || 'http://localhost:8790').trim().replace(/\/$/, '');
const redirect = `${origin}/auth/google/callback`;
console.log('\nGoogle OAuth setup for Opt Out');
console.log(`In your OAuth client (type "Web application"), the authorised redirect URI must be:\n  ${redirect}\n`);

const clientId = await ask('Client ID: ');
if (!/^[\w-]+\.apps\.googleusercontent\.com$/.test(clientId)) {
  console.error('That does not look like a Google OAuth client ID (it ends in .apps.googleusercontent.com).');
  process.exit(1);
}
const secret = await ask('Client secret (hidden): ', true);
if (secret.length < 10) { console.error('That secret looks too short.'); process.exit(1); }

process.stdout.write('Checking with Google… ');
const check = await checkWithGoogle(clientId, secret, redirect);
if (check === 'bad_client') {
  console.error('\nGoogle rejected this client ID and secret combination. Copy both again from the Credentials page.');
  process.exit(1);
}
console.log(check === 'ok' ? 'accepted.' : 'could not reach Google; saving anyway.');

env = setVar(env, 'GOOGLE_CLIENT_ID', clientId);
env = setVar(env, 'GOOGLE_CLIENT_SECRET', secret);
writeFileSync(envPath, env, { mode: 0o600 });
console.log(`Saved to ${envPath}. Restart the server, then sign in with Google.`);
console.log('Reminder: while the app is in "Testing", only the test users you added can sign in, and Google expires its refresh tokens after 7 days.');
