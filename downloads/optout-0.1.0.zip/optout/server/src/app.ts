import Fastify from 'fastify';
import cookie from '@fastify/cookie';
import rateLimit from '@fastify/rate-limit';
import fastifyStatic from '@fastify/static';
import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import type { DB } from './db/client.ts';
import { config } from './config.ts';
import { authRoutes } from './routes/auth.ts';
import { apiRoutes } from './routes/api.ts';

export async function buildApp(db: DB, opts: { onJobQueued?: () => void; logger?: boolean } = {}) {
  const app = Fastify({
    logger: opts.logger ? { level: 'warn', redact: ['req.headers.authorization', 'req.headers.cookie'] } : false,
    trustProxy: config.isProd,
    bodyLimit: 1024 * 1024,
  });
  const notify = opts.onJobQueued ?? (() => {});
  await app.register(cookie);
  await app.register(rateLimit, { max: 600, timeWindow: '1 minute', allowList: () => config.isTest });

  app.addHook('onSend', async (_req, reply) => {
    reply.header('content-security-policy', "default-src 'self'; img-src 'self' data: https://icons.duckduckgo.com https://logos.haveibeenpwned.com https://xposedornot.com; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
    reply.header('x-content-type-options', 'nosniff');
    reply.header('referrer-policy', 'same-origin');
    reply.header('x-frame-options', 'DENY');
    if (config.appOrigin.startsWith('https://')) reply.header('strict-transport-security', 'max-age=31536000; includeSubDomains');
  });

  app.get('/healthz', async () => ({ ok: true }));
  authRoutes(app, db, notify);
  apiRoutes(app, db, notify);

  // Serve the built web app in production (single origin keeps cookies simple).
  const dist = resolve(import.meta.dirname, '../../web/dist');
  if (existsSync(dist)) {
    await app.register(fastifyStatic, { root: dist });
    app.setNotFoundHandler((req, reply) => {
      const spaRoute = !/^\/(api|auth|assets)\//.test(req.url) && !/\.[a-z0-9]+$/i.test(req.url.split('?')[0]);
      if (req.method === 'GET' && spaRoute) return reply.sendFile('index.html');
      return reply.code(404).send({ error: 'not found' });
    });
  }
  return app;
}
