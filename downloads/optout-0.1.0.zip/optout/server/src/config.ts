import { readFileSync, existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { randomBytes } from 'node:crypto';

// Minimal .env loader so the server runs without extra dependencies.
function loadDotEnv(path: string): void {
  if (!existsSync(path)) return;
  for (const line of readFileSync(path, 'utf8').split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/.exec(line);
    if (!m || line.trimStart().startsWith('#')) continue;
    if (process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^"(.*)"$/, '$1');
  }
}
loadDotEnv(resolve(import.meta.dirname, '../.env'));

const env = process.env;
const isProd = env.NODE_ENV === 'production';
const isTest = env.NODE_ENV === 'test';

function key(name: string): Buffer {
  const v = env[name];
  if (v) {
    const buf = Buffer.from(v, 'base64');
    if (buf.length !== 32) throw new Error(`${name} must be 32 bytes, base64-encoded`);
    return buf;
  }
  if (isProd) throw new Error(`${name} is required in production`);
  // Development fallback: a random key kept next to the local database.
  const file = resolve(config_dataDir(), `.${name.toLowerCase()}`);
  if (existsSync(file)) return Buffer.from(readFileSync(file, 'utf8').trim(), 'base64');
  const k = randomBytes(32);
  mkdirSync(config_dataDir(), { recursive: true });
  writeFileSync(file, k.toString('base64'), { mode: 0o600 });
  return k;
}

function config_dataDir(): string {
  return resolve(import.meta.dirname, '..', env.DATA_DIR ?? './data');
}

const devFake = env.DEV_FAKE_PROVIDER === 'true';
if (devFake && isProd) throw new Error('DEV_FAKE_PROVIDER cannot be enabled in production');

export const config = {
  isProd,
  isTest,
  port: Number(env.PORT ?? 8790),
  appOrigin: (env.APP_ORIGIN ?? 'http://localhost:8790').replace(/\/$/, ''),
  databaseUrl: env.DATABASE_URL || '',
  dataDir: config_dataDir(),
  encryptionKey: isTest ? Buffer.alloc(32, 7) : key('TOKEN_ENCRYPTION_KEY'),
  google: {
    clientId: env.GOOGLE_CLIENT_ID ?? '',
    clientSecret: env.GOOGLE_CLIENT_SECRET ?? '',
  },
  unsubscribeMode: (env.UNSUBSCRIBE_MODE === 'live' ? 'live' : 'dry_run') as 'live' | 'dry_run',
  embeddedWorker: env.EMBEDDED_WORKER !== 'false',
  workerConcurrency: Math.max(1, Number(env.WORKER_CONCURRENCY ?? 4)),
  extensionIds: (env.EXTENSION_IDS ?? '').split(',').map((s) => s.trim()).filter(Boolean),
  devFakeProvider: devFake,
  // Have I Been Pwned API key (paid). Only needed for looking up the user's own addresses;
  // the public breach catalogue needs no key.
  hibpApiKey: env.HIBP_API_KEY ?? '',
  // auto | hibp | xposedornot. auto uses HIBP when a key is set, otherwise free XposedOrNot.
  breachProvider: (['hibp', 'xposedornot'].includes(env.BREACH_PROVIDER ?? '') ? env.BREACH_PROVIDER : 'auto') as 'auto' | 'hibp' | 'xposedornot',
  // Upper bound for a single bulk request; the UI also shows a confirmation screen.
  bulkMax: Number(env.BULK_MAX ?? 250),
  // How long a worker may hold a job without a heartbeat before another worker takes it over.
  jobLeaseMs: Math.max(1000, Number(env.JOB_LEASE_MS ?? 120000)),
  sessionDays: 30,
};

export function googleConfigured(): boolean {
  return Boolean(config.google.clientId && config.google.clientSecret);
}
