import { mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
import type { PgDatabase, PgQueryResultHKT } from 'drizzle-orm/pg-core';
import { config } from '../config.ts';
import * as schema from './schema.ts';

export type DB = PgDatabase<PgQueryResultHKT, typeof schema>;

export interface Database {
  db: DB;
  close(): Promise<void>;
}

const migrationsFolder = resolve(import.meta.dirname, '../../drizzle');

/** Opens Postgres (DATABASE_URL) or an embedded PGlite database, then applies migrations. */
export async function openDatabase(opts: { memory?: boolean } = {}): Promise<Database> {
  if (config.databaseUrl && !opts.memory) {
    const { default: pg } = await import('pg');
    const { drizzle } = await import('drizzle-orm/node-postgres');
    const { migrate } = await import('drizzle-orm/node-postgres/migrator');
    const pool = new pg.Pool({ connectionString: config.databaseUrl, max: 10 });
    const db = drizzle(pool, { schema }) as unknown as DB;
    await migrate(db as never, { migrationsFolder });
    return { db, close: () => pool.end() };
  }
  const { PGlite } = await import('@electric-sql/pglite');
  const { drizzle } = await import('drizzle-orm/pglite');
  const { migrate } = await import('drizzle-orm/pglite/migrator');
  let client;
  if (opts.memory) client = new PGlite();
  else {
    mkdirSync(config.dataDir, { recursive: true });
    client = new PGlite(resolve(config.dataDir, 'pg'));
  }
  const db = drizzle(client, { schema }) as unknown as DB;
  await migrate(db as never, { migrationsFolder });
  return { db, close: () => client.close() };
}
