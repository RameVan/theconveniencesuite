import { openDatabase } from './client.ts';

const { close } = await openDatabase();
await close();
console.log('migrations applied');
