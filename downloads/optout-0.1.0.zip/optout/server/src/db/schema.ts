import { sql } from 'drizzle-orm';
import {
  pgTable, uuid, text, timestamp, integer, boolean, real, jsonb, bigserial, bigint,
  uniqueIndex, index, primaryKey,
} from 'drizzle-orm/pg-core';

const ts = (name: string) => timestamp(name, { withTimezone: true });
const createdAt = () => ts('created_at').notNull().defaultNow();

export const users = pgTable('users', {
  id: uuid('id').primaryKey().defaultRandom(),
  email: text('email').notNull().unique(),
  name: text('name'),
  googleSub: text('google_sub').unique(),
  avatarUrl: text('avatar_url'),
  createdAt: createdAt(),
});

export const sessions = pgTable('sessions', {
  // SHA-256 of the cookie value; the raw token is never stored.
  id: text('id').primaryKey(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  createdAt: createdAt(),
  expiresAt: ts('expires_at').notNull(),
  userAgent: text('user_agent'),
}, (t) => [index('sessions_user_idx').on(t.userId)]);

export const apiTokens = pgTable('api_tokens', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  tokenHash: text('token_hash').notNull().unique(),
  label: text('label').notNull(),
  createdAt: createdAt(),
  lastUsedAt: ts('last_used_at'),
  revokedAt: ts('revoked_at'),
});

export const oauthStates = pgTable('oauth_states', {
  state: text('state').primaryKey(),
  purpose: text('purpose').notNull(), // login | connect | send_scope
  userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }),
  accountId: uuid('account_id'),
  codeVerifier: text('code_verifier').notNull(),
  createdAt: createdAt(),
  expiresAt: ts('expires_at').notNull(),
});

export const mailAccounts = pgTable('mail_accounts', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  provider: text('provider').notNull(), // gmail | fake
  email: text('email').notNull(),
  providerAccountId: text('provider_account_id'),
  accessTokenEnc: text('access_token_enc'),
  refreshTokenEnc: text('refresh_token_enc'),
  tokenExpiresAt: ts('token_expires_at'),
  scopes: text('scopes').notNull().default(''),
  historyId: text('history_id'),
  status: text('status').notNull().default('active'), // active | reauth_required | disconnected
  statusDetail: text('status_detail'),
  messagesScanned: integer('messages_scanned').notNull().default(0),
  lastSyncAt: ts('last_sync_at'),
  fullScanCompletedAt: ts('full_scan_completed_at'),
  createdAt: createdAt(),
}, (t) => [uniqueIndex('mail_accounts_user_email').on(t.userId, t.email)]);

export const categories = pgTable('categories', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  slug: text('slug').notNull(),
  name: text('name').notNull(),
  isSystem: boolean('is_system').notNull().default(false),
  // Identities in a protected category are excluded from bulk unsubscribe.
  isProtected: boolean('is_protected').notNull().default(false),
  createdAt: createdAt(),
}, (t) => [uniqueIndex('categories_user_slug').on(t.userId, t.slug)]);

export const senderIdentities = pgTable('sender_identities', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  accountId: uuid('account_id').notNull().references(() => mailAccounts.id, { onDelete: 'cascade' }),
  // list:<list-id> or addr:<from-address>
  identityKey: text('identity_key').notNull(),
  fromAddress: text('from_address').notNull(),
  fromName: text('from_name'),
  domain: text('domain').notNull(),
  listId: text('list_id'),
  lastSubject: text('last_subject'),
  messageCount: integer('message_count').notNull().default(0),
  firstSeenAt: ts('first_seen_at').notNull(),
  lastSeenAt: ts('last_seen_at').notNull(),
  // Unsubscribe methods discovered from the most recent message that had them.
  unsubHttp: text('unsub_http'),
  unsubMailto: text('unsub_mailto'),
  oneClick: boolean('one_click').notNull().default(false),
  // Signal counters gathered per message; classification is recomputed from them.
  signals: jsonb('signals').$type<Record<string, number>>().notNull().default({}),
  categoryId: uuid('category_id').references(() => categories.id, { onDelete: 'set null' }),
  categorySource: text('category_source').notNull().default('rule'), // rule | user
  confidence: real('confidence').notNull().default(0),
  kind: text('kind').notNull().default('unknown'), // marketing | transactional | personal | unknown
  isProtected: boolean('is_protected').notNull().default(false),
  protectionReason: text('protection_reason'),
  protectionSource: text('protection_source'), // auto | user | override
  whitelisted: boolean('whitelisted').notNull().default(false),
  // Mirror of the latest unsubscribe request state (null = never attempted).
  unsubState: text('unsub_state'),
  unsubStateAt: ts('unsub_state_at'),
  createdAt: createdAt(),
  updatedAt: ts('updated_at').notNull().defaultNow(),
}, (t) => [
  uniqueIndex('identities_account_key').on(t.accountId, t.identityKey),
  index('identities_user_last_seen').on(t.userId, t.lastSeenAt),
  index('identities_user_count').on(t.userId, t.messageCount),
  index('identities_user_category').on(t.userId, t.categoryId),
  index('identities_user_domain').on(t.userId, t.domain),
]);

export const messages = pgTable('messages', {
  id: bigserial('id', { mode: 'number' }).primaryKey(),
  accountId: uuid('account_id').notNull().references(() => mailAccounts.id, { onDelete: 'cascade' }),
  identityId: uuid('identity_id').notNull().references(() => senderIdentities.id, { onDelete: 'cascade' }),
  providerMessageId: text('provider_message_id').notNull(),
  receivedAt: ts('received_at').notNull(),
}, (t) => [
  uniqueIndex('messages_account_provider_id').on(t.accountId, t.providerMessageId),
  index('messages_identity_received').on(t.identityId, t.receivedAt),
]);

export const ACTIVE_UNSUB_STATES = [
  'awaiting_approval', 'queued', 'processing', 'awaiting_confirmation', 'request_submitted',
  'verification_pending', 'requires_manual_action',
] as const;

export const unsubscribeRequests = pgTable('unsubscribe_requests', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  accountId: uuid('account_id').notNull().references(() => mailAccounts.id, { onDelete: 'cascade' }),
  identityId: uuid('identity_id').notNull().references(() => senderIdentities.id, { onDelete: 'cascade' }),
  method: text('method').notNull(), // one_click | mailto | web | manual
  target: text('target'),
  state: text('state').notNull(),
  source: text('source').notNull(), // web | extension
  batchId: uuid('batch_id'),
  dryRun: boolean('dry_run').notNull().default(false),
  attempts: integer('attempts').notNull().default(0),
  httpStatus: integer('http_status'),
  lastError: text('last_error'),
  submittedAt: ts('submitted_at'),
  verifyAfter: ts('verify_after'),
  verifiedAt: ts('verified_at'),
  // Set just before a network send and cleared after its outcome is saved. Still set when a job
  // starts means the previous attempt died mid-send (crash), so the send may have happened.
  inFlightAt: ts('in_flight_at'),
  // Message count when submitted; verification compares against later mail.
  baselineLastSeenAt: ts('baseline_last_seen_at'),
  createdAt: createdAt(),
  updatedAt: ts('updated_at').notNull().defaultNow(),
}, (t) => [
  // One active request per identity: the database, not the UI, prevents duplicate execution.
  uniqueIndex('unsub_one_active_per_identity').on(t.identityId)
    .where(sql`state in ('awaiting_approval','queued','processing','awaiting_confirmation','request_submitted','verification_pending','requires_manual_action')`),
  index('unsub_user_created').on(t.userId, t.createdAt),
  index('unsub_batch').on(t.batchId),
]);

export const unsubscribeEvents = pgTable('unsubscribe_events', {
  id: bigserial('id', { mode: 'number' }).primaryKey(),
  requestId: uuid('request_id').notNull().references(() => unsubscribeRequests.id, { onDelete: 'cascade' }),
  at: ts('at').notNull().defaultNow(),
  fromState: text('from_state'),
  toState: text('to_state').notNull(),
  detail: text('detail'),
}, (t) => [index('unsub_events_request').on(t.requestId)]);

export const jobs = pgTable('jobs', {
  id: uuid('id').primaryKey().defaultRandom(),
  type: text('type').notNull(),
  payload: jsonb('payload').$type<Record<string, unknown>>().notNull().default({}),
  status: text('status').notNull().default('queued'), // queued | running | succeeded | failed | cancelled | paused
  runAt: ts('run_at').notNull().defaultNow(),
  attempts: integer('attempts').notNull().default(0),
  maxAttempts: integer('max_attempts').notNull().default(5),
  leaseUntil: ts('lease_until'),
  lockedBy: text('locked_by'),
  lastError: text('last_error'),
  progress: jsonb('progress').$type<Record<string, unknown>>(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }),
  accountId: uuid('account_id').references(() => mailAccounts.id, { onDelete: 'cascade' }),
  // Unique while the job is unfinished, so the same scan or unsubscribe is never queued twice.
  dedupeKey: text('dedupe_key'),
  createdAt: createdAt(),
  updatedAt: ts('updated_at').notNull().defaultNow(),
  finishedAt: ts('finished_at'),
}, (t) => [
  index('jobs_claim').on(t.status, t.runAt),
  index('jobs_user').on(t.userId, t.createdAt),
  uniqueIndex('jobs_dedupe_open').on(t.dedupeKey).where(sql`status in ('queued','running','paused')`),
]);

export const preferences = pgTable('preferences', {
  userId: uuid('user_id').primaryKey().references(() => users.id, { onDelete: 'cascade' }),
  theme: text('theme').notNull().default('system'),
  // Days of silence after submission before an unsubscribe counts as verified.
  verificationDays: integer('verification_days').notNull().default(7),
  mailtoEnabled: boolean('mailto_enabled').notNull().default(false),
  scanMaxMessages: integer('scan_max_messages').notNull().default(20000),
  // Explicit consent to send the user's addresses to Have I Been Pwned.
  breachConsent: boolean('breach_consent').notNull().default(false),
  updatedAt: ts('updated_at').notNull().defaultNow(),
});

// Public breach catalogue (Have I Been Pwned, CC BY 4.0). Holds no user data.
export const breaches = pgTable('breaches', {
  name: text('name').primaryKey(),
  title: text('title').notNull(),
  domain: text('domain').notNull().default(''),
  breachDate: text('breach_date'),
  addedDate: ts('added_date'),
  pwnCount: bigint('pwn_count', { mode: 'number' }).notNull().default(0),
  dataClasses: jsonb('data_classes').$type<string[]>().notNull().default([]),
  description: text('description').notNull().default(''),
  logoPath: text('logo_path'),
  isVerified: boolean('is_verified').notNull().default(true),
  isSensitive: boolean('is_sensitive').notNull().default(false),
  isSpamList: boolean('is_spam_list').notNull().default(false),
  isFabricated: boolean('is_fabricated').notNull().default(false),
  source: text('source').notNull().default('hibp'), // hibp | fixture
  updatedAt: ts('updated_at').notNull().defaultNow(),
}, (t) => [index('breaches_domain').on(t.domain)]);

// One row per address checked for a user.
export const breachChecks = pgTable('breach_checks', {
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  email: text('email').notNull(),
  status: text('status').notNull(), // ok | error
  error: text('error'),
  checkedAt: ts('checked_at').notNull(),
}, (t) => [primaryKey({ columns: [t.userId, t.email] })]);

// Breaches an address appears in, as reported by the lookup.
export const breachHits = pgTable('breach_hits', {
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  email: text('email').notNull(),
  breachName: text('breach_name').notNull(),
  firstSeenAt: ts('first_seen_at').notNull().defaultNow(),
}, (t) => [primaryKey({ columns: [t.userId, t.email, t.breachName] })]);

// Spacing between requests to one sender domain, shared by all workers.
export const domainThrottle = pgTable('domain_throttle', {
  domain: text('domain').notNull(),
  scope: text('scope').notNull(),
  nextAllowedAt: ts('next_allowed_at').notNull(),
}, (t) => [primaryKey({ columns: [t.domain, t.scope] })]);
