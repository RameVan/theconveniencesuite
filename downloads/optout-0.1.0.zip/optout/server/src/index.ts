import { config } from './config.ts';
import { openDatabase } from './db/client.ts';
import { buildApp } from './app.ts';
import { createWorker, startMaintenance } from './jobs-runtime.ts';
import { log } from './lib/log.ts';

const { db, close } = await openDatabase();
const worker = config.embeddedWorker ? createWorker(db) : null;
const app = await buildApp(db, { onJobQueued: () => worker?.notify(), logger: true });
const stopMaintenance = config.embeddedWorker ? startMaintenance(db) : () => {};

await app.listen({ port: config.port, host: config.isProd ? '0.0.0.0' : '127.0.0.1' });
worker?.start();
log.info('server listening', { port: config.port, worker: Boolean(worker), unsubscribeMode: config.unsubscribeMode, database: config.databaseUrl ? 'postgres' : 'pglite' });

let stopping = false;
async function shutdown(signal: string) {
  if (stopping) return;
  stopping = true;
  log.info('shutting down', { signal });
  stopMaintenance();
  await app.close();
  await worker?.stop(); // in-flight jobs finish; anything else is resumed after restart
  await close();
  process.exit(0);
}
process.on('SIGINT', () => void shutdown('SIGINT'));
process.on('SIGTERM', () => void shutdown('SIGTERM'));
