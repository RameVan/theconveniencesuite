import { eq, and, lt, sql } from 'drizzle-orm';
import type { DB } from './db/client.ts';
import { mailAccounts, oauthStates, sessions } from './db/schema.ts';
import { config } from './config.ts';
import { Worker } from './modules/jobs/queue.ts';
import { scanHandler, enqueueScan } from './modules/discovery/scan.ts';
import { reconcileRequests, unsubscribeHandler, verifyHandler } from './modules/unsubscribe/engine.ts';
import { log, errMsg } from './lib/log.ts';
import { breachMaintenance, catalogueHandler, checkHandler } from './modules/breaches/service.ts';

export const handlers = {
  scan: scanHandler, unsubscribe: unsubscribeHandler, verify: verifyHandler,
  'breach-catalogue': catalogueHandler, 'breach-check': checkHandler,
};

export function createWorker(db: DB, concurrency = config.workerConcurrency): Worker {
  return new Worker(db, handlers, concurrency);
}

const SYNC_EVERY_MS = 6 * 3600 * 1000;

/** Periodic housekeeping: incremental sync, stuck-request recovery, expired sessions. */
export async function maintenance(db: DB): Promise<void> {
  const stale = await db.select().from(mailAccounts)
    .where(and(eq(mailAccounts.status, 'active'), sql`${mailAccounts.historyId} is not null`, lt(mailAccounts.lastSyncAt, new Date(Date.now() - SYNC_EVERY_MS))));
  for (const a of stale) await enqueueScan(db, a, 'incremental');
  const recovered = await reconcileRequests(db);
  if (recovered) log.warn('marked interrupted unsubscribe requests as failed', { count: recovered });
  await breachMaintenance(db);
  await db.delete(sessions).where(lt(sessions.expiresAt, new Date()));
  await db.delete(oauthStates).where(lt(oauthStates.expiresAt, new Date()));
  // Minimal retention: finished jobs are only kept for 30 days.
  await db.execute(sql`delete from jobs where status in ('succeeded','failed','cancelled') and finished_at < now() - interval '30 days'`);
}

export function startMaintenance(db: DB, everyMs = 10 * 60 * 1000): () => void {
  const run = () => maintenance(db).catch((e) => log.error('maintenance failed', { error: errMsg(e) }));
  const first = setTimeout(run, 5000);
  const t = setInterval(run, everyMs);
  return () => { clearTimeout(first); clearInterval(t); };
}
