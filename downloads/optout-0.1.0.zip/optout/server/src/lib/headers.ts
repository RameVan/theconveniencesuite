// Parsing of the email headers the discovery engine relies on.

export interface ParsedFrom { address: string; name: string | null; domain: string }

/** Decodes RFC 2047 encoded-words (=?charset?B|Q?...?=). */
export function decodeWords(s: string): string {
  return s.replace(/=\?([^?]+)\?([BbQq])\?([^?]*)\?=(\s+(?==\?))?/g, (_m, charset: string, enc: string, text: string) => {
    try {
      const bytes = enc.toUpperCase() === 'B'
        ? Buffer.from(text, 'base64')
        : Buffer.from(text.replace(/_/g, ' ').replace(/=([0-9A-Fa-f]{2})/g, (_x, h: string) => String.fromCharCode(parseInt(h, 16))), 'latin1');
      return new TextDecoder(charset.toLowerCase() === 'utf8' ? 'utf-8' : charset).decode(bytes);
    } catch {
      return text;
    }
  });
}

export function parseFrom(raw: string | undefined): ParsedFrom | null {
  if (!raw) return null;
  const v = decodeWords(raw).trim();
  let address: string | undefined;
  let name: string | null = null;
  const angle = /^(.*)<([^<>]+)>\s*$/.exec(v);
  if (angle) {
    address = angle[2].trim();
    name = angle[1].trim().replace(/^"(.*)"$/, '$1').replace(/\\"/g, '"').trim() || null;
  } else {
    const m = /([^\s<>()"]+@[^\s<>()"]+)/.exec(v);
    address = m?.[1];
  }
  if (!address || !address.includes('@')) return null;
  address = address.toLowerCase();
  const domain = address.slice(address.lastIndexOf('@') + 1);
  if (!domain) return null;
  return { address, name, domain };
}

/** List-Id: "Some list <list.example.com>" -> "list.example.com". */
export function parseListId(raw: string | undefined): string | null {
  if (!raw) return null;
  const m = /<([^<>]+)>/.exec(raw);
  const id = (m ? m[1] : raw).trim().toLowerCase();
  return id && id.length <= 255 ? id : null;
}

export interface UnsubMethods { http: string | null; mailto: string | null; oneClick: boolean }

/** Parses List-Unsubscribe (RFC 2369) and List-Unsubscribe-Post (RFC 8058). */
export function parseListUnsubscribe(raw: string | undefined, post: string | undefined): UnsubMethods {
  const out: UnsubMethods = { http: null, mailto: null, oneClick: false };
  if (!raw) return out;
  let uris = [...raw.matchAll(/<\s*([^<>]+?)\s*>/g)].map((m) => m[1].replace(/\s+/g, ''));
  // RFC 2369 requires angle brackets, but some senders send bare URIs.
  if (!uris.length) uris = raw.split(',').map((s) => s.trim().split(/\s/)[0]).filter(Boolean);
  let plainHttp: string | null = null;
  for (const uri of uris) {
    const lower = uri.toLowerCase();
    if (!out.mailto && lower.startsWith('mailto:')) out.mailto = uri;
    else if (!out.http && lower.startsWith('https://')) out.http = uri;
    else if (!plainHttp && lower.startsWith('http://')) plainHttp = uri;
  }
  // Prefer HTTPS: one-click needs it, and it is the safer link to open.
  out.http ??= plainHttp;
  // RFC 8058: one-click needs the exact POST body token and an HTTPS URI.
  out.oneClick = Boolean(
    out.http?.toLowerCase().startsWith('https://') &&
    post && /^\s*List-Unsubscribe\s*=\s*One-Click\s*$/i.test(post),
  );
  return out;
}

export interface Mailto { to: string; subject: string; body: string }

export function parseMailto(uri: string): Mailto | null {
  if (!/^mailto:/i.test(uri)) return null;
  const rest = uri.slice(7);
  const q = rest.indexOf('?');
  let to: string;
  try { to = decodeURIComponent(q >= 0 ? rest.slice(0, q) : rest).trim(); } catch { return null; }
  if (!/^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+$/.test(to)) return null; // single recipient only
  const params = new URLSearchParams(q >= 0 ? rest.slice(q + 1) : '');
  const clean = (s: string | null, d: string) => (s ?? '').replace(/[\r\n]+/g, ' ').trim().slice(0, 300) || d;
  return { to, subject: clean(params.get('subject'), 'unsubscribe'), body: clean(params.get('body'), 'unsubscribe') };
}

/** Registrable-ish domain: last two labels, or three for common two-level TLDs. */
export function baseDomain(domain: string): string {
  const parts = domain.toLowerCase().split('.').filter(Boolean);
  if (parts.length <= 2) return parts.join('.');
  const sld = parts[parts.length - 2];
  const twoLevel = ['co', 'com', 'org', 'net', 'ac', 'gov', 'edu'].includes(sld) && parts[parts.length - 1].length === 2;
  return parts.slice(twoLevel ? -3 : -2).join('.');
}
