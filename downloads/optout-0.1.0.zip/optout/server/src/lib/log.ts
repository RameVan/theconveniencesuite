// Logging that never prints tokens, email addresses or URL query strings.
const EMAIL = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;
const SECRET = /(Bearer|access_token|refresh_token|code|token)([=: ]+)[A-Za-z0-9._~+/-]{8,}/gi;

export function redact(s: string): string {
  return s
    .replace(SECRET, '$1$2[redacted]')
    .replace(EMAIL, '[email]')
    .replace(/(https?:\/\/[^\s?#"]+)[?#][^\s"]*/g, '$1?[redacted]');
}

type Level = 'info' | 'warn' | 'error';
function emit(level: Level, msg: string, extra?: Record<string, unknown>): void {
  if (process.env.NODE_ENV === 'test' && level !== 'error') return;
  const line = { t: new Date().toISOString(), level, msg: redact(msg), ...(extra ? JSON.parse(redact(JSON.stringify(extra))) : {}) };
  (level === 'error' ? console.error : console.log)(JSON.stringify(line));
}

export const log = {
  info: (m: string, e?: Record<string, unknown>) => emit('info', m, e),
  warn: (m: string, e?: Record<string, unknown>) => emit('warn', m, e),
  error: (m: string, e?: Record<string, unknown>) => emit('error', m, e),
};

export function errMsg(e: unknown): string {
  return redact(e instanceof Error ? e.message : String(e)).slice(0, 500);
}
