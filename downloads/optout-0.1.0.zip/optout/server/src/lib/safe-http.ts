import { lookup } from 'node:dns';
import { isIP } from 'node:net';
import https from 'node:https';
import http from 'node:http';
import type { LookupFunction } from 'node:net';

export class UnsafeDestinationError extends Error {}

export interface SafeHttpOptions {
  /** Tests only: permit loopback/private addresses and non-standard ports. */
  allowPrivate?: boolean;
  /** Tests only: like allowPrivate, but only for these exact IPs (everything else stays blocked). */
  allowPrivateHosts?: string[];
  /** Tests only: permit plain http://. */
  allowHttp?: boolean;
  timeoutMs?: number;
  /** Tests only: extra trusted CA (PEM) for the simulated sender's certificate. */
  ca?: string;
}

function ipv4ToInt(ip: string): number {
  return ip.split('.').reduce((a, o) => (a << 8) + Number(o), 0) >>> 0;
}

function inV4(ip: string, cidr: string): boolean {
  const [base, bits] = cidr.split('/');
  const mask = bits === '0' ? 0 : (~0 << (32 - Number(bits))) >>> 0;
  return (ipv4ToInt(ip) & mask) === (ipv4ToInt(base) & mask);
}

const BLOCKED_V4 = ['0.0.0.0/8', '10.0.0.0/8', '100.64.0.0/10', '127.0.0.0/8', '169.254.0.0/16', '172.16.0.0/12',
  '192.0.0.0/24', '192.0.2.0/24', '192.168.0.0/16', '198.18.0.0/15', '198.51.100.0/24', '203.0.113.0/24', '224.0.0.0/3'];

export function isPublicAddress(ip: string): boolean {
  if (isIP(ip) === 4) return !BLOCKED_V4.some((c) => inV4(ip, c));
  const v6 = ip.toLowerCase();
  const mapped = /^::ffff:(\d+\.\d+\.\d+\.\d+)$/.exec(v6);
  if (mapped) return isPublicAddress(mapped[1]);
  if (v6 === '::' || v6 === '::1') return false;
  if (/^f[cd]/.test(v6) || /^fe[89ab]/.test(v6) || /^ff/.test(v6) || v6.startsWith('2001:db8')) return false;
  return true;
}

/** Validates an unsubscribe destination without contacting it. */
export function validateDestination(raw: string, opts: SafeHttpOptions = {}): URL {
  let url: URL;
  try { url = new URL(raw); } catch { throw new UnsafeDestinationError('not a valid URL'); }
  if (url.protocol !== 'https:' && !(opts.allowHttp && url.protocol === 'http:')) throw new UnsafeDestinationError('only https destinations are allowed');
  if (url.username || url.password) throw new UnsafeDestinationError('credentials in URL are not allowed');
  const host = url.hostname.replace(/^\[|\]$/g, '');
  const exempt = opts.allowPrivate || opts.allowPrivateHosts?.includes(host);
  if (url.port && url.port !== '443' && !exempt) throw new UnsafeDestinationError('non-standard port');
  if (!exempt) {
    if (isIP(host) && !isPublicAddress(host)) throw new UnsafeDestinationError('private address');
    if (/^(localhost|.*\.local|.*\.internal|.*\.localhost)$/i.test(host)) throw new UnsafeDestinationError('internal hostname');
  }
  return url;
}

function guardedLookup(allowPrivate: boolean, allowHosts: string[] = []): LookupFunction {
  return (hostname, options, cb) => {
    lookup(hostname, { ...options, all: true }, (err, addrs) => {
      if (err) return cb(err, '', 0);
      const list = addrs as unknown as { address: string; family: number }[];
      const bad = !allowPrivate && list.find((a) => !isPublicAddress(a.address) && !allowHosts.includes(a.address));
      if (bad || list.length === 0) return cb(new UnsafeDestinationError('destination resolves to a private address'), '', 0);
      if ((options as { all?: boolean }).all) return (cb as unknown as (e: null, a: typeof list) => void)(null, list);
      cb(null, list[0].address, list[0].family);
    });
  };
}

export interface SafeResponse { status: number; headers: Record<string, string | string[] | undefined>; body: string; url: string }

/**
 * One HTTP request to a validated destination. DNS answers are checked at connect time,
 * which also defeats DNS rebinding. Redirects are returned, never followed, so the caller
 * re-validates and decides (a POST must never silently become a GET).
 */
/** TLS/certificate failures are permanent for a given link; retrying cannot help. */
export function isTlsError(e: unknown): boolean {
  const code = (e as { code?: string })?.code ?? '';
  return /CERT|TLS|SSL|SELF_SIGNED|UNABLE_TO_VERIFY|ALTNAME/i.test(code);
}

export async function safeRequest(rawUrl: string, init: { method: 'GET' | 'POST'; body?: string; headers?: Record<string, string> }, opts: SafeHttpOptions = {}): Promise<SafeResponse> {
  const url = validateDestination(rawUrl, opts);
  const mod = url.protocol === 'https:' ? https : http;
  const idleMs = opts.timeoutMs ?? 15000;
  return new Promise((resolvePromise, reject) => {
    // The socket timeout only catches silence; a sender trickling bytes would never trip it.
    const deadline = setTimeout(() => req.destroy(new Error('timeout (no complete response)')), idleMs * 2);
    const done = <T>(fn: (v: T) => void) => (v: T) => { clearTimeout(deadline); fn(v); };
    resolvePromise = done(resolvePromise);
    reject = done(reject);
    const req = mod.request(url, {
      method: init.method,
      headers: {
        'user-agent': 'OptOut/0.1 (+RFC 8058)',
        ...(init.headers ?? {}),
        ...(init.body !== undefined ? { 'content-length': Buffer.byteLength(init.body).toString() } : {}),
      },
      lookup: guardedLookup(Boolean(opts.allowPrivate), opts.allowPrivateHosts),
      timeout: idleMs,
      ...(opts.ca ? { ca: opts.ca } : {}),
    }, (res) => {
      const chunks: Buffer[] = [];
      let size = 0;
      // Only the start of the body matters (CAPTCHA / confirmation detection); stop reading after 256 KB.
      res.on('data', (c: Buffer) => {
        size += c.length;
        if (size <= 256 * 1024) chunks.push(c);
        else { res.destroy(); resolvePromise({ status: res.statusCode ?? 0, headers: res.headers, body: Buffer.concat(chunks).toString('utf8'), url: url.toString() }); }
      });
      res.on('end', () => resolvePromise({ status: res.statusCode ?? 0, headers: res.headers, body: Buffer.concat(chunks).toString('utf8'), url: url.toString() }));
      res.on('error', reject);
    });
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', reject);
    if (init.body !== undefined) req.write(init.body);
    req.end();
  });
}
