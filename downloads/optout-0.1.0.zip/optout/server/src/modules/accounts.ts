import { eq } from 'drizzle-orm';
import type { DB } from '../db/client.ts';
import { mailAccounts } from '../db/schema.ts';
import { config } from '../config.ts';
import { decrypt, encrypt } from '../lib/crypto.ts';
import { GmailProvider, type TokenSource } from '../providers/gmail.ts';
import { FakeProvider, fakeMailbox, seedFixtureMailbox } from '../providers/fake.ts';

export const DEV_FIXTURE_EMAIL = 'fixture-mailbox@unsubscriber.test';
import { refreshAccessToken, revokeToken } from '../providers/google-oauth.ts';
import { ProviderAuthError, type MailProvider } from '../providers/types.ts';

export type MailAccount = typeof mailAccounts.$inferSelect;

type Factory = (db: DB, account: MailAccount) => MailProvider;
let override: Factory | null = null;
/** Tests: substitute providers. */
export function setProviderFactory(f: Factory | null): void { override = f; }

export function fakeAllowed(): boolean { return config.devFakeProvider || config.isTest; }

export function getProvider(db: DB, account: MailAccount): MailProvider {
  if (override) return override(db, account);
  if (account.provider === 'fake') {
    if (!fakeAllowed()) throw new ProviderAuthError('fixture accounts are disabled');
    const box = fakeMailbox(account.email);
    // The dev fixture lives in memory; rebuild it after a restart (same ids, so nothing is re-counted).
    if (account.email === DEV_FIXTURE_EMAIL) seedFixtureMailbox(box);
    return new FakeProvider(box);
  }
  return new GmailProvider(tokenSource(db, account));
}

function tokenSource(db: DB, account: MailAccount): TokenSource {
  let access = account.accessTokenEnc ? decrypt(account.accessTokenEnc) : '';
  let expires = account.tokenExpiresAt?.getTime() ?? 0;
  return {
    scopes: () => account.scopes.split(' ').filter(Boolean),
    async get(force = false) {
      if (!force && access && expires - Date.now() > 60_000) return access;
      if (!account.refreshTokenEnc) {
        await markReauth(db, account.id, 'No refresh token; reconnect the account');
        throw new ProviderAuthError('no refresh token');
      }
      try {
        const t = await refreshAccessToken(decrypt(account.refreshTokenEnc));
        access = t.access_token;
        expires = Date.now() + t.expires_in * 1000;
        const update: Partial<MailAccount> = { accessTokenEnc: encrypt(access), tokenExpiresAt: new Date(expires) };
        if (t.refresh_token) update.refreshTokenEnc = encrypt(t.refresh_token);
        if (t.scope) { update.scopes = t.scope; account.scopes = t.scope; }
        await db.update(mailAccounts).set(update).where(eq(mailAccounts.id, account.id));
        return access;
      } catch (e) {
        if ((e as { oauthError?: string }).oauthError === 'invalid_grant') {
          await markReauth(db, account.id, 'Google access was revoked or expired; reconnect the account');
          throw new ProviderAuthError('invalid_grant');
        }
        throw e;
      }
    },
  };
}

export async function markReauth(db: DB, accountId: string, detail: string): Promise<void> {
  await db.update(mailAccounts).set({ status: 'reauth_required', statusDetail: detail }).where(eq(mailAccounts.id, accountId));
}

/** Revokes Google tokens and deletes the account with all derived data (cascades). */
export async function disconnectAccount(db: DB, account: MailAccount): Promise<{ revoked: boolean }> {
  let revoked = account.provider !== 'gmail';
  if (account.provider === 'gmail') {
    const token = account.refreshTokenEnc ? decrypt(account.refreshTokenEnc) : account.accessTokenEnc ? decrypt(account.accessTokenEnc) : null;
    revoked = token ? await revokeToken(token) : true;
  }
  await db.delete(mailAccounts).where(eq(mailAccounts.id, account.id));
  return { revoked };
}
