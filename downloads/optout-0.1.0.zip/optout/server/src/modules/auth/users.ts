import { and, eq, gt, isNull } from 'drizzle-orm';
import type { DB } from '../../db/client.ts';
import { apiTokens, categories, preferences, sessions, users } from '../../db/schema.ts';
import { config } from '../../config.ts';
import { randomToken, sha256 } from '../../lib/crypto.ts';
import { SYSTEM_CATEGORIES } from '../classify/rules.ts';

export type User = typeof users.$inferSelect;

async function seedUser(db: DB, userId: string): Promise<void> {
  await db.insert(categories).values(SYSTEM_CATEGORIES.map(([slug, name]) => ({ userId, slug, name, isSystem: true }))).onConflictDoNothing();
  await db.insert(preferences).values({ userId }).onConflictDoNothing();
}

export async function upsertGoogleUser(db: DB, p: { sub: string; email: string; name?: string; picture?: string }): Promise<User> {
  const email = p.email.toLowerCase();
  const [bySub] = await db.select().from(users).where(eq(users.googleSub, p.sub));
  let user = bySub;
  if (user) {
    [user] = await db.update(users).set({ email, name: p.name ?? user.name, avatarUrl: p.picture ?? user.avatarUrl }).where(eq(users.id, user.id)).returning();
  } else {
    // An existing row with this email is only adopted if no Google identity owns it yet.
    [user] = await db.insert(users).values({ email, googleSub: p.sub, name: p.name ?? null, avatarUrl: p.picture ?? null })
      .onConflictDoUpdate({ target: users.email, set: { googleSub: p.sub }, setWhere: isNull(users.googleSub) }).returning();
    if (!user) throw new Error('This email belongs to a different Google account');
  }
  await seedUser(db, user.id);
  return user;
}

export async function ensureUser(db: DB, email: string, name: string): Promise<User> {
  const [user] = await db.insert(users).values({ email, name }).onConflictDoUpdate({ target: users.email, set: { name } }).returning();
  await seedUser(db, user.id);
  return user;
}

export async function createSession(db: DB, userId: string, userAgent?: string): Promise<string> {
  const token = randomToken();
  await db.insert(sessions).values({
    id: sha256(token), userId, userAgent: userAgent?.slice(0, 200) ?? null,
    expiresAt: new Date(Date.now() + config.sessionDays * 86400000),
  });
  return token;
}

export async function userForSession(db: DB, token: string): Promise<User | null> {
  const [row] = await db.select({ user: users }).from(sessions).innerJoin(users, eq(users.id, sessions.userId))
    .where(and(eq(sessions.id, sha256(token)), gt(sessions.expiresAt, new Date())));
  return row?.user ?? null;
}

export async function deleteSession(db: DB, token: string): Promise<void> {
  await db.delete(sessions).where(eq(sessions.id, sha256(token)));
}

export async function createApiToken(db: DB, userId: string, label: string): Promise<{ id: string; token: string }> {
  const token = `uxt_${randomToken()}`;
  const [row] = await db.insert(apiTokens).values({ userId, tokenHash: sha256(token), label: label.slice(0, 80) }).returning({ id: apiTokens.id });
  return { id: row.id, token };
}

export async function userForApiToken(db: DB, token: string): Promise<User | null> {
  const [row] = await db.select({ user: users, id: apiTokens.id }).from(apiTokens).innerJoin(users, eq(users.id, apiTokens.userId))
    .where(and(eq(apiTokens.tokenHash, sha256(token)), isNull(apiTokens.revokedAt)));
  if (!row) return null;
  await db.update(apiTokens).set({ lastUsedAt: new Date() }).where(eq(apiTokens.id, row.id));
  return row.user;
}
