// Breach data providers: Have I Been Pwned (paid key for address lookups; data CC BY 4.0) or
// XposedOrNot (free, no key). Both are attributed in the UI.
import { config } from '../../config.ts';

export interface HibpBreach {
  Name: string; Title: string; Domain: string; BreachDate: string; AddedDate: string; PwnCount: number;
  Description: string; LogoPath?: string; DataClasses: string[];
  IsVerified: boolean; IsSensitive: boolean; IsSpamList: boolean; IsFabricated: boolean;
}

export class HibpRateLimitError extends Error {
  retryAfterMs: number;
  constructor(ms: number) { super('Have I Been Pwned rate limit'); this.retryAfterMs = ms; }
}
export class HibpAuthError extends Error {}

export interface ProviderInfo { name: string; url: string; host: string; attribution: string }

export interface HibpClient {
  readonly source: 'hibp' | 'xposedornot' | 'fixture';
  readonly provider: ProviderInfo;
  /** Minimum spacing between address lookups, shared by all workers. */
  readonly lookupSpacingMs: number;
  /** Whether per-address lookups are possible (needs an API key). */
  canLookupAccounts(): boolean;
  allBreaches(): Promise<HibpBreach[]>;
  /** Breaches containing the address; [] when none. */
  breachesForAccount(email: string): Promise<HibpBreach[]>;
}

const BASE = 'https://haveibeenpwned.com/api/v3';
const UA = 'Opt Out (breach check for connected mailboxes)';

export class LiveHibpClient implements HibpClient {
  readonly source = 'hibp' as const;
  readonly provider = { name: 'Have I Been Pwned', url: 'https://haveibeenpwned.com', host: 'haveibeenpwned.com', attribution: 'CC BY 4.0' };
  // The cheapest HIBP plan allows 10 lookups a minute.
  readonly lookupSpacingMs = 6500;
  private key: string;
  private fetchImpl: typeof fetch;
  constructor(key = config.hibpApiKey, fetchImpl: typeof fetch = fetch) {
    this.key = key;
    this.fetchImpl = fetchImpl;
  }

  canLookupAccounts(): boolean { return Boolean(this.key); }

  private async get(path: string, withKey: boolean): Promise<unknown | null> {
    const res = await this.fetchImpl(`${BASE}${path}`, {
      headers: { 'user-agent': UA, ...(withKey ? { 'hibp-api-key': this.key } : {}) },
      signal: AbortSignal.timeout(30000),
    });
    if (res.status === 404) return null; // "not pwned"
    if (res.status === 429) throw new HibpRateLimitError((Number(res.headers.get('retry-after')) || 6) * 1000);
    if (res.status === 401 || res.status === 403) throw new HibpAuthError('Have I Been Pwned rejected the API key');
    if (!res.ok) throw new Error(`Have I Been Pwned returned HTTP ${res.status}`);
    return res.json();
  }

  async allBreaches(): Promise<HibpBreach[]> {
    return (await this.get('/breaches', false) as HibpBreach[] | null) ?? [];
  }

  async breachesForAccount(email: string): Promise<HibpBreach[]> {
    if (!this.key) throw new HibpAuthError('No Have I Been Pwned API key configured');
    return (await this.get(`/breachedaccount/${encodeURIComponent(email)}?truncateResponse=false`, true) as HibpBreach[] | null) ?? [];
  }
}

const fixture = (name: string, title: string, domain: string, date: string, count: number, classes: string[]): HibpBreach => ({
  Name: name, Title: title, Domain: domain, BreachDate: date, AddedDate: `${date}T12:00:00Z`, PwnCount: count,
  Description: `Fixture breach for development. In ${date.slice(0, 4)}, ${title} exposed ${classes.join(', ').toLowerCase()}.`,
  DataClasses: classes, IsVerified: true, IsSensitive: false, IsSpamList: false, IsFabricated: false,
});

/** Development-only data matching the fixture mailbox. Labelled as fixture data in the UI. */
export class FixtureHibpClient implements HibpClient {
  readonly source = 'fixture' as const;
  readonly provider = { name: 'fixture breach data', url: 'https://haveibeenpwned.com', host: 'nowhere (fixture data)', attribution: 'development only' };
  readonly lookupSpacingMs = 0;
  static readonly BREACHES = [
    fixture('NorthwindOutfitters', 'Northwind Outfitters', 'northwind-outfitters.example', '2024-03-11', 2_400_000, ['Email addresses', 'Names', 'Passwords', 'Physical addresses']),
    fixture('Chirper', 'Chirper', 'chirper.example', '2022-09-02', 18_000_000, ['Email addresses', 'Usernames', 'Phone numbers']),
    fixture('PaylyPartner', 'Payly partner leak', 'payly.example', '2023-06-19', 310_000, ['Email addresses', 'Partial credit card data']),
    fixture('OldForum', 'Old Hobby Forum', 'oldforum.example', '2016-01-30', 95_000, ['Email addresses', 'Passwords', 'IP addresses']),
  ];
  canLookupAccounts(): boolean { return true; }
  async allBreaches(): Promise<HibpBreach[]> { return FixtureHibpClient.BREACHES; }
  async breachesForAccount(): Promise<HibpBreach[]> {
    return FixtureHibpClient.BREACHES.filter((b) => ['NorthwindOutfitters', 'OldForum'].includes(b.Name));
  }
}

interface XonBreach {
  breachID: string; breachedDate: string; addedDate: string; domain: string; logo?: string; sensitive: boolean; verified: boolean;
  exposedData: string[]; exposedRecords: number; exposureDescription: string;
}

/** "GlendaleCommunityCollege" -> "Glendale Community College"; brand names like "SoundCloud" stay whole. */
export const titleFromId = (id: string) => {
  const split = id.replace(/([a-z0-9])([A-Z])/g, '$1 $2').replace(/([A-Z]+)([A-Z][a-z])/g, '$1 $2');
  return split.split(' ').length >= 3 ? split : id;
};

/** XposedOrNot: free and keyless. https://xposedornot.com/api_doc */
export class XposedOrNotClient implements HibpClient {
  readonly source = 'xposedornot' as const;
  readonly provider = { name: 'XposedOrNot', url: 'https://xposedornot.com', host: 'xposedornot.com', attribution: 'free community breach database' };
  readonly lookupSpacingMs = 2000;
  private fetchImpl: typeof fetch;
  private cache: { at: number; list: HibpBreach[] } | null = null;
  constructor(fetchImpl: typeof fetch = fetch) { this.fetchImpl = fetchImpl; }

  canLookupAccounts(): boolean { return true; }

  private async get(path: string): Promise<{ status: number; body: unknown }> {
    const res = await this.fetchImpl(`https://api.xposedornot.com/v1${path}`, { headers: { 'user-agent': UA }, signal: AbortSignal.timeout(30000) });
    if (res.status === 429) throw new HibpRateLimitError((Number(res.headers.get('retry-after')) || 5) * 1000);
    const body = await res.json().catch(() => null);
    if (res.status !== 404 && !res.ok) throw new Error(`XposedOrNot returned HTTP ${res.status}`);
    return { status: res.status, body };
  }

  static toBreach(b: XonBreach): HibpBreach {
    return {
      Name: b.breachID, Title: titleFromId(b.breachID), Domain: b.domain ?? '', BreachDate: (b.breachedDate ?? '').slice(0, 10),
      AddedDate: b.addedDate, PwnCount: b.exposedRecords ?? 0, Description: b.exposureDescription ?? '', LogoPath: b.logo,
      DataClasses: b.exposedData ?? [], IsVerified: b.verified ?? true, IsSensitive: b.sensitive ?? false,
      IsSpamList: false, IsFabricated: false,
    };
  }

  async allBreaches(): Promise<HibpBreach[]> {
    if (this.cache && Date.now() - this.cache.at < 3600000) return this.cache.list;
    const { body } = await this.get('/breaches');
    const list = ((body as { exposedBreaches?: XonBreach[] } | null)?.exposedBreaches ?? []).map(XposedOrNotClient.toBreach);
    if (list.length) this.cache = { at: Date.now(), list };
    return list;
  }

  async breachesForAccount(email: string): Promise<HibpBreach[]> {
    const { status, body } = await this.get(`/check-email/${encodeURIComponent(email)}`);
    const names = (body as { breaches?: string[][] } | null)?.breaches?.[0];
    if (status === 404 || !names?.length) return []; // {"Error":"Not found"}
    // The lookup returns names only; details come from the catalogue.
    const byName = new Map((await this.allBreaches()).map((b) => [b.Name, b]));
    return names.map((n) => byName.get(n) ?? XposedOrNotClient.toBreach({ breachID: n } as XonBreach));
  }
}

let override: HibpClient | null = null;
/** Tests: substitute the client. */
export function setHibpClient(c: HibpClient | null): void { override = c; }

export function hibpClient(): HibpClient {
  if (override) return override;
  if (config.devFakeProvider && !config.isProd && config.breachProvider === 'auto') return new FixtureHibpClient();
  // auto: HIBP when a key is configured, otherwise the free XposedOrNot service.
  if (config.breachProvider === 'hibp' || (config.breachProvider === 'auto' && config.hibpApiKey)) return new LiveHibpClient();
  return new XposedOrNotClient();
}
