// Breach monitoring: which companies that email the user were breached (public catalogue,
// no user data leaves the server), and which breaches the user's own addresses appear in
// (per-address lookup, only with explicit consent and an API key).
import { and, eq, inArray, lt, notInArray, sql } from 'drizzle-orm';
import type { DB } from '../../db/client.ts';
import { breachChecks, breachHits, breaches, mailAccounts, preferences, senderIdentities, users } from '../../db/schema.ts';
import { baseDomain } from '../../lib/headers.ts';
import { errMsg } from '../../lib/log.ts';
import { acquireDomainSlot, enqueue, type JobContext, type JobOutcome } from '../jobs/queue.ts';
import { hibpClient, HibpAuthError, HibpRateLimitError, type HibpBreach, type HibpClient } from './hibp.ts';
import { fakeAllowed } from '../accounts.ts';

export type Breach = typeof breaches.$inferSelect;

/** HIBP descriptions contain HTML; keep plain text only. */
export function plainText(html: string): string {
  return html
    .replace(/<[^>]*>/g, '')
    .replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&')
    .replace(/\s+/g, ' ').trim()
    .slice(0, 2000);
}

function toRow(b: HibpBreach, source: HibpClient['source']) {
  return {
    name: b.Name, title: b.Title, domain: (b.Domain ?? '').toLowerCase(), breachDate: b.BreachDate ?? null,
    addedDate: b.AddedDate ? new Date(b.AddedDate) : null, pwnCount: b.PwnCount ?? 0, dataClasses: b.DataClasses ?? [],
    description: plainText(b.Description ?? ''), logoPath: b.LogoPath ?? null, isVerified: b.IsVerified ?? true,
    isSensitive: b.IsSensitive ?? false, isSpamList: b.IsSpamList ?? false, isFabricated: b.IsFabricated ?? false,
    source, updatedAt: new Date(),
  };
}

async function upsertBreaches(db: DB, list: HibpBreach[], source: HibpClient['source']): Promise<void> {
  for (let i = 0; i < list.length; i += 200) {
    const rows = list.slice(i, i + 200).map((b) => toRow(b, source));
    await db.insert(breaches).values(rows).onConflictDoUpdate({
      target: breaches.name,
      set: Object.fromEntries(Object.keys(rows[0]).filter((k) => k !== 'name').map((k) => [k, sql.raw(`excluded.${k.replace(/[A-Z]/g, (c) => `_${c.toLowerCase()}`)}`)])),
    });
  }
}

/** Job 'breach-catalogue': refreshes the public breach list. */
export async function catalogueHandler(ctx: JobContext): Promise<JobOutcome> {
  const client = hibpClient();
  try {
    const list = await client.allBreaches();
    if (!list.length) return { status: 'retry', error: 'empty breach catalogue' };
    await upsertBreaches(ctx.db, list, client.source);
    // Drop breaches the source no longer lists (retired or removed).
    await ctx.db.delete(breaches).where(and(eq(breaches.source, client.source), notInArray(breaches.name, list.map((b) => b.Name))));
    return { status: 'done', progress: { breaches: list.length } };
  } catch (e) {
    if (e instanceof HibpRateLimitError) return { status: 'defer', delayMs: e.retryAfterMs };
    throw e;
  }
}

/** Addresses checked for a user: their sign-in address and every connected mailbox. */
export async function addressesFor(db: DB, userId: string): Promise<string[]> {
  const [u] = await db.select({ email: users.email }).from(users).where(eq(users.id, userId));
  const accts = await db.select({ email: mailAccounts.email, provider: mailAccounts.provider }).from(mailAccounts).where(eq(mailAccounts.userId, userId));
  const list = [u?.email, ...accts.filter((a) => a.provider === 'gmail' || fakeAllowed()).map((a) => a.email)].filter((e): e is string => Boolean(e));
  return [...new Set(list.map((e) => e.toLowerCase()))];
}

/** Job 'breach-check': looks up each address. Resumable: done addresses are skipped. */
export async function checkHandler(ctx: JobContext): Promise<JobOutcome> {
  const { db, job } = ctx;
  const userId = String(job.payload.userId);
  const [prefs] = await db.select().from(preferences).where(eq(preferences.userId, userId));
  if (!prefs?.breachConsent) return { status: 'done', progress: { skipped: 'no consent' } };
  const client = hibpClient();
  if (!client.canLookupAccounts()) return { status: 'done', progress: { skipped: 'no API key' } };

  const emails = await addressesFor(db, userId);
  const done = await db.select().from(breachChecks).where(eq(breachChecks.userId, userId));
  const fresh = new Set(done.filter((c) => c.checkedAt >= job.createdAt).map((c) => c.email));
  for (const email of emails) {
    if (fresh.has(email)) continue;
    // Shared spacing for all workers, per the provider's rate limit.
    if (client.lookupSpacingMs) {
      const wait = await acquireDomainSlot(db, client.provider.host, 'breach-lookup', client.lookupSpacingMs);
      if (wait) return { status: 'defer', delayMs: wait };
    }
    let found: HibpBreach[];
    try {
      found = await client.breachesForAccount(email);
    } catch (e) {
      if (e instanceof HibpRateLimitError) return { status: 'defer', delayMs: e.retryAfterMs };
      await db.insert(breachChecks).values({ userId, email, status: 'error', error: errMsg(e), checkedAt: new Date() })
        .onConflictDoUpdate({ target: [breachChecks.userId, breachChecks.email], set: { status: 'error', error: errMsg(e), checkedAt: new Date() } });
      if (e instanceof HibpAuthError) return { status: 'failed', error: errMsg(e) };
      throw e;
    }
    await db.transaction(async (tx) => {
      if (found.length) await upsertBreaches(tx as unknown as DB, found, client.source);
      const names = found.map((b) => b.Name);
      await tx.delete(breachHits).where(and(eq(breachHits.userId, userId), eq(breachHits.email, email), ...(names.length ? [notInArray(breachHits.breachName, names)] : [])));
      if (names.length) await tx.insert(breachHits).values(names.map((breachName) => ({ userId, email, breachName }))).onConflictDoNothing();
      await tx.insert(breachChecks).values({ userId, email, status: 'ok', error: null, checkedAt: new Date() })
        .onConflictDoUpdate({ target: [breachChecks.userId, breachChecks.email], set: { status: 'ok', error: null, checkedAt: new Date() } });
    });
    await ctx.heartbeat({ checked: email });
  }
  return { status: 'done' };
}

export function enqueueBreachCheck(db: DB, userId: string) {
  return enqueue(db, { type: 'breach-check', payload: { userId }, userId, dedupeKey: `breach-check:${userId}`, maxAttempts: 4 });
}

export function enqueueCatalogue(db: DB) {
  return enqueue(db, { type: 'breach-catalogue', dedupeKey: 'breach-catalogue', maxAttempts: 5 });
}

/** Removes everything learned from per-address lookups (consent withdrawn). */
export async function forgetLookups(db: DB, userId: string): Promise<void> {
  await db.delete(breachHits).where(eq(breachHits.userId, userId));
  await db.delete(breachChecks).where(eq(breachChecks.userId, userId));
}

/** Daily refresh: catalogue, and lookups for users who consented. */
export async function breachMaintenance(db: DB): Promise<void> {
  const [{ fresh }] = await db.select({ fresh: sql<number>`count(*) filter (where ${breaches.updatedAt} > now() - interval '1 day')::int` }).from(breaches).where(eq(breaches.source, hibpClient().source));
  if (!fresh) await enqueueCatalogue(db);
  if (!hibpClient().canLookupAccounts()) return;
  const consenting = await db.select({ userId: preferences.userId }).from(preferences).where(eq(preferences.breachConsent, true));
  for (const { userId } of consenting) {
    const stale = await db.select({ email: breachChecks.email }).from(breachChecks)
      .where(and(eq(breachChecks.userId, userId), lt(breachChecks.checkedAt, new Date(Date.now() - 86400000))));
    const checked = await db.select({ n: sql<number>`count(*)::int` }).from(breachChecks).where(eq(breachChecks.userId, userId));
    const addresses = await addressesFor(db, userId);
    if (stale.length || checked[0].n < addresses.length) await enqueueBreachCheck(db, userId);
  }
}

const publicBreach = (b: Breach) => ({
  name: b.name, title: b.title, domain: b.domain, breachDate: b.breachDate, addedDate: b.addedDate, pwnCount: b.pwnCount,
  dataClasses: b.dataClasses, description: b.description, logoPath: b.logoPath, isVerified: b.isVerified,
  isSpamList: b.isSpamList, isFabricated: b.isFabricated, source: b.source,
});
export type PublicBreach = ReturnType<typeof publicBreach>;

/** Breaches of a sender's organisation, matched on the registrable domain. */
export async function breachesForDomain(db: DB, domain: string): Promise<PublicBreach[]> {
  const base = baseDomain(domain);
  const rows = await db.select().from(breaches)
    .where(and(eq(breaches.source, hibpClient().source), sql`(${breaches.domain} = ${base} or ${breaches.domain} like ${`%.${base}`})`));
  return rows.filter((b) => baseDomain(b.domain) === base && !b.isSensitive).map(publicBreach);
}

export async function breachOverview(db: DB, userId: string) {
  const client = hibpClient();
  const [prefs] = await db.select().from(preferences).where(eq(preferences.userId, userId));
  const [cat] = await db.select({ n: sql<number>`count(*)::int`, updatedAt: sql<string | null>`max(${breaches.updatedAt})` }).from(breaches).where(eq(breaches.source, client.source));

  // Companies that email the user and appear in the catalogue.
  const ids = await db.select({
    id: senderIdentities.id, fromName: senderIdentities.fromName, fromAddress: senderIdentities.fromAddress, domain: senderIdentities.domain,
    messageCount: senderIdentities.messageCount, lastSeenAt: senderIdentities.lastSeenAt, unsubState: senderIdentities.unsubState, accountId: senderIdentities.accountId,
  }).from(senderIdentities).where(eq(senderIdentities.userId, userId));
  const bases = [...new Set(ids.map((i) => baseDomain(i.domain)))];
  const catalogue = bases.length
    ? await db.select().from(breaches).where(and(eq(breaches.source, client.source), eq(breaches.isSensitive, false), sql`${breaches.domain} <> ''`))
    : [];
  const byBase = new Map<string, Breach[]>();
  for (const b of catalogue) {
    const k = baseDomain(b.domain);
    if (!bases.includes(k)) continue;
    byBase.set(k, [...(byBase.get(k) ?? []), b]);
  }
  const senderBreaches = [...byBase.entries()].flatMap(([base, list]) => list.map((b) => ({
    breach: publicBreach(b),
    senders: ids.filter((i) => baseDomain(i.domain) === base),
  }))).sort((a, b) => (b.breach.breachDate ?? '').localeCompare(a.breach.breachDate ?? ''));

  // The user's own addresses (only with consent).
  const addresses = await addressesFor(db, userId);
  const checks = prefs?.breachConsent ? await db.select().from(breachChecks).where(eq(breachChecks.userId, userId)) : [];
  const hits = prefs?.breachConsent ? await db.select().from(breachHits).where(eq(breachHits.userId, userId)) : [];
  const hitBreaches = hits.length ? await db.select().from(breaches).where(inArray(breaches.name, [...new Set(hits.map((h) => h.breachName))])) : [];
  const breachByName = new Map(hitBreaches.map((b) => [b.name, b]));
  const accounts = addresses.map((email) => {
    const check = checks.find((c) => c.email === email);
    const found = hits.filter((h) => h.email === email).map((h) => {
      const b = breachByName.get(h.breachName);
      const base = b?.domain ? baseDomain(b.domain) : null;
      return {
        firstSeenAt: h.firstSeenAt,
        breach: b ? publicBreach(b) : { name: h.breachName, title: h.breachName, domain: '', breachDate: null, addedDate: null, pwnCount: 0, dataClasses: [], description: '', logoPath: null, isVerified: true, isSpamList: false, isFabricated: false, source: client.source },
        senders: base ? ids.filter((i) => baseDomain(i.domain) === base).map((i) => i.id) : [],
      };
    }).sort((a, b) => (b.breach.breachDate ?? '').localeCompare(a.breach.breachDate ?? ''));
    return { email, checkedAt: check?.checkedAt ?? null, status: check?.status ?? null, error: check?.error ?? null, breaches: found };
  });

  return {
    source: client.source,
    provider: client.provider,
    catalogue: { count: cat?.n ?? 0, updatedAt: cat?.updatedAt ?? null },
    lookupAvailable: client.canLookupAccounts(),
    consent: Boolean(prefs?.breachConsent),
    accounts,
    senderBreaches,
  };
}
