// Deterministic, metadata-only classification. No email content leaves the server.
import { baseDomain } from '../../lib/headers.ts';

export const SYSTEM_CATEGORIES = [
  ['shopping', 'Shopping & retail'],
  ['food', 'Food & restaurants'],
  ['travel', 'Travel & accommodation'],
  ['transport', 'Airlines & transportation'],
  ['technology', 'Technology & software'],
  ['social', 'Social media & communities'],
  ['finance', 'Finance & banking'],
  ['insurance', 'Insurance'],
  ['news', 'News & media'],
  ['entertainment', 'Entertainment & streaming'],
  ['gaming', 'Gaming'],
  ['education', 'Education'],
  ['health', 'Health & fitness'],
  ['automotive', 'Automotive'],
  ['real_estate', 'Real estate'],
  ['telecom', 'Telecommunications'],
  ['jobs', 'Job alerts & recruitment'],
  ['newsletters', 'Newsletters & blogs'],
  ['other_marketing', 'Other marketing'],
  ['unknown', 'Unknown'],
] as const;

export type CategorySlug = (typeof SYSTEM_CATEGORIES)[number][0];

// Stems matched against tokens of the domain, sender name, List-Id and subject.
const KEYWORDS: Record<Exclude<CategorySlug, 'other_marketing' | 'unknown'>, string[]> = {
  shopping: ['shop', 'store', 'outfitter', 'retail', 'mall', 'bargain', 'fashion', 'apparel', 'boutique', 'amazon', 'ebay', 'etsy', 'zalando', 'bol', 'ikea', 'aliexpress', 'temu', 'shein', 'outlet', 'cart', 'wear', 'shoes', 'market'],
  food: ['food', 'restaurant', 'pizza', 'burger', 'ramen', 'bowl', 'kitchen', 'eats', 'deliveroo', 'ubereats', 'doordash', 'thuisbezorgd', 'grubhub', 'takeaway', 'recipe', 'coffee', 'cafe', 'bakery', 'grocer', 'tasty', 'dinner', 'meal'],
  travel: ['hotel', 'hotels', 'airbnb', 'expedia', 'booking', 'trip', 'travel', 'resort', 'hostel', 'stay', 'vacation', 'holiday', 'tripadvisor', 'cruise'],
  transport: ['airline', 'airlines', 'airways', 'flight', 'flights', 'fares', 'klm', 'ryanair', 'easyjet', 'lufthansa', 'transavia', 'rail', 'train', 'uber', 'lyft', 'bolt', 'taxi', 'transit'],
  technology: ['software', 'cloud', 'dev', 'devtools', 'github', 'gitlab', 'tech', 'saas', 'digital', 'app', 'apps', 'product', 'api', 'code', 'microsoft', 'google', 'apple', 'adobe', 'notion', 'slack', 'atlassian', 'desk'],
  social: ['facebook', 'instagram', 'twitter', 'reddit', 'tiktok', 'pinterest', 'snapchat', 'discord', 'mastodon', 'chirper', 'forum', 'community', 'social', 'meetup', 'friends'],
  finance: ['bank', 'banking', 'pay', 'payly', 'paypal', 'card', 'credit', 'finance', 'financial', 'invest', 'crypto', 'wallet', 'loan', 'mortgage', 'savings', 'revolut', 'wise', 'stripe', 'harbor'],
  insurance: ['insurance', 'insur', 'shieldins', 'verzeker', 'assurance', 'policy', 'aviva', 'allianz'],
  news: ['news', 'daily', 'times', 'post', 'ledger', 'journal', 'gazette', 'herald', 'tribune', 'briefing', 'press', 'media', 'magazine', 'nos', 'bbc', 'cnn', 'guardian'],
  entertainment: ['stream', 'streamflix', 'flix', 'music', 'spotify', 'netflix', 'cinema', 'movie', 'movies', 'tv', 'disney', 'hbo', 'concert', 'ticket', 'tickets', 'podcast'],
  gaming: ['game', 'games', 'gaming', 'steam', 'xbox', 'playstation', 'nintendo', 'epicgames', 'pixelforge', 'twitch', 'season'],
  education: ['learn', 'learnloop', 'course', 'courses', 'academy', 'university', 'school', 'udemy', 'coursera', 'edx', 'duolingo', 'class', 'tutor'],
  health: ['health', 'fit', 'fitpulse', 'fitness', 'gym', 'clinic', 'pharmacy', 'medical', 'wellness', 'yoga', 'coach', 'nutrition', 'doctor', 'dental'],
  automotive: ['auto', 'automotive', 'car', 'cars', 'motor', 'motors', 'tyre', 'tire', 'vehicle', 'garage', 'tesla', 'dealer'],
  real_estate: ['home', 'homes', 'homefinder', 'realty', 'estate', 'property', 'rent', 'rental', 'funda', 'zillow', 'rightmove', 'apartment', 'housing'],
  telecom: ['mobile', 'telecom', 'connectel', 'broadband', '5g', 'vodafone', 'kpn', 'tmobile', 'fiber', 'sim', 'telco', 'internet'],
  jobs: ['job', 'jobs', 'jobscout', 'career', 'careers', 'recruit', 'recruiting', 'hiring', 'indeed', 'glassdoor', 'linkedin', 'vacancy', 'talent'],
  newsletters: ['newsletter', 'newsletters', 'substack', 'weekly', 'digest', 'blog', 'issue', 'editor', 'beehiiv', 'roundup'],
};

// Signals counted per message. p_* keys mark protected communications.
export const PROTECTED_PATTERNS: [key: string, label: string, re: RegExp][] = [
  ['p_security', 'Security notification', /\b(security alert|new sign-?in|suspicious|unusual activity|login attempt|2fa|two-factor|security code)\b/i],
  ['p_auth', 'Authentication email', /\b(verification code|verify your|one-time (pass)?code|otp|confirm your (email|account)|activation|magic link|sign-?in link)\b/i],
  ['p_password', 'Password reset', /\b(password reset|reset your password|forgot (your )?password|password changed)\b/i],
  ['p_banking', 'Banking statement', /\b(statement|account balance|direct debit|overdraft|iban)\b/i],
  ['p_payment', 'Payment confirmation', /\b(receipt|payment (received|confirmation|confirmed)|invoice|refund|you paid|transaction)\b/i],
  ['p_insurance', 'Insurance correspondence', /\b(policy (renewal|documents|number)|claim|your policy|premium)\b/i],
  ['p_order', 'Order confirmation', /\b(order (confirmation|confirmed|#|number|received)|your order|thanks for your order)\b/i],
  ['p_shipping', 'Shipping notification', /\b(shipped|out for delivery|tracking|delivery (update|scheduled)|has been delivered|dispatched)\b/i],
  ['p_booking', 'Booking confirmation', /\b(booking (confirmation|confirmed|reference)|reservation (confirmed|confirmation)|itinerary|e-?ticket|boarding pass|check-?in)\b/i],
  ['p_medical', 'Medical communication', /\b(appointment|prescription|test results|patient|lab results|your doctor)\b/i],
  ['p_government', 'Government correspondence', /\b(tax (assessment|return|refund)|municipality|benefit|council tax|jury|passport|visa application)\b/i],
];

const PROTECTED_LOCALPARTS: [RegExp, string][] = [
  [/^(security|account-security|alerts?-security)/, 'p_security'],
  [/^(verify|verification|auth|otp)/, 'p_auth'],
  [/^(statements?|banking)/, 'p_banking'],
  [/^(receipts?|payments?|billing|invoices?)/, 'p_payment'],
  [/^(orders?|order-update)/, 'p_order'],
  [/^(shipping|delivery|tracking)/, 'p_shipping'],
  [/^(booking|bookings|reservations?|itinerary)/, 'p_booking'],
  [/^(policy|claims)/, 'p_insurance'],
  [/^(appointments?|patient)/, 'p_medical'],
];

export const isGovernmentDomain = (d: string) => /(^|\.)(gov|mil|gouv|gob|govt|overheid|gc)(\.[a-z]{2,})?(\.example)?$/i.test(d) || /\.gov\.[a-z]{2}$/i.test(d);

/** Per-message signals, accumulated on the identity row. */
export function messageSignals(m: { subject: string; labelIds: string[]; headers: Record<string, string>; hasUnsub: boolean; hasListId: boolean; fromAddress: string; domain: string }): Record<string, number> {
  const s: Record<string, number> = { total: 1 };
  if (m.hasUnsub) s.unsub = 1;
  if (m.hasListId) s.listid = 1;
  if (m.labelIds.includes('CATEGORY_PROMOTIONS')) s.promotions = 1;
  if (m.labelIds.includes('CATEGORY_SOCIAL')) s.social = 1;
  if (m.labelIds.includes('CATEGORY_UPDATES')) s.updates = 1;
  if (m.labelIds.includes('CATEGORY_FORUMS')) s.forums = 1;
  if (m.labelIds.includes('CATEGORY_PERSONAL')) s.personal = 1;
  if (/bulk|list/i.test(m.headers.precedence ?? '')) s.bulk = 1;
  if (m.headers['auto-submitted'] && !/^no$/i.test(m.headers['auto-submitted'])) s.auto = 1;
  if (m.headers['feedback-id']) s.feedback = 1;
  for (const [key, , re] of PROTECTED_PATTERNS) if (re.test(m.subject)) s[key] = 1;
  const local = m.fromAddress.split('@')[0];
  for (const [re, key] of PROTECTED_LOCALPARTS) if (re.test(local)) s[key] = 1;
  if (isGovernmentDomain(m.domain)) s.p_government = 1;
  return s;
}

export function addSignals(a: Record<string, number>, b: Record<string, number>): Record<string, number> {
  const out = { ...a };
  for (const [k, v] of Object.entries(b)) out[k] = (out[k] ?? 0) + v;
  return out;
}

function tokens(s: string | null | undefined): string[] {
  return (s ?? '').toLowerCase().split(/[^a-z0-9]+/).filter((t) => t.length > 1);
}

function hits(toks: string[], words: string[]): number {
  let n = 0;
  for (const t of toks) for (const w of words) if (t === w || (w.length >= 4 && t.includes(w))) { n++; break; }
  return n;
}

export interface ClassifyInput {
  fromAddress: string; fromName: string | null; domain: string; listId: string | null;
  lastSubject: string | null; signals: Record<string, number>; hasUnsubMethod: boolean;
}

export interface Classification {
  category: CategorySlug;
  confidence: number;
  kind: 'marketing' | 'transactional' | 'personal' | 'unknown';
  protectedReason: string | null;
}

export function classify(i: ClassifyInput): Classification {
  const s = i.signals;
  const total = Math.max(1, s.total ?? 0);
  const ratio = (k: string) => (s[k] ?? 0) / total;

  // Protected communications: decided per identity (one list), never per company.
  let protectedReason: string | null = null;
  let best = 0;
  const listLike = ratio('listid') > 0.5 || (ratio('unsub') > 0.5 && ratio('promotions') > 0.3);
  for (const [key, label] of PROTECTED_PATTERNS) {
    const r = ratio(key);
    // A marketing list occasionally mentioning "order" is not transactional; require a
    // strong majority when the identity looks like a list, a simple majority otherwise.
    const threshold = key === 'p_government' ? 0.01 : listLike ? 0.8 : 0.4;
    if (r >= threshold && r > best) { best = r; protectedReason = label; }
  }

  const bulkish = ratio('unsub') > 0.3 || ratio('listid') > 0.3 || ratio('bulk') > 0.3 || ratio('promotions') > 0.5;
  let kind: Classification['kind'];
  if (protectedReason) kind = 'transactional';
  else if (bulkish) kind = 'marketing';
  else if (ratio('updates') > 0.5 || ratio('auto') > 0.5 || /^(no-?reply|notifications?|notify|alerts?|info)\b/.test(i.fromAddress)) kind = 'unknown';
  else kind = 'personal';

  const strong = [...tokens(baseDomain(i.domain)), ...tokens(i.fromName), ...tokens(i.listId)];
  const weak = tokens(i.lastSubject);
  let bestCat: CategorySlug = 'unknown';
  let bestScore = 0;
  let second = 0;
  for (const [cat, words] of Object.entries(KEYWORDS) as [CategorySlug, string[]][]) {
    const score = hits(strong, words) * 3 + hits(weak, words);
    if (score > bestScore) { second = bestScore; bestScore = score; bestCat = cat; }
    else if (score > second) second = score;
  }
  // Gmail's own tabs are a useful prior for social/forums.
  if (ratio('social') + ratio('forums') > 0.5 && bestScore < 3) { bestCat = 'social'; bestScore = Math.max(bestScore, 3); }

  let confidence: number;
  if (bestScore === 0) {
    bestCat = kind === 'marketing' ? (ratio('listid') > 0.5 && ratio('promotions') < 0.3 ? 'newsletters' : 'other_marketing') : 'unknown';
    confidence = kind === 'marketing' ? 0.45 : 0.2;
  } else {
    const margin = (bestScore - second) / bestScore;
    confidence = Math.min(0.95, 0.35 + 0.1 * Math.min(bestScore, 5) + 0.15 * margin);
  }
  return { category: bestCat, confidence: Math.round(confidence * 100) / 100, kind, protectedReason };
}
