// Discovery engine: reads message metadata, groups it into sender identities (one per
// mailing list or sender address), and keeps their counters and classification current.
import { and, eq, inArray, sql } from 'drizzle-orm';
import type { DB } from '../../db/client.ts';
import { categories, jobs, mailAccounts, messages, preferences, senderIdentities } from '../../db/schema.ts';
import { parseFrom, parseListId, parseListUnsubscribe, decodeWords } from '../../lib/headers.ts';
import { addSignals, classify, messageSignals } from '../classify/rules.ts';
import { getProvider, markReauth, type MailAccount } from '../accounts.ts';
import { HistoryExpiredError, ProviderAuthError, RateLimitError, type MailProvider, type MessageMeta } from '../../providers/types.ts';
import { enqueue, type JobContext, type JobOutcome } from '../jobs/queue.ts';

export type ScanMode = 'full' | 'incremental' | 'partial';
export const PARTIAL_SCAN_LIMIT = 300;
const PAGE = 250;
const SKIP_LABELS = new Set(['SENT', 'DRAFT', 'CHAT', 'SPAM', 'TRASH']);

interface Group {
  key: string; fromAddress: string; fromName: string | null; domain: string; listId: string | null;
  metas: { meta: MessageMeta; subject: string; signals: Record<string, number>; unsub: ReturnType<typeof parseListUnsubscribe> }[];
}

export function identityKeyFor(fromAddress: string, listId: string | null): string {
  return listId ? `list:${listId}` : `addr:${fromAddress}`;
}

/** Ingests metadata idempotently: a message already stored is never counted twice. */
export async function ingest(db: DB, account: MailAccount, metas: MessageMeta[]): Promise<{ added: number; identities: number }> {
  const groups = new Map<string, Group>();
  for (const meta of metas) {
    if (meta.labelIds.some((l) => SKIP_LABELS.has(l))) continue;
    const from = parseFrom(meta.headers.from);
    if (!from || from.address === account.email) continue;
    const listId = parseListId(meta.headers['list-id']);
    const unsub = parseListUnsubscribe(meta.headers['list-unsubscribe'], meta.headers['list-unsubscribe-post']);
    const subject = decodeWords(meta.headers.subject ?? '').slice(0, 300);
    const key = identityKeyFor(from.address, listId);
    let g = groups.get(key);
    if (!g) { g = { key, fromAddress: from.address, fromName: from.name, domain: from.domain, listId, metas: [] }; groups.set(key, g); }
    const signals = messageSignals({ subject, labelIds: meta.labelIds, headers: meta.headers, hasUnsub: Boolean(unsub.http || unsub.mailto), hasListId: Boolean(listId), fromAddress: from.address, domain: from.domain });
    g.metas.push({ meta, subject, signals, unsub });
  }

  const cats = await db.select({ id: categories.id, slug: categories.slug }).from(categories).where(eq(categories.userId, account.userId));
  const catBySlug = new Map(cats.map((c) => [c.slug, c.id]));
  let added = 0;

  for (const g of groups.values()) {
    await db.transaction(async (tx) => {
      const sorted = g.metas.sort((a, b) => a.meta.internalDate - b.meta.internalDate);
      const first = new Date(sorted[0].meta.internalDate);
      const last = new Date(sorted[sorted.length - 1].meta.internalDate);
      await tx.insert(senderIdentities).values({
        userId: account.userId, accountId: account.id, identityKey: g.key, fromAddress: g.fromAddress, fromName: g.fromName,
        domain: g.domain, listId: g.listId, firstSeenAt: first, lastSeenAt: last,
      }).onConflictDoNothing();
      const [identity] = await tx.select().from(senderIdentities)
        .where(and(eq(senderIdentities.accountId, account.id), eq(senderIdentities.identityKey, g.key)));

      const inserted = await tx.insert(messages)
        .values(sorted.map((m) => ({ accountId: account.id, identityId: identity.id, providerMessageId: m.meta.id, receivedAt: new Date(m.meta.internalDate) })))
        .onConflictDoNothing().returning({ providerMessageId: messages.providerMessageId });
      if (!inserted.length) return;
      const fresh = new Set(inserted.map((r) => r.providerMessageId));
      const news = sorted.filter((m) => fresh.has(m.meta.id));
      added += news.length;

      let signals = identity.signals;
      for (const m of news) signals = addSignals(signals, m.signals);
      const newest = news[news.length - 1];
      const update: Partial<typeof senderIdentities.$inferInsert> = {
        messageCount: identity.messageCount + news.length,
        signals,
        firstSeenAt: new Date(Math.min(identity.firstSeenAt.getTime(), news[0].meta.internalDate)),
        updatedAt: new Date(),
      };
      if (newest.meta.internalDate >= identity.lastSeenAt.getTime() || identity.messageCount === 0) {
        update.lastSeenAt = new Date(newest.meta.internalDate);
        update.lastSubject = newest.subject || null;
        if (g.fromName) update.fromName = g.fromName;
      }
      // Unsubscribe methods from the newest message that carries them.
      const withUnsub = [...news].reverse().find((m) => m.unsub.http || m.unsub.mailto);
      if (withUnsub && (withUnsub.meta.internalDate >= identity.lastSeenAt.getTime() || (!identity.unsubHttp && !identity.unsubMailto))) {
        update.unsubHttp = withUnsub.unsub.http;
        update.unsubMailto = withUnsub.unsub.mailto;
        update.oneClick = withUnsub.unsub.oneClick;
      }
      const hasMethod = Boolean(update.unsubHttp ?? identity.unsubHttp ?? update.unsubMailto ?? identity.unsubMailto);
      const c = classify({
        fromAddress: identity.fromAddress, fromName: update.fromName ?? identity.fromName, domain: identity.domain, listId: identity.listId,
        lastSubject: update.lastSubject ?? identity.lastSubject, signals, hasUnsubMethod: hasMethod,
      });
      update.kind = c.kind;
      if (identity.categorySource !== 'user') {
        update.categoryId = catBySlug.get(c.category) ?? null;
        update.confidence = c.confidence;
      }
      if (identity.protectionSource !== 'user' && identity.protectionSource !== 'override') {
        update.isProtected = Boolean(c.protectedReason);
        update.protectionReason = c.protectedReason;
        update.protectionSource = c.protectedReason ? 'auto' : null;
      }
      await tx.update(senderIdentities).set(update).where(eq(senderIdentities.id, identity.id));
    });
  }
  return { added, identities: groups.size };
}

async function knownIds(db: DB, accountId: string, ids: string[]): Promise<Set<string>> {
  if (!ids.length) return new Set();
  const rows = await db.select({ id: messages.providerMessageId }).from(messages)
    .where(and(eq(messages.accountId, accountId), inArray(messages.providerMessageId, ids)));
  return new Set(rows.map((r) => r.id));
}

async function fetchAndIngest(db: DB, provider: MailProvider, account: MailAccount, ids: string[]): Promise<number> {
  const known = await knownIds(db, account.id, ids);
  const todo = ids.filter((id) => !known.has(id));
  let added = 0;
  for (let i = 0; i < todo.length; i += 100) {
    const metas = await provider.getMetadata(todo.slice(i, i + 100));
    added += (await ingest(db, account, metas)).added;
  }
  return added;
}

interface ScanProgress {
  mode: ScanMode; phase: string; pageToken?: string | null; processed: number; added: number;
  startHistoryId?: string; estimate?: number; complete?: boolean; limitReached?: boolean; note?: string;
}

/** Job handler for type 'scan'. Resumable: the checkpoint lives in job.progress. */
export async function scanHandler(ctx: JobContext): Promise<JobOutcome> {
  const { db, job } = ctx;
  const accountId = String(job.payload.accountId);
  let mode = (job.payload.mode as ScanMode) ?? 'incremental';
  const [account] = await db.select().from(mailAccounts).where(eq(mailAccounts.id, accountId));
  if (!account) return { status: 'failed', error: 'account no longer exists' };
  if (account.status !== 'active') return { status: 'failed', error: 'account needs to be reconnected' };
  const [prefs] = await db.select().from(preferences).where(eq(preferences.userId, account.userId));
  const provider = getProvider(db, account);
  const p: ScanProgress = { mode, phase: 'starting', processed: 0, added: 0, ...(job.progress as Partial<ScanProgress> ?? {}) };

  try {
    if (mode === 'incremental' && !account.historyId) mode = p.mode = 'full';
    if (mode === 'incremental') {
      p.phase = 'syncing';
      let pageToken: string | undefined;
      let historyId = account.historyId!;
      do {
        const page = await provider.listHistory(account.historyId!, pageToken);
        p.added += await fetchAndIngest(db, provider, account, page.addedIds);
        p.processed += page.addedIds.length;
        historyId = page.historyId;
        pageToken = page.nextPageToken;
        if (!(await ctx.heartbeat({ ...p }))) return { status: 'stopped' };
      } while (pageToken);
      await db.update(mailAccounts).set({ historyId, lastSyncAt: new Date(), messagesScanned: sql`${mailAccounts.messagesScanned} + ${p.added}`, status: 'active', statusDetail: null }).where(eq(mailAccounts.id, account.id));
      return { status: 'done', progress: { ...p, phase: 'done', complete: true } };
    }

    // Full or partial scan: walk the message list newest-first.
    if (!p.startHistoryId) {
      const profile = await provider.getProfile();
      p.startHistoryId = profile.historyId;
      p.estimate = profile.messagesTotal;
    }
    const limit = mode === 'partial' ? PARTIAL_SCAN_LIMIT : (prefs?.scanMaxMessages ?? 20000);
    p.phase = 'scanning';
    let pageToken = p.pageToken ?? undefined;
    while (p.processed < limit) {
      const page = await provider.listMessageIds(pageToken, Math.min(PAGE, limit - p.processed));
      p.added += await fetchAndIngest(db, provider, account, page.ids);
      p.processed += page.ids.length;
      pageToken = page.nextPageToken;
      p.pageToken = pageToken ?? null;
      if (!(await ctx.heartbeat({ ...p }))) return { status: 'stopped' };
      if (!pageToken) break;
    }
    p.complete = !pageToken;
    p.limitReached = Boolean(pageToken);
    if (p.limitReached) p.note = mode === 'partial'
      ? `Partial scan: the ${p.processed} most recent messages only`
      : `Stopped at the scan limit of ${limit} messages; older mail was not scanned`;
    const update: Partial<MailAccount> = { lastSyncAt: new Date(), messagesScanned: sql`${mailAccounts.messagesScanned} + ${p.added}` as never, status: 'active', statusDetail: null };
    if (mode === 'full') {
      update.fullScanCompletedAt = new Date();
      // Incremental sync continues from the moment the full scan started, so nothing
      // that arrived during the scan is missed.
      if (!account.historyId) update.historyId = p.startHistoryId;
    }
    await db.update(mailAccounts).set(update).where(eq(mailAccounts.id, account.id));
    return { status: 'done', progress: { ...p, phase: 'done' } };
  } catch (e) {
    if (e instanceof HistoryExpiredError) {
      // Too old for incremental sync: rerun this same job as a full scan. Already stored
      // messages are skipped, so only new metadata is fetched.
      await db.update(mailAccounts).set({ historyId: null }).where(eq(mailAccounts.id, account.id));
      await db.update(jobs).set({ payload: { ...job.payload, mode: 'full' }, progress: { note: 'History expired; rescanning' } }).where(eq(jobs.id, job.id));
      return { status: 'defer', delayMs: 0, reason: 'history expired, switching to full scan' };
    }
    if (e instanceof ProviderAuthError) {
      await markReauth(db, account.id, 'Reconnect this account to continue scanning');
      return { status: 'failed', error: 'account needs to be reconnected' };
    }
    if (e instanceof RateLimitError) {
      await ctx.heartbeat({ ...p, phase: 'rate limited, waiting' });
      return { status: 'defer', delayMs: Math.max(e.retryAfterMs, 5000), reason: 'provider rate limit' };
    }
    await ctx.heartbeat({ ...p });
    throw e;
  }
}

export function enqueueScan(db: DB, account: { id: string; userId: string }, mode: ScanMode) {
  // Full and incremental scans of one account share a key so they never run concurrently.
  return enqueue(db, {
    type: 'scan', payload: { accountId: account.id, mode }, userId: account.userId, accountId: account.id,
    dedupeKey: `scan:${account.id}`, maxAttempts: 8,
  });
}

/** Synchronous incremental sync used by verification; returns false when it could not run. */
export async function syncNow(db: DB, account: MailAccount): Promise<boolean> {
  if (account.status !== 'active' || !account.historyId) return false;
  const provider = getProvider(db, account);
  let pageToken: string | undefined;
  let historyId = account.historyId;
  try {
    do {
      const page = await provider.listHistory(account.historyId, pageToken);
      await fetchAndIngest(db, provider, account, page.addedIds);
      historyId = page.historyId;
      pageToken = page.nextPageToken;
    } while (pageToken);
  } catch (e) {
    if (e instanceof HistoryExpiredError) {
      await db.update(mailAccounts).set({ historyId: null }).where(eq(mailAccounts.id, account.id));
      await enqueueScan(db, account, 'full');
      return false;
    }
    throw e;
  }
  await db.update(mailAccounts).set({ historyId, lastSyncAt: new Date() }).where(eq(mailAccounts.id, account.id));
  return true;
}
