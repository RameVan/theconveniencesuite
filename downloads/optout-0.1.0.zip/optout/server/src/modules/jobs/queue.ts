// Postgres-backed persistent job queue. Jobs survive process restarts: a job whose worker
// died keeps status 'running' with an expired lease and is claimed again.
import { and, eq, inArray, sql } from 'drizzle-orm';
import { randomUUID } from 'node:crypto';
import type { DB } from '../../db/client.ts';
import { jobs } from '../../db/schema.ts';
import { log, errMsg } from '../../lib/log.ts';
import { config } from '../../config.ts';

export type Job = typeof jobs.$inferSelect;

export interface EnqueueOpts {
  type: string;
  payload?: Record<string, unknown>;
  userId?: string | null;
  accountId?: string | null;
  dedupeKey?: string | null;
  runAt?: Date;
  maxAttempts?: number;
}

/** Inserts a job unless an unfinished job with the same dedupeKey exists; returns either. */
export async function enqueue(db: DB, o: EnqueueOpts): Promise<{ job: Job; created: boolean }> {
  const rows = await db.insert(jobs).values({
    type: o.type,
    payload: o.payload ?? {},
    userId: o.userId ?? null,
    accountId: o.accountId ?? null,
    dedupeKey: o.dedupeKey ?? null,
    runAt: o.runAt ?? new Date(),
    maxAttempts: o.maxAttempts ?? 5,
  }).onConflictDoNothing().returning();
  if (rows[0]) return { job: rows[0], created: true };
  const [existing] = await db.select().from(jobs)
    .where(and(eq(jobs.dedupeKey, o.dedupeKey!), inArray(jobs.status, ['queued', 'running', 'paused'])));
  return { job: existing, created: false };
}

const leaseMs = () => config.jobLeaseMs;

export async function claim(db: DB, workerId: string, types: string[]): Promise<Job | null> {
  const typeList = sql.join(types.map((t) => sql`${t}`), sql`, `);
  const res = await db.execute(sql`
    update jobs set status = 'running', locked_by = ${workerId}, attempts = attempts + 1,
      lease_until = now() + (${leaseMs()} * interval '1 millisecond'), updated_at = now()
    where id = (
      select id from jobs
      where type in (${typeList})
        and ((status = 'queued' and run_at <= now()) or (status = 'running' and lease_until < now()))
      order by run_at
      limit 1
      for update skip locked
    )
    returning id`);
  const id = (res as unknown as { rows: { id: string }[] }).rows[0]?.id;
  if (!id) return null;
  const [job] = await db.select().from(jobs).where(eq(jobs.id, id));
  return job ?? null;
}

const owned = (job: Job, workerId: string) =>
  and(eq(jobs.id, job.id), eq(jobs.status, 'running'), eq(jobs.lockedBy, workerId));

export interface JobContext {
  db: DB;
  job: Job;
  /** Extends the lease and saves progress. Returns false when the job was paused or cancelled. */
  heartbeat(progress?: Record<string, unknown>): Promise<boolean>;
}

export type JobOutcome =
  | { status: 'done'; progress?: Record<string, unknown> }
  /** Try again later without counting an attempt (rate limit, throttle). */
  | { status: 'defer'; delayMs: number; reason?: string }
  /** Counted retry with the given delay. */
  | { status: 'retry'; delayMs?: number; error: string }
  | { status: 'failed'; error: string }
  /** The handler noticed it was paused/cancelled and stopped. */
  | { status: 'stopped' };

export type JobHandler = (ctx: JobContext) => Promise<JobOutcome>;

export class PermanentJobError extends Error {}

export const backoffMs = (attempt: number) => Math.min(60 * 60 * 1000, 5000 * 2 ** (attempt - 1)) + Math.floor(Math.random() * 1000);

async function finish(db: DB, job: Job, workerId: string, outcome: JobOutcome): Promise<void> {
  const now = new Date();
  const where = owned(job, workerId);
  switch (outcome.status) {
    case 'done':
      await db.update(jobs).set({ status: 'succeeded', finishedAt: now, updatedAt: now, leaseUntil: null, lastError: null, ...(outcome.progress ? { progress: outcome.progress } : {}) }).where(where);
      return;
    case 'defer':
      await db.update(jobs).set({ status: 'queued', attempts: sql`greatest(${jobs.attempts} - 1, 0)`, runAt: new Date(now.getTime() + outcome.delayMs), leaseUntil: null, lockedBy: null, updatedAt: now, lastError: outcome.reason ?? null }).where(where);
      return;
    case 'retry':
      if (job.attempts >= job.maxAttempts) {
        await db.update(jobs).set({ status: 'failed', lastError: outcome.error, finishedAt: now, updatedAt: now, leaseUntil: null }).where(where);
      } else {
        await db.update(jobs).set({ status: 'queued', lastError: outcome.error, runAt: new Date(now.getTime() + (outcome.delayMs ?? backoffMs(job.attempts))), leaseUntil: null, lockedBy: null, updatedAt: now }).where(where);
      }
      return;
    case 'failed':
      await db.update(jobs).set({ status: 'failed', lastError: outcome.error, finishedAt: now, updatedAt: now, leaseUntil: null }).where(where);
      return;
    case 'stopped':
      return; // status was already changed by whoever paused/cancelled it
  }
}

export async function runJob(db: DB, job: Job, workerId: string, handler: JobHandler): Promise<JobOutcome> {
  if (job.attempts > job.maxAttempts) {
    const outcome: JobOutcome = { status: 'failed', error: job.lastError ?? 'too many attempts (worker restarts)' };
    await finish(db, job, workerId, outcome);
    return outcome;
  }
  const ctx: JobContext = {
    db,
    job,
    async heartbeat(progress) {
      const r = await db.update(jobs)
        .set({ leaseUntil: new Date(Date.now() + leaseMs()), updatedAt: new Date(), ...(progress ? { progress } : {}) })
        .where(owned(job, workerId)).returning({ id: jobs.id });
      return r.length > 0;
    },
  };
  let outcome: JobOutcome;
  try {
    outcome = await handler(ctx);
  } catch (e) {
    outcome = e instanceof PermanentJobError ? { status: 'failed', error: errMsg(e) } : { status: 'retry', error: errMsg(e) };
  }
  await finish(db, job, workerId, outcome);
  return outcome;
}

export class Worker {
  readonly id = `w-${randomUUID().slice(0, 8)}`;
  private db: DB;
  private handlers: Record<string, JobHandler>;
  private concurrency: number;
  private running = false;
  private slots: Promise<void>[] = [];
  private wake: (() => void) | null = null;
  pollMs = 1000;

  constructor(db: DB, handlers: Record<string, JobHandler>, concurrency: number) {
    this.db = db;
    this.handlers = handlers;
    this.concurrency = concurrency;
  }

  start(): void {
    if (this.running) return;
    this.running = true;
    for (let i = 0; i < this.concurrency; i++) this.slots.push(this.loop());
    log.info('worker started', { id: this.id, concurrency: this.concurrency });
  }

  /** Nudge idle slots after enqueueing so work starts without waiting for the poll. */
  notify(): void { this.wake?.(); }

  async stop(): Promise<void> {
    this.running = false;
    this.notify();
    await Promise.all(this.slots);
    this.slots = [];
  }

  /** Processes jobs until none are runnable (tests and CLI). */
  async drain(maxJobs = 10000): Promise<number> {
    let n = 0;
    while (n < maxJobs) {
      const job = await claim(this.db, this.id, Object.keys(this.handlers));
      if (!job) break;
      await runJob(this.db, job, this.id, this.handlers[job.type]);
      n++;
    }
    return n;
  }

  private async loop(): Promise<void> {
    while (this.running) {
      let job: Job | null = null;
      try {
        job = await claim(this.db, this.id, Object.keys(this.handlers));
        if (job) await runJob(this.db, job, this.id, this.handlers[job.type]);
      } catch (e) {
        log.error('worker loop error', { error: errMsg(e) });
      }
      if (!job && this.running) {
        await new Promise<void>((r) => { const t = setTimeout(r, this.pollMs); this.wake = () => { clearTimeout(t); r(); }; });
      }
    }
  }
}

/**
 * Spacing between requests to one sender domain, shared across workers through the database.
 * Returns 0 when the caller may proceed now, otherwise the milliseconds to wait.
 */
export async function acquireDomainSlot(db: DB, domain: string, scope: string, spacingMs: number): Promise<number> {
  const res = await db.execute(sql`
    insert into domain_throttle (domain, scope, next_allowed_at)
    values (${domain}, ${scope}, now() + (${spacingMs} * interval '1 millisecond'))
    on conflict (domain, scope) do update
      set next_allowed_at = now() + (${spacingMs} * interval '1 millisecond')
      where domain_throttle.next_allowed_at <= now()
    returning domain`);
  if ((res as unknown as { rows: unknown[] }).rows.length) return 0;
  const r2 = await db.execute(sql`select greatest(0, extract(epoch from (next_allowed_at - now())) * 1000)::int as wait from domain_throttle where domain = ${domain} and scope = ${scope}`);
  return Math.max(1, Number((r2 as unknown as { rows: { wait: number }[] }).rows[0]?.wait ?? spacingMs));
}
