import { and, asc, desc, eq, ilike, inArray, isNull, notInArray, or, sql, type SQL } from 'drizzle-orm';
import { z } from 'zod';
import type { DB } from '../db/client.ts';
import { categories, mailAccounts, senderIdentities, ACTIVE_UNSUB_STATES } from '../db/schema.ts';
import { planMethod } from './unsubscribe/engine.ts';

export const filterSchema = z.object({
  search: z.string().max(200).optional(),
  categoryId: z.string().uuid().optional(),
  accountId: z.string().uuid().optional(),
  method: z.enum(['one_click', 'mailto', 'web', 'none']).optional(),
  status: z.enum(['none', 'in_progress', 'unsubscribed', 'failed', 'needs_action']).optional(),
  kind: z.enum(['marketing', 'transactional', 'personal', 'unknown']).optional(),
  excludeWhitelisted: z.coerce.boolean().optional(),
  excludeProtected: z.coerce.boolean().optional(),
  onlyKept: z.coerce.boolean().optional(),
  sort: z.enum(['volume', 'frequency', 'recent', 'name']).default('volume'),
  order: z.enum(['asc', 'desc']).default('desc'),
  limit: z.coerce.number().int().min(1).max(500).default(100),
  offset: z.coerce.number().int().min(0).default(0),
});
export type Filter = z.infer<typeof filterSchema>;

// Mail per month: last 90 days when the sender is older than that, otherwise the whole history.
const perMonth = sql<number>`(case
  when ${senderIdentities.firstSeenAt} < now() - interval '90 days'
    then (select count(*) from messages m where m.identity_id = "sender_identities"."id" and m.received_at > now() - interval '90 days') / 3.0
  else ${senderIdentities.messageCount} * 30.0 / greatest(30, extract(epoch from (now() - ${senderIdentities.firstSeenAt})) / 86400)
  end)::real`;

function conditions(userId: string, f: Partial<Filter>): SQL[] {
  const c: SQL[] = [eq(senderIdentities.userId, userId)];
  if (f.search) {
    const q = `%${f.search.replace(/[%_\\]/g, (m) => `\\${m}`)}%`;
    c.push(or(ilike(senderIdentities.fromName, q), ilike(senderIdentities.fromAddress, q), ilike(senderIdentities.domain, q), ilike(senderIdentities.listId, q))!);
  }
  if (f.categoryId) c.push(eq(senderIdentities.categoryId, f.categoryId));
  if (f.accountId) c.push(eq(senderIdentities.accountId, f.accountId));
  if (f.kind) c.push(eq(senderIdentities.kind, f.kind));
  if (f.method === 'one_click') c.push(sql`${senderIdentities.oneClick} and ${senderIdentities.unsubHttp} like 'https://%'`);
  if (f.method === 'mailto') c.push(sql`${senderIdentities.unsubMailto} is not null`);
  if (f.method === 'web') c.push(sql`${senderIdentities.unsubHttp} is not null and not ${senderIdentities.oneClick}`);
  if (f.method === 'none') c.push(sql`${senderIdentities.unsubHttp} is null and ${senderIdentities.unsubMailto} is null`);
  if (f.status === 'none') c.push(or(isNull(senderIdentities.unsubState), inArray(senderIdentities.unsubState, ['cancelled', 'prepared']))!);
  if (f.status === 'in_progress') c.push(inArray(senderIdentities.unsubState, ['queued', 'processing', 'request_submitted', 'verification_pending']));
  if (f.status === 'unsubscribed') c.push(inArray(senderIdentities.unsubState, ['unsubscribed', 'verification_unavailable']));
  if (f.status === 'failed') c.push(eq(senderIdentities.unsubState, 'failed'));
  if (f.status === 'needs_action') c.push(inArray(senderIdentities.unsubState, ['requires_manual_action', 'awaiting_confirmation', 'awaiting_approval']));
  if (f.excludeWhitelisted) c.push(eq(senderIdentities.whitelisted, false));
  if (f.onlyKept) c.push(eq(senderIdentities.whitelisted, true));
  if (f.excludeProtected) c.push(eq(senderIdentities.isProtected, false), sql`coalesce(${categories.isProtected}, false) = false`);
  return c;
}

const columns = {
  id: senderIdentities.id,
  accountId: senderIdentities.accountId,
  accountEmail: mailAccounts.email,
  fromAddress: senderIdentities.fromAddress,
  fromName: senderIdentities.fromName,
  domain: senderIdentities.domain,
  listId: senderIdentities.listId,
  lastSubject: senderIdentities.lastSubject,
  messageCount: senderIdentities.messageCount,
  firstSeenAt: senderIdentities.firstSeenAt,
  lastSeenAt: senderIdentities.lastSeenAt,
  unsubHttp: senderIdentities.unsubHttp,
  unsubMailto: senderIdentities.unsubMailto,
  oneClick: senderIdentities.oneClick,
  categoryId: senderIdentities.categoryId,
  categoryName: categories.name,
  categorySlug: categories.slug,
  categoryProtected: categories.isProtected,
  categorySource: senderIdentities.categorySource,
  confidence: senderIdentities.confidence,
  kind: senderIdentities.kind,
  isProtected: senderIdentities.isProtected,
  protectionReason: senderIdentities.protectionReason,
  protectionSource: senderIdentities.protectionSource,
  whitelisted: senderIdentities.whitelisted,
  unsubState: senderIdentities.unsubState,
  unsubStateAt: senderIdentities.unsubStateAt,
  updatedAt: senderIdentities.updatedAt,
  perMonth,
};

export type SubscriptionRow = Awaited<ReturnType<typeof listSubscriptions>>['items'][number];

export async function listSubscriptions(db: DB, userId: string, f: Filter, mailtoEnabled: boolean) {
  const where = and(...conditions(userId, f));
  const dir = f.order === 'asc' ? asc : desc;
  const orderBy = f.sort === 'name' ? [dir(sql`lower(coalesce(${senderIdentities.fromName}, ${senderIdentities.fromAddress}))`)]
    : f.sort === 'recent' ? [dir(senderIdentities.lastSeenAt)]
    : f.sort === 'frequency' ? [dir(perMonth), desc(senderIdentities.messageCount)]
    : [dir(senderIdentities.messageCount), desc(senderIdentities.lastSeenAt)];
  const base = db.select(columns).from(senderIdentities)
    .innerJoin(mailAccounts, eq(mailAccounts.id, senderIdentities.accountId))
    .leftJoin(categories, eq(categories.id, senderIdentities.categoryId))
    .where(where);
  const [rows, [{ total }]] = await Promise.all([
    base.orderBy(...orderBy, asc(senderIdentities.id)).limit(f.limit).offset(f.offset),
    db.select({ total: sql<number>`count(*)::int` }).from(senderIdentities)
      .leftJoin(categories, eq(categories.id, senderIdentities.categoryId)).where(where),
  ]);
  return { total, items: rows.map((r) => decorate(r, mailtoEnabled)) };
}

function decorate<T extends { oneClick: boolean; unsubHttp: string | null; unsubMailto: string | null; whitelisted: boolean; isProtected: boolean; categoryProtected: boolean | null; unsubState: string | null; perMonth: number }>(r: T, mailtoEnabled: boolean) {
  const { method } = planMethod(r, mailtoEnabled);
  const active = (ACTIVE_UNSUB_STATES as readonly string[]).includes(r.unsubState ?? '');
  const eligible = !r.whitelisted && !r.isProtected && !r.categoryProtected && !active && r.unsubState !== 'unsubscribed';
  return { ...r, perMonth: Math.round(Number(r.perMonth) * 10) / 10, method, eligible };
}

/** Ids matching a filter, for "select all in category" or "all eligible marketing". */
export async function idsForFilter(db: DB, userId: string, f: Partial<Filter>, eligibleOnly: boolean, cap: number): Promise<string[]> {
  const c = conditions(userId, f);
  if (eligibleOnly) {
    c.push(eq(senderIdentities.whitelisted, false), eq(senderIdentities.isProtected, false), sql`coalesce(${categories.isProtected}, false) = false`);
    c.push(or(isNull(senderIdentities.unsubState), notInArray(senderIdentities.unsubState, [...ACTIVE_UNSUB_STATES, 'unsubscribed']))!);
  }
  const rows = await db.select({ id: senderIdentities.id }).from(senderIdentities)
    .leftJoin(categories, eq(categories.id, senderIdentities.categoryId))
    .where(and(...c)).orderBy(desc(senderIdentities.messageCount)).limit(cap + 1);
  return rows.map((r) => r.id);
}

export async function getSubscription(db: DB, userId: string, id: string, mailtoEnabled: boolean) {
  const [r] = await db.select(columns).from(senderIdentities)
    .innerJoin(mailAccounts, eq(mailAccounts.id, senderIdentities.accountId))
    .leftJoin(categories, eq(categories.id, senderIdentities.categoryId))
    .where(and(eq(senderIdentities.userId, userId), eq(senderIdentities.id, id)));
  return r ? decorate(r, mailtoEnabled) : null;
}
