// Unsubscribe engine. Every state change goes through transition(), which records an event
// and mirrors the state onto the sender identity so both interfaces show the same thing.
import { and, eq, gt, inArray, sql } from 'drizzle-orm';
import { randomUUID } from 'node:crypto';
import type { DB } from '../../db/client.ts';
import {
  categories, mailAccounts, messages, preferences, senderIdentities, unsubscribeEvents, unsubscribeRequests, ACTIVE_UNSUB_STATES,
} from '../../db/schema.ts';
import { config } from '../../config.ts';
import { parseMailto } from '../../lib/headers.ts';
import { isTlsError, safeRequest, validateDestination, UnsafeDestinationError, type SafeHttpOptions } from '../../lib/safe-http.ts';
import { errMsg } from '../../lib/log.ts';
import { getProvider, markReauth } from '../accounts.ts';
import { MissingScopeError, ProviderAuthError, RateLimitError } from '../../providers/types.ts';
import { acquireDomainSlot, enqueue, type JobContext, type JobOutcome } from '../jobs/queue.ts';
import { syncNow } from '../discovery/scan.ts';

export type Identity = typeof senderIdentities.$inferSelect;
export type UnsubRequest = typeof unsubscribeRequests.$inferSelect;
export type Method = 'one_click' | 'mailto' | 'web' | 'manual';

export const STATE_LABELS: Record<string, string> = {
  awaiting_approval: 'Awaiting your approval',
  queued: 'Queued',
  processing: 'Processing',
  awaiting_confirmation: 'Sender asks for confirmation',
  request_submitted: 'Request submitted',
  verification_pending: 'Submitted, verifying',
  requires_manual_action: 'Needs you to finish',
  unsubscribed: 'Unsubscribed (verified)',
  verification_unavailable: 'Submitted, cannot be verified',
  failed: 'Failed',
  cancelled: 'Cancelled',
  prepared: 'Dry run: validated, not sent',
};

/** Days after submission during which mail is still expected (RFC 8058 senders get up to 2 days). */
export const GRACE_DAYS = 2;

/** Tests may relax destination checks to reach a local server. */
let httpOptions: SafeHttpOptions = {};
export function setUnsubscribeHttpOptions(o: SafeHttpOptions): void { httpOptions = o; }

/** Minimum gap between one-click requests to one host, across all workers. */
let domainSpacingMs = 3000;
export function setDomainSpacingMs(ms: number): void { domainSpacingMs = ms; }

// RFC 8058 requires HTTPS; plain HTTP is only accepted by the test-only allowHttp switch.
const oneClickUrl = (u: string | null) => Boolean(u && (/^https:\/\//i.test(u) || (httpOptions.allowHttp && /^http:\/\//i.test(u))));

export function planMethod(i: Pick<Identity, 'oneClick' | 'unsubHttp' | 'unsubMailto'>, mailtoEnabled: boolean): { method: Method; target: string | null } {
  if (i.oneClick && oneClickUrl(i.unsubHttp)) return { method: 'one_click', target: i.unsubHttp };
  const mailto = i.unsubMailto && parseMailto(i.unsubMailto) ? i.unsubMailto : null;
  if (mailto && (mailtoEnabled || !i.unsubHttp)) return { method: 'mailto', target: mailto };
  if (i.unsubHttp) return { method: 'web', target: i.unsubHttp };
  return { method: 'manual', target: null };
}

export interface Eligibility { id: string; eligible: boolean; reason?: string; method?: Method; needsOverride?: boolean }

export async function checkEligibility(db: DB, userId: string, ids: string[], opts: { allowProtected: boolean; mailtoEnabled: boolean }): Promise<Eligibility[]> {
  if (!ids.length) return [];
  const rows = await db.select({ i: senderIdentities, catProtected: categories.isProtected, catName: categories.name })
    .from(senderIdentities).leftJoin(categories, eq(categories.id, senderIdentities.categoryId))
    .where(and(eq(senderIdentities.userId, userId), inArray(senderIdentities.id, ids)));
  const found = new Map(rows.map((r) => [r.i.id, r]));
  return ids.map((id) => {
    const r = found.get(id);
    if (!r) return { id, eligible: false, reason: 'not found' };
    const { i } = r;
    const { method } = planMethod(i, opts.mailtoEnabled);
    if (i.whitelisted) return { id, eligible: false, reason: 'whitelisted', method };
    if ((ACTIVE_UNSUB_STATES as readonly string[]).includes(i.unsubState ?? '')) return { id, eligible: false, reason: 'already in progress', method };
    if (i.unsubState === 'unsubscribed') return { id, eligible: false, reason: 'already unsubscribed', method };
    const protectedWhy = i.isProtected ? (i.protectionReason ?? 'protected') : r.catProtected ? `protected category: ${r.catName}` : null;
    if (protectedWhy && !opts.allowProtected) return { id, eligible: false, reason: protectedWhy, method, needsOverride: true };
    if (method === 'manual') return { id, eligible: true, method, reason: 'no unsubscribe link: you will get instructions' };
    return { id, eligible: true, method };
  });
}

async function mailtoEnabledFor(db: DB, userId: string): Promise<boolean> {
  const [p] = await db.select({ m: preferences.mailtoEnabled }).from(preferences).where(eq(preferences.userId, userId));
  return Boolean(p?.m);
}

export interface CreateResult { created: { requestId: string; identityId: string; method: Method }[]; skipped: Eligibility[]; batchId: string }

/** Creates requests and queues their jobs. The partial unique index rejects duplicates. */
export async function createRequests(db: DB, userId: string, ids: string[], opts: { source: 'web' | 'extension'; allowProtected?: boolean }): Promise<CreateResult> {
  const mailtoEnabled = await mailtoEnabledFor(db, userId);
  const elig = await checkEligibility(db, userId, [...new Set(ids)], { allowProtected: Boolean(opts.allowProtected), mailtoEnabled });
  const batchId = randomUUID();
  const created: CreateResult['created'] = [];
  const skipped = elig.filter((e) => !e.eligible);
  const rows = await db.select().from(senderIdentities).where(inArray(senderIdentities.id, elig.filter((e) => e.eligible).map((e) => e.id).concat(['00000000-0000-0000-0000-000000000000'])));
  for (const identity of rows) {
    const { method, target } = planMethod(identity, mailtoEnabled);
    const [req] = await db.insert(unsubscribeRequests).values({
      userId, accountId: identity.accountId, identityId: identity.id, method, target, state: 'queued', source: opts.source,
      batchId, dryRun: config.unsubscribeMode !== 'live', baselineLastSeenAt: identity.lastSeenAt,
    }).onConflictDoNothing().returning();
    if (!req) { skipped.push({ id: identity.id, eligible: false, reason: 'already in progress' }); continue; }
    await db.insert(unsubscribeEvents).values({ requestId: req.id, toState: 'queued', detail: `${method} via ${opts.source}${req.dryRun ? ' (dry run)' : ''}${identity.isProtected ? '; protection overridden by user' : ''}` });
    await mirror(db, identity.id, 'queued');
    await enqueue(db, { type: 'unsubscribe', payload: { requestId: req.id }, userId, accountId: identity.accountId, dedupeKey: `unsub:${req.id}`, maxAttempts: 4 });
    created.push({ requestId: req.id, identityId: identity.id, method });
  }
  return { created, skipped, batchId };
}

async function mirror(db: DB, identityId: string, state: string): Promise<void> {
  await db.update(senderIdentities).set({ unsubState: state, unsubStateAt: new Date(), updatedAt: new Date() }).where(eq(senderIdentities.id, identityId));
}

async function setInFlight(db: DB, id: string, at: Date | null): Promise<void> {
  await db.update(unsubscribeRequests).set({ inFlightAt: at }).where(eq(unsubscribeRequests.id, id));
}

async function applyTransition(tx: DB, req: UnsubRequest, from: string[], to: string, detail: string | null, extra: Partial<UnsubRequest>): Promise<boolean> {
  // Leaving "processing" means the send's outcome is now recorded, so it is no longer in flight.
  const set = { state: to, updatedAt: new Date(), ...(to !== 'processing' ? { inFlightAt: null } : {}), ...extra };
  const updated = await tx.update(unsubscribeRequests).set(set)
    .where(and(eq(unsubscribeRequests.id, req.id), inArray(unsubscribeRequests.state, from))).returning({ id: unsubscribeRequests.id });
  if (!updated.length) return false;
  await tx.insert(unsubscribeEvents).values({ requestId: req.id, fromState: req.state, toState: to, detail });
  await mirror(tx, req.identityId, to);
  return true;
}

/**
 * Compare-and-set state change, atomic: the request, its history and the sender's displayed
 * state change together or not at all (a crash can't leave them disagreeing).
 * Returns false if the request was no longer in `from`.
 */
export async function transition(db: DB, req: UnsubRequest, from: string[], to: string, detail: string | null, extra: Partial<UnsubRequest> = {}): Promise<boolean> {
  const ok = await db.transaction((tx) => applyTransition(tx as unknown as DB, req, from, to, detail, extra));
  if (ok) { req.state = to; Object.assign(req, extra); }
  return ok;
}

async function verificationDays(db: DB, userId: string): Promise<number> {
  const [p] = await db.select({ d: preferences.verificationDays }).from(preferences).where(eq(preferences.userId, userId));
  return p?.d ?? 7;
}

async function markSubmitted(db: DB, req: UnsubRequest, detail: string, httpStatus?: number): Promise<void> {
  const days = await verificationDays(db, req.userId);
  const now = new Date();
  const verifyAfter = new Date(now.getTime() + Math.max(days, GRACE_DAYS + 1) * 86400000);
  // One transaction: a crash can never leave a submitted request without its verification job.
  await db.transaction(async (raw) => {
    const tx = raw as unknown as DB;
    const r = { ...req };
    if (!(await applyTransition(tx, r, ['processing'], 'request_submitted', detail, { submittedAt: now, httpStatus: httpStatus ?? null }))) return;
    r.state = 'request_submitted';
    await applyTransition(tx, r, ['request_submitted'], 'verification_pending', `Will check for new mail after ${verifyAfter.toISOString().slice(0, 10)}`, { verifyAfter });
    await enqueue(tx, { type: 'verify', payload: { requestId: req.id }, userId: req.userId, accountId: req.accountId, dedupeKey: `verify:${req.id}`, runAt: verifyAfter, maxAttempts: 6 });
  });
  Object.assign(req, { state: 'verification_pending', submittedAt: now, verifyAfter, httpStatus: httpStatus ?? null, inFlightAt: null });
}

const CAPTCHA = /captcha|are you (a )?human|recaptcha|hcaptcha|cf-challenge/i;
const NEEDS_CONFIRM = /(click|press|tap) (the )?(button|link|here) (below )?to (confirm|unsubscribe|complete)|confirm (your )?unsubscri/i;

async function executeOneClick(db: DB, req: UnsubRequest, identity: Identity): Promise<JobOutcome> {
  let url = req.target!;
  await setInFlight(db, req.id, new Date());
  for (let hop = 0; hop < 3; hop++) {
    const res = await safeRequest(url, {
      method: 'POST',
      body: 'List-Unsubscribe=One-Click',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
    }, httpOptions);
    if ((res.status === 307 || res.status === 308) && res.headers.location) {
      url = new URL(String(res.headers.location), url).toString(); // re-validated by safeRequest
      continue;
    }
    if (res.status >= 200 && res.status < 300) {
      if (CAPTCHA.test(res.body)) {
        await transition(db, req, ['processing'], 'requires_manual_action', 'The sender answered with a CAPTCHA; finish on their page', { httpStatus: res.status });
        return { status: 'done' };
      }
      if (NEEDS_CONFIRM.test(res.body)) {
        await transition(db, req, ['processing'], 'awaiting_confirmation', 'The sender asks for an extra confirmation on their page', { httpStatus: res.status });
        return { status: 'done' };
      }
      await markSubmitted(db, req, `One-click POST accepted by ${new URL(url).hostname} (HTTP ${res.status})`, res.status);
      return { status: 'done' };
    }
    if (res.status === 301 || res.status === 302 || res.status === 303) {
      await markSubmitted(db, req, `One-click POST received; sender redirected (HTTP ${res.status})`, res.status);
      return { status: 'done' };
    }
    if (res.status === 429 || res.status === 408 || res.status >= 500) {
      // Repeating an unsubscribe POST is harmless, so transient errors are retried,
      // no sooner than the sender's Retry-After.
      const retryAfter = Number(res.headers['retry-after']) * 1000;
      return { status: 'retry', error: `sender returned HTTP ${res.status}`, ...(retryAfter > 0 ? { delayMs: Math.min(Math.max(retryAfter, 1000), 3600000) } : {}) };
    }
    if (res.status === 405) {
      // The one-click link doesn't accept POST: the page itself usually still works in a browser.
      await transition(db, req, ['processing'], 'requires_manual_action', "The sender's one-click link didn't accept the automatic request. Open the page to finish there.", { httpStatus: res.status });
      return { status: 'done' };
    }
    const why = res.status === 404 || res.status === 410 ? 'the unsubscribe link is no longer valid' : 'the sender rejected the request';
    await transition(db, req, ['processing'], 'failed', `Failed: ${why} (HTTP ${res.status})${identity.unsubMailto ? '; an email unsubscribe is available' : ''}`, { httpStatus: res.status });
    return { status: 'done' };
  }
  await transition(db, req, ['processing'], 'failed', 'Too many redirects', {});
  return { status: 'done' };
}

function buildMailto(from: string, m: { to: string; subject: string; body: string }): string {
  const enc = (s: string) => (/^[\x20-\x7e]*$/.test(s) ? s : `=?UTF-8?B?${Buffer.from(s).toString('base64')}?=`);
  return [
    `From: ${from}`,
    `To: ${m.to}`,
    `Subject: ${enc(m.subject)}`,
    `Date: ${new Date().toUTCString()}`,
    `Message-ID: <${randomUUID()}@optout.local>`,
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset=UTF-8',
    'Auto-Submitted: auto-generated',
    '',
    m.body,
    '',
  ].join('\r\n');
}

async function executeMailto(db: DB, req: UnsubRequest): Promise<JobOutcome> {
  const [account] = await db.select().from(mailAccounts).where(eq(mailAccounts.id, req.accountId));
  const m = parseMailto(req.target!);
  if (!m) { await transition(db, req, ['processing'], 'failed', 'Invalid mailto address', {}); return { status: 'done' }; }
  const provider = getProvider(db, account);
  if (!provider.hasSendScope()) {
    await transition(db, req, ['processing'], 'awaiting_approval', 'Sending an unsubscribe email needs the Gmail "send" permission. Grant it in Accounts, or send it yourself.', {});
    return { status: 'done' };
  }
  const wait = await acquireDomainSlot(db, account.id, 'gmail-send', 2000);
  if (wait) return { status: 'defer', delayMs: wait };
  try {
    await setInFlight(db, req.id, new Date());
    const sent = await provider.sendRaw(buildMailto(account.email, m));
    await markSubmitted(db, req, `Unsubscribe email sent to ${m.to.split('@')[1]} (message ${sent.id})`);
  } catch (e) {
    if (e instanceof RateLimitError) return { status: 'defer', delayMs: e.retryAfterMs };
    if (e instanceof MissingScopeError) {
      await transition(db, req, ['processing'], 'awaiting_approval', 'Gmail send permission is missing', {});
    } else if (e instanceof ProviderAuthError) {
      await markReauth(db, account.id, 'Reconnect this account');
      await transition(db, req, ['processing'], 'failed', 'Account needs to be reconnected; nothing was sent', {});
    } else {
      // Sending is not idempotent: an unclear failure is reported, never blindly retried.
      await transition(db, req, ['processing'], 'failed', `Sending failed; the email may or may not have been sent (${errMsg(e)})`, {});
    }
  }
  return { status: 'done' };
}

/** Job handler 'unsubscribe'. */
export async function unsubscribeHandler(ctx: JobContext): Promise<JobOutcome> {
  const { db } = ctx;
  const [req] = await db.select().from(unsubscribeRequests).where(eq(unsubscribeRequests.id, String(ctx.job.payload.requestId)));
  if (!req || !['queued', 'processing'].includes(req.state)) return { status: 'done' };
  const [identity] = await db.select().from(senderIdentities).where(eq(senderIdentities.id, req.identityId));
  if (!identity) return { status: 'done' };
  const [account] = await db.select().from(mailAccounts).where(eq(mailAccounts.id, req.accountId));

  // Sender-specific spacing so a bulk run never hammers one company.
  if (req.method === 'one_click') {
    const host = (() => { try { return new URL(req.target!).hostname; } catch { return identity.domain; } })();
    const wait = domainSpacingMs ? await acquireDomainSlot(db, host, 'unsubscribe', domainSpacingMs) : 0;
    if (wait) return { status: 'defer', delayMs: wait };
  }
  // The previous attempt died while its request was on the wire (process crash or restart).
  if (req.state === 'processing' && req.inFlightAt) {
    await setInFlight(db, req.id, null);
    if (req.method === 'mailto') {
      await transition(db, req, ['processing'], 'failed', 'Interrupted while sending the unsubscribe email: it may or may not have been sent. It was not sent again, to avoid a duplicate email.', {});
      return { status: 'done' };
    }
    await db.insert(unsubscribeEvents).values({ requestId: req.id, fromState: 'processing', toState: 'processing', detail: 'The previous attempt was interrupted mid-request; sending again (a repeated unsubscribe request is harmless)' });
  }
  if (req.state === 'queued') await transition(db, req, ['queued'], 'processing', null, { attempts: req.attempts + 1 });
  else await db.update(unsubscribeRequests).set({ attempts: req.attempts + 1 }).where(eq(unsubscribeRequests.id, req.id));

  try {
    // Web pages are opened by the user, not fetched here, so http is acceptable for them;
    // private and internal addresses are still refused.
    if (req.method === 'one_click') validateDestination(req.target!, httpOptions);
    if (req.method === 'web') validateDestination(req.target!, { ...httpOptions, allowHttp: true });
  } catch (e) {
    await transition(db, req, ['processing'], 'failed', `Unsafe or invalid destination: ${(e as Error).message}`, {});
    return { status: 'done' };
  }

  if (req.method === 'web') {
    await transition(db, req, ['processing'], 'requires_manual_action', 'This sender only offers a web page. Open it, confirm there, then mark it done.', {});
    return { status: 'done' };
  }
  if (req.method === 'manual') {
    await transition(db, req, ['processing'], 'requires_manual_action', 'No unsubscribe link was found. Use the link in one of their emails, or filter or block the sender in Gmail.', {});
    return { status: 'done' };
  }
  if (req.dryRun) {
    await transition(db, req, ['processing'], 'prepared', `Dry run: ${req.method === 'one_click' ? 'one-click POST' : 'unsubscribe email'} validated but not sent (UNSUBSCRIBE_MODE=dry_run)`, {});
    return { status: 'done' };
  }
  if (account?.status !== 'active') {
    await transition(db, req, ['processing'], 'failed', 'The mail account needs to be reconnected; nothing was sent', {});
    return { status: 'done' };
  }
  try {
    let out: JobOutcome;
    try {
      out = req.method === 'one_click' ? await executeOneClick(db, req, identity) : await executeMailto(db, req);
    } finally {
      await setInFlight(db, req.id, null);
    }
    if (out.status === 'retry') {
      await db.update(unsubscribeRequests).set({ lastError: out.error, updatedAt: new Date() }).where(eq(unsubscribeRequests.id, req.id));
      if (ctx.job.attempts >= ctx.job.maxAttempts) {
        await transition(db, req, ['processing'], 'failed', `Gave up after ${ctx.job.attempts} attempts: ${out.error}`, {});
        return { status: 'done' };
      }
    }
    return out;
  } catch (e) {
    if (e instanceof UnsafeDestinationError) {
      await transition(db, req, ['processing'], 'failed', `Unsafe destination: ${e.message}`, {});
      return { status: 'done' };
    }
    if (isTlsError(e)) {
      await transition(db, req, ['processing'], 'failed', `The sender's secure connection failed its certificate check (${(e as { code?: string }).code}); nothing was sent`, {});
      return { status: 'done' };
    }
    const msg = errMsg(e);
    await db.update(unsubscribeRequests).set({ lastError: msg, updatedAt: new Date() }).where(eq(unsubscribeRequests.id, req.id));
    if (ctx.job.attempts >= ctx.job.maxAttempts) {
      await transition(db, req, ['processing'], 'failed', `Gave up after ${ctx.job.attempts} attempts: ${msg}`, {});
      return { status: 'done' };
    }
    return { status: 'retry', error: msg };
  }
}

/** Job handler 'verify': judges an unsubscribe by whether mail keeps arriving. */
export async function verifyHandler(ctx: JobContext): Promise<JobOutcome> {
  const { db } = ctx;
  const [req] = await db.select().from(unsubscribeRequests).where(eq(unsubscribeRequests.id, String(ctx.job.payload.requestId)));
  if (!req || req.state !== 'verification_pending' || !req.submittedAt) return { status: 'done' };
  // Never judge early, even if the job was started ahead of time.
  if (req.verifyAfter && req.verifyAfter.getTime() > Date.now()) return { status: 'defer', delayMs: req.verifyAfter.getTime() - Date.now() };
  const [account] = await db.select().from(mailAccounts).where(eq(mailAccounts.id, req.accountId));
  if (!account) return { status: 'done' };
  if (account.status === 'active' && (!account.lastSyncAt || Date.now() - account.lastSyncAt.getTime() > 30 * 60000)) {
    await syncNow(db, account);
  }
  const [identity] = await db.select().from(senderIdentities).where(eq(senderIdentities.id, req.identityId));
  const graceEnd = new Date(req.submittedAt.getTime() + GRACE_DAYS * 86400000);
  const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(messages)
    .where(and(eq(messages.identityId, req.identityId), gt(messages.receivedAt, graceEnd)));
  const windowDays = (Date.now() - graceEnd.getTime()) / 86400000;
  if (n > 0) {
    await transition(db, req, ['verification_pending'], 'failed', `Still receiving mail: ${n} message(s) arrived after the ${GRACE_DAYS}-day grace period`, { verifiedAt: new Date() });
    return { status: 'done' };
  }
  // Silence only proves something if this sender normally writes often enough.
  const spanDays = Math.max(1, (identity.lastSeenAt.getTime() - identity.firstSeenAt.getTime()) / 86400000);
  const perDay = identity.messageCount / Math.max(spanDays, 30);
  const expected = perDay * windowDays;
  if (account.status !== 'active') {
    await transition(db, req, ['verification_pending'], 'verification_unavailable', 'The account is disconnected, so new mail could not be checked', { verifiedAt: new Date() });
  } else if (expected >= 1.5) {
    await transition(db, req, ['verification_pending'], 'unsubscribed', `No mail for ${Math.round(windowDays)} days after the grace period (about ${expected.toFixed(1)} expected)`, { verifiedAt: new Date() });
    await db.update(senderIdentities).set({ updatedAt: new Date() }).where(eq(senderIdentities.id, identity.id));
  } else {
    await transition(db, req, ['verification_pending'], 'verification_unavailable', `No mail since, but this sender writes too rarely (about ${expected.toFixed(1)} expected) to confirm it`, { verifiedAt: new Date() });
  }
  return { status: 'done' };
}

/** User actions on a request. */
export async function confirmManual(db: DB, req: UnsubRequest, outcome: 'done' | 'failed'): Promise<boolean> {
  if (!['requires_manual_action', 'awaiting_confirmation', 'awaiting_approval'].includes(req.state)) return false;
  if (outcome === 'failed') return transition(db, req, [req.state], 'failed', 'You reported that it did not work', {});
  const from = req.state;
  // Reuse the normal submitted -> verification path.
  await transition(db, req, [from], 'processing', 'You confirmed you finished on the sender\'s page', {});
  await markSubmitted(db, req, 'Completed by you on the sender\'s page');
  return true;
}

export async function cancelRequest(db: DB, req: UnsubRequest): Promise<boolean> {
  return transition(db, req, ['queued', 'awaiting_approval', 'requires_manual_action', 'awaiting_confirmation', 'verification_pending'], 'cancelled', 'Cancelled by you', {});
}

/**
 * Restart recovery: a request left queued/processing whose job has failed or vanished
 * (for example the worker crashed repeatedly) is marked failed instead of hanging forever.
 */
export async function reconcileRequests(db: DB): Promise<number> {
  const res = await db.execute(sql`
    select r.id from unsubscribe_requests r
    where r.state in ('queued', 'processing') and r.updated_at < now() - interval '2 minutes'
      and not exists (
        select 1 from jobs j where j.type = 'unsubscribe' and j.payload->>'requestId' = r.id::text
          and j.status in ('queued', 'running', 'paused'))`);
  const ids = (res as unknown as { rows: { id: string }[] }).rows.map((r) => r.id);
  for (const id of ids) {
    const [req] = await db.select().from(unsubscribeRequests).where(eq(unsubscribeRequests.id, id));
    if (req) await transition(db, req, ['queued', 'processing'], 'failed', `Processing was interrupted${req.lastError ? ` (${req.lastError})` : ''}. The request may or may not have reached the sender; nothing more will be sent unless you retry.`, {});
  }
  // Submitted requests must always be heading for verification.
  const orphans = await db.execute(sql`
    select r.id from unsubscribe_requests r
    where r.state = 'request_submitted' and r.updated_at < now() - interval '2 minutes'`);
  for (const { id } of (orphans as unknown as { rows: { id: string }[] }).rows) {
    const [req] = await db.select().from(unsubscribeRequests).where(eq(unsubscribeRequests.id, id));
    const days = await verificationDays(db, req.userId);
    const verifyAfter = new Date((req.submittedAt ?? new Date()).getTime() + Math.max(days, GRACE_DAYS + 1) * 86400000);
    if (await transition(db, req, ['request_submitted'], 'verification_pending', `Will check for new mail after ${verifyAfter.toISOString().slice(0, 10)}`, { verifyAfter })) {
      await enqueue(db, { type: 'verify', payload: { requestId: req.id }, userId: req.userId, accountId: req.accountId, dedupeKey: `verify:${req.id}`, runAt: verifyAfter, maxAttempts: 6 });
    }
  }
  return ids.length;
}

/** After the send scope is granted, queue the mailto requests that were waiting for it. */
export async function requeueAwaitingApproval(db: DB, accountId: string): Promise<number> {
  const rows = await db.select().from(unsubscribeRequests)
    .where(and(eq(unsubscribeRequests.accountId, accountId), eq(unsubscribeRequests.state, 'awaiting_approval')));
  for (const r of rows) {
    if (await transition(db, r, ['awaiting_approval'], 'queued', 'Send permission granted', {})) {
      await enqueue(db, { type: 'unsubscribe', payload: { requestId: r.id }, userId: r.userId, accountId, dedupeKey: `unsub:${r.id}:${Date.now()}`, maxAttempts: 4 });
    }
  }
  return rows.length;
}
