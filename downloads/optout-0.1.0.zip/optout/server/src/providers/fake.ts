// In-memory mailbox used by the automated tests and, when DEV_FAKE_PROVIDER=true outside
// production, by local development. The UI labels such accounts as fixture data.
import type { MailProvider, MessageMeta, MessagePage, HistoryPage } from './types.ts';
import { HistoryExpiredError, MissingScopeError, RateLimitError } from './types.ts';

export interface FakeMessage extends MessageMeta {}

export class FakeMailbox {
  email: string;
  messages: FakeMessage[] = [];
  /** historyId at which each message was added (index-aligned). */
  addedAt: number[] = [];
  historyId = 1000;
  sent: string[] = [];
  sendScope = false;
  /** Errors thrown by the next sendRaw calls, in order (tests). */
  sendFailures: Error[] = [];
  sendAttempts = 0;
  /** Fail the next N metadata calls with a rate-limit error (tests). */
  rateLimitNext = 0;
  /** Throw after this many metadata calls (simulates a crash mid-scan). */
  crashAfterCalls: number | null = null;
  metadataCalls = 0;
  oldestHistory = 0;

  constructor(email: string) { this.email = email; }

  add(m: Omit<FakeMessage, 'id'> & { id?: string }): FakeMessage {
    this.historyId += 1;
    const msg = { id: m.id ?? `m${this.historyId}`, ...m } as FakeMessage;
    this.messages.unshift(msg); // Gmail lists newest first
    this.addedAt.unshift(this.historyId);
    return msg;
  }
}

const boxes = new Map<string, FakeMailbox>();
export function fakeMailbox(email: string): FakeMailbox {
  let b = boxes.get(email);
  if (!b) { b = new FakeMailbox(email); boxes.set(email, b); }
  return b;
}
export function resetFakeMailboxes(): void { boxes.clear(); }

export class FakeProvider implements MailProvider {
  readonly kind = 'fake' as const;
  private box: FakeMailbox;
  constructor(box: FakeMailbox) { this.box = box; }

  hasSendScope() { return this.box.sendScope; }

  async getProfile() {
    return { email: this.box.email, historyId: String(this.box.historyId), messagesTotal: this.box.messages.length };
  }

  async listMessageIds(pageToken?: string, pageSize = 500): Promise<MessagePage> {
    const start = pageToken ? Number(pageToken) : 0;
    const ids = this.box.messages.slice(start, start + pageSize).map((m) => m.id);
    const next = start + pageSize < this.box.messages.length ? String(start + pageSize) : undefined;
    return { ids, nextPageToken: next, resultSizeEstimate: this.box.messages.length };
  }

  async getMetadata(ids: string[]): Promise<MessageMeta[]> {
    this.box.metadataCalls++;
    if (this.box.crashAfterCalls !== null && this.box.metadataCalls > this.box.crashAfterCalls) {
      this.box.crashAfterCalls = null;
      throw new Error('simulated crash');
    }
    if (this.box.rateLimitNext > 0) { this.box.rateLimitNext--; throw new RateLimitError('fake rate limit', 10); }
    const byId = new Map(this.box.messages.map((m) => [m.id, m]));
    return ids.map((id) => byId.get(id)).filter((m): m is FakeMessage => Boolean(m));
  }

  async listHistory(startHistoryId: string): Promise<HistoryPage> {
    const start = Number(startHistoryId);
    if (start < this.box.oldestHistory) throw new HistoryExpiredError('expired');
    const addedIds = this.box.messages.filter((_m, i) => this.box.addedAt[i] > start).map((m) => m.id);
    return { addedIds, historyId: String(this.box.historyId) };
  }

  async sendRaw(rfc822: string) {
    this.box.sendAttempts++;
    if (!this.box.sendScope) throw new MissingScopeError('send scope not granted');
    const fail = this.box.sendFailures.shift();
    if (fail) throw fail;
    this.box.sent.push(rfc822);
    return { id: `sent${this.box.sent.length}` };
  }
}

interface SeedSender {
  name: string; address: string; listId?: string; perMonth: number; subject: string;
  oneClick?: boolean; mailto?: boolean; http?: boolean; labels?: string[]; precedence?: string;
}

// A realistic mix: marketing lists, multiple lists from one company, transactional and
// security mail from the same domains, and personal mail without list headers.
const SEED: SeedSender[] = [
  { name: 'Northwind Outfitters', address: 'news@northwind-outfitters.example', listId: 'weekly.northwind-outfitters.example', perMonth: 12, subject: 'New arrivals: autumn layers up to 40% off', oneClick: true, mailto: true, labels: ['CATEGORY_PROMOTIONS'] },
  { name: 'Northwind Outfitters', address: 'news@northwind-outfitters.example', listId: 'outlet.northwind-outfitters.example', perMonth: 6, subject: 'Outlet flash sale ends tonight', oneClick: true, labels: ['CATEGORY_PROMOTIONS'] },
  { name: 'Northwind Outfitters', address: 'orders@northwind-outfitters.example', perMonth: 1, subject: 'Your order #48213 has shipped', labels: ['CATEGORY_UPDATES'] },
  { name: 'Tasty Bowl', address: 'hello@tastybowl.example', listId: 'promo.tastybowl.example', perMonth: 8, subject: '2-for-1 ramen this weekend', http: true, labels: ['CATEGORY_PROMOTIONS'] },
  { name: 'SkyHop Airlines', address: 'deals@skyhop.example', listId: 'deals.skyhop.example', perMonth: 10, subject: 'Fares to Lisbon from €49', oneClick: true, labels: ['CATEGORY_PROMOTIONS'] },
  { name: 'SkyHop Airlines', address: 'booking@skyhop.example', perMonth: 1, subject: 'Booking confirmation SK1182', labels: ['CATEGORY_UPDATES'] },
  { name: 'StayWell Hotels', address: 'offers@staywell.example', listId: 'offers.staywell.example', perMonth: 4, subject: 'Members save 15% this winter', mailto: true, labels: ['CATEGORY_PROMOTIONS'] },
  { name: 'Devtools Weekly', address: 'editor@devtoolsweekly.example', listId: 'devtools-weekly.list.example', perMonth: 4, subject: 'Issue 212: faster builds, smaller bundles', oneClick: true, mailto: true },
  { name: 'CloudDesk', address: 'product@clouddesk.example', listId: 'product-updates.clouddesk.example', perMonth: 3, subject: 'What is new in CloudDesk 5.2', oneClick: true, labels: ['CATEGORY_UPDATES'] },
  { name: 'CloudDesk Security', address: 'no-reply@clouddesk.example', perMonth: 2, subject: 'Your verification code is 482913', labels: ['CATEGORY_UPDATES'] },
  { name: 'Chirper', address: 'notify@chirper.example', listId: 'digest.chirper.example', perMonth: 20, subject: 'See what people are talking about', oneClick: true, labels: ['CATEGORY_SOCIAL'] },
  { name: 'First Harbor Bank', address: 'statements@firstharbor.example', perMonth: 1, subject: 'Your monthly statement is ready', labels: ['CATEGORY_UPDATES'] },
  { name: 'First Harbor Bank', address: 'marketing@firstharbor.example', listId: 'offers.firstharbor.example', perMonth: 2, subject: 'Pre-approved: a credit card with 0% intro APR', http: true, labels: ['CATEGORY_PROMOTIONS'] },
  { name: 'Shield Insurance', address: 'policy@shieldins.example', perMonth: 1, subject: 'Your policy renewal documents', labels: ['CATEGORY_UPDATES'] },
  { name: 'The Daily Ledger', address: 'newsletters@dailyledger.example', listId: 'morning.dailyledger.example', perMonth: 30, subject: 'Morning briefing: markets, politics, science', oneClick: true, mailto: true },
  { name: 'StreamFlix', address: 'info@streamflix.example', listId: 'whats-on.streamflix.example', perMonth: 6, subject: 'New this week on StreamFlix', oneClick: true, labels: ['CATEGORY_PROMOTIONS'] },
  { name: 'PixelForge Games', address: 'news@pixelforge.example', listId: 'news.pixelforge.example', perMonth: 5, subject: 'Season 9 is live: new maps and skins', mailto: true, labels: ['CATEGORY_PROMOTIONS'] },
  { name: 'LearnLoop', address: 'courses@learnloop.example', listId: 'courses.learnloop.example', perMonth: 6, subject: 'Your weekly course recommendations', oneClick: true, labels: ['CATEGORY_PROMOTIONS'] },
  { name: 'FitPulse', address: 'coach@fitpulse.example', listId: 'tips.fitpulse.example', perMonth: 8, subject: '5 stretches for desk workers', http: true, labels: ['CATEGORY_PROMOTIONS'] },
  { name: 'City Health Clinic', address: 'appointments@cityhealth.example', perMonth: 1, subject: 'Appointment reminder for Tuesday', labels: ['CATEGORY_UPDATES'] },
  { name: 'AutoMotive Hub', address: 'offers@automotivehub.example', listId: 'offers.automotivehub.example', perMonth: 4, subject: 'Winter tyre deals near you', oneClick: true, labels: ['CATEGORY_PROMOTIONS'] },
  { name: 'HomeFinder', address: 'alerts@homefinder.example', listId: 'alerts.homefinder.example', perMonth: 15, subject: '12 new homes match your search', oneClick: true },
  { name: 'Connectel Mobile', address: 'offers@connectel.example', listId: 'offers.connectel.example', perMonth: 3, subject: 'Upgrade to 5G unlimited', mailto: true, labels: ['CATEGORY_PROMOTIONS'] },
  { name: 'JobScout', address: 'jobs@jobscout.example', listId: 'job-alerts.jobscout.example', perMonth: 20, subject: '8 new jobs for "product designer"', oneClick: true },
  { name: 'Mira Chen', address: 'mira.chen@personal.example', perMonth: 2, subject: 'Re: dinner on Friday?' },
  { name: 'Payly', address: 'receipts@payly.example', perMonth: 4, subject: 'Receipt for your payment to Tasty Bowl', labels: ['CATEGORY_UPDATES'] },
  { name: 'Payly', address: 'security@payly.example', perMonth: 1, subject: 'New sign-in to your account', labels: ['CATEGORY_UPDATES'] },
  { name: 'Gov Tax Office', address: 'noreply@tax.gov.example', perMonth: 1, subject: 'Your tax assessment is available' },
  { name: 'Bargain Bin', address: 'deals@bargainbin.example', perMonth: 9, subject: 'Mega sale!!! 70% off everything', precedence: 'bulk', labels: ['CATEGORY_PROMOTIONS'] },
  { name: 'Community Forum', address: 'digest@forum.example', listId: 'digest.forum.example', perMonth: 4, subject: 'Top posts this week', http: true, labels: ['CATEGORY_FORUMS'] },
];

/** Fills a mailbox with ~9 months of mail from SEED. Deterministic. */
export function seedFixtureMailbox(box: FakeMailbox, now = Date.now()): void {
  if (box.messages.length) return;
  const months = 9;
  const all: Omit<FakeMessage, 'id'>[] = [];
  SEED.forEach((s, si) => {
    const total = s.perMonth * months;
    for (let k = 0; k < total; k++) {
      const age = ((k + 0.37 * si) / total) * months * 30 * 86400000;
      const headers: Record<string, string> = {
        from: `"${s.name}" <${s.address}>`,
        subject: s.subject,
      };
      if (s.listId) headers['list-id'] = `${s.name} <${s.listId}>`;
      const uris: string[] = [];
      const host = s.address.split('@')[1];
      if (s.oneClick || s.http) uris.push(`<https://${host}/u/${encodeURIComponent(s.listId ?? s.address)}?t=fixture>`);
      if (s.mailto) uris.push(`<mailto:unsubscribe@${host}?subject=unsubscribe>`);
      if (uris.length) headers['list-unsubscribe'] = uris.join(', ');
      if (s.oneClick) headers['list-unsubscribe-post'] = 'List-Unsubscribe=One-Click';
      if (s.precedence) headers.precedence = s.precedence;
      all.push({ internalDate: Math.round(now - age), labelIds: ['INBOX', ...(s.labels ?? [])], headers });
    }
  });
  all.sort((a, b) => a.internalDate - b.internalDate);
  for (const m of all) box.add(m);
}
