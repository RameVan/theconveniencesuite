import {
  type MailProvider, type MessageMeta, type MessagePage, type HistoryPage,
  ProviderAuthError, RateLimitError, TransientProviderError, HistoryExpiredError, MissingScopeError,
  METADATA_HEADERS,
} from './types.ts';
import { SCOPES } from './google-oauth.ts';

export interface TokenSource {
  /** Returns a valid access token; force=true refreshes even if not yet expired. */
  get(force?: boolean): Promise<string>;
  scopes(): string[];
}

const API = 'https://gmail.googleapis.com/gmail/v1/users/me';
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** Runs fn over items with at most `limit` in flight. */
async function mapLimit<T, R>(items: T[], limit: number, fn: (t: T) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let i = 0;
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (i < items.length) { const k = i++; out[k] = await fn(items[k]); }
  }));
  return out;
}

export class GmailProvider implements MailProvider {
  readonly kind = 'gmail' as const;
  private tokens: TokenSource;
  private fetchImpl: typeof fetch;
  constructor(tokens: TokenSource, fetchImpl: typeof fetch = fetch) {
    this.tokens = tokens;
    this.fetchImpl = fetchImpl;
  }

  hasSendScope(): boolean { return this.tokens.scopes().includes(SCOPES.send); }

  private async call<T>(path: string, init: RequestInit = {}, attempt = 0, refreshed = false): Promise<T> {
    const token = await this.tokens.get(refreshed);
    let res: Response;
    try {
      res = await this.fetchImpl(`${API}${path}`, {
        ...init,
        headers: { authorization: `Bearer ${token}`, ...(init.body ? { 'content-type': 'application/json' } : {}) },
        signal: AbortSignal.timeout(30000),
      });
    } catch (e) {
      if (attempt < 3) { await sleep(500 * 2 ** attempt); return this.call(path, init, attempt + 1, refreshed); }
      throw new TransientProviderError(`network error: ${(e as Error).message}`);
    }
    if (res.ok) return res.status === 204 ? (undefined as T) : (await res.json() as T);
    const body = await res.json().catch(() => ({})) as { error?: { errors?: { reason?: string }[]; message?: string } };
    const reason = body.error?.errors?.[0]?.reason ?? '';
    if (res.status === 401 && !refreshed) return this.call(path, init, attempt, true);
    if (res.status === 401) throw new ProviderAuthError('Gmail rejected the credentials');
    if (res.status === 404 && path.startsWith('/history')) throw new HistoryExpiredError('history id too old');
    if (res.status === 403 && /insufficient|scope/i.test(`${reason} ${body.error?.message}`)) throw new MissingScopeError('permission not granted');
    const rateLimited = res.status === 429 || (res.status === 403 && /rateLimitExceeded|userRateLimitExceeded/.test(reason));
    if (rateLimited || res.status >= 500) {
      const retryAfter = Number(res.headers.get('retry-after')) * 1000 || 1000 * 2 ** attempt + Math.random() * 500;
      if (attempt < 4) { await sleep(Math.min(retryAfter, 32000)); return this.call(path, init, attempt + 1, refreshed); }
      if (rateLimited) throw new RateLimitError('Gmail rate limit', retryAfter);
      throw new TransientProviderError(`Gmail ${res.status}`);
    }
    if (res.status === 404) return undefined as T;
    throw new Error(`Gmail ${res.status} ${reason}`);
  }

  async getProfile() {
    const p = await this.call<{ emailAddress: string; historyId: string; messagesTotal: number }>('/profile');
    return { email: p.emailAddress.toLowerCase(), historyId: p.historyId, messagesTotal: p.messagesTotal };
  }

  async listMessageIds(pageToken?: string, pageSize = 500): Promise<MessagePage> {
    const q = new URLSearchParams({ maxResults: String(pageSize), includeSpamTrash: 'false' });
    if (pageToken) q.set('pageToken', pageToken);
    const r = await this.call<{ messages?: { id: string }[]; nextPageToken?: string; resultSizeEstimate?: number }>(`/messages?${q}`);
    return { ids: (r.messages ?? []).map((m) => m.id), nextPageToken: r.nextPageToken, resultSizeEstimate: r.resultSizeEstimate };
  }

  async getMetadata(ids: string[]): Promise<MessageMeta[]> {
    const hdrs = METADATA_HEADERS.map((h) => `metadataHeaders=${encodeURIComponent(h)}`).join('&');
    const results = await mapLimit(ids, 8, async (id) => {
      const m = await this.call<{ id: string; internalDate: string; labelIds?: string[]; payload?: { headers?: { name: string; value: string }[] } } | undefined>(
        `/messages/${encodeURIComponent(id)}?format=metadata&${hdrs}`,
      );
      if (!m) return null;
      const headers: Record<string, string> = {};
      for (const h of m.payload?.headers ?? []) {
        const k = h.name.toLowerCase();
        if (!(k in headers)) headers[k] = h.value;
      }
      return { id: m.id, internalDate: Number(m.internalDate), labelIds: m.labelIds ?? [], headers };
    });
    return results.filter((m): m is MessageMeta => m !== null);
  }

  async listHistory(startHistoryId: string, pageToken?: string): Promise<HistoryPage> {
    const q = new URLSearchParams({ startHistoryId, historyTypes: 'messageAdded', maxResults: '500' });
    if (pageToken) q.set('pageToken', pageToken);
    const r = await this.call<{ history?: { messagesAdded?: { message: { id: string } }[] }[]; historyId: string; nextPageToken?: string }>(`/history?${q}`);
    const added = new Set<string>();
    for (const h of r.history ?? []) for (const a of h.messagesAdded ?? []) added.add(a.message.id);
    return { addedIds: [...added], historyId: r.historyId, nextPageToken: r.nextPageToken };
  }

  async sendRaw(rfc822: string): Promise<{ id: string }> {
    if (!this.hasSendScope()) throw new MissingScopeError('gmail.send has not been granted');
    // Sending is not idempotent: no automatic retry here. Callers decide.
    const token = await this.tokens.get();
    const res = await this.fetchImpl(`${API}/messages/send`, {
      method: 'POST',
      headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json' },
      body: JSON.stringify({ raw: Buffer.from(rfc822, 'utf8').toString('base64url') }),
      signal: AbortSignal.timeout(30000),
    });
    if (res.status === 401) throw new ProviderAuthError('Gmail rejected the credentials');
    if (res.status === 403) throw new MissingScopeError('send permission not granted');
    if (res.status === 429) throw new RateLimitError('Gmail send rate limit', 60000);
    if (!res.ok) throw new Error(`Gmail send failed: ${res.status}`);
    return await res.json() as { id: string };
  }
}
