import { config } from '../config.ts';
import { pkceChallenge } from '../lib/crypto.ts';

export const SCOPES = {
  identity: ['openid', 'email', 'profile'],
  // Restricted scope: headers and labels only, never bodies.
  metadata: 'https://www.googleapis.com/auth/gmail.metadata',
  // Sensitive scope: only requested when the user enables mailto unsubscribe.
  send: 'https://www.googleapis.com/auth/gmail.send',
};

export const redirectUri = () => `${config.appOrigin}/auth/google/callback`;

export function authUrl(opts: { state: string; verifier: string; scopes: string[]; loginHint?: string; offline: boolean }): string {
  const p = new URLSearchParams({
    client_id: config.google.clientId,
    redirect_uri: redirectUri(),
    response_type: 'code',
    scope: opts.scopes.join(' '),
    state: opts.state,
    code_challenge: pkceChallenge(opts.verifier),
    code_challenge_method: 'S256',
    include_granted_scopes: 'true',
  });
  if (opts.offline) { p.set('access_type', 'offline'); p.set('prompt', 'consent'); }
  if (opts.loginHint) p.set('login_hint', opts.loginHint);
  return `https://accounts.google.com/o/oauth2/v2/auth?${p}`;
}

export interface TokenResponse {
  access_token: string;
  expires_in: number;
  refresh_token?: string;
  scope: string;
  id_token?: string;
}

async function tokenRequest(body: Record<string, string>): Promise<TokenResponse> {
  const res = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ client_id: config.google.clientId, client_secret: config.google.clientSecret, ...body }),
  });
  const json = await res.json() as TokenResponse & { error?: string; error_description?: string };
  if (!res.ok) {
    const err = new Error(`token endpoint: ${json.error ?? res.status}`) as Error & { oauthError?: string };
    err.oauthError = json.error;
    throw err;
  }
  return json;
}

export const exchangeCode = (code: string, verifier: string) =>
  tokenRequest({ grant_type: 'authorization_code', code, code_verifier: verifier, redirect_uri: redirectUri() });

export const refreshAccessToken = (refreshToken: string) =>
  tokenRequest({ grant_type: 'refresh_token', refresh_token: refreshToken });

export async function revokeToken(token: string): Promise<boolean> {
  try {
    const res = await fetch('https://oauth2.googleapis.com/revoke', {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ token }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

/** Reads the claims of an ID token received directly from Google's token endpoint over TLS. */
export function idTokenClaims(idToken: string): { sub: string; email: string; email_verified?: boolean; name?: string; picture?: string; aud: string; iss: string } {
  const claims = JSON.parse(Buffer.from(idToken.split('.')[1], 'base64url').toString('utf8'));
  if (claims.aud !== config.google.clientId) throw new Error('id_token audience mismatch');
  if (!['accounts.google.com', 'https://accounts.google.com'].includes(claims.iss)) throw new Error('id_token issuer mismatch');
  if (claims.exp * 1000 < Date.now()) throw new Error('id_token expired');
  claims.email_verified = claims.email_verified === true || claims.email_verified === 'true';
  return claims;
}
