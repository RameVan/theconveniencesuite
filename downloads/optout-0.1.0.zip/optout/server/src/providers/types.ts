export interface MessageMeta {
  id: string;
  internalDate: number; // ms since epoch
  labelIds: string[];
  /** Header names lower-cased; first occurrence wins. */
  headers: Record<string, string>;
}

export interface MessagePage { ids: string[]; nextPageToken?: string; resultSizeEstimate?: number }
export interface HistoryPage { addedIds: string[]; historyId: string; nextPageToken?: string }

export interface MailProvider {
  readonly kind: 'gmail' | 'fake';
  getProfile(): Promise<{ email: string; historyId: string; messagesTotal?: number }>;
  listMessageIds(pageToken?: string, pageSize?: number): Promise<MessagePage>;
  /** Metadata for the given ids. Ids that no longer exist are omitted. */
  getMetadata(ids: string[]): Promise<MessageMeta[]>;
  /** Messages added since startHistoryId. Throws HistoryExpiredError when too old. */
  listHistory(startHistoryId: string, pageToken?: string): Promise<HistoryPage>;
  /** Sends an RFC 5322 message. Requires the send scope. */
  sendRaw(rfc822: string): Promise<{ id: string }>;
  hasSendScope(): boolean;
}

export class ProviderAuthError extends Error {}
export class RateLimitError extends Error {
  retryAfterMs: number;
  constructor(msg: string, retryAfterMs: number) { super(msg); this.retryAfterMs = retryAfterMs; }
}
export class TransientProviderError extends Error {}
export class HistoryExpiredError extends Error {}
export class MissingScopeError extends Error {}

/** Headers requested from the provider; nothing else is read. */
export const METADATA_HEADERS = [
  'From', 'Subject', 'Date', 'List-Id', 'List-Unsubscribe', 'List-Unsubscribe-Post',
  'Precedence', 'Auto-Submitted', 'X-Auto-Response-Suppress', 'Feedback-ID', 'Return-Path',
];
