import type { FastifyInstance, FastifyRequest } from 'fastify';
import { and, desc, eq, gt, inArray, isNull, sql } from 'drizzle-orm';
import { z } from 'zod';
import type { DB } from '../db/client.ts';
import {
  apiTokens, categories, jobs, mailAccounts, messages, preferences, senderIdentities, unsubscribeEvents, unsubscribeRequests, users,
} from '../db/schema.ts';
import { config, googleConfigured } from '../config.ts';
import { revokeToken } from '../providers/google-oauth.ts';
import { decrypt } from '../lib/crypto.ts';
import { createApiToken, userForApiToken, type User } from '../modules/auth/users.ts';
import { disconnectAccount } from '../modules/accounts.ts';
import { enqueueScan, type ScanMode } from '../modules/discovery/scan.ts';
import { filterSchema, getSubscription, idsForFilter, listSubscriptions } from '../modules/subscriptions.ts';
import {
  STATE_LABELS, cancelRequest, checkEligibility, confirmManual, createRequests,
} from '../modules/unsubscribe/engine.ts';
import { sessionUser } from './auth.ts';
import { breachOverview, breachesForDomain, enqueueBreachCheck, enqueueCatalogue, forgetLookups } from '../modules/breaches/service.ts';
import { breachChecks, breachHits } from '../db/schema.ts';

declare module 'fastify' {
  interface FastifyRequest { user: User; via: 'web' | 'extension' }
}

class HttpError extends Error {
  status: number;
  constructor(status: number, msg: string) { super(msg); this.status = status; }
}

const uuid = z.string().uuid();
const parse = <T>(schema: z.ZodType<T>, v: unknown): T => {
  const r = schema.safeParse(v);
  if (!r.success) throw new HttpError(400, r.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; '));
  return r.data;
};

export function apiRoutes(app: FastifyInstance, db: DB, onJobQueued: () => void): void {
  app.decorateRequest('user', null as unknown as User);
  app.decorateRequest('via', 'web');

  app.setErrorHandler((err, _req, reply) => {
    if (err instanceof HttpError) return reply.code(err.status).send({ error: err.message });
    const e = err as { statusCode?: number; message: string };
    if (e.statusCode && e.statusCode < 500) return reply.code(e.statusCode).send({ error: e.message });
    app.log.error(err);
    return reply.code(500).send({ error: 'internal error' });
  });

  // Authentication for /api: extension bearer token, or session cookie plus a CSRF header.
  app.addHook('preHandler', async (req: FastifyRequest) => {
    if (!req.url.startsWith('/api/')) return;
    if (req.url.startsWith('/api/public/')) return;
    const auth = req.headers.authorization;
    if (auth?.startsWith('Bearer ')) {
      const u = await userForApiToken(db, auth.slice(7).trim());
      if (!u) throw new HttpError(401, 'invalid token');
      req.user = u;
      req.via = 'extension';
      return;
    }
    const u = await sessionUser(db, req);
    if (!u) throw new HttpError(401, 'not signed in');
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      // Cross-site forms cannot set custom headers; same-origin fetches always do.
      if (req.headers['x-requested-with'] !== 'unsubscriber') throw new HttpError(403, 'missing CSRF header');
      const origin = req.headers.origin;
      const devOrigin = !config.isProd && /^http:\/\/(localhost|127\.0\.0\.1):\d+$/.test(origin ?? '');
      if (origin && origin !== config.appOrigin && !devOrigin) throw new HttpError(403, 'bad origin');
    }
    req.user = u;
    req.via = 'web';
  });

  const prefsFor = async (userId: string) => {
    const [p] = await db.select().from(preferences).where(eq(preferences.userId, userId));
    return p;
  };
  const ownAccount = async (userId: string, id: string) => {
    const [a] = await db.select().from(mailAccounts).where(and(eq(mailAccounts.id, parse(uuid, id)), eq(mailAccounts.userId, userId)));
    if (!a) throw new HttpError(404, 'account not found');
    return a;
  };
  const ownRequest = async (userId: string, id: string) => {
    const [r] = await db.select().from(unsubscribeRequests).where(and(eq(unsubscribeRequests.id, parse(uuid, id)), eq(unsubscribeRequests.userId, userId)));
    if (!r) throw new HttpError(404, 'request not found');
    return r;
  };

  app.get('/api/public/config', async () => ({
    googleConfigured: googleConfigured(),
    devLogin: (config.devFakeProvider || config.isTest) && !config.isProd,
    unsubscribeMode: config.unsubscribeMode,
  }));

  app.get('/api/me', async (req) => ({
    user: { id: req.user.id, email: req.user.email, name: req.user.name, avatarUrl: req.user.avatarUrl },
    preferences: await prefsFor(req.user.id),
    via: req.via,
    unsubscribeMode: config.unsubscribeMode,
    bulkMax: config.bulkMax,
  }));

  // ---------- overview ----------
  app.get('/api/overview', async (req) => {
    const uid = req.user.id;
    const [accts, [counts], [volume], recent, prefs] = await Promise.all([
      db.select({ id: mailAccounts.id, email: mailAccounts.email, status: mailAccounts.status, provider: mailAccounts.provider, lastSyncAt: mailAccounts.lastSyncAt, fullScanCompletedAt: mailAccounts.fullScanCompletedAt }).from(mailAccounts).where(eq(mailAccounts.userId, uid)),
      db.select({
        total: sql<number>`count(*)::int`,
        marketing: sql<number>`count(*) filter (where kind = 'marketing')::int`,
        protected: sql<number>`count(*) filter (where is_protected)::int`,
        unsubscribed: sql<number>`count(*) filter (where unsub_state = 'unsubscribed')::int`,
        inProgress: sql<number>`count(*) filter (where unsub_state in ('queued','processing','request_submitted','verification_pending'))::int`,
        needsAction: sql<number>`count(*) filter (where unsub_state in ('requires_manual_action','awaiting_confirmation','awaiting_approval'))::int`,
      }).from(senderIdentities).where(eq(senderIdentities.userId, uid)),
      db.select({
        last30: sql<number>`count(*) filter (where ${messages.receivedAt} > now() - interval '30 days')::int`,
        marketing30: sql<number>`count(*) filter (where ${messages.receivedAt} > now() - interval '30 days' and ${senderIdentities.kind} = 'marketing')::int`,
      }).from(messages).innerJoin(senderIdentities, eq(senderIdentities.id, messages.identityId)).where(eq(senderIdentities.userId, uid)),
      db.select({ at: unsubscribeEvents.at, toState: unsubscribeEvents.toState, detail: unsubscribeEvents.detail, requestId: unsubscribeEvents.requestId, name: senderIdentities.fromName, address: senderIdentities.fromAddress })
        .from(unsubscribeEvents).innerJoin(unsubscribeRequests, eq(unsubscribeRequests.id, unsubscribeEvents.requestId))
        .innerJoin(senderIdentities, eq(senderIdentities.id, unsubscribeRequests.identityId))
        .where(eq(unsubscribeRequests.userId, uid)).orderBy(desc(unsubscribeEvents.at), desc(unsubscribeEvents.id)).limit(8),
      prefsFor(uid),
    ]);
    const recommended = await listSubscriptions(db, uid, filterSchema.parse({ kind: 'marketing', status: 'none', excludeWhitelisted: true, excludeProtected: true, sort: 'frequency', limit: 6 }), prefs?.mailtoEnabled ?? false);
    return { accounts: accts, counts, volume, recommended: recommended.items, recent: recent.map((r) => ({ ...r, label: STATE_LABELS[r.toState] ?? r.toState })) };
  });

  // ---------- accounts ----------
  app.get('/api/accounts', async (req) => {
    const accts = await db.select().from(mailAccounts).where(eq(mailAccounts.userId, req.user.id)).orderBy(mailAccounts.createdAt);
    const openJobs = accts.length ? await db.select().from(jobs)
      .where(and(eq(jobs.type, 'scan'), inArray(jobs.accountId, accts.map((a) => a.id)), inArray(jobs.status, ['queued', 'running', 'paused']))) : [];
    const lastJobs = accts.length ? await db.execute(sql`
      select distinct on (account_id) account_id, status, progress, last_error, finished_at from jobs
      where type = 'scan' and account_id in (${sql.join(accts.map((a) => sql`${a.id}`), sql`, `)}) and status in ('succeeded','failed','cancelled')
      order by account_id, finished_at desc nulls last`) : { rows: [] };
    const lastBy = new Map((lastJobs as unknown as { rows: { account_id: string }[] }).rows.map((r) => [r.account_id, r]));
    const counts = await db.select({ accountId: senderIdentities.accountId, n: sql<number>`count(*)::int` }).from(senderIdentities)
      .where(eq(senderIdentities.userId, req.user.id)).groupBy(senderIdentities.accountId);
    const countBy = new Map(counts.map((c) => [c.accountId, c.n]));
    return accts.map((a) => ({
      id: a.id, email: a.email, provider: a.provider, status: a.status, statusDetail: a.statusDetail,
      scopes: a.scopes.split(' ').filter(Boolean), canSend: a.scopes.includes('gmail.send'),
      messagesScanned: a.messagesScanned, lastSyncAt: a.lastSyncAt, fullScanCompletedAt: a.fullScanCompletedAt, createdAt: a.createdAt,
      identities: countBy.get(a.id) ?? 0,
      scan: openJobs.find((j) => j.accountId === a.id) ?? null,
      lastScan: lastBy.get(a.id) ?? null,
    }));
  });

  app.post<{ Params: { id: string }; Body: { mode?: ScanMode } }>('/api/accounts/:id/scan', async (req) => {
    const a = await ownAccount(req.user.id, req.params.id);
    if (a.status !== 'active') throw new HttpError(409, 'reconnect this account first');
    const mode = parse(z.enum(['full', 'incremental', 'partial']).default('incremental'), req.body?.mode);
    const { job, created } = await enqueueScan(db, a, mode);
    onJobQueued();
    return { jobId: job.id, created, mode: (job.payload as { mode: string }).mode };
  });

  app.post<{ Params: { id: string }; Body: { action: 'pause' | 'resume' | 'cancel' } }>('/api/accounts/:id/scan-control', async (req) => {
    const a = await ownAccount(req.user.id, req.params.id);
    const action = parse(z.enum(['pause', 'resume', 'cancel']), req.body?.action);
    const from = action === 'resume' ? ['paused'] : ['queued', 'running', 'paused'];
    const to = action === 'pause' ? 'paused' : action === 'resume' ? 'queued' : 'cancelled';
    const r = await db.update(jobs).set({ status: to, updatedAt: new Date(), ...(to === 'cancelled' ? { finishedAt: new Date() } : {}), ...(to === 'queued' ? { runAt: new Date() } : {}) })
      .where(and(eq(jobs.accountId, a.id), eq(jobs.type, 'scan'), inArray(jobs.status, from))).returning({ id: jobs.id });
    onJobQueued();
    return { changed: r.length };
  });

  app.delete<{ Params: { id: string } }>('/api/accounts/:id', async (req) => {
    const a = await ownAccount(req.user.id, req.params.id);
    return disconnectAccount(db, a);
  });

  // ---------- subscriptions ----------
  app.get('/api/subscriptions', async (req) => {
    const f = parse(filterSchema, req.query);
    const prefs = await prefsFor(req.user.id);
    return listSubscriptions(db, req.user.id, f, prefs?.mailtoEnabled ?? false);
  });

  app.get<{ Params: { id: string } }>('/api/subscriptions/:id', async (req) => {
    const prefs = await prefsFor(req.user.id);
    const s = await getSubscription(db, req.user.id, parse(uuid, req.params.id), prefs?.mailtoEnabled ?? false);
    if (!s) throw new HttpError(404, 'not found');
    const reqs = await db.select().from(unsubscribeRequests).where(eq(unsubscribeRequests.identityId, s.id)).orderBy(desc(unsubscribeRequests.createdAt)).limit(10);
    const events = reqs.length ? await db.select().from(unsubscribeEvents).where(inArray(unsubscribeEvents.requestId, reqs.map((r) => r.id))).orderBy(unsubscribeEvents.at, unsubscribeEvents.id) : [];
    const byMonth = await db.execute(sql`select to_char(date_trunc('month', received_at), 'YYYY-MM') as month, count(*)::int as n
      from messages where identity_id = ${s.id} and received_at > now() - interval '12 months' group by 1 order by 1`);
    return {
      ...s,
      breaches: await breachesForDomain(db, s.domain),
      byMonth: (byMonth as unknown as { rows: unknown[] }).rows,
      requests: reqs.map((r) => ({ ...r, label: STATE_LABELS[r.state], events: events.filter((e) => e.requestId === r.id) })),
    };
  });

  const patchSchema = z.object({
    categoryId: uuid.nullable().optional(),
    whitelisted: z.boolean().optional(),
    protected: z.boolean().optional(),
    confirmUnprotect: z.boolean().optional(),
  });
  app.patch<{ Params: { id: string } }>('/api/subscriptions/:id', async (req) => {
    const body = parse(patchSchema, req.body);
    const id = parse(uuid, req.params.id);
    const [cur] = await db.select().from(senderIdentities).where(and(eq(senderIdentities.id, id), eq(senderIdentities.userId, req.user.id)));
    if (!cur) throw new HttpError(404, 'not found');
    const set: Partial<typeof senderIdentities.$inferInsert> = { updatedAt: new Date() };
    if (body.categoryId !== undefined) {
      if (body.categoryId) {
        const [c] = await db.select().from(categories).where(and(eq(categories.id, body.categoryId), eq(categories.userId, req.user.id)));
        if (!c) throw new HttpError(400, 'unknown category');
      }
      set.categoryId = body.categoryId;
      set.categorySource = 'user';
      set.confidence = 1;
    }
    if (body.whitelisted !== undefined) set.whitelisted = body.whitelisted;
    if (body.protected === true) { set.isProtected = true; set.protectionSource = 'user'; set.protectionReason = cur.protectionReason ?? 'Protected by you'; }
    if (body.protected === false) {
      if (cur.isProtected && !body.confirmUnprotect) throw new HttpError(409, 'removing protection needs confirmUnprotect: true');
      set.isProtected = false; set.protectionSource = 'override';
    }
    await db.update(senderIdentities).set(set).where(eq(senderIdentities.id, id));
    return { ok: true };
  });

  // Bulk edits: category, whitelist.
  app.post('/api/subscriptions/bulk', async (req) => {
    const body = parse(z.object({ ids: z.array(uuid).min(1).max(2000), categoryId: uuid.optional(), whitelisted: z.boolean().optional() }), req.body);
    const set: Partial<typeof senderIdentities.$inferInsert> = { updatedAt: new Date() };
    if (body.categoryId) {
      const [c] = await db.select().from(categories).where(and(eq(categories.id, body.categoryId), eq(categories.userId, req.user.id)));
      if (!c) throw new HttpError(400, 'unknown category');
      Object.assign(set, { categoryId: c.id, categorySource: 'user', confidence: 1 });
    }
    if (body.whitelisted !== undefined) set.whitelisted = body.whitelisted;
    const r = await db.update(senderIdentities).set(set).where(and(eq(senderIdentities.userId, req.user.id), inArray(senderIdentities.id, body.ids))).returning({ id: senderIdentities.id });
    return { updated: r.length };
  });

  // ---------- unsubscribe ----------
  const selectionSchema = z.object({
    ids: z.array(uuid).max(5000).optional(),
    filter: filterSchema.partial().omit({ sort: true, order: true, limit: true, offset: true }).optional(),
    allowProtected: z.boolean().optional(),
  });
  const resolveSelection = async (userId: string, s: z.infer<typeof selectionSchema>) => {
    if (s.ids?.length) return s.ids;
    if (s.filter) return idsForFilter(db, userId, s.filter, !s.allowProtected, config.bulkMax);
    throw new HttpError(400, 'select ids or a filter');
  };

  // Confirmation screen data: what will happen to each selected subscription. No writes.
  app.post('/api/unsubscribe/preview', async (req) => {
    const s = parse(selectionSchema, req.body);
    const ids = await resolveSelection(req.user.id, s);
    const prefs = await prefsFor(req.user.id);
    const elig = await checkEligibility(db, req.user.id, ids.slice(0, config.bulkMax + 1), { allowProtected: Boolean(s.allowProtected), mailtoEnabled: prefs?.mailtoEnabled ?? false });
    const rows = elig.length ? await db.select({ id: senderIdentities.id, fromName: senderIdentities.fromName, fromAddress: senderIdentities.fromAddress, domain: senderIdentities.domain, messageCount: senderIdentities.messageCount, isProtected: senderIdentities.isProtected })
      .from(senderIdentities).where(inArray(senderIdentities.id, elig.map((e) => e.id))) : [];
    const info = new Map(rows.map((r) => [r.id, r]));
    const items = elig.map((e) => ({ ...e, ...info.get(e.id) }));
    const methods: Record<string, number> = {};
    for (const e of items) if (e.eligible && e.method) methods[e.method] = (methods[e.method] ?? 0) + 1;
    return {
      total: ids.length, tooMany: ids.length > config.bulkMax, bulkMax: config.bulkMax,
      eligible: items.filter((i) => i.eligible), excluded: items.filter((i) => !i.eligible),
      methods, dryRun: config.unsubscribeMode !== 'live',
    };
  });

  app.post('/api/unsubscribe', async (req) => {
    const s = parse(selectionSchema.extend({ confirm: z.literal(true) }), req.body);
    const ids = await resolveSelection(req.user.id, s);
    if (ids.length > config.bulkMax) throw new HttpError(400, `at most ${config.bulkMax} subscriptions per request`);
    const r = await createRequests(db, req.user.id, ids, { source: req.via, allowProtected: s.allowProtected });
    onJobQueued();
    return r;
  });

  app.get('/api/unsubscribe/requests', async (req) => {
    const q = parse(z.object({
      group: z.enum(['all', 'success', 'pending', 'failed', 'manual']).default('all'),
      limit: z.coerce.number().int().min(1).max(200).default(50),
      offset: z.coerce.number().int().min(0).default(0),
      since: z.string().datetime().optional(),
    }), req.query);
    const groups: Record<string, string[]> = {
      success: ['unsubscribed', 'verification_unavailable'],
      pending: ['queued', 'processing', 'request_submitted', 'verification_pending'],
      failed: ['failed'],
      manual: ['requires_manual_action', 'awaiting_confirmation', 'awaiting_approval'],
    };
    const where = and(
      eq(unsubscribeRequests.userId, req.user.id),
      q.group === 'all' ? undefined : inArray(unsubscribeRequests.state, groups[q.group]),
      q.since ? gt(unsubscribeRequests.updatedAt, new Date(q.since)) : undefined,
    );
    const rows = await db.select({ r: unsubscribeRequests, fromName: senderIdentities.fromName, fromAddress: senderIdentities.fromAddress, domain: senderIdentities.domain, accountEmail: mailAccounts.email })
      .from(unsubscribeRequests)
      .innerJoin(senderIdentities, eq(senderIdentities.id, unsubscribeRequests.identityId))
      .innerJoin(mailAccounts, eq(mailAccounts.id, unsubscribeRequests.accountId))
      .where(where).orderBy(desc(unsubscribeRequests.updatedAt)).limit(q.limit).offset(q.offset);
    const [{ total }] = await db.select({ total: sql<number>`count(*)::int` }).from(unsubscribeRequests).where(where);
    const evs = rows.length ? await db.select().from(unsubscribeEvents).where(inArray(unsubscribeEvents.requestId, rows.map((r) => r.r.id))).orderBy(unsubscribeEvents.at, unsubscribeEvents.id) : [];
    const counts = await db.select({ state: unsubscribeRequests.state, n: sql<number>`count(*)::int` }).from(unsubscribeRequests).where(eq(unsubscribeRequests.userId, req.user.id)).groupBy(unsubscribeRequests.state);
    return {
      total,
      counts: Object.fromEntries(counts.map((c) => [c.state, c.n])),
      items: rows.map(({ r, ...rest }) => ({ ...r, ...rest, label: STATE_LABELS[r.state] ?? r.state, events: evs.filter((e) => e.requestId === r.id) })),
    };
  });

  app.post<{ Params: { id: string } }>('/api/unsubscribe/requests/:id/manual', async (req) => {
    const r = await ownRequest(req.user.id, req.params.id);
    const { outcome } = parse(z.object({ outcome: z.enum(['done', 'failed']) }), req.body);
    if (!(await confirmManual(db, r, outcome))) throw new HttpError(409, `cannot change a request that is ${r.state}`);
    onJobQueued();
    return { ok: true };
  });

  app.post<{ Params: { id: string } }>('/api/unsubscribe/requests/:id/cancel', async (req) => {
    const r = await ownRequest(req.user.id, req.params.id);
    if (!(await cancelRequest(db, r))) throw new HttpError(409, `cannot cancel a request that is ${r.state}`);
    await db.update(jobs).set({ status: 'cancelled', finishedAt: new Date() })
      .where(and(sql`${jobs.payload}->>'requestId' = ${r.id}`, inArray(jobs.status, ['queued', 'paused'])));
    return { ok: true };
  });

  app.post<{ Params: { id: string } }>('/api/unsubscribe/requests/:id/retry', async (req) => {
    const r = await ownRequest(req.user.id, req.params.id);
    if (!['failed', 'cancelled', 'prepared', 'verification_unavailable'].includes(r.state)) throw new HttpError(409, `cannot retry a request that is ${r.state}`);
    const out = await createRequests(db, req.user.id, [r.identityId], { source: req.via, allowProtected: true });
    onJobQueued();
    return out;
  });

  // Pause / resume all pending unsubscribe work for this user.
  app.post('/api/unsubscribe/control', async (req) => {
    const { action } = parse(z.object({ action: z.enum(['pause', 'resume']) }), req.body);
    const r = await db.update(jobs).set({ status: action === 'pause' ? 'paused' : 'queued', updatedAt: new Date(), ...(action === 'resume' ? { runAt: new Date() } : {}) })
      .where(and(eq(jobs.userId, req.user.id), eq(jobs.type, 'unsubscribe'), eq(jobs.status, action === 'pause' ? 'queued' : 'paused'))).returning({ id: jobs.id });
    onJobQueued();
    return { changed: r.length };
  });

  app.get('/api/jobs', async (req) => {
    const rows = await db.select({ id: jobs.id, type: jobs.type, status: jobs.status, progress: jobs.progress, accountId: jobs.accountId, attempts: jobs.attempts, lastError: jobs.lastError, runAt: jobs.runAt, updatedAt: jobs.updatedAt })
      .from(jobs).where(and(eq(jobs.userId, req.user.id), inArray(jobs.status, ['queued', 'running', 'paused']))).orderBy(jobs.runAt).limit(200);
    const summary: Record<string, Record<string, number>> = {};
    for (const j of rows) { summary[j.type] ??= {}; summary[j.type][j.status] = (summary[j.type][j.status] ?? 0) + 1; }
    return { summary, scans: rows.filter((r) => r.type === 'scan') };
  });

  // ---------- categories ----------
  app.get('/api/categories', async (req) => {
    const rows = await db.select({
      id: categories.id, slug: categories.slug, name: categories.name, isSystem: categories.isSystem, isProtected: categories.isProtected,
      // Qualified by hand: without a join Drizzle renders ${categories.id} as a bare "id".
      count: sql<number>`(select count(*) from sender_identities s where s.category_id = "categories"."id")::int`,
    }).from(categories).where(eq(categories.userId, req.user.id)).orderBy(categories.isSystem, categories.name);
    return rows;
  });

  app.post('/api/categories', async (req) => {
    const { name } = parse(z.object({ name: z.string().trim().min(1).max(60) }), req.body);
    const slug = `custom_${name.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '')}_${Date.now().toString(36)}`;
    const [c] = await db.insert(categories).values({ userId: req.user.id, slug, name }).returning();
    return c;
  });

  app.patch<{ Params: { id: string } }>('/api/categories/:id', async (req) => {
    const body = parse(z.object({ name: z.string().trim().min(1).max(60).optional(), isProtected: z.boolean().optional() }), req.body);
    const r = await db.update(categories).set(body).where(and(eq(categories.id, parse(uuid, req.params.id)), eq(categories.userId, req.user.id))).returning();
    if (!r.length) throw new HttpError(404, 'not found');
    await db.update(senderIdentities).set({ updatedAt: new Date() }).where(eq(senderIdentities.categoryId, r[0].id));
    return r[0];
  });

  // Merge: move every subscription into the target, then delete the source (custom only).
  app.post<{ Params: { id: string } }>('/api/categories/:id/merge', async (req) => {
    const { intoId } = parse(z.object({ intoId: uuid }), req.body);
    const fromId = parse(uuid, req.params.id);
    if (fromId === intoId) throw new HttpError(400, 'cannot merge into itself');
    const both = await db.select().from(categories).where(and(eq(categories.userId, req.user.id), inArray(categories.id, [fromId, intoId])));
    const from = both.find((c) => c.id === fromId);
    if (!from || !both.find((c) => c.id === intoId)) throw new HttpError(404, 'not found');
    const moved = await db.update(senderIdentities).set({ categoryId: intoId, categorySource: 'user', updatedAt: new Date() })
      .where(and(eq(senderIdentities.userId, req.user.id), eq(senderIdentities.categoryId, fromId))).returning({ id: senderIdentities.id });
    if (!from.isSystem) await db.delete(categories).where(eq(categories.id, fromId));
    return { moved: moved.length, deletedSource: !from.isSystem };
  });

  app.delete<{ Params: { id: string } }>('/api/categories/:id', async (req) => {
    const id = parse(uuid, req.params.id);
    const [c] = await db.select().from(categories).where(and(eq(categories.id, id), eq(categories.userId, req.user.id)));
    if (!c) throw new HttpError(404, 'not found');
    if (c.isSystem) throw new HttpError(400, 'built-in categories cannot be deleted');
    // Subscriptions return to rule-based classification on the next scan.
    await db.update(senderIdentities).set({ categorySource: 'rule', updatedAt: new Date() }).where(eq(senderIdentities.categoryId, id));
    await db.delete(categories).where(eq(categories.id, id));
    return { ok: true };
  });

  // ---------- preferences ----------
  app.get('/api/preferences', async (req) => prefsFor(req.user.id));
  app.patch('/api/preferences', async (req) => {
    const body = parse(z.object({
      theme: z.enum(['system', 'light', 'dark']).optional(),
      verificationDays: z.number().int().min(3).max(60).optional(),
      mailtoEnabled: z.boolean().optional(),
      scanMaxMessages: z.number().int().min(500).max(200000).optional(),
      breachConsent: z.boolean().optional(),
    }), req.body);
    const [p] = await db.update(preferences).set({ ...body, updatedAt: new Date() }).where(eq(preferences.userId, req.user.id)).returning();
    if (body.breachConsent === true) { await enqueueCatalogue(db); await enqueueBreachCheck(db, req.user.id); onJobQueued(); }
    if (body.breachConsent === false) await forgetLookups(db, req.user.id);
    return p;
  });

  // ---------- breaches ----------
  app.get('/api/breaches', async (req) => breachOverview(db, req.user.id));

  app.post('/api/breaches/check', async (req) => {
    const prefs = await prefsFor(req.user.id);
    if (!prefs?.breachConsent) throw new HttpError(409, 'turn on address checks first');
    await enqueueCatalogue(db);
    const { created } = await enqueueBreachCheck(db, req.user.id);
    onJobQueued();
    return { queued: true, created };
  });

  // The catalogue is public and holds no user data; anyone signed in may refresh it.
  app.post('/api/breaches/refresh-catalogue', async () => {
    const { created } = await enqueueCatalogue(db);
    onJobQueued();
    return { queued: true, created };
  });

  // ---------- sync for the extension ----------
  app.get('/api/changes', async (req) => {
    const { since } = parse(z.object({ since: z.string().datetime() }), req.query);
    const d = new Date(since);
    const [[ids], [reqs]] = await Promise.all([
      db.select({ n: sql<number>`count(*)::int` }).from(senderIdentities).where(and(eq(senderIdentities.userId, req.user.id), gt(senderIdentities.updatedAt, d))),
      db.select({ n: sql<number>`count(*)::int` }).from(unsubscribeRequests).where(and(eq(unsubscribeRequests.userId, req.user.id), gt(unsubscribeRequests.updatedAt, d))),
    ]);
    return { subscriptions: ids.n, requests: reqs.n, now: new Date().toISOString() };
  });

  // ---------- extension tokens ----------
  app.get('/api/extension/tokens', async (req) =>
    db.select({ id: apiTokens.id, label: apiTokens.label, createdAt: apiTokens.createdAt, lastUsedAt: apiTokens.lastUsedAt })
      .from(apiTokens).where(and(eq(apiTokens.userId, req.user.id), isNull(apiTokens.revokedAt))).orderBy(desc(apiTokens.createdAt)));

  app.post('/api/extension/tokens', async (req) => {
    if (req.via !== 'web') throw new HttpError(403, 'link the extension from the web app');
    const { label } = parse(z.object({ label: z.string().max(80).default('Chrome extension') }), req.body ?? {});
    return createApiToken(db, req.user.id, label);
  });

  app.delete<{ Params: { id: string } }>('/api/extension/tokens/:id', async (req) => {
    await db.update(apiTokens).set({ revokedAt: new Date() }).where(and(eq(apiTokens.id, parse(uuid, req.params.id)), eq(apiTokens.userId, req.user.id)));
    return { ok: true };
  });

  // ---------- privacy ----------
  app.get('/api/privacy/export', async (req, reply) => {
    const uid = req.user.id;
    const [accts, ids, reqs, cats, prefs, checks, hits] = await Promise.all([
      db.select({ id: mailAccounts.id, email: mailAccounts.email, provider: mailAccounts.provider, scopes: mailAccounts.scopes, createdAt: mailAccounts.createdAt, lastSyncAt: mailAccounts.lastSyncAt }).from(mailAccounts).where(eq(mailAccounts.userId, uid)),
      db.select().from(senderIdentities).where(eq(senderIdentities.userId, uid)),
      db.select().from(unsubscribeRequests).where(eq(unsubscribeRequests.userId, uid)),
      db.select().from(categories).where(eq(categories.userId, uid)),
      prefsFor(uid),
      db.select().from(breachChecks).where(eq(breachChecks.userId, uid)),
      db.select().from(breachHits).where(eq(breachHits.userId, uid)),
    ]);
    reply.header('content-disposition', 'attachment; filename="opt-out-export.json"');
    return { exportedAt: new Date().toISOString(), user: { email: req.user.email, name: req.user.name, createdAt: req.user.createdAt }, accounts: accts, subscriptions: ids, unsubscribeRequests: reqs, categories: cats, preferences: prefs, breachChecks: checks, breachHits: hits };
  });

  // Full account deletion: revoke every Google token, then delete all rows (cascades).
  app.delete('/api/me', async (req, reply) => {
    parse(z.object({ confirm: z.literal('DELETE') }), req.body);
    const accts = await db.select().from(mailAccounts).where(eq(mailAccounts.userId, req.user.id));
    let revoked = 0;
    for (const a of accts) {
      if (a.provider !== 'gmail') continue;
      const t = a.refreshTokenEnc ? decrypt(a.refreshTokenEnc) : a.accessTokenEnc ? decrypt(a.accessTokenEnc) : null;
      if (t && await revokeToken(t)) revoked++;
    }
    await db.delete(users).where(eq(users.id, req.user.id));
    reply.clearCookie('ux_sid', { path: '/' });
    return { deleted: true, tokensRevoked: revoked, accounts: accts.length };
  });
}
