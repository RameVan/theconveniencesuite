import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { and, eq, lt } from 'drizzle-orm';
import type { DB } from '../db/client.ts';
import { mailAccounts, oauthStates } from '../db/schema.ts';
import { config, googleConfigured } from '../config.ts';
import { encrypt, randomToken } from '../lib/crypto.ts';
import { log, errMsg } from '../lib/log.ts';
import { SCOPES, authUrl, exchangeCode, idTokenClaims } from '../providers/google-oauth.ts';
import { fakeMailbox, seedFixtureMailbox } from '../providers/fake.ts';
import { DEV_FIXTURE_EMAIL, fakeAllowed } from '../modules/accounts.ts';
import { createSession, deleteSession, ensureUser, upsertGoogleUser, userForSession, type User } from '../modules/auth/users.ts';
import { enqueueScan } from '../modules/discovery/scan.ts';
import { requeueAwaitingApproval } from '../modules/unsubscribe/engine.ts';

export const SESSION_COOKIE = 'ux_sid';
// Ties an OAuth round-trip to the browser that started it (blocks login CSRF).
const STATE_COOKIE = 'ux_oauth';

export function setSessionCookie(reply: FastifyReply, token: string): void {
  reply.setCookie(SESSION_COOKIE, token, {
    path: '/', httpOnly: true, sameSite: 'lax', secure: config.appOrigin.startsWith('https://'),
    maxAge: config.sessionDays * 86400,
  });
}

export async function sessionUser(db: DB, req: FastifyRequest): Promise<User | null> {
  const t = req.cookies[SESSION_COOKIE];
  return t ? userForSession(db, t) : null;
}

async function newState(db: DB, reply: FastifyReply, purpose: string, userId: string | null, accountId?: string) {
  const state = randomToken(24);
  reply.setCookie(STATE_COOKIE, state, {
    path: '/auth/google', httpOnly: true, sameSite: 'lax', secure: config.appOrigin.startsWith('https://'), maxAge: 600,
  });
  const verifier = randomToken(48);
  await db.delete(oauthStates).where(lt(oauthStates.expiresAt, new Date()));
  await db.insert(oauthStates).values({ state, purpose, userId, accountId: accountId ?? null, codeVerifier: verifier, expiresAt: new Date(Date.now() + 10 * 60000) });
  return { state, verifier };
}

const back = (reply: FastifyReply, path: string, params: Record<string, string> = {}) =>
  reply.redirect(`${path}${Object.keys(params).length ? `?${new URLSearchParams(params)}` : ''}`);

export function authRoutes(app: FastifyInstance, db: DB, onJobQueued: () => void): void {
  app.get('/auth/google/login', async (_req, reply) => {
    if (!googleConfigured()) return back(reply, '/login', { error: 'google_not_configured' });
    const { state, verifier } = await newState(db, reply, 'login', null);
    return reply.redirect(authUrl({ state, verifier, scopes: SCOPES.identity, offline: false }));
  });

  // Connect a Gmail account: metadata scope only (headers and labels, never bodies).
  app.get<{ Querystring: { hint?: string } }>('/auth/google/connect', async (req, reply) => {
    const user = await sessionUser(db, req);
    if (!user) return back(reply, '/login');
    if (!googleConfigured()) return back(reply, '/accounts', { error: 'google_not_configured' });
    const { state, verifier } = await newState(db, reply, 'connect', user.id);
    return reply.redirect(authUrl({ state, verifier, scopes: [...SCOPES.identity, SCOPES.metadata], offline: true, loginHint: req.query.hint }));
  });

  // Incremental authorisation for mailto unsubscribes.
  app.get<{ Querystring: { accountId: string } }>('/auth/google/send-scope', async (req, reply) => {
    const user = await sessionUser(db, req);
    if (!user) return back(reply, '/login');
    const [acct] = await db.select().from(mailAccounts).where(and(eq(mailAccounts.id, req.query.accountId ?? ''), eq(mailAccounts.userId, user.id)));
    if (!acct || acct.provider !== 'gmail') return back(reply, '/accounts', { error: 'not_found' });
    const { state, verifier } = await newState(db, reply, 'send_scope', user.id, acct.id);
    return reply.redirect(authUrl({ state, verifier, scopes: [...SCOPES.identity, SCOPES.metadata, SCOPES.send], offline: true, loginHint: acct.email }));
  });

  app.get<{ Querystring: { code?: string; state?: string; error?: string } }>('/auth/google/callback', async (req, reply) => {
    const { code, state, error } = req.query;
    const browserState = req.cookies[STATE_COOKIE];
    reply.clearCookie(STATE_COOKIE, { path: '/auth/google' });
    // Single use, unexpired, and started in this same browser.
    const [st] = state ? await db.delete(oauthStates).where(eq(oauthStates.state, state)).returning() : [];
    if (!st || st.expiresAt < new Date() || !browserState || browserState !== state) return back(reply, '/login', { error: 'invalid_state' });
    const dest = st.purpose === 'login' ? '/login' : '/accounts';
    if (error || !code) return back(reply, dest, { error: error ?? 'cancelled' });
    try {
      const tokens = await exchangeCode(code, st.codeVerifier);
      const claims = idTokenClaims(tokens.id_token!);
      if (!claims.email_verified) return back(reply, dest, { error: 'email_not_verified' });

      if (st.purpose === 'login') {
        const user = await upsertGoogleUser(db, { sub: claims.sub, email: claims.email, name: claims.name, picture: claims.picture });
        setSessionCookie(reply, await createSession(db, user.id, req.headers['user-agent']));
        return back(reply, '/');
      }
      const user = st.userId ? (await sessionUser(db, req)) : null;
      if (!user || user.id !== st.userId) return back(reply, '/login', { error: 'session_changed' });
      if (!tokens.scope.split(' ').includes(SCOPES.metadata)) return back(reply, '/accounts', { error: 'metadata_scope_denied' });

      const values = {
        accessTokenEnc: encrypt(tokens.access_token),
        tokenExpiresAt: new Date(Date.now() + tokens.expires_in * 1000),
        scopes: tokens.scope,
        status: 'active',
        statusDetail: null,
        ...(tokens.refresh_token ? { refreshTokenEnc: encrypt(tokens.refresh_token) } : {}),
      };
      // Granting send permission must be for the mailbox the user picked, not another Google account.
      if (st.purpose === 'send_scope') {
        const [target] = await db.select().from(mailAccounts).where(eq(mailAccounts.id, st.accountId ?? ''));
        if (!target || target.email !== claims.email.toLowerCase()) return back(reply, '/accounts', { error: 'wrong_account' });
      }
      const [acct] = await db.insert(mailAccounts).values({ userId: user.id, provider: 'gmail', email: claims.email.toLowerCase(), providerAccountId: claims.sub, ...values })
        .onConflictDoUpdate({ target: [mailAccounts.userId, mailAccounts.email], set: values }).returning();
      if (!acct.refreshTokenEnc) {
        return back(reply, '/accounts', { error: 'no_refresh_token' });
      }
      if (st.purpose === 'send_scope') {
        if (tokens.scope.split(' ').includes(SCOPES.send)) await requeueAwaitingApproval(db, acct.id);
        onJobQueued();
        return back(reply, '/accounts', { connected: acct.id, scope: 'send' });
      }
      await enqueueScan(db, acct, acct.fullScanCompletedAt ? 'incremental' : 'full');
      onJobQueued();
      return back(reply, '/accounts', { connected: acct.id });
    } catch (e) {
      log.error('oauth callback failed', { error: errMsg(e) });
      return back(reply, dest, { error: 'oauth_failed' });
    }
  });

  // Development only: a fixture user and mailbox. Disabled unless DEV_FAKE_PROVIDER=true.
  app.post('/auth/dev-login', async (req, reply) => {
    if (!fakeAllowed() || config.isProd) return reply.code(404).send({ error: 'not found' });
    const user = await ensureUser(db, 'dev@unsubscriber.test', 'Development user');
    const email = DEV_FIXTURE_EMAIL;
    seedFixtureMailbox(fakeMailbox(email));
    const [acct] = await db.insert(mailAccounts).values({ userId: user.id, provider: 'fake', email, scopes: 'fixture' })
      .onConflictDoNothing().returning();
    if (acct) { await enqueueScan(db, acct, 'full'); onJobQueued(); }
    setSessionCookie(reply, await createSession(db, user.id, req.headers['user-agent']));
    return { ok: true };
  });

  app.post('/auth/logout', async (req, reply) => {
    const t = req.cookies[SESSION_COOKIE];
    if (t) await deleteSession(db, t);
    reply.clearCookie(SESSION_COOKIE, { path: '/' });
    return { ok: true };
  });
}
