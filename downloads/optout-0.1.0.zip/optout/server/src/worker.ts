// Standalone worker process (use with EMBEDDED_WORKER=false on the API, and Postgres).
import { openDatabase } from './db/client.ts';
import { createWorker, startMaintenance } from './jobs-runtime.ts';
import { log } from './lib/log.ts';

const { db, close } = await openDatabase();
const worker = createWorker(db);
const stopMaintenance = startMaintenance(db);
worker.start();
log.info('worker process started');

async function shutdown() {
  stopMaintenance();
  await worker.stop();
  await close();
  process.exit(0);
}
process.on('SIGINT', () => void shutdown());
process.on('SIGTERM', () => void shutdown());
