// Worker process for the crash test. Usage: child.ts <seed|resume> <simBase> <count> <mailtoCount>
// Prints "seeded" after creating requests and "settled" when nothing is left to do.
import { eq, inArray, sql } from 'drizzle-orm';
import { config } from '../src/config.ts';
import { openDatabase } from '../src/db/client.ts';
import { mailAccounts, preferences, senderIdentities, unsubscribeRequests } from '../src/db/schema.ts';
import { ensureUser } from '../src/modules/auth/users.ts';
import { ingest } from '../src/modules/discovery/scan.ts';
import { createRequests, setDomainSpacingMs, setUnsubscribeHttpOptions } from '../src/modules/unsubscribe/engine.ts';
import { createWorker } from '../src/jobs-runtime.ts';
import { fakeMailbox } from '../src/providers/fake.ts';

const [mode, simBase, countArg, mailtoArg] = process.argv.slice(2);
const count = Number(countArg);
const mailtos = Number(mailtoArg);
const port = new URL(simBase).port;
const hosts = Array.from({ length: 20 }, (_, i) => `127.0.0.${10 + i}`);
config.unsubscribeMode = 'live';
setUnsubscribeHttpOptions({ allowPrivateHosts: hosts, allowHttp: true, timeoutMs: 3000 });
setDomainSpacingMs(0);

const { db, close } = await openDatabase();
const email = 'crash-box@test.example';
const box = fakeMailbox(email);
box.sendScope = true;
// The in-memory "Gmail" outbox does not survive a kill, so sent mail is reported on stdout.
const realSend = box.sent.push.bind(box.sent);
box.sent.push = (...raw: string[]) => { for (const r of raw) console.log(`SENT ${/^To: (.*)$/m.exec(r)?.[1]}`); return realSend(...raw); };

if (mode === 'seed') {
  const user = await ensureUser(db, 'crash@test.example', 'Crash test');
  await db.update(preferences).set({ mailtoEnabled: true }).where(eq(preferences.userId, user.id));
  const [account] = await db.insert(mailAccounts).values({ userId: user.id, provider: 'fake', email, scopes: 'test' }).returning();
  const metas = Array.from({ length: count + mailtos }, (_, i) => {
    const isMail = i >= count;
    return {
      id: `m${i}`, internalDate: Date.now() - 86400000, labelIds: ['INBOX'],
      headers: {
        from: `<list${i}@co${i}.example>`, subject: 'News', 'list-id': `<l${i}.co${i}.example>`,
        'list-unsubscribe': isMail ? `<mailto:leave${i}@co${i}.example>` : `<http://${hosts[i % hosts.length]}:${port}/b/${i % 3 === 0 ? 'flaky1' : 'delay150'}/l${i}>`,
        ...(isMail ? {} : { 'list-unsubscribe-post': 'List-Unsubscribe=One-Click' }),
      },
    };
  });
  await ingest(db, account, metas);
  await db.update(senderIdentities).set({ oneClick: true }).where(sql`${senderIdentities.unsubHttp} is not null`);
  const ids = (await db.select({ id: senderIdentities.id }).from(senderIdentities)).map((r) => r.id);
  const r = await createRequests(db, user.id, ids, { source: 'web' });
  console.log(`seeded ${r.created.length}`);
}

const worker = createWorker(db, 4);
worker.pollMs = 50;
worker.start();
for (;;) {
  await new Promise((r) => setTimeout(r, 200));
  const [{ open }] = await db.select({ open: sql<number>`count(*)::int` }).from(unsubscribeRequests)
    .where(inArray(unsubscribeRequests.state, ['queued', 'processing']));
  if (open === 0) break;
  // Skip retry back-off so the test finishes quickly.
  await db.execute(sql`update jobs set run_at = now() where type = 'unsubscribe' and status = 'queued' and run_at > now()`);
}
await worker.stop();
await close();
console.log('settled');
process.exit(0);
