// Crash test: runs a live bulk unsubscribe in a child process on an on-disk database, kills
// that process hard three times mid-run, restarts it, and checks the end result.
//   npm run test:crash --workspace server
import { spawn, type ChildProcess } from 'node:child_process';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';

import { startSim } from '../test/sim.ts';

const ONE_CLICK = 120;
const MAILTO = 30;
const KILL_AT = [25, 60, 95]; // kill after this many requests reached the senders
const LEASE_MS = 2000;

const sim = await startSim({ host: '0.0.0.0' });
const dataDir = mkdtempSync(join(tmpdir(), 'unsub-crash-'));
const env = { ...process.env, NODE_ENV: 'test', DATA_DIR: dataDir, DATABASE_URL: '', JOB_LEASE_MS: String(LEASE_MS), DEV_FAKE_PROVIDER: 'false' };
const sent: string[] = [];
const log = (m: string) => console.log(`[crash-test] ${m}`);

function run(mode: 'seed' | 'resume'): { proc: ChildProcess; settled: Promise<boolean>; seeded: Promise<void> } {
  const proc = spawn(process.execPath, ['--disable-warning=ExperimentalWarning', resolve(import.meta.dirname, 'child.ts'), mode, sim.base, String(ONE_CLICK), String(MAILTO)], { env, stdio: ['ignore', 'pipe', 'pipe'] });
  let out = '';
  let resolveSeeded!: () => void;
  const seeded = new Promise<void>((r) => { resolveSeeded = r; });
  proc.stdout!.on('data', (d) => {
    out += d;
    for (const line of String(d).split('\n')) {
      if (line.startsWith('SENT ')) sent.push(line.slice(5).trim());
      if (line.startsWith('seeded')) resolveSeeded();
    }
  });
  proc.stderr!.on('data', (d) => process.stderr.write(`[child] ${d}`));
  const settled = new Promise<boolean>((r) => proc.on('exit', () => r(out.includes('settled'))));
  if (mode === 'resume') resolveSeeded();
  return { proc, settled, seeded };
}

const kill = (p: ChildProcess) => new Promise<void>((r) => {
  if (process.platform === 'win32') spawn('taskkill', ['/pid', String(p.pid), '/T', '/F'], { stdio: 'ignore' }).on('exit', () => r());
  else { p.kill('SIGKILL'); p.on('exit', () => r()); }
});
const until = async (cond: () => boolean, ms: number) => { const end = Date.now() + ms; while (!cond() && Date.now() < end) await new Promise((r) => setTimeout(r, 20)); return cond(); };

let child = run('seed');
await child.seeded;
for (const [i, at] of KILL_AT.entries()) {
  if (!(await until(() => sim.hits.length + sent.length >= at, 60000))) throw new Error(`stalled before kill ${i + 1}`);
  await kill(child.proc);
  log(`kill ${i + 1}: after ${sim.hits.length} sender requests and ${sent.length} emails`);
  // Wait out the lease so the restarted worker may take over the abandoned jobs.
  await new Promise((r) => setTimeout(r, LEASE_MS + 200));
  child = run('resume');
}
const finished = await Promise.race([child.settled, new Promise<boolean>((r) => setTimeout(() => r(false), 120000))]);
if (!finished) { await kill(child.proc); throw new Error('did not settle after the last restart'); }

// ---- Inspect the database the crashed processes left behind ----
process.env.DATA_DIR = dataDir;
process.env.NODE_ENV = 'test';
const { openDatabase } = await import('../src/db/client.ts');
const { unsubscribeRequests, unsubscribeEvents, senderIdentities } = await import('../src/db/schema.ts');
const { db, close } = await openDatabase();
const reqs = await db.select().from(unsubscribeRequests);
const ids = await db.select().from(senderIdentities);
const problems: string[] = [];
const byState = reqs.reduce<Record<string, number>>((m, r) => ({ ...m, [r.state]: (m[r.state] ?? 0) + 1 }), {});

if (reqs.length !== ONE_CLICK + MAILTO) problems.push(`expected ${ONE_CLICK + MAILTO} requests, found ${reqs.length}`);
let repeated = 0;
let missing = 0;
for (let i = 0; i < ONE_CLICK; i++) {
  const posts = sim.hits.filter((h) => h.id === `l${i}` && h.method === 'POST');
  const expected = i % 3 === 0 ? 2 : 1; // flaky1 senders fail once first
  if (posts.length < expected) missing++;
  if (posts.length > expected) repeated += posts.length - expected;
}
const mailSentTwice = new Set(sent.filter((to, i) => sent.indexOf(to) !== i));
for (const r of reqs) {
  const identity = ids.find((i) => i.id === r.identityId)!;
  if (['queued', 'processing'].includes(r.state)) problems.push(`request for ${identity.fromAddress} stuck in ${r.state}`);
  if (identity.unsubState !== r.state) problems.push(`${identity.fromAddress}: identity shows ${identity.unsubState}, request is ${r.state}`);
  if (r.inFlightAt) problems.push(`${identity.fromAddress}: in-flight marker left set`);
}
const mailFailedUnclear = reqs.filter((r) => r.method === 'mailto' && r.state === 'failed').length;
const mailOk = reqs.filter((r) => r.method === 'mailto' && r.state === 'verification_pending').length;
if (missing) problems.push(`${missing} senders never received their unsubscribe request`);
if (mailSentTwice.size) problems.push(`unsubscribe emails sent twice: ${[...mailSentTwice].join(', ')}`);
if (mailOk + mailFailedUnclear !== MAILTO) problems.push(`mailto outcomes don't add up (${mailOk} ok + ${mailFailedUnclear} unclear)`);
const resumedNotes = (await db.select().from(unsubscribeEvents)).filter((e) => e.detail?.includes('interrupted')).length;
// Each kill can leave at most one request per worker slot on the wire.
if (repeated > KILL_AT.length * 4) problems.push(`${repeated} repeated one-click requests, more than ${KILL_AT.length * 4} possible in-flight`);

log(`final states ${JSON.stringify(byState)}`);
log(`one-click: ${sim.hits.length} sender requests; ${repeated} repeated after crashes (harmless, at most ${KILL_AT.length * 4} possible); 0 missing`);
log(`email: ${sent.length} sent, ${mailOk} confirmed, ${mailFailedUnclear} reported "may or may not have been sent", ${mailSentTwice.size} sent twice`);
log(`${resumedNotes} interruption notes recorded in request histories`);
await close();
await sim.close();
rmSync(dataDir, { recursive: true, force: true });
if (problems.length) { log(`FAIL\n  ${problems.join('\n  ')}`); process.exit(1); }
log('PASS');
process.exit(0);
