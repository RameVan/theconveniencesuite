import { test } from 'node:test';
import assert from 'node:assert/strict';
import { eq, sql } from 'drizzle-orm';
import { buildApp } from '../src/app.ts';
import { config } from '../src/config.ts';
import { domainThrottle, jobs, mailAccounts, senderIdentities, users } from '../src/db/schema.ts';
import { createSession, ensureUser } from '../src/modules/auth/users.ts';
import { enqueueScan } from '../src/modules/discovery/scan.ts';
import { seedFixtureMailbox, fakeMailbox } from '../src/providers/fake.ts';
import { setup } from './helpers.ts';

config.unsubscribeMode = 'dry_run';

async function world() {
  const t = await setup();
  seedFixtureMailbox(t.box);
  await enqueueScan(t.db, t.account, 'full');
  await t.worker.drain();
  const app = await buildApp(t.db);
  const cookie = `ux_sid=${await createSession(t.db, t.user.id)}`;
  const web = (method: 'GET' | 'POST' | 'PATCH' | 'DELETE', url: string, payload?: unknown) =>
    app.inject({ method, url, payload: payload as never, headers: { cookie, 'x-requested-with': 'unsubscriber' } });
  return { ...t, app, cookie, web };
}

test('API requires authentication and a CSRF header for cookie writes', async () => {
  const w = await world();
  assert.equal((await w.app.inject({ method: 'GET', url: '/api/subscriptions' })).statusCode, 401);
  assert.equal((await w.app.inject({ method: 'GET', url: '/api/subscriptions', headers: { authorization: 'Bearer nope' } })).statusCode, 401);
  const noCsrf = await w.app.inject({ method: 'PATCH', url: '/api/preferences', payload: { theme: 'dark' }, headers: { cookie: w.cookie } });
  assert.equal(noCsrf.statusCode, 403);
  const badOrigin = await w.app.inject({ method: 'PATCH', url: '/api/preferences', payload: { theme: 'dark' }, headers: { cookie: w.cookie, 'x-requested-with': 'unsubscriber', origin: 'https://evil.example' } });
  assert.equal(badOrigin.statusCode, 403);
  assert.equal((await w.web('PATCH', '/api/preferences', { theme: 'dark' })).statusCode, 200);
  assert.equal((await w.app.inject({ method: 'GET', url: '/api/public/config' })).statusCode, 200);
  await w.close();
});

test('subscriptions list: search, filters, sorting and pagination', async () => {
  const w = await world();
  const all = (await w.web('GET', '/api/subscriptions?limit=500')).json();
  assert.equal(all.total, 30);
  const search = (await w.web('GET', '/api/subscriptions?search=northwind')).json();
  assert.equal(search.total, 3);
  const oneClick = (await w.web('GET', '/api/subscriptions?method=one_click&limit=500')).json();
  assert.ok(oneClick.items.every((i: { method: string }) => i.method === 'one_click'));
  const byFreq = (await w.web('GET', '/api/subscriptions?sort=frequency&limit=3')).json();
  assert.equal(byFreq.items[0].fromName, 'The Daily Ledger');
  assert.ok(byFreq.items[0].perMonth >= byFreq.items[1].perMonth);
  const recent = (await w.web('GET', '/api/subscriptions?sort=recent&order=desc&limit=500')).json();
  const dates = recent.items.map((i: { lastSeenAt: string }) => Date.parse(i.lastSeenAt));
  assert.deepEqual(dates, [...dates].sort((a, b) => b - a));
  const page2 = (await w.web('GET', '/api/subscriptions?limit=10&offset=10')).json();
  assert.equal(page2.items.length, 10);
  const noProtected = (await w.web('GET', '/api/subscriptions?excludeProtected=true&limit=500')).json();
  assert.ok(noProtected.items.every((i: { isProtected: boolean }) => !i.isProtected));
  assert.ok(noProtected.total < all.total);
  await w.close();
});

test('users can never see or act on another user\'s data', async () => {
  const w = await world();
  const other = await ensureUser(w.db, 'other@test.example', 'Other');
  const otherCookie = `ux_sid=${await createSession(w.db, other.id)}`;
  const mine = (await w.web('GET', '/api/subscriptions?limit=1')).json().items[0];
  const as = (method: 'GET' | 'POST' | 'PATCH', url: string, payload?: unknown) =>
    w.app.inject({ method, url, payload: payload as never, headers: { cookie: otherCookie, 'x-requested-with': 'unsubscriber' } });
  assert.equal((await as('GET', '/api/subscriptions')).json().total, 0);
  assert.equal((await as('GET', `/api/subscriptions/${mine.id}`)).statusCode, 404);
  assert.equal((await as('PATCH', `/api/subscriptions/${mine.id}`, { whitelisted: true })).statusCode, 404);
  const u = (await as('POST', '/api/unsubscribe', { ids: [mine.id], confirm: true })).json();
  assert.equal(u.created.length, 0);
  assert.equal((await as('POST', `/api/accounts/${w.account.id}/scan`, {})).statusCode, 404);
  await w.close();
});

test('extension token: actions in the extension show up in the web app', async () => {
  const w = await world();
  // Tokens can only be minted from a web session.
  const tok = (await w.web('POST', '/api/extension/tokens', { label: 'Test Chrome' })).json();
  assert.match(tok.token, /^uxt_/);
  const ext = (method: 'GET' | 'POST' | 'PATCH', url: string, payload?: unknown) =>
    w.app.inject({ method, url, payload: payload as never, headers: { authorization: `Bearer ${tok.token}` } });
  assert.equal((await ext('POST', '/api/extension/tokens', {})).statusCode, 403);

  const target = (await ext('GET', '/api/subscriptions?search=chirper')).json().items[0];
  const since = new Date(Date.now() - 1000).toISOString();
  const r = (await ext('POST', '/api/unsubscribe', { ids: [target.id], confirm: true })).json();
  assert.equal(r.created.length, 1);
  // The web app sees the same request, marked as coming from the extension.
  const hist = (await w.web('GET', '/api/unsubscribe/requests')).json();
  assert.equal(hist.items[0].identityId, target.id);
  assert.equal(hist.items[0].source, 'extension');
  const sub = (await w.web('GET', `/api/subscriptions/${target.id}`)).json();
  assert.equal(sub.unsubState, 'queued');
  // And the web app cannot start a duplicate.
  const dup = (await w.web('POST', '/api/unsubscribe', { ids: [target.id], confirm: true })).json();
  assert.equal(dup.created.length, 0);
  assert.equal(dup.skipped[0].reason, 'already in progress');
  // Change feed for polling clients.
  const changes = (await ext('GET', `/api/changes?since=${encodeURIComponent(since)}`)).json();
  assert.ok(changes.requests >= 1 && changes.subscriptions >= 1);
  // Whitelisting from the web is visible to the extension.
  await w.web('PATCH', `/api/subscriptions/${target.id}`, { whitelisted: true });
  assert.equal((await ext('GET', `/api/subscriptions/${target.id}`)).json().whitelisted, true);
  // Revoked tokens stop working.
  await w.web('DELETE', `/api/extension/tokens/${tok.id}`);
  assert.equal((await ext('GET', '/api/me')).statusCode, 401);
  await w.close();
});

test('bulk unsubscribe: preview excludes protected mail; execute needs explicit confirm', async () => {
  const w = await world();
  const prev = (await w.web('POST', '/api/unsubscribe/preview', { filter: { kind: 'marketing' } })).json();
  assert.ok(prev.eligible.length >= 15);
  assert.equal(prev.dryRun, true);
  const allIds = (await w.web('GET', '/api/subscriptions?limit=500')).json().items.map((i: { id: string }) => i.id);
  const prevAll = (await w.web('POST', '/api/unsubscribe/preview', { ids: allIds })).json();
  const reasons = prevAll.excluded.map((e: { reason: string }) => e.reason);
  for (const r of ['Banking statement', 'Password reset', 'Authentication email', 'Government correspondence'].filter((x) => x !== 'Password reset'))
    assert.ok(reasons.some((x: string) => x === r), `excluded: ${r}`);
  assert.equal((await w.web('POST', '/api/unsubscribe', { filter: { kind: 'marketing' } })).statusCode, 400, 'confirm: true is required');
  const run = (await w.web('POST', '/api/unsubscribe', { filter: { kind: 'marketing' }, confirm: true })).json();
  assert.equal(run.created.length, prev.eligible.length);
  await w.worker.drain();
  // Lists that share an unsubscribe host are spaced out; skip ahead past the spacing window.
  await w.db.delete(domainThrottle);
  await w.db.update(jobs).set({ runAt: new Date() }).where(eq(jobs.status, 'queued'));
  await w.worker.drain();
  const hist = (await w.web('GET', '/api/unsubscribe/requests?limit=200')).json();
  // Dry run: nothing claims success.
  assert.ok(hist.items.every((i: { state: string }) => ['prepared', 'requires_manual_action'].includes(i.state)), JSON.stringify(hist.counts));
  // Protected mail was never touched.
  const prot = await w.db.select().from(senderIdentities).where(eq(senderIdentities.isProtected, true));
  assert.ok(prot.length >= 8);
  assert.ok(prot.every((p) => p.unsubState === null));
  await w.close();
});

test('removing protection needs a second confirmation', async () => {
  const w = await world();
  const [bank] = await w.db.select().from(senderIdentities).where(sql`${senderIdentities.fromAddress} like 'statements@%'`);
  assert.equal((await w.web('PATCH', `/api/subscriptions/${bank.id}`, { protected: false })).statusCode, 409);
  assert.equal((await w.web('PATCH', `/api/subscriptions/${bank.id}`, { protected: false, confirmUnprotect: true })).statusCode, 200);
  const [after] = await w.db.select().from(senderIdentities).where(eq(senderIdentities.id, bank.id));
  assert.equal(after.isProtected, false);
  assert.equal(after.protectionSource, 'override');
  await w.close();
});

test('categories: create, assign, protect, merge', async () => {
  const w = await world();
  const cats = (await w.web('GET', '/api/categories')).json();
  assert.ok(cats.length >= 20);
  assert.equal(cats.reduce((s: number, c: { count: number }) => s + c.count, 0), 30, 'category counts cover every sender');
  assert.ok(cats.find((c: { slug: string }) => c.slug === 'transport').count >= 1);
  const mine = (await w.web('POST', '/api/categories', { name: 'Side projects' })).json();
  const ids = (await w.web('GET', '/api/subscriptions?search=devtools')).json().items.map((i: { id: string }) => i.id);
  assert.equal((await w.web('POST', '/api/subscriptions/bulk', { ids, categoryId: mine.id })).json().updated, ids.length);
  await w.web('PATCH', `/api/categories/${mine.id}`, { isProtected: true });
  const prev = (await w.web('POST', '/api/unsubscribe/preview', { ids })).json();
  assert.match(prev.excluded[0].reason, /protected category: Side projects/);
  const tech = cats.find((c: { slug: string }) => c.slug === 'technology');
  const merged = (await w.web('POST', `/api/categories/${mine.id}/merge`, { intoId: tech.id })).json();
  assert.equal(merged.moved, ids.length);
  assert.equal(merged.deletedSource, true);
  assert.equal((await w.web('GET', `/api/subscriptions/${ids[0]}`)).json().categorySlug, 'technology');
  await w.close();
});

test('scan controls: pause, resume and cancel', async () => {
  const w = await world();
  await w.web('POST', `/api/accounts/${w.account.id}/scan`, { mode: 'incremental' });
  assert.equal((await w.web('POST', `/api/accounts/${w.account.id}/scan-control`, { action: 'pause' })).json().changed, 1);
  assert.equal(await w.worker.drain(), 0, 'paused jobs are not run');
  assert.equal((await w.web('POST', `/api/accounts/${w.account.id}/scan-control`, { action: 'resume' })).json().changed, 1);
  assert.equal(await w.worker.drain(), 1);
  const accts = (await w.web('GET', '/api/accounts')).json();
  assert.equal(accts[0].scan, null);
  assert.equal(accts[0].lastScan.status, 'succeeded');
  await w.close();
});

test('multiple accounts are kept apart and filterable', async () => {
  const w = await world();
  const email2 = `second-${Date.now()}@test.example`;
  const [a2] = await w.db.insert(mailAccounts).values({ userId: w.user.id, provider: 'fake', email: email2, scopes: 'test' }).returning();
  seedFixtureMailbox(fakeMailbox(email2));
  await enqueueScan(w.db, a2, 'full');
  await w.worker.drain();
  assert.equal((await w.web('GET', '/api/subscriptions')).json().total, 60);
  assert.equal((await w.web('GET', `/api/subscriptions?accountId=${a2.id}`)).json().total, 30);
  // Disconnecting one account removes only its data.
  assert.equal((await w.web('DELETE', `/api/accounts/${a2.id}`)).statusCode, 200);
  assert.equal((await w.web('GET', '/api/subscriptions')).json().total, 30);
  await w.close();
});

test('privacy: export and full account deletion', async () => {
  const w = await world();
  const exp = (await w.web('GET', '/api/privacy/export')).json();
  assert.equal(exp.subscriptions.length, 30);
  assert.ok(!JSON.stringify(exp).includes('accessTokenEnc'));
  assert.equal((await w.web('DELETE', '/api/me', { confirm: 'nope' })).statusCode, 400);
  const del = (await w.web('DELETE', '/api/me', { confirm: 'DELETE' })).json();
  assert.equal(del.deleted, true);
  assert.equal((await w.db.select().from(users).where(eq(users.id, w.user.id))).length, 0);
  const [{ n }] = await w.db.select({ n: sql<number>`count(*)::int` }).from(senderIdentities);
  assert.equal(n, 0, 'all derived data is gone');
  assert.equal((await w.web('GET', '/api/me')).statusCode, 401);
  await w.close();
});
