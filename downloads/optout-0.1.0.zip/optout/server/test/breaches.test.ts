import { test } from 'node:test';
import assert from 'node:assert/strict';
import { eq, sql } from 'drizzle-orm';
import { buildApp } from '../src/app.ts';
import { breachChecks, breachHits, domainThrottle, jobs, preferences } from '../src/db/schema.ts';
import { createSession, ensureUser } from '../src/modules/auth/users.ts';
import { enqueueScan } from '../src/modules/discovery/scan.ts';
import { LiveHibpClient, XposedOrNotClient, titleFromId, HibpAuthError, HibpRateLimitError, hibpClient, setHibpClient, type HibpBreach, type HibpClient } from '../src/modules/breaches/hibp.ts';
import { config } from '../src/config.ts';
import { breachOverview, enqueueBreachCheck, enqueueCatalogue, plainText } from '../src/modules/breaches/service.ts';
import { setup, addSender } from './helpers.ts';

const breach = (Name: string, Domain: string, BreachDate = '2023-01-01', DataClasses = ['Email addresses', 'Passwords'], extra: Partial<HibpBreach> = {}): HibpBreach => ({
  Name, Title: Name, Domain, BreachDate, AddedDate: `${BreachDate}T00:00:00Z`, PwnCount: 1000,
  Description: `<p>${Name} was <a href="https://x.example">breached</a> &amp; leaked.</p>`, DataClasses,
  IsVerified: true, IsSensitive: false, IsSpamList: false, IsFabricated: false, ...extra,
});

class StubHibp implements HibpClient {
  readonly source = 'hibp' as const;
  readonly provider = { name: 'Stub', url: 'https://stub.example', host: 'stub.example', attribution: 'test' };
  readonly lookupSpacingMs = 6500;
  catalogue: HibpBreach[] = [];
  perAccount = new Map<string, HibpBreach[]>();
  lookups: string[] = [];
  key = true;
  rateLimitNext = 0;
  canLookupAccounts() { return this.key; }
  async allBreaches() { return this.catalogue; }
  async breachesForAccount(email: string) {
    if (this.rateLimitNext > 0) { this.rateLimitNext--; throw new HibpRateLimitError(2000); }
    this.lookups.push(email);
    return this.perAccount.get(email) ?? [];
  }
}

async function world() {
  const t = await setup();
  const hibp = new StubHibp();
  setHibpClient(hibp);
  addSender(t.box, { from: 'news@mail.shop.example', listId: 'news.shop.example', count: 10, unsub: '<https://shop.example/u>' });
  addSender(t.box, { from: 'hi@safe.example', count: 5 });
  await enqueueScan(t.db, t.account, 'full');
  await t.worker.drain();
  hibp.catalogue = [
    breach('ShopBreach', 'shop.example', '2024-02-02'),
    breach('Unrelated', 'other.example'),
    breach('SensitiveSite', 'shop.example', '2020-01-01', ['Email addresses'], { IsSensitive: true }),
  ];
  return { ...t, hibp };
}

const drainAll = async (t: Awaited<ReturnType<typeof world>>) => {
  for (let i = 0; i < 10; i++) {
    await t.db.delete(domainThrottle);
    await t.db.update(jobs).set({ runAt: new Date() }).where(eq(jobs.status, 'queued'));
    if (!(await t.worker.drain())) break;
  }
};

test('HIBP client: headers, encoding, not-found, rate limit and bad key', async () => {
  const calls: { url: string; headers: Record<string, string> }[] = [];
  const respond = (status: number, body: unknown, headers: Record<string, string> = {}) => new Response(status === 404 ? null : JSON.stringify(body), { status, headers });
  let next: Response = respond(200, [breach('A', 'a.example')]);
  const fetchImpl = (async (url: string, init: { headers: Record<string, string> }) => { calls.push({ url, headers: init.headers }); return next; }) as unknown as typeof fetch;
  const c = new LiveHibpClient('k3y', fetchImpl);
  assert.equal((await c.breachesForAccount('a+b@x.example')).length, 1);
  assert.equal(calls[0].url, 'https://haveibeenpwned.com/api/v3/breachedaccount/a%2Bb%40x.example?truncateResponse=false');
  assert.equal(calls[0].headers['hibp-api-key'], 'k3y');
  assert.ok(calls[0].headers['user-agent']);
  next = respond(404, null);
  assert.deepEqual(await c.breachesForAccount('clean@x.example'), []);
  next = respond(429, {}, { 'retry-after': '3' });
  await assert.rejects(c.breachesForAccount('x@x.example'), (e) => e instanceof HibpRateLimitError && e.retryAfterMs === 3000);
  next = respond(401, {});
  await assert.rejects(c.breachesForAccount('x@x.example'), HibpAuthError);
  // The public catalogue is fetched without the key.
  next = respond(200, [breach('A', 'a.example')]);
  await c.allBreaches();
  assert.equal(calls.at(-1)!.headers['hibp-api-key'], undefined);
  // No key: lookups are refused locally, nothing is sent.
  const n = calls.length;
  await assert.rejects(new LiveHibpClient('', fetchImpl).breachesForAccount('x@x.example'), HibpAuthError);
  assert.equal(calls.length, n);
});

test('XposedOrNot client (free): maps the catalogue and resolves address results to full breaches', async () => {
  const calls: string[] = [];
  const catalogue = { exposedBreaches: [
    { breachID: 'GlendaleCommunityCollege', breachedDate: '2020-05-01T00:00:00+00:00', addedDate: '2021-01-01T00:00:00+00:00', domain: 'glendale.edu', logo: 'https://xposedornot.com/static/logos/G.png', sensitive: false, verified: true, exposedData: ['Email addresses', 'Passwords'], exposedRecords: 1200, exposureDescription: 'Glendale leak.' },
    { breachID: 'Adobe', breachedDate: '2013-10-01T00:00:00+00:00', addedDate: '2023-11-08T00:00:00+00:00', domain: 'adobe.com', sensitive: false, verified: true, exposedData: ['Passwords'], exposedRecords: 152000000, exposureDescription: 'Adobe leak.' },
  ] };
  let lookup: { status: number; body: unknown } = { status: 200, body: { breaches: [['Adobe', 'UnknownNewBreach']] } };
  const fetchImpl = (async (url: string, init: { headers: Record<string, string> }) => {
    calls.push(url);
    assert.ok(init.headers['user-agent']);
    assert.equal(init.headers['hibp-api-key'], undefined, 'no key is sent');
    if (url.endsWith('/breaches')) return new Response(JSON.stringify(catalogue), { status: 200 });
    return new Response(JSON.stringify(lookup.body), { status: lookup.status });
  }) as unknown as typeof fetch;
  const c = new XposedOrNotClient(fetchImpl);
  assert.equal(c.canLookupAccounts(), true, 'free: works without a key');
  const all = await c.allBreaches();
  assert.equal(all[0].Title, 'Glendale Community College');
  assert.equal(all[0].BreachDate, '2020-05-01');
  assert.equal(all[0].PwnCount, 1200);
  const found = await c.breachesForAccount('a+b@x.example');
  assert.equal(calls.find((u) => u.includes('check-email')), 'https://api.xposedornot.com/v1/check-email/a%2Bb%40x.example');
  assert.deepEqual(found.map((b) => b.Name), ['Adobe', 'UnknownNewBreach']);
  assert.equal(found[0].Domain, 'adobe.com', 'details filled from the catalogue');
  assert.equal(found[1].Title, 'Unknown New Breach', 'unknown names still reported');
  assert.equal(titleFromId('SoundCloud'), 'SoundCloud', 'brand names stay whole');
  assert.equal(calls.filter((u) => u.endsWith('/breaches')).length, 1, 'catalogue cached');
  lookup = { status: 404, body: { Error: 'Not found' } };
  assert.deepEqual(await c.breachesForAccount('clean@x.example'), []);
  lookup = { status: 200, body: { Error: 'Not found', email: null } };
  assert.deepEqual(await c.breachesForAccount('clean@x.example'), []);
  lookup = { status: 429, body: {} };
  await assert.rejects(c.breachesForAccount('x@x.example'), HibpRateLimitError);
});

test('provider choice: free XposedOrNot unless an HIBP key is configured', () => {
  setHibpClient(null);
  const saved = { key: config.hibpApiKey, provider: config.breachProvider };
  config.hibpApiKey = '';
  config.breachProvider = 'auto';
  assert.equal(hibpClient().source, 'xposedornot');
  config.hibpApiKey = 'k';
  assert.equal(hibpClient().source, 'hibp');
  config.breachProvider = 'xposedornot';
  assert.equal(hibpClient().source, 'xposedornot');
  config.hibpApiKey = saved.key;
  config.breachProvider = saved.provider;
});

test('descriptions are reduced to plain text', () => {
  assert.equal(plainText('<p>Big <a href="https://x">leak</a> &amp; more&nbsp;data</p>'), 'Big leak & more data');
  assert.equal(plainText('<script>alert(1)</script>ok'), 'alert(1)ok');
});

test('companies that email you are matched against the catalogue without sending any user data', async () => {
  const t = await world();
  await enqueueCatalogue(t.db);
  await drainAll(t);
  const o = await breachOverview(t.db, t.user.id);
  assert.equal(o.catalogue.count, 3);
  assert.deepEqual(o.senderBreaches.map((s) => s.breach.name), ['ShopBreach'], 'subdomain matched; sensitive breach hidden');
  assert.equal(o.senderBreaches[0].senders[0].fromAddress, 'news@mail.shop.example');
  assert.equal(o.senderBreaches[0].breach.description, 'ShopBreach was breached & leaked.');
  assert.equal(t.hibp.lookups.length, 0, 'no per-address lookups without consent');
  assert.equal(o.consent, false);
  assert.ok(o.accounts.every((a) => a.breaches.length === 0));
  await t.close();
});

test('address lookups need consent, store hits, and are forgotten when consent is withdrawn', async () => {
  const t = await world();
  const app = await buildApp(t.db);
  const cookie = `ux_sid=${await createSession(t.db, t.user.id)}`;
  const web = (method: 'GET' | 'POST' | 'PATCH', url: string, payload?: unknown) => app.inject({ method, url, payload: payload as never, headers: { cookie, 'x-requested-with': 'unsubscriber' } });
  t.hibp.perAccount.set(t.account.email, [breach('ShopBreach', 'shop.example', '2024-02-02')]);

  assert.equal((await web('POST', '/api/breaches/check')).statusCode, 409, 'refused without consent');
  await enqueueBreachCheck(t.db, t.user.id);
  await drainAll(t);
  assert.equal(t.hibp.lookups.length, 0, 'a queued check does nothing without consent');

  assert.equal((await web('PATCH', '/api/preferences', { breachConsent: true })).statusCode, 200);
  await drainAll(t);
  assert.deepEqual([...t.hibp.lookups].sort(), [t.account.email, t.user.email].sort(), 'sign-in address and mailbox both checked');
  const o = (await web('GET', '/api/breaches')).json();
  const box = o.accounts.find((a: { email: string }) => a.email === t.account.email);
  assert.equal(box.status, 'ok');
  assert.equal(box.breaches[0].breach.name, 'ShopBreach');
  assert.deepEqual(box.breaches[0].breach.dataClasses, ['Email addresses', 'Passwords']);
  assert.equal(box.breaches[0].senders.length, 1, 'linked to the sender that emails you');
  assert.equal(o.accounts.find((a: { email: string }) => a.email === t.user.email).breaches.length, 0);

  // A breach that disappears from the lookup is removed; firstSeenAt of others is kept.
  const [before] = await t.db.select().from(breachHits).where(eq(breachHits.email, t.account.email));
  t.hibp.perAccount.set(t.account.email, [breach('ShopBreach', 'shop.example', '2024-02-02'), breach('Unrelated', 'other.example')]);
  await web('POST', '/api/breaches/check');
  await drainAll(t);
  const after = await t.db.select().from(breachHits).where(eq(breachHits.email, t.account.email));
  assert.equal(after.length, 2);
  assert.equal(after.find((h) => h.breachName === 'ShopBreach')!.firstSeenAt.getTime(), before.firstSeenAt.getTime());

  // Withdrawing consent deletes everything learned from lookups.
  await web('PATCH', '/api/preferences', { breachConsent: false });
  const [{ n }] = await t.db.select({ n: sql<number>`count(*)::int` }).from(breachHits);
  assert.equal(n, 0);
  assert.equal((await t.db.select().from(breachChecks)).length, 0);
  assert.ok((await web('GET', '/api/breaches')).json().accounts.every((a: { breaches: unknown[] }) => a.breaches.length === 0));
  await t.close();
});

test('lookups respect rate limits and resume without repeating finished addresses', async () => {
  const t = await world();
  await t.db.update(preferences).set({ breachConsent: true }).where(eq(preferences.userId, t.user.id));
  t.hibp.rateLimitNext = 1;
  await enqueueBreachCheck(t.db, t.user.id);
  await t.worker.drain();
  const [j] = await t.db.select().from(jobs).where(eq(jobs.type, 'breach-check'));
  assert.equal(j.status, 'queued');
  assert.equal(j.attempts, 0, 'rate limit does not use up attempts');
  await drainAll(t);
  assert.equal(t.hibp.lookups.length, 2, 'each address looked up exactly once');
  await t.close();
});

test('lookups are spaced for HIBP\'s per-minute limit', async () => {
  const t = await world();
  await t.db.update(preferences).set({ breachConsent: true }).where(eq(preferences.userId, t.user.id));
  await enqueueBreachCheck(t.db, t.user.id);
  await t.worker.drain();
  assert.equal(t.hibp.lookups.length, 1, 'second address waits for the spacing window');
  const [j] = await t.db.select().from(jobs).where(eq(jobs.type, 'breach-check'));
  assert.ok(j.runAt.getTime() > Date.now() + 3000);
  await t.close();
});

test('no API key: catalogue still works, lookups are skipped and reported as unavailable', async () => {
  const t = await world();
  t.hibp.key = false;
  await t.db.update(preferences).set({ breachConsent: true }).where(eq(preferences.userId, t.user.id));
  await enqueueCatalogue(t.db);
  await enqueueBreachCheck(t.db, t.user.id);
  await drainAll(t);
  const o = await breachOverview(t.db, t.user.id);
  assert.equal(o.lookupAvailable, false);
  assert.equal(t.hibp.lookups.length, 0);
  assert.equal(o.senderBreaches.length, 1);
  await t.close();
});

test('breach data is private to each user and shown on the subscription', async () => {
  const t = await world();
  await t.db.update(preferences).set({ breachConsent: true }).where(eq(preferences.userId, t.user.id));
  t.hibp.perAccount.set(t.account.email, [breach('ShopBreach', 'shop.example')]);
  await enqueueCatalogue(t.db);
  await enqueueBreachCheck(t.db, t.user.id);
  await drainAll(t);
  const app = await buildApp(t.db);
  const other = await ensureUser(t.db, `other-${Date.now()}@test.example`, 'Other');
  const otherCookie = `ux_sid=${await createSession(t.db, other.id)}`;
  const o = (await app.inject({ method: 'GET', url: '/api/breaches', headers: { cookie: otherCookie } })).json();
  assert.equal(o.senderBreaches.length, 0);
  assert.ok(o.accounts.every((a: { breaches: unknown[] }) => a.breaches.length === 0));
  assert.ok(!JSON.stringify(o).includes(t.account.email));

  const cookie = `ux_sid=${await createSession(t.db, t.user.id)}`;
  const list = (await app.inject({ method: 'GET', url: '/api/subscriptions?search=shop', headers: { cookie } })).json();
  const detail = (await app.inject({ method: 'GET', url: `/api/subscriptions/${list.items[0].id}`, headers: { cookie } })).json();
  assert.deepEqual(detail.breaches.map((b: { name: string }) => b.name), ['ShopBreach']);
  setHibpClient(null);
  await t.close();
});
