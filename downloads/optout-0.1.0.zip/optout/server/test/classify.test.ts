import { test } from 'node:test';
import assert from 'node:assert/strict';
import { classify, messageSignals, addSignals, type ClassifyInput } from '../src/modules/classify/rules.ts';

function identity(o: { from: string; name?: string; listId?: string; subjects: string[]; unsub?: boolean; labels?: string[] }): ClassifyInput {
  const domain = o.from.split('@')[1];
  let signals: Record<string, number> = {};
  for (const subject of o.subjects) {
    signals = addSignals(signals, messageSignals({
      subject, labelIds: o.labels ?? [], headers: {}, hasUnsub: Boolean(o.unsub), hasListId: Boolean(o.listId), fromAddress: o.from, domain,
    }));
  }
  return { fromAddress: o.from, fromName: o.name ?? null, domain, listId: o.listId ?? null, lastSubject: o.subjects.at(-1)!, signals, hasUnsubMethod: Boolean(o.unsub) };
}

test('protected communications are detected per identity', () => {
  const cases: [ClassifyInput, string][] = [
    [identity({ from: 'statements@bank.example', name: 'Bank', subjects: ['Your monthly statement is ready', 'Your monthly statement is ready'] }), 'Banking statement'],
    [identity({ from: 'no-reply@app.example', subjects: ['Reset your password', 'Password reset requested'] }), 'Password reset'],
    [identity({ from: 'no-reply@app.example', subjects: ['Your verification code is 123456'] }), 'Authentication email'],
    [identity({ from: 'security@mail.example', subjects: ['New sign-in from Chrome on Windows'] }), 'Security notification'],
    [identity({ from: 'orders@shop.example', subjects: ['Your order #123 has shipped', 'Order confirmation #124'] }), 'Order confirmation'],
    [identity({ from: 'info@carrier.example', subjects: ['Out for delivery today', 'Your parcel has been delivered'] }), 'Shipping notification'],
    [identity({ from: 'booking@air.example', subjects: ['Booking confirmation AB123', 'Your boarding pass'] }), 'Booking confirmation'],
    [identity({ from: 'receipts@pay.example', subjects: ['Receipt for your payment', 'Payment received'] }), 'Payment confirmation'],
    [identity({ from: 'appointments@clinic.example', subjects: ['Appointment reminder'] }), 'Medical communication'],
    [identity({ from: 'policy@ins.example', subjects: ['Your policy renewal documents'] }), 'Insurance correspondence'],
    [identity({ from: 'noreply@tax.gov.example', subjects: ['A message for you'] }), 'Government correspondence'],
  ];
  for (const [input, reason] of cases) {
    const c = classify(input);
    assert.equal(c.protectedReason !== null, true, `${input.fromAddress}: expected protected`);
    if (reason !== 'Shipping notification' && reason !== 'Order confirmation') assert.equal(c.protectedReason, reason, input.fromAddress);
    assert.equal(c.kind, 'transactional');
  }
});

test('a marketing list mentioning orders is not protected', () => {
  const c = classify(identity({
    from: 'news@shop.example', name: 'Shop', listId: 'weekly.shop.example', unsub: true, labels: ['CATEGORY_PROMOTIONS'],
    subjects: ['Order now: 30% off', 'New arrivals this week', 'Last chance for free shipping', 'Weekend sale', 'Fresh picks for you'],
  }));
  assert.equal(c.protectedReason, null);
  assert.equal(c.kind, 'marketing');
  assert.equal(c.category, 'shopping');
});

test('categories come from sender metadata', () => {
  const expect: [ClassifyInput, string][] = [
    [identity({ from: 'deals@skyhop.example', name: 'SkyHop Airlines', listId: 'deals.skyhop.example', unsub: true, subjects: ['Fares to Lisbon'] }), 'transport'],
    [identity({ from: 'hello@pizzaplace.example', name: 'Pizza Place', unsub: true, subjects: ['2-for-1 tonight'] }), 'food'],
    [identity({ from: 'jobs@jobscout.example', name: 'JobScout', listId: 'jobs.jobscout.example', unsub: true, subjects: ['8 new jobs for you'] }), 'jobs'],
    [identity({ from: 'news@pixelforge.example', name: 'PixelForge Games', unsub: true, subjects: ['Season 9 is live'] }), 'gaming'],
    [identity({ from: 'newsletters@dailyledger.example', name: 'The Daily Ledger', unsub: true, subjects: ['Morning briefing'] }), 'news'],
    [identity({ from: 'info@streamflix.example', name: 'StreamFlix', unsub: true, subjects: ['New this week'] }), 'entertainment'],
  ];
  for (const [input, cat] of expect) assert.equal(classify(input).category, cat, input.fromAddress);
});

test('unknown marketing falls back with low confidence; personal mail is personal', () => {
  const m = classify(identity({ from: 'x@qzv.example', listId: 'l.qzv.example', unsub: true, labels: ['CATEGORY_PROMOTIONS'], subjects: ['Hello'] }));
  assert.equal(m.category, 'other_marketing');
  assert.ok(m.confidence < 0.5);
  const p = classify(identity({ from: 'mira@personal.example', name: 'Mira Chen', subjects: ['Re: dinner on Friday?'] }));
  assert.equal(p.kind, 'personal');
  assert.equal(p.protectedReason, null);
});

test('confidence is bounded', () => {
  const c = classify(identity({ from: 'deals@shop-store-outlet.example', name: 'Shop Store Outlet Mall', unsub: true, subjects: ['shop shop'] }));
  assert.ok(c.confidence > 0.5 && c.confidence <= 0.95);
});
