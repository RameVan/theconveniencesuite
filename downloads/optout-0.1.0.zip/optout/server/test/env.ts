// Loaded before every test file.
process.env.NODE_ENV = 'test';
process.env.DEV_FAKE_PROVIDER = 'false';
process.env.DATABASE_URL = '';
