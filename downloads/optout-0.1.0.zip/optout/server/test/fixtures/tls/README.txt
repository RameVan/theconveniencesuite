Test-only TLS material for the simulated unsubscribe sender. Never used outside tests.
