// List-Unsubscribe headers in the shapes the large sending platforms use, odd-but-real
// variants, and a fuzz pass over the parsers.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { parseListUnsubscribe, parseMailto, parseFrom, parseListId, decodeWords } from '../src/lib/headers.ts';
import { planMethod } from '../src/modules/unsubscribe/engine.ts';

const ONE = 'List-Unsubscribe=One-Click';
type Case = { name: string; header: string; post?: string; http: string | null; mailto: string | null; oneClick: boolean };

const CASES: Case[] = [
  { name: 'Mailchimp', post: ONE,
    header: '<https://example.us1.list-manage.com/unsubscribe?u=abc123&id=def456&e=ghi789&c=jkl000>, <mailto:unsubscribe-mc.us1_abc123.def456-ghi789@mailchimpapp.net?subject=unsubscribe>',
    http: 'https://example.us1.list-manage.com/unsubscribe?u=abc123&id=def456&e=ghi789&c=jkl000', mailto: 'mailto:unsubscribe-mc.us1_abc123.def456-ghi789@mailchimpapp.net?subject=unsubscribe', oneClick: true },
  { name: 'SendGrid (mailto first)', post: ONE,
    header: '<mailto:unsubscribe@sendgrid.net?subject=Unsubscribe&body=1234>,<https://u123.ct.sendgrid.net/lu/unsubscribe?oc=abc&d=xyz>',
    http: 'https://u123.ct.sendgrid.net/lu/unsubscribe?oc=abc&d=xyz', mailto: 'mailto:unsubscribe@sendgrid.net?subject=Unsubscribe&body=1234', oneClick: true },
  { name: 'Klaviyo', post: ONE,
    header: '<https://manage.kmail-lists.com/subscriptions/unsubscribe?a=Xy1&c=01H&k=abc&m=01J&r=8z>, <mailto:unsubscribe+01J@unsubscribe.klaviyomail.com>',
    http: 'https://manage.kmail-lists.com/subscriptions/unsubscribe?a=Xy1&c=01H&k=abc&m=01J&r=8z', mailto: 'mailto:unsubscribe+01J@unsubscribe.klaviyomail.com', oneClick: true },
  { name: 'Amazon SES (mailto only)', header: '<mailto:01000189abc-unsubscribe@amazonses.com>',
    http: null, mailto: 'mailto:01000189abc-unsubscribe@amazonses.com', oneClick: false },
  { name: 'Salesforce Marketing Cloud', post: ONE,
    header: '<mailto:leave-fd8a1c7-fe6a@news.brand.example>, <https://click.news.brand.example/subscription_center.aspx?jwt=eyJhbGciOi.eyJzdWIiOi.SflKxw>',
    http: 'https://click.news.brand.example/subscription_center.aspx?jwt=eyJhbGciOi.eyJzdWIiOi.SflKxw', mailto: 'mailto:leave-fd8a1c7-fe6a@news.brand.example', oneClick: true },
  { name: 'HubSpot without one-click',
    header: '<mailto:1abc@bounce.hubspotemail.net?subject=unsubscribe>, <https://hs-123.s.hubspotemail.net/hs/manage-preferences/unsubscribe-all?languagePreference=en&d=V>',
    http: 'https://hs-123.s.hubspotemail.net/hs/manage-preferences/unsubscribe-all?languagePreference=en&d=V', mailto: 'mailto:1abc@bounce.hubspotemail.net?subject=unsubscribe', oneClick: false },
  { name: 'folded across lines', post: ONE,
    header: '<https://x.example/unsub?id=1>,\r\n\t<mailto:u@x.example>',
    http: 'https://x.example/unsub?id=1', mailto: 'mailto:u@x.example', oneClick: true },
  { name: 'URI split by folding whitespace', post: ONE,
    header: '<https://x.example/unsub?id=1234\r\n 5678>',
    http: 'https://x.example/unsub?id=12345678', mailto: null, oneClick: true },
  { name: 'uppercase scheme', post: ONE, header: '<HTTPS://X.EXAMPLE/U>', http: 'HTTPS://X.EXAMPLE/U', mailto: null, oneClick: true },
  { name: 'comment after URIs', header: '<mailto:a@x.example> (to leave this list)', http: null, mailto: 'mailto:a@x.example', oneClick: false },
  { name: 'post value with spacing and case', post: '  list-unsubscribe = one-click ', header: '<https://x.example/u>', http: 'https://x.example/u', mailto: null, oneClick: true },
  { name: 'wrong post value', post: 'List-Unsubscribe=Yes', header: '<https://x.example/u>', http: 'https://x.example/u', mailto: null, oneClick: false },
  { name: 'post header but only mailto', post: ONE, header: '<mailto:a@x.example>', http: null, mailto: 'mailto:a@x.example', oneClick: false },
  { name: 'post header but http (not https)', post: ONE, header: '<http://x.example/u>', http: 'http://x.example/u', mailto: null, oneClick: false },
  { name: 'http first, https second: prefer https for one-click', post: ONE,
    header: '<http://track.x.example/u?id=1>, <https://x.example/u?id=1>', http: 'https://x.example/u?id=1', mailto: null, oneClick: true },
  { name: 'bare URI without angle brackets (non-compliant but common)', post: ONE,
    header: 'https://x.example/unsub?id=9', http: 'https://x.example/unsub?id=9', mailto: null, oneClick: true },
  { name: 'bare mailto without brackets', header: 'mailto:leave@x.example', http: null, mailto: 'mailto:leave@x.example', oneClick: false },
  { name: 'unsupported schemes ignored', header: '<ftp://x.example/u>, <javascript:alert(1)>', http: null, mailto: null, oneClick: false },
  { name: 'empty', header: '', http: null, mailto: null, oneClick: false },
];

for (const c of CASES) {
  test(`List-Unsubscribe: ${c.name}`, () => {
    const r = parseListUnsubscribe(c.header, c.post);
    assert.deepEqual(r, { http: c.http, mailto: c.mailto, oneClick: c.oneClick });
  });
}

test('method priority follows the spec: one-click, then mailto (if enabled), then web, then manual', () => {
  const p = (h: string, post?: string, mailtoEnabled = false) => {
    const u = parseListUnsubscribe(h, post);
    return planMethod({ oneClick: u.oneClick, unsubHttp: u.http, unsubMailto: u.mailto }, mailtoEnabled).method;
  };
  assert.equal(p(CASES[0].header, ONE), 'one_click');
  assert.equal(p(CASES[5].header), 'web', 'HubSpot without one-click, email disabled -> web page');
  assert.equal(p(CASES[5].header, undefined, true), 'mailto', 'with email unsubscribes enabled -> mailto');
  assert.equal(p(CASES[3].header), 'mailto', 'mailto-only senders use mailto (it then asks for permission)');
  assert.equal(p(''), 'manual');
  assert.equal(p('<http://x.example/u>', ONE), 'web', 'plain http is never one-click');
});

test('mailto variants', () => {
  assert.deepEqual(parseMailto('mailto:unsubscribe%40x.example?subject=Unsubscribe%20me&body=Please%20remove'), { to: 'unsubscribe@x.example', subject: 'Unsubscribe me', body: 'Please remove' });
  assert.deepEqual(parseMailto('MAILTO:Leave+123@X.example'), { to: 'Leave+123@X.example', subject: 'unsubscribe', body: 'unsubscribe' });
  assert.equal(parseMailto('mailto:a@x.example;b@y.example'), null, 'multiple recipients refused');
  assert.equal(parseMailto('mailto:a@x.example,b@y.example'), null);
  assert.equal(parseMailto('mailto:?to=a@x.example'), null, 'hfields-only form is not used');
  assert.equal(parseMailto('mailto:not-an-address'), null);
  assert.equal(parseMailto('mailto:%E0%A4%A'), null, 'malformed percent-encoding');
  const inj = parseMailto('mailto:a@x.example?subject=x%0D%0ABcc%3A%20victim%40evil.example&body=y%0AFrom%3A%20boss');
  assert.ok(inj && !/[\r\n]/.test(inj.subject) && !/[\r\n]/.test(inj.body), 'no header injection');
  assert.ok(parseMailto(`mailto:a@x.example?subject=${'s'.repeat(5000)}`)!.subject.length <= 300);
});

// Deterministic pseudo-random generator so failures are reproducible.
function rng(seed: number) { return () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff); }
const ALPHABET = 'abcxyzABC019<>,:;@?=&%+-_./ \t\r\n"()\\[]=?QB';

test('fuzz: parsers never throw and keep their guarantees (20,000 inputs)', () => {
  const r = rng(42);
  const str = (max: number) => Array.from({ length: Math.floor(r() * max) }, () => ALPHABET[Math.floor(r() * ALPHABET.length)]).join('');
  const prefixes = ['<https://', '<http://', '<mailto:', 'https://', 'mailto:', '=?utf-8?B?', '=?iso-8859-1?Q?', ''];
  for (let i = 0; i < 20000; i++) {
    const header = prefixes[i % prefixes.length] + str(120) + (r() < 0.5 ? '>' : '');
    const post = r() < 0.5 ? ONE : str(30);
    const u = parseListUnsubscribe(header, post);
    if (u.oneClick) assert.match(u.http!, /^https:\/\//i, header);
    if (u.mailto) assert.match(u.mailto, /^mailto:/i);
    const m = u.mailto ? parseMailto(u.mailto) : parseMailto(`mailto:${str(40)}`);
    if (m) {
      assert.match(m.to, /^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+$/);
      assert.ok(!/[\r\n]/.test(m.subject + m.body));
    }
    const f = parseFrom(str(80));
    if (f) assert.ok(f.address.includes('@') && f.domain.length > 0);
    parseListId(str(60));
    decodeWords(prefixes[(i + 3) % prefixes.length] + str(50) + '?=');
  }
});

test('pathological sizes do not hang the parser', () => {
  const start = Date.now();
  parseListUnsubscribe('<'.repeat(50000) + 'https://x.example/u' + '>'.repeat(50000), ONE);
  parseListUnsubscribe(Array.from({ length: 2000 }, (_, i) => `<https://x${i}.example/u>`).join(', '), ONE);
  parseFrom(`${'"a'.repeat(20000)} <a@x.example>`);
  decodeWords('=?utf-8?B?' + 'QUFB'.repeat(20000) + '?=');
  assert.ok(Date.now() - start < 2000, `took ${Date.now() - start} ms`);
});
