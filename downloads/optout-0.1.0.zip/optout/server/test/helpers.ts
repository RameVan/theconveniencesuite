import { createServer, type IncomingMessage, type Server } from 'node:http';
import type { AddressInfo } from 'node:net';
import { openDatabase } from '../src/db/client.ts';
import { mailAccounts } from '../src/db/schema.ts';
import { ensureUser } from '../src/modules/auth/users.ts';
import { fakeMailbox, type FakeMailbox } from '../src/providers/fake.ts';
import { createWorker } from '../src/jobs-runtime.ts';
import { setUnsubscribeHttpOptions } from '../src/modules/unsubscribe/engine.ts';

let n = 0;

export async function setup() {
  const { db, close } = await openDatabase({ memory: true });
  const id = `${process.pid}-${++n}`;
  const user = await ensureUser(db, `user-${id}@test.example`, 'Test user');
  const email = `box-${id}@test.example`;
  const box = fakeMailbox(email);
  const [account] = await db.insert(mailAccounts).values({ userId: user.id, provider: 'fake', email, scopes: 'test' }).returning();
  const worker = createWorker(db, 1);
  setUnsubscribeHttpOptions({ allowPrivate: true, allowHttp: true, timeoutMs: 3000 });
  return { db, close, user, account, box, worker };
}

export async function addAccount(db: Awaited<ReturnType<typeof setup>>['db'], userId: string, email: string) {
  const [account] = await db.insert(mailAccounts).values({ userId, provider: 'fake', email, scopes: 'test' }).returning();
  return { account, box: fakeMailbox(email) };
}

const DAY = 86400000;

/** Adds `count` messages from one sender, spread over `days` days ending `endDaysAgo` ago. */
export function addSender(box: FakeMailbox, o: {
  from: string; name?: string; listId?: string; subject?: string; count: number; days?: number; endDaysAgo?: number;
  unsub?: string; oneClick?: boolean; labels?: string[];
}): void {
  const days = o.days ?? 90;
  for (let i = 0; i < o.count; i++) {
    const headers: Record<string, string> = { from: `"${o.name ?? o.from}" <${o.from}>`, subject: o.subject ?? 'Weekly news' };
    if (o.listId) headers['list-id'] = `<${o.listId}>`;
    if (o.unsub) headers['list-unsubscribe'] = o.unsub;
    if (o.oneClick) headers['list-unsubscribe-post'] = 'List-Unsubscribe=One-Click';
    const t = Date.now() - (o.endDaysAgo ?? 0) * DAY - ((o.count - i) / o.count) * days * DAY;
    box.add({ internalDate: Math.round(t), labelIds: ['INBOX', ...(o.labels ?? [])], headers });
  }
}

export interface Hit { method: string; url: string; body: string; headers: IncomingMessage['headers'] }

/** Local sender endpoint: records every request and answers with `respond`. */
export async function senderServer(respond: (h: Hit, n: number) => { status: number; body?: string; headers?: Record<string, string> }) {
  const hits: Hit[] = [];
  const server: Server = createServer((req, res) => {
    let body = '';
    req.on('data', (c) => { body += c; });
    req.on('end', () => {
      const h = { method: req.method!, url: req.url!, body, headers: req.headers };
      hits.push(h);
      const r = respond(h, hits.length);
      res.writeHead(r.status, r.headers ?? { 'content-type': 'text/plain' });
      res.end(r.body ?? 'ok');
    });
  });
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  return { hits, base, close: () => new Promise<void>((r) => server.close(() => r())) };
}
