// Google OAuth and the Gmail REST client, end to end against a simulated Google that enforces
// the protocol: single-use codes, PKCE, client secret, redirect URI, refresh and revocation.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createHash, randomBytes } from 'node:crypto';
import { eq } from 'drizzle-orm';
import { buildApp } from '../src/app.ts';
import { config } from '../src/config.ts';
import { jobs, mailAccounts, oauthStates, senderIdentities, unsubscribeRequests, users } from '../src/db/schema.ts';
import { openDatabase } from '../src/db/client.ts';
import { decrypt, encrypt } from '../src/lib/crypto.ts';
import { getProvider } from '../src/modules/accounts.ts';
import { createWorker } from '../src/jobs-runtime.ts';
import { FakeMailbox } from '../src/providers/fake.ts';
import { HistoryExpiredError, MissingScopeError, ProviderAuthError } from '../src/providers/types.ts';
import { SCOPES } from '../src/providers/google-oauth.ts';
import { addSender } from './helpers.ts';

const CLIENT_ID = 'test-client.apps.googleusercontent.com';
const CLIENT_SECRET = 'test-secret';
const REDIRECT = 'http://localhost:8790/auth/google/callback';

// ---------------- simulated Google ----------------
interface Person { sub: string; email: string; name: string; verified?: boolean }
interface Grant { person: Person; scopes: string[]; challenge: string; redirect: string; used: boolean }
const google = {
  codes: new Map<string, Grant>(),
  refresh: new Map<string, { person: Person; scopes: string[] }>(),
  access: new Map<string, { person: Person; scopes: string[]; exp: number }>(),
  revoked: [] as string[],
  calls: [] as { url: string; body?: string; auth?: string }[],
  mailboxes: new Map<string, FakeMailbox>(),
  issueRefreshToken: true,
  audOverride: null as string | null,
  accessTtl: 3600,
};

/** Plays the user's part on Google's consent screen. Returns the code the browser brings back. */
function consent(authUrl: string, person: Person, opts: { deny?: string[] } = {}): { code: string; state: string } {
  const u = new URL(authUrl);
  assert.equal(u.origin + u.pathname, 'https://accounts.google.com/o/oauth2/v2/auth');
  assert.equal(u.searchParams.get('client_id'), CLIENT_ID);
  assert.equal(u.searchParams.get('redirect_uri'), REDIRECT);
  assert.equal(u.searchParams.get('response_type'), 'code');
  assert.equal(u.searchParams.get('code_challenge_method'), 'S256');
  const scopes = u.searchParams.get('scope')!.split(' ').filter((s) => !opts.deny?.includes(s));
  const code = `code-${randomBytes(6).toString('hex')}`;
  google.codes.set(code, { person, scopes, challenge: u.searchParams.get('code_challenge')!, redirect: u.searchParams.get('redirect_uri')!, used: false });
  return { code, state: u.searchParams.get('state')! };
}

const jwt = (claims: object) => `${Buffer.from('{"alg":"RS256"}').toString('base64url')}.${Buffer.from(JSON.stringify(claims)).toString('base64url')}.sig`;
const json = (status: number, body: unknown, headers: Record<string, string> = {}) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json', ...headers } });

function tokenEndpoint(body: URLSearchParams): Response {
  if (body.get('client_id') !== CLIENT_ID || body.get('client_secret') !== CLIENT_SECRET) return json(401, { error: 'invalid_client' });
  const issue = (person: Person, scopes: string[], withRefresh: boolean) => {
    const access = `ya29.${randomBytes(8).toString('hex')}`;
    google.access.set(access, { person, scopes, exp: Date.now() + google.accessTtl * 1000 });
    const out: Record<string, unknown> = { access_token: access, expires_in: google.accessTtl, scope: scopes.join(' '), token_type: 'Bearer' };
    if (withRefresh) { const r = `1//rt-${randomBytes(8).toString('hex')}`; google.refresh.set(r, { person, scopes }); out.refresh_token = r; }
    out.id_token = jwt({ iss: 'https://accounts.google.com', aud: google.audOverride ?? CLIENT_ID, sub: person.sub, email: person.email, email_verified: person.verified ?? true, name: person.name, exp: Math.floor(Date.now() / 1000) + 3600 });
    return out;
  };
  if (body.get('grant_type') === 'authorization_code') {
    const g = google.codes.get(body.get('code') ?? '');
    if (!g || g.used) return json(400, { error: 'invalid_grant' });
    g.used = true;
    if (body.get('redirect_uri') !== g.redirect) return json(400, { error: 'redirect_uri_mismatch' });
    const verifier = body.get('code_verifier') ?? '';
    if (createHash('sha256').update(verifier).digest('base64url') !== g.challenge) return json(400, { error: 'invalid_grant', error_description: 'PKCE mismatch' });
    return json(200, issue(g.person, g.scopes, google.issueRefreshToken && g.scopes.some((s) => s.includes('gmail'))));
  }
  if (body.get('grant_type') === 'refresh_token') {
    const r = google.refresh.get(body.get('refresh_token') ?? '');
    if (!r) return json(400, { error: 'invalid_grant' });
    const out = issue(r.person, r.scopes, false);
    delete out.id_token;
    return json(200, out);
  }
  return json(400, { error: 'unsupported_grant_type' });
}

function gmailApi(url: URL, auth: string | undefined, init?: RequestInit): Response {
  const token = google.access.get((auth ?? '').replace('Bearer ', ''));
  if (!token || token.exp < Date.now()) return json(401, { error: { code: 401, message: 'Invalid Credentials' } });
  const box = google.mailboxes.get(token.person.email)!;
  const path = url.pathname.replace('/gmail/v1/users/me', '');
  const has = (s: string) => token.scopes.includes(s);
  if (!has(SCOPES.metadata) && !has(SCOPES.send)) return json(403, { error: { code: 403, message: 'Request had insufficient authentication scopes.', errors: [{ reason: 'insufficientPermissions' }] } });
  if (path === '/profile') return json(200, { emailAddress: box.email, historyId: String(box.historyId), messagesTotal: box.messages.length });
  if (path === '/messages' && (!init?.method || init.method === 'GET')) {
    if (url.searchParams.has('q')) return json(403, { error: { code: 403, message: "Metadata scope does not support 'q' parameter" } });
    const start = Number(url.searchParams.get('pageToken') ?? 0);
    const size = Number(url.searchParams.get('maxResults') ?? 100);
    const slice = box.messages.slice(start, start + size);
    return json(200, { messages: slice.map((m) => ({ id: m.id, threadId: m.id })), ...(start + size < box.messages.length ? { nextPageToken: String(start + size) } : {}), resultSizeEstimate: box.messages.length });
  }
  if (path === '/messages/send' && init?.method === 'POST') {
    if (!has(SCOPES.send)) return json(403, { error: { code: 403, message: 'insufficient', errors: [{ reason: 'insufficientPermissions' }] } });
    const raw = Buffer.from(JSON.parse(String(init.body)).raw, 'base64url').toString('utf8');
    box.sent.push(raw);
    return json(200, { id: `sent-${box.sent.length}` });
  }
  const m = /^\/messages\/([^/]+)$/.exec(path);
  if (m) {
    if (url.searchParams.get('format') !== 'metadata') return json(403, { error: { code: 403, message: 'Metadata scope does not allow format FULL' } });
    const msg = box.messages.find((x) => x.id === decodeURIComponent(m[1]));
    if (!msg) return json(404, { error: { code: 404, message: 'Requested entity was not found.' } });
    const wanted = url.searchParams.getAll('metadataHeaders').map((h) => h.toLowerCase());
    // Gmail returns header names as the sender wrote them.
    const headers = Object.entries(msg.headers).filter(([k]) => wanted.includes(k)).map(([k, v]) => ({ name: k.replace(/(^|-)([a-z])/g, (_x, a: string, b: string) => a + b.toUpperCase()), value: v }));
    return json(200, { id: msg.id, threadId: msg.id, labelIds: msg.labelIds, internalDate: String(msg.internalDate), payload: { headers } });
  }
  if (path === '/history') {
    const start = Number(url.searchParams.get('startHistoryId'));
    if (start < box.oldestHistory) return json(404, { error: { code: 404, message: 'Requested entity was not found.' } });
    const added = box.messages.filter((_x, i) => box.addedAt[i] > start).map((x) => ({ messagesAdded: [{ message: { id: x.id } }] }));
    return json(200, { history: added, historyId: String(box.historyId) });
  }
  return json(404, { error: { code: 404 } });
}

const realFetch = globalThis.fetch;
before(() => {
  config.google.clientId = CLIENT_ID;
  config.google.clientSecret = CLIENT_SECRET;
  globalThis.fetch = (async (input: string | URL | Request, init?: RequestInit) => {
    const url = new URL(typeof input === 'string' ? input : input instanceof URL ? input.href : input.url);
    const auth = (init?.headers as Record<string, string> | undefined)?.authorization;
    google.calls.push({ url: url.href, body: typeof init?.body === 'string' ? init.body : init?.body?.toString(), auth });
    if (url.href === 'https://oauth2.googleapis.com/token') return tokenEndpoint(new URLSearchParams(String(init?.body)));
    if (url.href === 'https://oauth2.googleapis.com/revoke') {
      const t = new URLSearchParams(String(init?.body)).get('token')!;
      google.revoked.push(t);
      google.refresh.delete(t);
      return json(200, {});
    }
    if (url.host === 'gmail.googleapis.com') return gmailApi(url, auth, init);
    return realFetch(input as never, init);
  }) as typeof fetch;
});
after(() => { globalThis.fetch = realFetch; config.google.clientId = ''; config.google.clientSecret = ''; });

// ---------------- browser helper ----------------
async function world() {
  const { db, close } = await openDatabase({ memory: true });
  const app = await buildApp(db);
  return { db, close, app, worker: createWorker(db, 1) };
}

/** A browser with its own cookie jar. */
function browser(app: Awaited<ReturnType<typeof world>>['app']) {
  const jar = new Map<string, string>();
  return {
    jar,
    async get(url: string) {
      const res = await app.inject({ method: 'GET', url, headers: { cookie: [...jar].map(([k, v]) => `${k}=${v}`).join('; ') } });
      for (const c of res.cookies) { if (c.value === '' || (c.maxAge !== undefined && c.maxAge <= 0) || (c.expires && new Date(c.expires) < new Date())) jar.delete(c.name); else jar.set(c.name, c.value); }
      return res;
    },
  };
}
const location = (res: { headers: Record<string, unknown> }) => String(res.headers.location ?? '');
const person = (n: string): Person => ({ sub: `sub-${n}`, email: `${n}@gmail.example`, name: n });

async function signIn(b: ReturnType<typeof browser>, p: Person) {
  const start = await b.get('/auth/google/login');
  const { code, state } = consent(location(start), p);
  return b.get(`/auth/google/callback?code=${code}&state=${state}`);
}

async function connectGmail(b: ReturnType<typeof browser>, p: Person, opts: { deny?: string[] } = {}) {
  const box = google.mailboxes.get(p.email) ?? new FakeMailbox(p.email);
  google.mailboxes.set(p.email, box);
  const start = await b.get('/auth/google/connect');
  const { code, state } = consent(location(start), p, opts);
  return { res: await b.get(`/auth/google/callback?code=${code}&state=${state}`), box, authUrl: location(start) };
}

// ---------------- tests ----------------

test('sign-in: least-privilege request, PKCE verified by Google, session created', async () => {
  const w = await world();
  const b = browser(w.app);
  const start = await b.get('/auth/google/login');
  const u = new URL(location(start));
  assert.deepEqual(u.searchParams.get('scope')!.split(' ').sort(), ['email', 'openid', 'profile'], 'sign-in asks for identity only, no Gmail access');
  assert.equal(b.jar.get('ux_oauth'), u.searchParams.get('state'), 'state bound to this browser');
  const { code, state } = consent(location(start), person('alice'));
  const res = await b.get(`/auth/google/callback?code=${code}&state=${state}`);
  assert.equal(location(res), '/');
  assert.ok(b.jar.get('ux_sid'), 'session cookie set');
  assert.ok(!b.jar.has('ux_oauth'), 'state cookie cleared');
  const tokenCall = google.calls.filter((c) => c.url.endsWith('/token')).at(-1)!;
  assert.match(tokenCall.body!, /code_verifier=/);
  assert.match(tokenCall.body!, /client_secret=test-secret/);
  const me = await w.app.inject({ method: 'GET', url: '/api/me', headers: { cookie: `ux_sid=${b.jar.get('ux_sid')}` } });
  assert.equal(me.json().user.email, 'alice@gmail.example');
  // The sign-in Google account has no mailbox access.
  assert.equal((await w.db.select().from(mailAccounts)).length, 0);
  await w.close();
});

test('callback refuses replayed, foreign-browser, tampered and expired states', async () => {
  const w = await world();
  const b = browser(w.app);
  const start = await b.get('/auth/google/login');
  const { code, state } = consent(location(start), person('bob'));
  // Login CSRF: the callback opened in a different browser (no state cookie).
  const other = browser(w.app);
  assert.equal(location(await other.get(`/auth/google/callback?code=${code}&state=${state}`)), '/login?error=invalid_state');
  assert.ok(!other.jar.has('ux_sid'));
  // The state was consumed by that attempt, so even the right browser can't reuse it.
  assert.equal(location(await b.get(`/auth/google/callback?code=${code}&state=${state}`)), '/login?error=invalid_state');
  // Tampered state.
  const s2 = await b.get('/auth/google/login');
  const g2 = consent(location(s2), person('bob'));
  assert.equal(location(await b.get(`/auth/google/callback?code=${g2.code}&state=${g2.state}x`)), '/login?error=invalid_state');
  // Expired state.
  const s3 = await b.get('/auth/google/login');
  const g3 = consent(location(s3), person('bob'));
  await w.db.update(oauthStates).set({ expiresAt: new Date(Date.now() - 1000) }).where(eq(oauthStates.state, g3.state));
  assert.equal(location(await b.get(`/auth/google/callback?code=${g3.code}&state=${g3.state}`)), '/login?error=invalid_state');
  // A good flow still works afterwards, and a replayed code is refused by Google.
  const s4 = await b.get('/auth/google/login');
  const g4 = consent(location(s4), person('bob'));
  assert.equal(location(await b.get(`/auth/google/callback?code=${g4.code}&state=${g4.state}`)), '/');
  assert.equal((await w.db.select().from(users)).length, 1);
  await w.close();
});

test('callback errors: user cancels, wrong audience, unverified email', async () => {
  const w = await world();
  const b = browser(w.app);
  const s1 = await b.get('/auth/google/login');
  const st1 = new URL(location(s1)).searchParams.get('state');
  assert.equal(location(await b.get(`/auth/google/callback?error=access_denied&state=${st1}`)), '/login?error=access_denied');
  google.audOverride = 'someone-elses-client';
  assert.equal(location(await signIn(b, person('carol'))), '/login?error=oauth_failed');
  google.audOverride = null;
  assert.equal(location(await signIn(b, { ...person('dave'), verified: false })), '/login?error=email_not_verified');
  assert.equal((await w.db.select().from(users)).length, 0);
  await w.close();
});

test('connect Gmail: offline metadata access, encrypted tokens, background scan of the real Gmail client', async () => {
  const w = await world();
  const b = browser(w.app);
  await signIn(b, person('erin'));
  const p = person('erin');
  const box = new FakeMailbox(p.email);
  addSender(box, { from: 'news@shop.example', name: 'Shop', listId: 'news.shop.example', count: 30, unsub: '<https://shop.example/u>, <mailto:u@shop.example>', oneClick: true, labels: ['CATEGORY_PROMOTIONS'] });
  addSender(box, { from: 'statements@bank.example', name: 'Bank', subject: 'Your monthly statement is ready', count: 6 });
  google.mailboxes.set(p.email, box);
  const { res, authUrl } = await connectGmail(b, p);
  const u = new URL(authUrl);
  assert.equal(u.searchParams.get('access_type'), 'offline');
  assert.equal(u.searchParams.get('prompt'), 'consent');
  assert.equal(u.searchParams.get('include_granted_scopes'), 'true');
  assert.ok(u.searchParams.get('scope')!.split(' ').includes(SCOPES.metadata));
  assert.ok(!u.searchParams.get('scope')!.includes('gmail.send'), 'send is not requested up front');
  assert.match(location(res), /^\/accounts\?connected=/);

  const [acct] = await w.db.select().from(mailAccounts);
  assert.equal(acct.provider, 'gmail');
  assert.equal(acct.email, p.email);
  const raw = JSON.stringify(acct);
  assert.ok(!/ya29\.|1\/\/rt-/.test(raw), 'no plaintext tokens in the database');
  assert.match(decrypt(acct.refreshTokenEnc!), /^1\/\/rt-/);
  assert.ok(google.access.has(decrypt(acct.accessTokenEnc!)));
  assert.equal((await w.db.select().from(jobs)).filter((j) => j.type === 'scan').length, 1, 'scan queued');

  // The scan runs through the real Gmail REST client against the simulated API.
  await w.worker.drain();
  const ids = await w.db.select().from(senderIdentities);
  assert.equal(ids.length, 2);
  const shop = ids.find((i) => i.domain === 'shop.example')!;
  assert.equal(shop.messageCount, 30);
  assert.equal(shop.oneClick, true);
  assert.equal(shop.unsubMailto, 'mailto:u@shop.example');
  assert.equal(ids.find((i) => i.domain === 'bank.example')!.isProtected, true);
  const gmailCalls = google.calls.filter((c) => c.url.startsWith('https://gmail.googleapis.com'));
  assert.ok(gmailCalls.every((c) => !c.url.includes('format=full') && !c.url.includes('format=raw')), 'never requests message bodies');
  assert.ok(gmailCalls.some((c) => c.url.includes('metadataHeaders=List-Unsubscribe-Post')));
  const [after] = await w.db.select().from(mailAccounts);
  assert.ok(after.historyId && after.fullScanCompletedAt);
  await w.close();
});

test('connect: denied Gmail permission, missing refresh token, session switched mid-flow', async () => {
  const w = await world();
  const b = browser(w.app);
  await signIn(b, person('frank'));
  // Google's granular consent: the user unticks the Gmail box.
  const denied = await connectGmail(b, person('frank'), { deny: [SCOPES.metadata] });
  assert.equal(location(denied.res), '/accounts?error=metadata_scope_denied');
  assert.equal((await w.db.select().from(mailAccounts)).length, 0);

  google.issueRefreshToken = false;
  const noRefresh = await connectGmail(b, person('frank'));
  google.issueRefreshToken = true;
  assert.equal(location(noRefresh.res), '/accounts?error=no_refresh_token');

  // Connect started as one user, finished after signing in as another in the same browser.
  const start = await b.get('/auth/google/connect');
  const g = consent(location(start), person('frank'));
  const otherSession = browser(w.app);
  await signIn(otherSession, person('mallory'));
  b.jar.set('ux_sid', otherSession.jar.get('ux_sid')!);
  assert.equal(location(await b.get(`/auth/google/callback?code=${g.code}&state=${g.state}`)), '/login?error=session_changed');
  // Without a session, connect sends you to sign in.
  assert.equal(location(await browser(w.app).get('/auth/google/connect')), '/login');
  await w.close();
});

test('reconnecting the same Gmail updates it in place and clears "needs reconnecting"', async () => {
  const w = await world();
  const b = browser(w.app);
  await signIn(b, person('gina'));
  await connectGmail(b, person('gina'));
  await w.db.update(mailAccounts).set({ status: 'reauth_required', statusDetail: 'revoked' });
  const again = await connectGmail(b, person('gina'));
  assert.match(location(again.res), /connected=/);
  const accts = await w.db.select().from(mailAccounts);
  assert.equal(accts.length, 1);
  assert.equal(accts[0].status, 'active');
  assert.equal(accts[0].statusDetail, null);
  await w.close();
});

test('send permission: incremental consent for the same mailbox only, then waiting emails go out', async () => {
  const w = await world();
  const b = browser(w.app);
  await signIn(b, person('hana'));
  const { box } = await connectGmail(b, person('hana'));
  addSender(box, { from: 'x@mailonly.example', listId: 'l.mailonly.example', count: 5, unsub: '<mailto:leave@mailonly.example>' });
  await w.db.update(mailAccounts).set({ historyId: null });
  await w.worker.drain();
  const [acct] = await w.db.select().from(mailAccounts);
  const [identity] = await w.db.select().from(senderIdentities);
  config.unsubscribeMode = 'live';
  const { createRequests } = await import('../src/modules/unsubscribe/engine.ts');
  await createRequests(w.db, acct.userId, [identity.id], { source: 'web' });
  await w.worker.drain();
  let [req] = await w.db.select().from(unsubscribeRequests);
  assert.equal(req.state, 'awaiting_approval', 'waits for send permission');

  // Picking a different Google account on the consent screen is refused.
  const s1 = await b.get(`/auth/google/send-scope?accountId=${acct.id}`);
  const g1 = consent(location(s1), person('not-hana'));
  google.mailboxes.set('not-hana@gmail.example', new FakeMailbox('not-hana@gmail.example'));
  assert.equal(location(await b.get(`/auth/google/callback?code=${g1.code}&state=${g1.state}`)), '/accounts?error=wrong_account');
  assert.equal((await w.db.select().from(mailAccounts)).length, 1, 'no second mailbox added');

  const s2 = await b.get(`/auth/google/send-scope?accountId=${acct.id}`);
  const scopes = new URL(location(s2)).searchParams.get('scope')!.split(' ');
  assert.ok(scopes.includes(SCOPES.send) && scopes.includes(SCOPES.metadata));
  assert.equal(new URL(location(s2)).searchParams.get('login_hint'), acct.email);
  const g2 = consent(location(s2), person('hana'));
  assert.equal(location(await b.get(`/auth/google/callback?code=${g2.code}&state=${g2.state}`)), `/accounts?connected=${acct.id}&scope=send`);
  await w.worker.drain();
  [req] = await w.db.select().from(unsubscribeRequests);
  assert.equal(req.state, 'verification_pending');
  assert.equal(box.sent.length, 1, 'the email went out through the Gmail API');
  assert.match(box.sent[0], /^From: hana@gmail\.example\r\nTo: leave@mailonly\.example\r\n/);
  // Someone else's account id is refused.
  const otherUser = browser(w.app);
  await signIn(otherUser, person('ivan'));
  assert.equal(location(await otherUser.get(`/auth/google/send-scope?accountId=${acct.id}`)), '/accounts?error=not_found');
  config.unsubscribeMode = 'dry_run';
  await w.close();
});

test('token refresh: expired access token is refreshed and saved; a revoked grant asks to reconnect', async () => {
  const w = await world();
  const b = browser(w.app);
  await signIn(b, person('jo'));
  await connectGmail(b, person('jo'));
  let [acct] = await w.db.select().from(mailAccounts);
  const oldAccess = decrypt(acct.accessTokenEnc!);
  await w.db.update(mailAccounts).set({ tokenExpiresAt: new Date(Date.now() - 1000) });
  [acct] = await w.db.select().from(mailAccounts);
  const profile = await getProvider(w.db, acct).getProfile();
  assert.equal(profile.email, 'jo@gmail.example');
  [acct] = await w.db.select().from(mailAccounts);
  assert.notEqual(decrypt(acct.accessTokenEnc!), oldAccess, 'new access token stored');
  assert.ok(acct.tokenExpiresAt!.getTime() > Date.now() + 3000 * 1000);

  // Google rejects a token it thinks is valid (revoked elsewhere): refresh once and retry.
  google.access.delete(decrypt(acct.accessTokenEnc!));
  assert.equal((await getProvider(w.db, acct).getProfile()).email, 'jo@gmail.example');

  // The user removes the app at myaccount.google.com: refresh fails with invalid_grant.
  google.refresh.clear();
  google.access.clear();
  [acct] = await w.db.select().from(mailAccounts);
  await assert.rejects(getProvider(w.db, acct).getProfile(), ProviderAuthError);
  [acct] = await w.db.select().from(mailAccounts);
  assert.equal(acct.status, 'reauth_required');
  await w.close();
});

test('Gmail client edge cases: deleted messages, expired history, missing scope, paging', async () => {
  const w = await world();
  const b = browser(w.app);
  await signIn(b, person('kim'));
  const { box } = await connectGmail(b, person('kim'));
  addSender(box, { from: 'a@a.example', count: 620 });
  const [acct] = await w.db.select().from(mailAccounts);
  const gmail = getProvider(w.db, acct);
  const p1 = await gmail.listMessageIds(undefined, 500);
  assert.equal(p1.ids.length, 500);
  const p2 = await gmail.listMessageIds(p1.nextPageToken, 500);
  assert.equal(p2.ids.length, 120);
  assert.equal(p2.nextPageToken, undefined);
  const metas = await gmail.getMetadata([p1.ids[0], 'deleted-meanwhile', p1.ids[1]]);
  assert.equal(metas.length, 2, 'a message deleted since listing is skipped');
  assert.equal(metas[0].headers.from, '"a@a.example" <a@a.example>', 'header names normalised to lower case');
  box.oldestHistory = Number.MAX_SAFE_INTEGER;
  await assert.rejects(gmail.listHistory('1'), HistoryExpiredError);
  await assert.rejects(gmail.sendRaw('x'), MissingScopeError, 'send refused locally without the scope');
  await w.close();
});

test('disconnect and account deletion revoke Google access', async () => {
  const w = await world();
  const b = browser(w.app);
  await signIn(b, person('lee'));
  await connectGmail(b, person('lee'));
  const [acct] = await w.db.select().from(mailAccounts);
  const refresh = decrypt(acct.refreshTokenEnc!);
  const call = (method: 'DELETE', url: string, payload?: unknown) => w.app.inject({ method, url, payload: payload as never, headers: { cookie: `ux_sid=${b.jar.get('ux_sid')}`, 'x-requested-with': 'unsubscriber' } });
  const r = await call('DELETE', `/api/accounts/${acct.id}`);
  assert.deepEqual(r.json(), { revoked: true });
  assert.ok(google.revoked.includes(refresh), 'refresh token revoked at Google');
  assert.equal((await w.db.select().from(mailAccounts)).length, 0);

  await connectGmail(b, person('lee'));
  const [acct2] = await w.db.select().from(mailAccounts);
  const refresh2 = decrypt(acct2.refreshTokenEnc!);
  const del = await call('DELETE', '/api/me', { confirm: 'DELETE' });
  assert.equal(del.json().tokensRevoked, 1);
  assert.ok(google.revoked.includes(refresh2));
  await w.close();
});

test('tokens are encrypted with authenticated encryption under the configured key', () => {
  const blob = encrypt('1//rt-secret');
  const other = Buffer.alloc(32, 9);
  assert.throws(() => decrypt(blob, other), 'a different key cannot read stored tokens');
});
