import { test } from 'node:test';
import assert from 'node:assert/strict';
import { parseFrom, parseListId, parseListUnsubscribe, parseMailto, decodeWords, baseDomain } from '../src/lib/headers.ts';
import { validateDestination, isPublicAddress, safeRequest, UnsafeDestinationError } from '../src/lib/safe-http.ts';
import { encrypt, decrypt } from '../src/lib/crypto.ts';
import { redact } from '../src/lib/log.ts';

test('parseFrom handles names, bare addresses and encoded words', () => {
  assert.deepEqual(parseFrom('"Shop, Inc." <News@Shop.Example>'), { address: 'news@shop.example', name: 'Shop, Inc.', domain: 'shop.example' });
  assert.deepEqual(parseFrom('alerts@bank.example'), { address: 'alerts@bank.example', name: null, domain: 'bank.example' });
  assert.equal(parseFrom('=?UTF-8?B?w4lsw6lnYW50?= <hi@x.example>')?.name, 'Élégant');
  assert.equal(parseFrom('not an address'), null);
  assert.equal(parseFrom(undefined), null);
});

test('decodeWords handles Q encoding', () => {
  assert.equal(decodeWords('=?iso-8859-1?Q?Caf=E9_news?='), 'Café news');
});

test('parseListId extracts the identifier', () => {
  assert.equal(parseListId('Weekly <Weekly.Shop.Example>'), 'weekly.shop.example');
  assert.equal(parseListId('plain.id.example'), 'plain.id.example');
  assert.equal(parseListId(undefined), null);
});

test('List-Unsubscribe and RFC 8058 one-click detection', () => {
  const both = parseListUnsubscribe('<mailto:u@x.example?subject=stop>, <https://x.example/u?id=1>', 'List-Unsubscribe=One-Click');
  assert.equal(both.http, 'https://x.example/u?id=1');
  assert.equal(both.mailto, 'mailto:u@x.example?subject=stop');
  assert.equal(both.oneClick, true);
  // No Post header: not one-click.
  assert.equal(parseListUnsubscribe('<https://x.example/u>', undefined).oneClick, false);
  // Wrong Post value: not one-click.
  assert.equal(parseListUnsubscribe('<https://x.example/u>', 'List-Unsubscribe=Yes').oneClick, false);
  // HTTP (not HTTPS) can never be one-click.
  assert.equal(parseListUnsubscribe('<http://x.example/u>', 'List-Unsubscribe=One-Click').oneClick, false);
  assert.deepEqual(parseListUnsubscribe(undefined, undefined), { http: null, mailto: null, oneClick: false });
});

test('parseMailto rejects multiple recipients and strips header injection', () => {
  assert.deepEqual(parseMailto('mailto:leave@list.example?subject=Unsubscribe%20me'), { to: 'leave@list.example', subject: 'Unsubscribe me', body: 'unsubscribe' });
  assert.equal(parseMailto('mailto:a@x.example,b@y.example'), null);
  assert.equal(parseMailto('https://x.example'), null);
  const inj = parseMailto('mailto:a@x.example?subject=hi%0D%0ABcc:%20victim@z.example');
  assert.ok(inj && !/[\r\n]/.test(inj.subject));
});

test('baseDomain', () => {
  assert.equal(baseDomain('mail.news.shop.example'), 'shop.example');
  assert.equal(baseDomain('email.brand.co.uk'), 'brand.co.uk');
});

test('destination validation blocks unsafe targets', () => {
  const bad = ['http://x.example/u', 'https://user:pw@x.example/', 'https://127.0.0.1/u', 'https://10.1.2.3/', 'https://[::1]/',
    'https://localhost/u', 'https://printer.local/', 'https://x.example:8443/u', 'javascript:alert(1)', 'not a url'];
  for (const u of bad) assert.throws(() => validateDestination(u), UnsafeDestinationError, u);
  assert.equal(validateDestination('https://unsub.example.com/u?id=1').hostname, 'unsub.example.com');
});

test('isPublicAddress', () => {
  for (const ip of ['127.0.0.1', '10.0.0.1', '172.20.1.1', '192.168.1.1', '169.254.169.254', '100.64.0.1', '::1', 'fd00::1', 'fe80::1', '::ffff:127.0.0.1'])
    assert.equal(isPublicAddress(ip), false, ip);
  for (const ip of ['8.8.8.8', '1.1.1.1', '2606:4700::1111']) assert.equal(isPublicAddress(ip), true, ip);
});

test('safeRequest refuses loopback without the test override', async () => {
  await assert.rejects(safeRequest('https://127.0.0.1/', { method: 'POST' }), UnsafeDestinationError);
});

test('token encryption round-trips and detects tampering', () => {
  const blob = encrypt('ya29.secret-token');
  assert.notEqual(blob, 'ya29.secret-token');
  assert.equal(decrypt(blob), 'ya29.secret-token');
  const parts = blob.split('.');
  parts[3] = Buffer.from('tampered').toString('base64url');
  assert.throws(() => decrypt(parts.join('.')));
});

test('logs never contain emails or tokens', () => {
  const s = redact('refresh failed for john@doe.example token=ya29.a0AfH6SMBxyz123 at https://x.example/u?id=secret');
  assert.ok(!s.includes('john@doe.example'));
  assert.ok(!s.includes('ya29'));
  assert.ok(!s.includes('id=secret'));
});
