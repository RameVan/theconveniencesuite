import { test } from 'node:test';
import assert from 'node:assert/strict';
import { eq, sql } from 'drizzle-orm';
import { jobs, mailAccounts, messages, senderIdentities, categories } from '../src/db/schema.ts';
import { enqueueScan, ingest } from '../src/modules/discovery/scan.ts';
import { claim } from '../src/modules/jobs/queue.ts';
import { seedFixtureMailbox } from '../src/providers/fake.ts';
import { setup, addSender } from './helpers.ts';

const identities = async (db: Awaited<ReturnType<typeof setup>>['db'], accountId: string) =>
  db.select().from(senderIdentities).where(eq(senderIdentities.accountId, accountId));

test('full scan groups mail into identities and separates lists of one company', async () => {
  const t = await setup();
  seedFixtureMailbox(t.box);
  await enqueueScan(t.db, t.account, 'full');
  await t.worker.drain();
  const ids = await identities(t.db, t.account.id);
  // 30 seeded senders; the personal sender and all others are distinct identities.
  assert.equal(ids.length, 30);
  const northwind = ids.filter((i) => i.domain === 'northwind-outfitters.example');
  assert.equal(northwind.length, 3, 'two lists and the order address stay separate');
  const orders = northwind.find((i) => i.fromAddress.startsWith('orders@'))!;
  assert.equal(orders.isProtected, true);
  assert.equal(orders.kind, 'transactional');
  const weekly = northwind.find((i) => i.listId === 'weekly.northwind-outfitters.example')!;
  assert.equal(weekly.isProtected, false);
  assert.equal(weekly.oneClick, true);
  assert.ok(weekly.unsubMailto?.startsWith('mailto:'));
  // Same company, bank statements protected, bank marketing not.
  const bank = ids.filter((i) => i.domain === 'firstharbor.example');
  assert.equal(bank.find((i) => i.fromAddress.startsWith('statements@'))!.isProtected, true);
  assert.equal(bank.find((i) => i.fromAddress.startsWith('marketing@'))!.isProtected, false);
  // Counts add up to the mailbox.
  const [{ n }] = await t.db.select({ n: sql<number>`count(*)::int` }).from(messages).where(eq(messages.accountId, t.account.id));
  assert.equal(n, t.box.messages.length);
  assert.equal(ids.reduce((s, i) => s + i.messageCount, 0), t.box.messages.length);
  const [acct] = await t.db.select().from(mailAccounts).where(eq(mailAccounts.id, t.account.id));
  assert.ok(acct.fullScanCompletedAt);
  assert.ok(acct.historyId);
  await t.close();
});

test('ingesting the same messages twice never double counts', async () => {
  const t = await setup();
  addSender(t.box, { from: 'news@a.example', listId: 'a.list', count: 20, unsub: '<https://a.example/u>' });
  const metas = t.box.messages.slice();
  await ingest(t.db, t.account, metas);
  await ingest(t.db, t.account, metas);
  await ingest(t.db, t.account, metas.slice(0, 5));
  const [i] = await identities(t.db, t.account.id);
  assert.equal(i.messageCount, 20);
  assert.equal(i.signals.total, 20);
  await t.close();
});

test('an interrupted scan resumes from its checkpoint with identical results', async () => {
  const t = await setup();
  for (let s = 0; s < 40; s++) addSender(t.box, { from: `n${s}@s${s}.example`, listId: `l${s}.example`, count: 30, unsub: `<https://s${s}.example/u>` });
  t.box.crashAfterCalls = 5; // provider fails mid-scan
  await enqueueScan(t.db, t.account, 'full');
  await t.worker.drain(1);
  const [afterCrash] = await t.db.select().from(jobs).where(eq(jobs.accountId, t.account.id));
  assert.equal(afterCrash.status, 'queued', 'job is re-queued for retry');
  const checkpoint = afterCrash.progress as { processed: number; pageToken: string };
  assert.ok(checkpoint.processed > 0 && checkpoint.pageToken, 'progress checkpoint saved');
  await t.db.update(jobs).set({ runAt: new Date() }).where(eq(jobs.id, afterCrash.id));
  const callsBefore = t.box.metadataCalls;
  await t.worker.drain();
  const ids = await identities(t.db, t.account.id);
  assert.equal(ids.length, 40);
  assert.equal(ids.reduce((s, i) => s + i.messageCount, 0), 1200);
  // Resumed instead of restarting. A full scan of 1,200 messages takes 14 metadata calls
  // (pages of 250 fetched in batches of 100,100,50); 6 were made before the crash.
  assert.ok(t.box.metadataCalls - callsBefore <= 9, `metadata calls after resume: ${t.box.metadataCalls - callsBefore}`);
  await t.close();
});

test('a worker that dies mid-job is recovered when its lease expires', async () => {
  const t = await setup();
  addSender(t.box, { from: 'x@x.example', count: 10 });
  await enqueueScan(t.db, t.account, 'full');
  const job = await claim(t.db, 'dead-worker', ['scan']);
  assert.ok(job);
  // The "dead" worker never finishes; simulate the lease running out.
  await t.db.update(jobs).set({ leaseUntil: new Date(Date.now() - 1000) }).where(eq(jobs.id, job.id));
  await t.worker.drain();
  const [after] = await t.db.select().from(jobs).where(eq(jobs.id, job.id));
  assert.equal(after.status, 'succeeded');
  assert.equal((await identities(t.db, t.account.id))[0].messageCount, 10);
  await t.close();
});

test('rate limits defer the scan without consuming attempts', async () => {
  const t = await setup();
  addSender(t.box, { from: 'x@x.example', count: 10 });
  t.box.rateLimitNext = 1;
  await enqueueScan(t.db, t.account, 'full');
  await t.worker.drain(1);
  const [j] = await t.db.select().from(jobs).where(eq(jobs.accountId, t.account.id));
  assert.equal(j.status, 'queued');
  assert.equal(j.attempts, 0);
  assert.ok(j.runAt.getTime() > Date.now());
  await t.close();
});

test('incremental sync only fetches new mail; expired history falls back to a full scan', async () => {
  const t = await setup();
  addSender(t.box, { from: 'news@a.example', listId: 'a.list', count: 50 });
  await enqueueScan(t.db, t.account, 'full');
  await t.worker.drain();
  addSender(t.box, { from: 'news@a.example', listId: 'a.list', count: 3, days: 1 });
  addSender(t.box, { from: 'new@b.example', count: 2, days: 1 });
  const calls = t.box.metadataCalls;
  await enqueueScan(t.db, t.account, 'incremental');
  await t.worker.drain();
  assert.equal(t.box.metadataCalls - calls, 1, 'one metadata batch for 5 new messages');
  let ids = await identities(t.db, t.account.id);
  assert.equal(ids.find((i) => i.listId === 'a.list')!.messageCount, 53);
  assert.equal(ids.find((i) => i.fromAddress === 'new@b.example')!.messageCount, 2);

  addSender(t.box, { from: 'late@c.example', count: 4, days: 1 });
  t.box.oldestHistory = Number.MAX_SAFE_INTEGER; // provider forgot our history id
  await enqueueScan(t.db, t.account, 'incremental');
  await t.worker.drain();
  ids = await identities(t.db, t.account.id);
  assert.equal(ids.find((i) => i.fromAddress === 'late@c.example')!.messageCount, 4);
  assert.equal(ids.find((i) => i.listId === 'a.list')!.messageCount, 53, 'no double counting after fallback');
  await t.close();
});

test('partial scan is limited and labelled as partial', async () => {
  const t = await setup();
  addSender(t.box, { from: 'a@a.example', count: 800 });
  await enqueueScan(t.db, t.account, 'partial');
  await t.worker.drain();
  const [j] = await t.db.select().from(jobs).where(eq(jobs.accountId, t.account.id));
  const p = j.progress as { processed: number; limitReached: boolean; note: string };
  assert.equal(p.processed, 300);
  assert.equal(p.limitReached, true);
  assert.match(p.note, /Partial scan/);
  const [acct] = await t.db.select().from(mailAccounts).where(eq(mailAccounts.id, t.account.id));
  assert.equal(acct.fullScanCompletedAt, null, 'a partial scan never claims to be complete');
  await t.close();
});

test('scans of one account are never queued twice', async () => {
  const t = await setup();
  const a = await enqueueScan(t.db, t.account, 'full');
  const b = await enqueueScan(t.db, t.account, 'incremental');
  assert.equal(a.created, true);
  assert.equal(b.created, false);
  assert.equal(a.job.id, b.job.id);
  await t.close();
});

test('user category choices survive rescans', async () => {
  const t = await setup();
  addSender(t.box, { from: 'deals@shop.example', name: 'Shop', listId: 'deals.shop.example', count: 5, unsub: '<https://shop.example/u>' });
  await enqueueScan(t.db, t.account, 'full');
  await t.worker.drain();
  const [news] = await t.db.select().from(categories).where(sql`${categories.userId} = ${t.user.id} and ${categories.slug} = 'news'`);
  const [i] = await identities(t.db, t.account.id);
  await t.db.update(senderIdentities).set({ categoryId: news.id, categorySource: 'user' }).where(eq(senderIdentities.id, i.id));
  addSender(t.box, { from: 'deals@shop.example', name: 'Shop', listId: 'deals.shop.example', count: 2, days: 1 });
  await enqueueScan(t.db, t.account, 'incremental');
  await t.worker.drain();
  const [after] = await identities(t.db, t.account.id);
  assert.equal(after.categoryId, news.id);
  assert.equal(after.messageCount, 7);
  await t.close();
});

test('large mailbox: 25,000 messages scan in reasonable time', async () => {
  const t = await setup();
  for (let s = 0; s < 500; s++) addSender(t.box, { from: `n@s${s}.example`, listId: `l${s}.example`, count: 50, unsub: `<https://s${s}.example/u>`, oneClick: true });
  await t.db.execute(sql`update preferences set scan_max_messages = 30000 where user_id = ${t.user.id}`);
  const start = Date.now();
  await enqueueScan(t.db, t.account, 'full');
  await t.worker.drain();
  const ms = Date.now() - start;
  const ids = await identities(t.db, t.account.id);
  assert.equal(ids.length, 500);
  assert.equal(ids.reduce((s, i) => s + i.messageCount, 0), 25000);
  console.log(`# 25k message scan took ${ms} ms`);
  assert.ok(ms < 120000);
  await t.close();
});
