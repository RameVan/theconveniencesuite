// Simulated unsubscribe endpoint. The path picks the behaviour: /b/<behaviour>/<id>.
// It records every request so tests can assert exactly what a sender received.
import { createServer as createHttp, type IncomingMessage, type ServerResponse, type Server } from 'node:http';
import { createServer as createHttps } from 'node:https';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import type { AddressInfo } from 'node:net';

const tls = resolve(import.meta.dirname, 'fixtures/tls');
export const TEST_CA = readFileSync(resolve(tls, 'ca.crt'), 'utf8');

export interface Hit { method: string; path: string; behaviour: string; id: string; body: string; headers: IncomingMessage['headers']; at: number }

export interface Sim {
  base: string;
  hits: Hit[];
  hitsFor(id: string): Hit[];
  /** Per-id counters for "flaky" behaviours. */
  close(): Promise<void>;
}

function handle(hits: Hit[], counters: Map<string, number>, req: IncomingMessage, res: ServerResponse, body: string, base: () => string) {
  const url = new URL(req.url!, 'http://x');
  const [, , behaviour = 'ok200', id = 'anon'] = url.pathname.split('/');
  hits.push({ method: req.method!, path: url.pathname + url.search, behaviour, id, body, headers: req.headers, at: Date.now() });
  const n = (counters.get(id) ?? 0) + 1;
  counters.set(id, n);
  const send = (status: number, text = 'ok', headers: Record<string, string> = {}) => { res.writeHead(status, { 'content-type': 'text/html', ...headers }); res.end(text); };
  const delay = /^delay(\d+)$/.exec(behaviour);
  if (delay) { setTimeout(() => send(200), Number(delay[1])); return; }
  const flaky = /^flaky(\d+)$/.exec(behaviour);
  if (flaky) return n <= Number(flaky[1]) ? send(503, 'try later') : send(200, 'You have been unsubscribed');
  switch (behaviour) {
    case 'ok200': return send(200, '<h1>You have been unsubscribed</h1>');
    case 'ok201': return send(201);
    case 'ok202': return send(202);
    case 'ok204': res.writeHead(204); return res.end();
    case 'confirm': return send(200, '<form><p>Click the button below to confirm your unsubscribe</p><button>Confirm</button></form>');
    case 'captcha': return send(200, '<div class="g-recaptcha" data-sitekey="x"></div>');
    case 'hcaptcha': return send(200, '<div class="h-captcha"></div>');
    case 'r301': case 'r302': case 'r303': return send(Number(behaviour.slice(1)), '', { location: `/b/ok200/${id}-after` });
    case 'r307': case 'r308': return send(Number(behaviour.slice(1)), '', { location: `/b/ok200/${id}` });
    case 'r307abs': return send(307, '', { location: `${base()}/b/ok202/${id}` });
    case 'loop': return send(307, '', { location: `/b/loop/${id}` });
    case 'toprivate': return send(307, '', { location: 'https://169.254.169.254/latest/meta-data/' });
    case 'tohttp': return send(307, '', { location: `http://example.com/b/ok200/${id}` });
    case 'tobadscheme': return send(307, '', { location: 'javascript:alert(1)' });
    case 'getonly': return req.method === 'POST' ? send(405, 'Method Not Allowed', { allow: 'GET' }) : send(200);
    case 'e400': case 'e401': case 'e403': case 'e404': case 'e405': case 'e410': case 'e422': case 'e500': case 'e502': case 'e503': case 'e408':
      return send(Number(behaviour.slice(1)), 'error');
    case 'e429': return send(429, 'slow down', { 'retry-after': '1' });
    case 'slow': setTimeout(() => send(200), 5000); return; // longer than the test timeout
    case 'trickle': {
      // Sends one byte a second forever: an idle timeout never fires, only a total deadline does.
      res.writeHead(200, { 'content-type': 'text/plain' });
      const t = setInterval(() => res.write('.'), 200);
      res.on('close', () => clearInterval(t));
      return;
    }
    case 'reset': req.socket.destroy(); return;
    case 'huge': res.writeHead(200, { 'content-type': 'text/plain' }); res.end('x'.repeat(5 * 1024 * 1024)); return;
    default: return send(200);
  }
}

export async function startSim(opts: { https?: boolean; host?: string } = {}): Promise<Sim> {
  const hits: Hit[] = [];
  const counters = new Map<string, number>();
  let base = '';
  const listener = (req: IncomingMessage, res: ServerResponse) => {
    let body = '';
    req.on('data', (c) => { body += c; });
    req.on('end', () => handle(hits, counters, req, res, body, () => base));
  };
  const server: Server = opts.https
    ? createHttps({ key: readFileSync(resolve(tls, 'server.key')), cert: readFileSync(resolve(tls, 'server.crt')) }, listener) as unknown as Server
    : createHttp(listener);
  server.keepAliveTimeout = 100;
  await new Promise<void>((r) => server.listen(0, opts.host ?? '127.0.0.1', r));
  base = `${opts.https ? 'https' : 'http'}://127.0.0.1:${(server.address() as AddressInfo).port}`;
  return {
    base,
    hits,
    hitsFor: (id) => hits.filter((h) => h.id === id || h.id === `${id}-after`),
    close: () => new Promise<void>((r) => { server.closeAllConnections?.(); server.close(() => r()); }),
  };
}
