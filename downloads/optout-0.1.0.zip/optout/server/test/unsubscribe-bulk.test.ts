// A large bulk run with three workers in parallel on one database, a realistic mix of sender
// behaviours, users clicking again from both interfaces mid-run, and per-company spacing.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { and, eq, inArray, sql } from 'drizzle-orm';
import { config } from '../src/config.ts';
import { jobs, senderIdentities, unsubscribeRequests } from '../src/db/schema.ts';
import { createRequests, setDomainSpacingMs, setUnsubscribeHttpOptions } from '../src/modules/unsubscribe/engine.ts';
import { ingest } from '../src/modules/discovery/scan.ts';
import { Worker } from '../src/modules/jobs/queue.ts';
import { handlers } from '../src/jobs-runtime.ts';
import { setup } from './helpers.ts';
import { startSim } from './sim.ts';

config.unsubscribeMode = 'live';
const SPACING = 250;
const DOMAINS = 50;
const LISTS_PER_DOMAIN = 5;
// Behaviour mix, roughly like real inboxes: most succeed, some are flaky, some broken.
const MIX: [behaviour: string, share: number, posts: number, state: string][] = [
  ['ok200', 0.62, 1, 'verification_pending'],
  ['ok204', 0.08, 1, 'verification_pending'],
  ['flaky1', 0.08, 2, 'verification_pending'],
  ['r307', 0.06, 2, 'verification_pending'],
  ['captcha', 0.04, 1, 'requires_manual_action'],
  ['e404', 0.04, 1, 'failed'],
  ['getonly', 0.04, 1, 'requires_manual_action'],
  ['e503', 0.04, 4, 'failed'],
];

test(`bulk: ${DOMAINS * LISTS_PER_DOMAIN} senders, 3 workers x 4 slots`, { timeout: 240000 }, async () => {
  const sim = await startSim({ host: '0.0.0.0' });
  const port = new URL(sim.base).port;
  const t = await setup();
  const hosts = Array.from({ length: DOMAINS }, (_, d) => `127.0.${1 + Math.floor(d / 250)}.${2 + (d % 250)}`);
  setUnsubscribeHttpOptions({ allowPrivateHosts: hosts, allowHttp: true, timeoutMs: 2000 });
  setDomainSpacingMs(SPACING);

  // Build the mailbox: each domain has several lists with different behaviours.
  const plan = new Map<string, (typeof MIX)[number]>();
  const metas = [];
  let k = 0;
  for (let d = 0; d < DOMAINS; d++) {
    for (let l = 0; l < LISTS_PER_DOMAIN; l++, k++) {
      let acc = 0;
      const r = ((k * 7919) % 1000) / 1000;
      const mix = MIX.find(([, share]) => (acc += share) > r) ?? MIX[0];
      const id = `d${d}l${l}`;
      plan.set(id, mix);
      metas.push({
        id: `m-${id}`, internalDate: Date.now() - 86400000, labelIds: ['INBOX'],
        headers: {
          from: `"Company ${d}" <list${l}@company${d}.example>`, subject: 'News', 'list-id': `<${id}.company${d}.example>`,
          'list-unsubscribe': `<http://${hosts[d]}:${port}/b/${mix[0]}/${id}>`, 'list-unsubscribe-post': 'List-Unsubscribe=One-Click',
        },
      });
    }
  }
  await ingest(t.db, t.account, metas);
  // The parser rightly refuses one-click over plain HTTP; this run uses HTTP only because 50 hosts
  // can't share the test certificate (HTTPS is covered by the matrix test).
  await t.db.update(senderIdentities).set({ oneClick: true }).where(eq(senderIdentities.accountId, t.account.id));
  const ids = await t.db.select().from(senderIdentities).where(eq(senderIdentities.accountId, t.account.id));
  assert.equal(ids.length, DOMAINS * LISTS_PER_DOMAIN);
  const idByCase = new Map(ids.map((i) => [i.listId!.split('.')[0], i.id]));

  // Three independent workers, as if three server processes shared one Postgres.
  const workers = [0, 1, 2].map(() => new Worker(t.db, handlers, 4));
  for (const w of workers) { w.pollMs = 50; w.start(); }

  // Click "unsubscribe all" from the web app, and repeatedly from the extension while it runs.
  const all = ids.map((i) => i.id);
  const first = await createRequests(t.db, t.user.id, all, { source: 'web' });
  assert.equal(first.created.length, all.length);
  for (const w of workers) w.notify();
  const extraClicks = await Promise.all([1, 2, 3].map(() => createRequests(t.db, t.user.id, all, { source: 'extension' })));
  assert.ok(extraClicks.every((c) => c.created.length === 0), 'repeat clicks never create duplicates while requests are active');

  // Wait for every request to settle. Back-off waits are skipped; spacing is still enforced in the DB.
  const start = Date.now();
  while (Date.now() - start < 200000) {
    const [{ open }] = await t.db.select({ open: sql<number>`count(*)::int` }).from(unsubscribeRequests).where(inArray(unsubscribeRequests.state, ['queued', 'processing']));
    if (open === 0) break;
    await t.db.update(jobs).set({ runAt: new Date() }).where(and(eq(jobs.type, 'unsubscribe'), eq(jobs.status, 'queued'), sql`${jobs.lastError} is not null and ${jobs.lastError} not like 'deferred%'`));
    await new Promise((r) => setTimeout(r, 200));
  }
  await Promise.all(workers.map((w) => w.stop()));
  const elapsed = Date.now() - start;

  const problems: string[] = [];
  const reqs = await t.db.select().from(unsubscribeRequests);
  assert.equal(reqs.length, all.length, 'exactly one request per sender');
  for (const [id, [behaviour, , posts, state]] of plan) {
    const r = reqs.find((x) => x.identityId === idByCase.get(id))!;
    const hits = sim.hitsFor(id);
    if (r.state !== state) problems.push(`${id} (${behaviour}): state ${r.state}, expected ${state}`);
    if (hits.length !== posts) problems.push(`${id} (${behaviour}): ${hits.length} requests, expected ${posts}`);
    if (hits.some((h) => h.method !== 'POST')) problems.push(`${id}: non-POST request`);
  }
  // Identity rows mirror their request.
  const mirrored = await t.db.select({ id: senderIdentities.id, s: senderIdentities.unsubState }).from(senderIdentities);
  for (const m of mirrored) {
    const r = reqs.find((x) => x.identityId === m.id)!;
    if (m.s !== r.state) problems.push(`identity ${m.id} shows ${m.s}, request is ${r.state}`);
  }
  // Per-company spacing: requests to one host never closer than SPACING (first attempt of each request).
  let minGap = Infinity;
  for (const h of hosts) {
    const times = sim.hits.filter((x) => x.headers.host?.startsWith(h + ':')).filter((x, i, arr) => arr.findIndex((y) => y.id === x.id) === i).map((x) => x.at).sort((a, b) => a - b);
    for (let i = 1; i < times.length; i++) minGap = Math.min(minGap, times[i] - times[i - 1]);
  }
  if (minGap < SPACING - 25) problems.push(`two requests to one company only ${minGap} ms apart (minimum ${SPACING})`);
  const counts = reqs.reduce<Record<string, number>>((m, r) => ({ ...m, [r.state]: (m[r.state] ?? 0) + 1 }), {});
  console.log(`# bulk: ${all.length} senders in ${elapsed} ms; ${sim.hits.length} HTTP requests; min same-company gap ${minGap} ms; states ${JSON.stringify(counts)}`);
  assert.deepEqual(problems, []);
  await sim.close();
  await t.close();
});
