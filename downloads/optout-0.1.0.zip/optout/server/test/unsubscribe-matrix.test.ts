// Every sender response we could think of, over real HTTPS (test CA), checked for:
// the final state, exactly what the sender received, and that nothing claims success early.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { and, eq, inArray } from 'drizzle-orm';
import { config } from '../src/config.ts';
import { domainThrottle, jobs, mailAccounts, preferences, senderIdentities, unsubscribeEvents, unsubscribeRequests } from '../src/db/schema.ts';
import { createRequests, setDomainSpacingMs, setUnsubscribeHttpOptions } from '../src/modules/unsubscribe/engine.ts';
import { ingest } from '../src/modules/discovery/scan.ts';
import { MissingScopeError, ProviderAuthError, RateLimitError } from '../src/providers/types.ts';
import { setup } from './helpers.ts';
import { startSim, TEST_CA, type Sim } from './sim.ts';

config.unsubscribeMode = 'live';
let sim: Sim;
let plain: Sim;
before(async () => { sim = await startSim({ https: true }); plain = await startSim(); });
after(async () => { await sim.close(); await plain.close(); });

type World = Awaited<ReturnType<typeof setup>>;

/** One identity per case, all with a one-click link to the simulator. */
async function world(cases: { id: string; url: string; mailto?: string }[]) {
  const t = await setup();
  // Production rules (HTTPS only), except that the simulator lives on 127.0.0.1 and uses the test CA.
  setUnsubscribeHttpOptions({ allowPrivateHosts: ['127.0.0.1'], ca: TEST_CA, timeoutMs: 1500 });
  setDomainSpacingMs(0);
  await ingest(t.db, t.account, cases.map((c, i) => ({
    id: `msg-${c.id}`, internalDate: Date.now() - 86400000 * (1 + (i % 5)), labelIds: ['INBOX'],
    headers: {
      from: `"Sender ${c.id}" <news-${c.id}@sender${i}.example>`, subject: 'Weekly deals', 'list-id': `<${c.id}.list.example>`,
      'list-unsubscribe': [`<${c.url}>`, c.mailto ? `<${c.mailto}>` : ''].filter(Boolean).join(', '),
      'list-unsubscribe-post': 'List-Unsubscribe=One-Click',
    },
  })));
  const ids = await t.db.select().from(senderIdentities).where(eq(senderIdentities.accountId, t.account.id));
  const byCase = new Map(ids.map((i) => [i.listId!.replace('.list.example', ''), i]));
  return { ...t, byCase };
}

/** Runs the queue to completion, skipping retry back-off waits. */
async function runAll(t: World, rounds = 12) {
  for (let i = 0; i < rounds; i++) {
    await t.db.delete(domainThrottle);
    // Only unsubscribe jobs: verification is scheduled days later on purpose.
    await t.db.update(jobs).set({ runAt: new Date() }).where(and(eq(jobs.status, 'queued'), eq(jobs.type, 'unsubscribe')));
    if (!(await t.worker.drain())) return;
  }
}

async function finalState(t: World, identityId: string) {
  const [r] = await t.db.select().from(unsubscribeRequests).where(eq(unsubscribeRequests.identityId, identityId));
  const events = await t.db.select().from(unsubscribeEvents).where(eq(unsubscribeEvents.requestId, r.id)).orderBy(unsubscribeEvents.id);
  return { ...r, events: events.map((e) => e.toState), detail: events.map((e) => e.detail ?? '').join(' | ') };
}

interface Expect { behaviour: string; state: string; posts: number; detail?: RegExp; followed?: boolean }
const OK = 'verification_pending';

const MATRIX: Expect[] = [
  { behaviour: 'ok200', state: OK, posts: 1 },
  { behaviour: 'ok201', state: OK, posts: 1 },
  { behaviour: 'ok202', state: OK, posts: 1 },
  { behaviour: 'ok204', state: OK, posts: 1 },
  { behaviour: 'huge', state: OK, posts: 1 },
  { behaviour: 'confirm', state: 'awaiting_confirmation', posts: 1 },
  { behaviour: 'captcha', state: 'requires_manual_action', posts: 1, detail: /CAPTCHA/ },
  { behaviour: 'hcaptcha', state: 'requires_manual_action', posts: 1, detail: /CAPTCHA/ },
  { behaviour: 'r301', state: OK, posts: 1, detail: /redirected/ },
  { behaviour: 'r302', state: OK, posts: 1, detail: /redirected/ },
  { behaviour: 'r303', state: OK, posts: 1, detail: /redirected/ },
  { behaviour: 'r307', state: OK, posts: 2, followed: true },
  { behaviour: 'r308', state: OK, posts: 2, followed: true },
  { behaviour: 'r307abs', state: OK, posts: 2, followed: true },
  { behaviour: 'loop', state: 'failed', posts: 3, detail: /redirects/ },
  { behaviour: 'toprivate', state: 'failed', posts: 1, detail: /private|Unsafe/i },
  { behaviour: 'tohttp', state: 'failed', posts: 1, detail: /https/ },
  { behaviour: 'tobadscheme', state: 'failed', posts: 1, detail: /Unsafe|valid/i },
  { behaviour: 'getonly', state: 'requires_manual_action', posts: 1, detail: /page/ },
  { behaviour: 'e400', state: 'failed', posts: 1 },
  { behaviour: 'e401', state: 'failed', posts: 1 },
  { behaviour: 'e403', state: 'failed', posts: 1 },
  { behaviour: 'e404', state: 'failed', posts: 1, detail: /no longer|expired|404/ },
  { behaviour: 'e410', state: 'failed', posts: 1, detail: /no longer|expired|410/ },
  { behaviour: 'e422', state: 'failed', posts: 1 },
  { behaviour: 'e408', state: 'failed', posts: 4, detail: /4 attempts/ },
  { behaviour: 'e429', state: 'failed', posts: 4, detail: /4 attempts/ },
  { behaviour: 'e500', state: 'failed', posts: 4, detail: /4 attempts/ },
  { behaviour: 'e502', state: 'failed', posts: 4 },
  { behaviour: 'e503', state: 'failed', posts: 4 },
  { behaviour: 'flaky1', state: OK, posts: 2 },
  { behaviour: 'flaky3', state: OK, posts: 4 },
  { behaviour: 'flaky4', state: 'failed', posts: 4 },
  { behaviour: 'slow', state: 'failed', posts: 4, detail: /timeout|attempts/ },
  { behaviour: 'trickle', state: 'failed', posts: 4, detail: /timeout|attempts/ },
  { behaviour: 'reset', state: 'failed', posts: 4 },
];

test(`one-click over HTTPS: ${MATRIX.length} sender behaviours`, { timeout: 180000 }, async () => {
  const t = await world(MATRIX.map((m) => ({ id: m.behaviour, url: `${sim.base}/b/${m.behaviour}/${m.behaviour}` })));
  const { created } = await createRequests(t.db, t.user.id, [...t.byCase.values()].map((i) => i.id), { source: 'web' });
  assert.equal(created.length, MATRIX.length);
  assert.ok(created.every((c) => c.method === 'one_click'));
  await runAll(t);
  const problems: string[] = [];
  for (const m of MATRIX) {
    const r = await finalState(t, t.byCase.get(m.behaviour)!.id);
    const hits = sim.hitsFor(m.behaviour);
    const posts = hits.filter((h) => h.method === 'POST');
    const why = `${m.behaviour}: state=${r.state} posts=${posts.length} detail="${r.detail}"`;
    if (r.state !== m.state) problems.push(`${why} (expected state ${m.state})`);
    if (posts.length !== m.posts) problems.push(`${why} (expected ${m.posts} POSTs)`);
    if (hits.some((h) => h.method !== 'POST')) problems.push(`${m.behaviour}: sent a ${hits.find((h) => h.method !== 'POST')!.method}, never allowed`);
    if (posts.some((h) => h.body !== 'List-Unsubscribe=One-Click' || h.headers['content-type'] !== 'application/x-www-form-urlencoded')) problems.push(`${m.behaviour}: wrong POST body or content type`);
    if (m.detail && !m.detail.test(r.detail)) problems.push(`${why} (detail should match ${m.detail})`);
    if (r.events.includes('unsubscribed')) problems.push(`${m.behaviour}: claimed "unsubscribed" without verification`);
    if (r.state === OK && !r.events.includes('request_submitted')) problems.push(`${m.behaviour}: skipped request_submitted`);
  }
  // The private-address redirect must never have been contacted (it isn't routable here anyway,
  // but the check proves the guard ran before any connection).
  assert.deepEqual(problems, []);
  await t.close();
});

test('TLS failures (untrusted certificate) fail fast without retrying', { timeout: 60000 }, async () => {
  const t = await world([{ id: 'badcert', url: `${sim.base}/b/ok200/badcert` }]);
  setUnsubscribeHttpOptions({ allowPrivateHosts: ['127.0.0.1'], timeoutMs: 1500 }); // no test CA: certificate is untrusted
  await createRequests(t.db, t.user.id, [t.byCase.get('badcert')!.id], { source: 'web' });
  await runAll(t);
  const r = await finalState(t, t.byCase.get('badcert')!.id);
  assert.equal(r.state, 'failed');
  assert.match(r.detail, /certificate/i);
  assert.equal(r.attempts, 1, 'a certificate error is permanent; no retries');
  assert.equal(sim.hitsFor('badcert').length, 0, 'nothing was sent over an untrusted connection');
  await t.close();
});

test('plain-HTTP one-click links are never POSTed in production mode', async () => {
  const t = await world([{ id: 'plainhttp', url: `${plain.base}/b/ok200/plainhttp` }]);
  const i = t.byCase.get('plainhttp')!;
  assert.equal(i.oneClick, false, 'parser refuses one-click over http');
  const { created } = await createRequests(t.db, t.user.id, [i.id], { source: 'web' });
  assert.equal(created[0].method, 'web', 'offered as a page for the user instead');
  await runAll(t);
  assert.equal((await finalState(t, i.id)).state, 'requires_manual_action');
  assert.equal(plain.hitsFor('plainhttp').length, 0);
  await t.close();
});

test('429 Retry-After is respected before the next attempt', async () => {
  const t = await world([{ id: 'ra', url: `${sim.base}/b/e429/ra` }]);
  await createRequests(t.db, t.user.id, [t.byCase.get('ra')!.id], { source: 'web' });
  await t.worker.drain();
  const [j] = await t.db.select().from(jobs).where(eq(jobs.type, 'unsubscribe'));
  assert.equal(j.status, 'queued');
  assert.ok(j.runAt.getTime() >= Date.now() + 900, 'waits at least the Retry-After second');
  await t.close();
});

// ---------- mailto ----------

async function mailtoWorld(mailto: string) {
  const t = await world([{ id: 'm', url: 'https://unused.example/u', mailto }]);
  // Mail-only sender: drop the web link and the one-click flag.
  await t.db.update(senderIdentities).set({ unsubHttp: null, oneClick: false });
  await t.db.update(preferences).set({ mailtoEnabled: true }).where(eq(preferences.userId, t.user.id));
  t.box.sendScope = true;
  return t;
}

test('mailto: message is well formed, including non-ASCII subjects', async () => {
  const t = await mailtoWorld('mailto:leave+x1@list.example?subject=D%C3%A9sinscription%20%E2%9C%93&body=Please%20remove%20me');
  await createRequests(t.db, t.user.id, [t.byCase.get('m')!.id], { source: 'web' });
  await runAll(t);
  assert.equal(t.box.sent.length, 1);
  const raw = t.box.sent[0];
  const [head, body] = raw.split('\r\n\r\n');
  const h = Object.fromEntries(head.split('\r\n').map((l) => [l.slice(0, l.indexOf(':')).toLowerCase(), l.slice(l.indexOf(':') + 2)]));
  assert.equal(h.to, 'leave+x1@list.example');
  assert.equal(h.from, t.account.email);
  assert.equal(Buffer.from(h.subject.replace(/^=\?UTF-8\?B\?|\?=$/g, ''), 'base64').toString('utf8'), 'Désinscription ✓');
  assert.match(h['message-id'], /^<[^@\s]+@[^>\s]+>$/);
  assert.ok(h.date && !Number.isNaN(Date.parse(h.date)));
  assert.equal(h['content-type'], 'text/plain; charset=UTF-8');
  assert.equal(body.trim(), 'Please remove me');
  assert.ok(!/\n(?<!\r\n)/.test(raw.replace(/\r\n/g, '')), 'CRLF line endings only');
  assert.equal((await finalState(t, t.byCase.get('m')!.id)).state, OK);
  await t.close();
});

test('mailto: an unclear send failure is reported, never resent', async () => {
  const t = await mailtoWorld('mailto:leave@list.example');
  t.box.sendFailures.push(new Error('socket hang up'));
  await createRequests(t.db, t.user.id, [t.byCase.get('m')!.id], { source: 'web' });
  await runAll(t);
  assert.equal(t.box.sendAttempts, 1, 'exactly one send attempt');
  const r = await finalState(t, t.byCase.get('m')!.id);
  assert.equal(r.state, 'failed');
  assert.match(r.detail, /may or may not/);
  await t.close();
});

test('mailto: rate limits wait, then send once', async () => {
  const t = await mailtoWorld('mailto:leave@list.example');
  t.box.sendFailures.push(new RateLimitError('slow down', 10));
  await createRequests(t.db, t.user.id, [t.byCase.get('m')!.id], { source: 'web' });
  await runAll(t);
  assert.equal(t.box.sent.length, 1);
  assert.equal(t.box.sendAttempts, 2);
  assert.equal((await finalState(t, t.byCase.get('m')!.id)).state, OK);
  await t.close();
});

test('mailto: revoked permission and revoked account are handled without sending', async () => {
  const t = await mailtoWorld('mailto:leave@list.example');
  t.box.sendFailures.push(new MissingScopeError('gone'));
  await createRequests(t.db, t.user.id, [t.byCase.get('m')!.id], { source: 'web' });
  await runAll(t);
  assert.equal((await finalState(t, t.byCase.get('m')!.id)).state, 'awaiting_approval');

  const t2 = await mailtoWorld('mailto:leave@list.example');
  t2.box.sendFailures.push(new ProviderAuthError('revoked'));
  await createRequests(t2.db, t2.user.id, [t2.byCase.get('m')!.id], { source: 'web' });
  await runAll(t2);
  const r = await finalState(t2, t2.byCase.get('m')!.id);
  assert.equal(r.state, 'failed');
  assert.match(r.detail, /reconnected; nothing was sent/);
  const [acct] = await t2.db.select().from(mailAccounts).where(eq(mailAccounts.id, t2.account.id));
  assert.equal(acct.status, 'reauth_required');
  assert.equal(t2.box.sent.length, 0);
  await t.close();
  await t2.close();
});

test('dry run: no method sends anything', async () => {
  config.unsubscribeMode = 'dry_run';
  const t = await world([{ id: 'dry1', url: `${sim.base}/b/ok200/dry1` }, { id: 'dry2', url: 'https://unused.example/u', mailto: 'mailto:leave@list.example' }]);
  await t.db.update(senderIdentities).set({ unsubHttp: null, oneClick: false }).where(eq(senderIdentities.id, t.byCase.get('dry2')!.id));
  await t.db.update(preferences).set({ mailtoEnabled: true }).where(eq(preferences.userId, t.user.id));
  t.box.sendScope = true;
  await createRequests(t.db, t.user.id, [...t.byCase.values()].map((i) => i.id), { source: 'web' });
  await runAll(t);
  config.unsubscribeMode = 'live';
  assert.equal(sim.hitsFor('dry1').length, 0);
  assert.equal(t.box.sendAttempts, 0);
  const states = await t.db.select({ s: unsubscribeRequests.state }).from(unsubscribeRequests)
    .where(inArray(unsubscribeRequests.identityId, [...t.byCase.values()].map((i) => i.id)));
  assert.deepEqual(states.map((s) => s.s), ['prepared', 'prepared']);
  await t.close();
});

// ---------- crash mid-send (in-flight marker) ----------

test('crash during an email send: reported as uncertain, never sent again', async () => {
  const t = await mailtoWorld('mailto:leave@list.example');
  const { created } = await createRequests(t.db, t.user.id, [t.byCase.get('m')!.id], { source: 'web' });
  // As if a previous worker set the marker, began sending, and the process died.
  await t.db.update(unsubscribeRequests).set({ state: 'processing', inFlightAt: new Date() }).where(eq(unsubscribeRequests.id, created[0].requestId));
  await runAll(t);
  const r = await finalState(t, t.byCase.get('m')!.id);
  assert.equal(r.state, 'failed');
  assert.match(r.detail, /may or may not have been sent/);
  assert.equal(t.box.sendAttempts, 0, 'not sent again');
  assert.equal(r.inFlightAt, null);
  await t.close();
});

test('crash during a one-click request: sent again once, with a note in the history', async () => {
  const t = await world([{ id: 'crash1', url: `${sim.base}/b/ok200/crash1` }]);
  const { created } = await createRequests(t.db, t.user.id, [t.byCase.get('crash1')!.id], { source: 'web' });
  await t.db.update(unsubscribeRequests).set({ state: 'processing', inFlightAt: new Date() }).where(eq(unsubscribeRequests.id, created[0].requestId));
  await runAll(t);
  const r = await finalState(t, t.byCase.get('crash1')!.id);
  assert.equal(r.state, OK);
  assert.match(r.detail, /interrupted mid-request; sending again/);
  assert.equal(sim.hitsFor('crash1').length, 1);
  assert.equal(r.inFlightAt, null);
  await t.close();
});

test('a submitted request with no verification job is repaired', async () => {
  const t = await world([{ id: 'orphan', url: `${sim.base}/b/ok200/orphan` }]);
  const { created } = await createRequests(t.db, t.user.id, [t.byCase.get('orphan')!.id], { source: 'web' });
  await t.db.update(unsubscribeRequests).set({ state: 'request_submitted', submittedAt: new Date(), updatedAt: new Date(Date.now() - 10 * 60000) }).where(eq(unsubscribeRequests.id, created[0].requestId));
  await t.db.delete(jobs);
  const { reconcileRequests } = await import('../src/modules/unsubscribe/engine.ts');
  await reconcileRequests(t.db);
  const r = await finalState(t, t.byCase.get('orphan')!.id);
  assert.equal(r.state, OK);
  const verify = await t.db.select().from(jobs).where(eq(jobs.type, 'verify'));
  assert.equal(verify.length, 1);
  await t.close();
});
