import { test } from 'node:test';
import assert from 'node:assert/strict';
import { eq } from 'drizzle-orm';
import { config } from '../src/config.ts';
import { domainThrottle, jobs, mailAccounts, preferences, senderIdentities, unsubscribeEvents, unsubscribeRequests } from '../src/db/schema.ts';
import { enqueueScan } from '../src/modules/discovery/scan.ts';
import { cancelRequest, confirmManual, createRequests, reconcileRequests, requeueAwaitingApproval } from '../src/modules/unsubscribe/engine.ts';
import { setup, addSender, senderServer } from './helpers.ts';

config.unsubscribeMode = 'live';
const DAY = 86400000;

async function scanned(o: { oneClickUrl?: string; mailto?: string; webUrl?: string; perMonth?: number; protectedSubject?: boolean; endDaysAgo?: number }) {
  const t = await setup();
  const uris = [o.oneClickUrl ?? o.webUrl, o.mailto].filter(Boolean).map((u) => `<${u}>`).join(', ');
  addSender(t.box, {
    from: o.protectedSubject ? 'statements@bank.example' : 'news@list.example', listId: o.protectedSubject ? undefined : 'news.list.example',
    subject: o.protectedSubject ? 'Your monthly statement is ready' : 'Weekly deals',
    count: Math.round((o.perMonth ?? 8) * 3), days: 90, endDaysAgo: o.endDaysAgo ?? 1, unsub: uris || undefined, oneClick: Boolean(o.oneClickUrl),
  });
  await enqueueScan(t.db, t.account, 'full');
  await t.worker.drain();
  const [identity] = await t.db.select().from(senderIdentities).where(eq(senderIdentities.accountId, t.account.id));
  // Header parsing only marks HTTPS as one-click; the local test server is HTTP, so set it directly.
  if (o.oneClickUrl) await t.db.update(senderIdentities).set({ oneClick: true, unsubHttp: o.oneClickUrl }).where(eq(senderIdentities.id, identity.id));
  return { ...t, identity };
}

const requestFor = async (t: { db: Awaited<ReturnType<typeof setup>>['db'] }, id: string) =>
  (await t.db.select().from(unsubscribeRequests).where(eq(unsubscribeRequests.id, id)))[0];
const eventsFor = async (t: { db: Awaited<ReturnType<typeof setup>>['db'] }, id: string) =>
  (await t.db.select().from(unsubscribeEvents).where(eq(unsubscribeEvents.requestId, id)).orderBy(unsubscribeEvents.id)).map((e) => e.toState);

test('RFC 8058: exactly one POST with the one-click body, never a GET; success is not claimed early', async () => {
  const srv = await senderServer(() => ({ status: 200 }));
  const t = await scanned({ oneClickUrl: `${srv.base}/unsub?u=42` });
  const { created } = await createRequests(t.db, t.user.id, [t.identity.id], { source: 'web' });
  assert.equal(created[0].method, 'one_click');
  await t.worker.drain();
  assert.equal(srv.hits.length, 1);
  assert.equal(srv.hits[0].method, 'POST');
  assert.equal(srv.hits[0].url, '/unsub?u=42');
  assert.equal(srv.hits[0].body, 'List-Unsubscribe=One-Click');
  assert.equal(srv.hits[0].headers['content-type'], 'application/x-www-form-urlencoded');
  const r = await requestFor(t, created[0].requestId);
  assert.equal(r.state, 'verification_pending', 'a 200 is "submitted, verifying", not "unsubscribed"');
  assert.equal(r.httpStatus, 200);
  assert.deepEqual(await eventsFor(t, r.id), ['queued', 'processing', 'request_submitted', 'verification_pending']);
  const [verify] = await t.db.select().from(jobs).where(eq(jobs.type, 'verify'));
  assert.ok(verify.runAt.getTime() > Date.now() + 5 * DAY, 'verification scheduled days later');
  await srv.close(); await t.close();
});

test('transient sender errors are retried with backoff, then succeed', async () => {
  const srv = await senderServer((_h, n) => ({ status: n < 3 ? 503 : 200 }));
  const t = await scanned({ oneClickUrl: `${srv.base}/u` });
  const { created } = await createRequests(t.db, t.user.id, [t.identity.id], { source: 'web' });
  for (let i = 0; i < 3; i++) {
    await t.db.update(jobs).set({ runAt: new Date() }).where(eq(jobs.type, 'unsubscribe'));
    await t.db.delete(domainThrottle);
    await t.worker.drain();
  }
  assert.equal(srv.hits.length, 3);
  assert.ok(srv.hits.every((h) => h.method === 'POST'));
  assert.equal((await requestFor(t, created[0].requestId)).state, 'verification_pending');
  await srv.close(); await t.close();
});

test('retries stop at the attempt limit and report failure', async () => {
  const srv = await senderServer(() => ({ status: 500 }));
  const t = await scanned({ oneClickUrl: `${srv.base}/u` });
  const { created } = await createRequests(t.db, t.user.id, [t.identity.id], { source: 'web' });
  for (let i = 0; i < 6; i++) {
    await t.db.update(jobs).set({ runAt: new Date() }).where(eq(jobs.type, 'unsubscribe'));
    await t.db.delete(domainThrottle);
    await t.worker.drain();
  }
  assert.equal(srv.hits.length, 4, 'maxAttempts = 4');
  const r = await requestFor(t, created[0].requestId);
  assert.equal(r.state, 'failed');
  assert.match(r.lastError ?? '', /500/);
  await srv.close(); await t.close();
});

test('a 404 fails immediately without retrying', async () => {
  const srv = await senderServer(() => ({ status: 404 }));
  const t = await scanned({ oneClickUrl: `${srv.base}/u` });
  const { created } = await createRequests(t.db, t.user.id, [t.identity.id], { source: 'web' });
  await t.worker.drain();
  assert.equal(srv.hits.length, 1);
  assert.equal((await requestFor(t, created[0].requestId)).state, 'failed');
  await srv.close(); await t.close();
});

test('CAPTCHA and confirmation pages are handed to the user', async () => {
  for (const [body, state] of [['<div class="g-recaptcha"></div>', 'requires_manual_action'], ['Click the button below to confirm your unsubscribe', 'awaiting_confirmation']]) {
    const srv = await senderServer(() => ({ status: 200, body }));
    const t = await scanned({ oneClickUrl: `${srv.base}/u` });
    const { created } = await createRequests(t.db, t.user.id, [t.identity.id], { source: 'web' });
    await t.worker.drain();
    assert.equal((await requestFor(t, created[0].requestId)).state, state);
    await srv.close(); await t.close();
  }
});

test('307 redirects keep the POST; 302 counts as received without following', async () => {
  const srv = await senderServer((h) => h.url === '/first' ? { status: 307, headers: { location: '/second' } } : { status: 200 });
  const t = await scanned({ oneClickUrl: `${srv.base}/first` });
  await createRequests(t.db, t.user.id, [t.identity.id], { source: 'web' });
  await t.worker.drain();
  assert.deepEqual(srv.hits.map((h) => `${h.method} ${h.url}`), ['POST /first', 'POST /second']);
  await srv.close(); await t.close();

  const srv2 = await senderServer(() => ({ status: 302, headers: { location: '/thanks' } }));
  const t2 = await scanned({ oneClickUrl: `${srv2.base}/u` });
  const { created } = await createRequests(t2.db, t2.user.id, [t2.identity.id], { source: 'web' });
  await t2.worker.drain();
  assert.equal(srv2.hits.length, 1);
  assert.equal((await requestFor(t2, created[0].requestId)).state, 'verification_pending');
  await srv2.close(); await t2.close();
});

test('invalid or unsafe destinations fail without any request', async () => {
  const t = await scanned({ oneClickUrl: 'http://127.0.0.1:1/u' });
  // Turn the test override off for this request only.
  const { setUnsubscribeHttpOptions } = await import('../src/modules/unsubscribe/engine.ts');
  await t.db.update(senderIdentities).set({ unsubHttp: 'https://169.254.169.254/latest/meta-data' }).where(eq(senderIdentities.id, t.identity.id));
  const { created } = await createRequests(t.db, t.user.id, [t.identity.id], { source: 'web' });
  setUnsubscribeHttpOptions({});
  await t.worker.drain();
  const r = await requestFor(t, created[0].requestId);
  assert.equal(r.state, 'failed');
  assert.match((await t.db.select().from(unsubscribeEvents).where(eq(unsubscribeEvents.requestId, r.id))).at(-1)!.detail!, /private address/);
  setUnsubscribeHttpOptions({ allowPrivate: true, allowHttp: true });
  await t.close();
});

test('duplicate execution is prevented across interfaces and concurrent calls', async () => {
  const srv = await senderServer(() => ({ status: 200 }));
  const t = await scanned({ oneClickUrl: `${srv.base}/u` });
  const [web, ext] = await Promise.all([
    createRequests(t.db, t.user.id, [t.identity.id], { source: 'web' }),
    createRequests(t.db, t.user.id, [t.identity.id], { source: 'extension' }),
  ]);
  assert.equal(web.created.length + ext.created.length, 1);
  assert.equal(web.skipped.length + ext.skipped.length, 1);
  const again = await createRequests(t.db, t.user.id, [t.identity.id, t.identity.id], { source: 'web' });
  assert.equal(again.created.length, 0);
  await t.worker.drain();
  assert.equal(srv.hits.length, 1);
  await srv.close(); await t.close();
});

test('protected and whitelisted senders are excluded unless explicitly overridden', async () => {
  const t = await scanned({ protectedSubject: true, webUrl: 'https://bank.example/prefs' });
  assert.equal(t.identity.isProtected, true);
  const blocked = await createRequests(t.db, t.user.id, [t.identity.id], { source: 'web' });
  assert.equal(blocked.created.length, 0);
  assert.match(blocked.skipped[0].reason!, /Banking statement/);
  const allowed = await createRequests(t.db, t.user.id, [t.identity.id], { source: 'web', allowProtected: true });
  assert.equal(allowed.created.length, 1);
  await t.close();

  const t2 = await scanned({ oneClickUrl: 'https://x.example/u' });
  await t2.db.update(senderIdentities).set({ whitelisted: true }).where(eq(senderIdentities.id, t2.identity.id));
  const w = await createRequests(t2.db, t2.user.id, [t2.identity.id], { source: 'web', allowProtected: true });
  assert.equal(w.created.length, 0);
  assert.equal(w.skipped[0].reason, 'whitelisted');
  await t2.close();
});

test('dry-run mode validates but sends nothing', async () => {
  config.unsubscribeMode = 'dry_run';
  const srv = await senderServer(() => ({ status: 200 }));
  const t = await scanned({ oneClickUrl: `${srv.base}/u` });
  const { created } = await createRequests(t.db, t.user.id, [t.identity.id], { source: 'web' });
  await t.worker.drain();
  config.unsubscribeMode = 'live';
  assert.equal(srv.hits.length, 0);
  const r = await requestFor(t, created[0].requestId);
  assert.equal(r.state, 'prepared');
  assert.equal(r.dryRun, true);
  await srv.close(); await t.close();
});

test('mailto waits for send permission, then sends a well-formed message once', async () => {
  const t = await scanned({ mailto: 'mailto:leave@list.example?subject=Unsubscribe%20please' });
  await t.db.update(preferences).set({ mailtoEnabled: true }).where(eq(preferences.userId, t.user.id));
  const { created } = await createRequests(t.db, t.user.id, [t.identity.id], { source: 'web' });
  assert.equal(created[0].method, 'mailto');
  await t.worker.drain();
  assert.equal((await requestFor(t, created[0].requestId)).state, 'awaiting_approval');
  assert.equal(t.box.sent.length, 0);

  t.box.sendScope = true;
  await requeueAwaitingApproval(t.db, t.account.id);
  await t.worker.drain();
  assert.equal(t.box.sent.length, 1);
  const raw = t.box.sent[0];
  assert.match(raw, /^From: box-.*@test\.example\r\nTo: leave@list\.example\r\nSubject: Unsubscribe please\r\n/);
  assert.equal((await requestFor(t, created[0].requestId)).state, 'verification_pending');
  await t.close();
});

test('web-only senders become a manual task the user can complete', async () => {
  const t = await scanned({ webUrl: 'https://list.example/preferences' });
  const { created } = await createRequests(t.db, t.user.id, [t.identity.id], { source: 'web' });
  assert.equal(created[0].method, 'web');
  await t.worker.drain();
  let r = await requestFor(t, created[0].requestId);
  assert.equal(r.state, 'requires_manual_action');
  assert.equal(await confirmManual(t.db, r, 'done'), true);
  r = await requestFor(t, r.id);
  assert.equal(r.state, 'verification_pending');
  assert.equal(await cancelRequest(t.db, r), true);
  assert.equal((await requestFor(t, r.id)).state, 'cancelled');
  await t.close();
});

async function submittedDaysAgo(days: number, perMonth: number, mailAfter = 0) {
  const srv = await senderServer(() => ({ status: 200 }));
  const t = await scanned({ oneClickUrl: `${srv.base}/u`, perMonth, endDaysAgo: days + 1 });
  const { created } = await createRequests(t.db, t.user.id, [t.identity.id], { source: 'web' });
  await t.worker.drain();
  const submittedAt = new Date(Date.now() - days * DAY);
  // Backdate both the submission and its due date, as if the days had really passed.
  await t.db.update(unsubscribeRequests).set({ submittedAt, verifyAfter: new Date(submittedAt.getTime() + 7 * DAY) }).where(eq(unsubscribeRequests.id, created[0].requestId));
  if (mailAfter) addSender(t.box, { from: 'news@list.example', listId: 'news.list.example', count: mailAfter, days: 1 });
  await t.db.update(jobs).set({ runAt: new Date() }).where(eq(jobs.type, 'verify'));
  await t.db.update(mailAccounts).set({ lastSyncAt: new Date(0) });
  await t.worker.drain();
  const r = await requestFor(t, created[0].requestId);
  await srv.close(); await t.close();
  return r;
}

test('verification: silence from a frequent sender is verified', async () => {
  const r = await submittedDaysAgo(9, 20);
  assert.equal(r.state, 'unsubscribed');
});

test('verification: a rare sender cannot be verified and says so', async () => {
  const r = await submittedDaysAgo(9, 0.5);
  assert.equal(r.state, 'verification_unavailable');
});

test('verification: mail after the grace period means it did not work', async () => {
  const r = await submittedDaysAgo(9, 20, 2);
  assert.equal(r.state, 'failed');
});

test('requests stranded by a crashed worker are reconciled, not left hanging', async () => {
  const t = await scanned({ oneClickUrl: 'https://x.example/u' });
  const { created } = await createRequests(t.db, t.user.id, [t.identity.id], { source: 'web' });
  // Simulate: job exhausted by repeated crashes, request still "processing".
  await t.db.update(jobs).set({ status: 'failed' }).where(eq(jobs.type, 'unsubscribe'));
  await t.db.update(unsubscribeRequests).set({ state: 'processing', updatedAt: new Date(Date.now() - 10 * 60000) }).where(eq(unsubscribeRequests.id, created[0].requestId));
  assert.equal(await reconcileRequests(t.db), 1);
  const r = await requestFor(t, created[0].requestId);
  assert.equal(r.state, 'failed');
  const [i] = await t.db.select().from(senderIdentities).where(eq(senderIdentities.id, t.identity.id));
  assert.equal(i.unsubState, 'failed', 'identity mirrors the request state');
  await t.close();
});

test('bulk run spaces requests to one sender domain', async () => {
  const srv = await senderServer(() => ({ status: 200 }));
  const t = await setup();
  for (let k = 0; k < 3; k++) addSender(t.box, { from: `l${k}@same.example`, listId: `l${k}.same.example`, count: 6, unsub: '<https://same.example/u>', oneClick: true });
  await enqueueScan(t.db, t.account, 'full');
  await t.worker.drain();
  const ids = await t.db.select().from(senderIdentities).where(eq(senderIdentities.accountId, t.account.id));
  await t.db.update(senderIdentities).set({ unsubHttp: `${srv.base}/u` }).where(eq(senderIdentities.accountId, t.account.id));
  await createRequests(t.db, t.user.id, ids.map((i) => i.id), { source: 'web' });
  await t.worker.drain();
  assert.equal(srv.hits.length, 1, 'only one request per domain per spacing window');
  const deferred = await t.db.select().from(jobs).where(eq(jobs.status, 'queued'));
  assert.equal(deferred.filter((j) => j.type === 'unsubscribe').length, 2);
  await srv.close(); await t.close();
});
