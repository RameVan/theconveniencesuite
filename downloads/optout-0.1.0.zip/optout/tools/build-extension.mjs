// Builds the extension for a given server origin.
//   node tools/build-extension.mjs https://unsubscriber.example.com
// Output: extension-dist/ (load unpacked, or zip it for the Chrome Web Store).
import { cpSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

const origin = (process.argv[2] ?? '').replace(/\/$/, '');
if (!/^https:\/\/[a-z0-9.-]+(:\d+)?$/i.test(origin) && !/^http:\/\/localhost:\d+$/.test(origin)) {
  console.error('Usage: node tools/build-extension.mjs https://your-server.example (https required, except http://localhost)');
  process.exit(1);
}
const root = resolve(import.meta.dirname, '..');
const src = resolve(root, 'extension');
const out = resolve(root, 'extension-dist');
rmSync(out, { recursive: true, force: true });
cpSync(src, out, { recursive: true });

const manifest = JSON.parse(readFileSync(resolve(src, 'manifest.json'), 'utf8'));
manifest.host_permissions = [`${origin}/*`];
manifest.externally_connectable = { matches: [`${origin}/*`] };
writeFileSync(resolve(out, 'manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`);
writeFileSync(resolve(out, 'config.js'), `export const API_ORIGIN = ${JSON.stringify(origin)};\n`);
console.log(`Built extension for ${origin} in ${out}`);
