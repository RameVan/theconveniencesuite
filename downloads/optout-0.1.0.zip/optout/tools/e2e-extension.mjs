// End-to-end check of the extension against a running development server:
// web sign-in -> link extension -> popup lists senders -> unsubscribe from the popup ->
// the web app's API sees the same request and refuses a duplicate.
//
//   (server running with DEV_FAKE_PROVIDER=true on http://localhost:8790)
//   node tools/e2e-extension.mjs
//
// Needs Chrome; set CHROME_PATH if it isn't in the default location.
import { spawn } from 'node:child_process';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { StringDecoder } from 'node:string_decoder';

const ORIGIN = 'http://localhost:8790';
const chromePath = process.env.CHROME_PATH || 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const extDir = resolve(import.meta.dirname, '../extension');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

class Browser {
  async launch() {
    this.profile = await mkdtemp(join(tmpdir(), 'unsubscriber-e2e-'));
    this.pending = new Map();
    this.nextId = 1;
    this.proc = spawn(chromePath, ['--headless=new', '--remote-debugging-pipe', '--enable-unsafe-extension-debugging',
      `--user-data-dir=${this.profile}`, '--no-first-run', '--no-default-browser-check', 'about:blank'],
    { stdio: ['ignore', 'ignore', 'ignore', 'pipe', 'pipe'] });
    const decoder = new StringDecoder('utf8');
    let buffer = '';
    this.proc.stdio[4].on('data', (chunk) => {
      buffer += decoder.write(chunk);
      let end;
      while ((end = buffer.indexOf('\0')) >= 0) {
        const msg = JSON.parse(buffer.slice(0, end));
        buffer = buffer.slice(end + 1);
        const w = msg.id && this.pending.get(msg.id);
        if (!w) continue;
        this.pending.delete(msg.id);
        msg.error ? w.reject(new Error(msg.error.message)) : w.resolve(msg.result);
      }
    });
    this.proc.stdio[3].on('error', () => {});
    this.extensionId = (await this.send('Extensions.loadUnpacked', { path: extDir })).id;
  }
  send(method, params = {}, sessionId) {
    const id = this.nextId++;
    this.proc.stdio[3].write(JSON.stringify({ id, method, params, sessionId }) + '\0');
    return new Promise((res, rej) => {
      this.pending.set(id, { resolve: res, reject: rej });
      setTimeout(() => this.pending.has(id) && (this.pending.delete(id), rej(new Error(`${method} timed out`))), 30000);
    });
  }
  async open(url) {
    const { targetId } = await this.send('Target.createTarget', { url });
    const { sessionId } = await this.send('Target.attachToTarget', { targetId, flatten: true });
    return sessionId;
  }
  async navigate(sessionId, url) { await this.send('Page.navigate', { url }, sessionId); }
  async eval(sessionId, expression) {
    const { result, exceptionDetails } = await this.send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true }, sessionId);
    if (exceptionDetails) throw new Error(exceptionDetails.exception?.description || exceptionDetails.text);
    return result.value;
  }
  async waitFor(sessionId, expression, what, ms = 15000) {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      try { const v = await this.eval(sessionId, expression); if (v) return v; } catch { /* page still loading */ }
      await sleep(250);
    }
    throw new Error(`timed out waiting for ${what}`);
  }
  async close() {
    if (this.proc?.pid && process.platform === 'win32') {
      await new Promise((r) => spawn('taskkill', ['/pid', String(this.proc.pid), '/T', '/F'], { stdio: 'ignore' }).on('exit', r).on('error', r));
    } else this.proc?.kill();
    await sleep(500);
    await rm(this.profile, { recursive: true, force: true }).catch(() => {});
  }
}

const results = [];
const check = (name, ok, detail = '') => { results.push({ name, ok }); console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? `  (${detail})` : ''}`); };
const webApi = (path, init = {}) => `fetch(${JSON.stringify(ORIGIN + path)}, { method: ${JSON.stringify(init.method ?? 'GET')}, credentials: 'include', headers: { 'x-requested-with': 'unsubscriber', 'content-type': 'application/json' }${init.body ? `, body: ${JSON.stringify(JSON.stringify(init.body))}` : ''} }).then(r => r.json())`;

const b = new Browser();
try {
  await b.launch();
  check('extension loads', Boolean(b.extensionId), b.extensionId);

  // 1. Sign in to the web app (development fixture user).
  const web = await b.open(`${ORIGIN}/login`);
  await b.waitFor(web, `location.origin === ${JSON.stringify(ORIGIN)} && document.readyState === "complete"`, 'login page');
  await b.eval(web, `fetch('/auth/dev-login', { method: 'POST' }).then(r => r.ok)`);
  const me = await b.eval(web, webApi('/api/me'));
  check('web session established', Boolean(me.user?.email), me.user?.email);

  // 2. Link the extension through the web app.
  await b.navigate(web, `${ORIGIN}/link-extension?ext=${b.extensionId}`);
  const linked = await b.waitFor(web, `document.body.innerText.includes('extension is connected') || (document.body.innerText.match(/Failed|did not|Open this page/) || [false])[0]`, 'link result');
  check('extension linked via externally_connectable', linked === true, String(linked));

  // 3. Popup shows senders from the shared backend.
  const popup = await b.open(`chrome-extension://${b.extensionId}/popup.html`);
  const count = await b.waitFor(popup, `document.querySelectorAll('#senders li').length`, 'sender list');
  check('popup lists suggested senders', count > 0, `${count} rows`);
  const target = await b.eval(popup, `(() => { const li = [...document.querySelectorAll('#senders li')].find(l => l.querySelector('button')); return li && li.querySelector('.name').textContent; })()`);

  // 4. Unsubscribe one sender from the popup (with its confirmation step).
  await b.eval(popup, `[...document.querySelectorAll('#senders li')].find(l => l.querySelector('.name').textContent === ${JSON.stringify(target)}).querySelector('button').click()`);
  await b.waitFor(popup, `!document.getElementById('confirm-go').disabled`, 'confirmation');
  const title = await b.eval(popup, `document.getElementById('confirm-title').textContent`);
  check('popup shows a confirmation first', title.includes(target), title);
  await b.eval(popup, `document.getElementById('confirm-go').click()`);
  await b.waitFor(popup, `!document.getElementById('view-main').hidden`, 'back to main view');

  // 5. The web app sees the same request, marked as coming from the extension.
  await sleep(1500);
  const hist = await b.eval(web, webApi('/api/unsubscribe/requests?limit=50'));
  const req = hist.items.find((r) => (r.fromName || r.fromAddress) === target && r.source === 'extension');
  check('web app sees the extension request', Boolean(req), req ? `${req.state}` : 'missing');

  // 6. A duplicate from the web app is refused while it is active, or it is already finished.
  const sub = await b.eval(web, webApi(`/api/subscriptions/${req?.identityId}`));
  const dup = await b.eval(web, webApi('/api/unsubscribe', { method: 'POST', body: { ids: [req?.identityId], confirm: true } }));
  const active = ['queued', 'processing', 'verification_pending', 'requires_manual_action', 'awaiting_confirmation', 'awaiting_approval'].includes(sub.unsubState);
  check('no duplicate execution across interfaces', active ? dup.created?.length === 0 : true, active ? `skipped: ${dup.skipped?.[0]?.reason}` : `state ${sub.unsubState} (finished, re-run allowed)`);

  // 7. A change made in the web app shows up in the extension.
  await b.eval(web, webApi(`/api/subscriptions/${req?.identityId}`, { method: 'PATCH', body: { whitelisted: true } }));
  await b.eval(popup, 'location.reload()');
  await b.waitFor(popup, `document.querySelectorAll('#senders li').length`, 'reloaded list');
  await b.eval(popup, `document.getElementById('search').value = ${JSON.stringify(target)}; document.getElementById('search').dispatchEvent(new Event('input'))`);
  await sleep(1200);
  const keptSub = await b.eval(popup, `document.querySelector('#senders li .sub')?.textContent ?? ''`);
  check('web change visible in extension', keptSub.includes('kept'), keptSub);
  await b.eval(web, webApi(`/api/subscriptions/${req?.identityId}`, { method: 'PATCH', body: { whitelisted: false } }));
} catch (e) {
  check('run', false, e.message);
} finally {
  await b.close();
}
const failed = results.filter((r) => !r.ok).length;
console.log(`\n${results.length - failed}/${results.length} checks passed`);
process.exit(failed ? 1 : 0);
