import { NavLink, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Activity, Inbox, LayoutDashboard, LogOut, Mail, Settings as SettingsIcon, ShieldAlert } from 'lucide-react';
import { api, post } from './api.ts';
import { useJobs, useMe, useTheme } from './hooks.ts';
import { BrandMark, Spinner } from './components/ui.tsx';
import { Login } from './pages/Login.tsx';
import { Overview } from './pages/Overview.tsx';
import { Subscriptions } from './pages/Subscriptions.tsx';
import { Accounts } from './pages/Accounts.tsx';
import { ActivityPage } from './pages/Activity.tsx';
import { Settings } from './pages/Settings.tsx';
import { LinkExtension } from './pages/LinkExtension.tsx';
import { Breaches } from './pages/Breaches.tsx';

const NAV = [
  { to: '/', label: 'Overview', icon: LayoutDashboard, end: true },
  { to: '/subscriptions', label: 'Subscriptions', icon: Inbox },
  { to: '/accounts', label: 'Accounts', icon: Mail },
  { to: '/activity', label: 'Activity', icon: Activity },
  { to: '/breaches', label: 'Breaches', icon: ShieldAlert },
  { to: '/settings', label: 'Settings', icon: SettingsIcon },
];

export function App() {
  const me = useMe();
  const loc = useLocation();
  useTheme(me.data?.preferences.theme);

  if (me.isLoading) return <div className="login"><Spinner /></div>;
  if (!me.data) {
    if (loc.pathname !== '/login') return <Navigate to={`/login${loc.search}`} replace />;
    return <Login />;
  }
  if (loc.pathname === '/login') return <Navigate to="/" replace />;
  return <Shell />;
}

function Shell() {
  const qc = useQueryClient();
  const me = useMe().data!;
  useJobs();
  const needs = useQuery<{ counts: Record<string, number> }>({ queryKey: ['requests', 'counts'], queryFn: () => api('/api/unsubscribe/requests?limit=1') });
  const c = needs.data?.counts ?? {};
  const needsYou = (c.requires_manual_action ?? 0) + (c.awaiting_confirmation ?? 0) + (c.awaiting_approval ?? 0);

  const logout = async () => {
    await post('/auth/logout');
    qc.clear();
    window.location.href = '/login';
  };

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand"><BrandMark className="brand-mark" /><span>Opt Out<small>Convenience Suite</small></span></div>
        <nav className="nav">
          {NAV.map(({ to, label, icon: Icon, end }) => (
            <NavLink key={to} to={to} end={end}>
              <Icon size={17} />{label}
              {to === '/activity' && needsYou > 0 && <span className="count" title="Waiting for you">{needsYou}</span>}
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-foot">
          <div className="small truncate" title={me.user.email}><b>{me.user.name ?? 'Signed in'}</b><br /><span className="muted">{me.user.email}</span></div>
          <button className="btn sm ghost" onClick={logout} style={{ justifyContent: 'flex-start', paddingLeft: 0 }}><LogOut size={14} />Sign out</button>
        </div>
      </aside>
      <main className="main">
        <Routes>
          <Route path="/" element={<Overview />} />
          <Route path="/subscriptions" element={<Subscriptions />} />
          <Route path="/accounts" element={<Accounts />} />
          <Route path="/activity" element={<ActivityPage />} />
          <Route path="/breaches" element={<Breaches />} />
          <Route path="/settings" element={<Settings onLogout={logout} />} />
          <Route path="/link-extension" element={<LinkExtension />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <nav className="mobile-bar" aria-label="Main">
        {NAV.map(({ to, label, icon: Icon, end }) => (
          <NavLink key={to} to={to} end={end}><Icon size={20} />{label}</NavLink>
        ))}
      </nav>
    </div>
  );
}
