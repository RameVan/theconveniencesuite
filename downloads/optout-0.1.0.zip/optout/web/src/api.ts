export class ApiError extends Error {
  status: number;
  constructor(status: number, msg: string) { super(msg); this.status = status; }
}

export async function api<T = unknown>(path: string, init: { method?: string; body?: unknown } = {}): Promise<T> {
  const res = await fetch(path, {
    method: init.method ?? 'GET',
    credentials: 'same-origin',
    headers: {
      'x-requested-with': 'unsubscriber',
      ...(init.body !== undefined ? { 'content-type': 'application/json' } : {}),
    },
    body: init.body !== undefined ? JSON.stringify(init.body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(res.status, (data as { error?: string }).error ?? `HTTP ${res.status}`);
  return data as T;
}

export const post = <T = unknown>(path: string, body: unknown = {}) => api<T>(path, { method: 'POST', body });
export const patch = <T = unknown>(path: string, body: unknown) => api<T>(path, { method: 'PATCH', body });
export const del = <T = unknown>(path: string, body?: unknown) => api<T>(path, { method: 'DELETE', body });

export type Method = 'one_click' | 'mailto' | 'web' | 'manual';

export interface Subscription {
  id: string; accountId: string; accountEmail: string; fromAddress: string; fromName: string | null; domain: string;
  listId: string | null; lastSubject: string | null; messageCount: number; firstSeenAt: string; lastSeenAt: string;
  unsubHttp: string | null; unsubMailto: string | null; oneClick: boolean;
  categoryId: string | null; categoryName: string | null; categorySlug: string | null; categoryProtected: boolean | null; categorySource: string;
  confidence: number; kind: 'marketing' | 'transactional' | 'personal' | 'unknown';
  isProtected: boolean; protectionReason: string | null; protectionSource: string | null; whitelisted: boolean;
  unsubState: string | null; unsubStateAt: string | null; perMonth: number; method: Method; eligible: boolean;
}

export interface UnsubEvent { id: number; at: string; fromState: string | null; toState: string; detail: string | null }
export interface UnsubRequest {
  id: string; identityId: string; accountId: string; method: Method; target: string | null; state: string; label: string;
  source: string; dryRun: boolean; attempts: number; httpStatus: number | null; lastError: string | null;
  submittedAt: string | null; verifyAfter: string | null; verifiedAt: string | null; createdAt: string; updatedAt: string;
  fromName?: string | null; fromAddress?: string; domain?: string; accountEmail?: string; events: UnsubEvent[];
}

export interface Breach {
  name: string; title: string; domain: string; breachDate: string | null; addedDate: string | null; pwnCount: number;
  dataClasses: string[]; description: string; logoPath: string | null; isVerified: boolean; isSpamList: boolean;
  isFabricated: boolean; source: 'hibp' | 'xposedornot' | 'fixture';
}
export interface BreachSender { id: string; fromName: string | null; fromAddress: string; domain: string; messageCount: number; unsubState: string | null }
export interface BreachOverview {
  source: 'hibp' | 'xposedornot' | 'fixture';
  provider: { name: string; url: string; host: string; attribution: string };
  catalogue: { count: number; updatedAt: string | null };
  lookupAvailable: boolean;
  consent: boolean;
  accounts: { email: string; checkedAt: string | null; status: string | null; error: string | null; breaches: { firstSeenAt: string; breach: Breach; senders: string[] }[] }[];
  senderBreaches: { breach: Breach; senders: BreachSender[] }[];
}

export interface SubscriptionDetail extends Subscription {
  breaches: Breach[];
  byMonth: { month: string; n: number }[];
  requests: UnsubRequest[];
}

export interface Category { id: string; slug: string; name: string; isSystem: boolean; isProtected: boolean; count: number }

export interface Account {
  id: string; email: string; provider: 'gmail' | 'fake'; status: string; statusDetail: string | null; scopes: string[]; canSend: boolean;
  messagesScanned: number; lastSyncAt: string | null; fullScanCompletedAt: string | null; createdAt: string; identities: number;
  scan: { id: string; status: string; progress: ScanProgress | null; attempts: number; lastError: string | null; runAt: string } | null;
  lastScan: { status: string; progress: ScanProgress | null; last_error: string | null; finished_at: string } | null;
}
export interface ScanProgress { mode: string; phase: string; processed: number; added: number; estimate?: number; complete?: boolean; limitReached?: boolean; note?: string }

export interface Preferences { theme: 'system' | 'light' | 'dark'; verificationDays: number; mailtoEnabled: boolean; scanMaxMessages: number; breachConsent: boolean }
export interface Me {
  user: { id: string; email: string; name: string | null; avatarUrl: string | null };
  preferences: Preferences; unsubscribeMode: 'live' | 'dry_run'; bulkMax: number;
}

export interface Eligibility { id: string; eligible: boolean; reason?: string; method?: Method; needsOverride?: boolean; fromName?: string | null; fromAddress?: string; domain?: string; messageCount?: number }
export interface Preview { total: number; tooMany: boolean; bulkMax: number; eligible: Eligibility[]; excluded: Eligibility[]; methods: Record<string, number>; dryRun: boolean }
export interface Filter {
  search?: string; categoryId?: string; accountId?: string; method?: string; status?: string; kind?: string;
  excludeWhitelisted?: boolean; excludeProtected?: boolean;
}

export function filterQuery(f: Filter & { sort?: string; order?: string; limit?: number; offset?: number }): string {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(f)) if (v !== undefined && v !== '' && v !== false) p.set(k, String(v));
  return p.toString();
}
