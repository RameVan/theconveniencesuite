import { useState } from 'react';
import type { Breach } from '../api.ts';
import { Avatar, n } from './ui.tsx';

const SEVERE = /password|credit card|bank|social security|passport|security questions|government issued/i;

/** Practical next steps for the kinds of data that leaked. */
export function adviceFor(classes: string[]): string[] {
  const has = (re: RegExp) => classes.some((c) => re.test(c));
  const out: string[] = [];
  if (has(/password/i)) out.push('Change your password there and anywhere you reused it; turn on two-factor sign-in.');
  if (has(/credit card|bank|payment/i)) out.push('Check your card and bank statements, and ask your bank about a new card.');
  if (has(/phone/i)) out.push('Expect scam texts and calls that mention this company.');
  if (has(/physical address|dates of birth|government|passport|social security/i)) out.push('Watch for identity fraud; consider a credit freeze where available.');
  if (has(/security questions/i)) out.push('Change any security questions and answers you used there.');
  if (!out.length) out.push('Be wary of emails that look like they come from this company; phishing often follows a breach.');
  return out;
}

export function BreachCard({ breach: b, children }: { breach: Breach; children?: React.ReactNode }) {
  const [more, setMore] = useState(false);
  const [logoFailed, setLogoFailed] = useState(false);
  const year = b.breachDate?.slice(0, 4);
  return (
    <div className="breach">
      {b.logoPath && !logoFailed
        ? <img className="breach-logo" src={b.logoPath} alt="" onError={() => setLogoFailed(true)} referrerPolicy="no-referrer" loading="lazy" />
        : <Avatar name={b.title} domain={b.domain || b.name} size={36} />}
      <div className="grow stack" style={{ gap: 6 }}>
        <div className="row wrap" style={{ gap: 6 }}>
          <b>{b.title}</b>
          {b.domain && <span className="small muted">{b.domain}</span>}
          {b.source === 'fixture' && <span className="badge warn">fixture</span>}
          {!b.isVerified && <span className="badge" title="Have I Been Pwned could not fully verify this breach">unverified</span>}
          {b.isSpamList && <span className="badge" title="A spam list rather than a hack">spam list</span>}
        </div>
        <p className="small muted">{year ? `Breached ${new Date(b.breachDate!).toLocaleDateString(undefined, { month: 'long', year: 'numeric' })}` : 'Date unknown'} · {n(b.pwnCount)} accounts</p>
        <div className="row wrap" style={{ gap: 4 }}>
          {b.dataClasses.map((c) => <span key={c} className={`badge ${SEVERE.test(c) ? 'bad' : ''}`}>{c}</span>)}
        </div>
        {b.description && (
          <p className="small muted">
            {more || b.description.length <= 180 ? b.description : `${b.description.slice(0, 180)}… `}
            {b.description.length > 180 && <button className="btn ghost sm" style={{ height: 'auto', padding: 0 }} onClick={() => setMore(!more)}>{more ? ' less' : 'more'}</button>}
          </p>
        )}
        {children}
      </div>
    </div>
  );
}
