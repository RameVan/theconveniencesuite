import { useQueryClient } from '@tanstack/react-query';
import { ExternalLink } from 'lucide-react';
import { post, type UnsubRequest } from '../api.ts';
import { invalidateAll } from '../hooks.ts';
import { Notice, useToast } from './ui.tsx';

/** The next step a user can take on a request, with the honest explanation of where it stands. */
export function RequestActions({ request: r, compact }: { request: UnsubRequest; compact?: boolean }) {
  const qc = useQueryClient();
  const toast = useToast();
  const act = async (path: string, body: unknown, msg: string) => {
    try { await post(`/api/unsubscribe/requests/${r.id}/${path}`, body); toast(msg); invalidateAll(qc); } catch (e) { toast((e as Error).message, true); }
  };
  const last = r.events.at(-1)?.detail;
  const manual = ['requires_manual_action', 'awaiting_confirmation'].includes(r.state);
  const webTarget = r.target && /^https?:\/\//.test(r.target) ? r.target : null;

  const buttons = (
    <div className="row wrap" style={{ marginTop: compact ? 0 : 8 }}>
      {manual && webTarget && <a className="btn sm primary" href={webTarget} target="_blank" rel="noopener noreferrer nofollow">Open unsubscribe page <ExternalLink size={12} /></a>}
      {(manual || r.state === 'awaiting_approval') && <button className="btn sm" onClick={() => act('manual', { outcome: 'done' }, 'Marked as done; verifying over the next days')}>I've unsubscribed</button>}
      {manual && <button className="btn sm" onClick={() => act('manual', { outcome: 'failed' }, 'Marked as not working')}>It didn't work</button>}
      {r.state === 'awaiting_approval' && <a className="btn sm primary" href={`/auth/google/send-scope?accountId=${r.accountId}`}>Allow sending</a>}
      {['queued', 'awaiting_approval', 'requires_manual_action', 'awaiting_confirmation', 'verification_pending'].includes(r.state) &&
        <button className="btn sm ghost" onClick={() => act('cancel', {}, 'Cancelled')}>Cancel</button>}
      {['failed', 'cancelled', 'prepared', 'verification_unavailable'].includes(r.state) &&
        <button className="btn sm" onClick={() => act('retry', {}, 'Queued again')}>Try again</button>}
    </div>
  );
  if (compact) return buttons;
  const kind = r.state === 'failed' ? 'bad' : r.state === 'unsubscribed' ? 'ok' : manual || r.state === 'awaiting_approval' ? 'warn' : 'info';
  return <Notice kind={kind}><p>{last ?? r.label}</p>{buttons}</Notice>;
}
