import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { ExternalLink, Shield, ShieldOff, Star } from 'lucide-react';
import { api, patch, type SubscriptionDetail } from '../api.ts';
import { invalidateAll, useCategories } from '../hooks.ts';
import { Avatar, Drawer, METHOD_HELP, MethodBadge, Notice, Spinner, StateBadge, Switch, ago, displayName, fmtDate, n, useToast } from './ui.tsx';
import { UnsubscribeDialog } from './UnsubscribeDialog.tsx';
import { RequestActions } from './RequestActions.tsx';
import { BreachCard, adviceFor } from './BreachCard.tsx';

export function SubscriptionDrawer({ id, onClose }: { id: string; onClose: () => void }) {
  const qc = useQueryClient();
  const toast = useToast();
  const cats = useCategories().data ?? [];
  const q = useQuery<SubscriptionDetail>({ queryKey: ['subscription', id], queryFn: () => api(`/api/subscriptions/${id}`) });
  const [confirm, setConfirm] = useState(false);
  const [unprotect, setUnprotect] = useState(false);
  const s = q.data;

  const update = async (body: Record<string, unknown>, msg: string) => {
    try { await patch(`/api/subscriptions/${id}`, body); toast(msg); invalidateAll(qc); } catch (e) { toast((e as Error).message, true); }
  };

  if (!s) return <Drawer onClose={onClose} head={<Spinner />}><div className="skeleton" /></Drawer>;
  const maxBar = Math.max(1, ...s.byMonth.map((b) => b.n));
  const latest = s.requests[0];

  return (
    <Drawer onClose={onClose} head={
      <div className="row" style={{ gap: 12 }}>
        <Avatar name={displayName(s)} domain={s.domain} size={42} />
        <div className="grow">
          <h2 style={{ fontSize: 17 }} className="truncate">{displayName(s)}</h2>
          <p className="muted small truncate">{s.fromAddress}</p>
        </div>
      </div>
    }>
      <div className="row wrap">
        <StateBadge state={s.unsubState} />
        {s.isProtected && <span className="badge warn"><Shield size={12} />{s.protectionReason ?? 'Protected'}</span>}
        {s.whitelisted && <span className="badge accent"><Star size={12} />Kept</span>}
        <span className="chip">{s.kind}</span>
      </div>

      {s.unsubState !== 'unsubscribed' && (
        <div className="row wrap">
          <button className="btn primary" onClick={() => setConfirm(true)} disabled={s.whitelisted || ['queued', 'processing', 'verification_pending', 'request_submitted'].includes(s.unsubState ?? '')}>
            Unsubscribe
          </button>
          <span className="small muted">{METHOD_HELP[s.method]}</span>
        </div>
      )}
      {latest && <RequestActions request={latest} />}

      {s.breaches.length > 0 && (
        <section className="section">
          <h3>Data breaches</h3>
          {s.breaches.map((b) => (
            <div key={b.name} className="notice bad" style={{ display: 'block' }}>
              <BreachCard breach={b}>
                <ul className="small advice" style={{ color: 'inherit' }}>{adviceFor(b.dataClasses).map((t) => <li key={t}>{t}</li>)}</ul>
              </BreachCard>
            </div>
          ))}
          <p className="small faint">Breach data: {s.breaches[0].source === 'xposedornot' ? 'XposedOrNot' : s.breaches[0].source === 'fixture' ? 'fixture data' : 'Have I Been Pwned (CC BY 4.0)'}. Matched on the sender's domain, so it shows the company was breached, not that your data was in it.</p>
        </section>
      )}

      <section className="section">
        <h3>Volume</h3>
        <div className="bars" aria-label="Emails per month">
          {s.byMonth.map((b) => <div key={b.month} style={{ height: `${(b.n / maxBar) * 100}%` }} title={`${b.month}: ${b.n}`} />)}
        </div>
        <dl className="kv">
          <dt>Emails received</dt><dd>{n(s.messageCount)}</dd>
          <dt>Per month</dt><dd>≈ {s.perMonth}</dd>
          <dt>First / latest</dt><dd>{fmtDate(s.firstSeenAt)} · {ago(s.lastSeenAt)}</dd>
          <dt>Latest subject</dt><dd>{s.lastSubject ?? '—'}</dd>
        </dl>
      </section>

      <section className="section">
        <h3>Identity</h3>
        <dl className="kv">
          <dt>Domain</dt><dd>{s.domain}</dd>
          <dt>Mailing list</dt><dd className="mono">{s.listId ?? 'none (grouped by sender address)'}</dd>
          <dt>Account</dt><dd>{s.accountEmail}</dd>
          <dt>Unsubscribe</dt><dd className="row wrap"><MethodBadge method={s.method} />
            {s.unsubHttp && <a className="small" href={s.unsubHttp} target="_blank" rel="noopener noreferrer nofollow">open page <ExternalLink size={11} /></a>}
            {s.unsubMailto && <span className="small mono">{s.unsubMailto.replace(/^mailto:/, '').split('?')[0]}</span>}
          </dd>
        </dl>
      </section>

      <section className="section">
        <h3>Classification</h3>
        <div className="row">
          <select className="select grow" value={s.categoryId ?? ''} onChange={(e) => update({ categoryId: e.target.value || null }, 'Category updated')} aria-label="Category">
            <option value="">Uncategorised</option>
            {cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <span className="small muted" title="How sure the rules are">{s.categorySource === 'user' ? 'set by you' : `${Math.round(s.confidence * 100)}% sure`}</span>
        </div>
        <div className="setting" style={{ padding: '6px 0', borderBottom: 0 }}>
          <div className="grow"><p><b>Keep this sender</b></p><p className="small muted">Whitelisted senders are never unsubscribed in bulk.</p></div>
          <Switch checked={s.whitelisted} onChange={(v) => update({ whitelisted: v }, v ? 'Sender kept' : 'Removed from kept senders')} label="Keep this sender" />
        </div>
        <div className="setting" style={{ padding: '6px 0', borderBottom: 0 }}>
          <div className="grow"><p><b>Protected</b></p><p className="small muted">{s.isProtected ? `${s.protectionReason ?? 'Protected'} (${s.protectionSource === 'user' ? 'by you' : 'detected automatically'})` : 'Protect important mail from bulk unsubscribe.'}</p></div>
          {s.isProtected
            ? <button className="btn sm" onClick={() => setUnprotect(true)}><ShieldOff size={13} />Remove</button>
            : <button className="btn sm" onClick={() => update({ protected: true }, 'Sender protected')}><Shield size={13} />Protect</button>}
        </div>
        {unprotect && (
          <Notice kind="warn">
            <p>Removing protection lets this sender be included in bulk unsubscribes. {s.protectionReason ? `It looks like: ${s.protectionReason.toLowerCase()}.` : ''}</p>
            <div className="row" style={{ marginTop: 8 }}>
              <button className="btn sm danger solid" onClick={() => { setUnprotect(false); update({ protected: false, confirmUnprotect: true }, 'Protection removed'); }}>Remove protection</button>
              <button className="btn sm" onClick={() => setUnprotect(false)}>Keep it</button>
            </div>
          </Notice>
        )}
      </section>

      {s.requests.length > 0 && (
        <section className="section">
          <h3>History</h3>
          {s.requests.map((r) => (
            <div key={r.id} className="stack" style={{ gap: 6 }}>
              <div className="row small"><StateBadge state={r.state} /><span className="muted">{r.method.replace('_', '-')} · from {r.source} · {fmtDate(r.createdAt)}</span></div>
              <div className="timeline">
                {r.events.map((e, i) => (
                  <div key={e.id} className={`ev${i === r.events.length - 1 ? ' last' : ''}`}>
                    <b>{e.toState.replace(/_/g, ' ')}</b> <span className="faint small">{fmtDate(e.at)}</span>
                    {e.detail && <p className="small muted">{e.detail}</p>}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </section>
      )}
      {confirm && <UnsubscribeDialog selection={{ ids: [s.id], label: s.fromAddress }} onClose={() => setConfirm(false)} />}
    </Drawer>
  );
}
