import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { ChevronDown, ChevronRight, ShieldAlert } from 'lucide-react';
import { post, type Filter, type Method, type Preview } from '../api.ts';
import { invalidateAll } from '../hooks.ts';
import { METHOD_HELP, METHOD_LABEL, Modal, Notice, Spinner, displayName, useToast } from './ui.tsx';

export interface Selection { ids?: string[]; filter?: Filter; label: string }

const ORDER: Method[] = ['one_click', 'mailto', 'web', 'manual'];

export function UnsubscribeDialog({ selection, onClose, onDone }: { selection: Selection; onClose: () => void; onDone?: () => void }) {
  const qc = useQueryClient();
  const toast = useToast();
  const [allowProtected, setAllowProtected] = useState(false);
  const [understood, setUnderstood] = useState(false);
  const [showExcluded, setShowExcluded] = useState(false);
  const [busy, setBusy] = useState(false);

  const preview = useQuery<Preview>({
    queryKey: ['preview', selection.ids, selection.filter, allowProtected],
    queryFn: () => post('/api/unsubscribe/preview', { ids: selection.ids, filter: selection.filter, allowProtected }),
    staleTime: 0,
  });
  const p = preview.data;
  const protectedCount = p?.excluded.filter((e) => e.needsOverride).length ?? 0;
  const overrideNeeded = allowProtected && !understood;
  const count = p?.eligible.length ?? 0;

  const run = async () => {
    if (!p) return;
    setBusy(true);
    try {
      const r = await post<{ created: unknown[]; skipped: { reason?: string }[] }>('/api/unsubscribe', {
        ids: p.eligible.map((e) => e.id), allowProtected, confirm: true,
      });
      toast(`${r.created.length} unsubscribe request${r.created.length === 1 ? '' : 's'} queued${r.skipped.length ? `, ${r.skipped.length} skipped` : ''}. They keep running if you close this page.`);
      invalidateAll(qc);
      onDone?.();
      onClose();
    } catch (e) {
      toast((e as Error).message, true);
      setBusy(false);
    }
  };

  return (
    <Modal
      title={count === 1 && p ? `Unsubscribe from ${displayName(p.eligible[0])}?` : `Unsubscribe from ${count} senders?`}
      sub={selection.label}
      onClose={onClose}
      footer={<>
        <button className="btn" onClick={onClose}>Cancel</button>
        <button className="btn primary" onClick={run} disabled={!p || count === 0 || busy || overrideNeeded || p.tooMany}>
          {busy ? <Spinner /> : null}{p?.dryRun ? `Run dry run for ${count}` : `Unsubscribe from ${count}`}
        </button>
      </>}
    >
      {preview.isLoading && <div className="row muted"><Spinner /> Checking each sender…</div>}
      {preview.error && <Notice kind="bad">{(preview.error as Error).message}</Notice>}
      {p && <>
        {p.dryRun && (
          <Notice kind="info"><b>Dry-run mode.</b> Requests are validated but nothing is sent to senders. An administrator enables live mode with <span className="mono">UNSUBSCRIBE_MODE=live</span>.</Notice>
        )}
        {p.tooMany && <Notice kind="warn">This selection has more than {p.bulkMax} senders. Narrow it down; large runs are split for safety.</Notice>}
        {count > 0 && (
          <div className="stack" style={{ gap: 8 }}>
            {ORDER.filter((m) => p.methods[m]).map((m) => (
              <div key={m} className="row" style={{ alignItems: 'flex-start' }}>
                <span className="badge accent" style={{ minWidth: 34, justifyContent: 'center' }}>{p.methods[m]}</span>
                <div><b>{METHOD_LABEL[m]}</b><p className="small muted">{METHOD_HELP[m]}</p></div>
              </div>
            ))}
          </div>
        )}
        {count === 0 && <Notice kind="warn">None of the selected senders can be unsubscribed right now. See the reasons below.</Notice>}
        <p className="small muted">Results are reported honestly: an accepted request is shown as <i>submitted</i>, and only counts as <i>unsubscribed</i> once mail from the sender stops.</p>

        {p.excluded.length > 0 && (
          <div className="card" style={{ boxShadow: 'none' }}>
            <button className="btn ghost" style={{ width: '100%', justifyContent: 'flex-start', height: 40 }} onClick={() => setShowExcluded(!showExcluded)} aria-expanded={showExcluded}>
              {showExcluded ? <ChevronDown size={15} /> : <ChevronRight size={15} />}{p.excluded.length} not included
            </button>
            {showExcluded && (
              <div style={{ maxHeight: 220, overflowY: 'auto', borderTop: '1px solid var(--border)' }}>
                {p.excluded.map((e) => (
                  <div key={e.id} className="row small" style={{ padding: '7px 14px', borderBottom: '1px solid var(--border)' }}>
                    <span className="grow truncate">{displayName(e)}</span>
                    <span className={`badge ${e.needsOverride ? 'warn' : ''}`}>{e.reason}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {(protectedCount > 0 || allowProtected) && (
          <div className="card card-pad stack" style={{ boxShadow: 'none', gap: 10 }}>
            <label className="row" style={{ alignItems: 'flex-start', cursor: 'pointer' }}>
              <input type="checkbox" className="check" checked={allowProtected} onChange={(e) => { setAllowProtected(e.target.checked); setUnderstood(false); }} style={{ marginTop: 2 }} />
              <span><b>Also include protected senders</b><br /><span className="small muted">Bank statements, security alerts, receipts, bookings and similar mail are excluded by default.</span></span>
            </label>
            {allowProtected && (
              <label className="row notice warn" style={{ cursor: 'pointer' }}>
                <ShieldAlert size={16} />
                <input type="checkbox" className="check" checked={understood} onChange={(e) => setUnderstood(e.target.checked)} />
                <span>I understand I may stop receiving important messages from these senders.</span>
              </label>
            )}
          </div>
        )}
      </>}
    </Modal>
  );
}
