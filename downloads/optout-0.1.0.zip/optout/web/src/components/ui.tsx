import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { AlertTriangle, CheckCircle2, Info, X } from 'lucide-react';
import type { Method } from '../api.ts';

// ---------- toasts ----------
type Toast = { id: number; text: string; bad?: boolean };
const ToastCtx = createContext<(text: string, bad?: boolean) => void>(() => {});
export const useToast = () => useContext(ToastCtx);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Toast[]>([]);
  const push = useCallback((text: string, bad?: boolean) => {
    const id = Date.now() + Math.random();
    setItems((x) => [...x, { id, text, bad }]);
    setTimeout(() => setItems((x) => x.filter((t) => t.id !== id)), bad ? 6000 : 3500);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="toast-wrap" role="status" aria-live="polite">
        {items.map((t) => <div key={t.id} className={`toast${t.bad ? ' bad' : ''}`}>{t.text}</div>)}
      </div>
    </ToastCtx.Provider>
  );
}

// ---------- overlays ----------
function useEscape(onClose: () => void) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [onClose]);
}

export function Modal({ title, onClose, children, footer, sub }: { title: string; sub?: ReactNode; onClose: () => void; children: ReactNode; footer: ReactNode }) {
  useEscape(onClose);
  return (
    <>
      <div className="overlay" onClick={onClose} />
      <div className="modal" role="dialog" aria-modal="true" aria-label={title}>
        <div className="modal-head row">
          <div className="grow"><h2 style={{ fontSize: 17 }}>{title}</h2>{sub && <p className="muted small" style={{ marginTop: 4 }}>{sub}</p>}</div>
          <button className="btn ghost icon" onClick={onClose} aria-label="Close"><X size={18} /></button>
        </div>
        <div className="modal-body">{children}</div>
        <div className="modal-foot">{footer}</div>
      </div>
    </>
  );
}

export function Drawer({ onClose, head, children }: { onClose: () => void; head: ReactNode; children: ReactNode }) {
  useEscape(onClose);
  return (
    <>
      <div className="overlay" onClick={onClose} />
      <aside className="drawer" role="dialog" aria-modal="true">
        <div className="drawer-head">
          <div className="grow">{head}</div>
          <button className="btn ghost icon" onClick={onClose} aria-label="Close"><X size={18} /></button>
        </div>
        <div className="drawer-body">{children}</div>
      </aside>
    </>
  );
}

export function Notice({ kind, children }: { kind: 'warn' | 'info' | 'bad' | 'ok'; children: ReactNode }) {
  const Icon = kind === 'ok' ? CheckCircle2 : kind === 'info' ? Info : AlertTriangle;
  return <div className={`notice ${kind}`}><Icon size={16} /><div>{children}</div></div>;
}

export function Switch({ checked, onChange, label, disabled }: { checked: boolean; onChange: (v: boolean) => void; label: string; disabled?: boolean }) {
  return (
    <label className="switch" title={label}>
      <input type="checkbox" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} aria-label={label} />
      <span />
    </label>
  );
}

/** The app icon (same artwork as the favicon and the extension icon). */
export function BrandMark({ className }: { className?: string }) {
  return <img className={className} src="/favicon.svg" alt="" width={32} height={32} />;
}

export function Spinner() { return <span className="spinner" aria-label="Loading" />; }

// ---------- sender avatar ----------
function hue(s: string): number { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) % 360; return h; }

export function Avatar({ name, domain, size = 32 }: { name: string; domain: string; size?: number }) {
  const [failed, setFailed] = useState(false);
  const logos = readLogoPref();
  const letter = (name.replace(/[^\p{L}\p{N}]/gu, '')[0] ?? '?').toUpperCase();
  return (
    <div className="avatar" style={{ width: size, height: size, background: `hsl(${hue(domain)} 55% 48%)` }} aria-hidden>
      {logos && !failed
        ? <img src={`https://icons.duckduckgo.com/ip3/${encodeURIComponent(domain)}.ico`} alt="" onError={() => setFailed(true)} loading="lazy" referrerPolicy="no-referrer" />
        : letter}
    </div>
  );
}

const LOGO_KEY = 'ux.logos';
export function readLogoPref(): boolean { try { return localStorage.getItem(LOGO_KEY) === '1'; } catch { return false; } }
export function writeLogoPref(v: boolean): void { try { localStorage.setItem(LOGO_KEY, v ? '1' : '0'); } catch { /* storage unavailable */ } }

// ---------- status ----------
const STATE: Record<string, { label: string; cls: string }> = {
  queued: { label: 'Queued', cls: 'info' },
  processing: { label: 'Processing', cls: 'info' },
  request_submitted: { label: 'Submitted', cls: 'info' },
  verification_pending: { label: 'Submitted, verifying', cls: 'info' },
  awaiting_confirmation: { label: 'Needs confirmation', cls: 'warn' },
  awaiting_approval: { label: 'Needs permission', cls: 'warn' },
  requires_manual_action: { label: 'Needs you', cls: 'warn' },
  unsubscribed: { label: 'Unsubscribed', cls: 'ok' },
  verification_unavailable: { label: 'Sent, unverifiable', cls: 'ok' },
  failed: { label: 'Failed', cls: 'bad' },
  cancelled: { label: 'Cancelled', cls: '' },
  prepared: { label: 'Dry run', cls: '' },
};
export function StateBadge({ state }: { state: string | null }) {
  if (!state) return <span className="faint small">—</span>;
  const s = STATE[state] ?? { label: state, cls: '' };
  return <span className={`badge ${s.cls}`}>{s.label}</span>;
}

export const METHOD_LABEL: Record<Method, string> = {
  one_click: 'One-click', mailto: 'Email', web: 'Web page', manual: 'Manual',
};
export function MethodBadge({ method }: { method: Method }) {
  return <span className={`chip`} title={METHOD_HELP[method]}>{METHOD_LABEL[method]}</span>;
}
export const METHOD_HELP: Record<Method, string> = {
  one_click: 'One-click (RFC 8058): the server sends the sender a single secure unsubscribe request for you',
  mailto: 'An unsubscribe email is sent from your Gmail account (needs send permission)',
  web: 'The sender only offers a web page; you finish there in one click or two',
  manual: 'No unsubscribe link in the headers; instructions are provided',
};

// ---------- formatting ----------
export function ago(iso: string | null | undefined): string {
  if (!iso) return 'never';
  const s = (Date.now() - Date.parse(iso)) / 1000;
  if (s < 0) return `in ${Math.round(-s / 86400)}d`;
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  if (s < 86400) return `${Math.round(s / 3600)}h ago`;
  if (s < 86400 * 45) return `${Math.round(s / 86400)}d ago`;
  return new Date(iso).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
}
export const fmtDate = (iso: string | null | undefined) => (iso ? new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }) : '—');
export const n = (x: number) => x.toLocaleString();
export const displayName = (s: { fromName?: string | null; fromAddress?: string; domain?: string }) => s.fromName || s.fromAddress || s.domain || 'Unknown sender';
