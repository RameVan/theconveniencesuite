import { useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { api, ApiError, type Account, type Category, type Me } from './api.ts';

export function useMe() {
  return useQuery<Me | null>({
    queryKey: ['me'],
    queryFn: async () => {
      try { return await api<Me>('/api/me'); } catch (e) { if (e instanceof ApiError && e.status === 401) return null; throw e; }
    },
    staleTime: 30000,
  });
}

export function usePublicConfig() {
  return useQuery<{ googleConfigured: boolean; devLogin: boolean; unsubscribeMode: string }>({
    queryKey: ['public-config'], queryFn: () => api('/api/public/config'), staleTime: Infinity,
  });
}

interface JobsSummary { summary: Record<string, Record<string, number>>; scans: { id: string; status: string; accountId: string }[] }

/** Polls fast while background work is running, slowly otherwise, and refreshes data as it lands. */
export function useJobs() {
  const qc = useQueryClient();
  const q = useQuery<JobsSummary>({
    queryKey: ['jobs'],
    queryFn: () => api('/api/jobs'),
    refetchInterval: (query) => {
      const s = query.state.data?.summary ?? {};
      const busy = Object.values(s).some((m) => (m.running ?? 0) + (m.queued ?? 0) > 0);
      return busy ? 2000 : 15000;
    },
  });
  const summary = q.data?.summary ?? {};
  const busy = Object.values(summary).some((m) => (m.running ?? 0) + (m.queued ?? 0) > 0);
  // While busy, refresh on every poll so a running scan fills the list live.
  const busyKey = busy ? String(q.dataUpdatedAt) : JSON.stringify(summary);
  useEffect(() => {
    if (!q.data) return;
    qc.invalidateQueries({ queryKey: ['subscriptions'] });
    qc.invalidateQueries({ queryKey: ['overview'] });
    qc.invalidateQueries({ queryKey: ['accounts'] });
    qc.invalidateQueries({ queryKey: ['requests'] });
    qc.invalidateQueries({ queryKey: ['subscription'] });
    qc.invalidateQueries({ queryKey: ['breaches'] });
  }, [busyKey, qc, q.data]);
  return q;
}

export const useAccounts = () => useQuery<Account[]>({ queryKey: ['accounts'], queryFn: () => api('/api/accounts') });
export const useCategories = () => useQuery<Category[]>({ queryKey: ['categories'], queryFn: () => api('/api/categories') });

/** Applies the theme preference to the document. */
export function useTheme(theme: string | undefined) {
  useEffect(() => {
    const el = document.documentElement;
    if (!theme || theme === 'system') el.removeAttribute('data-theme');
    else el.setAttribute('data-theme', theme);
  }, [theme]);
}

export function invalidateAll(qc: ReturnType<typeof useQueryClient>) {
  for (const k of ['subscriptions', 'subscription', 'overview', 'accounts', 'requests', 'jobs', 'categories', 'me', 'breaches']) qc.invalidateQueries({ queryKey: [k] });
}
