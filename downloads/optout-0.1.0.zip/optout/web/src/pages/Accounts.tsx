import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import { FlaskConical, Mail, Pause, Play, Plus, RefreshCw, Send, Trash2, X } from 'lucide-react';
import { del, post, type Account } from '../api.ts';
import { invalidateAll, useAccounts, usePublicConfig } from '../hooks.ts';
import { Modal, Notice, Spinner, ago, n, useToast } from '../components/ui.tsx';

const CALLBACK: Record<string, [kind: 'ok' | 'bad' | 'warn', text: string]> = {
  google_not_configured: ['bad', 'Google OAuth is not configured on this server. See docs/SETUP.md.'],
  metadata_scope_denied: ['warn', 'Gmail access was not granted, so nothing can be scanned. Connect again and allow "View your email message metadata".'],
  no_refresh_token: ['warn', 'Google did not return a long-lived token. Remove Opt Out at myaccount.google.com/permissions, then connect again.'],
  access_denied: ['warn', 'Connection cancelled.'],
  wrong_account: ['warn', 'You chose a different Google account than the mailbox you were granting permission for. Try again and pick the same account.'],
  invalid_state: ['bad', 'That sign-in link expired or was opened in a different browser. Please try again.'],
  not_found: ['bad', 'That account was not found.'],
  oauth_failed: ['bad', 'Connecting failed. Please try again.'],
};

export function Accounts() {
  const accounts = useAccounts();
  const cfg = usePublicConfig().data;
  const [params, setParams] = useSearchParams();
  const err = params.get('error');
  const connected = params.get('connected');
  const [removing, setRemoving] = useState<Account | null>(null);

  return (
    <>
      <div className="page-head">
        <div className="grow"><p className="eyebrow">Mailboxes</p><h1>Accounts</h1><p className="sub">Connected mailboxes, scans and permissions.</p></div>
        <a className="btn primary" href="/auth/google/connect" aria-disabled={cfg && !cfg.googleConfigured}
          onClick={(e) => { if (cfg && !cfg.googleConfigured) e.preventDefault(); }}><Plus size={15} />Connect Gmail</a>
      </div>
      <div className="stack" style={{ gap: 16 }}>
        {(err || connected) && (
          <div className="row">
            <div className="grow">
              {err ? <Notice kind={CALLBACK[err]?.[0] ?? 'bad'}>{CALLBACK[err]?.[1] ?? `Something went wrong (${err}).`}</Notice>
                : <Notice kind="ok">{params.get('scope') === 'send' ? 'Send permission granted. Waiting email unsubscribes are being sent.' : 'Account connected. Scanning has started and continues in the background, even if you close this tab.'}</Notice>}
            </div>
            <button className="btn ghost icon" onClick={() => setParams({}, { replace: true })} aria-label="Dismiss"><X size={16} /></button>
          </div>
        )}
        {cfg && !cfg.googleConfigured && <Notice kind="warn">Google OAuth credentials are missing on the server, so Gmail accounts can't be connected yet. Follow docs/SETUP.md.</Notice>}
        {accounts.isLoading && <div className="card card-pad"><Spinner /></div>}
        {accounts.data?.length === 0 && (
          <div className="card empty"><Mail size={32} /><p>No accounts connected yet.</p></div>
        )}
        {accounts.data?.map((a) => <AccountCard key={a.id} account={a} onRemove={() => setRemoving(a)} />)}

        <div className="card card-pad stack small muted" style={{ gap: 8 }}>
          <h2 style={{ color: 'var(--text)' }}>What Opt Out can access</h2>
          <p><b>Email metadata</b> (<span className="mono">gmail.metadata</span>): sender, subject, date, labels and list headers such as List-Unsubscribe. Message bodies and attachments can't be read with this permission.</p>
          <p><b>Send email</b> (<span className="mono">gmail.send</span>, optional): only requested if you turn on email unsubscribes. Used solely to send the unsubscribe messages a sender asks for.</p>
          <p>Disconnecting revokes Google access immediately and deletes everything derived from that mailbox.</p>
        </div>
      </div>
      {removing && <RemoveDialog account={removing} onClose={() => setRemoving(null)} />}
    </>
  );
}

function AccountCard({ account: a, onRemove }: { account: Account; onRemove: () => void }) {
  const qc = useQueryClient();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const scan = async (mode: string) => {
    setBusy(true);
    try {
      const r = await post<{ created: boolean; mode: string }>(`/api/accounts/${a.id}/scan`, { mode });
      toast(r.created ? (mode === 'full' ? 'Full rescan started' : 'Sync started') : `A ${r.mode} scan is already queued`);
      invalidateAll(qc);
    } catch (e) { toast((e as Error).message, true); }
    setBusy(false);
  };
  const fixture = a.provider === 'fake';
  return (
    <div className="card">
      <div className="card-head" style={{ flexWrap: 'wrap' }}>
        <Mail size={18} color="var(--accent)" />
        <div className="grow">
          <div className="row"><h2 className="truncate">{a.email}</h2>
            {fixture && <span className="badge warn" title="Development fixture data, not a real mailbox"><FlaskConical size={12} />Fixture mailbox</span>}
            {a.status === 'active' ? <span className="badge ok">Connected</span> : <span className="badge bad">Needs reconnecting</span>}
          </div>
          <p className="small muted">{n(a.identities)} senders · {n(a.messagesScanned)} messages scanned · synced {ago(a.lastSyncAt)}{a.fullScanCompletedAt ? '' : ' · full scan not finished'}</p>
        </div>
        <div className="row wrap">
          {a.status !== 'active'
            ? <a className="btn primary sm" href={`/auth/google/connect?hint=${encodeURIComponent(a.email)}`}>Reconnect</a>
            : <>
              <button className="btn sm" onClick={() => scan('incremental')} disabled={busy || Boolean(a.scan)}><RefreshCw size={13} />Sync now</button>
              <button className="btn sm" onClick={() => scan('full')} disabled={busy || Boolean(a.scan)}>Full rescan</button>
            </>}
          <button className="btn sm ghost danger" onClick={onRemove}><Trash2 size={13} />Disconnect</button>
        </div>
      </div>
      <div className="card-pad stack" style={{ gap: 12 }}>
        {a.statusDetail && <Notice kind="bad">{a.statusDetail}</Notice>}
        {a.scan ? <ScanStatus account={a} /> : a.lastScan && (
          <p className="small muted">
            Last scan {a.lastScan.status === 'succeeded' ? 'finished' : a.lastScan.status} {ago(a.lastScan.finished_at)}
            {a.lastScan.progress?.note ? ` · ${a.lastScan.progress.note}` : ''}
            {a.lastScan.status === 'failed' && a.lastScan.last_error ? ` · ${a.lastScan.last_error}` : ''}
          </p>
        )}
        {!fixture && a.status === 'active' && (
          <div className="row wrap small">
            <Send size={14} color="var(--text-3)" />
            {a.canSend
              ? <span className="muted">Email unsubscribes allowed (gmail.send granted).</span>
              : <><span className="muted grow">Email unsubscribes need send permission. Only requested if you want it.</span><a className="btn sm" href={`/auth/google/send-scope?accountId=${a.id}`}>Allow sending</a></>}
          </div>
        )}
      </div>
    </div>
  );
}

export function ScanStatus({ account: a }: { account: Account }) {
  const qc = useQueryClient();
  const toast = useToast();
  const s = a.scan!;
  const p = s.progress;
  const control = async (action: string) => {
    try { await post(`/api/accounts/${a.id}/scan-control`, { action }); invalidateAll(qc); toast(action === 'pause' ? 'Paused' : action === 'resume' ? 'Resumed' : 'Scan cancelled'); } catch (e) { toast((e as Error).message, true); }
  };
  const mode = (p?.mode ?? 'scan') === 'partial' ? 'Quick scan (recent mail only)' : p?.mode === 'incremental' ? 'Syncing new mail' : 'Scanning mailbox';
  const pct = p?.estimate && p.mode !== 'incremental' ? Math.min(100, Math.round((p.processed / p.estimate) * 100)) : null;
  const waiting = s.status === 'queued' && new Date(s.runAt).getTime() > Date.now() + 1000;
  return (
    <div className="stack" style={{ gap: 8 }}>
      <div className="row wrap">
        <b className="grow">{mode} · {a.email}</b>
        <span className="small muted">
          {s.status === 'paused' ? 'Paused' : waiting ? `Waiting (${s.lastError ?? 'retrying'})` : s.status === 'queued' ? 'Queued' : `${n(p?.processed ?? 0)} messages${p?.estimate ? ` of ~${n(p.estimate)}` : ''} · ${n(p?.added ?? 0)} new`}
        </span>
        {s.status === 'paused'
          ? <button className="btn sm" onClick={() => control('resume')}><Play size={13} />Resume</button>
          : <button className="btn sm" onClick={() => control('pause')}><Pause size={13} />Pause</button>}
        <button className="btn sm ghost" onClick={() => control('cancel')}>Cancel</button>
      </div>
      <div className={`progress${pct === null && s.status === 'running' ? ' indeterminate' : ''}`}><div style={{ width: `${pct ?? 0}%` }} /></div>
      <p className="small faint">Runs on the server. You can close this tab; progress is kept if anything restarts.</p>
    </div>
  );
}

function RemoveDialog({ account, onClose }: { account: Account; onClose: () => void }) {
  const qc = useQueryClient();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const remove = async () => {
    setBusy(true);
    try {
      const r = await del<{ revoked: boolean }>(`/api/accounts/${account.id}`);
      toast(r.revoked ? 'Disconnected and Google access revoked' : 'Disconnected. Google did not confirm revocation; remove access at myaccount.google.com/permissions.', !r.revoked);
      invalidateAll(qc);
      onClose();
    } catch (e) { toast((e as Error).message, true); setBusy(false); }
  };
  return (
    <Modal title={`Disconnect ${account.email}?`} onClose={onClose} footer={<>
      <button className="btn" onClick={onClose}>Cancel</button>
      <button className="btn danger solid" onClick={remove} disabled={busy}>{busy && <Spinner />}Disconnect and delete data</button>
    </>}>
      <p>This revokes Opt Out's access to the mailbox and permanently deletes its {n(account.identities)} senders and unsubscribe history from Opt Out. Your emails in Gmail are not touched.</p>
    </Modal>
  );
}
