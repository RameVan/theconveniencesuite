import { useState } from 'react';
import { useInfiniteQuery, useQuery, useQueryClient } from '@tanstack/react-query';
import { Activity as ActivityIcon, Pause, Play } from 'lucide-react';
import { api, post, type UnsubRequest } from '../api.ts';
import { invalidateAll } from '../hooks.ts';
import { MethodBadge, Notice, Spinner, StateBadge, ago, displayName, fmtDate, useToast } from '../components/ui.tsx';
import { RequestActions } from '../components/RequestActions.tsx';
import { SubscriptionDrawer } from '../components/SubscriptionDrawer.tsx';

const GROUPS = [
  { key: 'all', label: 'All', states: [] as string[] },
  { key: 'manual', label: 'Needs you', states: ['requires_manual_action', 'awaiting_confirmation', 'awaiting_approval'] },
  { key: 'pending', label: 'Pending', states: ['queued', 'processing', 'request_submitted', 'verification_pending'] },
  { key: 'success', label: 'Successful', states: ['unsubscribed', 'verification_unavailable'] },
  { key: 'failed', label: 'Failed', states: ['failed'] },
];
const PAGE = 50;

export function ActivityPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [group, setGroup] = useState('all');
  const [open, setOpen] = useState<string | null>(null);
  const q = useInfiniteQuery({
    queryKey: ['requests', group],
    queryFn: ({ pageParam }) => api<{ total: number; counts: Record<string, number>; items: UnsubRequest[] }>(`/api/unsubscribe/requests?group=${group}&limit=${PAGE}&offset=${pageParam}`),
    initialPageParam: 0,
    getNextPageParam: (last, pages) => (pages.length * PAGE < last.total ? pages.length * PAGE : undefined),
  });
  const jobs = useQuery<{ summary: Record<string, Record<string, number>> }>({ queryKey: ['jobs'], queryFn: () => api('/api/jobs') });
  const u = jobs.data?.summary.unsubscribe ?? {};
  const counts = q.data?.pages[0]?.counts ?? {};
  const items = q.data?.pages.flatMap((p) => p.items) ?? [];
  const groupCount = (states: string[]) => (states.length ? states.reduce((s, k) => s + (counts[k] ?? 0), 0) : Object.values(counts).reduce((a, b) => a + b, 0));

  const control = async (action: 'pause' | 'resume') => {
    try { const r = await post<{ changed: number }>('/api/unsubscribe/control', { action }); toast(`${r.changed} pending request${r.changed === 1 ? '' : 's'} ${action === 'pause' ? 'paused' : 'resumed'}`); invalidateAll(qc); } catch (e) { toast((e as Error).message, true); }
  };

  return (
    <>
      <div className="page-head">
        <div className="grow"><p className="eyebrow">Requests</p><h1>Unsubscribe activity</h1><p className="sub">Every request, its current state and what happened.</p></div>
        {(u.queued ?? 0) > 0 && <button className="btn" onClick={() => control('pause')}><Pause size={14} />Pause queue ({u.queued})</button>}
        {(u.paused ?? 0) > 0 && <button className="btn primary" onClick={() => control('resume')}><Play size={14} />Resume {u.paused} paused</button>}
      </div>
      <div className="stack" style={{ gap: 16 }}>
        <Notice kind="info">
          <b>How results are reported.</b> <i>Submitted, verifying</i> means the sender accepted the request; it becomes <i>Unsubscribed</i> only after no new mail arrives for the verification period. <i>Sent, unverifiable</i> means the sender writes too rarely to tell.
        </Notice>
        <div className="seg" role="tablist">
          {GROUPS.map((g) => (
            <button key={g.key} role="tab" aria-selected={group === g.key} className={group === g.key ? 'on' : ''} onClick={() => setGroup(g.key)}>
              {g.label}<span className="n">{groupCount(g.states)}</span>
            </button>
          ))}
        </div>
        <div className="card">
          {q.isLoading && <div className="card-pad"><Spinner /></div>}
          {!q.isLoading && items.length === 0 && <div className="empty"><ActivityIcon size={30} /><p>Nothing here yet.</p></div>}
          {items.map((r) => (
            <div key={r.id} className="activity-item" style={{ flexWrap: 'wrap' }}>
              <div className="grow" style={{ minWidth: 220 }}>
                <div className="row wrap">
                  <button className="btn ghost sm" style={{ padding: 0, height: 'auto', fontWeight: 650 }} onClick={() => setOpen(r.identityId)}>{displayName(r)}</button>
                  <MethodBadge method={r.method} />
                  {r.dryRun && <span className="badge">dry run</span>}
                  <span className="small faint">via {r.source}</span>
                </div>
                <p className="small muted">{r.events.at(-1)?.detail ?? r.label}</p>
                <p className="small faint">{r.accountEmail} · started {fmtDate(r.createdAt)}{r.verifyAfter && r.state === 'verification_pending' ? ` · checking ${ago(r.verifyAfter)}` : ''}{r.attempts > 1 ? ` · ${r.attempts} attempts` : ''}</p>
                <div style={{ marginTop: 6 }}><RequestActions request={r} compact /></div>
              </div>
              <div style={{ textAlign: 'right' }}><StateBadge state={r.state} /><p className="small faint">{ago(r.updatedAt)}</p></div>
            </div>
          ))}
          {q.hasNextPage && <div style={{ padding: 12, textAlign: 'center' }}><button className="btn" onClick={() => q.fetchNextPage()} disabled={q.isFetchingNextPage}>Load more</button></div>}
        </div>
      </div>
      {open && <SubscriptionDrawer id={open} onClose={() => setOpen(null)} />}
    </>
  );
}
