import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { RefreshCw, ShieldAlert, ShieldCheck } from 'lucide-react';
import { api, patch, post, type BreachOverview } from '../api.ts';
import { invalidateAll } from '../hooks.ts';
import { BreachCard, adviceFor } from '../components/BreachCard.tsx';
import { SubscriptionDrawer } from '../components/SubscriptionDrawer.tsx';
import { Notice, Spinner, StateBadge, Switch, ago, displayName, n, useToast } from '../components/ui.tsx';

export function Breaches() {
  const qc = useQueryClient();
  const toast = useToast();
  const q = useQuery<BreachOverview>({ queryKey: ['breaches'], queryFn: () => api('/api/breaches') });
  const [open, setOpen] = useState<string | null>(null);
  const d = q.data;

  const setConsent = async (v: boolean) => {
    try {
      await patch('/api/preferences', { breachConsent: v });
      toast(v ? 'Checking your addresses…' : 'Address checks turned off and their results deleted');
      invalidateAll(qc);
      qc.invalidateQueries({ queryKey: ['breaches'] });
    } catch (e) { toast((e as Error).message, true); }
  };
  const checkNow = async () => {
    try { await post('/api/breaches/check'); toast('Check queued'); invalidateAll(qc); } catch (e) { toast((e as Error).message, true); }
  };
  const refreshCatalogue = async () => {
    try { await post('/api/breaches/refresh-catalogue'); toast('Refreshing the breach list'); invalidateAll(qc); } catch (e) { toast((e as Error).message, true); }
  };

  const hitCount = d?.accounts.reduce((s, a) => s + a.breaches.length, 0) ?? 0;

  return (
    <>
      <div className="page-head">
        <div className="grow"><p className="eyebrow">Safety</p><h1>Data breaches</h1><p className="sub">Where your email address leaked, and which companies that email you have been breached.</p></div>
      </div>
      {q.isLoading && <div className="card card-pad"><Spinner /></div>}
      {d && (
        <div className="stack" style={{ gap: 20 }}>
          {d.source === 'fixture' && <Notice kind="warn"><b>Fixture breach data.</b> These breaches are made up to match the development mailbox. With DEV_FAKE_PROVIDER off, data comes from XposedOrNot (free) or Have I Been Pwned (with an API key).</Notice>}

          <section className="section">
            <h3>Your email addresses</h3>
            <div className="card">
              {!d.lookupAvailable ? (
                <div className="card-pad"><Notice kind="info">Address checks are not available with the configured breach provider. The company check below still works.</Notice></div>
              ) : (
                <div className="setting">
                  <div className="grow">
                    <p><b>Check my addresses with {d.provider.name}</b></p>
                    <p className="small muted">Sends only your email addresses ({d.accounts.map((a) => a.email).join(', ')}) to {d.provider.host} over HTTPS, then again once a day. Turning this off deletes the results.</p>
                  </div>
                  <Switch checked={d.consent} onChange={setConsent} label="Check my addresses" />
                </div>
              )}
              {d.consent && d.accounts.map((a) => (
                <div key={a.email} style={{ borderTop: '1px solid var(--border)' }}>
                  <div className="setting" style={{ borderBottom: 0 }}>
                    {a.breaches.length ? <ShieldAlert size={18} color="var(--bad)" /> : <ShieldCheck size={18} color={a.status === 'ok' ? 'var(--ok)' : 'var(--text-3)'} />}
                    <div className="grow">
                      <p><b>{a.email}</b></p>
                      <p className="small muted">
                        {a.status === null ? 'Not checked yet; it runs in the background.'
                          : a.status === 'error' ? `Last check failed: ${a.error}`
                          : a.breaches.length ? `Found in ${a.breaches.length} breach${a.breaches.length === 1 ? '' : 'es'} · checked ${ago(a.checkedAt)}`
                          : `Not found in any known breach · checked ${ago(a.checkedAt)}`}
                      </p>
                    </div>
                  </div>
                  {a.breaches.map(({ breach, senders, firstSeenAt }) => (
                    <div key={breach.name} style={{ padding: '0 18px 14px' }}>
                      <BreachCard breach={breach}>
                        <ul className="small advice">{adviceFor(breach.dataClasses).map((t) => <li key={t}>{t}</li>)}</ul>
                        <div className="row wrap small">
                          <span className="faint">First reported to you {ago(firstSeenAt)}</span>
                          {senders.length > 0 && <button className="btn sm" onClick={() => setOpen(senders[0])}>They still email you · review</button>}
                        </div>
                      </BreachCard>
                    </div>
                  ))}
                </div>
              ))}
              {d.consent && (
                <div className="setting small muted" style={{ borderTop: '1px solid var(--border)' }}>
                  <span className="grow">{hitCount ? `${hitCount} breach${hitCount === 1 ? '' : 'es'} across your addresses.` : ''} Breaches marked sensitive (for example adult sites) are never returned by this check.</span>
                  <button className="btn sm" onClick={checkNow}><RefreshCw size={13} />Check now</button>
                </div>
              )}
            </div>
          </section>

          <section className="section">
            <h3>Companies that email you and were breached</h3>
            <div className="card">
              {d.catalogue.count === 0 ? (
                <div className="setting">
                  <span className="grow small muted">The public breach list hasn't been downloaded yet. It refreshes daily in the background.</span>
                  <button className="btn sm" onClick={refreshCatalogue}><RefreshCw size={13} />Download now</button>
                </div>
              ) : d.senderBreaches.length === 0 ? (
                <div className="empty small"><ShieldCheck size={28} />None of the {n(d.catalogue.count)} known breaches match a company that emails you.</div>
              ) : d.senderBreaches.map(({ breach, senders }) => (
                <div key={breach.name} style={{ padding: '14px 18px', borderBottom: '1px solid var(--border)' }}>
                  <BreachCard breach={breach}>
                    <p className="small muted">This doesn't mean your data was included: it means this company was breached and you have an account or subscription with it.</p>
                    <div className="stack" style={{ gap: 4 }}>
                      {senders.map((s) => (
                        <button key={s.id} className="row small sender-link" onClick={() => setOpen(s.id)}>
                          <span className="grow truncate" style={{ textAlign: 'left' }}><b>{displayName(s)}</b> <span className="muted">{s.fromAddress} · {n(s.messageCount)} emails</span></span>
                          <StateBadge state={s.unsubState} />
                        </button>
                      ))}
                    </div>
                  </BreachCard>
                </div>
              ))}
              <div className="setting small faint" style={{ borderBottom: 0 }}>
                <span className="grow">Breach data: <a href={d.provider.url} target="_blank" rel="noopener noreferrer">{d.provider.name}</a> ({d.provider.attribution}) · {n(d.catalogue.count)} breaches · updated {ago(d.catalogue.updatedAt)}</span>
              </div>
            </div>
          </section>
        </div>
      )}
      {open && <SubscriptionDrawer id={open} onClose={() => setOpen(null)} />}
    </>
  );
}
