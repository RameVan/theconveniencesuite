import { useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Puzzle } from 'lucide-react';
import { post } from '../api.ts';
import { Notice, Spinner } from '../components/ui.tsx';

declare const chrome: { runtime?: { sendMessage: (id: string, msg: unknown, cb: (r: unknown) => void) => void; lastError?: { message: string } } } | undefined;

/**
 * Opened by the extension. Mints a token for the signed-in user and hands it to the extension
 * through Chrome's externally_connectable messaging; only extension IDs listed in the
 * extension's own manifest can receive it.
 */
export function LinkExtension() {
  const [params] = useSearchParams();
  const ext = params.get('ext') ?? '';
  const [state, setState] = useState<'idle' | 'busy' | 'done' | 'error'>('idle');
  const [msg, setMsg] = useState('');
  const started = useRef(false);

  const link = async () => {
    setState('busy');
    try {
      if (!/^[a-p]{32}$/.test(ext)) throw new Error('This link did not come from the extension.');
      if (typeof chrome === 'undefined' || !chrome?.runtime?.sendMessage) throw new Error('Open this page in Chrome with the extension installed.');
      const { token, id } = await post<{ token: string; id: string }>('/api/extension/tokens', { label: 'Chrome extension' });
      await new Promise<void>((resolve, reject) => {
        chrome!.runtime!.sendMessage(ext, { type: 'link', token, tokenId: id, origin: window.location.origin }, (r) => {
          if (chrome!.runtime!.lastError || !(r as { ok?: boolean })?.ok) reject(new Error(chrome!.runtime!.lastError?.message ?? 'The extension did not accept the link.'));
          else resolve();
        });
      });
      setState('done');
    } catch (e) {
      setState('error');
      setMsg((e as Error).message);
    }
  };
  useEffect(() => { if (!started.current) { started.current = true; void link(); } }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="login" style={{ minHeight: '60vh' }}>
      <div className="card">
        <div><p className="eyebrow row" style={{ gap: 6 }}><Puzzle size={13} />Browser extension</p><h1 style={{ fontSize: 34 }}>Connect the extension</h1></div>
        {state === 'busy' && <div className="row muted"><Spinner />Linking…</div>}
        {state === 'done' && <Notice kind="ok">The extension is connected. You can close this tab.</Notice>}
        {state === 'error' && <><Notice kind="bad">{msg}</Notice><button className="btn" onClick={link}>Try again</button></>}
        <p className="small muted">The extension gets its own key, which you can revoke any time in Settings → Browser extension.</p>
      </div>
    </div>
  );
}
