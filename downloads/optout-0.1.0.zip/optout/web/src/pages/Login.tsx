import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import { ShieldCheck, Eye, Trash2 } from 'lucide-react';
import { post } from '../api.ts';
import { usePublicConfig } from '../hooks.ts';
import { BrandMark, Notice } from '../components/ui.tsx';

const ERRORS: Record<string, string> = {
  google_not_configured: 'Google sign-in is not configured on this server yet. See docs/SETUP.md.',
  invalid_state: 'The sign-in link expired. Please try again.',
  oauth_failed: 'Google sign-in failed. Please try again.',
  email_not_verified: 'Your Google email address is not verified.',
  access_denied: 'Sign-in was cancelled.',
  session_changed: 'Your session changed during sign-in. Please sign in again.',
};

export function Login() {
  const cfg = usePublicConfig().data;
  const [params] = useSearchParams();
  const qc = useQueryClient();
  const [busy, setBusy] = useState(false);
  const error = params.get('error');

  const devLogin = async () => {
    setBusy(true);
    await post('/auth/dev-login');
    await qc.invalidateQueries({ queryKey: ['me'] });
  };

  return (
    <div className="login">
      <div className="card">
        <BrandMark className="login-mark" />
        <div><p className="eyebrow">The Convenience Suite</p><h1>Opt Out</h1><p className="lede" style={{ marginTop: 10 }}>Find every mailing list in your inbox and leave the ones you don't want.</p></div>
        {error && <Notice kind="bad">{ERRORS[error] ?? `Sign-in failed (${error}).`}</Notice>}
        <a className={`btn primary${cfg && !cfg.googleConfigured ? ' disabled' : ''}`} href="/auth/google/login" style={{ height: 42 }}
          aria-disabled={cfg && !cfg.googleConfigured} onClick={(e) => { if (cfg && !cfg.googleConfigured) e.preventDefault(); }}>
          <GoogleG /> Sign in with Google
        </a>
        {cfg && !cfg.googleConfigured && <p className="small muted">Google sign-in needs a Google Cloud OAuth client on this server.</p>}
        {cfg?.devLogin && (
          <button className="btn" onClick={devLogin} disabled={busy}>Use development fixture mailbox</button>
        )}
        <div className="stack small muted promises" style={{ gap: 10 }}>
          <div className="row" style={{ alignItems: 'flex-start' }}><Eye size={15} style={{ flex: 'none', marginTop: 2 }} /><span>Reads email <b>headers only</b> (sender, subject, unsubscribe links). Never the body of your emails.</span></div>
          <div className="row" style={{ alignItems: 'flex-start' }}><ShieldCheck size={15} style={{ flex: 'none', marginTop: 2 }} /><span>Bank, security, order and other important mail is protected from bulk unsubscribe.</span></div>
          <div className="row" style={{ alignItems: 'flex-start' }}><Trash2 size={15} style={{ flex: 'none', marginTop: 2 }} /><span>Disconnect or delete your account at any time; Google access is revoked straight away.</span></div>
        </div>
      </div>
    </div>
  );
}

function GoogleG() {
  return (
    <svg width="16" height="16" viewBox="0 0 48 48" aria-hidden>
      <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 13 4 4 13 4 24s9 20 20 20 20-9 20-20c0-1.3-.1-2.4-.4-3.5z" />
      <path fill="#FF3D00" d="m6.3 14.7 6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z" />
      <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z" />
      <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z" />
    </svg>
  );
}
