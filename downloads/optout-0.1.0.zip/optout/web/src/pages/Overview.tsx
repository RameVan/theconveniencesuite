import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { ArrowRight, Mail, Sparkles } from 'lucide-react';
import { api, type Subscription } from '../api.ts';
import { useAccounts, useMe } from '../hooks.ts';
import { Avatar, MethodBadge, Notice, StateBadge, ago, displayName, n } from '../components/ui.tsx';
import { UnsubscribeDialog, type Selection } from '../components/UnsubscribeDialog.tsx';
import { SubscriptionDrawer } from '../components/SubscriptionDrawer.tsx';
import { ScanStatus } from './Accounts.tsx';

interface OverviewData {
  accounts: { id: string; email: string; status: string; provider: string; lastSyncAt: string | null; fullScanCompletedAt: string | null }[];
  counts: { total: number; marketing: number; protected: number; unsubscribed: number; inProgress: number; needsAction: number };
  volume: { last30: number; marketing30: number };
  recommended: Subscription[];
  recent: { at: string; toState: string; detail: string | null; requestId: string; name: string | null; address: string; label: string }[];
}

export function Overview() {
  const me = useMe().data!;
  const q = useQuery<OverviewData>({ queryKey: ['overview'], queryFn: () => api('/api/overview') });
  const accounts = useAccounts().data ?? [];
  const [dialog, setDialog] = useState<Selection | null>(null);
  const [open, setOpen] = useState<string | null>(null);
  const d = q.data;
  const scanning = accounts.filter((a) => a.scan);
  const share = d && d.volume.last30 ? Math.round((d.volume.marketing30 / d.volume.last30) * 100) : 0;

  return (
    <>
      <div className="page-head">
        <div className="grow"><p className="eyebrow">Your inbox</p><h1>Overview</h1><p className="sub">Hi {me.user.name?.split(' ')[0] ?? 'there'}. Here's what's landing in your inbox.</p></div>
      </div>
      <div className="stack" style={{ gap: 16 }}>
        {me.unsubscribeMode === 'dry_run' && (
          <Notice kind="info"><b>Dry-run mode is on.</b> Unsubscribe requests are prepared and validated, but nothing is sent to senders until an administrator sets <span className="mono">UNSUBSCRIBE_MODE=live</span>.</Notice>
        )}
        {d?.accounts.some((a) => a.provider === 'fake') && (
          <Notice kind="warn"><b>Development fixture mailbox.</b> These numbers come from built-in test data, not a real inbox. Fixture accounts only exist when DEV_FAKE_PROVIDER is on, outside production.</Notice>
        )}
        {d && d.accounts.length === 0 && (
          <div className="card card-pad row wrap" style={{ gap: 16 }}>
            <Mail size={28} color="var(--accent)" />
            <div className="grow"><h2>Connect your first Gmail account</h2><p className="muted">Opt Out reads message headers only, to find mailing lists and their unsubscribe links.</p></div>
            <Link className="btn primary" to="/accounts">Connect Gmail</Link>
          </div>
        )}
        {scanning.map((a) => <div key={a.id} className="card card-pad"><ScanStatus account={a} /></div>)}

        <div className="grid grid-4">
          <Stat label="Connected accounts" value={d?.accounts.length} hint={d?.accounts.filter((a) => a.status !== 'active').length ? 'one needs reconnecting' : 'all healthy'} to="/accounts" />
          <Stat label="Subscriptions found" value={d?.counts.total} hint={d ? `${n(d.counts.marketing)} marketing · ${n(d.counts.protected)} protected` : ''} to="/subscriptions" />
          <Stat label="Emails, last 30 days" value={d?.volume.last30} hint={d ? `${share}% marketing` : ''} />
          <Stat label="Unsubscribed" value={d?.counts.unsubscribed} hint={d ? `${n(d.counts.inProgress)} in progress · ${n(d.counts.needsAction)} need you` : ''} to="/activity" />
        </div>

        <div className="grid grid-2">
          <div className="card">
            <div className="card-head">
              <Sparkles size={16} color="var(--accent)" /><h2 className="grow">Recommended unsubscribes</h2>
              {d && d.recommended.length > 0 && (
                <button className="btn sm primary" onClick={() => setDialog({ ids: d.recommended.map((r) => r.id), label: 'The most frequent marketing senders you have not acted on' })}>Unsubscribe all {d.recommended.length}</button>
              )}
            </div>
            {d?.recommended.length === 0 && <div className="empty small">Nothing to recommend right now.</div>}
            {d?.recommended.map((s) => (
              <div key={s.id} className="activity-item" style={{ cursor: 'pointer', alignItems: 'center' }} onClick={() => setOpen(s.id)}>
                <Avatar name={displayName(s)} domain={s.domain} />
                <div className="grow">
                  <p className="truncate"><b>{displayName(s)}</b></p>
                  <p className="small muted truncate">≈ {s.perMonth} emails a month · {s.categoryName ?? 'Uncategorised'} · latest {ago(s.lastSeenAt)}</p>
                </div>
                <MethodBadge method={s.method} />
              </div>
            ))}
            <div style={{ padding: '10px 18px' }}><Link to="/subscriptions?kind=marketing&sort=frequency" className="small row">See all marketing senders <ArrowRight size={13} /></Link></div>
          </div>

          <div className="card">
            <div className="card-head"><h2 className="grow">Recent activity</h2><Link to="/activity" className="small">All activity</Link></div>
            {d?.recent.length === 0 && <div className="empty small">No unsubscribe activity yet.</div>}
            {d?.recent.map((e, i) => (
              <div key={`${e.requestId}-${i}`} className="activity-item">
                <div className="grow">
                  <p className="truncate"><b>{e.name ?? e.address}</b></p>
                  {e.detail && <p className="small muted">{e.detail}</p>}
                </div>
                <div style={{ textAlign: 'right' }}><StateBadge state={e.toState} /><p className="small faint">{ago(e.at)}</p></div>
              </div>
            ))}
          </div>
        </div>
      </div>
      {dialog && <UnsubscribeDialog selection={dialog} onClose={() => setDialog(null)} />}
      {open && <SubscriptionDrawer id={open} onClose={() => setOpen(null)} />}
    </>
  );
}

function Stat({ label, value, hint, to }: { label: string; value?: number; hint?: string; to?: string }) {
  const body = (
    <div className="card stat">
      <div className="label">{label}</div>
      <div className="value">{value === undefined ? <span className="skeleton" style={{ display: 'block', width: 60, height: 28 }} /> : n(value)}</div>
      <div className="hint truncate">{hint}</div>
    </div>
  );
  return to ? <Link to={to} style={{ color: 'inherit', textDecoration: 'none' }}>{body}</Link> : body;
}
