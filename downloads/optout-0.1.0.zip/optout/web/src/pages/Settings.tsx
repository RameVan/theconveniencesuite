import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Download, Merge, Pencil, Plus, Puzzle, Star, Trash2 } from 'lucide-react';
import { api, del, patch, post, type Preferences, type Subscription } from '../api.ts';
import { invalidateAll, useCategories, useMe } from '../hooks.ts';
import { Modal, Notice, Spinner, Switch, ago, displayName, readLogoPref, writeLogoPref, useToast } from '../components/ui.tsx';

export function Settings({ onLogout }: { onLogout: () => void }) {
  const qc = useQueryClient();
  const toast = useToast();
  const me = useMe().data!;
  const p = me.preferences;
  const [logos, setLogos] = useState(readLogoPref());

  const setPref = async (body: Partial<Preferences>) => {
    try { await patch('/api/preferences', body); invalidateAll(qc); toast('Saved'); } catch (e) { toast((e as Error).message, true); }
  };

  return (
    <>
      <div className="page-head"><div className="grow"><p className="eyebrow">Preferences</p><h1>Settings</h1><p className="sub">Privacy, protection, scanning and appearance.</p></div></div>
      <div className="stack" style={{ gap: 24 }}>
        <section className="section">
          <h3>Appearance</h3>
          <div className="card">
            <div className="setting">
              <div className="grow"><p><b>Theme</b></p></div>
              <div className="seg">
                {(['system', 'light', 'dark'] as const).map((t) => <button key={t} className={p.theme === t ? 'on' : ''} onClick={() => setPref({ theme: t })}>{t[0].toUpperCase() + t.slice(1)}</button>)}
              </div>
            </div>
            <div className="setting">
              <div className="grow"><p><b>Show sender logos</b></p><p className="small muted">Loads logos from DuckDuckGo's icon service, which then sees the sender domains you view. Off by default; stored in this browser only.</p></div>
              <Switch checked={logos} onChange={(v) => { setLogos(v); writeLogoPref(v); qc.invalidateQueries(); }} label="Show sender logos" />
            </div>
          </div>
        </section>

        <section className="section">
          <h3>Unsubscribing</h3>
          <div className="card">
            <div className="setting">
              <div className="grow"><p><b>Unsubscribe by email</b></p><p className="small muted">For senders that only accept an email. Requires granting Gmail send permission per account (Accounts page). Messages go only to the address the sender lists.</p></div>
              <Switch checked={p.mailtoEnabled} onChange={(v) => setPref({ mailtoEnabled: v })} label="Unsubscribe by email" />
            </div>
            <div className="setting">
              <div className="grow"><p><b>Verification period</b></p><p className="small muted">Days without new mail before a request counts as verified. Senders are allowed two days to process it first.</p></div>
              <select className="select" value={p.verificationDays} onChange={(e) => setPref({ verificationDays: Number(e.target.value) })} aria-label="Verification period">
                {[5, 7, 10, 14, 21, 30].map((d) => <option key={d} value={d}>{d} days</option>)}
              </select>
            </div>
          </div>
        </section>

        <section className="section">
          <h3>Scanning</h3>
          <div className="card">
            <div className="setting">
              <div className="grow"><p><b>Maximum messages per full scan</b></p><p className="small muted">Newest first. After the first scan only new mail is fetched.</p></div>
              <select className="select" value={p.scanMaxMessages} onChange={(e) => setPref({ scanMaxMessages: Number(e.target.value) })} aria-label="Scan limit">
                {[5000, 10000, 20000, 50000, 100000, 200000].map((v) => <option key={v} value={v}>{v.toLocaleString()}</option>)}
              </select>
            </div>
          </div>
        </section>

        <CategoriesSection />
        <KeptSection />
        <ExtensionSection />

        <section className="section">
          <h3>Privacy & data</h3>
          <div className="card">
            <div className="setting">
              <div className="grow">
                <p><b>What is stored</b></p>
                <p className="small muted">Per sender: address, name, list ID, unsubscribe links, the latest subject line, counts and dates. Per message: only its Gmail ID and date. Never email bodies. Google tokens are encrypted (AES-256-GCM). Nothing is sold, shared or used for advertising, and nothing is sent to AI services.</p>
              </div>
            </div>
            <div className="setting">
              <div className="grow"><p><b>Export your data</b></p><p className="small muted">Everything Opt Out holds about you, as JSON.</p></div>
              <a className="btn" href="/api/privacy/export" download><Download size={14} />Export</a>
            </div>
            <DeleteAccount onDeleted={onLogout} email={me.user.email} />
          </div>
        </section>
      </div>
    </>
  );
}

function CategoriesSection() {
  const qc = useQueryClient();
  const toast = useToast();
  const cats = useCategories().data ?? [];
  const [name, setName] = useState('');
  const [merging, setMerging] = useState<string | null>(null);
  const [renaming, setRenaming] = useState<{ id: string; name: string } | null>(null);
  const run = async (fn: () => Promise<unknown>, msg: string) => { try { await fn(); invalidateAll(qc); toast(msg); } catch (e) { toast((e as Error).message, true); } };
  const merge = cats.find((c) => c.id === merging);

  return (
    <section className="section">
      <h3>Categories & protection</h3>
      <div className="card">
        <div className="setting">
          <form className="row grow" onSubmit={(e) => { e.preventDefault(); if (name.trim()) run(() => post('/api/categories', { name }), 'Category created').then(() => setName('')); }}>
            <input className="input grow" placeholder="New category name" value={name} onChange={(e) => setName(e.target.value)} maxLength={60} aria-label="New category name" />
            <button className="btn" disabled={!name.trim()}><Plus size={14} />Add</button>
          </form>
        </div>
        <div className="setting small muted" style={{ paddingTop: 8, paddingBottom: 8 }}>Senders in a protected category are never included in bulk unsubscribes.</div>
        {cats.map((c) => (
          <div key={c.id} className="setting" style={{ paddingTop: 9, paddingBottom: 9 }}>
            <div className="grow row">
              {renaming?.id === c.id
                ? <form className="row grow" onSubmit={(e) => { e.preventDefault(); run(() => patch(`/api/categories/${c.id}`, { name: renaming.name }), 'Renamed').then(() => setRenaming(null)); }}>
                    <input className="input grow" value={renaming.name} onChange={(e) => setRenaming({ id: c.id, name: e.target.value })} autoFocus aria-label="Category name" />
                    <button className="btn sm">Save</button>
                  </form>
                : <><b className="truncate">{c.name}</b><span className="small faint">{c.count}</span>{!c.isSystem && <span className="badge">custom</span>}</>}
            </div>
            <span className="small muted hide-mobile">Protected</span>
            <Switch checked={c.isProtected} onChange={(v) => run(() => patch(`/api/categories/${c.id}`, { isProtected: v }), v ? `${c.name} protected` : `${c.name} no longer protected`)} label={`Protect ${c.name}`} />
            <button className="btn sm icon ghost" onClick={() => setRenaming({ id: c.id, name: c.name })} aria-label={`Rename ${c.name}`}><Pencil size={13} /></button>
            <button className="btn sm icon ghost" onClick={() => setMerging(c.id)} aria-label={`Merge ${c.name}`} disabled={c.count === 0 && c.isSystem}><Merge size={13} /></button>
            {!c.isSystem && <button className="btn sm icon ghost danger" onClick={() => run(() => del(`/api/categories/${c.id}`), 'Category deleted')} aria-label={`Delete ${c.name}`}><Trash2 size={13} /></button>}
          </div>
        ))}
      </div>
      {merge && <MergeDialog from={merge} onClose={() => setMerging(null)} />}
    </section>
  );
}

function MergeDialog({ from, onClose }: { from: { id: string; name: string; isSystem: boolean; count: number }; onClose: () => void }) {
  const qc = useQueryClient();
  const toast = useToast();
  const cats = useCategories().data ?? [];
  const [into, setInto] = useState('');
  const go = async () => {
    try { const r = await post<{ moved: number }>(`/api/categories/${from.id}/merge`, { intoId: into }); toast(`${r.moved} senders moved`); invalidateAll(qc); onClose(); } catch (e) { toast((e as Error).message, true); }
  };
  return (
    <Modal title={`Merge "${from.name}"`} onClose={onClose} footer={<><button className="btn" onClick={onClose}>Cancel</button><button className="btn primary" disabled={!into} onClick={go}>Merge</button></>}>
      <p>Move all {from.count} senders into another category.{from.isSystem ? ' Built-in categories stay available afterwards.' : ` "${from.name}" is deleted afterwards.`}</p>
      <select className="select" value={into} onChange={(e) => setInto(e.target.value)} aria-label="Merge into">
        <option value="">Choose a category…</option>
        {cats.filter((c) => c.id !== from.id).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
      </select>
    </Modal>
  );
}

function KeptSection() {
  const qc = useQueryClient();
  const toast = useToast();
  const q = useQuery<{ items: Subscription[]; total: number }>({ queryKey: ['subscriptions', 'kept'], queryFn: () => api('/api/subscriptions?onlyKept=true&limit=500&sort=name&order=asc') });
  const kept = q.data?.items ?? [];
  const unkeep = async (id: string) => { try { await patch(`/api/subscriptions/${id}`, { whitelisted: false }); invalidateAll(qc); toast('Removed'); } catch (e) { toast((e as Error).message, true); } };
  return (
    <section className="section">
      <h3>Kept & protected senders</h3>
      <div className="card">
        {q.isLoading && <div className="card-pad"><Spinner /></div>}
        {!q.isLoading && kept.length === 0 && <div className="setting small muted">No senders kept yet. Use "Keep" on a subscription to exclude it from bulk unsubscribes.</div>}
        {kept.map((s) => (
          <div key={s.id} className="setting" style={{ paddingTop: 9, paddingBottom: 9 }}>
            <Star size={14} color="var(--accent)" />
            <div className="grow truncate"><b>{displayName(s)}</b> <span className="small muted">{s.fromAddress}</span></div>
            <button className="btn sm" onClick={() => unkeep(s.id)}>Remove</button>
          </div>
        ))}
      </div>
    </section>
  );
}

function ExtensionSection() {
  const qc = useQueryClient();
  const toast = useToast();
  const q = useQuery<{ id: string; label: string; createdAt: string; lastUsedAt: string | null }[]>({ queryKey: ['tokens'], queryFn: () => api('/api/extension/tokens') });
  const revoke = async (id: string) => { try { await del(`/api/extension/tokens/${id}`); qc.invalidateQueries({ queryKey: ['tokens'] }); toast('Extension disconnected'); } catch (e) { toast((e as Error).message, true); } };
  return (
    <section className="section">
      <h3>Browser extension</h3>
      <div className="card">
        <div className="setting small muted"><Puzzle size={16} />Install the Chrome extension, then press "Connect" in its popup. It uses this account and the same data; nothing is stored separately.</div>
        {(q.data ?? []).map((t) => (
          <div key={t.id} className="setting" style={{ paddingTop: 9, paddingBottom: 9 }}>
            <div className="grow"><b>{t.label}</b><p className="small muted">Linked {ago(t.createdAt)} · last used {ago(t.lastUsedAt)}</p></div>
            <button className="btn sm danger" onClick={() => revoke(t.id)}>Disconnect</button>
          </div>
        ))}
      </div>
    </section>
  );
}

function DeleteAccount({ onDeleted, email }: { onDeleted: () => void; email: string }) {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const toast = useToast();
  const go = async () => {
    setBusy(true);
    try { await del('/api/me', { confirm: 'DELETE' }); onDeleted(); } catch (e) { toast((e as Error).message, true); setBusy(false); }
  };
  return (
    <div className="setting">
      <div className="grow"><p><b>Delete account</b></p><p className="small muted">Revokes Google access for every connected mailbox and permanently deletes all your data.</p></div>
      <button className="btn danger" onClick={() => setOpen(true)}><Trash2 size={14} />Delete…</button>
      {open && (
        <Modal title="Delete your account?" onClose={() => setOpen(false)} footer={<>
          <button className="btn" onClick={() => setOpen(false)}>Cancel</button>
          <button className="btn danger solid" disabled={text !== 'DELETE' || busy} onClick={go}>{busy && <Spinner />}Delete everything</button>
        </>}>
          <Notice kind="bad">This cannot be undone. Everything for <b>{email}</b> is deleted: accounts, senders, categories and unsubscribe history.</Notice>
          <label className="stack" style={{ gap: 6 }}><span className="small">Type <b className="mono">DELETE</b> to confirm</span>
            <input className="input" value={text} onChange={(e) => setText(e.target.value)} aria-label="Type DELETE to confirm" /></label>
        </Modal>
      )}
    </div>
  );
}
