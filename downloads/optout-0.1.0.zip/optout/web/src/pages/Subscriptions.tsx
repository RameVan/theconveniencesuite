import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useInfiniteQuery, useQueryClient } from '@tanstack/react-query';
import { ArrowDown, ArrowUp, Inbox, Search, Shield, Star, X } from 'lucide-react';
import { api, filterQuery, post, type Filter, type Subscription } from '../api.ts';
import { invalidateAll, useAccounts, useCategories, useMe } from '../hooks.ts';
import { Avatar, MethodBadge, Spinner, StateBadge, ago, displayName, n, useToast } from '../components/ui.tsx';
import { SubscriptionDrawer } from '../components/SubscriptionDrawer.tsx';
import { UnsubscribeDialog, type Selection } from '../components/UnsubscribeDialog.tsx';

type Sort = 'volume' | 'frequency' | 'recent' | 'name';
const PAGE = 100;

function useDebounced<T>(v: T, ms: number): T {
  const [d, setD] = useState(v);
  useEffect(() => { const t = setTimeout(() => setD(v), ms); return () => clearTimeout(t); }, [v, ms]);
  return d;
}

export function Subscriptions() {
  const [params, setParams] = useSearchParams();
  const qc = useQueryClient();
  const toast = useToast();
  const me = useMe().data!;
  const cats = useCategories().data ?? [];
  const accounts = useAccounts().data ?? [];

  const get = (k: string) => params.get(k) ?? undefined;
  const [search, setSearch] = useState(get('search') ?? '');
  const debounced = useDebounced(search, 250);
  const filter: Filter = {
    search: debounced || undefined,
    categoryId: get('category'), accountId: get('account'), method: get('method'), status: get('status'), kind: get('kind'),
    excludeWhitelisted: params.get('kept') === 'hide', excludeProtected: params.get('protected') === 'hide',
  };
  const sort = (get('sort') as Sort) ?? 'volume';
  const order = get('order') ?? (sort === 'name' ? 'asc' : 'desc');
  const setParam = (k: string, v: string | undefined) => {
    const next = new URLSearchParams(params);
    if (v) next.set(k, v); else next.delete(k);
    setParams(next, { replace: true });
  };
  useEffect(() => { setParam('search', debounced || undefined); }, [debounced]); // eslint-disable-line react-hooks/exhaustive-deps

  const q = useInfiniteQuery({
    queryKey: ['subscriptions', filter, sort, order],
    queryFn: ({ pageParam }) => api<{ total: number; items: Subscription[] }>(`/api/subscriptions?${filterQuery({ ...filter, sort, order, limit: PAGE, offset: pageParam })}`),
    initialPageParam: 0,
    getNextPageParam: (last, pages) => (pages.length * PAGE < last.total ? pages.length * PAGE : undefined),
  });
  const items = useMemo(() => q.data?.pages.flatMap((p) => p.items) ?? [], [q.data]);
  const total = q.data?.pages[0]?.total ?? 0;

  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [open, setOpen] = useState<string | null>(null);
  const [dialog, setDialog] = useState<Selection | null>(null);
  const filterKey = JSON.stringify(filter);
  useEffect(() => setSelected(new Set()), [filterKey]);

  const toggle = (id: string) => setSelected((s) => { const x = new Set(s); if (x.has(id)) x.delete(id); else x.add(id); return x; });
  const allOnPage = items.length > 0 && items.every((i) => selected.has(i.id));
  const togglePage = () => setSelected(allOnPage ? new Set() : new Set(items.map((i) => i.id)));

  const bulk = async (body: Record<string, unknown>, msg: string) => {
    try { const r = await post<{ updated: number }>('/api/subscriptions/bulk', { ids: [...selected], ...body }); toast(`${r.updated} ${msg}`); invalidateAll(qc); setSelected(new Set()); } catch (e) { toast((e as Error).message, true); }
  };

  const sortBtn = (s: Sort, label: string) => (
    <button onClick={() => { if (sort === s) setParam('order', order === 'asc' ? 'desc' : 'asc'); else { const next = new URLSearchParams(params); next.set('sort', s); next.delete('order'); setParams(next, { replace: true }); } }}
      aria-label={`Sort by ${label}`}>
      {label}{sort === s && (order === 'asc' ? <ArrowUp size={11} /> : <ArrowDown size={11} />)}
    </button>
  );
  const activeFilters = ['category', 'account', 'method', 'status', 'kind', 'kept', 'protected'].filter((k) => params.get(k));
  const selectedCategory = cats.find((c) => c.id === filter.categoryId);

  return (
    <>
      <div className="page-head">
        <div className="grow"><p className="eyebrow">Mailing lists</p><h1>Subscriptions</h1><p className="sub">{q.isLoading ? 'Loading…' : `${n(total)} sender${total === 1 ? '' : 's'}${activeFilters.length || filter.search ? ' match' : ''}`}</p></div>
        <button className="btn" onClick={() => setDialog({ filter: { ...filter, kind: 'marketing' }, label: 'All eligible marketing senders matching the current filters' })}>
          Unsubscribe all eligible marketing
        </button>
      </div>

      <div className="card">
        <div className="toolbar">
          <div className="search">
            <Search size={15} />
            <input className="input" placeholder="Search company, sender or list" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search" />
          </div>
          <select className="select" value={sort} onChange={(e) => setParam('sort', e.target.value)} aria-label="Sort">
            <option value="volume">Most emails</option>
            <option value="frequency">Most frequent</option>
            <option value="recent">Most recent</option>
            <option value="name">Name</option>
          </select>
        </div>
        <div className="filters" style={{ paddingTop: 12 }}>
          <select className="select" value={filter.categoryId ?? ''} onChange={(e) => setParam('category', e.target.value || undefined)} aria-label="Category">
            <option value="">All categories</option>
            {cats.filter((c) => c.count > 0 || c.id === filter.categoryId).map((c) => <option key={c.id} value={c.id}>{c.name} ({c.count})</option>)}
          </select>
          {accounts.length > 1 && (
            <select className="select" value={filter.accountId ?? ''} onChange={(e) => setParam('account', e.target.value || undefined)} aria-label="Account">
              <option value="">All accounts</option>
              {accounts.map((a) => <option key={a.id} value={a.id}>{a.email}</option>)}
            </select>
          )}
          <select className="select" value={filter.kind ?? ''} onChange={(e) => setParam('kind', e.target.value || undefined)} aria-label="Type">
            <option value="">All types</option>
            <option value="marketing">Marketing</option>
            <option value="transactional">Transactional</option>
            <option value="personal">Personal</option>
            <option value="unknown">Unclear</option>
          </select>
          <select className="select" value={filter.method ?? ''} onChange={(e) => setParam('method', e.target.value || undefined)} aria-label="Unsubscribe method">
            <option value="">Any method</option>
            <option value="one_click">One-click</option>
            <option value="mailto">Email</option>
            <option value="web">Web page</option>
            <option value="none">No link</option>
          </select>
          <select className="select" value={filter.status ?? ''} onChange={(e) => setParam('status', e.target.value || undefined)} aria-label="Status">
            <option value="">Any status</option>
            <option value="none">Not started</option>
            <option value="in_progress">In progress</option>
            <option value="needs_action">Needs you</option>
            <option value="unsubscribed">Unsubscribed</option>
            <option value="failed">Failed</option>
          </select>
          <label className="row small" style={{ cursor: 'pointer' }}><input type="checkbox" className="check" checked={params.get('kept') === 'hide'} onChange={(e) => setParam('kept', e.target.checked ? 'hide' : undefined)} />Hide kept</label>
          <label className="row small" style={{ cursor: 'pointer' }}><input type="checkbox" className="check" checked={params.get('protected') === 'hide'} onChange={(e) => setParam('protected', e.target.checked ? 'hide' : undefined)} />Hide protected</label>
          {activeFilters.length > 0 && <button className="btn sm ghost" onClick={() => { const next = new URLSearchParams(); if (filter.search) next.set('search', filter.search); setParams(next, { replace: true }); }}><X size={13} />Clear filters</button>}
          {selectedCategory && <button className="btn sm" style={{ marginLeft: 'auto' }} onClick={() => setDialog({ filter, label: `Eligible senders in ${selectedCategory.name}` })}>Unsubscribe whole category</button>}
        </div>

        <div className="list-row head" role="row">
          <input type="checkbox" className="check" checked={allOnPage} onChange={togglePage} aria-label="Select all loaded" />
          <span>{sortBtn('name', 'Sender')}</span>
          <span className="col-cat">Category</span>
          <span className="num col-count">{sortBtn('volume', 'Emails')}</span>
          <span className="num col-freq">{sortBtn('frequency', '/ month')}</span>
          <span className="col-last">{sortBtn('recent', 'Latest')}</span>
          <span className="col-method">Method</span>
          <span>Status</span>
        </div>
        {q.isLoading && Array.from({ length: 6 }, (_, i) => <div key={i} className="list-row"><span /><div className="skeleton" /><div className="skeleton col-cat" /><span /><span /><span /><span /><span /></div>)}
        {!q.isLoading && items.length === 0 && (
          <div className="empty"><Inbox size={32} /><p>{activeFilters.length || filter.search ? 'No senders match these filters.' : 'No subscriptions yet. Connect a Gmail account and run a scan.'}</p></div>
        )}
        {items.map((s) => (
          <div key={s.id} className={`list-row${selected.has(s.id) ? ' selected' : ''}`} onClick={() => setOpen(s.id)} role="row">
            <input type="checkbox" className="check" checked={selected.has(s.id)} onClick={(e) => e.stopPropagation()} onChange={() => toggle(s.id)} aria-label={`Select ${displayName(s)}`} />
            <div className="sender">
              <Avatar name={displayName(s)} domain={s.domain} />
              <div className="grow">
                <div className="row" style={{ gap: 6 }}>
                  <span className="name truncate">{displayName(s)}</span>
                  {s.isProtected && <span title={s.protectionReason ?? 'Protected'}><Shield size={13} color="var(--warn)" /></span>}
                  {s.whitelisted && <span title="Kept"><Star size={13} color="var(--accent)" /></span>}
                </div>
                <div className="small muted truncate">{s.fromAddress}{s.listId ? ` · ${s.listId}` : ''}{accounts.length > 1 ? ` · ${s.accountEmail}` : ''}</div>
              </div>
            </div>
            <div className="col-cat truncate small" title={s.categorySource === 'user' ? 'Set by you' : `${Math.round(s.confidence * 100)}% confidence`}>
              {s.categoryName ?? '—'}{s.categorySource !== 'user' && s.confidence < 0.5 && <span className="faint"> ?</span>}
            </div>
            <div className="num col-count">{n(s.messageCount)}</div>
            <div className="num col-freq">{s.perMonth}</div>
            <div className="col-last small muted">{ago(s.lastSeenAt)}</div>
            <div className="col-method"><MethodBadge method={s.method} /></div>
            <div><StateBadge state={s.unsubState} /></div>
          </div>
        ))}
        {q.hasNextPage && (
          <div style={{ padding: 12, textAlign: 'center' }}>
            <button className="btn" onClick={() => q.fetchNextPage()} disabled={q.isFetchingNextPage}>{q.isFetchingNextPage ? <Spinner /> : null}Load {Math.min(PAGE, total - items.length)} more</button>
          </div>
        )}
      </div>

      {selected.size > 0 && (
        <div className="bulkbar" role="toolbar" aria-label="Selection actions">
          <b>{selected.size} selected</b>
          <button className="btn sm primary" onClick={() => setDialog({ ids: [...selected], label: `${selected.size} selected sender${selected.size === 1 ? '' : 's'}` })} disabled={selected.size > me.bulkMax}>Unsubscribe</button>
          <button className="btn sm" onClick={() => bulk({ whitelisted: true }, 'senders kept')}><Star size={13} />Keep</button>
          <select className="select" style={{ height: 28 }} value="" onChange={(e) => e.target.value && bulk({ categoryId: e.target.value }, 'senders moved')} aria-label="Move to category">
            <option value="">Move to…</option>
            {cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <button className="btn sm icon" onClick={() => setSelected(new Set())} aria-label="Clear selection"><X size={14} /></button>
        </div>
      )}
      {open && <SubscriptionDrawer id={open} onClose={() => setOpen(null)} />}
      {dialog && <UnsubscribeDialog selection={dialog} onClose={() => setDialog(null)} onDone={() => setSelected(new Set())} />}
    </>
  );
}
