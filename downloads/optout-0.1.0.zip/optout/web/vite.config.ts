import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// In development the API runs on :8790; Vite proxies to it so cookies stay same-origin.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5180,
    strictPort: true,
    proxy: { '/api': 'http://127.0.0.1:8790', '/auth': 'http://127.0.0.1:8790' },
  },
  build: { outDir: 'dist', sourcemap: false },
});
