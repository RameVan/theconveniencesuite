// Thin client of the Opt Out API. The extension stores nothing but its access token:
// all subscription data lives on the server, which the web app also uses.
import { API_ORIGIN } from './config.js';

export async function getToken() {
  const { token } = await chrome.storage.local.get('token');
  return token ?? null;
}

export async function setToken(token) {
  if (token) await chrome.storage.local.set({ token });
  else await chrome.storage.local.remove('token');
}

export class ApiError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

export async function api(path, { method = 'GET', body } = {}) {
  const token = await getToken();
  if (!token) throw new ApiError(401, 'not connected');
  let res;
  try {
    res = await fetch(`${API_ORIGIN}${path}`, {
      method,
      headers: { authorization: `Bearer ${token}`, ...(body !== undefined ? { 'content-type': 'application/json' } : {}) },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError(0, 'Cannot reach the Opt Out server');
  }
  const data = await res.json().catch(() => ({}));
  if (res.status === 401) await setToken(null); // revoked from the web app
  if (!res.ok) throw new ApiError(res.status, data.error ?? `HTTP ${res.status}`);
  return data;
}

export { API_ORIGIN };
