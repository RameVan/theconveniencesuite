import { api, setToken, getToken, API_ORIGIN } from './api.js';

// Linking: the web app's /link-extension page sends us a freshly minted token. Only the
// configured server origin may do this (externally_connectable restricts it as well).
chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  if (sender.origin !== API_ORIGIN || msg?.type !== 'link' || typeof msg.token !== 'string' || !msg.token.startsWith('uxt_')) {
    sendResponse({ ok: false });
    return;
  }
  setToken(msg.token).then(() => { refreshBadge(); sendResponse({ ok: true }); });
  return true; // async response
});

// Badge: how many unsubscribes are waiting for the user (manual steps, permissions).
async function refreshBadge() {
  if (!(await getToken())) { await chrome.action.setBadgeText({ text: '' }); return; }
  try {
    const { counts } = await api('/api/unsubscribe/requests?limit=1');
    const n = (counts.requires_manual_action ?? 0) + (counts.awaiting_confirmation ?? 0) + (counts.awaiting_approval ?? 0);
    await chrome.action.setBadgeBackgroundColor({ color: '#b45309' });
    await chrome.action.setBadgeText({ text: n ? String(n) : '' });
  } catch {
    await chrome.action.setBadgeText({ text: '' });
  }
}

chrome.alarms.create('badge', { periodInMinutes: 15 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'badge') refreshBadge(); });
chrome.runtime.onStartup.addListener(refreshBadge);
chrome.runtime.onInstalled.addListener(refreshBadge);
chrome.runtime.onMessage.addListener((msg) => { if (msg?.type === 'refresh-badge') refreshBadge(); });
