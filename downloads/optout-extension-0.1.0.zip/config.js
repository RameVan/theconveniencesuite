// The Opt Out server this build talks to. tools/build-extension.mjs rewrites this
// file and the manifest's host permissions for other origins.
export const API_ORIGIN = 'http://localhost:8790';
