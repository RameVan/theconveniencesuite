import { api, getToken, API_ORIGIN, ApiError } from './api.js';

const $ = (id) => document.getElementById(id);
const selected = new Set();
let manualRequests = [];

// Builds DOM nodes without innerHTML: sender names and subjects are untrusted input.
function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') node.className = v;
    else if (k.startsWith('on')) node.addEventListener(k.slice(2), v);
    else if (v === true) node.setAttribute(k, '');
    else if (v !== false && v != null) node.setAttribute(k, v);
  }
  for (const c of children.flat()) if (c != null && c !== false) node.append(c instanceof Node ? c : String(c));
  return node;
}

const STATE = {
  queued: ['Queued', 'info'], processing: ['Processing', 'info'], request_submitted: ['Submitted', 'info'],
  verification_pending: ['Submitted, verifying', 'info'], awaiting_confirmation: ['Needs confirmation', 'warn'],
  awaiting_approval: ['Needs permission', 'warn'], requires_manual_action: ['Needs you', 'warn'],
  unsubscribed: ['Unsubscribed', 'ok'], verification_unavailable: ['Sent, unverifiable', 'ok'],
  failed: ['Failed', 'bad'], cancelled: ['Cancelled', ''], prepared: ['Dry run', ''],
};
const METHOD = { one_click: 'one-click', mailto: 'by email', web: 'web page', manual: 'no link' };
const badge = (state) => { const [label, cls] = STATE[state] ?? [state, '']; return el('span', { class: `badge ${cls}` }, label); };
const name = (s) => s.fromName || s.fromAddress || s.domain || 'Unknown sender';
const hue = (s) => { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
const avatar = (s) => el('div', { class: 'av', style: `background:hsl(${hue(s.domain)} 55% 48%)`, 'aria-hidden': 'true' }, (name(s).replace(/[^\p{L}\p{N}]/gu, '')[0] ?? '?').toUpperCase());

function show(view) {
  for (const v of ['connect', 'main', 'confirm']) $(`view-${v}`).hidden = v !== view;
  $('open-app').hidden = view === 'connect';
}

function showError(e) {
  if (e instanceof ApiError && e.status === 401) { show('connect'); return; }
  $('error').textContent = e.message;
  $('error').hidden = false;
}

// ---------- senders ----------
async function loadSenders() {
  const q = $('search').value.trim();
  const params = new URLSearchParams(q
    ? { search: q, limit: '25', sort: 'volume' }
    : { kind: 'marketing', status: 'none', excludeWhitelisted: 'true', excludeProtected: 'true', sort: 'frequency', limit: '25' });
  const { items, total } = await api(`/api/subscriptions?${params}`);
  const list = $('senders');
  list.replaceChildren(...items.map((s) => el('li', {},
    el('input', { type: 'checkbox', 'aria-label': `Select ${name(s)}`, checked: selected.has(s.id), disabled: !s.eligible, onchange: (e) => { if (e.target.checked) selected.add(s.id); else selected.delete(s.id); updateBulk(); } }),
    avatar(s),
    el('div', { class: 'grow' },
      el('div', { class: 'name', title: s.fromAddress }, name(s)),
      el('div', { class: 'sub' }, `≈ ${s.perMonth}/month · ${METHOD[s.method]}${s.isProtected ? ' · protected' : ''}${s.whitelisted ? ' · kept' : ''}`)),
    s.unsubState ? badge(s.unsubState) : s.eligible
      ? el('button', { class: 'btn sm', onclick: () => confirmUnsubscribe([s.id]) }, 'Unsubscribe')
      : el('span', { class: 'badge' }, s.isProtected ? 'Protected' : 'Kept'),
  )));
  $('senders-empty').hidden = items.length > 0;
  $('senders-empty').textContent = q ? 'No senders match.' : total === 0 ? 'Nothing left to suggest. Nice.' : '';
  updateBulk();
}

function updateBulk() {
  $('bulk').hidden = selected.size === 0;
  $('bulk-count').textContent = `${selected.size} selected`;
}

// ---------- confirmation (same server-side checks as the web app) ----------
async function confirmUnsubscribe(ids) {
  show('confirm');
  $('confirm-title').textContent = 'Checking…';
  $('confirm-body').replaceChildren();
  $('confirm-go').disabled = true;
  try {
    const p = await api('/api/unsubscribe/preview', { method: 'POST', body: { ids } });
    $('confirm-title').textContent = p.eligible.length === 1 ? `Unsubscribe from ${name(p.eligible[0])}?` : `Unsubscribe from ${p.eligible.length} senders?`;
    const body = [];
    if (p.dryRun) body.push(el('div', { class: 'notice info' }, 'Dry-run mode: validated, nothing is sent to senders.'));
    const methods = Object.entries(p.methods).map(([m, n]) => el('li', {}, el('span', {}, METHOD[m]), el('b', {}, n)));
    if (methods.length) body.push(el('ul', { class: 'list summary' }, methods));
    if (p.excluded.length) {
      body.push(el('p', { class: 'muted small', style: 'margin-top:10px' }, `${p.excluded.length} not included:`));
      body.push(el('ul', { class: 'list' }, p.excluded.map((e) => el('li', {}, el('span', { class: 'grow name' }, name(e)), el('span', { class: 'badge warn' }, e.reason)))));
      if (p.excluded.some((e) => e.needsOverride)) body.push(el('p', { class: 'muted small', style: 'margin-top:8px' }, 'Protected senders can only be included from the web app.'));
    }
    body.push(el('p', { class: 'muted small', style: 'margin-top:10px' }, 'Shown as "submitted" until mail actually stops. It keeps running if you close the browser.'));
    $('confirm-body').replaceChildren(...body);
    $('confirm-go').disabled = p.eligible.length === 0;
    $('confirm-go').onclick = async () => {
      $('confirm-go').disabled = true;
      try {
        const r = await api('/api/unsubscribe', { method: 'POST', body: { ids: p.eligible.map((e) => e.id), confirm: true } });
        selected.clear();
        await openMain(`${r.created.length} queued${r.skipped.length ? `, ${r.skipped.length} skipped (${r.skipped[0].reason})` : ''}.`);
      } catch (e) { showError(e); }
    };
  } catch (e) { showError(e); show('main'); }
}

// ---------- activity ----------
async function act(id, path, body) {
  await api(`/api/unsubscribe/requests/${id}/${path}`, { method: 'POST', body });
  chrome.runtime.sendMessage({ type: 'refresh-badge' });
  await Promise.all([loadActivity(), loadSenders()]);
}

async function loadActivity() {
  const { items, counts } = await api('/api/unsubscribe/requests?limit=20');
  manualRequests = items.filter((r) => ['requires_manual_action', 'awaiting_confirmation'].includes(r.state));
  const needs = (counts.requires_manual_action ?? 0) + (counts.awaiting_confirmation ?? 0) + (counts.awaiting_approval ?? 0);
  $('needs').hidden = !needs;
  $('needs').textContent = needs;
  $('activity').replaceChildren(...items.map((r) => {
    const manual = ['requires_manual_action', 'awaiting_confirmation'].includes(r.state);
    const web = r.target && /^https?:\/\//.test(r.target);
    return el('li', { style: 'align-items:flex-start' },
      el('div', { class: 'grow' },
        el('div', { class: 'name' }, name(r)),
        el('div', { class: 'sub', title: r.events.at(-1)?.detail ?? '' }, r.events.at(-1)?.detail ?? r.label),
        manual && el('div', { class: 'actions' },
          web && el('button', { class: 'btn sm primary', onclick: () => chrome.tabs.create({ url: r.target }) }, 'Open page'),
          el('button', { class: 'btn sm', onclick: () => act(r.id, 'manual', { outcome: 'done' }).catch(showError) }, 'Done'),
          el('button', { class: 'btn sm', onclick: () => act(r.id, 'manual', { outcome: 'failed' }).catch(showError) }, "Didn't work")),
        r.state === 'awaiting_approval' && el('div', { class: 'actions' },
          el('button', { class: 'btn sm', onclick: () => chrome.tabs.create({ url: `${API_ORIGIN}/accounts` }) }, 'Grant permission in app'))),
      badge(r.state));
  }));
  $('activity-empty').hidden = items.length > 0;
}

// Browser-assisted unsubscribe: if the current tab is a pending unsubscribe page, offer to finish it.
async function checkCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url) return;
  let here;
  try { here = new URL(tab.url); } catch { return; }
  const match = manualRequests.find((r) => {
    try { const t = new URL(r.target); return t.hostname === here.hostname && here.pathname.startsWith(t.pathname.replace(/\/$/, '')); } catch { return false; }
  });
  const box = $('here');
  box.hidden = !match;
  if (!match) return;
  box.replaceChildren(
    el('div', {}, 'This looks like the unsubscribe page for ', el('b', {}, name(match)), '. Finished here?'),
    el('div', { class: 'actions' },
      el('button', { class: 'btn sm primary', onclick: () => act(match.id, 'manual', { outcome: 'done' }).then(() => { box.hidden = true; }).catch(showError) }, "Yes, I've unsubscribed"),
      el('button', { class: 'btn sm', onclick: () => act(match.id, 'manual', { outcome: 'failed' }).then(() => { box.hidden = true; }).catch(showError) }, "It didn't work")));
}

// ---------- quick scan (deliberately partial) ----------
async function quickScan() {
  $('quick-scan').disabled = true;
  try {
    const accounts = await api('/api/accounts');
    const active = accounts.filter((a) => a.status === 'active');
    for (const a of active) await api(`/api/accounts/${a.id}/scan`, { method: 'POST', body: { mode: 'partial' } });
    $('scan-status').textContent = active.length
      ? `Partial scan queued for ${active.length} account${active.length > 1 ? 's' : ''} (recent mail only). Results appear here shortly.`
      : 'No connected accounts. Connect Gmail in the web app.';
    setTimeout(() => loadSenders().catch(showError), 4000);
  } catch (e) { showError(e); }
  $('quick-scan').disabled = false;
}

async function openMain(message) {
  show('main');
  $('error').hidden = true;
  const me = await api('/api/me');
  $('dry-run').hidden = me.unsubscribeMode !== 'dry_run';
  await Promise.all([loadSenders(), loadActivity()]);
  await checkCurrentTab();
  if (message) $('scan-status').textContent = message;
}

// ---------- wiring ----------
$('connect').onclick = () => { chrome.tabs.create({ url: `${API_ORIGIN}/link-extension?ext=${chrome.runtime.id}` }); window.close(); };
$('open-app').onclick = () => chrome.tabs.create({ url: `${API_ORIGIN}/` });
$('bulk-go').onclick = () => confirmUnsubscribe([...selected]);
$('confirm-cancel').onclick = () => show('main');
$('quick-scan').onclick = quickScan;
let searchTimer;
$('search').oninput = () => { clearTimeout(searchTimer); searchTimer = setTimeout(() => loadSenders().catch(showError), 250); };
for (const b of document.querySelectorAll('.tabs button')) {
  b.onclick = () => {
    for (const x of document.querySelectorAll('.tabs button')) { x.classList.toggle('on', x === b); x.setAttribute('aria-selected', String(x === b)); }
    $('tab-senders').hidden = b.dataset.tab !== 'senders';
    $('tab-activity').hidden = b.dataset.tab !== 'activity';
  };
}

if (await getToken()) openMain().catch(showError);
else show('connect');
