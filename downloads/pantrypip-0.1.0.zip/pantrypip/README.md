# PantryPip

A personal food assistant that keeps your grocery inventory up to date with as little effort as possible:
photograph a receipt, say "I finished the milk", tap "Cooked it". PantryPip plans meals, writes the shopping
list (only what you're missing, rounded to packages), finds recipes for what you have, tracks leftovers
and waste, and learns how fast you use things.

English and Dutch. Mobile-first PWA, works on desktop. Self-hosted: one Node process and one SQLite file.

## Run it

Requires Node 24+.

```bash
npm install
npm run build          # builds the web app into web/dist
npm start              # http://127.0.0.1:8787
```

The first start seeds a demo household with ten weeks of history:
`demo@larder.test` / `larder-demo-2026` (test data only; set `SEED_DEMO=0` for real use).

Development with hot reload: `npm run dev --workspace server` and `npm run dev --workspace web`
(Vite on :5173 proxies `/api` to :8787).

Tests: `npm test` (110 workflow + unit tests, a few seconds). Browser end-to-end checks: `e2e/` (see docs/TESTING.md).

**iPhone:** see [docs/IPHONE.md](docs/IPHONE.md). Either `npm run serve:tailscale` (Tailscale HTTPS), or
`npm run cert` then `npm run start:https` (your own certificate on the home network), then Add to Home Screen.

## Configuration (environment variables)

| Variable | Default | |
|---|---|---|
| `PORT`, `HOST` | 8787, 127.0.0.1 | Use `HOST=0.0.0.0` behind a reverse proxy |
| `DB_FILE` | data/larder.db | |
| `BACKUP_DIR`, `BACKUP_KEEP` | data/backups, 14 | Daily consistent snapshots |
| `AI_ENABLED` | off | AI is off by default: receipts are read on the device, commands by the built-in parser. `1` plus a key turns on the optional Claude features |
| `ANTHROPIC_API_KEY` | (none) | Only used when `AI_ENABLED=1` |
| `AI_MODEL` | claude-opus-5-5 | Only used when `AI_ENABLED=1` |
| `OFF_LOOKUP` | on | `0` disables Open Food Facts lookups |
| `COOKIE_SECURE` | | Force Secure cookies. Not needed with `start:https` or Tailscale Serve: HTTPS is detected per request |
| `HTTPS` | | `1` serves HTTPS itself (what `npm run start:https` sets); `HOST` then defaults to 0.0.0.0 |
| `HTTPS_PORT` | 8443 | HTTPS port; `PORT` then only serves the iPhone setup page and redirects |
| `HTTPS_CERT`, `HTTPS_KEY` | data/certs/server.crt, .key | Made by `npm run cert` (`CERT_NAMES=a,b` adds names) |
| `SEED_DEMO` | on | `0` for a clean install |
| `LOG_LEVEL` | info | JSON-lines logs |
| `TZ` | system | Time zone for the daily cooking question, e.g. `Europe/Amsterdam` |
| `PUSH_CONTACT` | mailto:larder-admin@localhost.localdomain | Your e-mail as `mailto:you@example.com`; push services use it to contact the sender |

## Docs

- [docs/RESEARCH.md](docs/RESEARCH.md): apps, APIs, Dutch supermarkets, OCR, speech, AI, prediction, hardware, privacy, costs
- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md): design principles, stack choices, data model, concurrency, prediction model
- [docs/API.md](docs/API.md): every endpoint
- [docs/TESTING.md](docs/TESTING.md): the 15 workflows, results, interaction counts
- [docs/IMPLEMENTATION_LOG.md](docs/IMPLEMENTATION_LOG.md): what was built, decided and fixed
- [docs/RESEARCH-KITCHEN.md](docs/RESEARCH-KITCHEN.md): recipes, planning, nutrition data, scoring and motivation research, and the decisions
- [docs/IPHONE.md](docs/IPHONE.md): iPhone setup: HTTPS, home screen, notifications, Siri
- [docs/NEEDS_ATTENTION.md](docs/NEEDS_ATTENTION.md): things only you can decide or do
