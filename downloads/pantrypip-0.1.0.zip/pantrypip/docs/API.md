# API reference

All endpoints are JSON under `/api`. Auth is a session cookie (`larder_session`, HttpOnly, SameSite=Lax).
State-changing requests must send `Content-Type: application/json` (CSRF defence).
Errors: `{ "error": { "code", "message", "details? } }` with HTTP 400 (validation, with field paths),
401, 404, 409 (conflict / duplicate), 413, 415, 422 (domain rule), 429 (sign-in rate limit), 500.

Quantities are in the product's **base unit** (`g`, `ml`, `pcs`) unless a `unit` is given
(`"2", "litres"` → 2000 ml). Mutations accept an optional `clientRequestId`: retries with the same id
are applied once and return `{ duplicate: true, batchId, events }`. Mutations return a `batchId` you can
pass to `POST /api/inventory/undo`.

## Auth & system
| Method | Path | Body / query | Notes |
|---|---|---|---|
| GET | /api/health | | no auth |
| GET | /api/config | | AI on/off, model, categories; no auth |
| POST | /api/auth/register | email, password (≥10), name, inviteCode? | joins a household with an invite code, else creates one |
| POST | /api/auth/login | email, password | rate limited per IP+email |
| POST | /api/auth/logout | | |
| GET | /api/me | | user, household (invite code), members, storage locations |
| GET | /api/stream | | Server-Sent Events: `changed` with `{ scopes: [...] }` |

## Home, products, inventory
| Method | Path | Body / query |
|---|---|---|
| GET | /api/home | expiring, low, leftovers, suggestions, today's meals, cook-now, recent events, stats |
| GET | /api/products?q= | fuzzy EN/NL search (or full list) |
| GET | /api/products/:id | product, stock (with prediction), purchases, events |
| POST / PATCH | /api/products(/:id) | name, name_nl, brand, category, barcode, unit, package_size, piece_size, price, preferred_store, default_location, shelf_life_days, synonyms |
| GET | /api/inventory?location= | items (confirmed, estimated, confidence, daysLeft, runOutOn, status, lots), leftovers, locations |
| POST | /api/inventory/add | productId \| name, quantity? + unit?, packages?, location?, expiresOn?, price?, source? |
| POST | /api/inventory/consume | productId \| lotId \| name, quantity \| "all", unit?, type consume\|discard, reason? |
| POST | /api/inventory/set | productId, quantity, unit?, expectedTotal? (409 if stale). Records the estimate seen → trains predictor |
| PATCH | /api/inventory/lots/:id | quantity?, expectedVersion?, expiresOn?, location? |
| POST | /api/inventory/lots/:id/move | to (fridge\|freezer\|pantry\|location id), quantity? (splits) |
| POST | /api/inventory/undo | batchId |
| GET | /api/inventory/events?limit=&productId= | ledger history |
| GET | /api/inventory/verify | rebuild check: `{ lots, mismatches: [] }` |
| POST | /api/leftovers/:lotId | action eat\|discard\|freeze\|thaw, portions |
| POST | /api/devices/events | header `X-Larder-Token`; productId, type consume\|set\|add, quantity, eventId (idempotent) |

## Assistant
| Method | Path | Body |
|---|---|---|
| POST | /api/assistant | text, conversationId?, lang? (en\|nl), context? (UI section), clientRequestId? |
| POST | /api/assistant/undo | batchId |

Response: `{ conversationId, turnId, lang, reply, actions[{kind,label}], batchId, undoable, clarify?{question, options[{label,value}]}, clientAction?, data?, via: rules|ai, duplicate? }`.
Send a clarify option's `value` as the next `text` in the same conversation.

## Receipts & barcodes
| Method | Path | Body |
|---|---|---|
| POST | /api/receipts/scan | `images[{mediaType,data(base64)}]` (needs AI) **or** `text` (OCR / e-mail / digital), useAi? → draft with proposals |
| GET | /api/receipts, /api/receipts/:id | |
| POST | /api/receipts/:id/commit | lines[{index, action add\|skip, productId?, newProduct?, quantity?, packages?, location?, expiresOn?, duplicate reconcile\|add}], force? |
| DELETE | /api/receipts/:id | discard draft |
| GET | /api/barcode/:ean | local product, Open Food Facts data, suggested catalogue match |
| POST | /api/barcode/:ean/link | productId? (link) or name/packageSize/unit (create) |

## Shopping
| Method | Path | Body |
|---|---|---|
| GET | /api/shopping | groups by aisle, checked, count (recalculates plan-driven items) |
| POST | /api/shopping | name \| productId, packages?, quantity?, note? (merges duplicates) |
| PATCH / DELETE | /api/shopping/:id | checked?, packages?, note?, name? |
| POST | /api/shopping/complete | itemIds?, store? → ticked items become inventory |
| POST | /api/shopping/sync | force plan recalculation |
| GET | /api/shopping/suggestions | predictive suggestions with reason + confidence |
| POST | /api/shopping/suggestions/:productId/accept\|reject | packages? |

## Planner & recipes
| Method | Path | Body / query |
|---|---|---|
| GET | /api/plan?start=&days= | days with slots and per-person nutrition, week totals |
| POST | /api/plan | date, meal, recipeId \| leftoverLotId \| title, servings? |
| PATCH / DELETE | /api/plan/:id | date?, meal?, servings?, status planned\|skipped |
| POST | /api/plan/:id/cook | servings?, overrides?[{position, quantity?, productId?}], leftovers?{fridge,freezer} |
| GET | /api/recipes | q, ingredient, cuisine, diet, tag, maxMinutes, maxCost, maxKcal, minProtein, difficulty, servings, origin, saved=1, sort best\|match\|time\|protein\|cost |
| GET | /api/recipes/cook-now | ≥50 % in stock, expiring ingredients first |
| GET | /api/recipes/ask?q= | natural-language discovery ("high-protein dinner under 20 minutes") |
| GET | /api/recipes/:id?servings= | recipe, scaled match per ingredient, substitutes |
| POST | /api/recipes | user recipe (ingredients matched to products) |
| POST | /api/recipes/generate | prompt, servings?, lang? (needs AI) → stored, labelled `origin: ai` |
| POST | /api/recipes/:id/cook | as plan cook |
| POST | /api/recipes/:id/interaction | saved?, rating? |

## Other
| Method | Path | |
|---|---|---|
| GET | /api/analytics?days= | spending (weekly/monthly), top products, waste (value, reasons), price history, input sources |
| GET / PUT | /api/preferences | diet, dislikes, cuisines, householdSize, maxWeeknightMinutes, language, quickActions… |
| POST | /api/preferences/device-token | create token for device events |
| GET | /api/quick-actions | |
| GET / POST | /api/notifications(/read) | |
| GET | /api/export | full household data as JSON (GDPR export) |

## Daily cooking check-in & push
| Method | Path | Body / query |
|---|---|---|
| GET | /api/checkins?all=1 | settings `{enabled, time}`, pending planned meals (yesterday always; today after the check-in time, or always with `all=1`) |
| POST | /api/checkins/:slotId | answer cooked\|not_cooked\|tomorrow, servings?, leftovers?{fridge,freezer}. "cooked" deducts via the ledger; idempotent per meal |
| PUT | /api/checkins/settings | enabled, time (HH:MM, server local time) |
| POST | /api/assistant/greet | conversationId?, lang → `{ greeting }`: the assistant's "Did you cook X?" question (answer with `POST /api/assistant` "yes"/"no"/"tomorrow") or null |
| GET | /api/push/key | VAPID public key |
| POST | /api/push/subscribe, /api/push/unsubscribe | browser PushSubscription JSON / `{ endpoint }` |
| POST | /api/push/test | sends a test notification to this household's devices |

Receipt proposals also carry `quantityCertain` and `product` (unit, package size, piece name, `package_options`).
When `quantityCertain` is false, send the answered amount as `quantity` (total base units) and `packages` on commit.

## Dietary needs & fun stats
| Method | Path | Body / query |
|---|---|---|
| GET | /api/dietary | people `[{id, name, diets[], allergies[], avoid[] (product ids), kcal?, protein?}]`, options (diets, EU-14 allergens) |
| PUT | /api/dietary | `{ people }`. Recipes are filtered on the union of everyone's needs |
| GET | /api/stats/fun?period=month\|year\|all | most eaten (incl. unlogged use), eggs, milk, coffee, fruit & veg, variety, food rescued, meals cooked, streaks, top recipes, favourite cuisine, busiest day, shopping, waste rate, effort saved |

Recipe responses now include `allergens {required, optional}`, computed `diet[]`, and (cards) `suitable`, `adaptable`, `swaps`;
`GET /api/recipes/:id` adds `suitability {ok, conflicts, optionalConflicts, swaps, adaptable}`.
Barcode lookups add `conflicts` (e.g. `allergy:peanuts`). Receipt commit lines accept `damaged` (base units, logged as waste
with reason `damaged`). Discard reasons: `spoiled`, `damaged`, `expired`, `mouldy`, `leftover`, `other`.

## iPhone & Siri
| Method | Path | Body / query |
|---|---|---|
| GET | /api/tokens | Siri keys `[{id, name, created_at, last_used_at}]` (hashes never leave the server) |
| POST | /api/tokens | `{ name }` → `{ id, token, name }`: the token (`lrd_…`) is shown only this once |
| DELETE | /api/tokens/:id | revoke |
| POST | /api/shortcut/say | `Authorization: Bearer lrd_…`, `{ text, lang? }` → **text/plain** for Siri to speak. Empty text asks the daily cooking question. Follow-up questions continue on the next call. The token works for this endpoint only |

With `HTTPS=1` the plain-HTTP port serves `GET /setup` (install steps) and `GET /setup/larder-ca.crt`
(`application/x-x509-ca-cert`) and answers everything else with a 308 redirect to https.

## Voice lists
| Method | Path | Body / query |
|---|---|---|
| POST | /api/assistant/list | `{ text, lang }` → `{ lines: [{said, productId\|null, name, category, unit, qty, packageSize, pieceName, isNew, location}] }`: reads a spoken list without changing anything. Run-on speech ("milk eggs bread") is split per product |
| POST | /api/inventory/add-many | `{ items: [{productId? \| name?, quantity?, location?}], clientRequestId }`: adds all lines as one batch (one undo) |

## My recipes, week planner, cooking path
| Method | Path | Body / query |
|---|---|---|
| GET | /api/recipes?diet=vegan,pescatarian | several diets: recipes that fit any of them |
| GET | /api/recipes/mine | saved, rated, "more often" and own recipes (with `saved`, `rating`, `priority`) |
| POST | /api/recipes/import | `{ url }` → draft from the page's schema.org Recipe (title, servings, times, image, steps with timers, ingredients matched to products) |
| POST | /api/recipes/draft | `{ title, servings?, minutes?, ingredients (one per line), steps? }` → the same draft shape |
| POST | /api/recipes | save a draft (existing endpoint) |
| DELETE | /api/recipes/:id | own recipes only; planned meals with it are removed |
| POST | /api/recipes/:id/interaction | `saved?`, `rating?` 1–5, `priority?` −2 never … 2 favourite, `notes?`, `toTry?`, `ease?` 1 easy · 2 okay · 3 hard, `again?` would cook again |
| POST | /api/recipes/quick | `{ text, servings?, lang? }`: one sentence ("chicken fajitas with peppers, onion, rice and avocado") → saved recipe `{ recipe, existing, template, guessed, unmatched }` |
| POST | /api/recipes/from-stock | `{ servings?, lang? }` → a use-it-up recipe from the food at most risk, saved: `{ recipe, pattern, usesFirst }` |
| PUT | /api/recipes/:id | own recipes only (403 for built-ins): same body as POST /api/recipes; replaces content and ingredients |
| POST | /api/recipes/:id/copy | your own editable copy of any recipe |
| PUT | /api/recipes/:id/retention | `{ position, retention: 0.1–1 \| null }`: share of a fat or marinade counted as eaten, per household (422 for other ingredients) |
| GET | /api/recipes/imported | `{ urls }` of recipes this household imported (bulk import skips them) |
| GET | /api/achievements | `{ items: [{id, group, title, title_nl, emoji, xp, at}], total, xp, level, badges }` |
| POST | /api/plan/auto/preview | `{ start?, days?, servings?, fifo?, maxWeeknightMinutes?, replace?, seed?, avoid?, only? }` → `{ plan: [{date, recipeId, title, minutes, kcal, health, reasons, usesUp, existing}], summary }`. Changes nothing |
| POST | /api/plan/auto/apply | `{ days: [{date, recipeId}], servings }` → `{ added, shoppingAdded }` |
| GET / PUT | /api/plan/auto/prefs | `favouriteFoods` (product ids), `fifo`, `maxWeeknightMinutes`, `householdSize`; GET adds `options` for the picker |
| GET | /api/game | XP, level and path, streak (with rest day), balanced streak, last 7 days, weekly quests, badges, recent meals with XP breakdown |

Recipes now include `health {score 0–100, grade, vegGrams, vegKinds, parts}`, `assumedFat` (g oil per serving added for frying),
`nutritionCoverage {known, total}` and `protein` (main protein). Cook responses (`/api/recipes/:id/cook`, `/api/plan/:id/cook`)
include `reward {xp, parts, score, streak, level, levelUp, totalXp}`.

## Kitchen assistant (phase 2)
| Method | Path | Body / query |
|---|---|---|
| POST | /api/plan/auto/preview | now also `fifo: off\|balanced\|strong`; each day has `why [{factor, points}]`, `extraCost`, `locked`; summary has `extraCost`, `learned` |
| PATCH | /api/plan/:id | `locked: true\|false`: locked meals survive "redo planned days" |
| POST | /api/plan/:id/swap | the next-best recipe for that day; the old one is remembered as swapped out |
| GET | /api/insights/learned | what PantryPip learned (quick meals, favourite protein/cuisine, high protein, often wasted, often swapped), each with `active` |
| POST | /api/insights/learned/:id | `{ active }`: switch an insight off or on |
| POST | /api/recipes/:id/interaction | adds `notes`, `toTry` |
| GET | /api/recipes/:id | adds `history` (cook dates), `interaction.notes/to_try/swapped_count`; `health` uses the household's targets |
| POST | /api/recipes/:id/photo | `{ data: dataURL }` for your own recipes; served from `/api/photos/:file` |
| PUT | /api/game/settings | `xpRules {…}`, `nutritionTargets {fibre, saltMax, satFatPct, sugarPct}`, `accent` (must be unlocked) |
| POST / DELETE | /api/game/challenge | `{ id }` to join (7 days from today) / leave |

Recipes carry `nutritionPerServing` and `nutritionTotal` with `kcal, protein, carbs, sugars, fat, satFat, fibre, salt`, and `nutritionAudit`:
one line per ingredient with `grams`, `status` (`counted`, `assumed`, `optional`, `no_product`, `no_amount`, `no_data`), `source`, `missing` and `contribution`.
`GET /api/game` now returns 21 levels in 7 ranks, `streaks {cooking, nutrition, exploration, lowWaste, planning}`, `nutrition {today, weekAverage}`,
`challenge {current, suggestions, completed}`, `rules`, `accent`, `accents`, `targets`.

## Journey, dashboard and personalisation
| Method | Path | Body / query |
|---|---|---|
| GET | /api/journey | 7 chapters (`path` of tasks, reward chest, final challenge; `bonus` beside the path), node `state` = completed · current · available · locked · bonus, `current` (the next step, with `cta`), 5 `tracks`, `companion` (skin, stages, looks), `decor`, `collections`, `fresh` (not yet celebrated) |
| GET | /api/journey/fresh | evaluates and returns uncelebrated nodes with titles (for the "you moved forward" toast) |
| POST | /api/journey/seen | marks everything as celebrated |
| POST | /api/journey/swap | `{ nodeId }`: replace an open task with another from the same chapter |
| PUT | /api/journey/companion | `{ skin?, name? }` (skin must be unlocked: 403 otherwise) |
| GET | /api/journey/collection/:id | recipes in an unlocked reward collection (`useitup`, `world`, `balanced`) |
| GET | /api/dashboard?device=phone\|tablet\|desktop | `config` (profiles with layouts per device), `widgets` (library of 37), `presets` (9), `suggestions` (read-only) |
| PUT | /api/dashboard | the whole config `{ version: 1, active, profiles: [{ id, name, preset, layouts: { phone?, tablet?, desktop? } }] }`, widgets `{ id, type, size: s\|m\|l, view: compact\|expanded, pinned?, hidden? }` |
| POST | /api/dashboard/reset | back to the default profiles |
| GET | /api/dashboard/data?types=a,b,c | live data for those widgets only |
| POST | /api/dashboard/usage | `{ key: open:<section> \| widget:<type> \| recipe:favourite }` (counted per day, per person) |
| POST | /api/dashboard/suggestions/:id/dismiss | stop suggesting it |
| GET / PUT | /api/preferences/me | `{ appearance: { style: larder\|lavender\|herb\|citrus\|night\|ink, theme, density, cards, motion, textSize } }`, per person |
| PUT | /api/preferences | adds `favouriteFoods, mealTypes, maxWeekendMinutes, maxDifficulty, planDays, planningDay, autoPlanFifo, ratingWeight, overlap, variety, budgetPerServing, newPerWeek, nutritionPriorities, scoringSensitivity, notifications {…}, interaction {…}`; GET returns them merged with defaults plus `cuisineOptions`, `mealTypeOptions` |

Cooking routes accept `deduct: false` (log the meal only); by default they follow `interaction.autoDeduct`.
The cooking `reward` now includes `journey` (nodes completed by that meal) and their XP in `parts`.


## Settings (one source of truth)
| Method | Path | Body / query |
|---|---|---|
| GET | /api/settings | `{ household: {...every household setting, with defaults}, me: { language, appearance {...}, startPage }, rev }`. Stored values are validated on read: old shapes are migrated, invalid values fall back to the default (objects field by field). Reading never writes. |
| PATCH | /api/settings | `{ household?: { key: value }, me?: { key: value } }`. Only the keys sent change; object settings (`notifications`, `interaction`, `cookCheckin`, `nutritionTargets`, `xpRules`, `appearance`) merge field by field. Validated as a whole: any invalid or unknown key → 422 with `details`, and nothing is stored. Returns the full settings with a new `rev`. Choosing `me.language` also sets the household reminder language. |

The schema lives in `server/src/domain/settings.ts`. The older endpoints (`PUT /api/preferences`, `/api/preferences/me`, `/api/plan/auto/prefs`, `/api/checkins/settings`, `/api/game/settings`) still work and read/write the same stored keys; the app itself only uses `/api/settings` (plus `/api/dietary` for people and `/api/dashboard` for layouts).

## Ingredients, substitutions and supermarkets
See docs/INGREDIENTS.md for the model.

| Method | Path | Body / query |
|---|---|---|
| GET | /api/ingredients/:id | One ingredient: family and its types, subcategory, measurement definition, availability in your country, supermarket products by chain (status, source, last verified), usual pack sizes. |
| GET | /api/ingredients/review | Recipe lines in your recipes that are unresolved or replaced by something close, grouped by original, with counts. `?all=1` includes exact equivalents. |
| PUT | /api/ingredients/choice | `{ key, choice }`: `key` is the original ('x:habanero', 'u:<name>', 'f:<family>' or a product id); `choice` is a product id, `'keep'` (the original, not tracked) or `null` (back to the default). Applies to every recipe and the shopping list. |
| GET | /api/ingredients/types | Your usual type per family. |
| POST | /api/ingredients/custom-type | `{ family, name }` → a household-only type in that family (inherits the family's measurements). |
| GET | /api/ingredients/country | Countries (with whether data exists), your country and whether you chose it. |
| POST | /api/ingredients/locate | `{ lat, lon }` → sets the country from your location (unless you chose one). Coordinates are not stored. |
| POST | /api/inventory/lots/:id/product | `{ productId }` → move a wrongly matched stock item, with its history, to another product of the same unit. |

Recipes: each ingredient has `match`, `sub` (original, kind, note, preparation, your choice, options) and the
recipe has `compat` (`full` · `substitutions` · `partial` · `specialist`). `GET /api/recipes?compat=full|available`
filters on it. Shopping items planned from meals carry `plan` (need, have, packs, pack size, left over).
