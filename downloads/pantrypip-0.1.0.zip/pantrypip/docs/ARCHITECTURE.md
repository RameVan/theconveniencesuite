# Architecture

## Principles

1. **Effort is the enemy.** Every design decision is judged by how much maintenance it saves the user.
2. **One ledger.** Every inventory change is an append-only event. Lot quantities are a materialised
   sum of those events and can be rebuilt (`GET /api/inventory/verify`).
3. **Confirmed ≠ estimated.** The ledger holds what a person or a deterministic event (receipt, cooking)
   established. Predictions are computed at read time and never written back.
4. **AI proposes, the ledger disposes.** Claude output (receipt lines, command intents, recipes) is
   validated against schemas and goes through the same functions as manual input. AI has no write path.
5. **AI-free by default.** Deterministic parsers handle commands and receipts, and photos are read on
   the device. The optional Claude integration stays off unless `AI_ENABLED=1` and a key are set.
6. **One process, one file.** Node + SQLite. No queue, no cache server, no external database.

## Stack and why

| Concern | Choice | Alternatives considered | Why |
|---|---|---|---|
| Runtime | Node 24, TypeScript run natively (type stripping) | Bun, Deno, compiled TS | No build step for the server; standard Node |
| HTTP | `node:http` + 150-line router | Fastify, Express | Tiny surface, no framework churn; validation via zod |
| Database | SQLite via built-in `node:sqlite`, WAL mode | Postgres, better-sqlite3 | Zero ops, single-file backup, no native module compile on Windows/ARM; `BEGIN IMMEDIATE` serialises writers |
| Validation | zod v4 | hand-written | Same schemas drive AI structured outputs |
| Auth | scrypt password hashes, hashed session tokens in HttpOnly SameSite=Lax cookie, 120-day sessions | OAuth, passkeys | Self-hosted household; long sessions keep "open and speak" fast. Passkeys are a good next step |
| Real-time sync | Server-Sent Events, scope-based invalidation | WebSockets, CRDT | One-way change notification is all a household needs; clients refetch |
| Frontend | React 18 + Vite, hand-written CSS design system, lucide icons | Next.js, Tailwind, component libs | Small bundle (84 KB gz), full control over the look |
| Offline shell | Service worker app-shell cache, PWA manifest with shortcuts | Workbox | Simple, no build plugin |
| Speech-to-text | Web Speech API (nl-NL / en-US), keyboard dictation as fallback | Whisper, Deepgram | Free, instant, no audio leaves the app server; see RESEARCH §7 |
| Command understanding | Rule parser (EN/NL) → Claude structured output fallback | LLM-only | ~1 ms, offline, predictable; LLM for the long tail |
| Receipt OCR | Claude vision (server) **or** Tesseract.js `nld+eng` in the browser | Veryfi/Mindee | Works with or without a key; no per-month minimums |
| Receipt structure | Rule parser for Dutch layouts + learned alias table | AI-only | Learns per store; testable; cheap |
| Barcodes | Native `BarcodeDetector`, zxing-wasm ponyfill on iOS/Firefox | QuaggaJS | Best decode quality per platform |
| Product data | Open Food Facts v2 via server proxy with permanent cache | Commercial GS1 data | Free, ODbL, respects 15 req/min limit |
| Recipes | Original built-in recipes, user recipes, AI recipes (labelled); provider slot for TheMealDB/Edamam | Scraping | Licensing (RESEARCH §6) |
| Background jobs | In-process timer every 30 min | cron, BullMQ | Notifications, auto-finishing shopping trips, daily backup |
| Backups | `VACUUM INTO data/backups/larder-YYYY-MM-DD.db`, keep 14 | litestream | Consistent online snapshot; copy off-box yourself |

## Layout

```
server/
  src/
    index.ts            app factory + entry point
    config.ts           all configuration from env (secrets stay server-side)
    db/                 Db wrapper, migrations/, catalogue (≈100 NL/EN products), seed recipes, demo seed
    domain/
      ledger.ts         THE write path: addStock, deduct (FIFO), setProductQuantity, moveLot, undoBatch, verifyLedger
      inventory.ts      read model: confirmed vs estimated, status, expiry, corrections
      prediction.ts     consumption-rate model + confidence
      products.ts       matching (EN/NL synonyms, stemming, fuzzy), product CRUD
      units.ts          units & number words in EN/NL, conversions, package rounding
      receipts.ts       Dutch receipt parser, matching, alias learning, duplicate & reconcile logic
      barcode.ts        Open Food Facts lookup + linking
      recipes.ts        nutrition, cost, inventory matching, substitutions, search & ranking, cooking
      planner.ts        week plan, requirements
      shopping.ts       list, plan sync, trip completion, predictive suggestions + feedback
      analytics.ts      spending, waste, price history, input sources
    assistant/
      parser.ts         deterministic NL → intents (EN + NL)
      engine.ts         dialogue: resolution, clarification, execution, undo, corrections, answers
    ai/ai.ts            Claude: command interpretation, receipt vision, recipe generation (all optional)
    http/               router + server, auth, routes (API)
    scheduler.ts        notifications, auto trip completion, backups
    bus.ts              change notifications → SSE
  test/                 workflow tests (HTTP) + parser/receipt unit tests
web/
  src/
    api.ts              fetch wrapper, query cache, SSE invalidation, request ids
    App.tsx             shell, routing, global sheets
    components/         Assistant, QuickSheet, ReceiptSheet, BarcodeSheet, cards, ui primitives
    pages/              Home, Inventory, Planner, Discover, Recipe (+ CookMode), Shopping, Insights, Settings, Login
    styles.css          design tokens (light/dark), components
```

## Data model (see `server/src/db/migrations/001_init.sql`)

- `products`: catalogue rows (`household_id` NULL) and household products. Base unit (g/ml/pcs),
  package size, piece size (for "2 slices"), price, store, default location, shelf lives, synonyms (EN+NL),
  nutrition per 100 g with its source.
- `inventory_lots`: one row per purchase/leftover. Confirmed `quantity`, location, purchase date,
  expiry (+ whether estimated), opened/frozen timestamps, source, `last_confirmed_at`, unit price, `version`.
- `inventory_events`: append-only ledger: type (purchase, consume, discard, cook, adjust, transfer,
  freeze, thaw, leftover, undo), signed delta, quantity after, source (manual, voice, assistant_ai, receipt,
  barcode, shopping_list, recipe, device…), reason, `predicted_before` (training signal), `batch_id`,
  `reverses_event_id`, unique `idempotency_key`.
- `purchases`: price and quantity per purchase (prediction + analytics).
- `receipts` (+ fingerprint for duplicate detection), `receipt_aliases` (learned store-specific mappings).
- `shopping_items` (reason, plan-driven flag), `suggestion_feedback` (accept/reject learning).
- `recipes`, `recipe_ingredients`, `recipe_interactions` (saved, rating, cooked, skipped).
- `meal_slots`, `preferences`, `assistant_turns` (dialogue memory + dedupe), `product_lookups` (OFF cache),
  `notifications`, `audit_log`, `households`, `users`, `sessions`, `storage_locations`.

## Correctness under concurrency and duplicates

| Risk | Defence |
|---|---|
| Double tap / network retry | Client sends `clientRequestId` → deterministic `batch_id`; a second request returns the first result |
| Same voice command said twice | Identical utterance within 30 s that changes stock → assistant asks "Do it again?" |
| Concurrent writers | `BEGIN IMMEDIATE` transactions; relative deltas commute; deductions clamp at zero and report shortfall |
| Stale absolute edits | `expectedTotal` / `expectedVersion` → HTTP 409 |
| Same receipt scanned twice | Fingerprint of store + date + total + lines; second commit → 409 unless forced |
| Shopping list ticked *and* receipt scanned | Receipt lines matching a recent `shopping_list` purchase reconcile that lot instead of adding |
| AI misreads | AI output is a proposal shown in review; nothing is written until confirmed |
| Undo | Every command's events share a batch; `undo` writes reversing events (history kept) |

## Prediction model (`domain/prediction.ts`)

- **Cycle rate** = quantity bought ÷ days to next purchase, recency-weighted (half-life 45 days).
- **Logged rate** = consume/cook/discard events over the last 60 days.
- **Total rate** = max(cycle, logged). **Implicit rate** (unlogged use) = total − logged, × correction factor.
- **Estimate** = confirmed − implicit × days since last confirmation (frozen stock excluded).
- **Correction factor**: every user correction stores `usageRatio` = actual ÷ predicted use since the
  last confirmation; the recency-weighted mean (clamped 0.2–3) scales future decay.
- **Confidence**: grows with cycles observed (0.15 → 0.82), shrinks with variance between cycles and
  with time since confirmation. Below 0.4 the UI shows the confirmed number, not an estimate.
- **Run-out date** and **overdue** detection drive suggestions and notifications.
- Seasonality: data is day-stamped; the shopping suggester already looks for same-month purchases in
  previous years. A proper seasonal component needs a year of data.

## Effort-saving features, by mechanism

| Mechanism | Where |
|---|---|
| Receipt photo / pasted e-mail receipt → reviewed purchase | `ReceiptSheet`, `domain/receipts.ts` |
| Learned receipt abbreviations and package sizes per store | `receipt_aliases` |
| Voice & text commands in EN/NL with follow-ups, corrections and undo | `assistant/*`, `Assistant.tsx` |
| One-tap consumption chips (configurable) | Home, Settings |
| "Cooked it" deducts all ingredients; leftovers become lots | `cookRecipe` |
| Ticked shopping items become stock (auto after 6 h) | `completeTrip`, scheduler |
| Buying something removes it from the list | `execItem`, `/inventory/add` |
| Regulars that run out go on the list automatically | engine |
| Estimates decay in the background; corrections retrain | prediction |
| Plan → list with only the shortfall, rounded to packages | `syncPlanToShopping` |
| Opening a product shortens its expiry estimate | `markOpened` |
| Device/webhook endpoint for scales / Home Assistant | `POST /api/devices/events` |
