# Public test copy (app.theconveniencesuite.com)

One container on Fly.io, with its own database on a volume. It never touches your own `data/larder.db`.
Sign-up is open; each tester gets a private household. The demo household is off (`SEED_DEMO=0`).

## One-time setup (you)
1. Create a Fly.io account at fly.io and add a card (a 512 MB machine plus a 1 GB volume costs a few euros a month; it sleeps when nobody uses it).
2. Install flyctl: `powershell -Command "iwr https://fly.io/install.ps1 -useb | iex"`, then run `fly auth login`.

## First deploy (from this folder)
    fly launch --no-deploy --copy-config --name pantrypip
    fly volumes create pantrypip_data --region ams --size 1
    fly deploy
    fly certs add app.theconveniencesuite.com

The domain's DNS is at Cloudflare. Add two records for `app`, with the proxy **off** (grey cloud, "DNS only"), or Fly can't issue the certificate:
- `A` `app` → `66.241.124.206`
- `AAAA` `app` → `2a09:8280:1::1ef:2860:0`

The site itself stays on GitHub Pages. Check progress with `fly certs check app.theconveniencesuite.com`.

## Updates
`fly deploy` after each commit. The database stays on the volume.

## Android APK (after the copy is live)
Go to pwabuilder.com, enter `https://app.theconveniencesuite.com` and choose Android → Download. It builds a signed APK from the PWA. Put `assetlinks.json` from that zip in `web/public/.well-known/` and redeploy, so the app opens without a browser bar. The APK goes in the site's `downloads/` folder.

## iPhone
Safari → Share → Add to Home Screen. There's no App Store build (that would need an Apple Developer account and a Mac).

## Status (2026-11-07)
- Live at https://app.theconveniencesuite.com (Fly.io app `pantrypip`, region ams, volume `pantrypip_data`).
- Android package `com.theconveniencesuite.pantrypip`, built with PWABuilder. The APK is offered at theconveniencesuite.com/downloads/pantrypip-0.1.0.apk.
- The signing key is in `D:\Documents\RameClaude\PantryPip-android-signing` (outside every repo). Keep a backup: every future version of the app must be signed with this key, and `web/public/.well-known/assetlinks.json` must keep its fingerprint.

## Sign-up alerts
Set `SIGNUP_ALERT_EMAIL` (a Fly secret) to the email of your account on the public copy. Each new sign-up then pushes "New PantryPip account: <name> signed up · N accounts now" to every device where that account has notifications on (Settings → Notifications). Only the name is sent, never the email.

## Invite only
`INVITE_ONLY = "1"` (in `fly.toml`) means nobody can sign up without an invite. An invite is either:
- **a friend's code or link** (Progress → Friends → share your link): the newcomer gets their own household and is friends with you straight away (and you both get the invite reward once they cook), or
- **a household's invite code** (Settings → Account & data): the newcomer joins that household.

Opening an invite link while signed out starts on "Create account" with the code filled in. Wrong codes count as failed attempts and are rate-limited per IP. Test accounts you make from owner test mode don't need one. Leave `INVITE_ONLY` out to let anyone sign up again. The home copy doesn't set it.

## Email (account confirmation, forgot password)
New accounts exist only after the emailed link is opened; "Forgot password?" emails a one-hour link.

### From your own Gmail address (simplest)
1. Turn on 2-Step Verification for the Google account (myaccount.google.com → Security). App passwords need it.
2. Go to myaccount.google.com/apppasswords, name it "PantryPip" and copy the 16-letter password. It only works for sending mail, and you can revoke it there any time.
3. Set it on Fly yourself (it never goes in the repo), with your own address:

       fly secrets set SMTP_HOST=smtp.gmail.com SMTP_USER=you@gmail.com SMTP_PASS="abcd efgh ijkl mnop" --app pantrypip

   The app restarts by itself. Emails then come from `PantryPip <you@gmail.com>`; replies go to your inbox, and sent mail shows up in your Gmail "Sent" folder. Gmail allows about 500 emails a day.
4. Test: sign up on the site with another address of yours. If nothing arrives, `fly logs` shows "email failed" with Gmail's reason.

`SMTP_PORT` defaults to 465 (TLS); 587 uses STARTTLS. Any other mail provider's SMTP works the same way. SMTP is used when `SMTP_HOST` is set, otherwise Resend.

### Through Resend (from @theconveniencesuite.com)

1. Create a Resend account and add the domain `theconveniencesuite.com`. Resend shows DNS records (SPF, DKIM, and a return-path MX); add them in Cloudflare as **DNS only** and wait until Resend says *Verified*.
2. Create an API key with "Sending access" and set it on Fly yourself (it never goes in the repo): `fly secrets set RESEND_API_KEY=re_…`
3. Optional: `MAIL_FROM` (default `PantryPip <noreply@theconveniencesuite.com>`).

`PUBLIC_URL` (in `fly.toml`) is where the links point. Without `RESEND_API_KEY` nothing is sent: the email, link included, is written to the server log (`fly logs`). `EMAIL_CONFIRM=0` turns confirmation off.

## Owner test mode
`OWNER_EMAIL` (falls back to `SIGNUP_ALERT_EMAIL`) is the account that sees **Settings → Account & data → Test mode**: a sandbox (a checked copy of the database is made on entry; leaving puts every row of your household back), unlock everything, time travel for your household only, and test accounts without email confirmation. Snapshots live in `BACKUP_DIR/test-mode/` and are removed after a restore.
