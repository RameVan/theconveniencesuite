# Implementation log

## 2026-11-02

**Inspect.** No existing project, so nothing to preserve. Tooling: Node 24.14 (built-in `node:sqlite`,
native TypeScript type stripping), npm 11, git, Windows 11.

**Research** (docs/RESEARCH.md). Verified: no official AH/Jumbo/Lidl/Picnic APIs, only reverse-engineered
clients; Open Food Facts 15 reads/min/IP; NEVO terms; Web Speech availability; BarcodeDetector
disabled by default on iOS Safari. Main conclusion: cheap purchase capture + inferred consumption with
honest confidence + one-gesture correction.

**Decisions.**
- Node + SQLite, single process. Postgres was rejected: no multi-tenant scale needed, and SQLite makes
  backups a file copy.
- `node:sqlite` over better-sqlite3: no native compile step on Windows/ARM home servers.
- Event ledger with materialised lot quantities and a verify endpoint, not a mutable "quantity" field.
- Predictions computed on read; never stored as stock.
- Rule-based EN/NL parser first, Claude as fallback. LLM-first was rejected: latency, cost, offline
  use and testability.
- Receipt: two-stage (image→text→lines), so OCR can be AI or on-device and the line parser is shared.
- Recipes: original seed recipes. Scraping rejected for licensing.
- Frontend: React + Vite + hand-written CSS. No UI kit, so the visual language could be custom.

**Built.** Schema and migrations; catalogue of ≈100 Dutch/English products with synonyms and receipt
abbreviations; 21 original recipes; ledger (add, FIFO deduct, set/correct, move/freeze/thaw with
expiry changes, undo, verify); prediction; inventory read model; recipe matching, substitutions,
ranking, cooking with leftovers; planner; shopping list with plan sync, package rounding, trip completion,
suggestions with reject-learning; Dutch receipt parser with alias learning, duplicate detection and
reconciliation; Open Food Facts lookup; analytics; assistant parser + dialogue engine; optional Claude
integration; auth, SSE, scheduler, backups; API; demo seed with ten weeks of history.

**Tested.** 29 workflow tests at first run: 27 passed. Fixed: a pending clarification ("Any
leftovers?") swallowing the next full command. Added parser/receipt unit tests: 38/38.

**Frontend.** Shell with bottom tabs (mobile) / side rail (desktop), assistant sheet with Web Speech,
quick sheet, receipt sheet (AI or Tesseract OCR, review, learning), barcode sheet (native + WASM),
Home, Inventory, Planner (drag-and-drop), Discover, Recipe, Cooking mode (timers, wake lock, voice
"next"), Shopping (+ shopping mode), Insights, Settings, Login. PWA manifest with home-screen shortcuts.

**Browser testing found and fixed.**
- Recipe carousel blew the mobile layout out to 948 px wide (grid `min-width` issue).
- "≈ 0.46 tomatos": countables now round to halves, show "<1", and pluralise properly.
- "I finished the milk" asked "Add to list?", which kept the panel open. Regulars now go on the list
  automatically (undoable) and the panel closes itself.
- Plan-driven list items only synced on plan edits. Now recalculated on read.
- That change caused a refetch loop: estimates drift every second, so each read changed the list and
  notified clients. Shortages are now rounded and only meaningful changes notify. Regression test added.
- Recipe illustrations too small on phones (container-relative sizing). Planner titles truncated on desktop.

**State at end of session.** 39/39 tests pass, production build 84 KB gz, all five sections working
in the browser on mobile and desktop, light and dark.

## Known limitations / next steps
- Real Claude calls, camera and microphone not exercised in this environment (see TESTING.md).
- No push notifications yet (notifications are generated server-side and shown in-app). Web Push
  needs VAPID keys + HTTPS.
- Household members share one inventory; per-person consumption profiles are modelled by `user_id`
  on events but not yet surfaced in the UI.
- Seasonality uses same-month-last-year purchases only.
- Catalogue product edits apply to the shared row (fine for a single household per server).
- Passkeys would make sign-in effortless on new devices.

## 2026-11-02 (later): cooked-dish voice commands, daily check-in, receipt quantities

Requested: "I've cooked X" by voice, a daily question whether a planned dish was cooked, and receipt
quantity questions that fit each product (eggs → how many eggs, tomatoes → how many tomatoes).

- **Voice.** Probing the parser showed gaps: "cooked the dal", "net pannenkoeken gebakken",
  "vanavond chili gemaakt" weren't recognised, "I cooked dinner" looked for a recipe called "dinner",
  and **"ik heb de curry niet gekookt" was parsed as cooked, so it would have deducted the ingredients**.
  New: broader cooked phrasing (EN/NL), meal words ("dinner is done" → today's planned dinner), a
  `not_cooked` intent ("I didn't cook X", "we skipped X", "… niet gekookt") that skips the meal and
  offers to move it to tomorrow, Dutch dish words mapped to recipe titles (omelet, soep, zalm, linzen…),
  yesterday's open meals included, leftovers eaten by name ("we ate the dal" → how many portions?),
  and dishes without a recipe ask what went into them. "I had a banana" stays consumption.
- **Daily check-in.** `domain/checkins.ts`. Default on, 20:00, set in Settings. Shows as a card on
  Home (Yes → leftovers? → done; No; Tomorrow), as the assistant's first question when opened ("Did you
  cook X tonight?" → say "yes"), and as a Web Push notification with Yes/No buttons that work from the
  lock screen (service worker posts the answer). VAPID keys generated on first use. Answers are
  idempotent per meal. Scheduler now ticks every 10 min.
- **Receipt quantities.** Products now carry `package_options` (common pack sizes). A line is
  "certain" when it's weighed, prints a usable size, was learned before, or the product has one size;
  otherwise the review shows a question in the product's own unit with its usual sizes as one-tap
  options plus free entry ("600 g" of tomatoes → 6 tomatoes via the typical piece weight). Multi-pack
  lines ask per pack. Answers are learned per store line, so the same line isn't asked again.
  New products created in review ask how they're counted (pieces / g / ml) and how much.
- Tests: 11 new (50/50 passing). Checked in the browser: Settings section, Home card flow, receipt
  questions with chips and typed weight; stock and ledger verified after commit.

## 2026-11-02 (later): dietary needs, "your year in food", custom amounts everywhere

- **Dietary needs.** Products carry EU-14 allergens and diet flags (meat, pork, fish, animal, alcohol);
  catalogue tagged by hand, barcode products from Open Food Facts `allergens_tags` /
  `ingredients_analysis_tags`. Recipes' diets and allergens are computed from their ingredients (the
  seed's hand-written tags were wrong in places: the "vegan" stir-fry contains honey). Settings has a
  per-person editor (diets, allergies, avoided ingredients, kcal/protein targets); suggestions use the
  union of everyone's needs. Recipes that clash are left out unless a curated swap fixes every clash
  ("swap chicken breast for tofu"), shown on the card and as a banner on the recipe page. Substitutes
  never suggest something unsafe. Scanning a product someone is allergic to shows a warning. Planner
  day headers show kcal against the household's average target.
- **Your year in food** (Insights): most eaten (counts unlogged use: bought-and-gone counts, via
  the ledger), eggs, milk, coffee, bread, fruit & veg kg and variety, food rescued before its date,
  meals cooked, streaks, top recipes, favourite cuisine, busiest weekday, shopping days, waste rate,
  effort saved. Month / year / all. Added a `cook_log` so meals cooked with nothing in stock count too.
  Demo seed includes ten weeks of cooking.
- **Custom amounts everywhere.** Voice understands damage ("an egg broke in transit", "I broke 3 eggs",
  "2 eieren waren kapot"; "the eggs broke" asks how many instead of binning all). Throw-away sheet asks
  why (went bad, broken, past date, mouldy, other) and how much; the bin button on inventory rows opens
  it instead of discarding everything. Receipt review: every line's amount is tappable, with an
  "arrived broken or already bad" field that's logged as waste. "I cooked this": tap any ingredient to
  set the amount actually used. Leftovers: eat/throw away/freeze any number of portions. Barcode: any
  amount.
- **Bug found by the new tests:** undoing a meal cooked with nothing in stock returned "not found",
  so it stayed logged. Undo now recognises cook-only batches.
- The browser demo database was recreated so it includes cooking history; the previous one is kept
  in `data/previous-demo/`.
- Tests: 10 new, 60/60 passing.

## 2026-11-02 (later): iPhone

- **Home-screen app:**
  - 180 px apple-touch-icon plus PNG manifest icons (192, 512, maskable), rendered from the SVG.
  - Full-screen standalone mode with a translucent status bar.
  - Layout respects the notch and the home indicator (`env(safe-area-inset-*)`).
  - Inputs are 16 px on touch screens, so Safari doesn't zoom.
  - No double-tap zoom on buttons, and no sticky hover states.
  - Home shows an "Add to Home Screen" hint on iOS. It warns when the page isn't on https, because
    camera and mic are blocked then.
- **HTTPS, two routes:**
  - `npm run serve:tailscale` (Tailscale Serve).
  - `npm run cert` + `npm run start:https`: a private CA via openssl, a server cert for this computer's
    names/IPs, TLS on 8443, and a plain-HTTP companion on 8787 that serves a `/setup` page with the
    profile and redirects everything else.
  - Cookies are Secure whenever the request came over https (direct or `X-Forwarded-Proto`).
- **Siri Shortcut:**
  - Per-household keys (`api_tokens`, stored hashed, revocable) that only unlock `POST /api/shortcut/say`.
  - Returns plain text for Siri to speak.
  - Keeps the conversation per key, so follow-up questions work across runs.
  - An empty request asks the daily cooking question.
  - Settings → iPhone & Siri builds the steps with copy buttons.
- **Safari fixes:**
  - The mic starts within the tap gesture, as WebKit requires.
  - If speech recognition is refused, Larder says so and opens the keyboard for dictation.
  - Receipt photos are decoded through `<img>` so EXIF rotation is applied before scaling (iPhone
    photos were sideways).
  - The service worker cache was bumped.
- `index.ts` exports `main()` so `start:https` can reuse it. The request handler is shared between
  HTTP and HTTPS.
- Tests: 5 new, 65/65 passing. A WebKit iPhone 15 run found no layout or flow problems. Not yet tried
  on a physical iPhone.

## 2026-11-02 (later): voice lists and listening that waits

- **Whole lists in one go.** "I bought milk eggs bread cheese and 2 kg potatoes" now adds five products, even
  without commas. A run-on phrase is split into the products it names, longest match first, so "chicken breast"
  stays one item. Amounts belong to the item they precede, unknown words become new products, and filler
  ("uh", "then", "done") is dropped. More separators are understood: "then", "also", "daarna", "verder".
- **List mode** (Home → Bought, or the assistant's "Say everything you bought"). It keeps listening through
  pauses until you say "done"/"klaar" or tap stop. Recognised products appear as you talk, each with an
  amount you can change (−/+, or tap to type) or remove. Typing or keyboard dictation works the same way.
  Everything is added in one step with one undo.
- **The microphone waits for you.**
  - Before: recognition stopped at the first pause (iPhone Safari often before you'd started) and
    submitted half a sentence.
  - Now it uses continuous recognition, restarts when the browser gives up early, and keeps trying for
    12 s until it hears something.
  - It submits after about 1.5 s of silence.
  - Android Chrome's repeated results are de-duplicated.
  - Larder's spoken reply is cancelled before listening, so it doesn't hear itself.
  - When nothing was heard, it says so.
- **Speech language switch** (EN/NL chip in the assistant and list mode), separate from the app language.
  Recognition in the wrong language was a likely cause of "it doesn't hear me".
- Tests: 5 new, 70/70 passing. List mode checked in the browser (typed; this browser has no microphone).

## 2026-11-02 (later): my recipes, plan my week, macros, cooking path

- **More recipes and several diets at once.**
  - 28 new built-in dinners, 49 in total. Vegan went from 3 to 12, low-carb from 3 to 9, plus more pescatarian and gluten-free.
  - Discover's diet chips are multi-select: picking several shows recipes that fit any of them.
  - Household dietary needs still filter as before.
- **My recipes** (Discover → My recipes): saved, rated and own recipes. "Add recipe" has two ways in:
  - **Link:** reads the schema.org Recipe that most recipe sites embed (AI-free) and matches ingredient lines to products, e.g. "2 el olijfolie" → 30 ml olive oil, "1 blik kikkererwten" → one tin. Fractions, ranges, and "to taste" (optional) are handled.
  - **Type or paste:** one ingredient per line.
  - Either way you get a preview before saving. Your own recipes can be deleted.
- **Macros from ingredients.**
  - Calculated per serving as before, and now also counting about 1 tsp oil per serving when the method fries or roasts without listing a fat.
  - The recipe page shows a balance panel with kcal, protein, carbs and fat, an energy split bar, the score breakdown, vegetables per serving, and which ingredients the estimate is based on.
- **Balance score** (0–100) per meal:
  - Portion near the dinner target: 35% of the household's daily kcal target, default 700.
  - Protein ≥ 25 g, vegetables ≥ 200 g (potatoes don't count, legumes do), fat ≤ 35% of energy, and variety of vegetables.
- **Ratings & how often.**
  - Stars on the recipe page, plus a one-tap rating in the popup right after cooking.
  - "How often in Plan my week": never, less, normal, more, or favourite.
  - Favourite foods (salmon, chicken, tofu…) can be picked in the planner sheet.
- **Plan my week** (Planner):
  - One tap proposes dinners for every open day.
  - Scoring:
    - Ratings, "how often", favourite foods, what's in stock and balance count for a recipe.
    - Recipes eaten recently count against it.
    - It rotates chicken, fish, meat and veg, and cuisines.
    - Weeknights stay quick (≤ 30 min option) and breakfasts are skipped.
    - Dietary needs are respected.
  - **FIFO**: it simulates the week's stock, oldest or soonest-expiring first, and plans meals that use food before it goes off ("Uses up spinach").
  - Swap or skip any day, shuffle for another plan, then add it in one tap. Missing ingredients go on the shopping list.
- **Cooking path** (Home card → Path page), all derived from the cook log, so undo also removes XP:
  - **XP:** +10 per meal, +20 for a new recipe, up to +20 for balance, +5 per expiring food rescued, +5 for cooking as planned, and a streak bonus.
  - **Levels and badges:** 15 levels on a Duolingo-style winding path, and 13 badges worth +50 each.
  - **Streaks:** the cooking streak forgives one rest day a week. A balanced-meals streak counts meals scoring 70+ in a row.
  - **Weekly quests:** cook 4 dinners, try a new recipe, 3 balanced meals, rescue 2 expiring foods.
  - **Reward popup:** after every cook it shows the XP breakdown, streak, level progress and a level-up moment.
- Tests: 9 new, 79/79 passing. Browser-checked on a mobile viewport.

## 2026-11-02 (phase 2): one connected kitchen assistant

Branch `smart-kitchen`; the demo database was backed up to `data/backups-manual/` before migration 006.
Research and decisions are in RESEARCH-KITCHEN.md.

- **Navigation:** Home · Inventory · Recipes · Plan · Progress.
  - Shopping is a tab inside Plan, with the count on the Plan icon.
  - Statistics moved into Progress.
  - Settings is behind the gear icon on Home.
- **Home** shows at a glance:
  - tonight's dinner, how many items are on the shopping list, what's in stock and what to use soon;
  - your streak, rank and today's nutrition score;
  - a one-tap "Plan your week" prompt when fewer than 4 evenings are planned.
- **Voice and inventory:**
  - "half the chicken" is half of what's in stock;
  - "I opened the milk" opens the oldest pack and shortens its expiry (undoable);
  - "it went off" is understood as a reason.
- **Nutrition engine:**
  - **Nutrients:** 8 per 100 g for all 105 products (energy, protein, carbs, sugars, fat, saturated fat, fibre, salt).
  - **Densities:** spoons and cups convert to grams (oil 0.91, flour 0.55, honey 1.42, spices 0.45).
  - **Totals:** totals and per-serving values, with a per-ingredient audit (grams, source, status, contribution).
  - **Cooking fat:** fat is never dropped. Listed fat always counts, "oil for frying" without an amount counts 1 tsp per serving, and frying with no fat listed adds the same and says so.
  - **Scanned products:** Open Food Facts now supplies all 8 nutrients.
- **Balance score:**
  - It covers energy (scored in both directions), protein, fibre, vegetables, fat range, saturated fat, sugars and salt.
  - Targets come from each person plus household overrides (Progress → adjust).
  - The XP reward is full from 70, so there's nothing to gain from chasing 100 or eating less.
- **Recipe library:**
  - Notes, a "want to try" list, cooking history and your own photos.
  - Dictating ingredients and steps; a spoken run-on list is split into one ingredient per line.
  - Filters in My recipes: favourites, to try, added by me.
  - Imported recipe images now load (the image policy allowed only a few sites).
- **Planner:**
  - FIFO off / balanced / strong, using a spoilage risk (how perishable × how soon it expires, ×1.4 when opened; dry goods are never urgent).
  - Bonuses for untried recipes and to-try picks, and for ingredients shared within the week (leftover pack contents are tracked).
  - A penalty for extra shopping cost; swapped and skipped recipes are deprioritised.
  - Learned preferences are applied.
  - Locked meals; "Something else" swaps one day; each pick has a "why" breakdown, and the extra cost is shown.
- **Learning:**
  - Larder notices from the last 90 days:
    - quick meals;
    - a favourite protein or cuisine;
    - high-protein habits;
    - often-wasted foods (FIFO weighs them more);
    - often-swapped and much-loved recipes.
  - Each insight is shown in Progress and can be switched off.
- **Cook mode:**
  - Hands-free mode keeps the mic open and runs commands: next, back, repeat, timer, stop timer, ingredients, "how much butter?", done.
  - Optional read-aloud pauses the mic while speaking.
  - Each step shows the amounts it uses.
  - Timers beep audibly, vibrate and say which step's timer finished.
- **Progress:**
  - **Ranks:** 7 (Kitchen Beginner → Culinary Master) × 3 tiers.
  - **XP:** configurable XP for cooking, a new recipe, a favourite, cooking as planned, balance, rescued food, a new cuisine, a streak, a week cooked as planned, and a zero-waste week.
  - **Streaks:** five of them — cooking (a rest day a week, plus a repair after up to 2 missed days), nutrition, exploration, low waste and planning.
  - **Challenges:** 7 optional challenges, 2 suggested from behaviour.
  - **Badges:** 15.
  - **Accent colours:** unlocked by rank.
- **Performance:** recipe lists load all products in one query (49 recipes in about 5 ms).
- **Tests:** 87/87 (8 new scenario tests). The WebKit iPhone run is clean.


## 2026-11-02 (phase 3): the journey and your own home screen

Branch `journey-dashboard`; database backed up to `data/backups-manual/larder-before-journey-dashboard-20261102.db`.

- **Journey** (`server/src/domain/journey.ts`, migration 007): 7 chapters × 5 tasks, a reward chest halfway,
  a final challenge and a bonus task. Tasks are measured from the ledger, cook log, plan and recipes; picked
  when a chapter opens, preferring ones you can do now ("use 3 foods near their date" waits if nothing is
  near its date); any open task can be swapped. Each completed node is stored once (primary key), so XP
  can't be earned twice and history stays. Final challenges only count what happens after they open.
  Five skill tracks with 8 levels each. Pip, the companion, gains an apron, a chef's hat and a scarf;
  looks, kitchen decorations and recipe collections unlock along the way. Journey XP counts towards levels.
- **Progress screen** rebuilt: hero with XP count-up, streak, dinners this week, today's balance, challenge
  and the next step; a winding path per chapter, each in its own world; node states, progress rings,
  completion burst, Pip walking forward, chapter celebration; Tracks, Rewards and Habits tabs. Animations
  respect the system setting and the in-app Animations option.
- **Dashboard** (`server/src/domain/dashboard.ts`, `web/src/pages/Home.tsx`, `components/Widgets.tsx`):
  37 widgets with live data and inline actions, 9 presets, 4 default profiles, per-device layouts
  (phone 2 columns, tablet 3, desktop 4), edit mode with drag handles and arrow buttons, sizes, compact
  view, pin, hide, undo, reset. Usage-based suggestions are only offered, never applied.
- **Personalise** (`web/src/pages/Personalise.tsx`, `server/src/domain/personal.ts`): food (cuisines,
  ingredients, meal types, time, difficulty), planning (dinner days, planning day, FIFO, ratings weight,
  overlap, variety, budget, new recipes per week), nutrition (priorities, sensitivity, targets),
  reminders (six kinds, frequency all / daily summary / off, prep time), appearance per person (theme,
  spacing, cards, text size, animations), interaction (voice first, automatic deductions, shopping
  auto-complete, cooking mode defaults, confirm before throwing away). All wired into the planner,
  the scorer, the scheduler and cooking.
- **Fix found by the new tests:** retrying "Cooked it" for a meal with nothing in stock logged it twice
  (the duplicate check only looked at stock changes). It now also checks the cook log.


## 2026-11-02 (later): theme styles

Six styles under Settings → Personalise → Appearance → Style, from a reference with gradient glass,
pill controls and pastel tiles (design canvas "Larder rethemes"): Larder (unchanged default), Lavender
Glass, Herb Glass, Citrus Morning, Night Pantry (always dark) and Ink & Signal (flat, high contrast).

- `web/src/themes.css`: token overrides per style, each with a dark variant; a colour band behind the
  page header (taller on Home), accent fill on primary actions and the mic, and a floating pill tab bar
  on phones. `data-style` and `data-mode` on `<html>` are set by `appearance.ts`, which follows the
  theme setting and the system light/dark switch live.
- Per person, saved with the other appearance choices; the picker previews each style.
- System fonts only (`ui-rounded` for Citrus), so nothing is fetched from outside; the named web fonts
  in the stacks are used only if installed.
- Checked in WebKit at iPhone 15 size: 6 styles × light/dark × Home, Progress, Inventory. That found and
  fixed widget rows that didn't shrink on narrow screens (also in the default look).


## 2026-11-02 (later): reliable layout saving, optional spending & waste

- **Saving the home layout** (`web/src/pages/Home.tsx`): one save at a time, always the latest layout;
  flushed when you leave Home or the app (keepalive request); Home refetches on open and follows the
  server whenever nothing is unsaved, so a cached old layout can't come back and overwrite newer changes.
  Saves notify your other devices. Names are trimmed (never empty) and layouts capped at 8 before saving,
  so one bad value can't block every later save.
- **Drag and drop** now follows the finger on the window instead of relying on pointer capture, which iOS
  refused, so finger drags actually start.
- **Spending & waste is optional** (per person): a switch on the Statistics page and in Personalise →
  Appearance. Off hides the Spending & waste section and the money/waste tiles in Your year in food. On by
  default. The money widgets on Home were already opt-in.
- New: `e2e/app.e2e.mjs` (see TESTING.md).


## 2026-11-02 (phase 4): settings that stay put, and a much simpler app

Branch `simplify-and-persist`; database backed up to `data/backups-manual/larder-before-simplify-20261102.db`.

**Persistence**
- One settings schema (`server/src/domain/settings.ts`) with defaults and validation for every household and
  personal setting; `GET/PATCH /api/settings`. Reads validate and migrate (never write); patches are
  key-level, merged per field for objects, validated as a whole (rejected = nothing stored). The planner,
  reminders and check-ins read through the same validation.
- One settings store in the app (`web/src/settings.tsx`), loaded before any screen renders: instant
  optimistic changes, batched saves, one request in flight, rollback with a reason on rejection, changes
  kept on the device and retried when offline, newer server copies applied without undoing unsaved changes,
  live updates from other devices. A small "Saving… / Saved / Not saved" note for every save, including
  people (dietary) and Home layouts.
- Language now follows your account (it was stuck per device); start page is a personal setting.

**Simpler app**
- Navigation: Home · Groceries · Recipes · Planner · Progress. Shopping list is the second tab of
  Groceries; Statistics moved into Progress → Stats; Settings behind the gear (and in the desktop sidebar).
- Settings: seven categories (General, Food preferences, Meal planning, Nutrition, Notifications,
  Personalisation, Account & data), one page each, one row style, advanced options under "More options".
  Personalise merged in. The planner sheet no longer holds algorithm settings.
- Home: a calm default (tonight, shopping list, use soon, ideas), one suggestion at a time, layout switch only
  when you have more than one layout, "Customise Home" at the bottom; edit mode shows move/remove, with size,
  compact, pin and hide under "Options". Five presets instead of nine; one default layout instead of four.
- Groceries: one big "Add groceries" with voice and "use" next to it; "Use soon" first; filters, sorting,
  receipt, barcode and history behind buttons; product rows show name, amount and one warning, details and
  rare actions on tap.
- Recipes: For you · All · Saved; filters behind one button; cards show photo, time, your rating, favourite
  and how much you have (nutrition and cost stay on the recipe page).
- Planner: "Plan my week" first; missing ingredients as one link; no nutrition totals on the grid; the meal
  sheet leads with Recipe and Cooked it, then Swap, Lock, Skip, Remove; day and servings folded away.
- Progress: level, XP and streak in one row plus the next step; tabs Path · Rewards · Stats; scoring settings
  moved to Settings.
- New screens open at the top; history is only fetched when you open it.

## Spec check and gaps (2026-11-03)

- Checked the feature brief point by point (RESEARCH-KITCHEN §10). Built: recipes from one sentence (voice and
  a one-line box), use-it-up recipes from stock, ease and "cook again" answers that steer the planner, editing own
  recipes and "Edit a copy" for built-ins, per-household counted share for fats and marinades, carbohydrate
  balance in the score (with a low-carb range and settings), and fixed the assistant suggesting AI when it's off.
- Migration 008: `recipe_interactions.ease`, `recipe_interactions.again`, table `recipe_retention`.
- Tests: `quick-recipe.test.ts` (8). Browser-checked on a throwaway copy: from-stock recipe, editor, counted share,
  one-line recipe, reward with after-cooking questions, recipe page sync, carb targets.


## Recipe cache for large libraries (2026-11-03)

- Calculated recipes (nutrition, score, diets, cost) are cached per household in memory and shared read-only
  (frozen). `Db.recipeVersion` goes up on any write to recipes, ingredients, products or counted shares, so
  no write path can leave the cache stale; a rebuild runs in the background 0.5 s after a change. The rebuild
  loads products and ingredients in one query each instead of one per recipe.
- The week planner plans from a shortlist of 500 when there are more than 750 candidates (one quick score
  per recipe: stock, rating, how often, new, food at risk, seeded randomness).
- Measured on a copy of the database with library sizes up to 20,000 (ms per request, before → after):

  | Recipes | Recipe list | Cook now | Plan week | Progress | Journey | Rebuild after a change |
  |---|---|---|---|---|---|---|
  | 1,000 | 62 → 7 | 62 → 9 | 97 → 32 | 58 → 6 | 180 → 20 | 76 |
  | 10,000 | 667 → 45 | 661 → 48 | 1,092 → 58 | 599 → 7 | 1,854 → 66 | 661 |
  | 20,000 | — → 106 | — → 106 | — → 93 | — → 8 | — → 134 | 1,334 |

  Memory: about 180 MB for 20,000 cached recipes (~9 KB each). Beyond ~20,000 the next step is storing the
  calculated values in the database with search indexes.

## Bulk recipe import (2026-11-03)

- `npm run import:recipes` (server/scripts/import-recipes.ts, src/import/bulk-recipes.ts): Wikibooks Cookbook
  JSON and RecipeNLG CSV from files you downloaded, offline. Streaming CSV reader (2 GB is fine), fast name
  check first, full ingredient matching with a memo of lines already seen, quality bar, dedupe, 70 % dinners,
  tags from titles, estimated servings and times, credits and source links. Backup first; `--dry-run`, `--remove`.
- US units in the unit table (oz, lb, pint, quart, gallon, pkg); "diced/crushed/stewed tomatoes" are the tin.
- The recipe cache also watches SQLite's data_version, so the running server sees imports without a restart.
- Recipe page: the source name links to the original page; CC BY-SA links its licence.
- Checked on a copy with 200,000 generated rows in RecipeNLG's format: 4 s dry run, 7 s to add 15,000; the
  running server then served 15,138 recipes at 70–140 ms per screen. Real data not yet run (needs your download).

## Ingredient, substitution and Dutch supermarket overhaul (2026-11-03)

See docs/INGREDIENTS.md. In short:
- Matcher that never ignores a word that changes identity; five match kinds stored per recipe line;
  families with types asked once and remembered (incl. household custom types); 246 ingredients each with a
  measurement definition (recipe unit, minimum, precision, plausible maximum per serving, small measures).
- 67 Dutch substitutions and 75 foreign ingredients with per-country availability; shown as
  "Original → Replacement" on recipe pages, in cooking mode and on the shopping list; your choice holds everywhere.
- 847 Dutch supermarket products (846 EANs, 12 chains) from Open Food Facts, labelled listed/unverified.
- Pack-aware shopping (need / have / packs / left over across recipes); recipe compatibility in browsing,
  search and the week planner.
- Wikibooks import re-checked with the new matcher (`--refresh`): 567 recipes meet the bar (was 894 under
  the looser matching); recipes someone cooked, planned or saved are never removed.
- Stock phrases: "a pack of six chicken breasts", "half a bottle of olive oil", "ran out of butter",
  "I added milk" (asks the type once).
- Tests: 166 in total; the new ingredient suite includes a speed check (2,000 identifications against 2,000 extra products, under 0.5 ms each).

## 2026-11-03 — Shopping mode fix, webshop links

- Shopping mode: ticking off a meal-plan item made it come straight back (the plan sync only counted
  unticked items, so it re-added what was in the cart). Items in the cart now count as covered.
  Test: `server/test/shopping-mode.test.ts` (fails without the fix).
- Webshop search links per chain (see docs/INGREDIENTS.md, "Webshops"). Links only, no fetching:
  the chains' terms don't allow automated collection.
- AH and Jumbo own-brand products show without the brand, at that supermarket (display only).

## 2026-11-03 — Dutch product catalogue (Open Food Facts export)

- From 847 products found by searching per ingredient to the whole Dutch range: 108,681 products from Open Food
  Facts' daily export (`npm run fetch:off-dump`, `npm run import:catalogue`; see docs/INGREDIENTS.md).
- Add sheet: "In the shops" under the ingredient matches, with photo, brand, size and shop, and "counts as …"
  when it's one of our ingredients. Picking a non-ingredient product makes it the household's own product.
- Barcode scans use the catalogue first (no network needed for products it knows).
- Linking stays strict: name only, checked against categories; category-only linking was tried and dropped
  (about a third wrong). Old per-ingredient search scripts (`fetch:off-nl`, `import:retail`) removed.
- Database grows by ~32 MB (catalogue and its search index).
- Tests: `server/test/catalogue.test.ts` (import rules, search, picking, barcode without network). 173 in total.

## 2026-11-03 — Catalogue duplicates and pack sizes

- The same product entered several times (pack sizes, spellings, word order, words run together, brand written
  longer) is shown once with its sizes: 108,681 entries → 86,093 products. Doritos Sweet Chili: 8 entries →
  1 product in 44 g / 170 g / 272 g. Organic stays apart from regular. Audit: 20 lookalikes left of 86,093.
- Names with HTML entities ("Jack Link&#039;s") are decoded.
- Add sheet: pack size choice from the product's sizes, or any other ("24" eggs); the shopping list keeps it
  (`packSize`, stored as `pack_size`). A picked product keeps all its sizes; its other barcodes find it.
- Migration 011 (group_key, words, listed on catalogue; catalogue_group on products). Tests: 176.

## Recipe from a photo or screenshot (2026-11-03)

- Add a recipe → **Photo**: take a photo or choose one or more screenshots (in order). The phone reads the
  text with Tesseract (same as receipts, no AI); `POST /api/recipes/photo` (`domain/photo-recipe.ts`) splits it
  into title, servings, time, ingredients and steps.
- Headings ("Ingrediënten", "Bereiding", "Method"…) are used when present; otherwise an amount at the start
  makes a line an ingredient and sentences make the method. Numbered steps stay as they are, lines wrapped by
  the screen are joined, unnumbered text becomes one step per sentence. App buttons, status bar and
  checkbox glyphs are ignored; "Tip"/"Voedingswaarde" sections are skipped.
- No method in the photo: a plain method is written from the ingredients and the review says so.
- Nothing recipe-like: the read text goes into "Type" to fix by hand.
- The review now shows every step, editable, with remove and add; timers follow the edited text.
- Also: "tenen" (knoflook) is a clove, "currypoeder" is curry powder.

## Battery and stability pass (2026-11-06)

Measured on a copy of the live database in a phone-sized browser. The server was already healthy (515 real
requests: no errors, slowest 116 ms); the work was on the phone side.

- **Data refreshes only what's on screen.** Each query has its own listeners; a change (or returning to the
  app) refetches queries in view and marks the rest stale until they're shown. Before: every screen visited
  that session was refetched (14 requests, 272 KB) on each return; now e.g. 6 small ones on Shopping.
- **Returning within 10 s refreshes nothing** (a quick app switch).
- **Live updates pause in the background.** The event stream closes when the app is hidden and reopens on
  return; when the server can't be reached it retries after 3, 6, 12… up to 60 s (was every 3 s forever).
- **Compressed responses.** JSON over 1 KB and the app's text files are gzipped (Home: 268 KB → 48 KB).
- **App files from the phone's cache.** The service worker serves hashed `/assets/` files without the network.
- **Cooking screen ticks only while a timer runs**, counts by the clock (correct after the phone paused it),
  and keeps the screen awake again after you switch back.
- **No endless decorative animations.** Streak flame, current level and path bubbles pulse three times;
  only listening, a finished timer and loading spinners keep moving. The tab bar's background blur is gone
  (it repainted on every scroll frame).

## Receipt photos read reliably (2026-11-06)

A real AH receipt photographed on a table read as "2 SOURCY 1798" and lost its total: shadows and the grey background
confused Tesseract. Photos are now evened out before OCR (`evenLight` in `ReceiptSheet.tsx`: each pixel divided by the
blurred page around it, dark screenshots inverted first); the same photo then reads every line exactly. Recipe photos
use the same step. The parser also got more forgiving: the unit-price column stays out of names ("2 SOURCY 1,79 3,58"),
split amounts ("10, 30") are joined, stray marks before the quantity are dropped, a product whose price is unreadable
is kept (price left blank), the subtotal stands in for an unreadable total, nothing after the payment starts becomes a
product, and carrier bags count towards the total without becoming stock (`extras`). Also fixed: Home's recipe cards
showed "10000%" instead of "100%".
