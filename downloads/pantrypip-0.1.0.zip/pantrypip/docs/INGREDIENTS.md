# Ingredients, substitutions and Dutch supermarkets

How PantryPip knows what an ingredient is, what to use instead in the Netherlands, where to buy it and how
much to buy. Decisions first, then the moving parts.

## Decisions

- **Never a silent mismatch.** A recipe line or stock phrase is matched only when every word is accounted
  for: by the product's own names, its family's words, or a short list of harmless words (colours, "fresh",
  "ground", packaging, quantities). One unexplained word ("smoked salmon", "chicken stock cubes") means no
  match, or the larger name that covers it. What can't be matched stays as text and is listed for review.
- **Five kinds of match**, stored per recipe line (`recipe_ingredients.match`):
  exact · equivalent (same thing, other name: cilantro → coriander) · substitute (different, works the same:
  habanero → Madame Jeanette) · approximate (close, the dish changes a bit: cheddar → mature Gouda) ·
  unresolved (kept as text, not counted).
- **Substitutions are visible.** Every non-exact line shows "Original → Replacement" with the reason, on the
  recipe page, in cooking mode (preparation notes) and on the shopping list ("replaces …"). You can accept
  it, keep the original, pick any product, and the choice holds for all your recipes.
- **Families ask once.** "Milk", "cheese", "cream", "rice", "mince" … are families of types. When it matters
  (adding stock, a recipe that says only "cheese") PantryPip uses your usual type, or asks once and remembers.
  "Old cheese" is oude kaas, not "cheese that's old". A household can add its own type to a family.
- **Small measures stay small.** A pinch, dash, sprig, knob or handful has a weight and never becomes a pack
  on the shopping list.
- **Shopping buys packs.** The list shows need, in stock, packs to buy and what's left over, across all
  planned recipes; pack sizes come from the catalogue and from sizes seen in Dutch listings.
- **Supermarket data is labelled by how sure it is.** `listed`: open data names the chain. `unverified`:
  sold in the Netherlands, chain unknown. `verified` is reserved for a chain's own catalogue, which isn't
  available (no official APIs), so nothing is marked verified. Prices are never invented.
- **Country-aware.** The Netherlands is complete. Belgium and Germany have their chains and the structure,
  but no data yet. The country comes from your location (only used to pick the country, on your server) or
  your own choice in Settings.

## Data (migration 009_ingredient_ecosystem.sql)

| Table / column | What |
|---|---|
| products.family, .subcategory, .measure, .custom | identity and measurement definition per ingredient |
| countries, chains | NL, BE, DE; 14 Dutch chains, 3 Belgian, 4 German |
| retail_products | supermarket products: name, brand, size, EAN, chain, URL, status, nutrition, last verified, source |
| ingredient_availability | how easy an ingredient is to get per country (common / limited / specialist) |
| foreign_ingredients | ingredients that aren't Dutch catalogue products (habanero, palm oil, paneer …) with per-country status |
| substitutions | from (product or foreign key) → to, kind, ratio, note, preparation, extra product, country |
| substitution_prefs | a household's choice per original ('keep', a product, or a family's usual type) |
| recipe_ingredients.match, .source_key | the match kind and what the line originally named |
| shopping_items.need_qty, .have_qty, .pack_size | the plan behind a list item |
| recipes.servings_estimated | servings guessed by PantryPip (shown with ≈) |

Source tables in code: `server/src/db/ingredient-knowledge.ts` (families, subcategories, measures, packs,
substitutions, foreign ingredients, availability, countries, chains) and `catalogue-extra.ts` (new products,
synonym fixes). `seedKnowledge` rewrites these rows on start; households' choices are never touched.

## Moving parts

- `domain/ingredient-match.ts` — `identifyIngredient`: product, family, foreign ingredient or none, with
  the words left over.
- `domain/recipe-import.ts` — `parseIngredientLine`: quantity, unit and identity of one recipe line, the
  default substitution for foreign ingredients, "X or Y" (the first, sharing the noun), US sticks of butter,
  bare "pepper" (spooned: black pepper; counted: bell pepper), celery ribs.
- `domain/substitutions.ts` — resolving a stored line for a household (its choice, then the country's
  default), quantity conversion, recipe compatibility: full · with substitutions · partial · specialist.
- `domain/shopping.ts` — `choosePacks` (fewest leftovers, then fewest packs), plan lines.
- `import/catalogue.ts` + `scripts/fetch-off-dump.ts` — Dutch products from Open Food Facts (see below);
  `domain/catalogue.ts` — searching and picking them.
- `import/bulk-recipes.ts` — the quality bar for imported recipes now uses the matcher above: a recipe whose
  title ingredient or meat can't be matched, or with implausible amounts, is not imported.
- Web: `components/Ingredient.tsx` (ingredient and substitution sheets), recipe page badges and lines,
  Groceries → More → "Type & shops", Settings → Shopping & ingredients.

## Dutch supermarket products

Every product Open Food Facts lists as sold in the Netherlands, from its full daily export (ODbL; Open Food
Facts asks apps that need many products to use the export rather than the API).

- `npm run fetch:off-dump` downloads the export (~1.5 GB, CSV) into `data/imports/off-dump/` and keeps the Dutch
  rows as `nl.ndjson` (~40 MB, under a minute). `-- --force` downloads a newer export.
- `npm run import:catalogue` (backs up first, ~3 s) writes them to `catalogue`, searchable with SQLite FTS5, and
  rewrites the Open Food Facts rows of `retail_products` (an ingredient's "Where to buy").
- Kept: a name, a valid barcode, and a brand, size or photo. Nothing is filled in that the export doesn't say.
- **Which ingredient a product is.** Its name, without brand and retail words, must be the ingredient's name and
  nothing more (every word belongs to the ingredient's names). When the product has categories, at least one of
  them must mostly hold that ingredient. Only brands on 3 or more products come off a name: a one-off "brand"
  is often the first word of the name ("Kaas mosterd" by "Kaas").
- **Categories alone never decide.** Tried and dropped: about a third of category-only links were wrong
  ("Kruidnoten" as dark chocolate). Categories only give a product its shelf (dairy, drinks …).
- **Picking one** in the Add sheet ("In the shops"): a product that is one of our ingredients *is* that
  ingredient, so stock and recipes count it, and its brand and size go on the shopping list as a note. Any other
  product becomes the household's own product, with its brand, barcode, size, photo, nutrition and allergens.
- **Barcodes** the catalogue knows are answered without asking Open Food Facts.
- **One product, once.** Open Food Facts often has a product several times: a barcode per pack size, entered
  twice, names typed differently ("Doritos Sweet Chili", "Sweet Chilli Pepper Flavour", "Doritos Tortilla chips
  sweet chilli pepper"). `import/identity.ts` decides what's the same: same brand (own brands: same supermarket)
  and the same words once amounts, packaging and flavour words are gone, in any order; or the same letters (words
  run together or apart: "stroop wafels", "stroopwafels"); or a brand written longer ("Tony's", "Tony's
  Chocolonely"; 5+ letters, so Vega isn't Vegan). Words like biologisch, light, zero and lactosevrij always count:
  organic isn't regular. Search shows each product once with its sizes (at most 6, the most entered).
- **Not shown in search** (still found by barcode): names that are only a brand or an amount, and copies without
  brand or shop of a product that has one (they can't say whose they are).
- **Pack sizes.** Picking a product keeps its sizes as pack options; the Add sheet lets you choose one (or any
  other: 24 eggs), for adding stock and for the shopping list ("1 × 24"). A product's other barcodes find it.

Result on 2026-11-03 (export of that day): 115,738 Dutch products read, 108,681 kept, 44,733 with a photo;
7,958 linked to 238 ingredients (511 more dropped because their categories disagreed). "Where to buy": 7,964
rows; AH 1,128, Jumbo 930, PLUS 287, Picnic 216, Lidl 159, Dirk 141, Vomar 70, Aldi 66, Hoogvliet 49, Spar 34,
DekaMarkt 19, Poiesz 9, Coop 6, Jan Linders 3. A sample of 50 links had 3 wrong ("Vanilla" coffee as vanilla
extract, mint tea as mint, ketjap asin as ketjap manis); the Add sheet shows "counts as …" for each.
Grouped: 86,093 products in search (from 108,681 entries; 7,497 entries not shown). An audit of everything shown
for products that still look identical (same shown name, brand and shop) found 20, where a product line sits in
the brand field ("AH Glutenvrij", "Liefde & Passie"); left as they are.

Supermarkets' own brands (AH, Jumbo; also misspelled, as typed into Open Food Facts) are shown as just the
product at that supermarket: "AH Kokosmelk" → "Kokosmelk" at Albert Heijn. An own brand is only sold there, so a
listing without a chain gets it from the brand. Display only (`withoutOwnBrand` in `domain/ingredients.ts`); the
stored rows keep what Open Food Facts says.

## Webshops (search links only)

Tapping an item on the shopping list, or "Type & shops" on an ingredient, shows links that open the
supermarket's own webshop search for the Dutch name (AH, Jumbo, Lidl, Aldi, PLUS, Dirk, Vomar, DekaMarkt;
your chosen chains only, if you picked any). PantryPip never fetches these sites itself: Jumbo's terms
(art. 9.3) forbid scraping and systematic reuse of site content, and AH's (part II, art. 14) only allow
reuse for personal use. Hoogvliet, Spar, Poiesz and Jan Linders have no search address a link can open;
Picnic is app-only; Coop stores became PLUS. Search addresses checked by hand on 2026-11-03
(`CHAINS[].search` in `ingredient-knowledge.ts`).

## Limits

- Coverage of supermarket ranges is what volunteers put into Open Food Facts: about 109,000 Dutch products, but
  the shop is only known for a few thousand (mostly AH and Jumbo). Not a complete or current assortment.
- Photos load from images.openfoodfacts.org on your device (so Open Food Facts sees your IP address, as when
  scanning a barcode).
- Nutrition of the new catalogue products are table estimates; NEVO (RIVM) would be the authoritative
  Dutch source.
- Of 33,569 Wikibooks ingredient lines about 8,600 stay unmatched. Many are rightly so (palm oil, ground
  crayfish, stockfish, curry leaves: specialist shops); the rest are less common names worth adding over time.
  Settings → Shopping & ingredients lists the ones in your recipes.
