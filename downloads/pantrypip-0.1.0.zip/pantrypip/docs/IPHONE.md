# PantryPip on iPhone

PantryPip runs as a home-screen web app on iPhone (iOS 16.4 or later for notifications). There's nothing
to install from the App Store. The server keeps running on your computer and the iPhone opens it.

Safari only allows the camera (receipts, barcodes), microphone and notifications on an `https://`
address. You need one of the two routes below. Without it, PantryPip still works on the iPhone, but you
type instead of talk and paste receipt text instead of taking a photo.

## Route A: Tailscale (recommended)

This works at home and away. You don't need a certificate to install and the iPhone shows no warnings.
Your computer is already on a tailnet.

1. Install **Tailscale** from the App Store on the iPhone and sign in with the same account.
2. In the Tailscale admin console (login.tailscale.com → DNS), turn on **MagicDNS** and
   **HTTPS Certificates** if they aren't on yet.
3. On the computer, start PantryPip as usual (`npm start`), then run once:

   ```bash
   npm run serve:tailscale
   ```

   This runs `tailscale serve --bg --https=443 http://127.0.0.1:8787`. The setting persists until
   you turn it off with `tailscale serve --https=443 off`. Only devices on your tailnet can reach it.
4. On the iPhone, open `https://<computer-name>.<tailnet-name>.ts.net` in Safari. `tailscale status`
   on the computer shows the name.

Tailscale passes `X-Forwarded-Proto: https`, so login cookies are marked Secure automatically.

## Route B: home network with your own certificate

This works on your Wi-Fi only and needs no extra apps. You install a small certificate profile on the
iPhone once.

1. On the computer:

   ```bash
   npm run cert
   ```

   ```bash
   npm run start:https
   ```

   `cert` creates a private certificate authority (`data/certs/larder-ca.crt`, valid 10 years) and a server
   certificate for this computer's name and IP addresses. It needs `openssl`, which Git for Windows
   includes. `start:https` serves PantryPip on `https://<ip>:8443`. Port 8787 then only serves the setup
   page and redirects everything else to https. Allow Node through the Windows firewall when asked.
2. On the iPhone, open `http://<computer-ip>:8787/setup` in **Safari**. `cert` prints the address, for
   example `http://192.168.68.103:8787/setup`. Then follow the page:
   1. Tap **Download certificate** → Allow.
   2. Settings → **Profile Downloaded** → Install.
   3. Settings → General → About → **Certificate Trust Settings** → turn on "PantryPip local CA (<computer name>)".
   4. Open `https://<computer-ip>:8443`.
3. If the computer's IP changes, run `npm run cert` again. It keeps the CA, so the iPhone doesn't need a
   new profile. To add a name, set `CERT_NAMES=larder.home` before running it.

The CA key stays on your computer (`data/certs/larder-ca.key`). Anyone with that file could create
certificates your iPhone trusts, so keep it private and don't copy it elsewhere.

## Add to Home Screen

In Safari, tap **Share → Add to Home Screen**. PantryPip then opens full screen with its own icon. Home
shows a reminder until you do it or dismiss it. Home-screen apps keep their own login, so sign in
once more there.

## Notifications (daily "Did you cook …?")

1. On the computer, set your time zone and contact address before starting, for example
   `TZ=Europe/Amsterdam` and `PUSH_CONTACT=mailto:you@example.com`.
2. Open PantryPip **from the home-screen icon**. iOS only gives notifications to home-screen apps.
3. Go to Settings → Daily cooking question → **Turn on notifications for this device** and allow.

The computer has to be on at the check-in time for the notification to go out.

## Siri: "Hey Siri, PantryPip"

Settings → **iPhone & Siri** → **Create Siri key** shows the key once with copy buttons. In the
Shortcuts app, build a shortcut named "PantryPip":

1. **Dictate Text** (language English or Dutch).
2. **Get Contents of URL**: `https://<your-larder-address>/api/shortcut/say`, method POST,
   header `Authorization: Bearer lrd_…`, request body JSON with field `text` = Dictated Text.
3. **Speak Text** → Contents of URL.

Then say "Hey Siri, PantryPip" and, for example, "I finished the milk" or "ik heb de lasagne gekookt".
Siri speaks the answer. If PantryPip asks something back ("Approximately how much?"), run the shortcut
again and answer. If you run it without saying anything, it asks the daily cooking question. The key
only works for this endpoint. Revoke it in the same Settings section.

## Talking in the app

Tap the microphone button and start talking. PantryPip waits for you to finish and keeps going through short
pauses. The EN/NL chip at the top sets the language you speak, separately from the app language.
For a whole shopping haul, use **Home → Bought**: name everything, say "done", check the amounts, then
tap Add. On iPhone, Safari's speech recognition is used. If iOS refuses it (it
sometimes does in home-screen apps, or with dictation turned off under Settings → General → Keyboard),
PantryPip says so and opens the keyboard. Tap the keyboard's 🎤 to dictate instead. PantryPip handles
the text the same way either way.

## What was tested, and what wasn't

- Tested in WebKit, Safari's engine, emulating an iPhone 15 (iOS 17.5 Safari) on every page and the
  main flows:
  - No sideways scrolling, and no inputs small enough to make iOS zoom.
  - The tab bar clears the home indicator.
  - Typed assistant commands work.
  - Receipt quantity questions work ("How many eggs?").
  - The throw-away sheet works.
  - The icon and manifest load.
- Server tests cover the Siri endpoint, follow-ups, revocation, and the https setup/redirect server.
- **Not tested on a physical iPhone:** microphone, camera capture, push notifications, the Siri
  shortcut end to end, and the barcode scanner's WASM fallback on iOS. Try these first and tell me what
  misbehaves.
