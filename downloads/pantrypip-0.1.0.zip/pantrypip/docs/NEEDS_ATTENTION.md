# Needs your attention

Nothing here blocks running the app locally. These are decisions or actions only you can take.

1. **AI: decided off (2026-11-02).** The app runs AI-free: receipt photos are read on the device with
   Tesseract, commands use the rule parser, and "Generate with AI" is hidden. A key in the environment
   is ignored unless `AI_ENABLED=1` is also set. The notes below only apply if you change your mind.
   - Default model: `claude-opus-5-5` (`AI_MODEL` to change). For receipts and short commands a smaller
     model would be much cheaper (`claude-haiku-5-5`, `claude-sonnet-5-5`). That is your call on cost
     vs. accuracy.
   - Requests opt into server-side refusal fallback (`fallbacks: "default"`, beta header
     `server-side-fallback-2026-07-01`).
   - **Not yet exercised against the live API** (no key available while building). Try one receipt
     photo and one "generate" request after setting the key, and check the server log line `ai call`.
2. **iPhone: pick an HTTPS route** (docs/IPHONE.md). Browsers only allow the camera, microphone and
   push notifications on `https://`.
   - Tailscale (recommended; your computer is already on the tailnet): install Tailscale on the iPhone,
     enable HTTPS certificates in the admin console, then run `npm run serve:tailscale`. This changes
     your tailnet's Serve config, which is why I didn't run it for you.
   - Or `npm run cert` + `npm run start:https` and install the profile from `http://<computer-ip>:8787/setup`.
   - For the daily "Did you cook X?" notification also set `PUSH_CONTACT=mailto:<your e-mail>` and
     `TZ=Europe/Amsterdam`, open PantryPip from the home-screen icon, then turn on notifications in Settings.
   - **Not yet tested on a physical iPhone** (mic, camera, push, Siri shortcut). Only WebKit emulation
     was run.
3. **Demo account.** The database seeds `demo@larder.test` with test data. For real use start with an
   empty database and `SEED_DEMO=0`, then register.
4. **Supermarket accounts.** AH, Jumbo, Lidl and Picnic have no official APIs (RESEARCH §4). Unofficial
   clients exist but need your credentials and may break or violate terms. I didn't build them in. The
   receipt photo/paste path covers every store. If you want one, the `online_order` source and
   `/api/receipts/scan` (text) are the places to plug it in.
5. **Backups off the machine.** Daily snapshots go to `data/backups/`. Copy that folder elsewhere
   (NAS, cloud drive).
6. **Recipe sources.** Built-in recipes (199) are original. For thousands more, download the Wikibooks
   Cookbook (CC BY-SA 4.0) and RecipeNLG (you must request it and accept its research-only terms) and run the
   offline importer: docs/RECIPE-IMPORT.md. Keep RecipeNLG recipes to your own private PantryPip.
7. **Nutrition data.** Values are approximate built-in estimates. Importing RIVM NEVO (free, attribution
   required, conditions must be accepted by you) would make them authoritative for Dutch foods.
8. **Recipe import from websites.**
   - It reads the recipe data sites publish for search engines.
   - Some sites block automated requests or hide the data. In that case the app asks you to paste the ingredients instead.
   - Only import recipes for your own use; the recipe text belongs to the site.
9. **Balance score and macros are estimates.** They come from built-in per-100 g values and typical piece weights, and are not medical or dietary advice. Set real kcal/protein targets per person in Settings → Dietary needs for better scoring.
10. **Branch.** Phase 2 is on branch `smart-kitchen`, fast-forwarded into `main`. The pre-migration demo database is in `data/backups-manual/`.
11. **Dutch nutrition data (optional).** Built-in values are generic estimates in line with CIQUAL/USDA. For authoritative Dutch values, accept RIVM's NEVO conditions and download the dataset; mapping it onto the catalogue is a follow-up.
12. **AI stays off,** as you decided. "AI-generated recipes" exist but only switch on with `AI_ENABLED=1` and a key. Everything else (import, planning, learning, scoring) is rule-based and explainable.
13. **Not yet tried on a real phone:** hands-free cook mode (continuous mic), timer sound on iOS (needs one tap first), photo upload from the camera.
14. **Test entries removed.** Earlier iPhone checks ran against the live server and added "I bought 6 eggs" six times plus six small Jumbo receipts (13:02–15:03 on 2 Nov). On your go-ahead they were undone through the ledger (8 batches) and the receipts marked discarded. The check now targets a throwaway copy on port 8799.
15. **Journey for an existing household.** The first time it runs, finished history counts: track levels and "ever" tasks complete at once, which can mean a large one-off XP jump. Final challenges always need new activity.
16. **Hands-free start in cooking mode** (Personalise → Interaction) begins listening when you tap into step 1; iOS may still ask for a tap on the mic.
17. **Branch.** Phase 3 is on branch `journey-dashboard`; phase 4 (settings and simplification) on `simplify-and-persist`, merged into `main`.
18. **Language now follows your account.** If a device used to show a different language than your account setting, it now shows the account's choice (Settings → General).
19. **Your Home layout.** If you never customised Home, you get the new calmer default (4 widgets). If you did, your layout is kept exactly; Settings → Personalisation → Default layout resets it.
20. **Browser tests need Playwright.** The scripts in `e2e/` run from any folder with Playwright installed, against a throwaway copy of the database.
21. **Supermarket products are not "verified".** AH, Jumbo and the others publish no product API, so the
    Dutch products come from Open Food Facts (volunteer data, ODbL) and are labelled "listed" or
    "unverified" with their date. Refresh with `npm run fetch:off-dump -- --force` (1.5 GB download) then
    `npm run import:catalogue`. Prices are not included anywhere. About 1 in 17 products linked to an
    ingredient is linked wrongly (a sample of 50: "Vanilla" coffee as vanilla extract, mint tea as mint); the Add
    sheet shows "counts as …" so you can see it.
22. **Fewer Wikibooks recipes, on purpose.** The stricter matching keeps 567 of the 894 Wikibooks recipes;
    the others had ingredients that only matched by guessing. Recipes you cooked, planned or saved stayed.
23. **NEVO nutrition (optional).** The new ingredients use table estimates. RIVM's NEVO table is the
    authoritative Dutch source; it needs a (free) download agreed to by you.
