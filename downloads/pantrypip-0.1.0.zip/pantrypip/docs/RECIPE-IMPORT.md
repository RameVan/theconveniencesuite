# Importing large recipe collections

PantryPip can add thousands of recipes from two collections that you download yourself. The import runs
offline on your computer; the app never contacts these sources.

| | Wikibooks Cookbook | RecipeNLG |
|---|---|---|
| Size | about 3,900 recipes | about 2.2 million (1.6 million "Gathered") |
| Licence | CC BY-SA 4.0: free to use with credit | Research and education only, under an agreement you accept when you request it. No open licence |
| What gets in | the ones whose ingredients match the groceries list | the best 15,000 by default (70 % dinners) |
| Credit in the app | "Wikibooks contributors, CC BY-SA 4.0" with links to the page and the licence | the original site, linked, plus "via RecipeNLG (personal use)" |

**Use RecipeNLG only for your own, private PantryPip.** Don't publish, share or sell an app or database that
contains its recipes. The recipe texts come from many websites, which keep their rights.

## 1. Download

1. **Wikibooks:** download `recipes_parsed.json` (17.3 MB) from
   https://huggingface.co/datasets/gossminn/wikibooks-cookbook/tree/main
2. **RecipeNLG:** request the dataset at https://recipenlg.cs.put.poznan.pl/ and read its terms. Unzip it; the
   file you need is `full_dataset.csv` (about 2 GB).
3. Put both in `data/imports/` in the PantryPip folder (that folder is never committed to git).

## 2. Check first (changes nothing)

```bash
cd server
npm run import:recipes -- --recipenlg ../data/imports/full_dataset.csv --dry-run
```

It reports how many recipes passed each check, the mix (dinners, desserts, soups…) and examples.

## 3. Import

```bash
npm run import:recipes -- --wikibooks ../data/imports/recipes_parsed.json
npm run import:recipes -- --recipenlg ../data/imports/full_dataset.csv --limit 15000
```

- A backup of the database is made first (`data/backups/before-recipe-import-….db`).
- The running server picks the new recipes up by itself (the first screen after the import takes about a
  second while it recalculates).
- Running an import again adds only what's new.
- Keep the total under about 20,000 recipes: up to there every screen stays around 0.1 s
  (docs/IMPLEMENTATION_LOG.md, "Recipe cache").

## What makes the cut

- Ingredient names: at least 85 % match a product in the catalogue (water and "cooking spray" don't count).
- Each line is then read in full: at least 85 % matched, at least 3 products, three quarters with an amount.
- A method of at least a sentence or two, 3–20 ingredients, a sensible title.
- Per-serving energy between 60 and 1,800 kcal after the import (anything else is usually a misread amount).
- Duplicates (same title, or already in the library) are skipped.
- US measures are converted: cups, tablespoons, "1 (14 oz.) can", pounds, pints, quarts.
- Servings and times: from the Wikibooks infobox; for RecipeNLG estimated from the weight of the food and
  the times in the method, and marked "Servings and times are estimated".
- Desserts, baking, breakfasts, drinks, sauces, snacks and sandwiches are recognised from the title (and
  the Wikibooks category) and kept out of the dinner planner.

## Taking a source out again

```bash
npm run import:recipes -- --remove recipenlg
npm run import:recipes -- --remove wikibooks
```

Recipes you cooked, planned, saved or rated stay.
