# Research: from grocery tracker to kitchen assistant (2026-11-02)

This builds on [RESEARCH.md](RESEARCH.md), which covers supermarkets, OCR, speech, prediction and privacy. This document covers the second phase: recipes, planning, nutrition, cooking and motivation. The decisions it led to are listed at the end.

## 1. What existing products do well, and where they cost effort

**Mealime**
- Does well: a weekly plan in minutes, then one consolidated shopping list. Recipes are designed around shared ingredients, so packs get used up.
- Costs effort: it has no idea what's in your fridge, it's a fixed recipe catalogue, and it lacks FIFO.
- Taken for PantryPip: shopping-list consolidation, and ingredient overlap as a planning goal.

**Paprika**
- Does well: the best recipe importer (it reads the schema.org data on any recipe page), plus pantry, meal plan and grocery list in one app.
- Costs effort: the pantry is a manual list without quantities that update themselves, and planning is manual.
- Taken for PantryPip: one-tap URL import into your own library with notes.

**AnyList**
- Does well: very fast list entry with smart categorisation, and a shared household list.
- Costs effort: no inventory and no planning intelligence.
- Taken for PantryPip: an aisle-sorted list and household sharing (both already in PantryPip).

**Samsung Food (Whisk)**
- Does well: imports from anywhere, a "fridge" view, and AI meal plans.
- Costs effort: fridge contents are entered by hand and don't decrease when you cook. Much is behind a subscription.
- Taken for PantryPip: one cohesive recipe → plan → list flow.

**Eat This Much**
- Does well: generates whole days to hit macro targets automatically, and "regenerate this meal" keeps the rest.
- Costs effort: it optimises numbers over enjoyment, and it ignores the food you actually have.
- Taken for PantryPip: lockable meals with regenerate-the-rest, and targets that are a range, not a minimum.

**MyFitnessPal**
- Does well: a huge food database and barcode logging.
- Costs effort: logging every bite is high effort, and the calorie focus can push restriction.
- Taken for PantryPip: nutrition derived from what you cook, with no bite-by-bite logging.

**Yummly**
- Does well: taste-profile recommendations, and learning from ratings and skips.
- Costs effort: discovery-focused, and it doesn't connect to stock.
- Taken for PantryPip: behaviour-learned preferences that can be overridden.

**What none of them do:** keep one ledger of what's in the house that every feature reads and writes. If the plan, the shopping list, cooking and nutrition all use the same stock, most manual upkeep disappears. That is PantryPip's core advantage, and every feature below is built on that shared ledger.

## 2. Frictionless inventory

- **Voice with natural phrases beats forms.** PantryPip already parses "I bought two packs of chicken, a bag of spinach, six eggs and some milk" into four items with amounts. This round adds:
  - "half the chicken": a fraction of what is in stock;
  - "I opened the milk": the opened date shortens the shelf life;
  - run-on lists without commas;
  - a list mode that keeps listening.
- **Receipts and planned purchases close the loop.** Checking items off the shopping list adds them to stock. Cooking deducts the ingredients. With both in place, an accurate inventory needs almost no manual edits; the remaining edits are corrections ("only 2 eggs left"), and those also train the predictor.
- **Opened vs unopened** matters for spoilage: an opened carton of milk lasts 4–5 days, not 14. PantryPip opens a pack automatically on first use, and voice can do it explicitly.

## 3. Spoilage and FIFO

"Oldest first" alone is naive: rice bought 3 weeks ago is fine, spinach bought 3 days ago is not. A pack's risk comes from three things:
- days left until its (estimated or printed) expiry, relative to its category's typical shelf life;
- whether it is opened, which shortens the remaining life;
- category perishability: leafy greens, fish and fresh meat are high risk; dairy medium; dry goods low.

PantryPip computes `risk = perishability × closeness to expiry (+ opened bonus)` and offers three strengths:
- **Off**: no FIFO weight.
- **Balanced**: risk is one factor among enjoyment and variety. This is the default.
- **Strong**: risk dominates, and the planner tries to use every at-risk item.

## 4. Nutrition data

**Sources compared**

| Source | Coverage | Licence / cost | Fit |
|---|---|---|---|
| CIQUAL 2020 (ANSES, France) | ~3,200 generic foods, ~70 nutrients | Open licence (Etalab), free | Best open European generic table |
| NEVO 2025/9.0 (RIVM, Netherlands) | 2,328 foods, ~130 nutrients | Free, but you must accept RIVM's conditions before downloading; data may not be sold on | Ideal for Dutch foods; needs your acceptance |
| USDA FoodData Central | Very large, branded + generic | Public domain (CC0); API key free | Good fallback; US products |
| Open Food Facts | Millions of branded products, barcode keyed | ODbL | Best for scanned products; quality varies per product |

**Decision**
- Every built-in product gets per-100 g values for 8 nutrients: energy, protein, carbohydrate, sugars, fat, saturated fat, fibre, salt. The values are transcribed estimates in line with generic table values (CIQUAL/USDA); each product records where its values came from.
- Scanned products use Open Food Facts' nutriments, which are more specific.
- No runtime API calls are needed for nutrition.
- NEVO import is offered as a follow-up because only you can accept its terms.

**Units**
- Recipes use volumes ("2 tbsp oil", "1 cup flour"), but nutrition tables are per 100 g. Converting with a density of 1 for everything is wrong:
  - oil is about 0.91 g/ml;
  - flour about 0.55 g/ml;
  - dried spices about 0.45 g/ml;
  - honey about 1.4 g/ml.
- PantryPip stores a density per product.
- Check: 15 ml olive oil → 13.7 g → about 121 kcal, matching the brief's "about 120 kcal".

**Cooking fats**
- Fats listed in a recipe are always counted (oil, butter, cream, sauces, honey, sugar). Optional toppings are shown separately and excluded from the totals, and they're labelled, not ignored.
- If a method fries or roasts but no fat is listed, PantryPip adds 1 tsp oil per serving and says so.

**Auditability:** each recipe's nutrition comes with a per-ingredient table showing:
- the grams used;
- how the amount was converted;
- the matched product and its source;
- the contribution to each nutrient;
- what couldn't be counted.

## 5. Nutrition scoring

Scores from the literature: Nutri-Score (per product), the Healthy Eating Index (diet quality per 1000 kcal), and the WHO/EFSA reference intakes:
- fat 20–35 % of energy;
- saturated fat < 10 %;
- free sugars < 10 %;
- salt < 5–6 g/day;
- fibre ≥ 25–30 g/day;
- protein about 0.8 g/kg (10–20 % of energy).

**Design**
- **Daily score (0–100).** The score covers what was cooked that day, measured against that share of the day's targets (a dinner is about 35 %).
- **Components:**
  - energy (symmetric: being under is penalised like being over);
  - protein (enough, not "more is better" beyond about 30 % of energy);
  - fibre, vegetables, fat range, saturated fat cap, sugar cap, salt cap.
- **Configurable targets.** Targets can be set per person in Dietary needs; the household average is used.
- **Consistency over perfection:**
  - XP for nutrition stops growing above 70;
  - the nutrition streak counts days ≥ 70, not 100;
  - there is no reward for eating less;
  - there are no weight or deficit features.

## 6. Recommendation and planning

**The plan as optimisation.** Each recipe gets an explainable linear score:
- enjoyment (rating, favourite, your "how often" setting);
- learned preference (cooked often, rarely skipped);
- novelty (an exploration bonus for untried recipes);
- stock use and FIFO risk;
- extra purchases needed (cost of the missing items);
- ingredient overlap with the rest of the week (shared packs = less waste);
- variety (protein, cuisine) and recency.

Recipes are picked greedily per day, while simulating stock through the week. The result is close to what Mealime and Eat This Much produce, is easy to explain, and runs in milliseconds.

**Exploration** works like a bandit's optimism bonus: untried recipes get a bonus that shrinks as you build a rated history, so the plan doesn't keep repeating the same 8 meals.

**Learning from behaviour**
- **Signals:** ratings, cook counts, skips, swaps (swapping a recipe away is a negative signal), wasted ingredients, cooking times, protein.
- **Insights:** the patterns found are shown as plain-language insights ("You usually cook meals under 30 minutes").
- **Overrides:** each insight can be switched off. Insights decay as behaviour changes.

## 7. Cooking interface

Good cooking modes (NYT Cooking, Paprika, SideChef) share these traits:
- one big step per screen;
- the screen stays on;
- step timers that keep running in the background, several at once;
- ingredient amounts shown inline;
- hands-free commands.

PantryPip's cook mode keeps the microphone open while you cook ("next", "back", "repeat", "start timer", "how much butter?"). Timers alert with sound, vibration and voice. Finishing logs the meal, deducts stock and shows the reward.

## 8. Motivation (gamification) without unhealthy pressure

- **Streaks.** Streaks work through loss aversion (Duolingo). The same research shows that rigid streaks punish normal life. Lally et al. (UCL) found that a single missed day doesn't reset habit formation; a run of missed days does. So:
  - each streak has a weekly rest day or freeze;
  - a broken streak can be recovered by doing two days in a row within 48 hours.
- **Five streaks:** cooking, nutrition (≥ 70), exploration (weekly), low waste (weekly), planning (weekly). Weekly streaks suit things that aren't daily.
- **XP only for meaningful outcomes:** cooking, a new recipe, rescued food, balanced meals, completed plans. Opening the app or tapping buttons earns nothing. Rewards are configurable.
- **Ranks and challenges:**
  - 7 ranks (Kitchen Beginner → Culinary Master), each with 3 tiers;
  - cosmetic rewards: accent colours unlock per rank;
  - optional weekly challenges, at most 2 suggested at a time, picked from your behaviour (more waste → Zero Waste; little variety → Explorer).

## 8b. The journey and the home screen (phase 3)

Design notes from how Duolingo's path works, translated into an original kitchen journey:

- **One obvious next step.** Duolingo's 2022 redesign replaced a tree of choices with a single path and a
  highlighted current node. PantryPip's Progress hero always shows the next step with one button that goes
  where you do it; the path marks it with a bubble and Pip stands next to it.
- **Units with a theme and a checkpoint.** Duolingo groups lessons into units with a guidebook and ends
  sections with a checkpoint. PantryPip's chapters have their own world, an intro, a reward chest halfway and
  a final challenge that counts only fresh activity, so finishing a chapter means you did something new.
- **Small, frequent rewards; one bigger celebration.** Node completions get a short burst and XP count-up;
  a chapter gets a full-screen moment with what you unlocked. Everything is cosmetic (looks, decorations,
  collections, accents): rewards never change what you can do in the app.
- **No app-tapping incentives.** Duolingo rewards lessons; PantryPip rewards kitchen outcomes measured from
  records (cooked, bought, used, planned, rescued). Opening screens earns nothing, and a reminder for the
  streak is off by default.
- **Realistic tasks only.** Tasks that need circumstances you don't have (food close to its date,
  4★ recipes, leftovers) are picked later or can be swapped, with a hint for when they'll fit.
- **Dashboard:** widget libraries (iOS/Android home screens, Notion) work because the default is good and
  editing is direct. PantryPip starts from an Everyday layout, offers presets and profiles, edits in place
  with drag handles plus arrow buttons (for touch and keyboard), and only suggests changes learned from
  use, never applies them.

## 9. Decisions

| Decision | Why |
|---|---|
| Stay AI-free (your decision); all intelligence is rule-based and explainable | Predictable, private, no cost; every recommendation can show its reasons |
| Built-in nutrition table (8 nutrients + density) + Open Food Facts for scanned products | No runtime API dependency; NEVO needs your acceptance |
| Per-ingredient nutrition audit in the API and UI | "Deterministic and traceable" requirement |
| Three-level FIFO with a perishability × time-left risk | Plain oldest-first is wrong for dry goods |
| Locked meals in the planner | Regenerate the rest without losing choices |
| Navigation: Home · Inventory · Recipes · Plan (week + shopping) · Progress | Shopping is the output of planning, so it lives with the plan; Progress groups the path and the statistics |
| Gamification computed from the ledger and cook log, never stored | Undo stays correct; no separate state to drift |
| Work on branch `smart-kitchen`, DB backed up in `data/backups-manual/` | Safe large change |
| Journey nodes are stored once when verified (unlike XP from cooking, which is derived) | "Can't be duplicated" and "historic achievements stay" both hold, even after an undo |
| Dashboard layouts saved per person on the server, per device size | Same layout on every phone you sign in to; tablet/desktop can differ |
| Suggestions read-only; applying them goes through the same undoable edit as manual changes | Never rearrange without permission |

Sources:
- CIQUAL: https://www.anses.fr/en/node/79557, https://zenodo.org/records/4770202
- NEVO conditions of use: https://www.rivm.nl/en/dutch-food-composition-database/use-of-nevo-online
- Duolingo on streaks and streak freezes: https://blog.duolingo.com/how-duolingo-streak-builds-habit
- Streak design study: https://mobbin.com/blog/streaks-are-about-losing-a-study-of-859-streak-designs

## 10. Spec check (2026-11-03)

The feature brief was checked point by point against the app. Most of it was already in place (phases 2–4).
These gaps were closed:

| Gap | What was built |
|---|---|
| "Save this recipe: chicken fajitas with peppers, onion, rice and avocado" | Voice and a one-line box (Add a recipe → Type or paste). Foods named in the title count too. Amounts and method come from the closest library recipe that shares most ingredients; otherwise per-serving defaults (e.g. 125 g meat, 75 g rice, 80 g vegetables) and a generic method. Guessed amounts are flagged; unrecognised words are kept as text. |
| Creating recipes from what's in stock | "Make a recipe from what I have" (Recipes → For you, or by voice). Rule-based: the food closest to its date leads, then one of seven cooking patterns (stir-fry, curry, pasta, frittata, traybake, soup, pan) picked from what's available. Amounts never exceed stock. |
| Rate how easy it was; would you cook it again | Asked after cooking (in the reward, after the stars) and on the recipe page. Planner: "not again" −1.2 (strong, but not excluded: that's "Never"); "again" +0.15; on weeknights "hard" −0.35 and "easy" +0.15. |
| Correct ingredient matching and quantities | Edit your own recipes (name, servings, times, each amount and product, steps). Built-in recipes are shared, so "Edit a copy". Bulk import and the link review also allow matching unrecognised lines. |
| Retention for fats and marinades | Per household, for oils, butter and lines that mention marinade, frying, brine or dressing: All (default) · ¾ · ½ · ¼. Only nutrition changes; stock and cost still use the full amount. |
| Carbohydrate balance in the score | New component, 40–60 % of the meal's energy (EFSA reference intake is 45–60 % per day; a single meal gets a little room). Low-carb households: 0–26 %. Configurable in Settings → Nutrition. |

**Where PantryPip deliberately differs from the brief's suggestions**
- **Score weights.** The brief suggests calories 25, protein 25, fibre 15, carbs 10, fat 10, sugar 5, sat fat 5, salt 5. PantryPip uses energy 20, protein 15, fibre 15, vegetables 10, carbs 10, fat 10, saturated fat 10, sugar 5, salt 5. Vegetables are kept because they are the strongest diet-quality signal in the Healthy Eating Index, and protein beyond the target isn't extra-rewarded (it's "enough", not "more"). Saturated fat gets 10 because the WHO limit (< 10 % energy) is one of the best-supported targets. None of these weights are medically validated; they are a reasonable, explainable balance and are shown per part on every recipe.
- **Daily targets.** PantryPip doesn't ask you to log every meal (that's the effort MyFitnessPal costs). The score covers what you cook, measured against the share of the day that meal is (a dinner ≈ 35 %). So there's XP for balanced meals but no "hit your daily calorie target" reward: it would push logging and restriction.
- **XP values.** The brief's table (25 / 60 / 15 / 20 / 100 …) is kept in proportion but scaled down (10 cooked, +20 new recipe, +5 planned, up to 20 for balance, +5 per rescued item, 30 for a planned week). All values are configurable (preference `xpRules`).
- **Preference weights.** Instead of multiplying selection odds (3× favourite, 2× highly rated), the planner adds explainable points (shown per day under "why"). The "How often" control per recipe (Never · Less · Normal · More · Favourite) and Settings → Meal planning → "How much ratings count" make it configurable, and the plan stays reproducible with a seed.

