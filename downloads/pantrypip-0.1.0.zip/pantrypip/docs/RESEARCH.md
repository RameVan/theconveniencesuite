# Research: making grocery tracking effortless

Date: 2026-11-02. Scope: existing apps, automation approaches, APIs, technologies, costs, privacy.
Claims marked **(verified)** were checked against sources during this research; **(unverified)** means
secondary sources only or conflicting; everything else is established, well-known platform behaviour.

---

## 1. The core finding

Every pantry app fails the same way: **the inventory goes stale because keeping it current costs
effort, so people stop.** AnyList reviewers say outright that keeping the pantry list updated "is
additional work most people abandon". NoWaste, KitchenPal, Grocy and Samsung Food all depend on the user
recording consumption by hand.

So the main design question is not "which input method is most accurate". It is "how do we keep a
*useful-enough* inventory with almost no input?" That leads to three principles that shape this app:

1. **Make purchases cheap to capture.** A purchase is one event per shopping trip (receipt, online order,
   ticked-off shopping list). Capture those well and you get most of the information.
2. **Infer consumption instead of asking for it.** Use recipes cooked, typical consumption rates and
   repurchase intervals. Show the result as an *estimate with a confidence level*, never as fact.
3. **Make corrections a single gesture.** "I finished the milk", or one tap on "out". A correction is
   also a training signal for the predictor.

---

## 2. Existing applications

| App | Strengths | Weaknesses (relevant to us) |
|---|---|---|
| **AnyList** | Best shared lists in the class, recipe import, good sync | No real inventory; meal planning is manual; pantry upkeep is abandoned in practice |
| **Bring!** | Fast list entry, icon grid, aisle sorting, Siri/Wear voice, strong in DACH/NL | Shopping list only; no inventory, no consumption |
| **Paprika** | Excellent recipe library and scaling, pantry list, offline | Manual pantry; paid per platform; no prediction |
| **Samsung Food** (ex-Whisk) | Recipe import + planner; deducts ingredients when you cook a saved recipe; fridge camera recognises ~33–37 fresh items (unverified counts) | Camera only on expensive Bespoke fridges; recognition limited to a small set of items; deduction only for saved recipes |
| **KitchenPal** | Pantry + list + recipes, barcode, expiry alerts, cheap lifetime licence | Data entry is still per item; receipt import claimed but not confirmed in store listing (unverified) |
| **NoWaste** | Expiry-first design, fridge/freezer/pantry, barcode | Manual quantity upkeep; users report barcode and sync bugs |
| **Out of Milk** | Simple list + pantry + barcode | Dated; manual |
| **Grocy** (open source, MIT) | Full household ERP: stock with due dates, min-stock → shopping list, recipes, meal plan, REST API; Barcode Buddy add-on looks unknown barcodes up in Open Food Facts | Admin-dashboard UX, high upkeep, a lot of forms; consumption is manual |
| **Mealime** | Quick weeknight plans → automatic list | Rigid when the week changes; no inventory |
| **SuperCook** | Best "cook with what I have" matcher | You re-enter your pantry; no tracking |
| **MyFitnessPal / Cronometer** | Huge food/nutrient databases, barcode logging; Cronometer has high-quality nutrient data | Nutrition logging, not inventory; logging fatigue is well documented |

**What to take from each:** Bring!'s one-tap list entry and aisle categories; Grocy's event ledger idea and
min-stock rules; Samsung Food's "cooked a recipe → deduct"; SuperCook's ingredient matching; Paprika's
scaling; Cronometer's honest nutrition data. Nobody combines **cheap purchase capture + inferred
consumption with confidence + one-gesture correction**. That combination is the gap this app fills.

---

## 3. Automation approaches, assessed

Scores: effort = user effort per use (lower is better); the rest on a 1–5 scale (5 = best/cheapest/most private).

| # | Approach | User effort | Accuracy | Build complexity | Ongoing cost | Reliability | Privacy | Verdict |
|---|---|---|---|---|---|---|---|---|
| 1 | **Receipt photo → OCR + LLM** | 1 photo per trip | 4 (LLM vision handles Dutch abbreviations well; Tesseract alone ~3) | 3 | 4 (≈ €0.005–0.02/receipt with a small vision model) | 4 | 3 (photo goes to an AI provider unless local OCR) | **Build: primary input** |
| 2 | Barcode scan | 1 scan per item | 5 for identity, says nothing about quantity used | 2 | 5 (Open Food Facts free) | 4 (native API missing on iOS Safari → WASM fallback) | 5 | **Build: secondary input, for new products** |
| 3 | Supermarket loyalty / digital receipts (AH, Jumbo, Lidl Plus) | 0 after setup | 5 (exact line items) | 4 | 5 | **2: unofficial, reverse-engineered, can break any time** | 3 | **Adapter interface only; no hard dependency** (see §4) |
| 4 | Email receipt parsing | 0 after setup (forwarding rule) | 4 | 3 | 5 | 3 | 2 (mailbox access) | **Later: same text pipeline as receipts; paste/forward supported now** |
| 5 | Voice | 1 sentence | 4 with an LLM, 3 with rules | 3 | 5 browser STT / 4 cloud STT | 4 | 3–4 | **Build: primary for consumption & corrections** |
| 6 | Conversational AI | 1 sentence | 4 | 3 | 4 | 4 | 3 | **Build: same engine as voice** |
| 7 | Grocery image recognition (photo of haul) | 1 photo | 2–3 (counts and package sizes unreliable) | 3 | 4 | 2 | 3 | Skip for now: receipts give the same info more accurately |
| 8 | Fridge/pantry camera | 0 | 2 (occlusion, opaque containers, ~35 recognisable classes) | 5 (hardware) | 2 | 2 | 1 (camera in the home) | **Skip** |
| 9 | Smart scales / weight shelves | 0 per use, high setup | 5 for a few bulk items | 5 (hardware, per-container calibration) | 2 | 3 | 5 | Skip; maybe later through a Home Assistant webhook |
| 10 | **Consumption prediction from purchase intervals** | 0 | 3 → 4 as history grows | 3 | 5 | 4 (if confidence is honest) | 5 | **Build: core of "invisible" tracking** |
| 11 | **Recipe-based deduction** | 0 extra (one tap "cooked") | 4 | 2 | 5 | 5 | 5 | **Build** |
| 12 | **Shopping list ticked → inventory** | 0 extra | 3 (bought ≈ listed) | 1 | 5 | 4 | 5 | **Build, with the receipt superseding it** |
| 13 | Shared household tracking | – | – | 3 | 5 | – | – | **Build: household model + live sync** |
| 14 | Online orders (Picnic, AH online) | 0 after setup | 5 | 4 | 5 | 2 (unofficial APIs) | 3 | Adapter slot; import via pasted order confirmation for now |
| 15 | Bluetooth / smart home | 0 | varies | 4 | 3 | 2 | 4 | Generic **webhook/REST event endpoint** so Home Assistant can push events |

### Why receipts beat cameras
A receipt captures *every* purchase with price and quantity in one action. A camera captures only what
it can see, cannot tell 500 g from 1 kg, and needs hardware. The receipt also gives price history for free.

### Why prediction must stay advisory
A purchase-interval model has very little data at the start (n = 1–3 cycles). The app keeps **two numbers
per stock lot: the confirmed quantity** (last value a person or a deterministic event like a receipt
established) **and the estimated quantity** (confirmed minus predicted consumption since then). Low-stock
warnings use the estimate only when confidence is high enough; otherwise they ask instead ("Still have
milk?"). A correction resets confirmation and feeds the rate model.

---

## 4. Dutch / European supermarket integrations (verified status)

| Retailer | Official public API? | What exists | Assessment |
|---|---|---|---|
| **Albert Heijn** | **No** | Unofficial clients of the mobile app API: `python-appie` (lists in-store receipt summaries; line items need a second call; warns it may break), `ah-mcp` (Go, OAuth login, fetches kassabonnen with line items), `albert-heijn-wrapper` (Node, GraphQL; receipts unconfirmed) **(verified)** | Possible as an opt-in, user-run connector. Not usable as a core dependency: ToS risk and fragility |
| **Jumbo** | **No** | `jumbo-mcp` (receipts, itemised prices, search), `vghoost360/jumbo` (REST wrapper using headless Chromium login), `python-jumbo-api` (orders only, last release 2021). Product API sits behind Cloudflare, NL IPs only **(verified)** | Same as AH |
| **Lidl (Lidl Plus)** | **No** | `lidl-plus` / `iLidl` (receipts v2 list, v3 detail; login needs a visible browser because of reCAPTCHA Enterprise; app version header checked) **(verified)** | Hardest to automate; a receipt photo is more reliable |
| **Picnic** | **No** | `python-picnic-api(2)`: cart, slots, current deliveries; past orders claimed by one secondary source **(verified / partly unverified)** | Most promising "zero effort" source because every order is digital; still unofficial |
| Prices/catalogue | No | `supermarkt/checkjebon` (MIT, frequently updated price data for ~12 NL chains, reusable) **(verified)** | Good optional source of reference prices/package sizes |

**Decision:** the app defines a `PurchaseSource` connector interface (receipt photo, receipt text, email
text, online order JSON, loyalty connector). Everything feeds one normalised `ParsedReceipt` →
review → `purchase` events path. Loyalty connectors are left as documented extension points that
**the user runs with their own credentials**, because none are official and some need captcha-protected
logins, which we must not automate around. The universally reliable path is the receipt photo, and that
works for every shop.

Dutch receipt formats (AH, Jumbo, Lidl, Plus, Dirk, Aldi) follow the same shape: `[qty] DESCRIPTION
price [VAT code]`, multi-buy lines like `2 x 1,29`, weighed lines `0,512 kg x 9,99 €/kg`, discount lines
(`BONUS`, `KORTING`, `-0,50`), and deposit lines (`STATIEGELD`). Abbreviations are heavy and
chain-specific (`AH HV MELK`, `JUMBO KIPFILET`). That calls for a **learned alias table per store**:
once a user corrects `HV MELK` → "Halfvolle melk 1 L", it is never asked again.

---

## 5. Product data

| Source | Coverage | Cost / licence | Use |
|---|---|---|---|
| **Open Food Facts** | Worldwide, good for NL packaged goods (country-level coverage not quantified) | Free, ODbL; no key for reads; **15 req/min/IP for product reads**, 503 on global limits, bans for abuse **(verified)** | Barcode → name, brand, quantity, image, category, nutrition. Server-side proxy with permanent local cache |
| **NEVO (RIVM)** | 2,328 Dutch generic foods, ~130 nutrients (2025/9.0) **(verified)** | Free; must accept conditions; use unchanged, cite "NEVO online, version 2025/9.0, RIVM, Bilthoven"; can't charge end users for it **(verified)** | Best source for generic Dutch nutrition (unpackaged produce). Planned import; the seed uses approximate values marked as estimates |
| USDA FoodData Central | US generic foods | Public domain | Fallback for nutrition |
| checkjebon | NL prices | MIT | Optional reference prices |

---

## 6. Recipes and licensing

| Source | Notes |
|---|---|
| TheMealDB | Free test key; production/premium needs a paid supporter key; commercial terms unclear **(unverified)** |
| Spoonacular | Paid tiers; **terms say you must delete all obtained data when you stop using the API** **(verified via listing)**: bad fit for a local library |
| Edamam | 2M+ recipes with nutrition; paid plans; attribution required |
| Scraping recipe sites | **Rejected.** Recipe *text and photos* are copyrighted (ingredient lists alone generally aren't) |
| schema.org/Recipe import of a URL the user chooses | Fine for personal use (the user imports a page they're viewing, like Paprika does) |
| AI-generated recipes | No licence problem; must be **labelled as AI-generated** and nutrition marked as an estimate |

**Decision:** a `RecipeProvider` interface. Built-in providers: (1) the app's own **original seed recipes**
(written for this project, no third-party text); (2) user-created recipes; (3) AI-generated recipes
(labelled); (4) TheMealDB as an *optional* provider enabled by setting a key, with attribution shown.

---

## 7. Speech recognition

| Option | Latency | Dutch | Cost | Privacy | Notes |
|---|---|---|---|---|---|
| **Web Speech API** (`SpeechRecognition`) | Very low, streaming | Yes (nl-NL) on Chrome/Edge/Android, Safari (`webkitSpeechRecognition`) | Free | Chrome sends audio to Google unless `processLocally` (new, experimental) **(verified)** | Firefox: behind a flag; Safari support reported inconsistently **(verified conflict)** |
| Native iOS/Android dictation (keyboard mic) | Low | Yes | Free | On-device on modern phones | Works in *any* text box, which is why the assistant always has a text field |
| OpenAI gpt-4o-mini-transcribe / gpt-4o-transcribe | ~1 s batch | Good | ≈ $0.003 / $0.006 per min **(verified across aggregators)** | Cloud | Good fallback for browsers without Web Speech |
| Deepgram Nova-3 | Streaming, fast | Yes | ≈ $0.004–0.006/min (sources conflict) | Cloud | |
| Whisper (local, whisper.cpp) | 1–3 s on CPU | Good | Free | Best | Needs a server with CPU headroom |

**Decision:** Web Speech API first (free, instant, nl-NL + en-US), with the always-available text
field (works with the phone keyboard's own dictation, which covers iOS/Firefox). A server endpoint for
cloud transcription is an optional extension; at a few commands a day, cost is negligible (< €0.10/month).

**Understanding** the sentence matters more than transcription. Two tiers:
1. A **deterministic bilingual parser** (no network, ~1 ms) for the ~90% of commands that follow
   common patterns ("ik heb 2 liter melk gekocht", "I finished the milk", "zet koffie op de lijst").
2. An **LLM tool-calling fallback** (Claude) for everything else and for open questions
   ("what should I cook?"). The LLM *proposes* actions; the server validates them and applies them only
   through the inventory ledger, so AI cannot write stock directly.

---

## 8. OCR and AI models for receipts

| Option | Accuracy on Dutch receipts | Cost | Privacy |
|---|---|---|---|
| Tesseract (local / tesseract.js) | Fair on clean, flat receipts; poor on crumpled thermal paper | Free | Local |
| Google Vision / AWS Textract | Good text, no item semantics | ~$1.5/1000 pages | Cloud |
| Veryfi / Mindee / Taggun | Strong line items; Veryfi priciest (min. $500/mo tier reported) | €44+/month | Cloud |
| **Vision LLM (Claude Haiku-class)** | Very good: reads abbreviations, multibuy and discounts, outputs structured JSON directly | ≈ $0.005 per receipt (one estimate) | Cloud (no training on API data by default) |

**Decision:** two-stage pipeline: **image → text** (Claude vision if configured; otherwise the text the
user pastes, or browser-side OCR as a future plug-in), then **text → structured items** with a
deterministic Dutch receipt parser that applies learned aliases. The LLM can do both stages in one call
when available. The parser makes the app useful without any API key and lets tests run offline.

---

## 9. Consumption estimation

Methods, roughly from simplest to richest:

1. **Shelf-life defaults** per category (fresh milk 7 d, opened 4 d; spinach 5 d; frozen 90–180 d).
2. **Repurchase interval:** quantity bought ÷ days until the next purchase ≈ consumption rate. Robust
   because it needs only purchase events, which we capture anyway.
3. **Observed consumption events** (cooked recipes, manual "used 250 ml").
4. **Exponentially weighted rate** combining 2 + 3, with half-life ~45 days so habit changes show up
   within a few cycles, and *shrinkage* toward a category prior when n is small.
5. **Confidence** = f(number of observations, variance of intervals, days since last confirmation).
   With fewer than 2 cycles the app shows no exact estimate, just "probably some left".

Seasonality needs a year of data; the model stores day-stamped events so it can be added later
without migrating data.

---

## 10. Hardware

Fridge cameras (Samsung Bespoke AI) and weight shelves (PantryOn, open-source EverShelf, DIY
ESP32 + HX711) exist but are expensive, limited or DIY. **Not a dependency.** Supported indirectly: the
REST event API accepts `consume`/`adjust` events with source `device`, so a Home Assistant automation
(e.g. a load cell under the coffee jar) can post updates.

---

## 11. Technical limitations

- No official NL retailer APIs; all loyalty integrations are fragile and possibly against ToS.
- Barcode: native `BarcodeDetector` on Chrome/Android; **disabled by default on iOS Safari** →
  needs a zxing-wasm polyfill **(verified)**. Camera access needs HTTPS (or localhost).
- Web Speech availability varies by browser; the text field is the universal fallback.
- Open Food Facts rate limit (15/min/IP) → cache every lookup permanently.
- Quantities on receipts are package counts, not contents: package size comes from the product
  record, an alias or barcode data.

---

## 12. Privacy and data protection (GDPR)

- Food purchase data reveals health, religion (halal/kosher), household size and routines. Some of
  this can count as **special-category data** by inference → store it locally, self-hosted by default.
- AI calls send receipt images/text and commands to the provider. Make this **opt-in, disclosed, and
  minimal**: no account identifiers in prompts, no storing of images after parsing unless the user chooses to.
- Household members see shared inventory; personal consumption profiles are per user.
- Export (JSON) and deletion endpoints support data-subject rights.
- Secrets are kept server-side only (env vars), never shipped to the browser.

---

## 13. Cost and operational complexity

| Component | Choice | Monthly cost (1 household) |
|---|---|---|
| Hosting | Single Node process + SQLite file (home server, Raspberry Pi, or €4 VPS) | €0–4 |
| AI (receipts ~10/month, commands ~150/month at small model prices) | Claude, optional | ≈ €0.20–1 |
| Speech | Browser | €0 |
| Product data | Open Food Facts | €0 |
| Backups | SQLite online backup to file + copy off-box | €0 |

Operational complexity is deliberately minimal: one process, one database file, no queue
infrastructure (background jobs are in-process timers), no external services needed to run.

---

## Sources

- python-appie: https://pypi.org/project/python-appie/ · ah-mcp: https://github.com/mrserzhan/ah-mcp · albert-heijn-wrapper: https://classic.yarnpkg.com/en/package/albert-heijn-wrapper
- jumbo-mcp: https://glama.ai/mcp/servers/Robert-SD/jumbo-mcp/schema · jumbo api (Docker): https://hub.docker.com/r/vghoost360/jumbo · python-jumbo-api: https://pypi.org/project/python-jumbo-api
- lidl-plus: https://github.com/Woyken/lidl-plus · iLidl: https://pypi.org/project/ilidl/ · lidlplus .NET: https://github.com/bluewalk/lidlplus-dotnet-client
- python-picnic-api2: https://pypi.org/project/python-picnic-api2/
- Open Food Facts API: https://openfoodfacts.github.io/openfoodfacts-server/api
- Grocy: https://github.com/grocy/grocy (README via https://cdn.jsdelivr.net/gh/grocy/grocy@master/README.md)
- Samsung AI fridge: https://mobilesyrup.com/2025/01/03/samsung-adding-ai-grocery-recognition-smart-fridges/ · https://betanews.com/2025/01/02/samsung-bespoke-smart-refrigerators-bring-instacart-powered-grocery-shopping-to-your-kitchen
- NEVO: https://www.rivm.nl/en/dutch-food-composition-database/use-of-nevo-online/request-dataset · conditions: https://www.rivm.nl/sites/default/files/2025-11/Conditions-of-use-NEVO-online-2025-dataset_0.pdf
- checkjebon: https://github.com/supermarkt/checkjebon
- Web Speech `processLocally`: https://developer.mozilla.org/docs/Web/API/SpeechRecognition/processLocally · support: https://web-platform-dx.github.io/web-features-explorer/features/speech-recognition
- STT pricing: https://deepgram.com/blog/speech-to-text-api-pricing-breakdown-2025 · https://apiscout.dev/blog/best-speech-to-text-apis-2026
- Receipt OCR: https://idp-software.com/guides/receipt-ocr/ · https://sidequest-automation.pages.dev/blog/how-we-evaluated-ocr.html · https://dev.to/edenai/best-receipt-parser-apis-in-2023-d0i
- BarcodeDetector: https://caniuse.com/mdn-api_barcodedetector · https://orbisk.github.io/vue-use-barcode-detection/compatibility
- Bring!: https://tapsmart.com/apps/review-bring-shopping-lists-made-easy · NoWaste: https://www.verbraucherzentrale.de/wissen/umwelt-haushalt/apptest-nowaste-lebensmittelliste-die-digitale-speisekammer-95921 · KitchenPal: https://apps.apple.com/us/app/-/id1084982489
- Recipe/meal-planning app comparison: https://softwaremany.pages.dev/blog/2026-01-16-recipe-meal-planning-apps/
- Recipe APIs: https://marketplace.apilayer.com/spoonacular-api · https://publicapis.io/alternatives/the-meal-db-api
- Weight-based pantry: https://www.producthunt.com/products/evershelf-2
- Bring! for Home Assistant: https://github.com/Poeschl/Bring-shoping-list-component
