# Testing

Run: `npm test` (server, Node's built-in test runner). Result at the time of writing: **101/101 passing**,
a few seconds. Each test starts the real HTTP server on an in-memory database and drives it over HTTP.

## The 15 required workflows

| # | Workflow | Automated test (server/test/workflows.test.ts) | Also checked in the browser UI |
|---|---|---|---|
| 1 | Photograph & process a receipt | Photo → (mocked) vision parse → review → commit; abbreviation learned and reused with its package size; duplicate receipt rejected (409); Jumbo `2 x 0,79` layout | Pasted AH receipt → review (4 matched, 1 flagged) → map `KNFLK BOL` → garlic → "5 products added" + undo; ledger verified |
| 2 | Add groceries by voice | "I bought two litres of milk", "Add six eggs to my groceries", "ik heb 3 uien gekocht" | Typed into the assistant (mic is blocked in the test browser) |
| 3 | Remove groceries by voice | "Remove one onion", "I used 200 grams of chicken", "Remove the remaining spinach, it has gone bad" (discard, reason spoiled), "I finished the milk" | "I finished the milk" → 2 L removed, undo offered |
| 4 | Add to shopping list by voice | "Add coffee to my shopping list", "zet twee pakken pasta op de boodschappenlijst"; "add butter" asks list vs inventory unless the screen says | |
| 5 | Correct a voice misinterpretation | "I bought 2 litres…" → "no, 1 litre" → net +1 L; "undo"; ledger verified | |
| 6 | Scan a barcode | Unknown EAN → Open Food Facts (mocked fetch) → product created with 1 L size → stock; second scan is local; OFF called once; check digit validated | Camera blocked in the test browser; manual entry path present |
| 7 | Cook a planned recipe | Plan shakshuka (no deduction) → cook → 4 eggs and the tomatoes deducted, slot marked cooked; second cook call is idempotent | |
| 8 | Change portions | Pesto pasta for 4 (recipe for 2) deducts 400 g pasta, 300 g peas | |
| 9 | Leftovers | Chili for 6 with 4 portions to the fridge → "I froze two portions of chili" splits the lot → eat 1, discard 1 → waste stats record `leftover` | |
| 10 | Shopping list from the meal plan | Have 300 g chicken, curry for 4 needs 500 g → 1 × 500 g pack; 8 servings → 2 packs; meal removed → item removed. Shopping trip then receipt → reconciled, not double counted. Repeated reads cause no change notifications | Seeded week shows "11 items on your list for this plan (only what you don't already have)" |
| 11 | Discover with current groceries | `/recipes/cook-now`: all ≥ 50 % match, with time, missing, nutrition | Discover tab ranks recipes using expiring spinach / minced beef first |
| 12 | Find new recipes | Cuisine filter; "less than 20 minutes" and "high-protein dinner" via natural language; vegan ≤ 30 min | |
| 13 | Predict run-out | 8 purchases of 2 L every 4 days (no logging) → rate ≈ 500 ml/day, estimate ≈ 1 L two days later, confirmed stays 2 L, days-left 1–3, suggested before running out | Inventory rows show "≈ 266 g · estimate" with confidence bars next to the confirmed amount |
| 14 | Correct a prediction | "I have 1.5 litres of oat milk left" → confirmed 1.5 L, correction factor < 1, slower decay afterwards. Rejected suggestions stop appearing | "Looks right" / "Correct" buttons on every estimated row |
| 15 | Duplicates & concurrency | Same `clientRequestId` twice (REST and voice) applies once; identical voice command → "Do it again?"; 25 parallel requests on 10 croissants → exactly 10 consumed, ledger consistent; stale `expectedTotal` → 409 | |

Cooking & check-ins (`cooking-checkins.test.ts`): cooked/not-cooked phrasing in EN/NL (negations never deduct;
"I had a banana" stays consumption); "I've cooked the curry" cooks today's planned curry; "I cooked dinner";
Dutch dish names ("omelet"); "I didn't cook the salmon" → skipped, nothing deducted, moved to tomorrow on "yes";
leftovers eaten by name; a dish without a recipe asks for its ingredients. Daily check-in: time gating,
yesterday's meals, assistant asks first and "yes" cooks it, idempotent answers, one push per meal with
Yes/No actions, switched off = no push. Receipt quantities: eggs/tomatoes/chicken asked in their own
units, printed sizes / weights / single-size products not asked, answers learned for the next receipt.

Dietary needs, custom amounts & stats (`dietary-stats.test.ts`): diets/allergens computed from ingredients;
vegetarian + milk allergy only gets suitable or swap-fixable recipes (curry → tofu; stamppot excluded); egg allergy;
substitutes never unsafe; barcode allergy warning; "an egg broke in transit", "the eggs broke" asks how many,
"I broke 3 eggs"; receipt line corrected + damaged logged as waste; custom amount when cooking; partial discard
with reason; meals/streak/top recipe/eggs; bought-and-gone counts as eaten; undo removes a cooked meal from the stats.

Unit tests (`parsing.test.ts`): every example command from the brief, Dutch commands, recipe filter
phrases, multi-item and correction parsing, AH/Jumbo/Lidl/generic receipts (totals reconcile to the cent),
unit conversions and package rounding.

iPhone (`iphone.test.ts`): Siri "I finished the milk" answers in plain text and deducts; a follow-up
question continues on the next Siri call; an empty Siri call asks the daily cooking question; a key only
unlocks the Siri endpoint, can be revoked, and its hash is never returned; the https companion serves the
setup page and certificate and 308-redirects everything else.

**WebKit / iPhone 15 run** (Playwright WebKit, iOS 17.5 Safari user agent, 393 × 659, touch; script in
`.scratch/webkit/iphone.mjs`): all eight pages plus assistant, receipt review ("How many eggs?" / "How many
tomatoes?"), and the throw-away sheet were checked. No sideways scroll, no input under 16 px (iOS zooms
those), tab bar flush with the bottom, no console errors, and the apple-touch-icon and manifest load.
Result: no problems found.

Voice lists (`voice-list.test.ts`): "I bought milk eggs bread cheese and 2 kg potatoes" adds five products;
a Dutch run-on list keeps "500 gram" with the mince, not the cucumber before it; unknown words become new
products; pauses, "uh" and "done" are ignored; "chicken breast" stays one item; list mode adds everything
in one undoable, idempotent batch.

Planning & game (`planning-game.test.ts`):
- Two diets show recipes that fit either, and there are at least 8 vegan dinners.
- A recipe page's schema.org data (`@graph`, `HowToSection`, entities) becomes a draft with every ingredient matched: "2 tbsp" → 30 ml, "to taste" → optional, step timers read.
- A typed recipe saves with macros, including assumed frying oil, and appears in and leaves My recipes. Built-in recipes can't be deleted.
- Ratings and "how often" are stored.
- The week planner:
  - plans 7 different dinners without breakfasts or "never" recipes, and shuffle changes the plan;
  - with FIFO on, spinach expiring tomorrow is planned in the first two days;
  - favourite foods and 5★ favourites are picked;
  - applying fills the plan and the shopping list, and re-planning keeps existing dinners.
- Cooking path: streaks forgive one rest day a week. XP comes from new recipes, balance and streaks, plus the streak badge. Undo takes the XP back.

Browser check (mobile viewport):
- Plan my week, then applying it.
- Recipe page balance panel and "how often".
- I cooked this, which shows the reward popup (+42 XP, rescued food, streak, rating).
- My recipes, then Add recipe by typing (Dutch ingredients all matched), then save.
- The cooking path page.

The six journeys from the phase 2 brief (`scenarios.test.ts`), each over HTTP:
1. **Voice groceries:** "I bought two packs of chicken, a bag of spinach, six eggs and some milk" (4 items); "I used half the chicken" (500 of 1000 g); "I opened the milk" (opened, shorter expiry, undo restores); "I only have 4 eggs left"; "I threw away the spinach, it went off".
2. **Planning:** 7 dinners; strong FIFO plans the spinach that expires tomorrow first; every pick has a score breakdown; FIFO off has no FIFO factor; a locked meal survives "redo"; a swap picks something else and is remembered.
3. **Shopping:** one line per product, nothing that's in stock, checked items restock on "done".
4. **Cooking:** a planned dinner deducts exactly the scaled ingredients, is marked cooked, rewards XP incl. "as planned", ledger verifies.
5. **Nutrition:** 2 tbsp olive oil ≈ 247 kcal, 1 cup flour ≈ 132 g and 1 tbsp honey ≈ 21 g via density, optional toppings excluded but listed, total = sum of audit lines, all 8 nutrients present, frying without fat adds assumed oil; the balance score is lower for both too little and too much.
6. **Progression:** 21 levels; rescuing expiring lentils earns XP; cooking, nutrition and exploration streaks; challenge progress; changing an XP rule changes XP; accent colours locked by rank; learned insights can be switched off.

WebKit (iPhone 15) run repeated with the new Progress and recipe-nutrition pages: no problems found.

## Not covered by automated tests (and why)

- **Real microphone and camera input.** The test browser blocks device capture. Speech goes through the
  browser's Web Speech API and produces text; everything after that is the tested text path.
  Barcode decoding uses the browser's `BarcodeDetector` or the zxing-wasm ponyfill.
- **Real Claude calls.** No API key in this environment. The AI paths are typed against the SDK
  (`tsc` passes) and the receipt-photo route is tested with a stand-in parser. First real-key run should
  be checked: see NEEDS_ATTENTION.md.
- **Tesseract on-device OCR quality** on real thermal receipts.
- **Recipe import from live websites.** Tested on a saved schema.org page, not against real sites (some block automated requests).
- **A physical iPhone:** microphone, camera, push, the Siri shortcut end to end, barcode WASM on iOS
  (see IPHONE.md).

## Interaction counts and timing (measured in the UI, mobile viewport 390 × 844)

Server timings from the request log on the demo household (≈170 lots, 10 weeks of history):
`/api/assistant` 3–8 ms, `/api/home` 11–16 ms, `/api/shopping` 3–5 ms, receipt parse + match ≈ 10 ms
(rule parser). The production bundle is 84 KB gzipped; OCR and barcode WASM load only when used.

| Task | Interactions | Notes |
|---|---|---|
| "I finished the milk" by voice | **1 tap + 1 sentence** | Mic starts listening on open; reply is spoken; panel closes itself after ~2 s with an undo toast. Regulars that run out are put on the list automatically |
| Same, typed | 1 tap + typing + Enter | |
| Frequent consumption ("250 ml milk") | **1 tap** | Configurable chips on Home |
| Use/add/discard anything via quick sheet | 3 taps | Mode → product → amount preset |
| Cooked today's planned meal | **1 tap** | "Cooked it" on Home; leftovers optional |
| Cooked an unplanned recipe by voice | 1 sentence (+1 tap if several recipes match) | "I cooked pasta for two" → pick recipe |
| Receipt, all lines known | ~4 taps | Receipt → Take photo → shutter → Read → Add N (aliases make this the norm after a few trips) |
| Receipt, one unknown abbreviation | +2 taps once | Tap line → pick product; remembered for next time |
| Barcode of a known product | 2 taps | Barcode → auto-detect → Add |
| Shopping trip | 1 tap per item, Finish optional | Ticked items move to inventory automatically after 6 h |
| Plan a meal | 2 taps | "+ Add meal" → recipe (list updates itself) |
| Correct an estimate | 2 taps | Row → "Looks right", or "Correct" + number |

Bugs found by testing and fixed: a pending clarification swallowing the next full command; mobile
layout blown out to 948 px by the recipe carousel; a refetch loop caused by drifting estimates
re-writing plan-driven list items; "0.46 tomatos" formatting; the emoji-on-plate sizing.


## Journey and dashboard (`journey-dashboard.test.ts`)

| # | Required check | How it's tested |
|---|---|---|
| 1 | Completing a task advances along the path | Adding five groceries completes "Add your first five groceries", it shows as fresh until seen, `current` moves on |
| 2 | Completing a chapter unlocks the next | All chapter-1 tasks → reward chest opens → final challenge counts only dinners after it opened → chapter 2 unlocks with 5 tasks, Pip gets the apron, the tomato look and the herb pot unlock |
| 3 | XP can't be duplicated | Reading the journey repeatedly adds nothing; the same cook sent twice is one cook with no second reward; undoing a cook keeps finished nodes and adds no XP; track levels stored once |
| 4 | Layout changes persist | Reorder, resize, compact, pin, hide, add and remove; reload returns the same layout; tablet keeps its own |
| 5 | Add and remove widgets | Same test; unknown widget types are rejected; unsupported sizes are corrected |
| 6 | Switch presets and profiles | Switch active profile; create a profile from the Minimal preset; reset |
| 7 | Responsive layouts | Browser: phone 2 columns, tablet 3, desktop 4 (checked at 375, 768 and 1400 px); WebKit iPhone 15 run (`.scratch/webkit/iphone.mjs`, against a throwaway copy on :8799) |
| 8 | Widgets show accurate live data | 37 widget types return data; shopping count, expiring items, streak, XP and cooking stats match their own endpoints |
| 9 | Suggestions never change the layout | Usage creates suggestions; reading and dismissing them leaves the saved layout byte-for-byte unchanged |

Also covered: planner honours dinner days, difficulty and nutrition priorities; notification frequency
"off" sends nothing and "daily" bundles everything into one summary; appearance is per person and validated.


## End-to-end in the browser (`e2e/app.e2e.mjs`)

Drives the real app in WebKit (Safari's engine) as an iPhone 15 and an iPad, against a throwaway copy of
the database. 52 checks, run twice in a row with the same result:

- **Home layout saving**: move a widget and leave Home within the save delay; come back (no stale
  cached layout) and edit again (the earlier change survives); six quick moves in a row (saved order equals
  what's on screen); reload; finger drag-and-drop the way iOS sends it; size, compact, pin, hide/unhide,
  remove, add from the library; presets, Undo, Reset; switch, create, rename (an empty name never blocks
  saving), delete layouts; a second tab picks up a change by itself; the tablet keeps its own layout and
  can follow the phone again; usage suggestions never change the layout.
- **Widgets**: add to and tick off the shopping list from Home.
- **Personalise**: dinner days, variety, reminder frequency, style and "Show spending & waste" survive a reload.
- **Spending & waste**: hidden on Statistics and in Your year in food when off, back when switched on.
- **Journey, assistant and every main page** render and respond.

Two real bugs this found (both fixed): Home could show a cached older layout after you left and came back,
and the next edit then saved over your newer one; and dragging a widget with a finger never started on
iOS-style touch input.


## Settings persistence (`server/test/settings.test.ts`, `e2e/settings.e2e.mjs`)

Server (9 tests): defaults without writing; a patch changes only its keys and merges objects field by field;
invalid patches are rejected whole and change nothing; stored values are validated on read (old boolean
FIFO migrates, a bad field falls back without losing the others, unreadable JSON falls back); 8 concurrent
patches of different settings all land; old and new endpoints agree; logging out and in, and a second
session, see the same settings; personal settings stay personal while household settings are shared;
your language also sets the reminder language.

Browser (124 checks, WebKit as an iPhone 15, run twice in a row with the same result):
20 settings across all seven categories are changed through the real UI (style, theme, text size,
spending & waste, confirm before throwing away, a person's diet, a favourite cuisine, dinner days,
weeknight time, use-first strength, people, hands-free cooking, variety, a person's calories, a nutrition
priority, the fibre target, reminder frequency, the cooking-question time, start page, XP per meal). Each is
then checked after navigating away and back, after a reload, after logging out and in, on a second device
with nothing cached, and on the server. Also: a change on one device appears on another without reloading;
a rejected save puts the control back and says "Not saved"; with the connection down the change stays on
screen, is kept on the device and lands when the connection returns; five quick changes end on the last
one, with other settings changed in between also saved; language switches at once, after a reload and on
another device; a Home change made from Settings → Customise survives a reload.

Run (against a throwaway copy, never your real data): start a copy with `PORT=8799 DB_FILE=<copy.db>`,
reset it with `e2e/reset-test-account.mjs`, then run `e2e/settings.e2e.mjs` and `e2e/app.e2e.mjs` from a
folder with Playwright installed.

Real bugs these tests found and that are fixed: Settings wrote six settings at once from a stale copy (so a
change elsewhere was silently undone); Personalise and the planner sheet started from stale cached copies;
the planner sheet's "quick" switch overwrote your weeknight time; language was pinned per device; several
saves failed silently with no rollback; the dietary editor saved unchanged values on every blur and kept
showing rejected ones; and, in the new store itself, a stray field in merged patches that made the server
reject every save (caught by the browser test before release).
