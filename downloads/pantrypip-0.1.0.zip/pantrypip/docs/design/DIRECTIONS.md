# The directions (eight, plus Suite)

Each is a complete, switchable theme in the real app (Settings → Appearance → Style, or `#/design`). They
share PantryPip's components and data; they differ in tokens and in their own scoped rules. Each entry:
rationale, type, layout and hierarchy, components, personality, where it is weakest.

---

## 1 · Pantry Editorial (`editorial`)

**Rationale.** PantryPip is mostly reading: lists, recipes, plans. A food magazine is the best-known form
for making that pleasant. **Type:** Fraunces (light italic display, SOFT 30) + Figtree. **Layout:** page
titles sit on an ink rule; sections are numbered `01, 02...` in rust caps above a serif heading and a full
rule; lists lose their boxes and become ruled columns; recipe cards become magazine items (picture,
serif title, caps facts) without a frame. **Components:** 4px buttons, ink primary, pill chips in caps,
italic serif step numerals, planner days as ruled columns with a rust "today" bar. **Personality:**
literate, calm, grown-up. **Weakest:** the italic display is less legible at very small widths.

## 2 · Corner Grocer (`grocer`)

**Rationale.** The shopping list is the app's heart; a neighbourhood shop is its natural metaphor.
**Type:** Bricolage Grotesque (condensed caps, 800) + DM Mono for prices, quantities, tags and tab labels.
**Layout:** every page title sits in a red shopfront band with a striped awning underneath; Home's greeting
is the shop sign. **Components:** 2px ink outlines, hard offset shadows (a print misregistration),
buttons that press down, price-ticket pills, square-ish checkboxes, dashed receipt separators.
**Personality:** cheerful, loud, practical. **Weakest:** the strongest colour use: may tire in daily use.

## 3 · Skog (`skog`)

**Rationale.** A pantry app should lower stress. Scandinavian design removes lines and lets space and
tone do the structuring. **Type:** Albert Sans only, 300 for display. **Layout:** larger section spacing
(36px), no borders, oat background with lighter tinted fields, floating rounded tab bar, a sage pill
behind the active icon. **Components:** 14px soft rectangles, borderless chips and inputs, 1.6 icon
stroke, slow easing. **Personality:** quiet, natural, restful. **Weakest:** lowest visual hierarchy of
the eight; relies on good spacing.

## 4 · Dot (`dot`)

**Rationale.** Take only the logo's coral dot and use it as the single marker of importance.
**Type:** Outfit (geometric, circular bowls like the logo). **Layout:** white, generous, every page title
ends in a coral full stop ("Recipes."), section headings start with a dot, the active tab is a dot under
the label, today in the planner gets a dot. **Components:** pill controls, circular thumbnails, ink
primary, springy press feedback. **Personality:** playful but minimal. **Weakest:** closest to "clean
modern app"; its identity rests on discipline with the dot.

## 5 · Épicerie (`epicerie`)

**Rationale.** Good food shops make ordinary groceries feel cared for. **Type:** Cormorant Garamond
(display) + Jost (spaced caps for UI and labels). **Layout:** dark olive navigation band with an italic
wordmark, section headings as spaced caps with a fine rule to the edge, centred recipe titles.
**Components:** double-framed label cards, 2px corners, uppercase tracked buttons, roman step numerals
in oxblood, brass "today" frame. **Personality:** refined, special, slow. **Weakest:** uppercase
small labels are a little less efficient to scan; heavier for a quick-add task.

## 6 · Pip Line (`monoline`)

**Rationale.** The logo is one round-ended line; make that line the whole system. **Type:** Quicksand
700 lowercase titles (the closest open face to the wordmark) + Figtree. **Layout:** logo paper and slate
ink exactly; every card, input and control is drawn with a 2px ink line; sections start with the logo's
leaf; titles are lowercase like the wordmark. **Components:** outlined pills, circle-outlined thumbnails,
round-capped underline for the active tab, 2.25 icon stroke matching the outlines, outlined step circles,
plates as outlined circles. **Personality:** friendly, crafted, unmistakably PantryPip. **Weakest:** many
2px outlines in dense lists; mitigated by lighter row separators.

## 7 · Raster (`raster`)

**Rationale.** For people who want information, fast. **Type:** Inter Tight 700 (tight, large),
Inter, JetBrains Mono for numbers and labels. **Layout:** strict flush-left grid, 2px ink rules above
every section with mono numbers, sidebar as a numbered index, page titles up to 64px on Home.
**Components:** 0 radius everywhere, red primary, ink chips, square checks, mono badges, full-width red
active bar. **Personality:** precise, neutral, efficient. **Weakest:** least warm; Pip and food emoji do
all the friendliness.

## 8 · Seventies Kitchen (`seventies`)

**Rationale.** Home cooking nostalgia, made contemporary. **Type:** Fraunces 760 with SOFT 100 and WONK 1
(Cooper-like softness) + Figtree. **Layout:** an arch behind the greeting, recipe pictures in arched
windows, arched product thumbnails, chocolate floating tab bar with a mustard active pill.
**Components:** 26px cards without borders, pill controls, mustard checks and step circles, terracotta
primary. **Personality:** warm, generous, characterful. **Weakest:** the arch motif must stay limited to
these three places or it becomes kitsch.


## 9 · Suite (`suite`), added 2026-11-08

**Rationale.** Ties PantryPip to its home, The Convenience Suite website (from the owner's screenshot), so
the app and the site read as one family. **Type:** Newsreader 380 (a light, bookish serif close to the
site's headlines) + Figtree. **Layout:** every page title sits in a black masthead edge to edge with four
hard sunset stripes underneath (yellow, orange, vermilion, red); Home's greeting is the site's hero, with
the date as a yellow spaced-caps kicker. **Components:** warm off-white cards with 22px corners, black
square-ish uppercase buttons, white outlined secondary buttons, dashed pill tags, small square bullets on
"why" notes, an orange top bar on today's planner day, black tab bar and sidebar with a yellow active state
and an orange edge. **Personality:** quiet, confident, editorial-meets-shop. **Weakest:** the masthead
takes vertical space on short phone screens.

---

## Coverage

All eight style every screen through the shared components: Home (hero, quick actions, widgets),
Groceries (stock and shopping list, shopping mode), Recipes (discover, recipe detail, cook mode),
Planner (week grid, meals), Progress (journey, Pip), Friends, Settings, sheets/dialogs, toasts, empty
states (Pip), loading (calm pulse + thinking Pip), navigation (phone tab bar and desktop sidebar), and the
sign-in page's type.
