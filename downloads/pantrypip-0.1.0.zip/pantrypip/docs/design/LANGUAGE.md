# Design language

The shared grammar behind all eight directions. A direction may push one rule further than the others,
but none breaks these.

## Principles

1. **A line, a leaf, a dot.** The logo's three ingredients are the only brand ornaments. Everything else
   is type, space and colour.
2. **Paper, not screens.** Backgrounds are warm papers (or a clean white in Raster/Dot), surfaces are a
   touch lighter, ink is slate or a warm near-black, never `#000` on `#fff` except in Raster.
3. **Structure from type and rules, not from boxes.** Fewer bordered cards; where boxes remain, each
   direction gives them its own logic (ruled list, label frame, outline, tinted field, ticket).
4. **Flat colour.** No gradients for surfaces, no glass, no blur. The one exception is the awning stripe
   in Corner Grocer, which is a hard stripe, not a gradient look. Recipe plates were flattened too.
5. **Food is the colour.** The UI stays calm so recipe colours and food emoji carry the warmth.
6. **Grown-up warmth.** Friendly copy and Pip, but no confetti on every action, no bouncing buttons,
   no baby-faced illustration.

## Typography

- Every direction defines six roles: display, heading, body, UI, data, label (see `TYPOGRAPHY.md`).
- Display type is big and set tight; body type is 15px/1.45 and never lighter than 400.
- Numbers use tabular figures; three directions give data its own mono.
- Labels may be spaced capitals, but never body text.

## Shape

| Token | Range across directions | Rule |
|---|---|---|
| `--r` (cards) | 0 → 26px | follows the direction's material: printed page (0–4), label (2–3), ticket (12), soft object (18–26) |
| `--r-btn` | 0 → pill | buttons echo cards, except pill directions where buttons are the round element |
| `--bw` | 1 → 2px | 2px only in the outline directions (Grocer, Pip Line) |
| icon stroke | 1.5 → 2.25 | lighter for the refined directions, heavier for the outlined ones |

## Illustration

- Pip is the only character. Food stays emoji (data-driven per product), on a flat plate.
- Drawings are monoline with round caps and joins, built from circles and straight lines.
- Decorative shapes are limited to: rules (Editorial, Raster, Épicerie), the awning (Grocer), the arch
  (Seventies), the leaf (Pip Line), the dot (Dot). One per direction.

## Colour

Each direction has 20 colour tokens in two modes (light, dark). Semantic roles are fixed across
directions so the app's meaning never changes with the style:

| Token | Meaning |
|---|---|
| `--herb` | primary/positive: links, active tab, "you have this", progress |
| `--tomato` | missing, out, destructive, alerts |
| `--saffron` | low, soon, warmth |
| `--plum`, `--sky` | secondary categories (AI, info) |
| `--accent-fill` / `--on-accent` | the one filled action per screen |

All text pairs meet WCAG AA 4.5:1 in both modes (checked by script, see `TESTING.md`).

## Motion

- Duration 100–240ms, easing per direction (`--ease`), springy only in Dot and Seventies.
- Pip blinks, sways and thinks a few times, then stops; nothing loops forever except the waiting state.
- Settings → Animations (reduced/off) and the system's reduced-motion setting override every direction.
