# Logo breakdown

Source: `web/public/icon.svg` (logo 15, "pip, written") and the PNG icons made from it. This is the master
logo: there is no separate wordmark file (confirmed by the owner, 2026-11-08).

## What the mark is

The icon is the word **pip** written as a single monoline drawing on a warm off-white tile:

| Part | Geometry (512 grid, before the 0.92 inset) | Reading |
|---|---|---|
| first **p** | stem `x=112, y=206→430`; bowl circle `c=(170,258) r=58` | the bowl carries two dot eyes: this is Pip's face |
| **i** | stem `x=262, y=214→314`, short (x-height only) | its dot is a **leaf** (`#6A994E`), not a circle |
| second **p** | stem `x=320, y=206→430`; bowl circle `c=(378,258) r=58` | a solid coral dot (`#E76F51`, r=20) sits in the bowl |

## Typography

- **Lowercase, single-storey, geometric.** The bowls are true circles, the stems are straight verticals.
  There is no contrast between thick and thin: it is a monoline, closer to Futura/Avenir-style geometry
  than to any humanist sans.
- **The bowl touches the stem tangentially** (bowl left edge `170−58 = 112` is exactly the stem's x). The
  join is not a drawn junction but two shapes kissing, which reads as friendly and slightly hand-built.
- **Descenders are long** (stem 224 units against a bowl of 116 + stroke): almost a full x-height below
  the baseline. This gives the word its upright, standing-figure quality: the first p literally stands.
- **x-height dominates.** There are no ascenders: the leaf is the only thing above the x-height, which
  makes it the visual "head" of the word.

## Proportions

- Bowl outer diameter: 116 + 22 = 138 units. Stroke: 22 units → **stroke ≈ 16% of the bowl, 19% of the
  inner bowl**. That is a medium-bold monoline: heavier than a hairline icon set (Lucide at 2/24 = 8%),
  lighter than a display "fat" face.
- Letter spacing is open: gap between first bowl and i stem ≈ 34 units (≈ 1.5 strokes), between i and
  second p ≈ 58 units. The rhythm is stem–bowl–stem–stem–bowl.
- The word sits slightly above centre on the tile (translated −30 in y), leaving the descenders room.

## Stroke, ends and corners

- `stroke-linecap: round` everywhere. **No square end exists in the mark.**
- No corners at all: every form is either a straight line or a circle. The tile's 112/512 corner radius
  (≈ 22%, the iOS squircle zone) is the only "corner" and it is generous.

## Negative space

- The counters of both bowls are large and open (inner diameter 94 units). The first one hosts the face,
  the second one the coral dot: **the counters are where the meaning lives.**
- The space above the x-height is empty except for the leaf, so the leaf is read immediately.

## Colour

| Role | Hex | Notes |
|---|---|---|
| Ink | `#24323B` | a blue-slate, not black: cool, calm, slightly nautical/stationery |
| Paper | `#F4F1EC` | warm off-white, like recycled paper or a paper bag lining |
| Leaf | `#6A994E` | a muted sap green; reads "fresh" without being neon |
| Coral | `#E76F51` | tomato/coral; the only warm saturated note |

Ink on paper is 11.6:1. Coral on paper is only 2.9:1, so coral is a **dot colour, never a text colour**
(the directions use darker tomatoes for text). Leaf on paper is 3.2:1: also decoration, not text.

## Personality

Quiet, literate, a little playful. It is a word first and a character second: Pip is discovered rather
than announced. The mark is not cute: no blush, no limbs, no mascot outline. That restraint is the
brief for everything else: **the identity is a line, a leaf and a dot.**

## What the redesign takes from it

1. One round-ended line as the drawing tool (Pip Line takes this literally; all directions use it for Pip).
2. Circles + verticals: geometric rounded type for display where the direction allows it.
3. The leaf as the only "ornament" of the brand (section markers in Pip Line, Pip's leaf everywhere).
4. The coral dot as a marker for "this matters" (Dot direction, Pip's cheek, active states).
5. Slate ink instead of black; warm paper instead of white, in most directions.

## Update (2026-11-08): the Suite icon and a logo per style

- The app icon (home screen, install, manifest) is now **logo 1, "Sunset pip"**: the same "pip" in cream
  on the black Suite masthead, standing on the four sunset stripes. Files: `web/public/icon.svg` and the
  PNGs, rendered by `.scratch/icons/render-suite.mjs` from `web/src/logo.ts`.
- Inside the app the logo follows the style on screen (`web/src/logo.ts`, `components/Logo.tsx`): the mark
  never changes, but each style picks tile, ink, leaf and dot colours and may add its own ground: Suite's
  sunset stripes, Corner Grocer's awning, Editorial's rust rule, Épicerie's brass double rule, Raster's red
  bar, Seventies' mustard/terracotta/avocado bands. Skog, Dot and Pip Line keep a clean centred mark;
  Classic and the earlier styles use the original paper-and-slate logo. The browser tab icon follows too.
