# Pip: the companion system

Code: `web/src/components/Pip.tsx` (drawing), `web/src/styles.css` (`.pip` motion), studio tab "Pip".

## Construction

Pip **is** the first "p" of the wordmark:

- **stem** `x=18, y=22→56` and **bowl** `circle (33,34) r=15` on a 64 grid: the bowl touches the stem
  tangentially, exactly as in the logo;
- **stroke** 5 units (≈ 17% of the bowl, the logo's ratio), 5.5 below 36px so it stays crisp; round caps
  and joins;
- **leaf** from the logo's "i" grows from the top of the stem; its colour is the "skin" earned on the
  journey (sprout green by default, tomato, lemon, blueberry, ... 13 in all);
- **face** in the bowl's counter: two dots, small mouth;
- **coral dot** from the second "p" becomes one cheek (`--pip-dot`).

The line is `currentColor` (`--pip-ink`, defaults to the direction's ink), so Pip is identical in every
direction and in dark mode: only ink and leaf change with context.

## Expressions

| Mood | Face | Used for |
|---|---|---|
| happy | dot eyes, small smile | default, progress, friends |
| calm | dot eyes, no mouth (the logo's face) | empty states |
| cheer | arc eyes, open smile | rewards, completed chapters, friends visiting |
| thinking | eyes up-right, flat mouth, two thought dots | loading, AI working |
| surprised | dot eyes, small "o" | new things found (receipt, barcode) |
| wink | one dot, one arc | invites, tips |
| sleepy | line eyes, no cheek | nothing planned, night |
| sad | dot eyes, down-turned mouth | used sparingly: food thrown away |

## Earned details (journey stages)

Drawn with the same line, in coral: an **apron tie** across the stem, a **chef's hat** (replaces the
leaf), a **scarf**, a **friendship heart**. Existing data (`companion.skin`, `companion.stages`) is
unchanged; all callers of `<Pip>` keep working.

## Motion

- blink: eyes squash for 3% of a 6s cycle, three times, then still;
- leaf sway: −9° around the stem top, twice;
- thinking dots fade in;
- `.wait`: the face looks left and right while something loads (the only looping motion);
- `.bounce`: the existing one-shot hop for rewards.

All stop with Settings → Animations: reduced/off and with the system's reduced-motion preference.

## Empty states

`<Empty>` now carries a calm Pip (64px) next to the old emoji. In the classic and earlier styles the emoji
shows; in all eight directions Pip replaces it, so empty states look the same everywhere.

## Rules (not childish)

- One Pip per screen, never on every card.
- No limbs, no speech bubbles, no blush gradients, no googly eyes.
- Never next to an error message: errors are plain and direct.
- Minimum size 20px.
