# PantryPip redesign (2026-11)

A visual-identity pass and eight switchable design directions, built into the real app, plus a ninth,
**Suite**, based on The Convenience Suite website (added later the same day).

**Try it:** Settings → Appearance → Style (eight directions at the top, earlier styles below), or the
design studio at `#/design` (Settings → Appearance → "Compare every direction in the design studio"):
- **Directions**: the eight, with fonts, palette and a Use button;
- **Compare**: the real app in phone (375) or desktop (1280) frames, one per direction, any screen, light
  or dark, on your own data. The style applies to the frame only; nothing is saved;
- **Specimen**: each direction's type roles and components on PantryPip UI;
- **Pip**: the companion's expressions, earned details and rules.

Switching is instant and changes nothing but `appearance.style`: no data, API or workflow changed. The
classic look stays the default until someone picks a direction.

| Document | Contents |
|---|---|
| [LOGO.md](LOGO.md) | breakdown of the logo: type, proportions, stroke, ends, space, colour, personality |
| [RESEARCH.md](RESEARCH.md) | reference research in eight fields; inspiration vs original decisions |
| [LANGUAGE.md](LANGUAGE.md) | the shared design language: principles, type, shape, illustration, colour, motion |
| [DIRECTIONS.md](DIRECTIONS.md) | the eight directions: rationale, type, layout, components, personality, weak spot |
| [TYPOGRAPHY.md](TYPOGRAPHY.md) | fonts, licences, roles per direction, scale, where the specimen is |
| [PIP.md](PIP.md) | the companion: construction, expressions, details, motion, empty states, rules |
| [TOKENS.md](TOKENS.md) | token architecture, layers, token list, how to add a direction |
| [TESTING.md](TESTING.md) | what was tested, problems found and fixed, what was not verified |

## Recommendation: Pip Line

**Pip Line (`monoline`) is the strongest direction**, with Pantry Editorial as the alternative.

Why Pip Line:

1. **It is the only direction that could not belong to another app.** It is derived directly from the
   logo's construction (one 2px round-ended line, circles and verticals, slate on paper, a leaf and a
   coral dot), so the icon, the companion and the interface finally speak one language.
2. **Pip feels native in it.** Pip is drawn with the same line as the cards, checkboxes and icons (icon
   stroke 2.25 matches the outlines), so the companion reads as part of the product, not a mascot pasted on.
3. **It is warm without being childish.** Lowercase page titles echo the wordmark; outlines and the leaf
   marker give friendliness; colour is used for meaning only.
4. **It survives the practical tests.** AA contrast in both modes, outlines stay visible in dark mode
   (lighter slate line), works at 375px and on the desktop sidebar, no extra visual weight from shadows
   or gradients, one display font (Quicksand) plus Figtree.
5. **It scales.** New features need no new decoration: draw it with the line.

Risks and next steps: dense lists get many outlines (rows use lighter separators already; consider
dropping the outer outline on long lists), and Quicksand's lowercase titles should be checked with long
Dutch titles. If the household prefers something calmer for daily use, **Pantry Editorial** is the most
refined and readable of the eight, and its numbered section structure could be borrowed by Pip Line.

Not recommended as the default: Corner Grocer (too loud for daily use, great as a seasonal look), Raster
(least warm), Skog (weakest hierarchy).
