# Visual identity research

Purpose: find where PantryPip's look can come from without looking like another brand, a generic SaaS
dashboard or a children's app. Each field below lists the references studied (well-known, public work),
what is useful in it, and what was deliberately **not** taken. The last section separates inspiration from
original decisions.

Method: desk research from design knowledge of the named publications, brands and type foundries, plus
the type specimens of every font considered (Google Fonts / Fontsource metadata, OFL licences checked in
`node_modules/@fontsource*/*/LICENSE`). No brand assets were downloaded or traced.

## 1 · Editorial food magazines

References: *Kinfolk* and *Cereal* (quiet, image-led, generous margins), the *Bon Appétit* redesigns of
the late 2010s (confident serif headlines, bright colour fields), *Apartamento* (informal, text-heavy),
*The Gentlewoman* / *Fantastic Man* (rules, numbered sections), cookbook typography of Ottolenghi's
*Plenty* era (warm serif + clean sans pairing).

Useful: big serif headlines against small sans captions; **hairline rules as structure instead of boxes**;
numbered sections ("01", "02") as navigation; captions in spaced capitals; italics for warmth.

Not taken: photography-first layouts (PantryPip has few photos), fashion-magazine coldness, any
publication's masthead or typeface.

## 2 · Scandinavian minimalism

References: Hay and Muuto product pages, the Danish coffee roaster La Cabra, Iittala's tableware
catalogues, Fiskars, Norwegian public-sector design (Statens vegvesen signage), Copenhagen restaurants'
menus.

Useful: **light weights at large sizes**; space instead of lines; muted naturals (oat, birch, sage,
spruce, clay); soft rectangles rather than pills; calm motion.

Not taken: Iittala's red dot (our coral dot comes from our own logo, and we keep it coral and round, never
a red sticker), any furniture-brand wordmark, the grey-on-grey low contrast common in the genre (contrast
kept ≥ 4.5:1).

## 3 · Retro grocery (1950s–70s modernism)

References: Sainsbury's own-label packaging of the 1960s–70s (bold flat colour, big type, simple
illustration), Migros and Coop signage in Switzerland, American supermarket shelf talkers and price
tickets, Dutch Albert Heijn packaging of the 1970s, shop awnings.

Useful: **flat bold colour fields**, chunky outlined shapes, price-tag/ticket typography (monospace
numerals, uppercase), the shopfront as a header, hard offset shadows as a print idea (misregistered
second colour).

Not taken: any specific pack design, logos, or the "vintage texture" cliché (no grain, no distress).

## 4 · Boutique packaging

References: Fortnum & Mason tins, Aesop labels (typographic, label as information), Le Labo's typed
labels, French épiceries fines and their gold-on-dark shopfronts, wine labels.

Useful: **framed labels** (double rule), spaced small capitals, classical serif display, a dark band
(shopfront) with a metal accent, roman numerals.

Not taken: gold foil effects, crests, Aesop's amber/brown palette and Helvetica-only labels.

## 5 · Independent coffee and lifestyle brands

References: Blue Bottle (one monoline symbol, lots of white), Tim Wendelboe, Square Mile, Kaffe 1668,
small Dutch roasters' bags.

Useful: **a single simple mark used with total consistency**; white or kraft backgrounds; one accent;
confident small type.

Not taken: any symbol shape. Our "one mark" is Pip/the leaf, already ours.

## 6 · Monoline iconography

References: Lucide (already in the app) and Feather, Phosphor, Material Symbols Rounded, the stroke
illustration style of wayfinding systems, Paul Rand-era children's books (for what to avoid: they tip
into childish quickly).

Useful: **one stroke weight, round caps, round joins**; drawings built from circles and straights; icons
and character drawn with the same tool so they belong together.

Not taken: filled "duotone" icon styles, emoji-like characters, mascots with limbs.

## 7 · Swiss / contemporary grotesk

References: Josef Müller-Brockmann's grid systems, Vignelli's *Canon*, contemporary Swiss studios' web
work, Swiss railway (SBB) timetables.

Useful: **strict column grid, flush-left, big tight headings, numbers in a mono for data**, one red,
nothing decorative.

Not taken: Helvetica itself (Inter Tight + Inter + JetBrains Mono are open alternatives), SBB red/clock.

## 8 · Organic modern retro (1970s kitchen)

References: 1970s Habitat catalogues, Cooper Black in food packaging, arch-shaped windows and mirrors
of current interior trends, terracotta/mustard/avocado kitchen tiles, *The Joy of Cooking* era covers.

Useful: **soft heavy serif**, arches as a frame, warm earthy palette, chunky rounded controls.

Not taken: Cooper Black itself (Fraunces with SOFT 100 and WONK 1 is an open, more refined cousin),
psychedelic gradients, orange-brown overload (kept to cream + three accents).

## Inspiration versus original decisions

| Inspired by research | Original to PantryPip |
|---|---|
| Hairline rules and numbered sections (magazines) | Pip as the letter "p" with a face, drawn from the logo's own geometry |
| Light weights and space (Scandinavia) | The leaf as the only ornament: section marker, Pip's head, favicon |
| Flat colour, price tickets, awning (retro grocery) | The coral dot as a functional "this matters" marker (active tab, today, first step) |
| Framed labels, spaced caps (boutique) | Lowercase page titles echoing the lowercase wordmark (Pip Line) |
| One mark used consistently (coffee brands) | One token architecture where every direction changes the same 50 variables plus a scoped rule set |
| Stroke icon discipline (Lucide etc.) | Icon stroke weight as a token, tuned per direction (1.5–2.25) |
| Grid and mono numerals (Swiss) | Directions previewed live on real data, per frame, without saving |
| Arches and soft serif (70s) | Arched recipe "windows" and arched thumbnails as the Seventies signature |

Every colour value, every rule and every drawing in the implementation was made for PantryPip; no brand's
palette was sampled.
