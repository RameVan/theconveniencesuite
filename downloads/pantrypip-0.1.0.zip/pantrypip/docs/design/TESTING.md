# Testing report (2026-11-08)

Setup: a `VACUUM INTO` copy of the database under `.scratch/dz/`, server on port 8798 and Vite on 5188
(`dz-server`, `dz-web` in `.claude/launch.json`), demo test account. The live server (8787) and
`data/larder.db` were not touched.

## Automated

| Check | Result |
|---|---|
| `tsc --noEmit` (web) | pass |
| `vite build` (to `.scratch/dz/dist`) | pass; CSS 161 kB (34 kB gzip), main JS unchanged in size apart from the studio page |
| `npm test` (server) | 238/241; the 3 failures are the known journey-dashboard tests, unchanged |
| Contrast script over every token pair, 8 directions × 2 modes | all text pairs ≥ 4.5:1 after fixes (below) |

Pairs checked: ink/bg, ink-2/surface, ink-3/bg and /surface, herb/surface and /bg, tomato/surface and
/bg, on-accent/accent-fill, chip-on-ink/chip-on, on-band/topbar-bg, on-nav/nav, herb/herb-soft and
tomato/tomato-soft (pills), saffron/surface (≥ 3:1, used for icons and large text only).

## Visual, in the browser

Each direction opened as `/?dz=<id>&dzmode=<mode>#/<screen>` at 375×812 (phone, 16px gutter) and
1280×800 (desktop sidebar), plus the studio's own Compare, Specimen and Pip tabs at 375 and desktop.

| Direction | Phone screens checked | Desktop | Dark |
|---|---|---|---|
| Pantry Editorial | Home, Groceries/shopping list, studio specimen | studio | specimen |
| Corner Grocer | Home, recipe detail, shopping list | — | shopping list |
| Skog | Planner | — | — |
| Dot | Recipes (discover) | — | — |
| Épicerie | In stock | Planner | — |
| Pip Line | Shopping list, Home | Planner | Home |
| Raster | Home | — | Recipes (desktop) |
| Seventies Kitchen | Recipes | — | Home (before and after the arch fix) |

The studio itself was checked on desktop (Directions cards for all eight in light, Pip tab, Compare grid
with the Home frames) and at 375px (Specimen tab, dark, Pantry Editorial: lists, recipe card, planner
day, controls, dialog). Desktop was checked for 3 directions and dark for 5; the rest rely on the same
shared rules and the contrast script. A full 8 × 8 screens × 2 modes × 2 sizes sweep was not done.

## Problems found and fixed

1. **Seventies, dark Home:** the arch behind the greeting ran down over the first card and hid its
   text (positioned pseudo-element painted above the next sibling). Now bounded to the hero.
2. **Raster:** the Home ask field and the mic stayed pill-shaped. The ask field now follows
   `--r-input`, mic/FAB follow `--r-btn`.
3. **Contrast:** 7 pairs were between 3.9 and 4.47:1 (tomato on its soft tint in Grocer, Skog, Dot,
   Seventies; tomato and herb in Pip Line; red on its tint in Raster). Darkened each text colour; fills
   kept their brighter value.
4. **Compare frames:** scaling with CSS `calc(100cqw / 375px)` needs typed arithmetic that older
   browsers lack; replaced with a ResizeObserver scale.

## Rejected during design

- Glass/gradient bands from the earlier styles: not carried into any direction.
- A filled, blushing Pip with arms: replaced by the monoline "p" (see `PIP.md`).
- Lowercase on *all* headings in Pip Line: names in greetings looked wrong; only page titles are lowercase.
- Awning stripes on every section in Corner Grocer: too loud; only under the shopfront.

## Not verified

- Real iPhone/Android hardware and the installed PWA (safe-area insets were only exercised through CSS).
- Every secondary screen in every direction (Friends play, receipt sheet, cook mode) was not looked at
  one by one; they use the same components and tokens.
- Screen readers: no new semantics were added except the studio's tabs/radios, which use roles.
- Firefox: `@scope` is supported from Firefox 146; older Firefox ignores the scoped rules and shows each
  direction's colours and fonts on the classic layout.

## Suite (added later)

Checked at 375px (Home, shopping list light; Recipes dark) and 1280px (Home, Planner). Contrast script: all
text pairs ≥ 4.5:1 in both modes (lowest: orange kicker on cards 4.79, saffron on cards 4.63).
