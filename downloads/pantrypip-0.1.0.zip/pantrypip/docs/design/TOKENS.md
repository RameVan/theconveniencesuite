# Token architecture

Code: `web/src/directions.css`, `web/src/appearance.ts`.

## How a direction is applied

```
<html data-direction="editorial" data-mode="light">        ← Settings → Style, saved per person
<section class="dz-frame" data-direction="raster" data-mode="dark">  ← studio preview frame
/?dz=grocer&dzmode=dark#/plan                              ← studio Compare frame (this frame only)
```

- `appearance.ts` sets `data-direction` for the eight directions (and keeps `data-style` for the earlier
  styles, untouched). `data-mode` comes from Settings → Light or dark / the system.
- The server accepts the eight new ids in the `appearance.style` enum (`server/src/domain/settings.ts`,
  `server/src/http/routes.ts`). Nothing else on the server changed: no data, API or workflow changes.

## Three layers

1. **Tokens** (`[data-direction='x'][data-mode]`, `[data-direction='x'][data-mode='dark']`): plain
   custom properties, so they inherit into everything and work on `<html>` or on any element.
2. **Shared rules** (`@scope ([data-direction]) to ([data-direction]) { ... }`): make the existing
   components read the tokens (buttons, chips, inputs, cards, lists, checks, dialogs, toasts, tab bar,
   empty and loading states, Pip).
3. **Direction rules** (`@scope ([data-direction='x']) to ([data-direction])`): what makes the direction
   itself: rules and counters, awning, arches, label frames, floating bars, sidebars.

`@scope ... to ([data-direction])` stops a page-level direction from reaching into a preview frame with
another direction; scope proximity makes the nearer direction win. Scoped rules also beat the base
stylesheet at equal specificity, so no `!important` was needed.

## Token list

| Group | Tokens |
|---|---|
| Colour | `--bg --bg-2 --surface --surface-2 --ink --ink-2 --ink-3 --line --line-2 --herb --herb-2 --herb-soft --tomato --tomato-soft --saffron --saffron-soft --plum --plum-soft --sky --ok` |
| Actions | `--accent-fill --on-accent --chip-on --chip-on-ink --topbar-bg --on-band` (+ direction extras: `--rust --hard --awning --brass --nav --on-nav --mustard --dot`) |
| Type | `--font --font-display --font-label --font-data --font-brand --display-weight --display-tracking --display-style --display-case --display-fvs --h1-size --h-weight --h-size --h-case --h-tracking --label-case --label-tracking --label-weight --btn-case --btn-tracking --btn-weight` |
| Shape | `--r-sm --r --r-lg --r-btn --r-chip --r-input --bw --card-border` |
| Depth | `--shadow-sm --shadow --shadow-lg --card-shadow --btn-shadow --scrim` |
| Icons | `--icon-stroke` (applied to every Lucide icon) |
| Motion | `--ease --dur` |
| Spacing | `--space-section` (plus the existing Settings → Spacing: compact) |
| Pip | `--pip-ink --pip-leaf --pip-dot` |

The original names (`--herb`, `--tomato`, ...) were kept on purpose: the whole app already reads them, so
the directions restyle every screen without touching page code.

## Personal settings that still apply on top

Text size, spacing (compact), cards (outlined/flat), animations, minimalist mode and the unlocked accent
colour (which overrides `--herb` inline) all keep working in every direction.

## Adding a direction

1. Add an entry with `direction: true` to `STYLES` in `appearance.ts` (names, description, fonts, preview colours).
2. Add the id to the two server enums.
3. Add a light and a dark token block and an `@scope` block in `directions.css`.
4. Add its type roles to `TYPE` in `pages/DesignStudio.tsx`.
