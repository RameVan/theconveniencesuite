# Typography system

All fonts are open source under the **SIL Open Font License 1.1** (free for commercial use, embedding and
self-hosting), installed as `@fontsource` / `@fontsource-variable` packages and bundled by Vite. Nothing
is fetched from Google or any third party at runtime. Each `@font-face` uses `unicode-range`, and browsers
only download a file the first time text actually uses that face, so a person on one direction downloads
only that direction's fonts (typically 1–2 variable files, 30–130 kB each, then cached by the service
worker).

## Why these faces fit the logo

The wordmark is lowercase, monoline, geometric, with circular bowls and round ends. Candidate faces were
judged on: circular `o`/`p` bowls, single-storey `a`/`g` (or at least simple), low stroke contrast,
open counters, and a lowercase that can carry a word on its own.

| Face | Closeness to the logo | Used in |
|---|---|---|
| **Quicksand** | closest: circular bowls, round terminals, monoline | Pip Line display |
| **Outfit** | geometric, circular bowls, clean | Dot (all roles) |
| **Figtree** | friendly geometric-humanist; great body text | Editorial, Pip Line, Seventies body/UI |
| **Albert Sans** | Scandinavian geometric grotesk, light weights hold up | Skog (all roles) |
| **Jost** | Futura-like geometry; elegant in spaced caps | Épicerie body, UI, labels |
| **Inter / Inter Tight** | neutral grotesk for a strict grid | Raster |
| **Bricolage Grotesque** | quirky grotesk with width + optical axes; condensed caps feel like shop signs | Corner Grocer |
| **Fraunces** | "Old Style soft" serif with SOFT and WONK axes: from refined to Cooper-like | Editorial (soft 30, light italic), Seventies (soft 100, wonky, heavy) |
| **Cormorant Garamond** | classical display Garamond | Épicerie display |
| **Newsreader** | light text serif with optical sizes; matches the Convenience Suite site | Suite display and headings |
| **DM Mono / JetBrains Mono** | tabular data, price tickets | Grocer, Raster data and labels |

## Roles per direction

| Direction | Display | Heading | Body | UI | Data | Label |
|---|---|---|---|---|---|---|
| Pantry Editorial | Fraunces 420 italic, 36–52px | Fraunces 500 | Figtree 400 | Figtree 600 | Figtree tabular | Figtree 650 caps .1em |
| Corner Grocer | Bricolage 800, wdth 75, caps | Bricolage 800 caps | Bricolage 400 | Bricolage 700 | DM Mono 500 | DM Mono caps |
| Skog | Albert Sans 300, 34–46px | Albert Sans 450 | Albert Sans 400 | Albert Sans 550 | Albert Sans tabular | Albert Sans 500 |
| Dot | Outfit 600 + coral full stop | Outfit 600 | Outfit 400 | Outfit 600 | Outfit tabular | Outfit 600 |
| Épicerie | Cormorant Garamond 500 italic, 38–54px | Cormorant 600 | Jost 400 | Jost 500 caps .14em | Jost tabular | Jost 500 caps .2em |
| Pip Line | Quicksand 700, lowercase | Quicksand 700 | Figtree 400 | Figtree 600 | Figtree tabular | Figtree 600 |
| Raster | Inter Tight 700, −0.035em, 40–64px | Inter Tight 650 | Inter 400 | Inter 600 | JetBrains Mono 500 | JetBrains Mono caps |
| Seventies Kitchen | Fraunces 760, SOFT 100, WONK 1 | Fraunces 700 soft | Figtree 400 | Figtree 700 | Figtree tabular | Figtree 800 |
| Suite | Newsreader 380, 36–64px | Newsreader 420 | Figtree 400 | Figtree 650 caps | Figtree tabular | Figtree 650 caps .14em |

## Scale

Body 15px/1.45 (16.5px with Settings → Text size: large). Page titles use `--h1-size` (28–40px), Home's
greeting runs larger with `clamp()` so it scales from 375px to desktop. Section headings use `--h-size`
(19–23px). Labels 10–12.5px, never below 9px (tab labels in Épicerie).

## Specimen

The live specimen is in the app: **Settings → Appearance → "Compare every direction in the design
studio" → Specimen** (`#/design`). It shows each direction's six roles on real PantryPip UI: section
heading, shopping list rows, a recipe card, a planner day, buttons, chips, pills, search, switch, a dialog,
an empty state with Pip, a loading state and a toast, in light or dark.
