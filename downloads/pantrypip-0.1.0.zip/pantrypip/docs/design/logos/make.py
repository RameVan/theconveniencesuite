# Generates the Suite logo concepts: logo-01.svg … logo-20.svg and index.html (the gallery).
# Run: python docs/design/logos/make.py
import os, html

HERE = os.path.dirname(os.path.abspath(__file__))
K, K2, C = '#0D0D0D', '#1C1C1C', '#F7F3EA'
Y, O, V, R = '#F5B335', '#F08A2B', '#E3532B', '#B8261E'
LEAF, DEEP = '#6A994E', '#2C5A4B'
SUN = [Y, O, V, R]
SERIF = "'Newsreader', Georgia, serif"


def tile(body, bg=K, defs=''):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">'
            f'<defs><clipPath id="t"><rect width="512" height="512" rx="112"/></clipPath>{defs}</defs>'
            f'<g clip-path="url(#t)"><rect width="512" height="512" fill="{bg}"/>{body}</g></svg>')


def stripes(y, h, x=0, w=512, colors=SUN):
    return ''.join(f'<rect x="{x}" y="{y + i * h}" width="{w}" height="{h}" fill="{c}"/>' for i, c in enumerate(colors))


def leaf(x, y, s=1, fill=LEAF, rot=0):
    # the leaf from the logo's "i", base at (x, y)
    return (f'<path transform="translate({x} {y}) rotate({rot}) scale({s})" '
            f'd="M0 0C0 -26 16 -42 42 -44C40 -20 24 -4 0 0Z" fill="{fill}"/>')


def face(cx, cy, s=1, fill=K):
    return (f'<circle cx="{cx - 14 * s}" cy="{cy - 6 * s}" r="{9 * s}" fill="{fill}"/>'
            f'<circle cx="{cx + 16 * s}" cy="{cy - 6 * s}" r="{9 * s}" fill="{fill}"/>')


def p_glyph(stem_x, top, bottom, cx, cy, r, stroke, color=C):
    return (f'<path d="M{stem_x} {top}V{bottom}" stroke="{color}" stroke-width="{stroke}" stroke-linecap="round" fill="none"/>'
            f'<circle cx="{cx}" cy="{cy}" r="{r}" stroke="{color}" stroke-width="{stroke}" fill="none"/>')


def pip_word(dx=0, dy=0, s=1, ink=C, leaf_fill=LEAF, dot=V, face_fill=None):
    # the current wordmark, re-coloured: stem–bowl, i with a leaf, stem–bowl with a dot
    g = (f'<g transform="translate({dx} {dy}) scale({s})">'
         f'<path d="M112 206V430M262 214V314M320 206V430" fill="none" stroke="{ink}" stroke-width="22" stroke-linecap="round"/>'
         f'<circle cx="170" cy="258" r="58" fill="none" stroke="{ink}" stroke-width="22"/>'
         f'<circle cx="378" cy="258" r="58" fill="none" stroke="{ink}" stroke-width="22"/>'
         f'<path d="M262 176C262 150 278 134 304 132C302 156 286 172 262 176Z" fill="{leaf_fill}"/>'
         f'<circle cx="156" cy="252" r="9" fill="{face_fill or ink}"/><circle cx="186" cy="252" r="9" fill="{face_fill or ink}"/>'
         f'<circle cx="378" cy="258" r="20" fill="{dot}"/></g>')
    return g


L = []  # (title, idea, svg)

# 01 · Sunset pip: today's wordmark on the masthead, sunset under it
L.append(('Sunset pip', 'The current “pip” wordmark in cream on the black masthead, with the four Suite stripes as the ground it stands on.',
          tile(pip_word(dx=8, dy=-46, s=0.96) + stripes(408, 26))))

# 02 · Rising bowl: the p's bowl is a sun made of the stripes
defs = '<clipPath id="half"><rect x="0" y="0" width="512" height="300"/></clipPath><clipPath id="sun"><circle cx="292" cy="300" r="128"/></clipPath>'
L.append(('Rising bowl', 'One big “p”: the bowl is a sun rising out of the stripes, the stem stands in front of it like a horizon post.',
          tile(f'<g clip-path="url(#half)"><g clip-path="url(#sun)">{stripes(172, 32)}</g></g>'
               f'<rect x="96" y="300" width="320" height="8" rx="4" fill="{C}"/>'
               f'<path d="M164 172V424" stroke="{C}" stroke-width="34" stroke-linecap="round"/>' + leaf(164, 150, 1.4), defs=defs)))

# 03 · Serif pip: Newsreader lowercase, leaf as the i's dot
L.append(('Serif pip', 'The word set in Newsreader like the Suite headlines; the dot of the i is the leaf, the sunset runs underneath as a rule.',
          tile(f'<text x="256" y="318" text-anchor="middle" font-family="{SERIF}" font-size="230" font-weight="400" fill="{C}" letter-spacing="-6">pıp</text>'
               + leaf(250, 160, 1.15) + stripes(380, 14, x=96, w=320))))

# 04 · Striped p: the bowl filled with sunset bands
defs = '<clipPath id="b"><circle cx="286" cy="226" r="104"/></clipPath>'
L.append(('Striped p', 'A single solid “p” whose bowl is filled with the four bands: the pantry jar seen from the side, layered like the site’s footer.',
          tile(f'<g clip-path="url(#b)">{stripes(122, 52)}</g>'
               f'<rect x="150" y="122" width="44" height="300" rx="22" fill="{C}"/>' + face(286, 196, 1.3, K) + leaf(172, 112, 1.3), defs=defs)))

# 05 · Pip at dusk: the face bowl on a sunset horizon
L.append(('Pip at dusk', 'Pip’s face as a cream disc sitting on the horizon; the sunset bands fade down to red like the Suite page break.',
          tile(stripes(330, 46) + f'<circle cx="256" cy="250" r="118" fill="{C}"/>' + face(256, 262, 1.8, K)
               + f'<circle cx="320" cy="290" r="11" fill="{V}"/>' + leaf(256, 136, 1.4))))

# 06 · Layered jar: pantry jar with four layers
L.append(('Layered jar', 'A cream outline jar holding four layers of “stock”, the sunset colours as lentils, pasta, rice and spice. A leaf on the lid.',
          tile(f'<rect x="146" y="120" width="220" height="40" rx="14" fill="none" stroke="{C}" stroke-width="20"/>'
               f'<path d="M160 168V384a40 40 0 0 0 40 40h112a40 40 0 0 0 40-40V168" fill="none" stroke="{C}" stroke-width="20" stroke-linejoin="round"/>'
               f'<g clip-path="url(#jar)">{stripes(236, 48, x=170, w=172)}</g>' + leaf(256, 112, 1.2, rot=-10),
               defs='<clipPath id="jar"><path d="M170 178V380a34 34 0 0 0 34 34h104a34 34 0 0 0 34-34V178Z"/></clipPath>')))

# 07 · Shelf: three shelves, Pip on top
def jar(x, y, w, h, fill=C):
    return f'<rect x="{x}" y="{y - h}" width="{w}" height="{h}" rx="{min(w, h) / 4}" fill="{fill}"/><rect x="{x + w * .15}" y="{y - h - 10}" width="{w * .7}" height="10" rx="4" fill="{fill}"/>'
L.append(('Shelf life', 'Three pantry shelves in the sunset colours, jars on each; Pip stands on the top shelf like one more jar.',
          tile(''.join(f'<rect x="80" y="{y}" width="352" height="16" rx="8" fill="{c}"/>' for y, c in ((214, Y), (318, O), (422, V)))
               + p_glyph(176, 120, 214, 214, 150, 32, 14) + face(214, 156, 0.6, C) + leaf(176, 112, 0.75)
               + jar(270, 214, 52, 64) + jar(340, 214, 60, 48)
               + jar(110, 318, 62, 70) + jar(190, 318, 46, 52) + jar(300, 318, 80, 60)
               + jar(130, 422, 90, 56) + jar(250, 422, 54, 72) + jar(330, 422, 58, 50))))

# 08 · Monogram: serif pp ligature with kicker dot
L.append(('Masthead monogram', 'Two serif “p”s locked together, cream on black: a quiet monogram for the masthead, with an orange kicker dot.',
          tile(f'<text x="236" y="350" text-anchor="middle" font-family="{SERIF}" font-size="300" font-weight="380" fill="{C}" letter-spacing="-70">pp</text>'
               f'<circle cx="388" cy="168" r="22" fill="{O}"/>')))

# 09 · Suite tile: 2×2 grid like the Suite mark, one square is Pip
L.append(('Suite tile', 'Speaks the Suite’s own 2×2 square mark: three colour squares and one cream square where Pip’s bowl looks out.',
          tile(f'<rect x="112" y="112" width="138" height="138" fill="{O}"/><rect x="262" y="112" width="138" height="138" fill="{Y}"/>'
               f'<rect x="112" y="262" width="138" height="138" fill="{V}"/><rect x="262" y="262" width="138" height="138" fill="{C}"/>'
               f'<circle cx="331" cy="331" r="40" fill="none" stroke="{K}" stroke-width="14"/>' + face(331, 337, 0.7, K))))

# 10 · Open box: the site's line cube, with a leaf inside
L.append(('Open crate', 'Borrows the line-drawn box from the Suite hero: an open crate in cream lines, a leaf growing inside, a solid cream base.',
          tile(f'<path d="M256 112 400 184V352L256 424 112 352V184Z" fill="none" stroke="{C}" stroke-width="10" stroke-linejoin="round"/>'
               f'<path d="M112 184 256 256 400 184M256 256V424" fill="none" stroke="{C}" stroke-width="10" stroke-dasharray="14 12"/>'
               f'<path d="M112 352 256 424 400 352V378L256 450 112 378Z" fill="{C}"/>' + leaf(256, 300, 2.2, fill=O))))

# 11 · Plate: top-down plate on a striped cloth
L.append(('Dinner plate', 'Seen from above: a cream plate on a sunset tablecloth, Pip’s face as the meal. Food first, app second.',
          tile(stripes(0, 128) + f'<circle cx="256" cy="256" r="150" fill="{C}"/><circle cx="256" cy="256" r="108" fill="none" stroke="{K}" stroke-width="6" opacity=".18"/>'
               + face(256, 266, 2, K) + f'<path d="M226 300q30 22 60 0" fill="none" stroke="{K}" stroke-width="12" stroke-linecap="round"/>')))

# 12 · Sunset leaf: one leaf filled with diagonal bands
defs = '<clipPath id="lf"><path d="M130 400C130 232 228 134 400 118C388 288 292 388 130 400Z"/></clipPath>'
L.append(('Sunset leaf', 'Just the leaf, at full size, filled with the four bands on a diagonal. The simplest mark: works as a favicon at 16px.',
          tile(f'<g clip-path="url(#lf)" transform="rotate(0)"><g transform="rotate(48 256 256)">{stripes(96, 80, x=-100, w=712)}</g></g>'
               f'<path d="M150 380 330 200" stroke="{K}" stroke-width="12" stroke-linecap="round"/>', defs=defs)))

# 13 · Arch window: an arch with the stripes, Pip's stem in front
defs = '<clipPath id="ar"><path d="M136 420V256a120 120 0 0 1 240 0V420Z"/></clipPath>'
L.append(('Window light', 'An arched kitchen window at sundown (the bands), with Pip standing on the sill. Warm, homely, still geometric.',
          tile(f'<g clip-path="url(#ar)">{stripes(136, 71)}</g>' + f'<path d="M136 420V256a120 120 0 0 1 240 0V420" fill="none" stroke="{C}" stroke-width="16"/>'
               + f'<rect x="112" y="414" width="288" height="18" rx="9" fill="{C}"/>'
               + p_glyph(232, 300, 414, 266, 336, 34, 14, K) + face(266, 342, 0.6, K) + leaf(232, 292, 0.7, fill=DEEP), defs=defs)))

# 14 · Receipt: a cream receipt with sunset lines
L.append(('Receipt', 'PantryPip reads your receipts: a cream receipt slip with a torn edge, four coloured lines, and the leaf as the shop’s stamp.',
          tile(f'<path d="M160 96H352V400L328 416 304 400 280 416 256 400 232 416 208 400 184 416 160 400Z" fill="{C}"/>'
               + ''.join(f'<rect x="190" y="{170 + i * 50}" width="{132 - (i % 2) * 40}" height="16" rx="8" fill="{c}"/>' for i, c in enumerate(SUN))
               + leaf(300, 150, 0.9))))

# 15 · Basket: shopping basket with striped weave
L.append(('Market basket', 'A shopping basket whose weave is the four bands; the handle is one round-ended line, like Pip’s stroke.',
          tile(f'<path d="M176 220a80 80 0 0 1 160 0" fill="none" stroke="{C}" stroke-width="22" stroke-linecap="round"/>'
               f'<g clip-path="url(#bk)">{stripes(220, 46, x=96, w=320)}</g>' + leaf(256, 206, 1.1, rot=-20),
               defs='<clipPath id="bk"><path d="M112 220H400L366 404a24 24 0 0 1-24 20H170a24 24 0 0 1-24-20Z"/></clipPath>')))

# 16 · Price tag: tag with serif pip
L.append(('Price tag', 'A cream price tag hanging from a string, “pip” in Newsreader on it, sunset ribbon at the end. Groceries, honestly priced at €0.',
          tile(f'<path d="M130 182 230 112H412V312H230Z" fill="{C}" transform="rotate(-14 270 212) translate(-30 60)"/>'
               f'<g transform="rotate(-14 270 212) translate(-30 60)"><circle cx="190" cy="212" r="14" fill="{K}"/>'
               f'<text x="320" y="246" text-anchor="middle" font-family="{SERIF}" font-size="96" fill="{K}">pip</text>'
               + stripes(272, 8, x=240, w=160) + '</g>'
               f'<path d="M96 130C120 200 140 250 150 278" fill="none" stroke="{C}" stroke-width="6" stroke-linecap="round"/>')))

# 17 · Voice: p with sound waves
L.append(('Say it', '“I finished the milk”: Pip’s bowl speaks, the four bands become sound waves. For the voice-first assistant.',
          tile(p_glyph(150, 156, 400, 216, 236, 66, 24) + face(216, 244, 0.95, C)
               + ''.join(f'<path d="M{306 + i * 30} {236 - 40 - i * 22}a{60 + i * 26} {60 + i * 26} 0 0 1 0 {80 + i * 44}" fill="none" stroke="{c}" stroke-width="16" stroke-linecap="round"/>' for i, c in enumerate(SUN))
               + leaf(150, 142, 1))))

# 18 · Concentric bowl: four arcs make the bowl
L.append(('Rainbow bowl', 'The bowl of the “p” drawn as four concentric half-rings in the sunset colours; one cream stem. Bold enough for a store icon.',
          tile(''.join(f'<path d="M{256 - rr} 300a{rr} {rr} 0 0 1 {2 * rr} 0" fill="none" stroke="{c}" stroke-width="26"/>' for rr, c in zip([150, 118, 86, 54], SUN))
               + f'<path d="M106 150V420" stroke="{C}" stroke-width="30" stroke-linecap="round"/>' + face(256, 290, 1.1, C))))

# 19 · Cream reverse: cream tile, black pip, sunset foot
L.append(('Daylight', 'The reverse for light surfaces: cream tile, black monoline “pip”, and the sunset as four short bars under the stems.',
          tile(pip_word(dx=8, dy=-40, s=0.96, ink=K, face_fill=K, dot=V) + stripes(412, 12, x=110, w=110) + stripes(412, 12, x=314, w=110), bg=C)))

# 20 · Wordmark lockup
lock = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><defs><clipPath id="t"><rect width="512" height="512" rx="112"/></clipPath></defs>'
        f'<g clip-path="url(#t)"><rect width="512" height="512" fill="{K}"/>'
        f'<text x="58" y="250" font-family="{SERIF}" font-size="104" font-weight="380" fill="{C}" letter-spacing="-3">pantry</text>'
        f'<text x="58" y="358" font-family="{SERIF}" font-size="104" font-weight="380" fill="{C}" letter-spacing="-3" font-style="italic">pip</text>'
        f'<text x="60" y="150" font-family="Figtree, Arial, sans-serif" font-size="22" font-weight="650" fill="{Y}" letter-spacing="4">A CONVENIENCE SUITE APP</text>'
        + stripes(412, 20) + '</g></svg>')
L.append(('Masthead lockup', 'The full name set like a Suite headline, “pip” in italic, with the yellow spaced-caps kicker. For the splash screen and store header.', lock))

assert len(L) == 20
for i, (_, _, svg) in enumerate(L, 1):
    with open(os.path.join(HERE, f'logo-{i:02d}.svg'), 'w', encoding='utf-8') as f:
        f.write(svg)

cards = []
for i, (title, idea, svg) in enumerate(L, 1):
    big = svg.replace('<svg ', '<svg class="big" ', 1)
    cards.append(f'''<figure class="card">
  <div class="sizes">{big}<div class="small">{svg.replace('<svg ', '<svg width="60" height="60" ', 1)}{svg.replace('<svg ', '<svg width="32" height="32" ', 1)}{svg.replace('<svg ', '<svg width="16" height="16" ', 1)}</div></div>
  <figcaption><span class="no">{i:02d}</span><b>{html.escape(title)}</b><p>{html.escape(idea)}</p><a href="logo-{i:02d}.svg">logo-{i:02d}.svg</a></figcaption>
</figure>''')

page = f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>PantryPip logo concepts</title>
<style>
@font-face {{ font-family: 'Newsreader'; src: url('newsreader.woff2') format('woff2'); font-weight: 200 800; }}
:root {{ --bg: #ffffff; --ink: #141414; --muted: #5f5b54; --card: #f8f6f1; --line: #e2ddd3; --kicker: #c2410c; }}
@media (prefers-color-scheme: dark) {{ :root {{ --bg: #0b0b0b; --ink: #f2efe8; --muted: #a29d93; --card: #161616; --line: #2a2927; --kicker: #f5b335; }} }}
* {{ box-sizing: border-box; }}
body {{ margin: 0; background: var(--bg); color: var(--ink); font: 15px/1.45 Figtree, system-ui, sans-serif; }}
header {{ background: #0d0d0d; color: #f7f3ea; padding: 40px 16px 28px; }}
header .in, main {{ max-width: 1180px; margin: 0 auto; }}
.k {{ color: #f5b335; text-transform: uppercase; letter-spacing: .14em; font-size: 12px; font-weight: 650; }}
h1 {{ font: 380 clamp(36px, 7vw, 60px)/1.02 'Newsreader', Georgia, serif; letter-spacing: -0.02em; margin: 8px 0 10px; }}
header p {{ color: #cfc9be; max-width: 640px; margin: 0; }}
.sun {{ height: 32px; background: linear-gradient(#f5b335 0 25%, #f08a2b 25% 50%, #e3532b 50% 75%, #b8261e 75%); }}
main {{ padding: 32px 16px 64px; display: grid; gap: 16px; grid-template-columns: repeat(auto-fill, minmax(min(100%, 340px), 1fr)); }}
.card {{ margin: 0; background: var(--card); border: 1px solid var(--line); border-radius: 22px; padding: 18px; display: grid; gap: 14px; }}
.sizes {{ display: flex; gap: 14px; align-items: flex-end; }}
.big {{ width: 150px; height: 150px; flex: none; }}
.small {{ display: flex; gap: 12px; align-items: flex-end; }}
figcaption {{ display: grid; gap: 4px; }}
.no {{ color: var(--kicker); font-size: 12px; font-weight: 650; letter-spacing: .14em; }}
figcaption b {{ font: 420 23px/1.1 'Newsreader', Georgia, serif; }}
figcaption p {{ margin: 0; color: var(--muted); font-size: 14px; }}
figcaption a {{ color: var(--muted); font-size: 12px; }}
</style></head><body>
<header><div class="in"><div class="k">PantryPip · Suite theme</div><h1>Twenty logo concepts.</h1>
<p>Each one shown as an app icon, then at home-screen (60), small icon (32) and favicon (16) size. The ingredients stay PantryPip’s own: the “p”, the leaf, Pip’s face. The Suite adds the black masthead, the four sunset bands, the Newsreader serif and the orange kicker.</p></div></header>
<div class="sun"></div>
<main>
{chr(10).join(cards)}
</main></body></html>'''
with open(os.path.join(HERE, 'index.html'), 'w', encoding='utf-8') as f:
    f.write(page)
print('wrote', len(L), 'logos')
