// End-to-end checks of the real app in WebKit as an iPhone 15 (and an iPad), against a throwaway copy
// on :8799 (it changes data: never point it at your real database).
// Run: start a copy with PORT=8799 DB_FILE=<copy.db> node server/src/index.ts, then from a folder that has
// Playwright installed (npm i playwright && npx playwright install webkit): node app.e2e.mjs Focus: the home screen layout is always saved and shown correctly, whatever you do.
import { webkit, devices } from 'playwright';

const BASE = process.env.BASE ?? 'http://localhost:8799';
const results = [];
const errors = [];
let current = '';
const check = (ok, what) => results.push({ ok: !!ok, what: `${current}: ${what}` });
async function step(name, fn) {
  current = name;
  try {
    await fn();
  } catch (e) {
    results.push({ ok: false, what: `${name}: threw ${e.message.split('\n')[0]}` });
  }
}

const browser = await webkit.launch();
const phone = await browser.newContext({ ...devices['iPhone 15'], colorScheme: 'light', locale: 'en-GB', serviceWorkers: 'block' });
const page = await phone.newPage();
page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
page.on('console', (m) => m.type() === 'error' && !/access control|Failed to load resource|microphone/i.test(m.text()) && errors.push(`console: ${m.text()}`));

const api = async (method, path, body) => {
  const r = await page.request.fetch(BASE + path, { method, data: body ? JSON.stringify(body) : undefined, headers: { 'content-type': 'application/json' } });
  return r.json().catch(() => null);
};
const serverLayout = async (device = 'phone') => {
  const d = await api('GET', '/api/dashboard');
  const p = d.config.profiles.find((x) => x.id === d.config.active);
  return { active: d.config.active, profiles: d.config.profiles, list: p.layouts[device] ?? p.layouts.phone };
};
const uiIds = () => page.$$eval('.dash > section[data-wid]', (els) => els.map((e) => e.dataset.wid));
const settle = (ms = 900) => page.waitForTimeout(ms);
const goHome = async () => {
  await page.goto(`${BASE}/#/`);
  await page.waitForSelector('.dash > section[data-wid]', { timeout: 10000 });
  await settle(600);
};
const edit = async (on = true) => {
  const editing = (await page.locator('.dash-edit').count()) > 0;
  if (on && !editing) await page.locator('.dash-customise').click();
  if (!on && editing) await page.locator('.dash-edit button:has-text("Done")').click();
  await settle(300);
};
const tool = (wid, label) => page.locator(`section[data-wid="${wid}"] [aria-label="${label}"]`).first();
/** Size, compact, pin and hide sit behind the widget's Options button. */
const option = async (wid, label) => {
  if (!(await tool(wid, label).count())) await page.locator(`section[data-wid="${wid}"] button:has-text("Options")`).click();
  return tool(wid, label);
};

// ---------- Sign in, start from the default layout ----------
await page.goto(BASE + '/');
await page.fill('input[type=email]', 'demo@larder.test');
await page.fill('input[type=password]', 'larder-demo-2026');
await page.click('button:has-text("Sign in")');
await page.waitForSelector('.hero h1', { timeout: 10000 });
await api('POST', '/api/dashboard/reset', {});
await page.evaluate(() => localStorage.clear());

await step('default layout', async () => {
  await goHome();
  const s = await serverLayout();
  check(s.active === 'home', 'the default layout is active');
  check(JSON.stringify(s.list.map((w) => w.type)) === JSON.stringify(['tonight', 'shopping', 'expiring', 'fromStock']), 'a calm default: tonight, the list, use first, ideas');
  check(JSON.stringify(await uiIds()) === JSON.stringify(s.list.filter((w) => !w.hidden).map((w) => w.id)), 'screen matches the saved layout');
});

await step('move and leave immediately', async () => {
  await edit(true);
  const before = (await serverLayout()).list.map((w) => w.id);
  await tool(before[1], 'Move up').click();
  // Leave Home straight away (before the save delay) — this used to lose or later undo the change.
  await page.evaluate(() => (location.hash = '#/inventory'));
  await page.waitForSelector('.topbar h1');
  await settle(800);
  const after = (await serverLayout()).list.map((w) => w.id);
  check(after[0] === before[1] && after[1] === before[0], `saved after leaving (${after.slice(0, 2)})`);
  await page.evaluate(() => (location.hash = '#/'));
  await page.waitForSelector('.dash > section[data-wid]');
  await settle(800);
  check((await uiIds())[0] === before[1], 'coming back shows the new order (not a cached old one)');
  // And a following edit doesn't bring the old order back.
  await edit(true);
  const third = after[2];
  await (await option(third, 'Hide')).click();
  await settle(900);
  const again = (await serverLayout()).list;
  check(again[0].id === before[1], 'next edit keeps the earlier change');
  check(again.find((w) => w.id === third)?.hidden === true, 'hide saved');
});

await step('rapid edits', async () => {
  await edit(true);
  const ids = (await serverLayout()).list.filter((w) => !w.hidden).map((w) => w.id);
  const target = ids[ids.length - 1];
  const moves = Math.min(6, ids.length - 1);
  for (let i = 0; i < moves; i++) await tool(target, 'Move up').click();
  await settle(1500);
  const saved = (await serverLayout()).list.map((w) => w.id);
  const shown = await page.$$eval('.dash > section[data-wid]', (els) => els.map((e) => e.dataset.wid));
  check(JSON.stringify(saved.filter((id) => shown.includes(id))) === JSON.stringify(shown), 'server equals screen after 6 quick moves');
  check(saved.indexOf(target) < ids.indexOf(target), 'the widget moved up');
});

await step('reload', async () => {
  const saved = (await serverLayout()).list.filter((w) => !w.hidden).map((w) => w.id);
  await page.reload();
  await page.waitForSelector('.dash > section[data-wid]');
  await settle();
  check(JSON.stringify(await uiIds()) === JSON.stringify(saved), 'same layout after reload');
});

await step('drag and drop (finger)', async () => {
  await edit(true);
  const ids = await uiIds();
  // Pointer events of type "touch", the way iOS Safari sends a finger drag.
  await page.evaluate(async ([fromId, toId]) => {
    const grip = document.querySelector(`section[data-wid="${fromId}"] .w-grip`);
    const a = grip.getBoundingClientRect();
    const b = document.querySelector(`section[data-wid="${toId}"]`).getBoundingClientRect();
    const ev = (type, x, y) => grip.dispatchEvent(new PointerEvent(type, { pointerId: 9, pointerType: 'touch', isPrimary: true, bubbles: true, cancelable: true, clientX: x, clientY: y }));
    ev('pointerdown', a.x + 10, a.y + 10);
    for (let i = 1; i <= 8; i++) { ev('pointermove', a.x + 10, a.y + 10 + (b.y + 10 - a.y - 10) * (i / 8)); await new Promise((r) => setTimeout(r, 30)); }
    ev('pointerup', a.x + 10, b.y + 10);
  }, [ids[ids.length - 1], ids[0]]);
  await settle(1200);
  const saved = (await serverLayout()).list.filter((w) => !w.hidden).map((w) => w.id);
  check(saved[0] === ids[ids.length - 1], `dragged widget is first (${saved.slice(0, 3)})`);
  check(JSON.stringify(await uiIds()) === JSON.stringify(saved), 'screen matches what was saved');
});

await step('size, compact, pin, unhide, remove, add', async () => {
  await edit(true);
  const ids = await uiIds();
  const w = ids.find((id) => id === 'expiring') ?? ids[1];
  await page.locator(`section[data-wid="${w}"] button:has-text("Options")`).click();
  await page.locator(`section[data-wid="${w}"] .seg.mini button:has-text("Small")`).click().catch(async () => page.locator(`section[data-wid="${w}"] .seg.mini button:has-text("Large")`).click());
  await (await option(w, 'Compact')).click();
  await (await option(w, 'Pin to top')).click();
  await settle(900);
  let s = (await serverLayout()).list.find((x) => x.id === w);
  check(s.view === 'compact', 'compact saved');
  check(s.pinned === true, 'pin saved');
  check(s.size === 's' || s.size === 'l', `size saved (${s.size})`);
  const hidden = (await serverLayout()).list.find((x) => x.hidden);
  if (hidden) {
    await page.locator('.hidden-tray .chip').first().click();
    await settle(900);
    check(!(await serverLayout()).list.find((x) => x.id === hidden.id).hidden, 'unhide saved');
  }
  const victim = ids[ids.length - 1];
  await page.locator(`section[data-wid="${victim}"] .w-remove`).click();
  await settle(900);
  check(!(await serverLayout()).list.some((x) => x.id === victim), 'remove saved');
  await page.locator('.dash-edit button:has-text("Widget")').click();
  await page.locator('[aria-label="Add Estimated money saved"]').click();
  await page.keyboard.press('Escape');
  await settle(900);
  check((await serverLayout()).list[0].type === 'moneySaved', 'added widget saved at the top');
  await edit(false);
  await settle(600);
  check((await uiIds())[0] === w, 'pinned widget shows first outside edit mode');
});

await step('presets, undo, reset', async () => {
  await edit(true);
  const before = (await serverLayout()).list.map((w) => w.id);
  await page.locator('.dash-edit button:has-text("Layouts")').click();
  await page.locator('.preset:has-text("Minimal") button:has-text("Use here")').click();
  await settle(900);
  check(JSON.stringify((await serverLayout()).list.map((w) => w.type)) === JSON.stringify(['tonight', 'shopping']), 'preset saved');
  await page.locator('.dash-edit button:has-text("Undo")').click();
  await settle(900);
  check(JSON.stringify((await serverLayout()).list.map((w) => w.id)) === JSON.stringify(before), 'undo restored and saved');
  await page.locator('.dash-edit button:has-text("Reset")').click();
  await settle(900);
  check((await serverLayout()).list.length === 4, 'reset to the Everyday preset');
});

await step('profiles: new, rename, switch, delete', async () => {
  await edit(true);
  await page.locator('.dash-edit button:has-text("Layouts")').click();
  await page.locator('.preset:has-text("Your journey") button:has-text("As new layout"), .preset:has-text("Progress") button:has-text("As new layout")').first().click();
  await settle(900);
  let s = await serverLayout();
  check(s.profiles.length === 2 && s.list[0].type === 'journey', 'new layout from a preset saved and active');
  const name = page.locator('input[aria-label="Name of this layout"]');
  await name.fill('');
  await name.blur();
  await settle(900);
  s = await serverLayout();
  check(s.profiles.find((p) => p.id === s.active).name.trim().length > 0, 'an empty name is never saved (and saving keeps working)');
  await name.fill('Weekend');
  await name.blur();
  await settle(900);
  s = await serverLayout();
  check(s.profiles.find((p) => p.id === s.active).name === 'Weekend', 'rename saved');
  await edit(false);
  check(await page.locator('.profiles button').count() === 2, 'with two layouts, a switch appears on Home');
  await page.locator('.profiles button:has-text("Home")').click();
  await settle(900);
  check((await serverLayout()).active === 'home', 'switch saved');
  await page.locator('.profiles button:has-text("Weekend")').click();
  await settle(600);
  await edit(true);
  await page.locator('.dash-edit button:has-text("Delete")').click();
  await settle(900);
  s = await serverLayout();
  check(s.profiles.length === 1 && s.active === 'home', 'delete saved');
  await edit(false);
});

await step('two tabs stay in sync', async () => {
  const other = await phone.newPage();
  await other.goto(`${BASE}/#/`);
  await other.waitForSelector('.dash > section[data-wid]');
  await settle(800);
  await edit(true);
  const ids = await uiIds();
  await tool(ids[1], 'Move up').click();
  await settle(2500);
  const there = await other.$$eval('.dash > section[data-wid]', (els) => els.map((e) => e.dataset.wid));
  check(there[0] === ids[1], 'the other tab picked up the change without reloading');
  await other.close();
  await edit(false);
});

await step('tablet keeps its own layout', async () => {
  const tablet = await browser.newContext({ ...devices['iPad (gen 7)'], colorScheme: 'light' });
  const t = await tablet.newPage();
  await t.goto(BASE + '/');
  await t.fill('input[type=email]', 'demo@larder.test');
  await t.fill('input[type=password]', 'larder-demo-2026');
  await t.click('button:has-text("Sign in")');
  await t.waitForSelector('.dash > section[data-wid]');
  await t.waitForTimeout(800);
  check(await t.$eval('.dash', (e) => e.classList.contains('dev-tablet')), 'tablet layout class');
  await t.locator('.dash-customise').click();
  const ids = await t.$$eval('.dash > section[data-wid]', (els) => els.map((e) => e.dataset.wid));
  await t.locator(`section[data-wid="${ids[0]}"] button:has-text("Options")`).click();
  await t.locator(`section[data-wid="${ids[0]}"] [aria-label="Hide"]`).click();
  await t.waitForTimeout(1200);
  const d = await (await t.request.get(BASE + '/api/dashboard')).json();
  const p = d.config.profiles.find((x) => x.id === d.config.active);
  check(p.layouts.tablet?.find((w) => w.id === ids[0])?.hidden === true, 'tablet change saved to the tablet layout');
  check(!p.layouts.phone.find((w) => w.id === ids[0])?.hidden, 'phone layout untouched');
  await t.locator('button:has-text("Follow the phone layout again")').click();
  await t.waitForTimeout(1200);
  const d2 = await (await t.request.get(BASE + '/api/dashboard')).json();
  check(!d2.config.profiles.find((x) => x.id === d2.config.active).layouts.tablet, 'follow phone again removes the tablet copy');
  await tablet.close();
});

await step('suggestions never change the layout by themselves', async () => {
  for (let i = 0; i < 6; i++) await api('POST', '/api/dashboard/usage', { key: 'open:shopping' });
  const before = JSON.stringify((await api('GET', '/api/dashboard')).config);
  await goHome();
  await settle(1200);
  check(JSON.stringify((await api('GET', '/api/dashboard')).config) === before, 'opening Home with suggestions leaves the layout alone');
});

// ---------- Widgets do things ----------
await step('widget actions', async () => {
  await goHome();
  const item = `e2e lemons ${Date.now() % 1000}`;
  const addBox = page.locator('section[data-wid="shopping"] input');
  if (await addBox.count()) {
    await addBox.fill(item);
    await addBox.press('Enter');
    await settle(1200);
    const list = await api('GET', '/api/shopping');
    const found = list.groups.flatMap((g) => g.items).find((i) => /lemon/i.test(i.name));
    check(found, 'add to shopping list from the widget');
    await page.locator(`section[data-wid="shopping"] button[aria-label="Tick off ${found?.name}"]`).click();
    await settle(1200);
    const after = await api('GET', '/api/shopping');
    check(after.checked.some((i) => i.id === found?.id), 'tick off from the widget');
  } else check(false, 'shopping widget present');
});

// ---------- Other features ----------
await step('settings: spending & waste switch', async () => {
  await page.goto(`${BASE}/#/settings/general`);
  await page.waitForSelector('[aria-label="Show spending & waste"]');
  await page.locator('[aria-label="Show spending & waste"]').click();
  await settle(1200);
  check((await api('GET', '/api/settings')).me.appearance.showMoney === false, 'spending & waste switched off');
});

await step('spending & waste optional', async () => {
  await page.goto(`${BASE}/#/insights`);
  await page.waitForSelector('.topbar h1');
  await settle(1200);
  check(!(await page.locator('text=Weekly spending').count()), 'hidden on Statistics when off');
  check(!(await page.locator('.yif, .tile:has-text("wasted")').count()), 'waste tile hidden in Your year in food');
  await page.locator('[aria-label="Show spending & waste"]').click();
  await settle(1200);
  check(await page.locator('text=Weekly spending').count(), 'shown again after switching on');
  check((await api('GET', '/api/preferences/me')).appearance.showMoney === true, 'saved');

});

await step('journey', async () => {
  await page.goto(`${BASE}/#/progress`);
  await page.waitForSelector('.jnode');
  await settle(800);
  check(await page.locator('.jnode.current').count() === 1, 'one current node');
  await page.locator('.jnode.current').click();
  await page.waitForSelector('.sheet');
  check(await page.locator('.sheet a.btn.primary').count(), 'node sheet has a do-it button');
  await page.keyboard.press('Escape');
  for (const tab of ['Rewards', 'Stats']) {
    await page.locator(`.progress-tabs button:has-text("${tab}")`).click();
    await settle(400);
  }
  check(await page.locator('text=Recently cooked').count(), 'habits tab renders');
  await page.locator('.progress-tabs button:has-text("Path")').click();
});

await step('assistant, plan, recipes, inventory', async () => {
  await page.goto(`${BASE}/#/`);
  await page.waitForSelector('.fab');
  await page.tap('.fab');
  await page.waitForSelector('.assistant input');
  await page.fill('.assistant input', 'add coffee to my shopping list');
  await page.press('.assistant input', 'Enter');
  await page.waitForSelector('.bubble.bot >> text=/list/i', { timeout: 8000 }).then(() => check(true, 'assistant answers')).catch(() => check(false, 'assistant answers'));
  await page.tap('[aria-label=Close]');
  for (const [hash, sel] of [['#/plan', '.week, .plan-tabs'], ['#/discover', '.topbar h1'], ['#/inventory', '.topbar h1'], ['#/shopping', '.topbar h1'], ['#/settings', '.set-account']]) {
    await page.goto(`${BASE}/${hash}`);
    check(await page.waitForSelector(sel, { timeout: 8000 }).then(() => true).catch(() => false), `${hash} renders`);
  }
});

await browser.close();
const failed = results.filter((r) => !r.ok);
for (const r of results) console.log(`${r.ok ? 'ok  ' : 'FAIL'} ${r.what}`);
if (errors.length) console.log('\nPage errors:\n' + [...new Set(errors)].join('\n'));
console.log(`\n${results.length - failed.length}/${results.length} passed`);
process.exit(failed.length ? 1 : 0);
