// Put the throwaway account back to defaults before a persistence run.
const BASE = 'http://localhost:8799';
let cookie = '';
const api = async (m, p, b) => { const r = await fetch(BASE + p, { method: m, headers: { 'content-type': 'application/json', cookie }, body: b ? JSON.stringify(b) : undefined }); const s = r.headers.get('set-cookie'); if (s) cookie = s.split(';')[0]; return r.status; };
await api('POST', '/api/auth/login', { email: 'demo@larder.test', password: 'larder-demo-2026' });
console.log(await api('PATCH', '/api/settings', {
  me: { language: 'auto', startPage: 'home', appearance: { style: 'larder', theme: 'system', density: 'comfortable', cards: 'soft', motion: 'full', textSize: 'normal', showMoney: true } },
  household: { householdSize: 2, cuisines: [], planDays: [0, 1, 2, 3, 4, 5, 6], maxWeeknightMinutes: 45, autoPlanFifo: 'balanced', variety: 'normal', nutritionPriorities: [], nutritionTargets: { fibre: 30 }, xpRules: { cooked: 10 }, notifications: { frequency: 'all' }, cookCheckin: { time: '20:00' }, interaction: { confirmDestructive: false, cookHandsFree: false, cookReadAloud: false, keepAwake: true } },
}));
const dietary = await fetch(BASE + '/api/dietary', { headers: { cookie } }).then((r) => r.json());
const people = dietary.people.map((p, i) => (i === 0 ? { ...p, diets: [], kcal: null, protein: null } : p));
console.log(await api('PUT', '/api/dietary', { people }));
