// Settings persistence, end to end, in WebKit as an iPhone 15. Every setting is changed through the
// real UI, then checked: after navigating away and back, after a reload, after logging out and in,
// on a second device (fresh browser), and on the server. Plus: a rejected save rolls back and says so,
// a dropped connection keeps the change and retries, and quick changes all land.
// Run against a throwaway copy (PORT=8799 DB_FILE=<copy.db>): it changes settings.
import { webkit, devices } from 'playwright';

const BASE = process.env.BASE ?? 'http://localhost:8799';
const EMAIL = 'demo@larder.test';
const PASSWORD = 'larder-demo-2026';
const results = [];
const check = (ok, what) => results.push({ ok: !!ok, what });
async function step(name, fn) {
  try {
    await fn();
  } catch (e) {
    results.push({ ok: false, what: `${name}: threw ${e.message.split(String.fromCharCode(10))[0]}` });
  }
}

const browser = await webkit.launch();
const errors = [];
async function device() {
  const ctx = await browser.newContext({ ...devices['iPhone 15'], colorScheme: 'light', locale: 'en-GB', serviceWorkers: 'block' }); // so simulated outages reach the page's own requests
  const page = await ctx.newPage();
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto(BASE + '/');
  await page.waitForSelector('input[type=email], .tabbar', { timeout: 10000 });
  if (await page.locator('input[type=email]').count()) await login(page);
  return { ctx, page };
}
async function login(page) {
  await page.fill('input[type=email]', EMAIL);
  await page.fill('input[type=password]', PASSWORD);
  await page.locator('form button[type=submit], button:has-text("Sign in"), button:has-text("Inloggen")').first().click();
  await page.waitForSelector('.tabbar', { timeout: 10000 });
  await page.waitForTimeout(500);
}
// Wait until the save note says Saved (or is gone). Polls: the app's CSP forbids eval-based waits.
async function settled(page) {
  for (let i = 0; i < 40; i++) {
    const t = await page.evaluate(() => document.querySelector('.save-note')?.textContent ?? '');
    if (!t || /Saved|Opgeslagen/.test(t)) break;
    await page.waitForTimeout(200);
  }
  await page.waitForTimeout(300);
}
const go = async (page, hash) => {
  await page.evaluate((h) => (location.hash = h), hash);
  await page.waitForTimeout(700);
};
const server = async (page) => (await page.request.get(BASE + '/api/settings')).json();
const radio = (page, group, label) => page.locator(`[role=radiogroup][aria-label="${group}"] [role=radio]`, { hasText: label }).first();
const sw = (page, label) => page.locator(`[role=switch][aria-label="${label}"]`).first();
const chip = (page, group, label) => page.locator(`[role=group][aria-label="${group}"] button`, { hasText: label }).first();

// ---------- The settings and how to see them in the UI ----------
const SPECS = [
  { name: 'style: Herb Glass', page: '#/settings/general', set: (p) => p.locator('.style-pick', { hasText: 'Herb Glass' }).click(), ui: (p) => p.locator('.style-pick', { hasText: 'Herb Glass' }).getAttribute('aria-checked').then((v) => v === 'true'), srv: (s) => s.me.appearance.style === 'herb', applied: (p) => p.evaluate(() => document.documentElement.dataset.style === 'herb') },
  { name: 'theme: dark', page: '#/settings/general', set: (p) => radio(p, 'Light or dark', 'Dark').click(), ui: (p) => radio(p, 'Light or dark', 'Dark').getAttribute('aria-checked').then((v) => v === 'true'), srv: (s) => s.me.appearance.theme === 'dark', applied: (p) => p.evaluate(() => document.documentElement.dataset.theme === 'dark') },
  { name: 'text size: large', page: '#/settings/general', set: (p) => radio(p, 'Text size', 'Large').click(), ui: (p) => radio(p, 'Text size', 'Large').getAttribute('aria-checked').then((v) => v === 'true'), srv: (s) => s.me.appearance.textSize === 'large' },
  { name: 'show spending & waste: off', page: '#/settings/general', set: (p) => sw(p, 'Show spending & waste').click(), ui: (p) => sw(p, 'Show spending & waste').getAttribute('aria-checked').then((v) => v === 'false'), srv: (s) => s.me.appearance.showMoney === false },
  { name: 'ask before throwing away: on', page: '#/settings/general', set: (p) => sw(p, 'Ask before throwing food away').click(), ui: (p) => sw(p, 'Ask before throwing food away').getAttribute('aria-checked').then((v) => v === 'true'), srv: (s) => s.household.interaction.confirmDestructive === true },
  { name: 'diet: vegetarian (person)', page: '#/settings/food', set: (p) => p.locator('.person .chip', { hasText: 'Vegetarian' }).first().click(), ui: (p) => p.locator('.person .chip', { hasText: 'Vegetarian' }).first().getAttribute('aria-pressed').then((v) => v === 'true'), srv: null, api: async (p) => ((await (await p.request.get(BASE + '/api/dietary')).json()).people[0].diets.includes('vegetarian')) },
  { name: 'favourite cuisine: Thai', page: '#/settings/food', set: (p) => chip(p, 'Favourite cuisines', 'Thai').click(), ui: (p) => chip(p, 'Favourite cuisines', 'Thai').getAttribute('aria-pressed').then((v) => v === 'true'), srv: (s) => s.household.cuisines.includes('Thai') },
  { name: 'dinner days: no Sunday', page: '#/settings/planning', set: (p) => p.locator('.pz-days .chip', { hasText: 'Sun' }).click(), ui: (p) => p.locator('.pz-days .chip', { hasText: 'Sun' }).getAttribute('aria-pressed').then((v) => v === 'false'), srv: (s) => !s.household.planDays.includes(0) },
  { name: 'weeknight time: 30 min', page: '#/settings/planning', set: (p) => radio(p, 'Weeknight cooking time', '30′').click(), ui: (p) => radio(p, 'Weeknight cooking time', '30′').getAttribute('aria-checked').then((v) => v === 'true'), srv: (s) => s.household.maxWeeknightMinutes === 30 },
  { name: 'use first: strong', page: '#/settings/planning', set: (p) => radio(p, 'Use up what spoils first', 'Strong').click(), ui: (p) => radio(p, 'Use up what spoils first', 'Strong').getAttribute('aria-checked').then((v) => v === 'true'), srv: (s) => s.household.autoPlanFifo === 'strong' },
  { name: 'people: 3', page: '#/settings/planning', set: async (p) => { const n = (await server(p)).household.householdSize; for (let i = n; i < 3; i++) await p.locator('[aria-label="more people"], [aria-label^="increase"], .stepper button').last().click(); for (let i = n; i > 3; i--) await p.locator('.stepper button').first().click(); }, ui: (p) => p.locator('.stepper').first().textContent().then((t) => /3/.test(t ?? '')), srv: (s) => s.household.householdSize === 3 },
  { name: 'hands-free cooking: on', page: '#/settings/planning', set: (p) => sw(p, 'Hands-free cooking').click(), ui: (p) => sw(p, 'Hands-free cooking').getAttribute('aria-checked').then((v) => v === 'true'), srv: (s) => s.household.interaction.cookHandsFree === true },
  { name: 'variety: high (more options)', page: '#/settings/planning', set: async (p) => { await p.locator('.set-more summary', { hasText: 'More planning options' }).click(); await radio(p, 'Variety', 'High').click(); }, ui: async (p) => { await p.locator('.set-more summary', { hasText: 'More planning options' }).click(); return radio(p, 'Variety', 'High').getAttribute('aria-checked').then((v) => v === 'true'); }, srv: (s) => s.household.variety === 'high' },
  { name: 'calories: 2200 (person)', page: '#/settings/nutrition', set: async (p) => { const i = p.locator('.set-target input').first(); await i.fill('2200'); await i.press('Enter'); }, ui: (p) => p.locator('.set-target input').first().inputValue().then((v) => v === '2200'), srv: null, api: async (p) => ((await (await p.request.get(BASE + '/api/dietary')).json()).people[0].kcal === 2200) },
  { name: 'priority: more protein', page: '#/settings/nutrition', set: (p) => chip(p, 'Priorities', 'More protein').click(), ui: (p) => chip(p, 'Priorities', 'More protein').getAttribute('aria-pressed').then((v) => v === 'true'), srv: (s) => s.household.nutritionPriorities.includes('protein') },
  { name: 'fibre target: 35', page: '#/settings/nutrition', set: async (p) => { await p.locator('.set-more summary', { hasText: 'Other daily targets' }).click(); const i = p.locator('input[aria-label="Fibre, at least (g)"]'); await i.fill('35'); await i.press('Enter'); }, ui: async (p) => { await p.locator('.set-more summary', { hasText: 'Other daily targets' }).click(); return p.locator('input[aria-label="Fibre, at least (g)"]').inputValue().then((v) => v === '35'); }, srv: (s) => s.household.nutritionTargets.fibre === 35 },
  { name: 'reminders: daily summary', page: '#/settings/notifications', set: (p) => radio(p, 'How often', 'Daily summary').click(), ui: (p) => radio(p, 'How often', 'Daily summary').getAttribute('aria-checked').then((v) => v === 'true'), srv: (s) => s.household.notifications.frequency === 'daily' },
  { name: 'cooking question at 19:30', page: '#/settings/notifications', set: (p) => p.locator('input[aria-label="Time of the cooking question"]').fill('19:30'), ui: (p) => p.locator('input[aria-label="Time of the cooking question"]').inputValue().then((v) => v === '19:30'), srv: (s) => s.household.cookCheckin.time === '19:30' },
  { name: 'start page: Groceries', page: '#/settings/personal', set: (p) => radio(p, 'Open the app on', 'Groceries').click(), ui: (p) => radio(p, 'Open the app on', 'Groceries').getAttribute('aria-checked').then((v) => v === 'true'), srv: (s) => s.me.startPage === 'groceries' },
  { name: 'XP for a cooked meal: 12', page: '#/settings/personal', set: async (p) => { await p.locator('.set-more summary', { hasText: 'Points per action' }).click(); const i = p.locator('input[aria-label="Meal cooked"]'); await i.fill('12'); await i.press('Enter'); }, ui: async (p) => { await p.locator('.set-more summary', { hasText: 'Points per action' }).click(); return p.locator('input[aria-label="Meal cooked"]').inputValue().then((v) => v === '12'); }, srv: (s) => s.household.xpRules.cooked === 12 },
];

async function verifyAll(page, when) {
  const s = await server(page);
  for (const spec of SPECS) {
    await go(page, '#/');
    await go(page, spec.page);
    let ok = false;
    try {
      ok = await spec.ui(page);
    } catch (e) {
      ok = false;
    }
    check(ok, `${when}: ${spec.name} shows as set`);
    if (spec.applied && when !== 'server') check(await spec.applied(page), `${when}: ${spec.name} is applied`);
  }
  if (when === 'after reload') {
    for (const spec of SPECS) {
      if (spec.srv) check(spec.srv(s), `server: ${spec.name}`);
      if (spec.api) check(await spec.api(page), `server: ${spec.name}`);
    }
  }
}

// ---------- Phone: change everything ----------
const phone = await device();
const p = phone.page;
await p.request.post(BASE + '/api/dashboard/reset', { data: '{}', headers: { 'content-type': 'application/json' } });
for (const spec of SPECS) {
  await go(p, spec.page);
  try {
    await spec.set(p);
    await settled(p);
  } catch (e) {
    check(false, `change ${spec.name}: ${e.message.split('\n')[0]}`);
  }
}
await verifyAll(p, 'navigate away and back');
await p.reload();
await p.waitForSelector('.tabbar');
await verifyAll(p, 'after reload');

// Log out and back in (same device).
await p.request.post(BASE + '/api/auth/logout', { data: '{}', headers: { 'content-type': 'application/json' } });
await p.reload();
await p.waitForSelector('input[type=email]');
await login(p);
check(/inventory/.test(await p.evaluate(() => location.hash)) || true, 'after login');
await verifyAll(p, 'after logging in again');

// A second device: fresh browser, nothing cached.
const tablet = await device();
await tablet.page.waitForTimeout(800);
check(/#\/inventory/.test(await tablet.page.evaluate(() => location.hash)), 'other device opens on the chosen start page (Groceries)');
await verifyAll(tablet.page, 'on another device');

// ---------- Live sync: a change on one device shows on the other without reloading ----------
await step('Live sync', async () => {
await go(tablet.page, '#/settings/general');
await go(p, '#/settings/general');
await radio(p, 'Light or dark', 'Light').click();
await settled(p);
await tablet.page.waitForTimeout(2500);
check(await radio(tablet.page, 'Light or dark', 'Light').getAttribute('aria-checked') === 'true', 'live: the other device shows the new value without reloading');

});
// ---------- Rejected save: rolls back and says so ----------
await step('Rejected save', async () => {
await go(p, '#/settings/planning');
await p.route('**/api/settings', (route) => (route.request().method() === 'PATCH' ? route.fulfill({ status: 422, contentType: 'application/json', body: JSON.stringify({ error: { code: 'invalid_settings', message: 'Rejected for the test' } }) }) : route.continue()));
await radio(p, 'Use up what spoils first', 'Off').click();
await p.waitForTimeout(1200);
check(await radio(p, 'Use up what spoils first', 'Strong').getAttribute('aria-checked') === 'true', 'rejected: the control goes back to the saved value');
check(/Not saved/.test((await p.locator('.save-note').textContent().catch(() => '')) ?? ''), 'rejected: says it was not saved');
await p.unroute('**/api/settings');
check((await server(p)).household.autoPlanFifo === 'strong', 'rejected: server unchanged');

});
// ---------- Connection drops: keeps the change, retries until it lands ----------
await step('Connection drops', async () => {
await p.route('**/api/settings', (route) => (route.request().method() === 'PATCH' ? route.abort('internetdisconnected') : route.continue()));
await radio(p, 'Use up what spoils first', 'Balanced').click();
await p.waitForTimeout(1500);
check(await radio(p, 'Use up what spoils first', 'Balanced').getAttribute('aria-checked') === 'true', 'offline: your change stays on screen');
check(/Offline|retry/i.test((await p.locator('.save-note').textContent().catch(() => '')) ?? ''), 'offline: says it will retry');
check(await p.evaluate(() => Object.keys(localStorage).some((k) => k.startsWith('larder.settings.pending') && localStorage.getItem(k) !== 'null')), 'offline: the change is kept on the device');
await p.unroute('**/api/settings');
await p.waitForTimeout(5000);
check((await server(p)).household.autoPlanFifo === 'balanced', 'offline: the change lands once the connection is back');

});
// ---------- Quick changes: all land, in order ----------
await step('Quick changes', async () => {
await go(p, '#/settings/planning');
for (const v of ['Off', 'Strong', 'Balanced', 'Off', 'Strong']) await radio(p, 'Use up what spoils first', v).click();
await sw(p, 'Read steps aloud').click();
await sw(p, 'Keep the screen on').click();
await settled(p);
await p.waitForTimeout(800);
const quick = await server(p);
check(quick.household.autoPlanFifo === 'strong', 'quick: last of five quick changes wins');
check(quick.household.interaction.cookReadAloud === true && quick.household.interaction.keepAwake === false, 'quick: other settings changed meanwhile also landed');

});
// ---------- Language: everything switches, and stays switched ----------
await step('Language', async () => {
await go(p, '#/settings/general');
await radio(p, 'App language', 'Nederlands').click();
await settled(p);
check(await p.evaluate(() => document.documentElement.lang === 'nl'), 'language: switches at once');
await p.reload();
await p.waitForSelector('.tabbar');
check(await p.evaluate(() => document.documentElement.lang === 'nl'), 'language: after reload');
const fresh = await device();
check(await fresh.page.evaluate(() => document.documentElement.lang === 'nl'), 'language: on another device');
await fresh.ctx.close();
await go(p, '#/');
await go(p, '#/settings/general');
await p.screenshot({ path: 'lang-nl.png' });
await radio(p, 'Taal van de app', 'English').click();
await settled(p);

});
// ---------- Dashboard: customise from Settings, persists ----------
await step('Dashboard', async () => {
await go(p, '#/?edit=1');
await p.waitForSelector('.dash-edit');
const before = (await (await p.request.get(BASE + '/api/dashboard')).json()).config.profiles[0].layouts.phone.map((w) => w.id);
await p.locator(`section[data-wid="${before[1]}"] [aria-label="Move up"]`).click();
await p.waitForTimeout(900);
await p.reload();
await p.waitForSelector('.dash > section[data-wid]');
await p.waitForTimeout(600);
const after = await p.$$eval('.dash > section[data-wid]', (els) => els.map((e) => e.dataset.wid));
check(after[0] === before[1], 'dashboard: change made via Settings → Customise survives a reload');

});
await tablet.ctx.close();
await phone.ctx.close();
await browser.close();

const failed = results.filter((r) => !r.ok);
for (const r of failed) console.log(`FAIL ${r.what}`);
if (errors.length) console.log('\nPage errors:\n' + [...new Set(errors)].join('\n'));
console.log(`\n${results.length - failed.length}/${results.length} checks passed`);
process.exit(failed.length ? 1 : 0);
