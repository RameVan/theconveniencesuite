// Every product Open Food Facts lists as sold in the Netherlands, from its full daily export (ODbL).
// Open Food Facts asks apps that need many products to use the export instead of the API.
// 1. Download the CSV export (~1.5 GB, gzip) into data/imports/off-dump/, unless it's already there;
// 2. stream it and keep the Dutch rows, with only the fields PantryPip uses, as nl.ndjson (~1 line per product).
// `npm run import:catalogue` turns nl.ndjson into the product catalogue.
//
//   npm run fetch:off-dump            (download only if missing)
//   npm run fetch:off-dump -- --force (download again, for a newer export)
import { createReadStream, createWriteStream, existsSync, mkdirSync, renameSync, statSync } from 'node:fs';
import { createGunzip } from 'node:zlib';
import { createInterface } from 'node:readline';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import path from 'node:path';
import { config } from '../src/config.ts';

const EXPORT = 'https://static.openfoodfacts.org/data/en.openfoodfacts.org.products.csv.gz';
const dir = path.join(path.dirname(config.dbFile), 'imports', 'off-dump');
const gz = path.join(dir, 'products.csv.gz');
const out = path.join(dir, 'nl.ndjson');
mkdirSync(dir, { recursive: true });

if (!existsSync(gz) || process.argv.includes('--force')) {
  console.log(`downloading ${EXPORT}`);
  const res = await fetch(EXPORT, { headers: { 'user-agent': 'PantryPip/1.0 (personal kitchen app)' } });
  if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);
  await pipeline(Readable.fromWeb(res.body as any), createWriteStream(gz + '.part'));
  renameSync(gz + '.part', gz);
}
console.log(`reading ${gz} (${Math.round(statSync(gz).size / 1e6)} MB)`);

const num = (s: string) => (s === '' ? undefined : Number(s));
const tags = (s: string) => (s ? s.split(',').filter(Boolean) : []);
const lines = createInterface({ input: createReadStream(gz).pipe(createGunzip()), crlfDelay: Infinity });
const sink = createWriteStream(out + '.part');
let col: Record<string, number> = {};
let rows = 0;
let kept = 0;
for await (const line of lines) {
  if (!rows++) {
    col = Object.fromEntries(line.split('\t').map((name, i) => [name, i]));
    continue;
  }
  // Cheap test before splitting 200 columns.
  if (!line.includes('en:netherlands')) continue;
  const f = line.split('\t');
  const v = (name: string) => f[col[name]] ?? '';
  if (!tags(v('countries_tags')).includes('en:netherlands')) continue;
  const p = {
    code: v('code'), name: v('product_name'), generic: v('generic_name') || undefined, brands: v('brands') || undefined,
    quantity: v('quantity') || undefined, product_quantity: num(v('product_quantity')),
    categories: tags(v('categories_tags')), labels: tags(v('labels_tags')), stores: v('stores') || undefined,
    allergens: tags(v('allergens')), analysis: tags(v('ingredients_analysis_tags')),
    image: v('image_small_url') || undefined, scans: num(v('unique_scans_n')), modified: num(v('last_modified_t')),
    n: {
      kcal: num(v('energy-kcal_100g')), protein: num(v('proteins_100g')), carbs: num(v('carbohydrates_100g')), fat: num(v('fat_100g')),
      sugars: num(v('sugars_100g')), satFat: num(v('saturated-fat_100g')), fibre: num(v('fiber_100g')), salt: num(v('salt_100g')),
    },
  };
  if (!sink.write(JSON.stringify(p) + '\n')) await new Promise((r) => sink.once('drain', r));
  if (++kept % 20000 === 0) console.log(`${kept} Dutch products of ${rows} read`);
}
await new Promise((r) => sink.end(r));
renameSync(out + '.part', out);
console.log(`done: ${kept} Dutch products of ${rows - 1} → ${out}`);
