// The Dutch product catalogue from the Open Food Facts export (npm run fetch:off-dump). Backs up the database
// first. Safe to run again: the Open Food Facts rows of catalogue and retail_products are rewritten.
//   npm run import:catalogue
import path from 'node:path';
import { config } from '../src/config.ts';
import { Db } from '../src/db/db.ts';
import { seedCatalogue } from '../src/db/seed.ts';
import { importCatalogue } from '../src/import/catalogue.ts';

const db = new Db(config.dbFile);
db.migrate();
seedCatalogue(db);
const backup = path.join(config.backupDir, `before-catalogue-import-${new Date().toISOString().replace(/[:.]/g, '-')}.db`);
db.backupTo(backup);
console.log(`Backup: ${backup}`);
// The export lives with the project's data (also when DB_FILE points at a test copy).
const file = process.argv.includes('--file') ? process.argv[process.argv.indexOf('--file') + 1] : path.resolve(import.meta.dirname, '..', '..', 'data', 'imports', 'off-dump', 'nl.ndjson');
const started = Date.now();
const r = await importCatalogue(db, file);
// Pack sizes seen in Dutch listings join each product's packaging options.
seedCatalogue(db);
console.log(`Read ${r.read} Dutch products; kept ${r.kept} (${r.skipped} without a name, barcode or any brand/size/photo); ${r.withImage} with a photo.`);
console.log(`Linked to an ingredient: ${r.linked} (${r.rejected} more dropped because their categories disagree); ${r.ingredients} ingredients have products.`);
console.log(`Search shows ${r.groups} products (the same product's entries as one); ${r.unlisted} entries not shown.`);
console.log(`Where to buy: ${r.retail} rows; at a chain: ${Object.entries(r.byChain).sort((a, b) => b[1] - a[1]).map(([c, n]) => `${c} ${n}`).join(', ')}`);
console.log(`${((Date.now() - started) / 1000).toFixed(0)} s`);
db.close();
