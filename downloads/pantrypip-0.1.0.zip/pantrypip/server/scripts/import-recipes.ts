// Import large recipe collections you downloaded into the shared library (see docs/RECIPE-IMPORT.md).
//
//   npm run import:recipes -- --wikibooks ../data/imports/recipes_parsed.json
//   npm run import:recipes -- --recipenlg ../data/imports/full_dataset.csv --limit 15000
//   npm run import:recipes -- --recipenlg <file> --dry-run      (report only, changes nothing)
//   npm run import:recipes -- --remove recipenlg                 (take a source out again)
//   npm run import:recipes -- --wikibooks <file> --refresh       (match this source again with today's rules)
//
// A backup of the database is made first. The running server picks the new recipes up by itself.
import path from 'node:path';
import { existsSync } from 'node:fs';
import { config } from '../src/config.ts';
import { Db } from '../src/db/db.ts';
import { seedCatalogue } from '../src/db/seed.ts';
import { importRecipes, recipeNlg, wikibooks, removeImported, type SourceId } from '../src/import/bulk-recipes.ts';

const args = process.argv.slice(2);
const opt = (k: string) => {
  const i = args.indexOf(`--${k}`);
  return i >= 0 ? args[i + 1] : undefined;
};
const flag = (k: string) => args.includes(`--${k}`);
const log = (s: string) => console.log(`  ${s}`);

const db = new Db(config.dbFile);
db.migrate();
seedCatalogue(db);

const remove = opt('remove') as SourceId | undefined;
if (remove) {
  if (remove !== 'recipenlg' && remove !== 'wikibooks') throw new Error('--remove takes recipenlg or wikibooks');
  const r = removeImported(db, remove);
  console.log(`Removed ${r.removed} ${remove} recipes; kept ${r.kept} you cooked, planned or saved.`);
  process.exit(0);
}

const dryRun = flag('dry-run');
if (!dryRun) {
  const backup = path.join(config.backupDir, `before-recipe-import-${new Date().toISOString().replace(/[:.]/g, '-')}.db`);
  db.backupTo(backup);
  console.log(`Backup: ${backup}`);
}

for (const [source, file, defaultLimit] of [['wikibooks', opt('wikibooks'), 4000], ['recipenlg', opt('recipenlg'), 15000]] as const) {
  if (!file) continue;
  if (!existsSync(file)) throw new Error(`File not found: ${file}`);
  const limit = Number(opt('limit') ?? defaultLimit);
  console.log(`${dryRun ? 'Checking' : 'Importing'} ${source} from ${file} (up to ${limit.toLocaleString('en')} recipes)…`);
  const started = Date.now();
  const rows = source === 'wikibooks' ? wikibooks(file) : recipeNlg(file);
  const r = await importRecipes(db, rows, { limit, dryRun, log, refresh: flag('refresh') ? source : undefined });
  console.log(`  read ${r.read.toLocaleString('en')}, ingredient names OK ${r.passedNames.toLocaleString('en')}, met the bar ${r.passed.toLocaleString('en')}, duplicates ${r.duplicates.toLocaleString('en')}`);
  if (r.refreshed || r.removed) console.log(`  re-matched ${r.refreshed.toLocaleString('en')} existing, took out ${r.removed} that no longer pass`);
  console.log(`  dish type corrected ${r.reclassified}, lines using a substitution ${r.substituted}, unresolved lines kept for review ${r.unresolvedLines}`);
  console.log(`  ${dryRun ? 'would add' : 'added'} ${r.imported.toLocaleString('en')}${r.rejectedNutrition ? ` (left out ${r.rejectedNutrition} with implausible nutrition)` : ''} in ${Math.round((Date.now() - started) / 1000)} s`);
  console.log(`  by type: ${Object.entries(r.byTag).sort((a, b) => b[1] - a[1]).map(([t, n]) => `${t} ${n}`).join(', ') || '—'}`);
  console.log(`  e.g. ${r.examples.slice(0, 8).join(' · ')}`);
}
db.close();
