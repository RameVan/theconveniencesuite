// Create a local certificate authority and an HTTPS certificate for this computer, so an iPhone on the
// same network can use Larder over HTTPS (camera, microphone, notifications). Uses the openssl CLI.
//   npm run cert            create (keeps an existing CA, renews the server certificate)
// iOS rules: server certificate valid ≤ 825 days, with subjectAltName and extendedKeyUsage serverAuth.
import { execFileSync } from 'node:child_process';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const dir = path.join(root, 'data', 'certs');
mkdirSync(dir, { recursive: true });
const f = (name: string) => path.join(dir, name);

function findOpenssl(): string {
  const candidates = ['openssl', 'C:\\Program Files\\Git\\usr\\bin\\openssl.exe', 'C:\\Program Files\\Git\\mingw64\\bin\\openssl.exe', '/usr/bin/openssl'];
  for (const c of candidates) {
    try {
      execFileSync(c, ['version'], { stdio: 'ignore' });
      return c;
    } catch {
      /* try the next one */
    }
  }
  console.error('openssl not found. Install Git for Windows (includes openssl) or OpenSSL, then run this again.');
  process.exit(1);
}
const openssl = findOpenssl();
const run = (...args: string[]) => execFileSync(openssl, args, { stdio: ['ignore', 'ignore', 'inherit'] });

// Every IPv4 address of this machine (home network, Tailscale) plus its names.
const ips = Object.values(os.networkInterfaces()).flat().filter((a) => a && a.family === 'IPv4').map((a) => a!.address);
const host = os.hostname().toLowerCase();
const names = [...new Set(['localhost', host, `${host}.local`, ...(process.env.CERT_NAMES ?? '').split(',').map((s) => s.trim()).filter(Boolean)])];
const san = [...names.map((n) => `DNS:${n}`), ...[...new Set(['127.0.0.1', ...ips])].map((ip) => `IP:${ip}`)].join(',');

if (!existsSync(f('larder-ca.key'))) {
  console.log('Creating the Larder local certificate authority (kept for future renewals)…');
  run('genrsa', '-out', f('larder-ca.key'), '2048');
  writeFileSync(f('ca.ext'), 'basicConstraints=critical,CA:TRUE\nkeyUsage=critical,keyCertSign,cRLSign\nsubjectKeyIdentifier=hash\n');
  run('req', '-x509', '-new', '-sha256', '-days', '3650', '-key', f('larder-ca.key'), '-subj', `/CN=Larder local CA (${host})/O=Larder`, '-out', f('larder-ca.crt'),
    '-addext', 'basicConstraints=critical,CA:TRUE', '-addext', 'keyUsage=critical,keyCertSign,cRLSign');
}

console.log('Creating the HTTPS certificate for:', san.replaceAll('DNS:', '').replaceAll('IP:', ''));
run('genrsa', '-out', f('server.key'), '2048');
run('req', '-new', '-key', f('server.key'), '-subj', `/CN=${host}/O=Larder`, '-out', f('server.csr'));
writeFileSync(f('server.ext'), `basicConstraints=CA:FALSE\nkeyUsage=critical,digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth\nsubjectAltName=${san}\n`);
run('x509', '-req', '-sha256', '-days', '820', '-in', f('server.csr'), '-CA', f('larder-ca.crt'), '-CAkey', f('larder-ca.key'), '-CAcreateserial', '-out', f('server.crt'), '-extfile', f('server.ext'));

const lan = ips.filter((ip) => /^(192\.168|10\.|172\.(1[6-9]|2\d|3[01]))/.test(ip));
console.log(`
Done. Certificates are in data/certs (keep larder-ca.key private).

Next:
  1. Start Larder with HTTPS:   npm run start:https
  2. On your iPhone (same Wi-Fi), open in Safari:
${(lan.length ? lan : ips).map((ip) => `       http://${ip}:8787/setup`).join('\n')}
     and follow the three steps there (install + trust the certificate, then open Larder).
`);
