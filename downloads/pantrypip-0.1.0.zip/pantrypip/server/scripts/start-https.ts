// `npm run start:https`: start PantryPip with HTTPS on (works the same on Windows, macOS and Linux).
process.env.HTTPS = '1';
const { main } = await import('../src/index.ts');
main();
