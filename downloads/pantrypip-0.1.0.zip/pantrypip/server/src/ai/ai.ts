// Optional Claude integration (server-side only; the key never reaches the browser).
// Every AI output is a *proposal* in a validated schema. The engine and the receipt review
// screen turn proposals into ledger events, so AI can never write inventory directly.
import Anthropic from '@anthropic-ai/sdk';
import { betaZodOutputFormat } from '@anthropic-ai/sdk/helpers/beta/zod';
import * as z from 'zod/v4';
import { config } from '../config.ts';
import { log } from '../log.ts';
import type { Intent, ItemSpec, Lang } from '../assistant/parser.ts';
import type { ParsedReceipt } from '../domain/receipts.ts';
import { parseSize } from '../domain/receipts.ts';

let client: Anthropic | null = null;
function getClient() {
  client ??= new Anthropic({ apiKey: config.anthropicKey, maxRetries: 2, timeout: 60_000 });
  return client;
}

// Server-side fallback: if the primary model declines, the API retries on a fallback model in the same call.
const FALLBACK = { betas: ['server-side-fallback-2026-07-01'], fallbacks: 'default' as const };

async function structured<T extends z.ZodType>(schema: T, opts: { system: string; content: Anthropic.Beta.BetaContentBlockParam[]; effort: 'low' | 'medium' | 'high'; maxTokens?: number }): Promise<z.infer<T>> {
  const started = Date.now();
  const res = await getClient().beta.messages.parse({
    model: config.aiModel,
    max_tokens: opts.maxTokens ?? 16000,
    system: opts.system,
    messages: [{ role: 'user', content: opts.content }],
    output_config: { effort: opts.effort, format: betaZodOutputFormat(schema) },
    ...FALLBACK,
  });
  log.info('ai call', { model: res.model, ms: Date.now() - started, in: res.usage.input_tokens, out: res.usage.output_tokens, stop: res.stop_reason });
  if (res.stop_reason === 'refusal') throw new Error('The AI declined this request');
  if (res.stop_reason === 'max_tokens') throw new Error('The AI response was cut off');
  if (!res.parsed_output) throw new Error('The AI returned an invalid response');
  return res.parsed_output as z.infer<T>;
}

// ---------- Commands ----------

const ItemZ = z.object({
  name: z.string().describe('Product name as the user said it, singular where natural'),
  amount: z.number().nullable().describe('Numeric amount if the user stated one, else null. Never guess.'),
  unit: z.string().nullable().describe('Unit word: g, kg, ml, l, piece, slice, pack, bottle, portion, ... or null'),
  all: z.boolean().describe('True if the user means everything that is left ("finished", "the rest")'),
  location: z.enum(['fridge', 'freezer', 'pantry']).nullable(),
});

const CommandZ = z.object({
  reply: z.string().describe('Short spoken reply in the user language. For questions, the answer. For actions, leave empty: the app confirms.'),
  intents: z.array(
    z.object({
      type: z.enum(['add_inventory', 'consume', 'discard', 'set_quantity', 'shopping_add', 'shopping_remove', 'freeze', 'thaw', 'cooked', 'query_item', 'query_inventory', 'query_low', 'query_buy', 'query_expiring', 'query_cook', 'none']),
      items: z.array(ItemZ),
      reason: z.string().nullable().describe('For discard: spoiled | expired | mouldy | other'),
      dish: z.string().nullable(),
      servings: z.number().nullable(),
    }),
  ),
});

const COMMAND_SYSTEM = `You interpret short spoken commands for a household grocery app (English or Dutch).
Map the utterance to intents. Rules:
- add_inventory: the user bought/has something new. shopping_add: they want to buy it. consume: used/ate/drank. discard: threw away/went bad. set_quantity: states how much is left.
- Never invent amounts. If no amount was said, amount = null.
- Use the inventory list to resolve what "it", "the rest", "those" refer to, and prefer names that exist there.
- If the request is a question you can answer from the provided data, use intents "none" and answer briefly in reply.
- If it is unrelated to food or groceries, return no intents and a one-line reply.`;

export interface Interpreted {
  intents: Intent[];
  reply: string;
}

function toIntent(i: z.infer<typeof CommandZ>['intents'][number]): Intent | null {
  const items: ItemSpec[] = i.items.map((x) => ({ name: x.name, amount: x.amount, unit: x.unit, all: x.all, vague: false, location: x.location }));
  switch (i.type) {
    case 'add_inventory': return { type: 'add_inventory', items, explicit: true };
    case 'consume': return { type: 'consume', items };
    case 'discard': return { type: 'discard', items, reason: i.reason ?? 'other' };
    case 'set_quantity': return { type: 'set_quantity', items };
    case 'shopping_add': return { type: 'shopping_add', items };
    case 'shopping_remove': return { type: 'shopping_remove', items };
    case 'freeze': return { type: 'freeze', items };
    case 'thaw': return { type: 'thaw', items };
    case 'cooked': return { type: 'cooked', dish: i.dish ?? '', servings: i.servings, leftovers: null };
    case 'query_item': return items[0] ? { type: 'query_item', name: items[0].name } : null;
    case 'query_inventory': return { type: 'query_inventory', location: items[0]?.location ?? null };
    case 'query_low': return { type: 'query_low' };
    case 'query_buy': return { type: 'query_buy' };
    case 'query_expiring': return { type: 'query_expiring' };
    case 'query_cook': return { type: 'query_cook', filters: { query: i.dish, ingredient: items[0]?.name ?? null, cuisine: null, maxMinutes: null, highProtein: false, cheap: false, diet: null, useUp: false, meal: null } };
    default: return null;
  }
}

async function interpretCommand(text: string, lang: Lang, snapshot: unknown): Promise<Interpreted> {
  const out = await structured(CommandZ, {
    system: COMMAND_SYSTEM,
    effort: 'low',
    maxTokens: 4000,
    content: [{ type: 'text', text: `Language: ${lang}\nHousehold data:\n${JSON.stringify(snapshot)}\n\nUtterance: ${text}` }],
  });
  return { intents: out.intents.map(toIntent).filter((x): x is Intent => !!x), reply: out.reply };
}

// ---------- Receipts ----------

const ReceiptZ = z.object({
  store: z.string().nullable(),
  date: z.string().nullable().describe('YYYY-MM-DD'),
  total: z.number().nullable(),
  deposit: z.number().describe('Total deposit (statiegeld), 0 if none'),
  lines: z.array(
    z.object({
      raw: z.string().describe('The receipt text of this line, as printed'),
      name: z.string().describe('Product description as printed, with abbreviations expanded when certain (e.g. "HV MELK" → "Halfvolle melk")'),
      count: z.number().describe('Number of units bought (1 for weighed items)'),
      weightKg: z.number().nullable(),
      unitPrice: z.number().nullable(),
      price: z.number().nullable().describe('Line total before discounts'),
      discount: z.number().describe('Discount applied to this line as a positive number, 0 if none'),
    }),
  ),
});

const RECEIPT_SYSTEM = `You read supermarket receipts (often Dutch: Albert Heijn, Jumbo, Lidl, Plus, Dirk, Aldi) and return every purchased product line.
- Include each product once with its count; merge "2 x 0,79" lines into the item they belong to.
- Attach bonus/korting/discount lines to the product they discount. Exclude deposits (statiegeld), bags, payment and loyalty lines.
- Weighed items: count 1 and weightKg.
- Do not invent lines you cannot read. If the image is not a receipt, return no lines.`;

async function parseReceiptImages(images: { mediaType: string; data: string }[]): Promise<ParsedReceipt> {
  const content: Anthropic.Beta.BetaContentBlockParam[] = images.map((img) => ({
    type: 'image' as const,
    source: { type: 'base64' as const, media_type: img.mediaType as 'image/jpeg' | 'image/png' | 'image/webp' | 'image/gif', data: img.data },
  }));
  content.push({ type: 'text', text: images.length > 1 ? 'These images are consecutive parts of one long receipt. Do not duplicate lines that appear in two images.' : 'Read this receipt.' });
  const out = await structured(ReceiptZ, { system: RECEIPT_SYSTEM, effort: 'medium', content });
  const lines = out.lines.map((l) => ({ ...l, size: parseSize(l.name) }));
  const sum = lines.reduce((s, l) => s + (l.price ?? 0) - l.discount, 0) + out.deposit;
  const warnings = out.total != null && Math.abs(sum - out.total) > 0.05 ? [`Line items add up to €${sum.toFixed(2)}, receipt total is €${out.total.toFixed(2)}.`] : [];
  if (!lines.length) warnings.push('No products found on this receipt.');
  return { store: out.store, date: out.date, total: out.total, deposit: out.deposit, lines, warnings };
}

async function parseReceiptText(text: string): Promise<ParsedReceipt> {
  const out = await structured(ReceiptZ, { system: RECEIPT_SYSTEM, effort: 'low', content: [{ type: 'text', text: `Receipt text (OCR or email):\n${text}` }] });
  const lines = out.lines.map((l) => ({ ...l, size: parseSize(l.name) }));
  return { store: out.store, date: out.date, total: out.total, deposit: out.deposit, lines, warnings: lines.length ? [] : ['No products found.'] };
}

// ---------- Recipes ----------

const RecipeZ = z.object({
  title: z.string(),
  summary: z.string(),
  cuisine: z.string(),
  servings: z.number().int(),
  prep_minutes: z.number().int(),
  cook_minutes: z.number().int(),
  difficulty: z.enum(['easy', 'medium', 'hard']),
  diet: z.array(z.string()).describe('Any of: vegetarian, vegan, gluten-free, dairy-free'),
  tags: z.array(z.string()),
  emoji: z.string(),
  ingredients: z.array(
    z.object({
      name: z.string().describe('Plain ingredient name, matching the inventory name when you use an inventory item'),
      quantity: z.number(),
      unit: z.enum(['g', 'ml', 'pcs']),
      display: z.string().describe('How it reads in the recipe, e.g. "1 onion, finely chopped"'),
      optional: z.boolean(),
    }),
  ),
  steps: z.array(z.object({ text: z.string(), timerSeconds: z.number().int().nullable() })),
  nutritionPerServing: z.object({ kcal: z.number(), protein: z.number(), carbs: z.number(), fat: z.number() }),
});

export type GeneratedRecipe = z.infer<typeof RecipeZ>;

const RECIPE_SYSTEM = `You are a practical home cook writing one original recipe for a household.
- Prefer ingredients from their inventory, especially ones that expire soon. Keep missing ingredients to a minimum and common in Dutch supermarkets.
- Quantities in g, ml or pcs for the given servings. Realistic timings. Clear, short steps with timers where useful.
- Respect dietary preferences and dislikes strictly. Nutrition is your estimate per serving.
- Write in the requested language.`;

async function generateRecipe(request: string, ctx: { lang: Lang; inventory: { name: string; qty: string; expiresInDays: number | null }[]; diet: string[]; dislikes: string[]; servings: number }): Promise<GeneratedRecipe> {
  return structured(RecipeZ, {
    system: RECIPE_SYSTEM,
    effort: 'medium',
    content: [{ type: 'text', text: `Language: ${ctx.lang}\nServings: ${ctx.servings}\nDiet: ${ctx.diet.join(', ') || 'none'}\nDislikes: ${ctx.dislikes.join(', ') || 'none'}\nInventory: ${JSON.stringify(ctx.inventory)}\n\nRequest: ${request}` }],
  });
}

export const ai = {
  enabled: () => config.aiEnabled,
  model: () => config.aiModel,
  interpretCommand,
  parseReceiptImages,
  parseReceiptText,
  generateRecipe,
};
