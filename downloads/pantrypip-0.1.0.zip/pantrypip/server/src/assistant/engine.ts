// Conversational assistant: interprets an utterance, resolves products, asks only when needed,
// and executes through the same ledger/shopping/recipe functions the UI uses.
import { interactionPrefs } from '../domain/personal.ts';
import type { Db } from '../db/db.ts';
import { newId, parseJson } from '../db/db.ts';
import { clock, daysBetween, addDays } from '../clock.ts';
import { log } from '../log.ts';
import { parse, parseItem, splitItems, type Intent, type ItemSpec, type Lang, type CookFilters } from './parser.ts';
import { displayName, resolveProduct, createProduct, createCustomType, normalizeText, stem, type Product, type MatchCandidate } from '../domain/products.ts';
import { addStock, deduct, moveLot, newCtx, undoBatch, batchExists, openProduct, type Ctx, type EventSource } from '../domain/ledger.ts';
import { inventorySummary, stockItem, correctQuantity, type StockItem } from '../domain/inventory.ts';
import { toBase, formatQty, parseNumber, unitDef, UnitError } from '../domain/units.ts';
import { addShoppingItem, findShoppingItemByName, removeShoppingItem, shoppingSuggestions, listShopping, syncPlanToShopping } from '../domain/shopping.ts';
import { cookRecipe, searchRecipes, listRecipes, getRecipe, type RecipeMatch } from '../domain/recipes.ts';
import { getSlot, updateSlot } from '../domain/planner.ts';
import { pendingCheckins } from '../domain/checkins.ts';
import { ai } from '../ai/ai.ts';
import { expandRunOn } from './list.ts';
import { recipeFromSentence, recipeFromStock } from '../domain/quick-recipe.ts';
import { familyPref, setChoice } from '../domain/substitutions.ts';
import { familyById } from '../domain/ingredient-match.ts';
import type { Family } from '../db/ingredient-knowledge.ts';

export interface ActionView {
  kind: 'added' | 'used' | 'discarded' | 'set' | 'listed' | 'unlisted' | 'frozen' | 'thawed' | 'cooked' | 'undone' | 'leftover' | 'skipped';
  label: string;
  productId?: string | null;
  lotId?: string | null;
  shoppingItemId?: string | null;
  estimate?: boolean;
}

export interface AssistantResponse {
  conversationId: string;
  turnId: string;
  lang: Lang;
  reply: string;
  actions: ActionView[];
  batchId: string | null;
  undoable: boolean;
  clarify?: { question: string; options: { label: string; value: string }[] } | null;
  clientAction?: 'open_receipt' | 'open_barcode' | 'open_recipes' | null;
  data?: { kind: 'stock' | 'list' | 'recipes' | 'suggestions' | 'expiring'; items: any[] } | null;
  via: 'rules' | 'ai';
  duplicate?: boolean;
}

type Pending =
  | { kind: 'amount'; intent: 'consume' | 'discard'; item: ItemSpec; productId: string | null; lotId: string | null; rest: ItemSpec[]; reason?: string }
  | { kind: 'choose'; intent: Intent['type']; item: ItemSpec; candidates: { id: string; name: string }[]; rest: ItemSpec[]; reason?: string }
  | { kind: 'target'; items: ItemSpec[] }
  | { kind: 'confirm_all'; intent: 'consume' | 'discard'; item: ItemSpec; productId: string | null; lotId: string | null; rest: ItemSpec[]; reason?: string }
  | { kind: 'repeat'; text: string }
  | { kind: 'recipe'; servings: number | null; options: { id: string; title: string; slotId?: string }[]; dish?: string }
  | { kind: 'leftovers'; recipeId: string; title: string }
  | { kind: 'add_to_list'; productIds: string[] }
  | { kind: 'free_cook'; dish: string; servings: number | null; asked: 'dish' | 'ingredients' }
  | { kind: 'leftover_eat'; lotId: string; label: string; max: number }
  | { kind: 'skip_slot'; slotIds: string[] }
  | { kind: 'move_slot'; slotId: string; title: string }
  | { kind: 'checkin'; slotId: string; title: string }
  | { kind: 'variant'; intent: ItemIntent; item: ItemSpec; rest: ItemSpec[]; reason?: string; family: string; group?: string; options: { id: string; name: string }[] }
  | { kind: 'custom_type'; intent: ItemIntent; item: ItemSpec; rest: ItemSpec[]; reason?: string; family: string };

interface TurnRecord {
  id: string;
  utterance: string;
  normalized: string;
  response: string;
  pending: string | null;
  batch_id: string | null;
  created_at: string;
}

const L = (lang: Lang, en: string, nl: string) => (lang === 'nl' ? nl : en);

export interface HandleInput {
  householdId: string;
  userId?: string | null;
  conversationId?: string | null;
  text: string;
  lang?: Lang | null;
  context?: string | null; // UI section the user is in: 'inventory' | 'shopping' | ...
  clientRequestId?: string | null;
}

class Turn {
  readonly actions: ActionView[] = [];
  reply: string[] = [];
  clarify: AssistantResponse['clarify'] = null;
  pending: Pending | null = null;
  clientAction: AssistantResponse['clientAction'] = null;
  data: AssistantResponse['data'] = null;
  intentRecord: Intent | null = null;
  mutated = false;
  via: 'rules' | 'ai' = 'rules';
  readonly db: Db;
  readonly householdId: string;
  readonly lang: Lang;
  ctx: Ctx;
  readonly input: HandleInput;
  constructor(db: Db, householdId: string, lang: Lang, ctx: Ctx, input: HandleInput) {
    this.db = db;
    this.householdId = householdId;
    this.lang = lang;
    this.ctx = ctx;
    this.input = input;
  }
  say(en: string, nl: string) {
    this.reply.push(L(this.lang, en, nl));
  }
  ask(en: string, nl: string, options: { label: string; value: string }[], pending: Pending) {
    this.clarify = { question: L(this.lang, en, nl), options };
    this.pending = pending;
  }
}

export async function handleUtterance(db: Db, input: HandleInput): Promise<AssistantResponse> {
  const conversationId = input.conversationId || newId('cv');
  const prev = db.get<TurnRecord>('SELECT * FROM assistant_turns WHERE conversation_id = ? AND household_id = ? ORDER BY created_at DESC, rowid DESC LIMIT 1', conversationId, input.householdId);
  const prevPending = prev?.pending ? parseJson<Pending | null>(prev.pending, null) : null;
  const prevResp = prev ? parseJson<any>(prev.response, {}) : null;
  const langHint: Lang = input.lang ?? prevResp?.lang ?? 'en';
  const parsed = parse(input.text, { awaiting: !!prevPending, langHint });
  const lang = input.lang ?? parsed.lang;
  const normalized = normalizeText(input.text);

  // Idempotency: the same client request id returns the stored response.
  if (input.clientRequestId) {
    const same = db.get<TurnRecord>("SELECT * FROM assistant_turns WHERE household_id = ? AND batch_id = ? LIMIT 1", input.householdId, newCtx(db, input.householdId, 'voice', { clientRequestId: input.clientRequestId }).batchId);
    if (same) return { ...JSON.parse(same.response), duplicate: true };
  }

  const ctx = newCtx(db, input.householdId, 'voice', { userId: input.userId, clientRequestId: input.clientRequestId });
  const turn = new Turn(db, input.householdId, lang, ctx, input);

  try {
    db.tx(() => {
      // Repeated identical command within 30 s that changed stock: ask before doing it twice.
      const isMutation = (i: Intent) => ['add_inventory', 'consume', 'discard', 'shopping_add', 'freeze', 'cooked', 'add_ambiguous', 'set_quantity', 'open'].includes(i.type);
      if (prev && prev.normalized === normalized && prev.batch_id && daysBetween(prev.created_at, clock.now()) * 86400 < 30 && parsed.intents.some(isMutation) && !prevPending) {
        turn.ask('You just said that. Do it again?', 'Dat zei je net ook. Nog een keer doen?', [opt(lang, 'Yes, again', 'Ja, nog een keer', 'yes'), opt(lang, 'No', 'Nee', 'no')], { kind: 'repeat', text: input.text });
        return;
      }
      // A complete new command overrides an open question ("Any leftovers?" → "I have 3 eggs left").
      const fresh = prevPending ? parse(input.text, { langHint }) : null;
      const standalone = fresh && fresh.intents.every(isStandalone);
      if (prevPending && !standalone && runPending(turn, prevPending, parsed.intents[0], input.text)) return;
      if (standalone && fresh) {
        for (const intent of fresh.intents) runIntent(turn, intent, prev, fresh.confidence);
        return;
      }
      for (const intent of parsed.intents) runIntent(turn, intent, prev, parsed.confidence);
    });
  } catch (e: any) {
    log.warn('assistant error', { err: e.message, text: input.text });
    turn.reply = [L(lang, `Sorry, that didn't work: ${e.message}`, `Sorry, dat lukte niet: ${e.message}`)];
  }

  // Fall back to the AI interpreter for anything the rules didn't understand.
  if (!turn.reply.length && !turn.clarify && !turn.actions.length && !turn.data && !turn.clientAction) {
    if (ai.enabled()) {
      try {
        const interpreted = await ai.interpretCommand(input.text, lang, contextSnapshot(db, input.householdId));
        if (interpreted.intents.length) {
          turn.via = 'ai';
          // AI-proposed actions go through the same validated paths, tagged with their source.
          turn.ctx = { ...ctx, source: 'assistant_ai' as EventSource };
          db.tx(() => {
            for (const intent of interpreted.intents) runIntent(turn, intent, prev, 0.8);
          });
          if (!turn.reply.length && interpreted.reply) turn.reply.push(interpreted.reply);
        } else if (interpreted.reply) {
          turn.via = 'ai';
          turn.reply.push(interpreted.reply);
        }
      } catch (e: any) {
        log.warn('ai interpret failed', { err: e.message });
      }
    }
    if (!turn.reply.length && !turn.clarify) {
      turn.say(
        "I didn't catch that. Try \"I bought 2 litres of milk\", \"I used 3 eggs\" or \"add coffee to the list\".",
        'Dat begreep ik niet. Probeer "ik heb 2 liter melk gekocht", "ik heb 3 eieren gebruikt" of "zet koffie op de lijst".',
      );
    }
  }

  const response: AssistantResponse = {
    conversationId,
    turnId: newId('t'),
    lang,
    reply: turn.reply.join(' '),
    actions: turn.actions,
    batchId: turn.mutated ? ctx.batchId : null,
    undoable: turn.mutated,
    clarify: turn.clarify,
    clientAction: turn.clientAction,
    data: turn.data,
    via: turn.via,
  };
  db.insert('assistant_turns', {
    id: response.turnId,
    household_id: input.householdId,
    user_id: input.userId ?? null,
    conversation_id: conversationId,
    utterance: input.text,
    normalized,
    response: { ...response, _intent: turn.intentRecord },
    pending: turn.pending,
    batch_id: turn.mutated || input.clientRequestId ? ctx.batchId : null,
    created_at: clock.iso(),
  });
  return response;
}

const opt = (lang: Lang, en: string, nl: string, value: string) => ({ label: L(lang, en, nl), value });

/**
 * When the assistant opens and a planned meal is waiting for its daily check-in, the assistant
 * asks first: "Did you cook X?". Answering "yes" (by voice or tap) cooks it; "no" skips it.
 */
export function greet(db: Db, input: { householdId: string; userId?: string | null; conversationId?: string | null; lang: Lang }): AssistantResponse | null {
  const c = pendingCheckins(db, input.householdId)[0];
  if (!c) return null;
  const lang = input.lang;
  const conversationId = input.conversationId || newId('cv');
  const question = c.when === 'yesterday'
    ? L(lang, `Did you cook ${c.title} yesterday?`, `Heb je gisteren ${c.title} gekookt?`)
    : L(lang, `Did you cook ${c.title}${c.meal === 'dinner' ? ' tonight' : ' today'}?`, `Heb je ${c.meal === 'dinner' ? 'vanavond' : 'vandaag'} ${c.title} gekookt?`);
  const response: AssistantResponse = {
    conversationId,
    turnId: newId('t'),
    lang,
    reply: '',
    actions: [],
    batchId: null,
    undoable: false,
    clarify: { question, options: [opt(lang, 'Yes, cooked', 'Ja, gekookt', 'yes'), opt(lang, 'No', 'Nee', 'no'), opt(lang, 'Tomorrow', 'Morgen', 'tomorrow')] },
    via: 'rules',
  };
  db.insert('assistant_turns', {
    id: response.turnId, household_id: input.householdId, user_id: input.userId ?? null, conversation_id: conversationId,
    utterance: '', normalized: '', response, pending: { kind: 'checkin', slotId: c.slotId, title: c.title }, batch_id: null, created_at: clock.iso(),
  });
  return response;
}

/** Whether an intent is a complete command on its own (as opposed to an answer fragment). */
function isStandalone(i: Intent): boolean {
  switch (i.type) {
    case 'unknown': case 'answer': case 'confirm': case 'correction': return false;
    case 'cooked': return !!i.dish || !!i.meal;
    case 'not_cooked': return true;
    case 'query_item': return !!i.name;
    default: return 'items' in i ? i.items.length > 0 && i.items.every((x) => x.name.length > 1) : true;
  }
}

function contextSnapshot(db: Db, householdId: string) {
  const { items, leftovers } = inventorySummary(db, householdId);
  return {
    inventory: items.map((s) => ({ name: s.product.name, qty: formatQty(s.showEstimate ? s.estimated : s.confirmed, s.product.unit) })),
    leftovers: leftovers.map((l) => ({ name: l.title, portions: l.quantity })),
    shoppingList: listShopping(db, householdId).groups.flatMap((g) => g.items.map((i) => i.name)),
  };
}

// ---------- Pending clarifications ----------

function runPending(turn: Turn, p: Pending, intent: Intent, text: string): boolean {
  const { lang } = turn;
  const t = normalizeText(text);
  switch (p.kind) {
    case 'repeat':
      if (intent.type === 'confirm' && intent.yes) {
        const again = parse(p.text, { langHint: lang });
        for (const i of again.intents) runIntent(turn, i, undefined, again.confidence);
      } else turn.say('OK, I left it.', 'Oké, ik heb niets gedaan.');
      return true;
    case 'amount': {
      if (intent.type === 'confirm' && !intent.yes) return cancelled(turn);
      const item = answerToItem(t, p.item);
      if (!item) return false;
      execItem(turn, p.intent, item, p.productId, p.lotId, p.reason);
      runItems(turn, p.intent, p.rest, p.reason);
      return true;
    }
    case 'confirm_all': {
      if (intent.type === 'confirm') {
        if (!intent.yes) return cancelled(turn);
        execItem(turn, p.intent, { ...p.item, all: true }, p.productId, p.lotId, p.reason);
        runItems(turn, p.intent, p.rest, p.reason);
        return true;
      }
      const item = answerToItem(t, p.item);
      if (!item) return false;
      execItem(turn, p.intent, item, p.productId, p.lotId, p.reason);
      runItems(turn, p.intent, p.rest, p.reason);
      return true;
    }
    case 'choose': {
      if (intent.type === 'confirm' && !intent.yes) return cancelled(turn);
      const pick = p.candidates.find((c) => c.id === text || normalizeText(c.name) === t) ?? p.candidates.find((c) => normalizeText(c.name).includes(t) || t.includes(normalizeText(c.name)));
      const ordinal = ['1', 'first', 'eerste', 'one', 'een'].includes(t) ? 0 : ['2', 'second', 'tweede', 'two', 'twee'].includes(t) ? 1 : ['3', 'third', 'derde'].includes(t) ? 2 : -1;
      const chosen = pick ?? (ordinal >= 0 ? p.candidates[ordinal] : undefined);
      if (!chosen) return false;
      runItemsWithProduct(turn, p.intent, p.item, chosen.id, p.reason);
      runItems(turn, p.intent, p.rest, p.reason);
      return true;
    }
    case 'variant': {
      if (intent.type === 'confirm' && !intent.yes) return cancelled(turn);
      const family = familyById(p.family);
      if (!family) return false;
      // A button value, or words that name one of the options ("oat", "the second").
      const ordinal = ['1', 'first', 'eerste'].includes(t) ? 0 : ['2', 'second', 'tweede'].includes(t) ? 1 : ['3', 'third', 'derde'].includes(t) ? 2 : -1;
      const opt = p.options.find((o) => o.id === text) ?? p.options.find((o) => normalizeText(o.name) === t)
        ?? p.options.find((o) => o.id !== 'other' && t.length >= 3 && normalizeText(o.name).split(' ').some((w) => w.startsWith(t) || t.split(' ').includes(w)))
        ?? (ordinal >= 0 ? p.options[ordinal] : undefined);
      const variants = resolveProduct(turn.db, turn.householdId, family.words[0]).candidates.map((c) => c.product);
      if (!opt) {
        // Not one of the options: a type of its own ("goat milk"), if it's a plausible name.
        if (t.length < 3 || t.split(' ').length > 5) return false;
        const custom = createCustomType(turn.db, turn.householdId, family.id, text);
        setChoice(turn.db, turn.householdId, `f:${family.id}`, custom.id);
        turn.say(`(New type: ${custom.name}.)`, `(Nieuw soort: ${custom.name}.)`);
        runItemsWithProduct(turn, p.intent, p.item, custom.id, p.reason);
        runItems(turn, p.intent, p.rest, p.reason);
        return true;
      }
      if (opt.id.startsWith('group:')) return askVariant(turn, p.intent, p.item, p.rest, p.reason, family, variants, opt.id.slice(6)), true;
      if (opt.id === 'other') {
        turn.ask(`What's it called? (e.g. "goat milk")`, `Hoe heet het? (bijv. "geitenmelk")`, [], { kind: 'custom_type', intent: p.intent, item: p.item, rest: p.rest, reason: p.reason, family: family.id });
        return true;
      }
      // Remember it: next time "milk" means this, without asking.
      if (!['consume', 'discard', 'set_quantity', 'freeze', 'thaw'].includes(p.intent)) setChoice(turn.db, turn.householdId, `f:${family.id}`, opt.id);
      runItemsWithProduct(turn, p.intent, p.item, opt.id, p.reason);
      runItems(turn, p.intent, p.rest, p.reason);
      return true;
    }
    case 'custom_type': {
      if (intent.type === 'confirm' && !intent.yes) return cancelled(turn);
      if (t.length < 2) return false;
      const custom = createCustomType(turn.db, turn.householdId, p.family, text);
      setChoice(turn.db, turn.householdId, `f:${p.family}`, custom.id);
      turn.say(`(New type: ${custom.name}.)`, `(Nieuw soort: ${custom.name}.)`);
      runItemsWithProduct(turn, p.intent, p.item, custom.id, p.reason);
      runItems(turn, p.intent, p.rest, p.reason);
      return true;
    }
    case 'target': {
      const toList = /\b(list|lijst|shopping|boodschappen|buy|kopen)\b/.test(t) || text === 'list';
      const toInv = /\b(inventory|stock|voorraad|have|bought|gekocht|kast|fridge|koelkast)\b/.test(t) || text === 'inventory';
      if (!toList && !toInv) return false;
      runIntent(turn, toList ? { type: 'shopping_add', items: p.items } : { type: 'add_inventory', items: p.items, explicit: true }, undefined, 0.9);
      return true;
    }
    case 'recipe': {
      if (text === 'other' || /^(something else|iets anders|anders|none of these|geen van deze)$/.test(t)) {
        turn.ask(
          'OK. What did you use? For example "pasta, 500 g minced beef and a tin of tomatoes".',
          'Oké. Wat heb je gebruikt? Bijvoorbeeld "pasta, 500 g gehakt en een blik tomaten".',
          [opt(lang, 'Nothing from stock', 'Niets uit de voorraad', 'none')],
          { kind: 'free_cook', dish: p.dish ?? '', servings: p.servings, asked: 'ingredients' },
        );
        return true;
      }
      const r = p.options.find((o) => o.slotId === text || o.id === text || normalizeText(o.title) === t || normalizeText(o.title).includes(t));
      if (!r) return false;
      const slot = r.slotId ? turn.db.get<{ servings: number }>('SELECT servings FROM meal_slots WHERE id = ?', r.slotId) : null;
      doCook(turn, r.id, p.servings ?? slot?.servings ?? null, r.slotId ?? null);
      return true;
    }
    case 'free_cook': {
      if (intent.type === 'confirm' && !intent.yes) return cancelled(turn);
      if (p.asked === 'dish') {
        runCooked(turn, text, p.servings, null);
        return true;
      }
      if (text === 'none' || /^(nothing|niets|none|geen)\b/.test(t)) {
        turn.say(`OK, noted that you cooked${p.dish ? ` ${p.dish}` : ''}. Nothing taken from stock.`, `Oké, genoteerd${p.dish ? ` dat je ${p.dish} hebt gemaakt` : ''}. Niets uit de voorraad gehaald.`);
        return true;
      }
      const used = parse(`I used ${text}`, { langHint: 'en' }).intents[0];
      const items = used.type === 'consume' ? used.items : splitItems(text).map(parseItem).filter((x): x is ItemSpec => !!x);
      if (!items.length) return false;
      runItems(turn, 'consume', items.map((i) => ({ ...i, vague: false })));
      return true;
    }
    case 'leftover_eat': {
      const n = /^(all|alles|everything)$/.test(t) || text === 'all' ? p.max : parseNumber(t.split(' ')[0] ?? '');
      if (!n) return false;
      deduct(turn.ctx, { lotId: p.lotId, quantity: Math.min(n, p.max), type: 'consume' });
      turn.mutated = true;
      turn.actions.push({ kind: 'used', label: `${p.label} −${formatQty(Math.min(n, p.max), 'portion', { lang })}`, lotId: p.lotId });
      turn.say(`Enjoy! ${formatQty(Math.min(n, p.max), 'portion')} of ${p.label.toLowerCase()} eaten.`, `Eet smakelijk! ${formatQty(Math.min(n, p.max), 'portion', { lang })} ${p.label.toLowerCase()} opgegeten.`);
      return true;
    }
    case 'skip_slot': {
      const id = p.slotIds.find((x) => x === text);
      if (!id) return false;
      const s = getSlot(turn.db, turn.householdId, id);
      skipSlot(turn, id, s.recipe?.title ?? s.title ?? '');
      return true;
    }
    case 'checkin': {
      // Answer to the daily "Did you cook X?" question.
      const slot = getSlot(turn.db, turn.householdId, p.slotId);
      if (slot.status !== 'planned') {
        turn.say('That one is already done.', 'Die is al afgehandeld.');
        return true;
      }
      if (/\b(tomorrow|morgen)\b/.test(t)) {
        updateSlot(turn.db, turn.householdId, p.slotId, { date: addDays(clock.today(), 1) });
        syncPlanToShopping(turn.db, turn.householdId, { quiet: true });
        turn.say(`Moved ${p.title} to tomorrow.`, `${p.title} staat nu op morgen.`);
        return true;
      }
      const servingsM = t.match(/\b(?:for|voor)\s+(\w+)/);
      const servings = servingsM ? parseNumber(servingsM[1]) : null;
      const no = (intent.type === 'confirm' && !intent.yes) || /\b(no|nee|not|niet|didnt|didn t|nope|skip|skipped|overgeslagen)\b/.test(t);
      const yes = !no && ((intent.type === 'confirm' && intent.yes) || /\b(yes|ja|yep|yeah|cooked|gekookt|gemaakt|made|did|klopt|sure|zeker|done)\b/.test(t));
      if (yes) {
        doCook(turn, slot.recipe_id!, servings ?? slot.servings, slot.id);
        return true;
      }
      if (no) {
        skipSlot(turn, slot.id, p.title);
        return true;
      }
      return false;
    }
    case 'move_slot': {
      if (intent.type !== 'confirm') return false;
      if (intent.yes) {
        updateSlot(turn.db, turn.householdId, p.slotId, { date: addDays(clock.today(), 1), status: 'planned' });
        syncPlanToShopping(turn.db, turn.householdId, { quiet: true });
        turn.say(`Moved ${p.title} to tomorrow.`, `${p.title} staat nu op morgen.`);
      } else turn.say('OK.', 'Oké.');
      return true;
    }
    case 'leftovers': {
      const m = text.match(/^leftover:(fridge|freezer):(\d+)$/) ?? null;
      let where: 'fridge' | 'freezer' = /freez|vries/.test(t) ? 'freezer' : 'fridge';
      let n = m ? Number(m[2]) : parseNumber(t.split(' ').find((w) => parseNumber(w) != null) ?? '') ?? null;
      if (m) where = m[1] as any;
      if (intent.type === 'confirm' && !intent.yes) {
        turn.say('OK, no leftovers.', 'Oké, geen restjes.');
        return true;
      }
      if (!n) return false;
      const { lot } = addStock(turn.ctx, { quantity: n, unit: 'portion', label: p.title, isLeftover: true, recipeId: p.recipeId, location: where, type: 'leftover' });
      turn.mutated = true;
      turn.actions.push({ kind: 'leftover', label: `${p.title} · ${formatQty(n, 'portion', { lang })}`, lotId: lot.id });
      turn.say(`Saved ${formatQty(n, 'portion')} in the ${where}.`, `${formatQty(n, 'portion', { lang })} bewaard in de ${where === 'freezer' ? 'vriezer' : 'koelkast'}.`);
      return true;
    }
    case 'add_to_list': {
      if (intent.type === 'confirm' && intent.yes) {
        for (const id of p.productIds) listAdd(turn, { name: '', amount: null, unit: null, all: false, vague: false }, id);
        return true;
      }
      if (intent.type === 'confirm') return true;
      return false;
    }
  }
}

function cancelled(turn: Turn) {
  turn.say('OK, cancelled.', 'Oké, geannuleerd.');
  return true;
}

/** Interpret a clarification answer ("about 250 ml", "half", "all", "2") as an amount for item. */
function answerToItem(t: string, item: ItemSpec): ItemSpec | null {
  if (/^(all|everything|all of it|the lot|alles|allemaal|helemaal|alles op|op)$/.test(t) || t === 'all') return { ...item, all: true, vague: false, amount: null };
  const parsed = parseItem(`${t} ${item.name}`);
  if (parsed && parsed.amount != null) return { ...item, amount: parsed.amount, unit: parsed.unit, vague: false, all: false };
  if (/^(half|de helft|helft|halve)$/.test(t)) return { ...item, amount: 0.5, unit: '__fraction__', vague: false };
  return null;
}

// ---------- Intents ----------

function runIntent(turn: Turn, intent: Intent, prev: TurnRecord | undefined, confidence: number) {
  const { lang } = turn;
  turn.intentRecord ??= intent;
  switch (intent.type) {
    case 'add_inventory':
    case 'shopping_add':
      // "I bought milk eggs bread": one item per product, even without commas.
      intent = { ...intent, items: expandRunOn(turn.db, turn.householdId, intent.items) };
      if (!intent.items.length) return turn.say("Which product do you mean?", 'Welk product bedoel je?');
      return runItems(turn, intent.type, intent.items);
    case 'consume':
    case 'set_quantity':
    case 'shopping_remove':
    case 'freeze':
    case 'thaw':
      if (!intent.items.length) return turn.say("Which product do you mean?", 'Welk product bedoel je?');
      return runItems(turn, intent.type, intent.items);
    case 'discard':
      if (!intent.items.length) return turn.say('What did you throw away?', 'Wat heb je weggegooid?');
      return runItems(turn, 'discard', intent.items, intent.reason);
    case 'add_ambiguous': {
      intent = { ...intent, items: expandRunOn(turn.db, turn.householdId, intent.items) };
      if (turn.input.context === 'shopping') return runItems(turn, 'shopping_add', intent.items);
      if (turn.input.context === 'inventory') return runItems(turn, 'add_inventory', intent.items);
      const names = intent.items.map((i) => i.name).join(', ');
      return turn.ask(`Add ${names} to your inventory or your shopping list?`, `${names} toevoegen aan je voorraad of je boodschappenlijst?`,
        [opt(lang, 'Shopping list', 'Boodschappenlijst', 'list'), opt(lang, 'I have it (inventory)', 'Heb ik in huis (voorraad)', 'inventory')], { kind: 'target', items: intent.items });
    }
    case 'open':
      for (const item of intent.items) {
        const res = resolveProduct(turn.db, turn.householdId, item.name);
        let product = res.product;
        // Only the family named ("the milk"): the type you have in stock, else your usual one.
        if (!product && res.family) {
          const have = res.candidates.map((c) => c.product).filter((p) => stockOf(turn.db, turn.householdId, p.id) > 0);
          const pref = familyPref(turn.db, turn.householdId, res.family.id);
          product = have.length === 1 ? have[0] : have.find((p) => p.id === pref) ?? null;
        }
        if (!product) {
          turn.say(`I couldn't find ${item.name} in your inventory.`, `Ik kon ${item.name} niet vinden in je voorraad.`);
          continue;
        }
        const lot = openProduct(turn.ctx, product.id);
        const name = displayName(product, lang).toLowerCase();
        if (!lot) {
          turn.say(`Your ${name} was already open.`, `${cap(name)} was al open.`);
          continue;
        }
        turn.mutated = true;
        turn.actions.push({ kind: 'set', label: `${displayName(product, lang)}: ${lang === 'nl' ? 'geopend' : 'opened'}`, productId: product.id, lotId: lot.id });
        turn.say(
          lot.expires_on ? `Opened the ${name}. Best used by ${lot.expires_on}.` : `Opened the ${name}.`,
          lot.expires_on ? `${cap(name)} geopend. Op voor ${lot.expires_on}.` : `${cap(name)} geopend.`,
        );
      }
      if (!intent.items.length) turn.say('What did you open?', 'Wat heb je geopend?');
      return;
    case 'cooked':
      return runCooked(turn, intent.dish, intent.servings, intent.leftovers, intent.meal);
    case 'not_cooked':
      return runNotCooked(turn, intent.dish, intent.meal);
    case 'undo':
      return runUndo(turn);
    case 'correction':
      return runCorrection(turn, intent.text, prev);
    case 'save_recipe':
      return saveRecipeFromSentence(turn, intent.text);
    case 'stock_recipe':
      return makeRecipeFromStock(turn);
    case 'scan_receipt':
      turn.clientAction = 'open_receipt';
      return turn.say('Opening the receipt scanner.', 'De bonnetjesscanner gaat open.');
    case 'scan_barcode':
      turn.clientAction = 'open_barcode';
      return turn.say('Opening the barcode scanner.', 'De barcodescanner gaat open.');
    case 'query_item':
      return queryItem(turn, intent.name);
    case 'query_inventory':
      return queryInventory(turn, intent.location);
    case 'query_low':
      return queryLow(turn);
    case 'query_buy':
      return queryBuy(turn);
    case 'query_expiring':
      return queryExpiring(turn);
    case 'query_cook':
      return queryCook(turn, intent.filters);
    case 'confirm':
      return turn.say('OK.', 'Oké.');
    case 'answer':
    case 'unknown':
      void confidence;
      return;
  }
}

type ItemIntent = 'add_inventory' | 'consume' | 'discard' | 'set_quantity' | 'shopping_add' | 'shopping_remove' | 'freeze' | 'thaw' | Intent['type'];

function runItems(turn: Turn, intent: ItemIntent, items: ItemSpec[], reason?: string) {
  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    const rest = items.slice(i + 1);
    const stop = runOneItem(turn, intent, item, rest, reason);
    if (stop) return; // waiting for a clarification; the rest continues after the answer
  }
}

/** Resolve the product for one item and execute, or set up a clarification. Returns true if waiting. */
function runOneItem(turn: Turn, intent: ItemIntent, item: ItemSpec, rest: ItemSpec[], reason?: string): boolean {
  const { db, householdId, lang } = turn;
  // Leftovers and frozen portions are matched by label first ("lasagna").
  if (['consume', 'discard', 'freeze', 'thaw', 'set_quantity'].includes(intent)) {
    const lot = findLeftover(db, householdId, item.name, intent === 'thaw' ? 'freezer' : intent === 'freeze' ? 'fridge' : null);
    if (lot) return execLeftover(turn, intent, item, lot, rest, reason);
  }
  if (intent === 'shopping_remove') {
    const it = findShoppingItemByName(db, householdId, item.name);
    if (!it) {
      turn.say(`${cap(item.name)} isn't on your list.`, `${cap(item.name)} staat niet op je lijst.`);
      return false;
    }
    removeShoppingItem(db, householdId, it.id);
    turn.actions.push({ kind: 'unlisted', label: it.name, productId: it.product_id });
    turn.say(`Removed ${it.name.toLowerCase()} from the list.`, `${it.name} van de lijst gehaald.`);
    return false;
  }
  const resolved = resolveProduct(db, householdId, item.name);
  const { product, candidates } = resolved;
  // Only the family was named ("milk", "kaas"): your usual type, or one short question.
  if (!product && resolved.family) return runFamily(turn, intent, item, rest, reason, resolved.family, candidates.map((c) => c.product));
  if (!product) {
    const inStock = candidates.filter((c) => stockOf(db, householdId, c.product.id) > 0);
    const pool = ['consume', 'discard', 'set_quantity', 'freeze', 'thaw'].includes(intent) && inStock.length ? inStock : candidates;
    if (pool.length === 1 && pool[0].score >= 0.6) return runItemsWithProduct(turn, intent, item, pool[0].product.id, reason, rest);
    if (pool.length > 1 && pool[0].score >= 0.6) {
      turn.ask(`Which ${item.name} do you mean?`, `Welke ${item.name} bedoel je?`, pool.slice(0, 3).map((c) => ({ label: displayName(c.product, lang), value: c.product.id })), { kind: 'choose', intent: intent as any, item, candidates: pool.slice(0, 3).map(choice(lang)), rest, reason });
      return true;
    }
    // Unknown product.
    if (intent === 'add_inventory') {
      const p = createProduct(db, householdId, { name: cap(item.name) });
      turn.say(`(New product "${p.name}".)`, `(Nieuw product "${p.name}".)`);
      return runItemsWithProduct(turn, intent, item, p.id, reason, rest);
    }
    if (intent === 'shopping_add') {
      listAdd(turn, item, null);
      return false;
    }
    turn.say(`I couldn't find ${item.name} in your inventory.`, `Ik kon ${item.name} niet vinden in je voorraad.`);
    return false;
  }
  return runItemsWithProduct(turn, intent, item, product.id, reason, rest);
}

const choice = (lang: Lang) => (c: MatchCandidate) => ({ id: c.product.id, name: displayName(c.product, lang) });

/**
 * A family without a type. Adding: your usual type if you've picked one before, otherwise ask once (and
 * remember). Using up: ask only between the types you actually have, and not at all if there's one.
 */
function runFamily(turn: Turn, intent: ItemIntent, item: ItemSpec, rest: ItemSpec[], reason: string | undefined, family: Family, variants: Product[]): boolean {
  const { db, householdId, lang } = turn;
  const fromStock = ['consume', 'discard', 'set_quantity', 'freeze', 'thaw'].includes(intent);
  if (fromStock) {
    const have = variants.filter((p) => stockOf(db, householdId, p.id) > 0);
    if (have.length === 1) return runItemsWithProduct(turn, intent, item, have[0].id, reason, rest);
    if (!have.length) {
      turn.say(`You have no ${family.name.toLowerCase()} in stock.`, `Je hebt geen ${family.name_nl.toLowerCase()} in huis.`);
      return false;
    }
    const options = have.map((p) => ({ id: p.id, name: displayName(p, lang) }));
    turn.ask(L(lang, family.question[0], family.question[1]), L(lang, family.question[0], family.question[1]), options.map((o) => ({ label: o.name, value: o.id })), { kind: 'variant', intent, item, rest, reason, family: family.id, options });
    return true;
  }
  const pref = familyPref(db, householdId, family.id);
  if (pref && variants.some((p) => p.id === pref)) return runItemsWithProduct(turn, intent, item, pref, reason, rest);
  return askVariant(turn, intent, item, rest, reason, family, variants);
}

function askVariant(turn: Turn, intent: ItemIntent, item: ItemSpec, rest: ItemSpec[], reason: string | undefined, family: Family, variants: Product[], group?: string) {
  const { lang } = turn;
  const byId = new Map(variants.map((p) => [p.id, p]));
  const list = group ? (family.variants.find((v) => typeof v !== 'string' && v.group === group) as { variants: string[] } | undefined)?.variants ?? [] : family.variants;
  const options: { id: string; name: string }[] = [];
  for (const v of list) {
    if (typeof v === 'string') {
      const p = byId.get(v);
      if (p) options.push({ id: p.id, name: displayName(p, lang) });
    } else options.push({ id: `group:${v.group}`, name: L(lang, v.name, v.name_nl) });
  }
  // Your own types of this family, then "something else".
  if (!group) for (const p of variants) if (p.household_id && !options.some((o) => o.id === p.id)) options.push({ id: p.id, name: displayName(p, lang) });
  options.push({ id: 'other', name: L(lang, 'Other type…', 'Ander soort…') });
  const q = group ? L(lang, 'Which one?', 'Welke?') : L(lang, family.question[0], family.question[1]);
  turn.ask(q, q, options.map((o) => ({ label: o.name, value: o.id })), { kind: 'variant', intent, item, rest, reason, family: family.id, group, options });
  return true;
}

function runItemsWithProduct(turn: Turn, intent: ItemIntent, item: ItemSpec, productId: string, reason?: string, rest: ItemSpec[] = []): boolean {
  const { db, householdId, lang } = turn;
  const p = stockProduct(db, householdId, productId);
  if (intent === 'add_inventory') return execItem(turn, intent, item, productId, null, reason), false;
  if (intent === 'shopping_add') return listAdd(turn, item, productId), false;
  if (intent === 'set_quantity') return execItem(turn, intent, item, productId, null, reason), false;
  if (intent === 'freeze' || intent === 'thaw') return execItem(turn, intent, item, productId, null, reason), false;
  // consume / discard
  const have = p.stock ? (p.stock.showEstimate ? p.stock.estimated : p.stock.confirmed) : 0;
  if (!p.stock || p.stock.confirmed <= 0) {
    const name = displayName(p.product, lang);
    if (item.all) {
      turn.say(`${name} wasn't in your inventory, so nothing to remove.`, `${name} stond niet in je voorraad, dus er is niets af te halen.`);
      offerList(turn, [productId]);
    } else turn.say(`You don't have any ${name.toLowerCase()} recorded.`, `Je hebt geen ${name.toLowerCase()} in je voorraad staan.`);
    return false;
  }
  if (item.vague || (item.amount == null && !item.all && intent === 'consume')) {
    const u = p.product.unit;
    const options =
      u === 'ml' ? ['100 ml', '250 ml', '500 ml'] : u === 'g' ? ['50 g', '100 g', '250 g'] : ['1', '2', '3'];
    if (!item.vague && intent === 'consume') {
      // "Remove the chicken": all of it, or just some?
      turn.ask(
        `All of the ${displayName(p.product, lang).toLowerCase()} (${formatQty(have, u, { lang })}), or how much?`,
        `Alle ${displayName(p.product, lang).toLowerCase()} (${formatQty(have, u, { lang })}), of hoeveel?`,
        [opt(lang, 'All of it', 'Alles', 'all'), ...options.map((o) => ({ label: o, value: o }))],
        { kind: 'confirm_all', intent: intent as any, item, productId, lotId: null, rest, reason },
      );
      return true;
    }
    turn.ask('Approximately how much?', 'Ongeveer hoeveel?', [...options.map((o) => ({ label: o, value: o })), opt(lang, 'All of it', 'Alles', 'all')], {
      kind: 'amount', intent: intent as any, item, productId, lotId: null, rest, reason,
    });
    return true;
  }
  execItem(turn, intent as any, item, productId, null, reason);
  return false;
}

function stockOf(db: Db, householdId: string, productId: string) {
  return stockItem(db, householdId, productId)?.confirmed ?? 0;
}

function stockProduct(db: Db, householdId: string, productId: string): { product: Product; stock: StockItem | null } {
  const s = stockItem(db, householdId, productId)!;
  return { product: s.product, stock: s.lots.length ? s : null };
}

function toQty(item: ItemSpec, p: Product, available: number): { qty: number; approx: boolean } {
  if (item.unit === '__fraction__' && item.amount != null) return { qty: available * item.amount, approx: true };
  try {
    return toBase(item.amount ?? 1, item.unit, p);
  } catch (e) {
    if (e instanceof UnitError) throw new Error(e.message);
    throw e;
  }
}

/** Execute one fully specified item through the ledger. */
function execItem(turn: Turn, intent: string, item: ItemSpec, productId: string | null, lotId: string | null, reason?: string) {
  const { db, householdId, lang, ctx } = turn;
  if (!productId) return;
  const s = stockItem(db, householdId, productId)!;
  const p = s.product;
  const name = displayName(p, lang);
  const fmt = (q: number) => formatQty(q, p.unit, { lang });
  const available = s.lots.length ? (s.showEstimate ? s.estimated : s.confirmed) : 0;
  switch (intent) {
    case 'add_inventory': {
      // No amount stated: one package, and we say so in the confirmation.
      const { qty } = item.amount == null ? { qty: p.package_size } : toQty(item, p, 0);
      const { lot } = addStock(ctx, { productId, quantity: qty, location: item.location ?? null, packages: qty / p.package_size });
      turn.mutated = true;
      turn.actions.push({ kind: 'added', label: `${name} +${fmt(qty)}`, productId, lotId: lot.id });
      turn.say(`Added ${fmt(qty)} ${name.toLowerCase()}.`, `${fmt(qty)} ${name.toLowerCase()} toegevoegd.`);
      // Bought it: it no longer needs to be on the shopping list.
      const listed = db.get<{ id: string }>('SELECT id FROM shopping_items WHERE household_id = ? AND product_id = ? AND checked = 0', householdId, productId);
      if (listed) {
        removeShoppingItem(db, householdId, listed.id);
        turn.actions.push({ kind: 'unlisted', label: name, productId });
      }
      return;
    }
    case 'consume':
    case 'discard': {
      const qty = item.all ? ('all' as const) : toQty(item, p, available).qty;
      const r = deduct(ctx, { productId, quantity: qty, type: intent, reason: intent === 'discard' ? reason ?? 'other' : null });
      if (!r.events.length) {
        turn.say(`There was no ${name.toLowerCase()} left to remove.`, `Er was geen ${name.toLowerCase()} meer om af te halen.`);
        return;
      }
      turn.mutated = true;
      const left = stockItem(db, householdId, productId)!.confirmed;
      turn.actions.push({ kind: intent === 'discard' ? 'discarded' : 'used', label: `${name} −${fmt(r.deducted)}`, productId });
      const verb = intent === 'discard' ? L(lang, 'Threw away', 'Weggegooid:') : L(lang, 'Used', 'Gebruikt:');
      let msg = item.all ? L(lang, `${intent === 'discard' ? 'Threw away' : 'Finished'} the ${name.toLowerCase()} (${fmt(r.deducted)}).`, `${name} is op (${fmt(r.deducted)}${intent === 'discard' ? ' weggegooid' : ''}).`) : `${verb} ${fmt(r.deducted)} ${name.toLowerCase()}.`;
      if (r.shortfall > 0) msg += L(lang, ` You only had ${fmt(r.deducted)} recorded, so it's now at zero.`, ` Er stond maar ${fmt(r.deducted)}, dus het staat nu op nul.`);
      else if (!item.all) msg += L(lang, ` ${fmt(left)} left.`, ` Nog ${fmt(left)} over.`);
      turn.reply.push(msg);
      // A regular that just ran out goes straight onto the list (undo reverts both).
      if (left <= 1e-6 && regular(db, householdId, productId) && !db.get('SELECT 1 FROM shopping_items WHERE household_id = ? AND product_id = ? AND checked = 0', householdId, productId)) {
        const it = addShoppingItem(db, householdId, { productId, reason: 'low_stock' }, turn.input.userId);
        turn.actions.push({ kind: 'listed', label: it.name, productId, shoppingItemId: it.id });
        turn.say('Put it on your shopping list.', 'Staat op je boodschappenlijst.');
      }
      return;
    }
    case 'set_quantity': {
      const { qty } = item.amount == null ? { qty: 0 } : toQty(item, p, available);
      const res = correctQuantity(ctx, productId, qty);
      turn.mutated = true;
      turn.actions.push({ kind: 'set', label: `${name} = ${fmt(qty)}`, productId });
      turn.say(`Updated: ${fmt(qty)} ${name.toLowerCase()}${Math.abs(res.before - qty) > 1e-6 ? ` (was ${fmt(res.before)})` : ''}. I'll use that to improve my estimates.`, `Bijgewerkt: ${fmt(qty)} ${name.toLowerCase()}${Math.abs(res.before - qty) > 1e-6 ? ` (was ${fmt(res.before)})` : ''}. Daarmee worden mijn schattingen beter.`);
      return;
    }
    case 'freeze':
    case 'thaw': {
      const lots = s.lots.filter((l) => (intent === 'freeze' ? l.location_kind !== 'freezer' : l.location_kind === 'freezer'));
      if (!lots.length) {
        turn.say(intent === 'freeze' ? `No unfrozen ${name.toLowerCase()} found.` : `No frozen ${name.toLowerCase()} found.`, intent === 'freeze' ? `Geen ${name.toLowerCase()} gevonden om in te vriezen.` : `Geen ingevroren ${name.toLowerCase()} gevonden.`);
        return;
      }
      let remaining = item.amount != null ? toQty(item, p, available).qty : Infinity;
      for (const l of lots) {
        if (remaining <= 1e-6) break;
        const q = Math.min(l.quantity, remaining);
        moveLot(ctx, l.id, intent === 'freeze' ? 'freezer' : 'fridge', { quantity: q < l.quantity ? q : undefined });
        remaining -= q;
      }
      turn.mutated = true;
      turn.actions.push({ kind: intent === 'freeze' ? 'frozen' : 'thawed', label: name, productId });
      turn.say(intent === 'freeze' ? `Moved ${name.toLowerCase()} to the freezer.` : `Moved ${name.toLowerCase()} to the fridge. Use it within 2 days.`, intent === 'freeze' ? `${name} naar de vriezer verplaatst.` : `${name} naar de koelkast verplaatst. Binnen 2 dagen gebruiken.`);
      return;
    }
  }
  void lotId;
}

function regular(db: Db, householdId: string, productId: string) {
  return (db.get<{ n: number }>('SELECT COUNT(*) n FROM purchases WHERE household_id = ? AND product_id = ?', householdId, productId)?.n ?? 0) >= 2;
}

function offerList(turn: Turn, productIds: string[]) {
  const onList = turn.db.get('SELECT 1 FROM shopping_items WHERE household_id = ? AND product_id = ? AND checked = 0', turn.householdId, productIds[0]);
  if (onList || turn.clarify) return;
  turn.ask('Add it to your shopping list?', 'Op je boodschappenlijst zetten?', [opt(turn.lang, 'Add to list', 'Op de lijst', 'yes'), opt(turn.lang, 'No', 'Nee', 'no')], { kind: 'add_to_list', productIds });
}

function listAdd(turn: Turn, item: ItemSpec, productId: string | null) {
  const { db, householdId, lang } = turn;
  let quantity: number | null = null;
  let packages: number | null = null;
  if (productId && item.amount != null) {
    const p = stockProduct(db, householdId, productId).product;
    try {
      const unit = item.unit ? unitDef(item.unit) : null;
      if (unit?.kind === 'package' || (!item.unit && p.unit !== 'pcs')) packages = item.amount;
      else quantity = toBase(item.amount, item.unit, p).qty;
    } catch {
      packages = item.amount;
    }
  }
  const it = addShoppingItem(db, householdId, { name: item.name, productId, quantity, packages }, turn.input.userId);
  turn.actions.push({ kind: 'listed', label: `${it.name}${it.label ? ` · ${it.label}` : ''}`, productId: it.product_id, shoppingItemId: it.id });
  turn.mutated = true;
  turn.say(`Added ${it.name.toLowerCase()} to your shopping list.`, `${it.name} staat op je boodschappenlijst.`);
  void lang;
}

// ---------- Leftovers ----------

interface LeftoverLot { id: string; label: string; quantity: number; location_kind: string | null }

function findLeftover(db: Db, householdId: string, name: string, kind: string | null): LeftoverLot | null {
  const n = normalizeText(name);
  if (!n) return null;
  const rows = db.all<LeftoverLot>(
    `SELECT l.id, l.label, l.quantity, s.kind AS location_kind FROM inventory_lots l LEFT JOIN storage_locations s ON s.id = l.location_id
     WHERE l.household_id = ? AND l.status = 'active' AND l.is_leftover = 1 ${kind ? 'AND s.kind = ?' : ''} ORDER BY l.created_at DESC`,
    ...(kind ? [householdId, kind] : [householdId]),
  );
  const stemmed = n.replace(/e$/, 'a'); // lasagne ↔ lasagna
  return rows.find((r) => {
    const l = normalizeText(r.label);
    return l.includes(n) || l.includes(stemmed) || n.includes(l) || l.replace(/e\b/g, 'a').includes(stemmed);
  }) ?? null;
}

function execLeftover(turn: Turn, intent: ItemIntent, item: ItemSpec, lot: LeftoverLot, rest: ItemSpec[], reason?: string): boolean {
  const { ctx, lang } = turn;
  const portions = item.all || item.amount == null ? lot.quantity : Math.min(lot.quantity, item.amount);
  if (intent === 'freeze' || intent === 'thaw') {
    moveLot(ctx, lot.id, intent === 'freeze' ? 'freezer' : 'fridge', { quantity: portions < lot.quantity ? portions : undefined });
    turn.mutated = true;
    turn.actions.push({ kind: intent === 'freeze' ? 'frozen' : 'thawed', label: `${lot.label} · ${formatQty(portions, 'portion', { lang })}`, lotId: lot.id });
    turn.say(intent === 'freeze' ? `Froze ${formatQty(portions, 'portion')} of ${lot.label.toLowerCase()}. Good for about 3 months.` : `Thawing ${formatQty(portions, 'portion')} of ${lot.label.toLowerCase()}. Eat within 2 days.`,
      intent === 'freeze' ? `${formatQty(portions, 'portion', { lang })} ${lot.label.toLowerCase()} ingevroren. Ongeveer 3 maanden houdbaar.` : `${formatQty(portions, 'portion', { lang })} ${lot.label.toLowerCase()} ontdooit. Binnen 2 dagen opeten.`);
  } else if (intent === 'set_quantity') {
    return false;
  } else {
    deduct(ctx, { lotId: lot.id, quantity: portions, type: intent === 'discard' ? 'discard' : 'consume', reason: intent === 'discard' ? reason ?? 'leftover' : null });
    turn.mutated = true;
    turn.actions.push({ kind: intent === 'discard' ? 'discarded' : 'used', label: `${lot.label} −${formatQty(portions, 'portion', { lang })}`, lotId: lot.id });
    turn.say(`${intent === 'discard' ? 'Threw away' : 'Ate'} ${formatQty(portions, 'portion')} of ${lot.label.toLowerCase()}.`, `${formatQty(portions, 'portion', { lang })} ${lot.label.toLowerCase()} ${intent === 'discard' ? 'weggegooid' : 'opgegeten'}.`);
  }
  runItems(turn, intent, rest, reason);
  return false;
}

// ---------- Cooking ----------

// Dish words people say (often Dutch) → words used in recipe titles.
const DISH_WORDS: Record<string, string> = {
  soep: 'soup', salade: 'salad', sla: 'salad', omelet: 'omelette', pannenkoek: 'pannenkoeken', pancake: 'pannenkoeken', pannekoek: 'pannenkoeken',
  nasi: 'fried rice', roerbak: 'stir fry', wok: 'stir fry', ovenschotel: 'traybake', zalm: 'salmon', kip: 'chicken', kipcurry: 'chicken curry',
  linzen: 'lentil', dahl: 'dal', lasagne: 'lasagna', bolognaise: 'bolognese', spag: 'spaghetti', chilli: 'chili', 'chili con carne': 'chili',
  havermout: 'oats', yoghurt: 'yoghurt', tonijn: 'tuna', rijst: 'rice', ei: 'egg', eieren: 'egg', groentesoep: 'vegetable soup', tomatensoep: 'tomato soup',
  pesto: 'pesto', stirfry: 'stir fry', 'stir-fry': 'stir fry',
};
const STOP = new Set(['with', 'met', 'and', 'en', 'of', 'van', 'the', 'de', 'het', 'a', 'een', 'some', 'wat']);

function dishWords(s: string): string[] {
  let t = normalizeText(s);
  for (const [k, v] of Object.entries(DISH_WORDS)) t = t.replace(new RegExp(`\\b${k}\\b`, 'g'), v);
  return t.split(' ').filter((w) => w && !STOP.has(w)).map(stem);
}

/** 0..1: how well a spoken dish name matches a recipe title (ingredients count for less). */
function dishScore(dish: string, title: string, extra: string): number {
  const d = dishWords(dish);
  if (!d.length) return 0;
  const tw = new Set(dishWords(title));
  const ew = new Set(dishWords(extra));
  let s = 0;
  for (const w of d) s += tw.has(w) ? 1 : [...tw].some((x) => x.length > 3 && (x.startsWith(w) || w.startsWith(x))) ? 0.8 : ew.has(w) ? 0.4 : 0;
  return s / d.length;
}

/** Planned meals still open from yesterday and today (people often confirm the next morning). */
function openSlots(db: Db, householdId: string) {
  const days = [clock.today(), addDays(clock.today(), -1)];
  return days.flatMap((d) => db.all<{ id: string; date: string; meal: string; recipe_id: string; servings: number }>(
    "SELECT id, date, meal, recipe_id, servings FROM meal_slots WHERE household_id = ? AND date = ? AND status = 'planned' AND recipe_id IS NOT NULL ORDER BY meal", householdId, d))
    .map((s) => ({ ...s, title: getRecipe(db, householdId, s.recipe_id).title }));
}

function pickSlot(db: Db, householdId: string, dish: string, meal: string | null | undefined) {
  const slots = openSlots(db, householdId);
  if (dish) {
    const scored = slots.map((s) => ({ s, score: dishScore(dish, s.title, '') })).filter((x) => x.score >= 0.5).sort((a, b) => b.score - a.score);
    return { slot: scored[0]?.s ?? null, slots };
  }
  const byMeal = meal ? slots.filter((s) => s.meal === meal) : slots.filter((s) => s.date === clock.today());
  return { slot: byMeal.length === 1 ? byMeal[0] : null, slots: byMeal.length ? byMeal : slots };
}

function runCooked(turn: Turn, dish: string, servings: number | null, leftovers: number | null, meal?: string | null) {
  const { db, householdId, lang } = turn;
  // 1. A planned meal (today or yesterday) that matches the dish, the meal type, or is the only one.
  const { slot, slots } = pickSlot(db, householdId, dish, meal);
  if (slot) return doCook(turn, slot.recipe_id, servings ?? slot.servings, slot.id, leftovers);
  if (!dish) {
    if (slots.length > 1) {
      return turn.ask('Which meal did you cook?', 'Welke maaltijd heb je gekookt?', slots.slice(0, 4).map((s) => ({ label: s.title, value: s.id })), {
        kind: 'recipe', servings, options: slots.slice(0, 4).map((s) => ({ id: s.recipe_id, title: s.title, slotId: s.id })),
      });
    }
    return turn.ask('What did you cook?', 'Wat heb je gekookt?', [], { kind: 'free_cook', dish: '', servings, asked: 'dish' });
  }
  // 2. Leftovers with that name ("we ate the lasagna") are eaten, not cooked again.
  const lo = findLeftover(db, householdId, dish, null);
  if (lo) {
    if (servings) return void execLeftover(turn, 'consume', { name: dish, amount: servings, unit: 'portion', all: false, vague: false }, lo, [], undefined);
    return turn.ask(`How many portions of ${lo.label.toLowerCase()} did you eat?`, `Hoeveel porties ${lo.label.toLowerCase()} heb je gegeten?`,
      [...Array.from({ length: Math.min(3, Math.floor(lo.quantity)) }, (_, i) => ({ label: String(i + 1), value: String(i + 1) })), opt(lang, `All (${lo.quantity})`, `Alles (${lo.quantity})`, 'all')],
      { kind: 'leftover_eat', lotId: lo.id, label: lo.label, max: lo.quantity });
  }
  // 3. Any recipe whose title matches.
  const scored = listRecipes(db, householdId)
    .map((r) => ({ r, score: dishScore(dish, r.title, [...r.tags, r.cuisine ?? '', ...r.ingredients.map((i) => `${i.product?.name ?? ''} ${i.product?.name_nl ?? ''}`)].join(' ')) }))
    .filter((x) => x.score >= 0.4)
    .sort((a, b) => b.score - a.score);
  const best = scored[0];
  if (best && best.score >= 0.75 && (!scored[1] || best.score - scored[1].score >= 0.15)) return doCook(turn, best.r.id, servings, null, leftovers);
  if (scored.length) {
    const options = scored.slice(0, 4);
    return turn.ask(`Which recipe did you make${servings ? ` for ${servings}` : ''}?`, `Welk recept heb je gemaakt${servings ? ` voor ${servings}` : ''}?`,
      [...options.map((x) => ({ label: x.r.title, value: x.r.id })), opt(lang, 'Something else', 'Iets anders', 'other')],
      { kind: 'recipe', servings, options: options.map((x) => ({ id: x.r.id, title: x.r.title })), dish });
  }
  // 4. No recipe: ask what went into it, and take those ingredients out of stock.
  turn.ask(
    `I don't have a recipe for ${dish}. What did you use? For example "pasta, 500 g minced beef and a tin of tomatoes".`,
    `Ik heb geen recept voor ${dish}. Wat heb je gebruikt? Bijvoorbeeld "pasta, 500 g gehakt en een blik tomaten".`,
    [opt(lang, 'Nothing from stock', 'Niets uit de voorraad', 'none')],
    { kind: 'free_cook', dish, servings, asked: 'ingredients' },
  );
}

function runNotCooked(turn: Turn, dish: string, meal?: string | null) {
  const { db, householdId, lang } = turn;
  const { slot, slots } = pickSlot(db, householdId, dish, meal);
  if (!slot) {
    if (slots.length > 1) {
      return turn.ask('Which meal didn’t you cook?', 'Welke maaltijd heb je niet gekookt?', slots.slice(0, 4).map((s) => ({ label: s.title, value: s.id })), { kind: 'skip_slot', slotIds: slots.slice(0, 4).map((s) => s.id) });
    }
    return turn.say("OK. There's no planned meal for that, so nothing changed.", 'Oké. Daar stond geen maaltijd voor gepland, dus er is niets veranderd.');
  }
  skipSlot(turn, slot.id, slot.title);
}

function skipSlot(turn: Turn, slotId: string, title: string) {
  const { db, householdId, lang } = turn;
  updateSlot(db, householdId, slotId, { status: 'skipped' });
  syncPlanToShopping(db, householdId, { quiet: true });
  turn.actions.push({ kind: 'skipped', label: title });
  turn.ask(`OK, ${title} wasn't cooked. Nothing was taken from your inventory. Move it to tomorrow?`, `Oké, ${title} is niet gekookt. Er is niets uit je voorraad gehaald. Naar morgen verplaatsen?`,
    [opt(lang, 'Move to tomorrow', 'Naar morgen', 'yes'), opt(lang, 'No', 'Nee', 'no')], { kind: 'move_slot', slotId, title });
}

function doCook(turn: Turn, recipeId: string, servings: number | null, mealSlotId: string | null = null, leftovers: number | null = null) {
  const { db, householdId, lang, ctx } = turn;
  const r = getRecipe(db, householdId, recipeId);
  const n = servings ?? r.servings;
  const res = cookRecipe(ctx, { recipeId, servings: n, mealSlotId, leftovers: leftovers ? { fridge: leftovers } : undefined, deduct: interactionPrefs(ctx.db, ctx.householdId).autoDeduct });
  turn.mutated = true;
  const used = res.deducted.filter((d) => d.quantity > 0);
  const missing = res.deducted.filter((d) => d.shortfall > 0);
  turn.actions.push({ kind: 'cooked', label: `${r.title} · ${n}` });
  for (const d of used) turn.actions.push({ kind: 'used', label: `${d.name} −${formatQty(d.quantity, d.unit, { lang })}`, productId: d.productId });
  turn.say(`Nice! Logged ${r.title} for ${n} and took ${used.length} ingredient${used.length === 1 ? '' : 's'} out of your inventory.`, `Lekker! ${r.title} voor ${n} gelogd en ${used.length} ingrediënt${used.length === 1 ? '' : 'en'} uit je voorraad gehaald.`);
  if (missing.length) turn.say(`(${missing.map((m) => m.name.toLowerCase()).join(', ')} weren't in stock.)`, `(${missing.map((m) => m.name.toLowerCase()).join(', ')} stond${missing.length > 1 ? 'en' : ''} niet in de voorraad.)`);
  if (!leftovers) {
    turn.ask('Any leftovers?', 'Nog restjes over?', [
      opt(lang, 'No', 'Nee', 'no'),
      opt(lang, '1 portion → fridge', '1 portie → koelkast', 'leftover:fridge:1'),
      opt(lang, '2 portions → fridge', '2 porties → koelkast', 'leftover:fridge:2'),
      opt(lang, '2 portions → freezer', '2 porties → vriezer', 'leftover:freezer:2'),
    ], { kind: 'leftovers', recipeId, title: r.title });
  }
}

// ---------- Undo & corrections ----------

function lastMutation(db: Db, householdId: string, conversationId: string | null | undefined) {
  if (!conversationId) return undefined;
  const rows = db.all<TurnRecord>('SELECT * FROM assistant_turns WHERE household_id = ? AND conversation_id = ? AND batch_id IS NOT NULL ORDER BY created_at DESC, rowid DESC LIMIT 10', householdId, conversationId);
  return rows.find((r) => {
    const resp = parseJson<any>(r.response, {});
    return resp.undoable && !resp.undone;
  });
}

export function undoTurnBatch(db: Db, householdId: string, batchId: string, userId?: string | null) {
  const ctx = newCtx(db, householdId, 'voice', { userId });
  const events = batchExists(db, batchId) ? undoBatch(ctx, batchId) : [];
  // Shopping-list additions made by that command.
  const turn = db.get<TurnRecord>('SELECT * FROM assistant_turns WHERE household_id = ? AND batch_id = ?', householdId, batchId);
  if (turn) {
    const resp = parseJson<any>(turn.response, {});
    for (const a of resp.actions ?? []) if (a.kind === 'listed' && a.shoppingItemId) removeShoppingItem(db, householdId, a.shoppingItemId);
    resp.undone = true;
    db.run('UPDATE assistant_turns SET response = ? WHERE id = ?', JSON.stringify(resp), turn.id);
  }
  db.run('DELETE FROM cook_log WHERE household_id = ? AND batch_id = ?', householdId, batchId);
  // Meal slots cooked by that batch become planned again.
  db.run("UPDATE meal_slots SET status = 'planned', cook_batch_id = NULL WHERE household_id = ? AND cook_batch_id = ?", householdId, batchId);
  return { events: events.length };
}

function runUndo(turn: Turn) {
  const last = lastMutation(turn.db, turn.householdId, turn.input.conversationId);
  if (!last) return turn.say('There is nothing to undo.', 'Er is niets om ongedaan te maken.');
  undoTurnBatch(turn.db, turn.householdId, last.batch_id!, turn.input.userId);
  turn.actions.push({ kind: 'undone', label: last.utterance });
  turn.say(`Undone: "${last.utterance}".`, `Ongedaan gemaakt: "${last.utterance}".`);
}

/** "No, 500 grams" / "no, oat milk": undo the last command and redo it with the change. */
function runCorrection(turn: Turn, text: string, prev: TurnRecord | undefined) {
  const last = lastMutation(turn.db, turn.householdId, turn.input.conversationId);
  const resp = last ? parseJson<any>(last.response, {}) : null;
  const intent: Intent | null = resp?._intent ?? null;
  if (!last || !intent || !('items' in intent) || !intent.items.length) {
    void prev;
    return turn.say("Sorry, what should I change? You can also say \"undo\".", 'Sorry, wat moet ik aanpassen? Je kunt ook "ongedaan maken" zeggen.');
  }
  const fix = parseItem(text.match(/^\d/) || /^(a|an|one|two|three|four|five|six|een|twee|drie|vier|vijf|zes|half)\b/.test(text) ? `${text} __x__` : text);
  const amountOnly = fix && fix.name === '__x__';
  const items = intent.items.map((it, i) => {
    if (i > 0) return it;
    if (amountOnly) return { ...it, amount: fix!.amount, unit: fix!.unit, all: false, vague: false };
    if (fix) return { ...it, name: fix.name, amount: fix.amount ?? it.amount, unit: fix.amount != null ? fix.unit : it.unit };
    return it;
  });
  undoTurnBatch(turn.db, turn.householdId, last.batch_id!, turn.input.userId);
  turn.actions.push({ kind: 'undone', label: last.utterance });
  turn.say('Fixed.', 'Aangepast.');
  runIntent(turn, { ...intent, items } as Intent, undefined, 0.9);
  turn.intentRecord = { ...intent, items } as Intent;
}

// ---------- Questions ----------

function qtyText(s: StockItem, lang: Lang) {
  const q = s.showEstimate ? s.estimated : s.confirmed;
  const approx = s.showEstimate && s.estimated < s.confirmed - 1e-6;
  return `${approx ? L(lang, 'about ', 'ongeveer ') : ''}${formatQty(q, s.product.unit, { lang })}`;
}

function queryItem(turn: Turn, name: string) {
  const { db, householdId, lang } = turn;
  const lo = findLeftover(db, householdId, name, null);
  if (lo) {
    turn.say(`You have ${formatQty(lo.quantity, 'portion')} of ${lo.label.toLowerCase()}${lo.location_kind ? ` in the ${lo.location_kind}` : ''}.`, `Je hebt ${formatQty(lo.quantity, 'portion', { lang })} ${lo.label.toLowerCase()}${lo.location_kind ? ` in de ${lo.location_kind === 'freezer' ? 'vriezer' : 'koelkast'}` : ''}.`);
    return;
  }
  const { product, candidates } = resolveProduct(db, householdId, name);
  const p = product ?? candidates.find((c) => stockOf(db, householdId, c.product.id) > 0)?.product ?? candidates[0]?.product;
  if (!p) return turn.say(`I don't know "${name}" yet.`, `Ik ken "${name}" nog niet.`);
  const s = stockItem(db, householdId, p.id)!;
  const pname = displayName(p, lang).toLowerCase();
  if (!s.lots.length || (s.showEstimate ? s.estimated : s.confirmed) <= 1e-6) {
    turn.say(`You're out of ${pname}.`, `Je hebt geen ${pname} meer.`);
    offerList(turn, [p.id]);
    return;
  }
  let msg = L(lang, `You have ${qtyText(s, lang)} ${pname}`, `Je hebt ${qtyText(s, lang)} ${pname}`);
  if (s.locations.length) msg += L(lang, ` (${s.locations.join(', ').toLowerCase()})`, ` (${s.locations.join(', ').toLowerCase()})`);
  msg += '.';
  if (s.showEstimate && s.estimated < s.confirmed - 1e-6) msg += L(lang, ' That is an estimate.', ' Dat is een schatting.');
  if (s.daysToExpiry != null && s.daysToExpiry <= 3) msg += L(lang, s.daysToExpiry < 0 ? ' It may be past its date.' : ` Use it within ${Math.max(0, s.daysToExpiry)} day${s.daysToExpiry === 1 ? '' : 's'}.`, s.daysToExpiry < 0 ? ' Mogelijk over de datum.' : ` Binnen ${Math.max(0, s.daysToExpiry)} dag${s.daysToExpiry === 1 ? '' : 'en'} gebruiken.`);
  turn.reply.push(msg);
  turn.data = { kind: 'stock', items: [stockView(s, lang)] };
}

function stockView(s: StockItem, lang: Lang) {
  return { productId: s.product.id, name: displayName(s.product, lang), qty: qtyText(s, lang), status: s.status, daysToExpiry: s.daysToExpiry, confidence: s.confidence, category: s.product.category };
}

function queryInventory(turn: Turn, location: string | null) {
  const { db, householdId, lang } = turn;
  const { items, leftovers } = inventorySummary(db, householdId);
  const filtered = items.filter((s) => (s.showEstimate ? s.estimated : s.confirmed) > 1e-6 && (!location || s.lots.some((l) => l.location_kind === location)));
  if (!filtered.length && !leftovers.length) return turn.say('Your inventory is empty.', 'Je voorraad is leeg.');
  const names = filtered.slice(0, 8).map((s) => displayName(s.product, lang).toLowerCase());
  turn.say(
    `You have ${filtered.length} product${filtered.length === 1 ? '' : 's'}${location ? ` in the ${location}` : ''}: ${names.join(', ')}${filtered.length > 8 ? ' and more' : ''}.${leftovers.length ? ` Plus ${leftovers.length} leftover${leftovers.length === 1 ? '' : 's'}.` : ''}`,
    `Je hebt ${filtered.length} product${filtered.length === 1 ? '' : 'en'}${location ? ` in de ${location === 'freezer' ? 'vriezer' : location === 'fridge' ? 'koelkast' : 'voorraadkast'}` : ''}: ${names.join(', ')}${filtered.length > 8 ? ' en meer' : ''}.${leftovers.length ? ` Plus ${leftovers.length} restje${leftovers.length === 1 ? '' : 's'}.` : ''}`,
  );
  turn.data = { kind: 'stock', items: filtered.map((s) => stockView(s, lang)) };
}

function queryLow(turn: Turn) {
  const { db, householdId, lang } = turn;
  const { items } = inventorySummary(db, householdId);
  const low = items.filter((s) => (s.status === 'low' || s.status === 'out') && !s.product.staple);
  const sug = shoppingSuggestions(db, householdId).filter((x) => x.reason === 'out' || x.reason === 'running_low');
  const names = [...new Set([...low.map((s) => displayName(s.product, lang)), ...sug.map((x) => x.name)])];
  if (!names.length) return turn.say("Nothing is running low right now.", 'Er raakt nu niets op.');
  turn.say(`Running low: ${names.slice(0, 8).join(', ').toLowerCase()}.`, `Bijna op: ${names.slice(0, 8).join(', ').toLowerCase()}.`);
  turn.data = { kind: 'stock', items: low.map((s) => stockView(s, lang)) };
}

function queryBuy(turn: Turn) {
  const { db, householdId } = turn;
  const list = listShopping(db, householdId);
  const sug = shoppingSuggestions(db, householdId);
  const onList = list.groups.flatMap((g) => g.items.map((i) => i.name.toLowerCase()));
  const parts: string[] = [];
  if (onList.length) parts.push(L(turn.lang, `Your list has ${onList.length} item${onList.length === 1 ? '' : 's'}: ${onList.slice(0, 6).join(', ')}${onList.length > 6 ? '…' : ''}.`, `Je lijst heeft ${onList.length} item${onList.length === 1 ? '' : 's'}: ${onList.slice(0, 6).join(', ')}${onList.length > 6 ? '…' : ''}.`));
  if (sug.length) parts.push(L(turn.lang, `I'd also suggest ${sug.slice(0, 5).map((s) => s.name.toLowerCase()).join(', ')}.`, `Ik zou ook ${sug.slice(0, 5).map((s) => s.name.toLowerCase()).join(', ')} halen.`));
  if (!parts.length) parts.push(L(turn.lang, "Nothing needed right now. Plan a few meals and I'll work out the list.", 'Er is nu niets nodig. Plan een paar maaltijden, dan maak ik de lijst.'));
  turn.reply.push(parts.join(' '));
  turn.data = { kind: 'suggestions', items: sug };
}

function queryExpiring(turn: Turn) {
  const { db, householdId, lang } = turn;
  const { items, leftovers } = inventorySummary(db, householdId);
  const soon = items.filter((s) => s.daysToExpiry != null && s.daysToExpiry <= 3 && s.confirmed > 0).sort((a, b) => a.daysToExpiry! - b.daysToExpiry!);
  const lo = leftovers.filter((l) => l.days_to_expiry != null && l.days_to_expiry <= 2 && l.location_kind !== 'freezer');
  const names = [...soon.map((s) => displayName(s.product, lang).toLowerCase()), ...lo.map((l) => `${l.title.toLowerCase()} (${L(lang, 'leftovers', 'restjes')})`)];
  if (!names.length) return turn.say('Nothing is about to expire.', 'Er gaat niets binnenkort over de datum.');
  turn.say(`Use soon: ${names.join(', ')}.`, `Snel gebruiken: ${names.join(', ')}.`);
  turn.data = { kind: 'expiring', items: soon.map((s) => stockView(s, lang)) };
}

export function recipesForFilters(db: Db, householdId: string, f: CookFilters): RecipeMatch[] {
  let res = searchRecipes(db, householdId, {
    cuisine: f.cuisine ?? undefined,
    maxMinutes: f.maxMinutes ?? undefined,
    diet: f.diet ?? undefined,
    ingredient: f.ingredient && f.ingredient !== 'vegetables' ? f.ingredient : undefined,
    sort: f.highProtein ? 'protein' : f.cheap ? 'cost' : 'best',
    tag: f.meal === 'breakfast' ? 'breakfast' : undefined,
  });
  if (f.ingredient === 'vegetables') res = res.filter((m) => m.recipe.ingredients.filter((i) => i.product?.category === 'produce' && m.ingredients.find((s) => s.position === i.position)?.status === 'have').length >= 2);
  if (f.useUp) res = res.filter((m) => m.matchPct >= 50).sort((a, b) => b.score - a.score);
  if (f.highProtein) res = res.filter((m) => (m.recipe.nutritionPerServing?.protein ?? 0) >= 20);
  if (f.meal === 'dinner') res = res.filter((m) => !m.recipe.tags.includes('breakfast'));
  return res;
}

function queryCook(turn: Turn, f: CookFilters) {
  const { db, householdId } = turn;
  const res = recipesForFilters(db, householdId, f).slice(0, 5);
  turn.clientAction = null;
  if (!res.length) {
    turn.say('I found no matching recipes. Say “make a recipe from what I have”, or loosen the filters.', 'Geen passende recepten gevonden. Zeg “maak een recept van wat ik heb”, of verruim de filters.');
    return;
  }
  const top = res.slice(0, 3).map((m) => `${m.recipe.title} (${m.matchPct}%)`);
  turn.say(`How about ${top.join(', ')}?`, `Wat dacht je van ${top.join(', ')}?`);
  turn.data = {
    kind: 'recipes',
    items: res.map((m) => ({ id: m.recipe.id, title: m.recipe.title, emoji: m.recipe.emoji, color: m.recipe.color, matchPct: m.matchPct, minutes: m.recipe.prep_minutes + m.recipe.cook_minutes, missing: m.missing.map((x) => x.name), reasons: m.reasons, origin: m.recipe.origin })),
  };
}

function recipeCard(r: any) {
  return { id: r.id, title: r.title, emoji: r.emoji, color: r.color, matchPct: null, minutes: r.prep_minutes + r.cook_minutes, missing: [], reasons: [], origin: r.origin };
}

/** "Save this recipe: chicken fajitas with peppers, onion, rice and avocado". */
function saveRecipeFromSentence(turn: Turn, text: string) {
  const { db, householdId, lang } = turn;
  try {
    const q = recipeFromSentence(db, householdId, text, { lang });
    turn.data = { kind: 'recipes', items: [recipeCard(q.recipe)] };
    if (q.existing) return turn.say(`Saved ${q.recipe.title} from the library to My recipes.`, `${q.recipe.title} uit de bibliotheek bewaard in Mijn recepten.`);
    const n = q.recipe.ingredients.length;
    const how = q.template ? L(lang, `method and amounts from ${q.template}`, `werkwijze en hoeveelheden van ${q.template}`) : q.guessed ? L(lang, 'amounts estimated', 'hoeveelheden geschat') : '';
    const miss = q.unmatched.length ? L(lang, ` I didn't recognise ${q.unmatched.join(', ')}.`, ` ${q.unmatched.join(', ')} herkende ik niet.`) : '';
    turn.say(`Saved ${q.recipe.title} to My recipes: ${n} ingredients for ${q.recipe.servings}${how ? `, ${how}` : ''}.${miss}`, `${q.recipe.title} bewaard in Mijn recepten: ${n} ingrediënten voor ${q.recipe.servings}${how ? `, ${how}` : ''}.${miss}`);
  } catch (e: any) {
    turn.say(e.message, e.message);
  }
}

/** "Make a recipe from what I have": a use-it-up recipe from the food at most risk. */
function makeRecipeFromStock(turn: Turn) {
  const { db, householdId, lang } = turn;
  try {
    const r = recipeFromStock(db, householdId, { lang });
    turn.data = { kind: 'recipes', items: [recipeCard(r.recipe)] };
    turn.say(`Here's ${r.recipe.title}, using ${r.usesFirst.join(', ')} first. Saved to My recipes.`, `Hier is ${r.recipe.title}, met ${r.usesFirst.join(', ')} eerst. Bewaard in Mijn recepten.`);
  } catch (e: any) {
    turn.say(e.message, e.message);
  }
}

const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);
