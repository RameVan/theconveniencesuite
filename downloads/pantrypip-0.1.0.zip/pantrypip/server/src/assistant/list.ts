// Spoken shopping hauls. Speech rarely has commas ("milk eggs bread two kilos of potatoes"), so a run-on
// phrase is split into the products it names, longest match first ("chicken breast" stays one item).
import type { Db } from '../db/db.ts';
import { parse, parseItem, type ItemSpec, type Lang } from './parser.ts';
import { listProducts, normalizeText, stem, resolveProduct, guessDefaults, displayName, type Product } from '../domain/products.ts';
import { parseNumber, toBase, formatQty } from '../domain/units.ts';

const NOISE = new Set('uh uhm um erm er hmm oh ah eh euh ehm nou then also and en dan daarna verder ook plus okay ok oke so yeah'.split(' '));
const MAX_SPAN = 6;

const stems = (s: string) => normalizeText(s).split(' ').filter(Boolean).map(stem);

/** Every name a product answers to, as stemmed word lists. */
function nameIndex(products: Product[]): string[][] {
  const out: string[][] = [];
  for (const p of products) for (const n of [p.name, p.name_nl ?? '', ...p.synonyms]) if (n) out.push(stems(n));
  return out;
}

/** True when every word of the name appears in one product name ("milk" ⊂ "semi-skimmed milk"). */
function namesAProduct(name: string, index: string[][]): boolean {
  const q = stems(name);
  return q.length > 0 && index.some((n) => q.every((w) => n.includes(w)));
}

/**
 * Split one item phrase into several when it names two or more known products.
 * Returns null when it is really one item (or unknown words with at most one product).
 */
export function segmentPhrase(phrase: string, products: Product[] | string[][]): ItemSpec[] | null {
  const tokens = phrase.trim().split(/\s+/).filter(Boolean);
  if (tokens.length < 2) return null;
  const index = (products.length && Array.isArray(products[0]) ? products : nameIndex(products as Product[])) as string[][];
  const out: ItemSpec[] = [];
  let unmatched: string[] = [];
  let found = 0;
  const flush = () => {
    const words = unmatched.filter((w) => !NOISE.has(w));
    unmatched = [];
    const spec = words.length ? parseItem(words.join(' ')) : null;
    if (spec) out.push(spec);
  };
  let i = 0;
  while (i < tokens.length) {
    let hit: ItemSpec | null = null;
    let end = i;
    for (let j = Math.min(tokens.length, i + MAX_SPAN); j > i; j--) {
      // Amounts lead an item ("2 kg potatoes", "half a loaf"); a number further in starts the next one.
      const lead = parseNumber(tokens[i]) != null ? 2 : 1;
      if (tokens.slice(i + lead, j).some((w) => parseNumber(w) != null)) continue;
      const spec = parseItem(tokens.slice(i, j).join(' '));
      if (spec && namesAProduct(spec.name, index)) {
        hit = spec;
        end = j;
        break;
      }
    }
    if (hit) {
      flush();
      out.push(hit);
      found++;
      i = end;
    } else {
      unmatched.push(tokens[i]);
      i++;
    }
  }
  flush();
  return found >= 2 ? out : null;
}

/** Expand run-on items ("milk eggs bread") into one item per product. Items that already match one product stay. */
export function expandRunOn(db: Db, householdId: string, items: ItemSpec[]): ItemSpec[] {
  let index: string[][] | null = null;
  return items.flatMap((item) => {
    if (item.name.split(' ').length < 2) return [item];
    if (resolveProduct(db, householdId, item.name).product) return [item];
    index ??= nameIndex(listProducts(db, householdId));
    const phrase = `${item.amount != null ? `${item.amount} ${item.unit ?? ''} ` : ''}${item.name}`;
    const parts = segmentPhrase(phrase, index);
    if (!parts) return [item];
    return parts.map((p) => ({ ...p, all: item.all || p.all, vague: item.vague || p.vague, location: p.location ?? item.location ?? null }));
  });
}

export interface ListLine {
  said: string;
  productId: string | null;
  name: string;
  category: string;
  unit: 'g' | 'ml' | 'pcs';
  qty: number;
  qtyLabel: string;
  packageSize: number;
  pieceName: string | null;
  isNew: boolean;
  location: string | null;
  candidates: { id: string; name: string }[];
}

/** Read a spoken or typed list of things bought, without changing anything. */
export function readBoughtList(db: Db, householdId: string, text: string, lang: Lang): { lang: Lang; lines: ListLine[] } {
  // "klaar" / "done" at the end only ends list mode.
  const body = text.replace(/[.!?]+/g, ',').replace(/\b(that'?s it|that'?s all|done|finished|klaar|dat was het|dat is alles)\s*,?\s*$/i, '');
  const r = parse(`${lang === 'nl' ? 'gekocht' : 'bought'} ${body}`, { langHint: lang });
  const specs = expandRunOn(db, householdId, r.intents.flatMap((i) => ('items' in i ? i.items : [])));
  const lines = specs.map((s): ListLine => {
    const { product, candidates } = resolveProduct(db, householdId, s.name);
    const p = product ?? (candidates.length && candidates[0].score >= 0.6 ? candidates[0].product : null);
    const said = `${s.amount != null ? `${s.amount} ${s.unit ?? ''} ` : ''}${s.name}`.replace(/\s+/g, ' ').trim();
    if (!p) {
      const d = guessDefaults(s.name);
      const qty = s.amount == null ? d.package_size : safeQty(s, { unit: d.unit, package_size: d.package_size, piece_size: null }) ?? d.package_size;
      return { said, productId: null, name: s.name.charAt(0).toUpperCase() + s.name.slice(1), category: d.category, unit: d.unit, qty, qtyLabel: formatQty(qty, d.unit, { lang }), packageSize: d.package_size, pieceName: null, isNew: true, location: s.location ?? null, candidates: [] };
    }
    const qty = s.amount == null ? p.package_size : safeQty(s, p) ?? p.package_size;
    return {
      said,
      productId: p.id,
      name: displayName(p, lang),
      category: p.category,
      unit: p.unit,
      qty,
      qtyLabel: formatQty(qty, p.unit, { pieceName: p.piece_name, lang }),
      packageSize: p.package_size,
      pieceName: p.piece_name,
      isNew: false,
      location: s.location ?? null,
      candidates: product ? [] : candidates.slice(0, 3).map((c) => ({ id: c.product.id, name: displayName(c.product, lang) })),
    };
  });
  return { lang: r.lang, lines };
}

function safeQty(s: ItemSpec, p: { unit: 'g' | 'ml' | 'pcs'; package_size: number; piece_size?: number | null }): number | null {
  try {
    return toBase(s.amount ?? 1, s.unit, p).qty;
  } catch {
    return null;
  }
}
