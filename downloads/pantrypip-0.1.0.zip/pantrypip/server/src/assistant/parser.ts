// Deterministic natural-language parser for grocery commands in English and Dutch.
// Turns an utterance into structured intents. It never touches the database; the engine
// resolves product names and executes intents through the ledger.
import { parseNumber, unitDef, NUMBER_WORDS } from '../domain/units.ts';

export type Lang = 'en' | 'nl';

export interface ItemSpec {
  name: string;
  amount: number | null;     // null = not stated
  unit: string | null;       // surface unit word as spoken ('liter', 'g', 'pak', ...)
  all: boolean;              // "the rest", "finished", "the remaining"
  vague: boolean;            // "some", "a bit of"
  location?: string | null;  // fridge | freezer | pantry
}

export type Intent =
  | { type: 'add_inventory'; items: ItemSpec[]; explicit: boolean }
  | { type: 'consume'; items: ItemSpec[] }
  | { type: 'discard'; items: ItemSpec[]; reason: string }
  | { type: 'open'; items: ItemSpec[] }
  | { type: 'set_quantity'; items: ItemSpec[] }
  | { type: 'shopping_add'; items: ItemSpec[] }
  | { type: 'shopping_remove'; items: ItemSpec[] }
  | { type: 'add_ambiguous'; items: ItemSpec[] } // "add coffee": inventory or list?
  | { type: 'freeze'; items: ItemSpec[] }
  | { type: 'thaw'; items: ItemSpec[] }
  | { type: 'cooked'; dish: string; servings: number | null; leftovers: number | null; meal?: string | null }
  | { type: 'not_cooked'; dish: string; meal?: string | null }
  | { type: 'query_item'; name: string }
  | { type: 'query_inventory'; location: string | null }
  | { type: 'query_low' }
  | { type: 'query_buy' }
  | { type: 'query_expiring' }
  | { type: 'query_cook'; filters: CookFilters }
  | { type: 'save_recipe'; text: string }
  | { type: 'stock_recipe' }
  | { type: 'scan_receipt' }
  | { type: 'scan_barcode' }
  | { type: 'undo' }
  | { type: 'correction'; text: string }
  | { type: 'confirm'; yes: boolean }
  | { type: 'answer'; text: string } // bare reply to a clarification ("about 250 ml")
  | { type: 'unknown' };

export interface CookFilters {
  query: string | null;
  ingredient: string | null;
  cuisine: string | null;
  maxMinutes: number | null;
  highProtein: boolean;
  cheap: boolean;
  diet: string | null;
  useUp: boolean;
  meal: string | null;
}

export interface ParseResult {
  lang: Lang;
  intents: Intent[];
  confidence: number; // 0..1, how sure the rule parser is
}

const NL_MARKERS = /\b(ik|heb|hebben|we|wij|de|het|een|gekocht|gehaald|gebruikt|gegeten|gedronken|op|nog|wat|hoeveel|zet|lijst|weg|gooi|bedorven|koelkast|vriezer|voorraad|toevoegen|voeg|moet|kan|koken|maken|nodig|ingevroren|porties?|liter|gram|stuks?|eieren|melk|kip|uien|boodschappen|graag|alsjeblieft|is|zijn|niet|nee|ja|mijn|onze|voor|personen|mensen|over|verwijder|haal|ongedaan|bijna|raakt|recept|iets|snel|goedkoop|eiwit)\b/g;
const EN_MARKERS = /\b(i|have|has|we|the|a|an|bought|got|used|ate|drank|finished|remove|add|my|to|of|some|what|how|much|many|left|list|shopping|need|cook|make|can|should|buy|froze|frozen|freezer|fridge|for|people|portions?|it|gone|bad|please|is|are|not|no|yes|our|running|low|out|undo)\b/g;

export function detectLang(text: string, fallback: Lang = 'en'): Lang {
  const t = text.toLowerCase();
  const nl = (t.match(NL_MARKERS) ?? []).length;
  const en = (t.match(EN_MARKERS) ?? []).length;
  if (nl === en) return fallback;
  return nl > en ? 'nl' : 'en';
}

function clean(text: string): string {
  return packCounts(text
    .toLowerCase())
    .replace(/[“”"!?¿¡]/g, ' ')
    .replace(/(\d),(\d)/g, '$1.$2')
    .replace(/(\d)\s*(kg|g|gr|ml|l|cl|dl)\b/g, '$1 $2')
    .replace(/[.;:]+(\s|$)/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

const LOCATIONS: [RegExp, string][] = [
  [/\b(in|into|to|naar|in de|in het)?\s*(the\s+)?(freezer|vriezer|diepvries)\b/, 'freezer'],
  [/\b(in|into|to|naar|in de|in het)?\s*(the\s+)?(fridge|refrigerator|koelkast|ijskast)\b/, 'fridge'],
  [/\b(in|into|to|naar|in de|in het)?\s*(the\s+)?(pantry|cupboard|voorraadkast|kast|voorraad)\b/, 'pantry'],
];

// Words that carry no product meaning once the intent is known.
const FILLER = new Set(
  (
    'i we you just already also have has had got the my our your some any of to a an and please also too now today this that these those it its ' +
    'ik we wij je jij net al ook heb hebt heeft hebben de het een mijn onze jouw van wat graag alsjeblieft even nu vandaag dit dat deze die er nog ' +
    'groceries grocery inventory stock boodschappen voorraad items item things stuff spullen'
  ).split(' '),
);

const ALL_WORDS = /\b(the rest of( the)?|rest of( the)?|remaining|all( of)?( the)?|the last( of)?( the)?|everything|whole|entire|alle|de rest( van)?( de| het)?|resterende|overgebleven|overige|hele|helemaal|laatste)\b/;
const VAGUE_WORDS = /\b(some|a bit( of)?|a little( bit)?( of)?|a few|bit of|wat|een beetje|beetje|een paar|enkele|een stuk(je)?)\b/;

/** Parse one item phrase: "2 litres of milk", "half a loaf of bread", "de rest van de spinazie". */
/** "a pack of six chicken breasts", "een doos met 12 eieren": the count inside the pack is what you got. */
function packCounts(s: string): string {
  return s.replace(/\b(a|an|one|een|\d+)\s+(packs?|packets?|boxes?|bags?|trays?|cartons?|nets?|pak|pakje|pakken|doos|doosje|zak|zakje|bakje|bakjes|netje)\s+(?:of|met|van)\s+(\d+|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|dozen|twee|drie|vier|vijf|zes|zeven|acht|negen|tien|twaalf)\b/g, (_m, a: string, _pk: string, n: string) => {
    const num = (x: string) => (/^\d+$/.test(x) ? Number(x) : NUMBER_WORDS[x] ?? 1);
    return `${num(a) * num(n)}`;
  });
}

export function parseItem(phrase: string): ItemSpec | null {
  let p = packCounts(` ${phrase.trim()} `);
  // "half the chicken", "a quarter of the cheese", "de helft van de kip": part of what's there.
  const frac = p.match(/^\s*(?:(half|a half|a quarter|a third|quarter|third)\s+(?:of\s+)?(?:(?:the|my|our)\s+)?|(?:de\s+)?(helft|een kwart|kwart|een derde)\s+(?:van\s+)?(?:(?:de|het|mijn|onze)\s+)?)(.+)$/);
  // Not "half a loaf" or "half a kilo": those are amounts.
  if (frac && !/^(a|an|een)\s/.test(frac[3]) && !unitDef(frac[3].split(/\s+/)[0])) {
    const w = (frac[1] ?? frac[2]).replace(/^(a|een)\s+/, '');
    const f = /half|helft/.test(w) ? 0.5 : /quarter|kwart/.test(w) ? 0.25 : 1 / 3;
    const rest = parseItem(frac[3]);
    if (rest) return { ...rest, amount: f, unit: '__fraction__', all: false, vague: false };
  }
  let location: string | null = null;
  for (const [re, loc] of LOCATIONS) {
    if (re.test(p)) {
      location = loc;
      p = p.replace(re, ' ');
    }
  }
  let all = false;
  if (ALL_WORDS.test(p)) {
    all = true;
    p = p.replace(ALL_WORDS, ' ');
  }
  let vague = false;
  // "wat" is only vague when it precedes a noun ("wat melk"), so check before stripping.
  if (VAGUE_WORDS.test(p) && !/^\s*wat\s*$/.test(p)) {
    vague = true;
    p = p.replace(VAGUE_WORDS, ' ');
  }
  const tokens = p.trim().split(/\s+/).filter(Boolean);
  let amount: number | null = null;
  let unit: string | null = null;
  let i = 0;
  // skip leading articles/filler before the amount ("about", "ongeveer", "zo'n")
  while (i < tokens.length && /^(about|around|approximately|roughly|ongeveer|zo'n|zon|circa|ca|bijna|almost|like|the|de|het|my|mijn)$/.test(tokens[i])) i++;
  // number (possibly "half a", "a couple of", "anderhalve", "1.5")
  if (i < tokens.length) {
    const t = tokens[i];
    const n = parseNumber(t);
    if (n != null && !(t === 'a' || t === 'an' || t === 'een') ) {
      amount = n;
      i++;
      if (tokens[i] === 'a' || tokens[i] === 'an' || tokens[i] === 'een') i++; // "half a loaf"
    } else if ((t === 'a' || t === 'an' || t === 'een') && i + 1 < tokens.length) {
      const next = tokens[i + 1];
      if (next === 'couple' || next === 'paar') {
        amount = 2;
        i += 2;
      } else if (next === 'dozen') {
        amount = 12;
        i += 2;
      } else if (next === 'half' || next === 'halve') {
        amount = 0.5;
        i += 2;
      } else if (unitDef(next) || /^(bag|bottle|pack|can|jar|box|loaf|bunch|zak|fles|pak|blik|pot|doos|bos|net)/.test(next)) {
        amount = 1;
        i += 1;
      } else {
        amount = 1;
        i += 1;
      }
    }
  }
  if (amount != null && i < tokens.length && unitDef(tokens[i])) {
    unit = tokens[i];
    i++;
  }
  if (i < tokens.length && /^(of|van|aan)$/.test(tokens[i])) i++;
  let nameTokens = tokens.slice(i).filter((t) => !FILLER.has(t));
  // Trailing amount: "milk 2 liter", "melk, 2 pakken"
  if (amount == null && nameTokens.length >= 2) {
    const last = nameTokens[nameTokens.length - 1];
    const prev = nameTokens[nameTokens.length - 2];
    if (unitDef(last) && parseNumber(prev) != null) {
      amount = parseNumber(prev);
      unit = last;
      nameTokens = nameTokens.slice(0, -2);
    } else if (parseNumber(last) != null) {
      amount = parseNumber(last);
      nameTokens = nameTokens.slice(0, -1);
    }
  }
  // Unit words used as nouns: "2 slices of bread" handled; "two boterhammen" → bread
  if (!nameTokens.length && unit && /^(boterham|boterhammen|sneetje|sneetjes)$/.test(unit)) nameTokens = ['brood'];
  const name = nameTokens.join(' ').replace(/\b(left|over|meer|more)\b/g, '').trim();
  if (!name) return null;
  return { name, amount, unit, all, vague, location };
}

/** Split "milk, eggs and two onions" into item phrases. */
export function splitItems(s: string): string[] {
  return s
    .split(/\s*(?:,|\band also\b|\band then\b|\band\b|\ben ook\b|\ben\b|&|\bplus\b|\bas well as\b|\bevenals\b|\bthen\b|\balso\b|\bdaarna\b|\bverder\b)\s*/)
    .map((x) => x.trim())
    .filter((x) => x && !FILLER.has(x));
}

function items(s: string): ItemSpec[] {
  return splitItems(s).map(parseItem).filter((x): x is ItemSpec => !!x);
}

const strip = (s: string, re: RegExp) => s.replace(re, ' ').replace(/\s+/g, ' ').trim();

// ---------- Patterns ----------

const UNDO = /^(undo|cancel( that)?|scratch that|revert|undo that|that'?s wrong|that was wrong|ongedaan( maken)?|maak (dat |het )?ongedaan|draai (dat |het )?terug|terugdraaien|annuleer|dat klopt niet|klopt niet)\b/;
const YES = /^(yes|yeah|yep|sure|ok|okay|correct|right|do it|go ahead|please do|ja|jawel|jazeker|klopt|prima|doe maar|graag|goed|oke|oké)\b/;
const NO = /^(no|nope|nah|cancel|stop|never ?mind|nee|neen|niet doen|laat maar|stop)\b\s*$/;
const CORRECTION = /^(?:no|nee|not|niet|actually|eigenlijk|sorry|oops|oeps|i mean|i meant|ik bedoel(?:de)?)[,\s]+(?:i meant |i mean |it was |it's |make it |ik bedoel(?:de)? |het was |maak er |het is )?(?<rest>.+)$/;

const SCAN_RECEIPT = /\b(receipt|receipts|kassabon|bonnetje|bon)\b/;
const SCAN_BARCODE = /\b(barcode|bar code|streepjescode|ean|scan (this|it|dit|het) (product|item))\b/;

const Q_HOW_MUCH = /^(?:how much|how many|hoeveel)\s+(.+?)(?:\s+(?:do|have|did|is|are|heb|hebben|is er|zijn er|ligt er|liggen er|staat er)\b.*)?$/;
const Q_DO_I_HAVE = /^(?:do (?:i|we) (?:still )?have|have (?:i|we) got|is there (?:still )?|are there (?:still )?|heb ik (?:nog )?|hebben we (?:nog )?|is er (?:nog )?|zijn er (?:nog )?)(?:any |some |nog |genoeg |enough )?(.+?)(?: left| over| in (?:the )?\w+| in huis| nog)?$/;
const Q_INVENTORY = /(what|which)\b.*\b(do (i|we) have|have (i|we) got|groceries|is in|are in|in stock|in (my|the|our) (fridge|freezer|pantry))|^wat (heb ik|hebben we|is er|ligt er|zit er|staat er)\b|^(show|list|toon|laat).*(inventory|voorraad|groceries|fridge|freezer|koelkast|vriezer)|^(inventory|voorraad)$/;
const Q_LOW = /(running low|run(ning)? out|almost out|nearly out|low on|out of stock|raakt op|raken op|bijna op|is bijna op|wat is op|wat raakt|wat gaat op|tekort)/;
const Q_BUY = /(what (should|do|must) (i|we) (buy|get|shop)|what do (i|we) need|shopping suggestions|what'?s on (my|the) (shopping )?list|wat (moet|moeten) (ik|we) (kopen|halen|nog halen)|wat hebben we nodig|wat staat er op (de|mijn) lijst|boodschappen(lijst)? deze week)/;
const Q_EXPIRING = /(expir|going off|go(es)? off|go bad|use (up )?first|use soon|over de datum|houdbaarheid|houdbaar|bederft|bederven|wat moet (eerst )?op|wat moet weg|tht|vervalt)/;
const Q_COOK = /(what (can|should|could) (i|we) (cook|make|eat|have for)|what'?s for (dinner|lunch|breakfast)|recipe|recipes|meal idea|dinner idea|give me (a|an|some)|find (me )?(something|a recipe|a meal|a dinner)|suggest (a|some|something)|make something|cook something|i want something|wat (kan|zal|moet) (ik|we) (koken|maken|eten)|recept|recepten|iets (lekkers|met|snels|goedkoops)|geef me (een|iets)|wat eten we)/;

const SHOP_LIST = /\b(shopping list|grocery list|groceries list|the list|my list|to buy|buy list|boodschappenlijst|boodschappen lijst|boodschappenlijstje|op de lijst|lijst|lijstje)\b/;
const SHOP_NEED = /^(we need|i need|we'?re out of|we are out of|need to (buy|get)|remind me to buy|don'?t forget|we moeten|ik moet|we hebben .+ nodig|ik heb .+ nodig|koop|kopen|haal|halen|vergeet .+ niet)\b/;
const SHOP_REMOVE = /\b(remove|delete|take|cross|strike|scrap|verwijder|haal|schrap|streep)\b.*\b(from|off|van|af)\b.*\b(list|lijst|lijstje|boodschappenlijst)\b/;

const FREEZE = /\b(froze|freeze|frozen|freezing|put .* in the freezer|ingevroren|invriezen|vries .* in|in de vriezer gezet|in de vriezer gedaan)\b/;
const THAW = /\b(defrost|defrosted|thaw|thawed|ontdooi|ontdooid|ontdooien|uit de vriezer)\b/;
// "I've cooked X", "cooked the dal", "made the traybake", "we had chili", "dinner is done",
// "ik heb X gekookt", "net pannenkoeken gebakken", "vanavond chili gemaakt", "we hebben X gegeten".
const COOKED = /^(?:(?:i|we)(?:'ve| have)? )?(?:just |already |finally )?(?:cooked|made|prepared|baked|roasted|grilled)\b|\b(?:i|we)(?:'ve| have)? (?:just |already )?(?:cooked|made|prepared|baked|had|ate|eaten)\b|\b(?:gekookt|gemaakt|klaargemaakt|gebakken|bereid)\b|\bwe hebben .+ gegeten\b|\b(?:dinner|lunch|breakfast|the meal|food) (?:is|was) (?:done|ready|cooked)\b|\b(?:het )?(?:eten|avondeten) is (?:klaar|gekookt)\b/;
// Negations must never deduct ingredients: "I didn't cook the curry", "we skipped the bolognese", "ik heb de curry niet gekookt".
const NOT_COOKED = /\b(?:didn'?t|did not|haven'?t|have not|never got to|won'?t|will not) (?:cook|make|have)\b|\b(?:skip|skipped|skipping)\b|\bniet (?:gekookt|gemaakt|gegeten|koken|maken)\b|\b(?:overgeslagen|sla .+ over|slaan .+ over)\b/;
const MEAL_WORDS: [RegExp, string][] = [
  [/\b(dinner|supper|avondeten|diner|avondmaal|the meal|het eten|eten)\b/, 'dinner'],
  [/\b(lunch|middageten)\b/, 'lunch'],
  [/\b(breakfast|ontbijt)\b/, 'breakfast'],
];
// Damage: "an egg broke in transit", "I dropped the yoghurt", "2 eieren waren kapot".
const DAMAGED = /\b(broke|broken|cracked|smashed|dropped|squashed|crushed|burst|leaked|leaking|damaged|split open|kapot|gebroken|gebarsten|gevallen|laten vallen|geplet|lek|lekte|beschadigd)\b/;
const DISCARD = /(broke|broken|cracked|smashed|dropped|squashed|crushed|burst|leaked|leaking|damaged|kapot|gebroken|gebarsten|gevallen|laten vallen|geplet|beschadigd|gone bad|went bad|has gone off|is off|expired|out of date|spoiled|spoilt|rotten|rotted|mouldy|moldy|threw (away|out)|throw (away|out)|thrown (away|out)|tossed|binned|discard|in the bin|bedorven|beschimmeld|schimmel|over de datum|weggegooid|gooi .* weg|weg ?gooien|slecht geworden|niet meer goed|verrot|zuur geworden)/;
const FINISHED = /(\bfinished\b|\bran out of\b|\bused up\b|\bused the last\b|\bate the last\b|\bdrank the last\b|\ball gone\b|\bis (op|leeg)\b|\bzijn op\b|\bopgemaakt\b|\bopgedronken\b|\bopgegeten\b|\bis leeg\b|\bno more\b|\bout of\b|\bgeen .+ meer\b)/;
const SET_QTY = /^(?:(?:i|we) (?:only |still )?(?:have|got)|there (?:is|are) (?:only |still )?|(?:ik heb|we hebben|er is|er zijn) (?:nog )?(?:maar )?|(?:nog|only|still) )(.+?)\s*(?:left|over|remaining|nog|meer)?$/;
const CONSUME = /\b(used|use|using|ate|eaten|eat|drank|drunk|drink|consumed|had|took|taken|take out|took out|remove|removed|minus|gebruikt|gegeten|gedronken|op ?gemaakt|verbruikt|genomen|haal|eruit|verwijder|weghalen|gepakt|af)\b/;
const ADD = /\b(bought|buy|got|get|picked up|purchased|add|added|put|stocked|restocked|received|delivered|gekocht|gehaald|toevoegen|toegevoegd|voeg|bijgekocht|erbij|binnen|geleverd|zet|gezet|gelegd|leg)\b/;

const COOK_VERBS = /\b(i (just )?(cooked|made|prepared|baked)|we (just )?(had|ate|cooked|made)|just|i('ve| have)|ik heb|we hebben|net|gekookt|gemaakt|klaargemaakt|gebakken|gegeten|cooked|made|prepared|baked|had|ate)\b/g;
const VERB_WORDS = /\b(i|we|just|have|has|had|got|bought|buy|picked up|purchased|add|added|put|stocked|restocked|received|delivered|used|use|using|ate|eaten|eat|drank|drunk|drink|consumed|took|taken|take out|took out|remove|removed|minus|finished|ran out of|used up|threw away|throw away|thrown away|threw out|discard|discarded|froze|freeze|frozen|defrost|defrosted|thaw|thawed|ik|wij|heb|hebben|gekocht|gehaald|toevoegen|toegevoegd|voeg|toe|bijgekocht|erbij|binnen|geleverd|zet|gezet|gelegd|leg|gebruikt|gegeten|gedronken|opgemaakt|verbruikt|genomen|haal|eruit|verwijder|weghalen|weggegooid|gooi|weg|ingevroren|invriezen|vries|in|ontdooid|ontdooi|net|is|zijn|op|leeg|it|has gone bad|gone bad|went bad|is off|expired|spoiled|rotten|mouldy|moldy|bedorven|beschimmeld|over de datum|slecht geworden|because|want|omdat|since|uit|from|out|of|the)\b/g;

function cookFilters(t: string): CookFilters {
  const minutes = t.match(/(?:under|less than|within|in|max(?:imum)?|binnen|onder|minder dan|in)\s+(\d+)\s*(?:min|minutes|minuten)/);
  const cuisines: [RegExp, string][] = [
    [/\b(italian|italiaans|italiaanse)\b/, 'Italian'], [/\b(mexican|mexicaans|mexicaanse)\b/, 'Mexican'], [/\b(thai|thaise?)\b/, 'Thai'],
    [/\b(indian|indiaas|indiase)\b/, 'Indian'], [/\b(chinese|chinees|aziatisch|asian)\b/, 'Chinese'], [/\b(dutch|hollands|hollandse|nederlands)\b/, 'Dutch'],
    [/\b(greek|grieks|griekse)\b/, 'Greek'], [/\b(middle eastern|midden-oosters)\b/, 'Middle Eastern'], [/\b(french|frans|franse)\b/, 'French'],
  ];
  const diet = /\b(vegan|veganistisch)\b/.test(t) ? 'vegan' : /\b(vegetarian|vegetarisch|veggie|vega)\b/.test(t) ? 'vegetarian' : /\b(gluten[- ]free|glutenvrij)\b/.test(t) ? 'gluten-free' : null;
  const withM = t.match(/\b(?:with|using|met)\s+(?:my\s+|mijn\s+|the\s+|de\s+)?(?:remaining\s+|resterende\s+|overgebleven\s+)?([a-zÀ-ſ ]+?)(?=\s+(?:that|in|for|tonight|vanavond|voor|which|under|binnen)|$)/);
  const meal = /\b(breakfast|ontbijt)\b/.test(t) ? 'breakfast' : /\b(lunch)\b/.test(t) ? 'lunch' : /\b(dinner|avondeten|diner|vanavond)\b/.test(t) ? 'dinner' : null;
  let ingredient = withM ? withM[1].trim() : null;
  if (ingredient && /^(what i have|wat ik heb|what we have|wat we hebben|stuff|things|everything)$/.test(ingredient)) ingredient = null;
  const useUp = /\b(remaining|leftover|use up|using up|before it goes|resterende|overgebleven|opmaken|restjes|restje|what i have|wat ik heb|what we have|wat we hebben|in my fridge|in de koelkast)\b/.test(t);
  if (ingredient && /^(vegetables|veg|veggies|groente|groenten)$/.test(ingredient)) ingredient = 'vegetables';
  return {
    query: null,
    ingredient,
    cuisine: cuisines.find(([re]) => re.test(t))?.[1] ?? null,
    maxMinutes: minutes ? Number(minutes[1]) : /\b(quick|fast|snel|snelle|vlug)\b/.test(t) ? 25 : null,
    highProtein: /\b(protein|eiwit|eiwitrijk|eiwitten)\b/.test(t),
    cheap: /\b(cheap|budget|inexpensive|goedkoop|goedkope|voordelig)\b/.test(t),
    diet,
    useUp,
    meal,
  };
}

const SAVE_RECIPE = /^(please |graag )?(save|add|create|store|new|bewaar|sla|voeg|nieuw)\b( (this|a|an|my|the|dit|een|mijn|het|nieuw|new))* ?(recipe|recept)\b/;
const STOCK_RECIPE = /\b(from|with|out of|using|uit|met|van)\b.*\b(what (i|we) (have|got)|my (stock|fridge|inventory|pantry)|(wat|alles wat) (ik|we) (heb|hebben)|mijn (voorraad|koelkast))\b|\b(use[- ]it[- ]up|opmaak|restjes)\b/;

/** Parse an utterance. `awaiting` tells the parser a clarification question is open. */
export function parse(utterance: string, opts: { awaiting?: boolean; langHint?: Lang } = {}): ParseResult {
  const t = clean(utterance);
  const lang = detectLang(t, opts.langHint ?? 'en');
  const one = (intent: Intent, confidence = 0.9): ParseResult => ({ lang, intents: [intent], confidence });
  if (!t) return one({ type: 'unknown' }, 0);

  if (UNDO.test(t)) return one({ type: 'undo' });
  if (opts.awaiting) {
    if (YES.test(t) && t.split(' ').length <= 4) return one({ type: 'confirm', yes: true });
    if (NO.test(t)) return one({ type: 'confirm', yes: false });
  }
  const corr = CORRECTION.exec(t);
  const rest = corr?.groups?.rest;
  if (rest && !opts.awaiting && rest.split(' ').length <= 6 && !CONSUME.test(rest) && !ADD.test(rest)) return one({ type: 'correction', text: rest }, 0.8);

  // Recipes: "save this recipe: X with a, b and c", "make a recipe from what I have".
  if (/\b(recipe|recept|gerecht)\b/.test(t) && STOCK_RECIPE.test(t)) return one({ type: 'stock_recipe' });
  if (SAVE_RECIPE.test(t)) return one({ type: 'save_recipe', text: utterance.trim() });

  if (SCAN_RECEIPT.test(t) && /\b(scan|photo|foto|picture|upload|camera|bought|gekocht|this|deze|dit)\b/.test(t)) return one({ type: 'scan_receipt' });
  if (SCAN_BARCODE.test(t)) return one({ type: 'scan_barcode' });

  // Questions
  if (Q_BUY.test(t)) return one({ type: 'query_buy' });
  if (Q_LOW.test(t) && /\b(what|which|wat|welke|is|anything|iets)\b/.test(t)) return one({ type: 'query_low' });
  if (Q_EXPIRING.test(t) && /\b(what|which|wat|welke|anything|iets|soon|binnenkort|eerst|first)\b/.test(t)) return one({ type: 'query_expiring' });
  if (Q_COOK.test(t) && !COOKED.test(t)) return one({ type: 'query_cook', filters: cookFilters(t) });
  const howMuch = Q_HOW_MUCH.exec(t);
  if (howMuch) return one({ type: 'query_item', name: cleanQueryName(howMuch[1]) });
  if (Q_INVENTORY.test(t)) {
    const loc = LOCATIONS.find(([re]) => re.test(t))?.[1] ?? null;
    return one({ type: 'query_inventory', location: loc });
  }
  const doIHave = Q_DO_I_HAVE.exec(t);
  if (doIHave && /^(do|have|is|are|heb|hebben|is er|zijn er)/.test(t) && !SHOP_LIST.test(t)) return one({ type: 'query_item', name: cleanQueryName(doIHave[1]) });

  // Shopping list
  if (SHOP_REMOVE.test(t) || (SHOP_LIST.test(t) && /\b(remove|delete|verwijder|schrap|haal .* af|van de lijst)\b/.test(t))) {
    const body = strip(t, /\b(please|remove|delete|take|cross|strike|scrap|verwijder|haal|schrap|streep|off|from|van|af|my|the|de|mijn|shopping list|grocery list|list|boodschappenlijst|lijstje|lijst|door)\b/g);
    return one({ type: 'shopping_remove', items: items(body) });
  }
  if (SHOP_LIST.test(t) || SHOP_NEED.test(t)) {
    const body = strip(
      t,
      /\b(please|add|put|zet|voeg|toe|to|on|onto|op|aan|my|the|our|de|mijn|onze|shopping list|grocery list|groceries list|the list|my list|list|to buy|boodschappenlijst|boodschappenlijstje|boodschappen lijst|lijstje|lijst|we need|i need|we'?re out of|we are out of|need to buy|need to get|remind me to buy|don'?t forget|we moeten|ik moet|nodig|we hebben|ik heb|koop|kopen|haal|halen|vergeet|niet|nog|graag|also|ook|write down|schrijf)\b/g,
    );
    return one({ type: 'shopping_add', items: items(body) });
  }

  // Cooking & leftovers
  if (FREEZE.test(t)) {
    const body = strip(t, /\b(i|we|just|have|ik|heb|hebben|froze|freeze|frozen|ingevroren|invriezen|vries|in|put|the|de|het|freezer|vriezer|into|gezet|gedaan)\b/g);
    return one({ type: 'freeze', items: items(body) });
  }
  if (THAW.test(t)) {
    const body = strip(t, /\b(i|we|just|have|ik|heb|hebben|defrost|defrosted|thaw|thawed|ontdooi|ontdooid|ontdooien|uit|de|the|vriezer|freezer|out|of|from|gehaald|taken|took)\b/g);
    return one({ type: 'thaw', items: items(body) });
  }
  if (NOT_COOKED.test(t) && /\b(cook|cooked|make|made|have|eat|skip|skipped|skipping|gekookt|gemaakt|gegeten|koken|maken|overgeslagen|over)\b/.test(t)) {
    const dish = t
      .replace(NOT_COOKED, ' ')
      .replace(/\b(i|we|ik|wij|heb|hebben|the|a|de|het|een|today|tonight|vandaag|vanavond|after all|toch|it|dat|dit|cook|cooked|make|made|have|eat|gekookt|gemaakt|gegeten|over|niet|meal|maaltijd|sla|slaan)\b/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    const meal = MEAL_WORDS.find(([re]) => re.test(t))?.[1] ?? null;
    return one({ type: 'not_cooked', dish: MEAL_WORDS.some(([re]) => re.test(dish)) ? '' : dish, meal });
  }
  // "I had a banana" / "we ate 2 apples" is consumption, not a cooked meal.
  const looksLikeSnack = /\b(ate|eaten|had|gegeten)\b/.test(t) && /\d|\b(a|an|one|two|three|een|twee|drie|some|wat|slice|slices|plak|plakje|glass|glas|bowl|kom)\b/.test(t) && !/\b(made|cooked|gekookt|gemaakt|gebakken)\b/.test(t);
  if (COOKED.test(t) && !looksLikeSnack) {
    const servingsM = t.match(/\bfor (\w+)(?: (?:people|persons|of us|servings|portions))?\b|\bvoor (\w+)(?: (?:personen|mensen|porties))?\b/);
    const servings = servingsM ? parseNumber(servingsM[1] ?? servingsM[2]) : null;
    const leftM = t.match(/(\w+) (?:portions?|servings?|porties?) (?:left ?over|leftover|over|remaining)/);
    let dish = t
      .replace(/\bfor (\w+)( (people|persons|of us|servings|portions))?\b|\bvoor (\w+)( (personen|mensen|porties))?\b/, ' ')
      .replace(/,?\s*(with |met )?(\w+) (portions?|servings?|porties?) (left ?over|leftover|over|remaining).*/, ' ')
      .replace(COOK_VERBS, ' ')
      .replace(/\b(a|an|the|some|een|de|het|tonight|vanavond|for dinner|voor het avondeten|for lunch|today|vandaag|already|finally|roasted|grilled|bereid|is|was|done|ready|klaar|our|my|ons|onze|mijn|have|hebben|heb|we|ik|i|for|voor|it|that|this|dat|dit)\b/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    const meal = MEAL_WORDS.find(([re]) => re.test(t))?.[1] ?? null;
    // "I cooked dinner" means today's planned dinner, not a recipe called "dinner".
    if (MEAL_WORDS.some(([re]) => re.test(dish)) && dish.split(' ').length <= 2) dish = '';
    return one({ type: 'cooked', dish, servings, leftovers: leftM ? parseNumber(leftM[1]) : null, meal });
  }

  // Inventory changes
  const opened = t.match(/^(?:i|we|ik|wij)?\s*(?:just\s+|net\s+)?(?:opened|open|heb\s+|hebben\s+)?(?:a\s+new\s+|the\s+|a\s+|de\s+|het\s+|een\s+(?:nieuwe?\s+)?)?(.+?)\s*(?:opened|geopend|open\s*gemaakt|opengemaakt|aangebroken)?$/);
  if (/\b(opened|geopend|opengemaakt|open gemaakt|aangebroken)\b|^(?:i|we)\s+(?:just\s+)?open(?:ed)?\b/.test(t) && opened && !DISCARD.test(t)) {
    const body = strip(opened[1], /\b(opened|open|geopend|opengemaakt|gemaakt|aangebroken|heb|hebben|new|nieuwe|nieuw|pack|of|the|a|de|het|een|van)\b/g);
    return one({ type: 'open', items: items(body) });
  }
  if (DISCARD.test(t)) {
    const damaged = DAMAGED.test(t);
    const reason = damaged ? 'damaged' : /(expired|out of date|over de datum|tht)/.test(t) ? 'expired' : /(mould|mold|schimmel)/.test(t) ? 'mouldy' : /(bad|off|spoil|rotten|bedorven|slecht|verrot|zuur)/.test(t) ? 'spoiled' : 'other';
    // Verb first ("I broke 3 eggs", "we dropped the yoghurt"): the item follows the verb.
    const verbFirst = t.match(/^(?:i|we)\s+(?:just\s+)?(?:broke|cracked|smashed|dropped|squashed|crushed|spilled|split)\s+(.+)$/);
    const body = (verbFirst ? verbFirst[1] : t)
      .replace(/\b(i|we|ik|wij)\s+(dropped|smashed|squashed|crushed|heb|hebben)\b/, ' ')
      .replace(/[,]?\s*\b(it|they|that|which|because|want|omdat|since|die|dat|het|deze)?\s*(has|have|had|is|are|was|were|zijn|is|got|waren|werd|raakte|went)?\s*(gone bad|went bad|gone off|went off|off|expired|out of date|spoiled|spoilt|rotten|rotted|mouldy|moldy|bedorven|beschimmeld|over de datum|slecht geworden|niet meer goed|verrot|zuur geworden|broke|broken|cracked|smashed|squashed|crushed|burst|leaked|leaking|damaged|split open|kapot|gebroken|gebarsten|gevallen|laten vallen|geplet|lek|lekte|beschadigd)\b.*$/, ' ')
      .replace(/\b(dropped|smashed|squashed|crushed|on the way home|in transit|onderweg)\b/g, ' ');
    const b2 = strip(body, VERB_WORDS);
    const its = items(b2);
    // "remove the remaining spinach" / bare discard without amount → everything that's left
    // "Remove the remaining spinach, it went bad" means all of it. Damage usually isn't everything
    // ("the eggs broke"), so without an amount we ask how many instead.
    for (const it of its) if (it.amount == null && !it.vague) damaged && !it.all ? (it.vague = true) : (it.all = true);
    return one({ type: 'discard', items: its, reason });
  }
  if (FINISHED.test(t)) {
    const body = strip(t.replace(/\bgeen (.+?) meer\b/, '$1'), /\b(i|we|just|have|has|finished|ran out of|used up|used the last|ate the last|drank the last|all gone|is|are|zijn|op|leeg|opgemaakt|opgedronken|opgegeten|no more|out of|the|de|het|ik|heb|hebben|we|any|geen|meer|of|last)\b/g);
    const its = items(body).map((i) => ({ ...i, all: true, amount: null }));
    return one({ type: 'consume', items: its });
  }
  const setM = SET_QTY.exec(t);
  if (setM && /\d|\b(one|two|three|four|five|six|seven|eight|nine|ten|een|twee|drie|vier|vijf|zes|zeven|acht|negen|tien|half|halve)\b/.test(setM[1]) && /\b(left|over|remaining|nog|still|only|maar)\b/.test(t) && !ADD.test(t.replace(/\b(got|have)\b/g, ''))) {
    return one({ type: 'set_quantity', items: items(setM[1]) }, 0.85);
  }
  const hasConsume = CONSUME.test(t);
  const hasAdd = ADD.test(t);
  if (hasConsume && (!hasAdd || /\b(used|ate|drank|gebruikt|gegeten|gedronken|remove|removed|verwijder|took)\b/.test(t))) {
    const body = strip(t, VERB_WORDS);
    return one({ type: 'consume', items: items(body) });
  }
  if (hasAdd) {
    // "I added milk" (past tense) is already in the house; "add milk" could be the list.
    const explicitInventory = /\b(bought|got|picked up|purchased|received|delivered|gekocht|gehaald|bijgekocht|geleverd|groceries|inventory|stock|voorraad|fridge|freezer|pantry|koelkast|vriezer|kast)\b|\b(i|we)\s+(just\s+)?(added|stocked|restocked)\b|\btoegevoegd\b/.test(t);
    const body = strip(t, VERB_WORDS);
    const its = items(body);
    if (explicitInventory) return one({ type: 'add_inventory', items: its, explicit: true });
    return one({ type: 'add_ambiguous', items: its }, 0.7);
  }

  // A clarification answer: "about 250 ml", "half", "2", "the oat milk"
  if (opts.awaiting) return one({ type: 'answer', text: t }, 0.7);

  // Bare product phrase ("milk") is not enough to act on.
  return one({ type: 'unknown' }, 0);
}

function cleanQueryName(s: string): string {
  return s
    .replace(/\b(do|i|we|have|got|left|still|there|is|are|any|some|of|the|my|in|stock|heb|ik|hebben|we|nog|er|is|zijn|in|huis|de|het|over|voorraad|hoeveel|much|many|how)\b/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}
