// In-process change bus. Domain code marks scopes as changed; the SSE layer pushes a
// debounced "changed" message to every connected client of that household.
type Listener = (scopes: string[]) => void;

const listeners = new Map<string, Set<Listener>>();
const pending = new Map<string, Set<string>>();

export const bus = {
  touch(householdId: string, scope: string) {
    let s = pending.get(householdId);
    if (!s) {
      s = new Set();
      pending.set(householdId, s);
      setTimeout(() => {
        const scopes = [...(pending.get(householdId) ?? [])];
        pending.delete(householdId);
        for (const l of listeners.get(householdId) ?? []) l(scopes);
      }, 40).unref?.();
    }
    s.add(scope);
  },
  subscribe(householdId: string, l: Listener): () => void {
    let set = listeners.get(householdId);
    if (!set) listeners.set(householdId, (set = new Set()));
    set.add(l);
    return () => set!.delete(l);
  },
};
