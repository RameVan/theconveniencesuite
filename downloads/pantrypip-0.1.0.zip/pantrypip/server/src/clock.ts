// Injectable clock so prediction and expiry logic can be tested deterministically.
let offsetMs = 0;
let fixed: number | null = null;

export const clock = {
  now(): Date {
    return new Date(fixed ?? Date.now() + offsetMs);
  },
  iso(): string {
    return clock.now().toISOString();
  },
  today(): string {
    return toDateString(clock.now());
  },
  /** Test helper: freeze time at the given instant. */
  set(d: Date | string | null) {
    fixed = d == null ? null : new Date(d).getTime();
  },
  advanceDays(days: number) {
    if (fixed != null) fixed += days * 86_400_000;
    else offsetMs += days * 86_400_000;
  },
};

export function toDateString(d: Date): string {
  return d.toISOString().slice(0, 10);
}

export function addDays(date: string | Date, days: number): string {
  const d = typeof date === 'string' ? new Date(date.length === 10 ? date + 'T12:00:00Z' : date) : new Date(date);
  d.setUTCDate(d.getUTCDate() + days);
  return toDateString(d);
}

export function daysBetween(a: string | Date, b: string | Date): number {
  const ta = new Date(typeof a === 'string' && a.length === 10 ? a + 'T12:00:00Z' : a).getTime();
  const tb = new Date(typeof b === 'string' && b.length === 10 ? b + 'T12:00:00Z' : b).getTime();
  return (tb - ta) / 86_400_000;
}
