import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');

// All configuration comes from the environment; secrets never reach the browser.
export const config = {
  port: Number(process.env.PORT ?? 8787),
  // HTTPS for phones on the home network (see docs/IPHONE.md). Uses data/certs/server.{crt,key} from `npm run cert`.
  httpsPort: Number(process.env.HTTPS_PORT ?? 8443),
  httpsCert: process.env.HTTPS_CERT ?? path.join(root, 'data', 'certs', 'server.crt'),
  httpsKey: process.env.HTTPS_KEY ?? path.join(root, 'data', 'certs', 'server.key'),
  httpsCa: path.join(root, 'data', 'certs', 'larder-ca.crt'),
  https: process.env.HTTPS === '1',
  // Local only by default. With HTTPS=1 the app is meant for phones on the network, so it listens on all interfaces.
  host: process.env.HOST ?? (process.env.HTTPS === '1' ? '0.0.0.0' : '127.0.0.1'),
  dbFile: process.env.DB_FILE ?? path.join(root, 'data', 'larder.db'),
  backupDir: process.env.BACKUP_DIR ?? path.join(root, 'data', 'backups'),
  backupKeep: Number(process.env.BACKUP_KEEP ?? 14),
  webDist: path.join(root, 'web', 'dist'),
  seedDemo: process.env.SEED_DEMO !== '0',
  cookieSecure: process.env.COOKIE_SECURE === '1',
  // AI is off unless explicitly enabled with AI_ENABLED=1 (a key in the environment alone is not enough,
  // so receipts and commands never leave the server by accident). Without it the deterministic parsers run.
  anthropicKey: process.env.ANTHROPIC_API_KEY ?? '',
  aiModel: process.env.AI_MODEL ?? 'claude-opus-5-5',
  aiEnabled: process.env.AI_ENABLED === '1' && !!process.env.ANTHROPIC_API_KEY,
  offLookup: process.env.OFF_LOOKUP !== '0',
  offUserAgent: process.env.OFF_USER_AGENT ?? 'PantryPip/0.1 (self-hosted household app)',
  mealDbKey: process.env.THEMEALDB_KEY ?? '',
  // Contact for Web Push (VAPID subject). Push services want a reachable mailto: or https: address.
  pushContact: process.env.PUSH_CONTACT ?? 'mailto:larder-admin@localhost.localdomain',
};
