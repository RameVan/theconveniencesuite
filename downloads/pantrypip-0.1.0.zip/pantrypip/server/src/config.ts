import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');

// All configuration comes from the environment; secrets never reach the browser.
export const config = {
  port: Number(process.env.PORT ?? 8787),
  // HTTPS for phones on the home network (see docs/IPHONE.md). Uses data/certs/server.{crt,key} from `npm run cert`.
  httpsPort: Number(process.env.HTTPS_PORT ?? 8443),
  httpsCert: process.env.HTTPS_CERT ?? path.join(root, 'data', 'certs', 'server.crt'),
  httpsKey: process.env.HTTPS_KEY ?? path.join(root, 'data', 'certs', 'server.key'),
  httpsCa: path.join(root, 'data', 'certs', 'larder-ca.crt'),
  https: process.env.HTTPS === '1',
  // Local only by default. With HTTPS=1 the app is meant for phones on the network, so it listens on all interfaces.
  host: process.env.HOST ?? (process.env.HTTPS === '1' ? '0.0.0.0' : '127.0.0.1'),
  dbFile: process.env.DB_FILE ?? path.join(root, 'data', 'larder.db'),
  backupDir: process.env.BACKUP_DIR ?? path.join(root, 'data', 'backups'),
  backupKeep: Number(process.env.BACKUP_KEEP ?? 14),
  webDist: path.join(root, 'web', 'dist'),
  seedDemo: process.env.SEED_DEMO !== '0',
  cookieSecure: process.env.COOKIE_SECURE === '1',
  // AI is off unless explicitly enabled with AI_ENABLED=1 (a key in the environment alone is not enough,
  // so receipts and commands never leave the server by accident). Without it the deterministic parsers run.
  anthropicKey: process.env.ANTHROPIC_API_KEY ?? '',
  aiModel: process.env.AI_MODEL ?? 'claude-opus-5-5',
  aiEnabled: process.env.AI_ENABLED === '1' && !!process.env.ANTHROPIC_API_KEY,
  offLookup: process.env.OFF_LOOKUP !== '0',
  offUserAgent: process.env.OFF_USER_AGENT ?? 'PantryPip/0.1 (self-hosted household app)',
  mealDbKey: process.env.THEMEALDB_KEY ?? '',
  // Contact for Web Push (VAPID subject). Push services want a reachable mailto: or https: address.
  // Public copy: the account (by email) whose devices get a push when someone new signs up. Off when empty.
  signupAlertEmail: (process.env.SIGNUP_ALERT_EMAIL ?? '').trim().toLowerCase(),
  pushContact: process.env.PUSH_CONTACT ?? 'mailto:larder-admin@localhost.localdomain',
  // The account that may use test mode (sandbox, unlock everything, time travel, test accounts).
  ownerEmail: (process.env.OWNER_EMAIL ?? process.env.SIGNUP_ALERT_EMAIL ?? '').trim().toLowerCase(),
  // New accounts confirm their email first (EMAIL_CONFIRM=0 turns that off, e.g. for a copy only you use).
  emailConfirm: process.env.EMAIL_CONFIRM !== '0',
  // Sign-up needs an invite: a household's invite code, or a friend's code or link (INVITE_ONLY=1, the public copy).
  inviteOnly: process.env.INVITE_ONLY === '1',
  // Email through your own mailbox over SMTP (Gmail: smtp.gmail.com, your address, an app password), or else
  // through Resend (https://resend.com). With neither, emails are written to the server log instead.
  smtpHost: process.env.SMTP_HOST ?? '',
  smtpPort: Number(process.env.SMTP_PORT ?? 465),
  smtpUser: process.env.SMTP_USER ?? '',
  smtpPass: (process.env.SMTP_PASS ?? '').replace(/\s+/g, ''), // Gmail shows app passwords in groups of four
  resendKey: process.env.RESEND_API_KEY ?? '',
  // Gmail only sends as your own address, so over SMTP the sender is that address unless MAIL_FROM says otherwise.
  mailFrom: process.env.MAIL_FROM ?? (process.env.SMTP_HOST && process.env.SMTP_USER ? `PantryPip <${process.env.SMTP_USER}>` : 'PantryPip <noreply@theconveniencesuite.com>'),
  // Where links in emails point. Never taken from the request, so a forged Host header can't redirect them.
  publicUrl: (process.env.PUBLIC_URL ?? `http://127.0.0.1:${process.env.PORT ?? 8787}`).replace(/\/+$/, ''),
};
