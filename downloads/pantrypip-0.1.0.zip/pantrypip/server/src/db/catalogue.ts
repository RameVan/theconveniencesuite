// Built-in product catalogue: common Dutch/European groceries with English and Dutch names.
import { NUTRITION_EXTRA } from './nutrition-data.ts';
import { EXTRA_ROWS, SYNONYM_FIXES, SYNONYM_ADDS, RENAMES, PIECE_FIXES } from './catalogue-extra.ts';
// Prices are typical Dutch supermarket prices (EUR, 2026), for estimates only.
// Nutrition is per 100 g/ml and marked as an estimate; replace with NEVO or Open Food Facts data where available.
// Synonyms include common receipt abbreviations.

type Row = [
  id: string, en: string, nl: string, category: string, unit: 'g' | 'ml' | 'pcs', pkg: number,
  piece: number | null, pieceName: string | null, price: number | null, location: 'fridge' | 'freezer' | 'pantry',
  shelf: number, opened: number | null, freezer: number | null, synonyms: string[],
  kcal: number, protein: number, carbs: number, fat: number, staple?: boolean,
];

const ROWS: Row[] = [
  // Dairy & eggs
  ['milk', 'Semi-skimmed milk', 'Halfvolle melk', 'dairy', 'ml', 1000, null, null, 1.19, 'fridge', 8, 4, 90, ['milk', 'melk', 'halfvolle melk', 'hv melk', 'halfv melk', 'semi skimmed milk'], 46, 3.5, 4.8, 1.5],
  ['whole_milk', 'Whole milk', 'Volle melk', 'dairy', 'ml', 1000, null, null, 1.35, 'fridge', 8, 4, 90, ['whole milk', 'volle melk', 'vol melk'], 63, 3.4, 4.7, 3.5],
  ['oat_milk', 'Oat drink', 'Haverdrank', 'dairy', 'ml', 1000, null, null, 2.19, 'pantry', 180, 7, null, ['oat milk', 'oatly', 'haverdrank', 'havermelk'], 46, 1, 6.7, 1.5],
  ['eggs', 'Eggs', 'Eieren', 'dairy', 'pcs', 10, 60, 'egg', 3.29, 'fridge', 28, null, null, ['egg', 'eggs', 'ei', 'eieren', 'scharreleieren', 'vrije uitloop eieren', 'eier'], 143, 12.6, 0.7, 9.5],
  ['butter', 'Butter', 'Roomboter', 'dairy', 'g', 250, null, null, 2.99, 'fridge', 60, 30, 180, ['butter', 'boter', 'roomboter'], 740, 0.6, 0.6, 82],
  ['yoghurt', 'Greek yoghurt', 'Griekse yoghurt', 'dairy', 'g', 500, null, null, 2.29, 'fridge', 14, 5, null, ['yoghurt', 'yogurt', 'greek yoghurt', 'griekse yoghurt', 'gr yoghurt'], 120, 6, 4, 10],
  ['skyr', 'Skyr', 'Skyr', 'dairy', 'g', 450, null, null, 2.39, 'fridge', 21, 5, null, ['skyr'], 63, 11, 4, 0.2],
  ['quark', 'Low-fat quark', 'Magere kwark', 'dairy', 'g', 500, null, null, 1.69, 'fridge', 14, 5, null, ['quark', 'kwark', 'magere kwark'], 58, 10, 3.6, 0.2],
  ['cheese', 'Gouda cheese (young matured)', 'Jong belegen kaas', 'dairy', 'g', 400, 20, 'slice', 4.49, 'fridge', 30, 21, 90, ['cheese', 'kaas', 'gouda', 'jong belegen', 'belegen kaas', 'goudse kaas', 'jb kaas'], 356, 24, 0, 29],
  ['parmesan', 'Parmesan', 'Parmezaanse kaas', 'dairy', 'g', 150, null, null, 3.49, 'fridge', 60, 30, 180, ['parmesan', 'parmigiano', 'parmezaan', 'parmezaanse kaas', 'grana padano'], 392, 36, 0, 26],
  ['mozzarella', 'Mozzarella', 'Mozzarella', 'dairy', 'g', 125, null, null, 1.29, 'fridge', 14, 3, 60, ['mozzarella', 'mozarella', 'buffelmozzarella'], 254, 18, 2, 19],
  ['feta', 'Feta', 'Feta', 'dairy', 'g', 200, null, null, 2.49, 'fridge', 30, 5, 60, ['feta'], 264, 14, 4, 21],
  ['cream', 'Cooking cream', 'Kookroom', 'dairy', 'ml', 250, null, null, 1.39, 'fridge', 21, 4, null, ['cream', 'room', 'kookroom', 'slagroom', 'cooking cream', 'whipping cream'], 195, 2.5, 3.5, 19],
  ['creme_fraiche', 'Crème fraîche', 'Crème fraîche', 'dairy', 'ml', 200, null, null, 1.29, 'fridge', 21, 5, null, ['creme fraiche', 'crème fraîche', 'zure room'], 292, 2.4, 2.8, 30],

  // Produce
  ['onion', 'Onion', 'Ui', 'produce', 'pcs', 6, 150, 'onion', 1.29, 'pantry', 30, null, 180, ['onion', 'onions', 'ui', 'uien', 'gele uien', 'uitjes'], 40, 1.1, 9.3, 0.1],
  ['red_onion', 'Red onion', 'Rode ui', 'produce', 'pcs', 3, 150, 'onion', 1.29, 'pantry', 30, null, 180, ['red onion', 'rode ui', 'rode uien'], 40, 1.1, 9.3, 0.1],
  ['garlic', 'Garlic', 'Knoflook', 'produce', 'pcs', 30, 5, 'clove', 0.99, 'pantry', 60, null, null, ['garlic', 'knoflook', 'knoflookbol', 'clove of garlic', 'garlic clove', 'teentje knoflook'], 149, 6.4, 33, 0.5],
  ['potatoes', 'Potatoes', 'Aardappelen', 'produce', 'g', 2000, 150, 'potato', 2.49, 'pantry', 30, null, null, ['potato', 'potatoes', 'aardappel', 'aardappelen', 'kruimige aardappelen', 'vastkokende aardappelen', 'krieltjes'], 77, 2, 17, 0.1],
  ['sweet_potato', 'Sweet potato', 'Zoete aardappel', 'produce', 'g', 500, 250, 'sweet potato', 1.99, 'pantry', 21, null, 180, ['sweet potato', 'sweet potatoes', 'zoete aardappel', 'zoete aardappelen'], 86, 1.6, 20, 0.1],
  ['carrots', 'Carrots', 'Wortels', 'produce', 'g', 1000, 80, 'carrot', 1.19, 'fridge', 21, null, 240, ['carrot', 'carrots', 'wortel', 'wortels', 'winterpeen', 'peen', 'worteltjes'], 41, 0.9, 10, 0.2],
  ['tomatoes', 'Tomatoes', 'Tomaten', 'produce', 'pcs', 6, 100, 'tomato', 1.99, 'pantry', 7, null, null, ['tomato', 'tomatoes', 'tomaat', 'tomaten', 'trostomaten', 'tros tomaten'], 18, 0.9, 3.9, 0.2],
  ['cherry_tomatoes', 'Cherry tomatoes', 'Cherrytomaten', 'produce', 'g', 250, 15, 'tomato', 1.79, 'pantry', 7, null, null, ['cherry tomatoes', 'cherrytomaten', 'snoeptomaten', 'cherry tomaten'], 18, 0.9, 3.9, 0.2],
  ['cucumber', 'Cucumber', 'Komkommer', 'produce', 'pcs', 1, 350, 'cucumber', 0.89, 'fridge', 7, null, null, ['cucumber', 'komkommer', 'komkommers'], 15, 0.7, 3.6, 0.1],
  ['bell_pepper', 'Bell pepper', 'Paprika', 'produce', 'pcs', 3, 160, 'pepper', 2.29, 'fridge', 10, null, 180, ['bell pepper', 'bell peppers', 'peppers', 'red pepper','paprika', 'paprikas', 'paprika\'s', 'rode paprika', 'paprika mix'], 31, 1, 6, 0.3],
  ['zucchini', 'Courgette', 'Courgette', 'produce', 'pcs', 1, 300, 'courgette', 0.99, 'fridge', 7, null, 120, ['courgette', 'zucchini', 'courgettes'], 17, 1.2, 3.1, 0.3],
  ['broccoli', 'Broccoli', 'Broccoli', 'produce', 'g', 500, null, null, 1.49, 'fridge', 6, null, 240, ['broccoli'], 34, 2.8, 7, 0.4],
  ['cauliflower', 'Cauliflower', 'Bloemkool', 'produce', 'pcs', 1, 600, 'head', 1.99, 'fridge', 7, null, 240, ['cauliflower', 'bloemkool'], 25, 1.9, 5, 0.3],
  ['spinach', 'Spinach', 'Spinazie', 'produce', 'g', 300, null, null, 1.79, 'fridge', 5, 2, 240, ['spinach', 'baby spinach', 'spinazie', 'babyspinazie', 'jonge spinazie'], 23, 2.9, 3.6, 0.4],
  ['lettuce', 'Lettuce', 'Sla', 'produce', 'g', 200, null, null, 1.29, 'fridge', 5, 2, null, ['lettuce', 'salad', 'sla', 'ijsbergsla', 'veldsla', 'little gem', 'slamix'], 15, 1.4, 2.9, 0.2],
  ['mushrooms', 'Mushrooms', 'Champignons', 'produce', 'g', 250, null, null, 1.39, 'fridge', 6, 3, 240, ['mushroom', 'mushrooms', 'champignon', 'champignons', 'kastanjechampignons'], 22, 3.1, 3.3, 0.3],
  ['leek', 'Leek', 'Prei', 'produce', 'pcs', 1, 250, 'leek', 0.99, 'fridge', 10, null, 180, ['leek', 'leeks', 'prei'], 61, 1.5, 14, 0.3],
  ['green_beans', 'Green beans', 'Sperziebonen', 'produce', 'g', 400, null, null, 1.99, 'fridge', 5, null, 240, ['green beans', 'sperziebonen', 'boontjes'], 31, 1.8, 7, 0.2],
  ['avocado', 'Avocado', 'Avocado', 'produce', 'pcs', 2, 150, 'avocado', 2.49, 'pantry', 5, 1, null, ['avocado', 'avocados', 'avocado\'s'], 160, 2, 8.5, 14.7],
  ['lemon', 'Lemon', 'Citroen', 'produce', 'pcs', 3, 100, 'lemon', 1.49, 'fridge', 21, 5, null, ['lemon', 'lemons', 'citroen', 'citroenen'], 29, 1.1, 9, 0.3],
  ['lime', 'Lime', 'Limoen', 'produce', 'pcs', 3, 60, 'lime', 1.49, 'fridge', 21, 5, null, ['lime', 'limes', 'limoen', 'limoenen'], 30, 0.7, 10.5, 0.2],
  ['apples', 'Apples', 'Appels', 'produce', 'pcs', 6, 180, 'apple', 2.49, 'pantry', 28, null, null, ['apple', 'apples', 'appel', 'appels', 'elstar', 'jonagold', 'goudrenet'], 52, 0.3, 14, 0.2],
  ['bananas', 'Bananas', 'Bananen', 'produce', 'pcs', 5, 120, 'banana', 1.69, 'pantry', 6, null, 90, ['banana', 'bananas', 'banaan', 'bananen'], 89, 1.1, 23, 0.3],
  ['berries', 'Blueberries', 'Blauwe bessen', 'produce', 'g', 125, null, null, 2.49, 'fridge', 6, null, 240, ['blueberries', 'berries', 'blauwe bessen', 'bosbessen', 'frambozen', 'aardbeien', 'strawberries', 'raspberries'], 57, 0.7, 14, 0.3],
  ['ginger', 'Ginger', 'Gember', 'produce', 'g', 100, null, null, 0.99, 'fridge', 21, null, 180, ['ginger', 'gember', 'verse gember'], 80, 1.8, 18, 0.8],
  ['chili', 'Red chilli', 'Rode peper', 'produce', 'pcs', 3, 10, 'chilli', 0.99, 'fridge', 10, null, 180, ['chili', 'chilli', 'chilli pepper', 'rode peper', 'spaanse peper', 'pepers'], 40, 1.9, 9, 0.4],
  ['parsley', 'Fresh parsley', 'Verse peterselie', 'produce', 'g', 30, null, null, 0.99, 'fridge', 6, null, 120, ['parsley', 'peterselie', 'platte peterselie'], 36, 3, 6, 0.8],
  ['coriander', 'Fresh coriander', 'Verse koriander', 'produce', 'g', 30, null, null, 0.99, 'fridge', 5, null, 120, ['coriander', 'cilantro', 'koriander', 'verse koriander'], 23, 2.1, 3.7, 0.5],
  ['basil', 'Fresh basil', 'Verse basilicum', 'produce', 'g', 30, null, null, 0.99, 'fridge', 5, null, null, ['basil', 'basilicum', 'verse basilicum'], 23, 3.2, 2.7, 0.6],
  ['spring_onion', 'Spring onions', 'Bosui', 'produce', 'pcs', 6, 15, 'spring onion', 0.79, 'fridge', 7, null, null, ['spring onion', 'spring onions', 'scallions', 'bosui', 'lente-ui', 'lente ui'], 32, 1.8, 7, 0.2],
  ['wok_vegetables', 'Stir-fry vegetables', 'Wokgroenten', 'produce', 'g', 400, null, null, 1.99, 'fridge', 4, 1, null, ['stir fry vegetables', 'wokgroente', 'wokgroenten', 'roerbakgroente', 'wok mix'], 30, 1.8, 5, 0.3],

  // Meat & fish
  ['chicken_breast', 'Chicken breast', 'Kipfilet', 'meat_fish', 'g', 500, 150, 'fillet', 6.49, 'fridge', 4, null, 180, ['chicken', 'chicken breast', 'chicken fillet', 'kip', 'kipfilet', 'kipfilets', 'kippenborst', 'kipfil', 'kipfilet naturel'], 110, 23, 0, 1.5],
  ['chicken_thigh', 'Chicken thigh fillet', 'Kippendijfilet', 'meat_fish', 'g', 400, 100, 'thigh', 5.29, 'fridge', 4, null, 180, ['chicken thigh', 'chicken thighs', 'kippendij', 'kippendijen', 'kippendijfilet', 'dijfilet'], 177, 18, 0, 11],
  ['minced_beef', 'Minced beef', 'Rundergehakt', 'meat_fish', 'g', 500, null, null, 5.49, 'fridge', 3, null, 120, ['minced beef', 'ground beef', 'mince', 'beef mince', 'gehakt', 'rundergehakt', 'rundgehakt', 'half om half gehakt', 'h o h gehakt', 'hoh gehakt'], 250, 18, 0, 20],
  ['bacon', 'Diced bacon', 'Spekblokjes', 'meat_fish', 'g', 150, null, null, 2.19, 'fridge', 14, 4, 90, ['bacon', 'pancetta', 'spekjes', 'spekblokjes', 'ontbijtspek', 'lardons'], 330, 15, 0.5, 30],
  ['ham', 'Sliced ham', 'Achterham', 'meat_fish', 'g', 150, 15, 'slice', 2.29, 'fridge', 10, 4, 60, ['ham', 'achterham', 'beenham', 'boterhamworst'], 110, 18, 1, 3.5],
  ['salmon', 'Salmon fillet', 'Zalmfilet', 'meat_fish', 'g', 250, 125, 'fillet', 5.99, 'fridge', 3, null, 120, ['salmon', 'salmon fillet', 'zalm', 'zalmfilet', 'zalmfilets'], 208, 20, 0, 13],
  ['shrimp', 'Prawns', 'Garnalen', 'meat_fish', 'g', 200, null, null, 4.99, 'freezer', 180, 2, 180, ['shrimp', 'prawns', 'garnalen', 'gamba', 'gambas'], 85, 20, 0, 0.5],
  ['tuna', 'Canned tuna', 'Tonijn in blik', 'pantry', 'g', 145, null, null, 1.79, 'pantry', 900, 2, null, ['tuna', 'canned tuna', 'tonijn', 'tonijnstukken'], 116, 26, 0, 1],
  ['smoked_sausage', 'Smoked sausage', 'Rookworst', 'meat_fish', 'g', 275, null, null, 2.79, 'fridge', 21, 4, 60, ['smoked sausage', 'rookworst', 'unox rookworst'], 300, 13, 2, 27],
  ['tofu', 'Tofu', 'Tofu', 'meat_fish', 'g', 375, null, null, 2.49, 'fridge', 30, 4, 90, ['tofu', 'firm tofu'], 120, 12, 2, 7],

  // Bakery
  ['bread', 'Wholegrain bread', 'Volkorenbrood', 'bakery', 'g', 800, 35, 'slice', 2.19, 'pantry', 4, null, 90, ['bread', 'loaf', 'brood', 'volkoren', 'volkorenbrood', 'tarwebrood', 'bruinbrood', 'heel volkoren', 'vk brood', 'boterham'], 230, 9, 40, 3],
  ['wraps', 'Tortilla wraps', 'Wraps', 'bakery', 'pcs', 8, 60, 'wrap', 1.89, 'pantry', 21, 5, 90, ['wrap', 'wraps', 'tortilla', 'tortillas', 'tortilla wraps'], 300, 8, 50, 7],
  ['croissants', 'Croissants', 'Croissants', 'bakery', 'pcs', 4, 45, 'croissant', 2.49, 'pantry', 3, null, 60, ['croissant', 'croissants'], 406, 8, 45, 21],

  // Pantry
  ['pasta', 'Spaghetti', 'Spaghetti', 'pantry', 'g', 500, null, null, 1.19, 'pantry', 720, 365, null, ['spaghetti', 'pasta', 'penne', 'fusilli', 'macaroni', 'tagliatelle', 'linguine'], 358, 12.5, 71, 1.5],
  ['rice', 'Basmati rice', 'Basmatirijst', 'pantry', 'g', 1000, null, null, 2.59, 'pantry', 720, 365, null, ['rice', 'rijst', 'basmati', 'basmatirijst', 'zilvervliesrijst', 'jasmijnrijst', 'pandanrijst'], 350, 8, 77, 0.6],
  ['noodles', 'Egg noodles', 'Mie', 'pantry', 'g', 250, null, null, 1.29, 'pantry', 540, 365, null, ['noodles', 'egg noodles', 'mie', 'mienestjes', 'rijstnoedels', 'rice noodles', 'udon'], 360, 13, 70, 2.5],
  ['oats', 'Rolled oats', 'Havermout', 'pantry', 'g', 500, null, null, 1.29, 'pantry', 365, 180, null, ['oats', 'rolled oats', 'oatmeal', 'havermout', 'havervlokken'], 370, 13, 59, 7],
  ['flour', 'Flour', 'Bloem', 'pantry', 'g', 1000, null, null, 0.99, 'pantry', 365, 180, null, ['flour', 'bloem', 'tarwebloem', 'patentbloem', 'meel'], 350, 10, 73, 1.2, true],
  ['sugar', 'Sugar', 'Suiker', 'pantry', 'g', 1000, null, null, 1.19, 'pantry', 1000, 1000, null, ['sugar', 'suiker', 'kristalsuiker', 'basterdsuiker', 'brown sugar'], 400, 0, 100, 0, true],
  ['olive_oil', 'Olive oil', 'Olijfolie', 'pantry', 'ml', 500, null, null, 6.99, 'pantry', 540, 180, null, ['olive oil', 'olijfolie', 'extra vierge olijfolie', 'oil', 'olie'], 824, 0, 0, 91.6, true],
  ['sunflower_oil', 'Sunflower oil', 'Zonnebloemolie', 'pantry', 'ml', 1000, null, null, 2.99, 'pantry', 540, 180, null, ['sunflower oil', 'vegetable oil', 'zonnebloemolie', 'frituurolie', 'bakolie'], 824, 0, 0, 91.6, true],
  ['canned_tomatoes', 'Chopped tomatoes (tin)', 'Tomatenblokjes', 'pantry', 'g', 400, null, null, 0.79, 'pantry', 730, 4, null, ['chopped tomatoes', 'canned tomatoes', 'tinned tomatoes', 'tomatenblokjes', 'gepelde tomaten', 'tomaten in blik', 'diced tomatoes', 'crushed tomatoes', 'stewed tomatoes', 'whole peeled tomatoes', 'peeled tomatoes'], 22, 1.2, 3.5, 0.2],
  ['tomato_paste', 'Tomato paste', 'Tomatenpuree', 'pantry', 'g', 70, null, null, 0.49, 'pantry', 730, 7, null, ['tomato paste', 'tomato puree', 'tomatenpuree', 'tomatenpuree blikje'], 82, 4.3, 14, 0.5],
  ['coconut_milk', 'Coconut milk', 'Kokosmelk', 'pantry', 'ml', 400, null, null, 1.69, 'pantry', 730, 3, null, ['coconut milk', 'kokosmelk', 'kokosroom'], 180, 1.6, 3, 18],
  ['chickpeas', 'Chickpeas (tin)', 'Kikkererwten', 'pantry', 'g', 400, null, null, 0.99, 'pantry', 730, 3, null, ['chickpeas', 'kikkererwten', 'garbanzo'], 120, 7, 16, 2.6],
  ['kidney_beans', 'Kidney beans (tin)', 'Kidneybonen', 'pantry', 'g', 400, null, null, 0.89, 'pantry', 730, 3, null, ['kidney beans', 'kidneybonen', 'red beans'], 110, 7.5, 15, 0.5],
  ['lentils', 'Red lentils', 'Rode linzen', 'pantry', 'g', 500, null, null, 1.99, 'pantry', 540, 365, null, ['lentils', 'red lentils', 'linzen', 'rode linzen'], 350, 24, 52, 1.5],
  ['stock_cube', 'Stock cubes', 'Bouillonblokjes', 'pantry', 'pcs', 12, 10, 'cube', 1.49, 'pantry', 540, 365, null, ['stock', 'stock cube', 'stock cubes', 'broth', 'bouillon', 'bouillonblokje', 'bouillonblokjes', 'kippenbouillon', 'groentebouillon'], 250, 10, 15, 15, true],
  ['soy_sauce', 'Soy sauce', 'Sojasaus', 'pantry', 'ml', 250, null, null, 2.29, 'pantry', 730, 365, null, ['soy sauce', 'soja', 'sojasaus', 'ketjap', 'ketjap manis', 'kecap manis', 'tamari'], 60, 8, 6, 0, true],
  ['peanut_butter', 'Peanut butter', 'Pindakaas', 'pantry', 'g', 350, null, null, 2.79, 'pantry', 365, 90, null, ['peanut butter', 'pindakaas', 'calve pindakaas'], 600, 25, 14, 49],
  ['honey', 'Honey', 'Honing', 'pantry', 'g', 350, null, null, 3.49, 'pantry', 730, 730, null, ['honey', 'honing'], 304, 0.3, 82, 0, true],
  ['curry_paste', 'Curry paste', 'Currypasta', 'pantry', 'g', 100, null, null, 2.49, 'pantry', 365, 30, null, ['curry paste', 'red curry paste', 'green curry paste', 'currypasta', 'rode currypasta', 'groene currypasta', 'boemboe'], 150, 3, 12, 10],
  ['pesto', 'Pesto', 'Pesto', 'pantry', 'g', 190, null, null, 2.49, 'pantry', 365, 7, null, ['pesto', 'groene pesto', 'pesto genovese'], 450, 5, 6, 45],
  ['mustard', 'Mustard', 'Mosterd', 'pantry', 'g', 250, null, null, 1.19, 'fridge', 365, 180, null, ['mustard', 'mosterd', 'dijon', 'grove mosterd'], 150, 7, 6, 10, true],
  ['mayonnaise', 'Mayonnaise', 'Mayonaise', 'pantry', 'ml', 500, null, null, 2.49, 'fridge', 180, 60, null, ['mayo', 'mayonnaise', 'mayonaise', 'fritessaus'], 680, 1, 2, 75],
  ['vinegar', 'Vinegar', 'Azijn', 'pantry', 'ml', 500, null, null, 0.99, 'pantry', 1000, 1000, null, ['vinegar', 'azijn', 'balsamico', 'balsamic vinegar', 'wijnazijn'], 20, 0, 1, 0, true],
  ['breakfast_cereal', 'Muesli', 'Muesli', 'pantry', 'g', 750, null, null, 2.99, 'pantry', 270, 60, null, ['muesli', 'granola', 'cereal', 'cruesli', 'ontbijtgranen', 'cornflakes'], 380, 9, 63, 8],
  ['nuts', 'Mixed nuts', 'Gemengde noten', 'snacks', 'g', 200, null, null, 3.49, 'pantry', 180, 60, null, ['nuts', 'mixed nuts', 'noten', 'gemengde noten', 'cashews', 'cashewnoten', 'walnoten', 'amandelen', 'almonds', 'pinda\'s', 'peanuts'], 600, 20, 15, 52],
  ['chocolate', 'Dark chocolate', 'Pure chocolade', 'snacks', 'g', 100, null, null, 1.99, 'pantry', 365, 90, null, ['chocolate', 'chocolade', 'pure chocolade', 'tony chocolonely', 'melkchocolade'], 550, 7, 45, 38],
  ['crisps', 'Crisps', 'Chips', 'snacks', 'g', 225, null, null, 1.89, 'pantry', 120, 7, null, ['crisps', 'chips', 'paprika chips', 'naturel chips'], 530, 6, 50, 33],
  ['hummus', 'Hummus', 'Hummus', 'dairy', 'g', 200, null, null, 2.19, 'fridge', 14, 5, null, ['hummus', 'houmous'], 300, 7, 12, 25],
  ['coffee', 'Ground coffee', 'Gemalen koffie', 'drinks', 'g', 500, null, null, 6.49, 'pantry', 365, 30, null, ['coffee', 'koffie', 'gemalen koffie', 'koffiebonen', 'coffee beans', 'filterkoffie', 'koffiecups', 'koffiepads'], 0, 0, 0, 0],
  ['tea', 'Tea', 'Thee', 'drinks', 'pcs', 20, 2, 'teabag', 1.89, 'pantry', 730, 365, null, ['tea', 'thee', 'theezakjes', 'tea bags', 'groene thee'], 0, 0, 0, 0],
  ['orange_juice', 'Orange juice', 'Sinaasappelsap', 'drinks', 'ml', 1000, null, null, 2.29, 'fridge', 21, 5, null, ['orange juice', 'juice', 'jus d\'orange', 'jus', 'sinaasappelsap', 'sap'], 45, 0.7, 10, 0.2],
  ['sparkling_water', 'Sparkling water', 'Bruisend water', 'drinks', 'ml', 1500, null, null, 0.69, 'pantry', 365, 3, null, ['sparkling water', 'water', 'spa rood', 'bruisend water', 'mineraalwater'], 0, 0, 0, 0],
  ['beer', 'Beer', 'Bier', 'drinks', 'ml', 3000, 300, 'bottle', 7.99, 'pantry', 180, 1, null, ['beer', 'bier', 'pils', 'krat bier', 'heineken', 'hertog jan'], 43, 0.5, 3.6, 0],

  // Spices (staples)
  ['salt', 'Salt', 'Zout', 'spices', 'g', 500, null, null, 0.59, 'pantry', 3650, 3650, null, ['salt', 'zout', 'zeezout'], 0, 0, 0, 0, true],
  ['pepper', 'Black pepper', 'Zwarte peper', 'spices', 'g', 50, null, null, 1.49, 'pantry', 1000, 1000, null, ['black pepper', 'pepper', 'zwarte peper', 'peper', 'peper en zout'], 250, 10, 64, 3, true],
  ['paprika_powder', 'Paprika powder', 'Paprikapoeder', 'spices', 'g', 40, null, null, 1.29, 'pantry', 730, 730, null, ['paprika powder', 'smoked paprika', 'paprikapoeder', 'gerookt paprikapoeder'], 280, 14, 54, 13, true],
  ['cumin', 'Ground cumin', 'Komijn', 'spices', 'g', 40, null, null, 1.29, 'pantry', 730, 730, null, ['cumin', 'komijn', 'djinten', 'komijnzaad'], 375, 18, 44, 22, true],
  ['curry_powder', 'Curry powder', 'Kerriepoeder', 'spices', 'g', 40, null, null, 1.29, 'pantry', 730, 730, null, ['curry powder', 'kerrie', 'kerriepoeder', 'currypoeder', 'garam masala'], 325, 14, 56, 14, true],
  ['oregano', 'Dried oregano', 'Oregano', 'spices', 'g', 15, null, null, 1.29, 'pantry', 730, 730, null, ['oregano', 'italian herbs', 'italiaanse kruiden', 'tijm', 'thyme', 'gedroogde kruiden'], 265, 9, 69, 4, true],
  ['cinnamon', 'Cinnamon', 'Kaneel', 'spices', 'g', 30, null, null, 1.29, 'pantry', 730, 730, null, ['cinnamon', 'kaneel'], 247, 4, 81, 1.2, true],

  // Frozen
  ['frozen_peas', 'Frozen peas', 'Diepvries doperwten', 'frozen', 'g', 450, null, null, 1.49, 'freezer', 365, null, 365, ['peas', 'frozen peas', 'doperwten', 'erwten', 'diepvries erwten', 'doperwtjes'], 81, 5.4, 14, 0.4],
  ['frozen_spinach', 'Frozen spinach', 'Diepvries spinazie', 'frozen', 'g', 450, null, null, 1.29, 'freezer', 365, null, 365, ['frozen spinach', 'diepvries spinazie', 'spinazie a la creme', 'bladspinazie'], 23, 2.9, 3.6, 0.4],
  ['frozen_berries', 'Frozen berries', 'Diepvries rood fruit', 'frozen', 'g', 300, null, null, 2.79, 'freezer', 365, null, 365, ['frozen berries', 'frozen fruit', 'rood fruit', 'diepvries fruit', 'diepvries bessen'], 50, 1, 11, 0.3],
  ['frozen_pizza', 'Frozen pizza', 'Diepvriespizza', 'frozen', 'pcs', 1, 350, 'pizza', 3.49, 'freezer', 270, null, 270, ['pizza', 'frozen pizza', 'diepvriespizza', 'dr oetker', 'ristorante'], 250, 10, 28, 11],
  ['ice_cream', 'Ice cream', 'IJs', 'frozen', 'ml', 900, null, null, 3.99, 'freezer', 365, null, 365, ['ice cream', 'ijs', 'roomijs', 'ben & jerry\'s', 'magnum'], 200, 3.5, 24, 10],
  // More everyday groceries, so the recipe library can cover Dutch classics and more of the world.
  ['pork_tenderloin', 'Pork tenderloin', 'Varkenshaas', 'meat_fish', 'g', 500, null, null, 7.99, 'fridge', 4, null, 90, ['pork tenderloin', 'pork fillet', 'varkenshaas', 'varkenshaasje'], 120, 22, 0, 3.5],
  ['pork_chops', 'Pork chops', 'Karbonades', 'meat_fish', 'g', 500, 150, 'chop', 5.49, 'fridge', 4, null, 90, ['pork chop', 'pork chops', 'karbonade', 'karbonades', 'schouderkarbonade'], 200, 20, 0, 13],
  ['beef_strips', 'Beef strips', 'Runderreepjes', 'meat_fish', 'g', 300, null, null, 5.99, 'fridge', 3, null, 90, ['beef strips', 'stir-fry beef', 'runderreepjes', 'biefreepjes', 'rundvlees reepjes', 'steak'], 130, 22, 0, 4.5],
  ['white_fish', 'White fish fillet', 'Witvisfilet', 'meat_fish', 'g', 400, 125, 'fillet', 6.99, 'fridge', 2, null, 180, ['white fish', 'cod', 'cod fillet', 'kabeljauw', 'kabeljauwfilet', 'witvis', 'witvisfilet', 'koolvis', 'pollock', 'pangasius', 'tilapia', 'schelvis'], 80, 18, 0, 0.7],
  ['smoked_mackerel', 'Smoked mackerel', 'Gerookte makreel', 'meat_fish', 'g', 200, null, null, 3.49, 'fridge', 14, 3, 90, ['smoked mackerel', 'mackerel', 'makreel', 'gerookte makreel', 'makreelfilet'], 300, 19, 0, 25],
  ['chorizo', 'Chorizo', 'Chorizo', 'meat_fish', 'g', 100, null, null, 2.29, 'fridge', 60, 14, 90, ['chorizo', 'chorizoworst'], 450, 24, 2, 38],
  ['tempeh', 'Tempeh', 'Tempeh', 'meat_fish', 'g', 200, null, null, 2.49, 'fridge', 21, 4, 90, ['tempeh', 'tempé', 'tempe'], 190, 19, 9, 11],
  ['veggie_mince', 'Vegetarian mince', 'Vegetarisch gehakt', 'meat_fish', 'g', 200, null, null, 3.29, 'fridge', 14, 3, 180, ['vegetarian mince', 'veggie mince', 'plant-based mince', 'vegetarisch gehakt', 'vega gehakt', 'vegan gehakt', 'gehaktstukjes'], 190, 18, 6, 10],
  ['kale', 'Curly kale', 'Boerenkool', 'produce', 'g', 500, null, null, 2.49, 'fridge', 5, null, 180, ['kale', 'curly kale', 'boerenkool', 'gesneden boerenkool'], 49, 4.3, 5, 0.9],
  ['sauerkraut', 'Sauerkraut', 'Zuurkool', 'produce', 'g', 500, null, null, 1.49, 'fridge', 21, 5, 90, ['sauerkraut', 'zuurkool'], 20, 1.2, 2, 0.2],
  ['endive', 'Belgian endive', 'Witlof', 'produce', 'g', 500, 125, 'head', 1.99, 'fridge', 7, null, null, ['endive', 'belgian endive', 'chicory', 'witlof', 'witloof'], 17, 1.3, 2.5, 0.2],
  ['cabbage', 'Pointed cabbage', 'Spitskool', 'produce', 'pcs', 1, 800, 'cabbage', 1.29, 'fridge', 14, null, 180, ['cabbage', 'pointed cabbage', 'spitskool', 'white cabbage', 'witte kool', 'savoy cabbage', 'savooiekool'], 25, 1.3, 4.5, 0.1],
  ['red_cabbage', 'Red cabbage', 'Rode kool', 'produce', 'pcs', 1, 900, 'cabbage', 1.49, 'fridge', 21, null, 180, ['red cabbage', 'rode kool', 'rodekool'], 31, 1.4, 5.5, 0.2],
  ['aubergine', 'Aubergine', 'Aubergine', 'produce', 'pcs', 1, 300, 'aubergine', 0.99, 'fridge', 7, null, 180, ['aubergine', 'eggplant', 'aubergines'], 25, 1, 4, 0.2],
  ['celery', 'Celery', 'Bleekselderij', 'produce', 'pcs', 1, 400, 'head', 1.29, 'fridge', 14, null, 180, ['celery', 'bleekselderij', 'selderij', 'stengel bleekselderij'], 16, 0.7, 3, 0.2],
  ['beetroot', 'Cooked beetroot', 'Gekookte bieten', 'produce', 'g', 500, 100, 'beet', 1.29, 'fridge', 14, 4, null, ['beetroot', 'beets', 'bieten', 'rode bieten', 'gekookte bieten', 'bietjes'], 43, 1.6, 8, 0.2],
  ['pumpkin', 'Butternut squash', 'Flespompoen', 'produce', 'pcs', 1, 1000, 'squash', 1.99, 'pantry', 60, null, 180, ['butternut', 'butternut squash', 'pumpkin', 'squash', 'pompoen', 'flespompoen'], 45, 1, 10, 0.1],
  ['rocket', 'Rocket', 'Rucola', 'produce', 'g', 75, null, null, 1.29, 'fridge', 5, null, null, ['rocket', 'arugula', 'rucola'], 25, 2.6, 3.7, 0.7],
  ['dill', 'Dill', 'Dille', 'produce', 'g', 20, null, null, 0.99, 'fridge', 7, null, 180, ['dill', 'dille'], 43, 3.5, 7, 1],
  ['mint', 'Mint', 'Munt', 'produce', 'g', 20, null, null, 0.99, 'fridge', 7, null, 180, ['mint', 'munt', 'verse munt'], 44, 3.3, 8, 0.7],
  ['oranges', 'Oranges', 'Sinaasappels', 'produce', 'pcs', 6, 180, 'orange', 2.49, 'pantry', 21, null, null, ['orange', 'oranges', 'sinaasappel', 'sinaasappels', 'handsinaasappels', 'mandarijnen'], 47, 0.9, 12, 0.1],
  ['couscous', 'Couscous', 'Couscous', 'pantry', 'g', 500, null, null, 1.39, 'pantry', 730, 365, null, ['couscous', 'parelcouscous'], 360, 12.5, 72, 1.5],
  ['bulgur', 'Bulgur', 'Bulgur', 'pantry', 'g', 500, null, null, 1.79, 'pantry', 730, 365, null, ['bulgur', 'bulghur', 'tarwe bulgur'], 350, 12, 70, 1.5],
  ['quinoa', 'Quinoa', 'Quinoa', 'pantry', 'g', 400, null, null, 2.99, 'pantry', 730, 365, null, ['quinoa'], 370, 14, 64, 6],
  ['gnocchi', 'Gnocchi', 'Gnocchi', 'pantry', 'g', 500, null, null, 1.99, 'pantry', 60, 3, 90, ['gnocchi'], 150, 4, 32, 0.4],
  ['lasagne', 'Lasagne sheets', 'Lasagnebladen', 'pantry', 'g', 500, null, null, 1.49, 'pantry', 730, 365, null, ['lasagne', 'lasagna', 'lasagne sheets', 'lasagnebladen'], 360, 12, 72, 1.5],
  ['passata', 'Passata', 'Passata', 'pantry', 'g', 500, null, null, 0.99, 'pantry', 540, 5, null, ['passata', 'tomato passata', 'tomatenpassata', 'gezeefde tomaten', 'tomatensaus'], 32, 1.5, 6, 0.2],
  ['white_beans', 'White beans', 'Witte bonen', 'pantry', 'g', 400, null, null, 0.89, 'pantry', 730, 3, null, ['white beans', 'cannellini', 'cannellini beans', 'butter beans', 'witte bonen', 'cannellinibonen'], 95, 7, 13, 0.5],
  ['black_beans', 'Black beans', 'Zwarte bonen', 'pantry', 'g', 400, null, null, 0.99, 'pantry', 730, 3, null, ['black beans', 'zwarte bonen'], 90, 6, 13, 0.5],
  ['brown_beans', 'Brown beans', 'Bruine bonen', 'pantry', 'g', 400, null, null, 0.89, 'pantry', 730, 3, null, ['brown beans', 'borlotti', 'bruine bonen'], 95, 6.5, 14, 0.5],
  ['corn', 'Sweetcorn', 'Maïs', 'pantry', 'g', 285, null, null, 0.99, 'pantry', 730, 3, 180, ['corn', 'sweetcorn', 'sweet corn', 'mais', 'maïs', 'maiskorrels'], 85, 3, 15, 1.2],
  ['olives', 'Olives', 'Olijven', 'pantry', 'g', 150, null, null, 1.99, 'pantry', 365, 14, null, ['olives', 'olijven', 'kalamata', 'groene olijven', 'zwarte olijven'], 145, 1, 4, 15],
  ['raisins', 'Raisins', 'Rozijnen', 'pantry', 'g', 250, null, null, 1.69, 'pantry', 365, 180, null, ['raisins', 'rozijnen', 'krenten', 'sultanas'], 300, 3, 70, 0.5],
  ['sambal', 'Sambal', 'Sambal', 'pantry', 'g', 200, null, null, 1.69, 'pantry', 365, 90, null, ['sambal', 'sambal oelek', 'chili paste', 'sriracha'], 40, 1, 5, 1.5],
  ['ketchup', 'Ketchup', 'Ketchup', 'pantry', 'ml', 500, null, null, 1.99, 'pantry', 365, 90, null, ['ketchup', 'tomatenketchup', 'curry ketchup'], 100, 1.5, 23, 0.1],
  ['pita', 'Pita bread', "Pita's", 'bakery', 'pcs', 6, 70, 'pita', 1.29, 'pantry', 5, null, 90, ['pita', 'pitas', "pita's", 'pitabroodjes', 'pita bread', 'naan'], 250, 9, 50, 1.2],
  ['cottage_cheese', 'Cottage cheese', 'Hüttenkäse', 'dairy', 'g', 200, null, null, 1.49, 'fridge', 14, 4, null, ['cottage cheese', 'huttenkase', 'hüttenkäse', 'huttenkäse'], 98, 11, 3.4, 4.3],
  ['puff_pastry', 'Puff pastry', 'Bladerdeeg', 'frozen', 'g', 450, 75, 'sheet', 1.79, 'freezer', 365, 2, 365, ['puff pastry', 'bladerdeeg', 'plakjes bladerdeeg'], 390, 6, 37, 24],
];

// Package sizes these products are commonly sold in (base units). When a receipt line doesn't state
// the size, the review asks the user to pick one, in the product's own terms ("How many eggs?").
// Products not listed come in one standard size and are not asked about.
const PACKAGE_OPTIONS: Record<string, number[]> = {
  milk: [500, 1000, 1500, 2000], whole_milk: [500, 1000, 1500], oat_milk: [1000, 1500],
  eggs: [6, 10, 12, 15, 30], butter: [125, 250, 500], yoghurt: [450, 500, 1000], skyr: [150, 450, 1000], quark: [500, 1000],
  cheese: [150, 250, 400, 500, 1000], parmesan: [100, 150, 200], cream: [200, 250, 500],
  onion: [1, 3, 6, 10], red_onion: [1, 3, 5], garlic: [10, 20, 30], potatoes: [500, 1000, 1500, 2000, 2500, 5000], sweet_potato: [250, 500, 1000],
  carrots: [500, 750, 1000], tomatoes: [1, 3, 4, 5, 6, 8], cherry_tomatoes: [250, 500], cucumber: [1, 2], bell_pepper: [1, 2, 3],
  zucchini: [1, 2], broccoli: [300, 500], spinach: [200, 300, 400], lettuce: [100, 150, 200], mushrooms: [250, 400, 500],
  avocado: [1, 2, 3], lemon: [1, 3, 4], lime: [1, 3], apples: [1, 4, 6, 8], bananas: [1, 4, 5, 6, 7], berries: [125, 250, 500],
  chicken_breast: [250, 300, 500, 1000], chicken_thigh: [300, 400, 600], minced_beef: [300, 500, 1000], bacon: [75, 150, 250],
  ham: [100, 150, 250], salmon: [125, 250, 500], shrimp: [150, 200, 400], smoked_sausage: [250, 275, 375],
  bread: [400, 600, 800], wraps: [4, 6, 8], croissants: [1, 4, 6], pasta: [500, 1000], rice: [400, 1000, 2000, 5000],
  noodles: [250, 500], oats: [500, 1000], coffee: [250, 500, 1000], tea: [20, 40, 100], orange_juice: [1000, 1500, 2000],
  sparkling_water: [500, 1000, 1500], beer: [330, 1980, 3000, 7200], crisps: [125, 225, 300], nuts: [150, 200, 400],
  chocolate: [100, 200], frozen_peas: [450, 1000], frozen_berries: [300, 750], canned_tomatoes: [400, 800],
};

// Allergens (EU-14 keys) for the generic catalogue products. Brand products from barcodes get theirs
// from Open Food Facts. These are typical compositions: labels always win.
const ALLERGENS: Record<string, string[]> = {
  milk: ['milk'], whole_milk: ['milk'], butter: ['milk'], yoghurt: ['milk'], skyr: ['milk'], quark: ['milk'], cheese: ['milk'], parmesan: ['milk'],
  mozzarella: ['milk'], feta: ['milk'], cream: ['milk'], creme_fraiche: ['milk'], ice_cream: ['milk', 'eggs'], chocolate: ['milk', 'soy'],
  eggs: ['eggs'], mayonnaise: ['eggs', 'mustard'], noodles: ['gluten', 'eggs'], croissants: ['gluten', 'milk', 'eggs'],
  bread: ['gluten'], wraps: ['gluten'], pasta: ['gluten'], flour: ['gluten'], oats: ['gluten'], breakfast_cereal: ['gluten', 'nuts'],
  soy_sauce: ['soy', 'gluten'], stock_cube: ['celery', 'gluten'], beer: ['gluten'], frozen_pizza: ['gluten', 'milk'],
  salmon: ['fish'], tuna: ['fish'], white_fish: ['fish'], smoked_mackerel: ['fish'], celery: ['celery'], tempeh: ['soy'], veggie_mince: ['soy'],
  skimmed_milk: ['milk'], lactose_free_milk: ['milk'], soy_drink: ['soy'], almond_drink: ['nuts'], buttermilk: ['milk'], whipping_cream: ['milk'], sour_cream: ['milk'],
  cream_cheese: ['milk'], mascarpone: ['milk'], ricotta: ['milk'], gouda_mature: ['milk'], gouda_extra: ['milk'], gouda_old: ['milk'], cheddar: ['milk'], goat_cheese: ['milk'],
  plain_yoghurt: ['milk'], low_fat_yoghurt: ['milk'], evaporated_milk: ['milk'], halloumi: ['milk'], semolina: ['gluten'], burger_buns: ['gluten'], mustard_seeds: ['mustard'], walnuts: ['nuts'], almonds: ['nuts'], cashews: ['nuts'], peanuts: ['peanuts'], pecans: ['nuts'], sesame_seeds: ['sesame'], ghee: ['milk'], condensed_milk: ['milk'], chocolate_chips: ['milk', 'soy'], rice_flour: [], red_wine: ['sulphites'], white_wine: ['sulphites'], margarine: ['milk'], broth: ['celery'], self_raising_flour: ['gluten'], wholemeal_flour: ['gluten'], breadcrumbs: ['gluten'],
  sweet_soy: ['soy', 'gluten'], fish_sauce: ['fish'], oyster_sauce: ['molluscs', 'soy', 'gluten'], sesame_oil: ['sesame'], tahini: ['sesame'], worcestershire: ['fish'], sausages: ['gluten'],
  couscous: ['gluten'], bulgur: ['gluten'], gnocchi: ['gluten'], lasagne: ['gluten', 'eggs'], pita: ['gluten'], puff_pastry: ['gluten'], cottage_cheese: ['milk'], shrimp: ['crustaceans'], nuts: ['nuts', 'peanuts'], peanut_butter: ['peanuts'],
  pesto: ['milk', 'nuts'], tofu: ['soy'], mustard: ['mustard'], hummus: ['sesame'], vinegar: ['sulphites'], oat_milk: ['gluten'],
};

// What a product is, for diet rules: meat, pork, fish (incl. shellfish), animal (any animal product), alcohol.
const DIET_FLAGS: Record<string, string[]> = {
  skimmed_milk: ['animal'], lactose_free_milk: ['animal'], buttermilk: ['animal'], whipping_cream: ['animal'], sour_cream: ['animal'], cream_cheese: ['animal'],
  mascarpone: ['animal'], ricotta: ['animal'], gouda_mature: ['animal'], gouda_extra: ['animal'], gouda_old: ['animal'], cheddar: ['animal'], goat_cheese: ['animal'],
  plain_yoghurt: ['animal'], low_fat_yoghurt: ['animal'], evaporated_milk: ['animal'], halloumi: ['animal'], ghee: ['animal'], condensed_milk: ['animal'], chocolate_chips: ['animal'], red_wine: ['alcohol'], white_wine: ['alcohol'], mixed_mince: ['meat', 'pork', 'animal'], pork_mince: ['meat', 'pork', 'animal'], chicken_mince: ['meat', 'animal'],
  lamb_mince: ['meat', 'animal'], turkey_breast: ['meat', 'animal'], chicken_drumsticks: ['meat', 'animal'], whole_chicken: ['meat', 'animal'], sausages: ['meat', 'pork', 'animal'],
  broth: ['meat', 'animal'], fish_sauce: ['fish', 'animal'], oyster_sauce: ['fish', 'animal'], worcestershire: ['fish', 'animal'], margarine: ['animal'],
  chicken_breast: ['meat', 'animal'], chicken_thigh: ['meat', 'animal'], minced_beef: ['meat', 'animal'], bacon: ['meat', 'pork', 'animal'],
  ham: ['meat', 'pork', 'animal'], smoked_sausage: ['meat', 'pork', 'animal'], frozen_pizza: ['meat', 'animal'],
  salmon: ['fish', 'animal'], tuna: ['fish', 'animal'], white_fish: ['fish', 'animal'], smoked_mackerel: ['fish', 'animal'],
  pork_tenderloin: ['meat', 'pork', 'animal'], pork_chops: ['meat', 'pork', 'animal'], chorizo: ['meat', 'pork', 'animal'], beef_strips: ['meat', 'animal'],
  cottage_cheese: ['animal'], lasagne: ['animal'], shrimp: ['fish', 'animal'],
  milk: ['animal'], whole_milk: ['animal'], butter: ['animal'], yoghurt: ['animal'], skyr: ['animal'], quark: ['animal'], cheese: ['animal'],
  parmesan: ['animal'], mozzarella: ['animal'], feta: ['animal'], cream: ['animal'], creme_fraiche: ['animal'], ice_cream: ['animal'],
  eggs: ['animal'], mayonnaise: ['animal'], noodles: ['animal'], croissants: ['animal'], honey: ['animal'], pesto: ['animal'], chocolate: ['animal'],
  beer: ['alcohol'],
};

export interface CatalogueProduct {
  id: string; name: string; name_nl: string; category: string; unit: 'g' | 'ml' | 'pcs';
  package_size: number; piece_size: number | null; piece_name: string | null; price: number | null;
  default_location: string; shelf_life_days: number; opened_life_days: number | null; freezer_life_days: number | null;
  synonyms: string[]; nutrition: { kcal: number; protein: number; carbs: number; fat: number; sugars?: number; satFat?: number; fibre?: number; salt?: number }; staple: boolean;
  density: number | null;
  package_options: number[];
  allergens: string[];
  diet_flags: string[];
}

const extra = (id: string) => {
  const e = NUTRITION_EXTRA[id];
  return e ? { sugars: e[0], satFat: e[1], fibre: e[2], salt: e[3] } : {};
};

// Older products lose names that belong to a family or to a newer, more precise product.
const fixed = (r: Row): Row => {
  const drop = new Set(SYNONYM_FIXES[r[0]] ?? []);
  const rn = RENAMES[r[0]] ?? {};
  const piece = PIECE_FIXES[r[0]];
  if (piece) r = [...r.slice(0, 6), piece[0], piece[1], ...r.slice(8)] as unknown as Row;
  return [r[0], rn.en ?? r[1], rn.nl ?? r[2], ...r.slice(3, 13), [...r[13].filter((x) => !drop.has(x)), ...(SYNONYM_ADDS[r[0]] ?? [])], ...r.slice(14)] as unknown as Row;
};

export const CATALOGUE: CatalogueProduct[] = [...ROWS, ...(EXTRA_ROWS as Row[])].map(fixed).map((r) => ({
  id: `p_${r[0]}`, name: r[1], name_nl: r[2], category: r[3], unit: r[4], package_size: r[5], piece_size: r[6], piece_name: r[7],
  price: r[8], default_location: r[9], shelf_life_days: r[10], opened_life_days: r[11], freezer_life_days: r[12],
  synonyms: [...new Set([r[1].toLowerCase(), r[2].toLowerCase(), ...r[13].map((s) => s.toLowerCase())])],
  nutrition: { kcal: r[14], protein: r[15], carbs: r[16], fat: r[17], ...extra(r[0]) }, staple: !!r[18],
  density: NUTRITION_EXTRA[r[0]]?.[4] ?? null,
  package_options: PACKAGE_OPTIONS[r[0]] ?? [],
  allergens: ALLERGENS[r[0]] ?? [],
  diet_flags: DIET_FLAGS[r[0]] ?? [],
}));

export const CATEGORY_LABELS: Record<string, { en: string; nl: string; order: number }> = {
  produce: { en: 'Fruit & vegetables', nl: 'Groente & fruit', order: 1 },
  bakery: { en: 'Bread & bakery', nl: 'Brood & bakkerij', order: 2 },
  meat_fish: { en: 'Meat, fish & vegetarian', nl: 'Vlees, vis & vega', order: 3 },
  dairy: { en: 'Dairy, cheese & eggs', nl: 'Zuivel, kaas & eieren', order: 4 },
  pantry: { en: 'Pantry', nl: 'Voorraadkast', order: 5 },
  spices: { en: 'Herbs & spices', nl: 'Kruiden & specerijen', order: 6 },
  snacks: { en: 'Snacks', nl: 'Snacks', order: 7 },
  drinks: { en: 'Drinks', nl: 'Dranken', order: 8 },
  frozen: { en: 'Frozen', nl: 'Diepvries', order: 9 },
  other: { en: 'Other', nl: 'Overig', order: 10 },
};
