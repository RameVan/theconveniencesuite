import { DatabaseSync } from 'node:sqlite';
import { randomUUID } from 'node:crypto';
import { readdirSync, readFileSync, mkdirSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { log } from '../log.ts';

const here = path.dirname(fileURLToPath(import.meta.url));
const MIGRATIONS_DIR = path.join(here, 'migrations');

export type Row = Record<string, any>;

/** Thin wrapper over node:sqlite with typed helpers and nested-safe transactions. */
const RECIPE_WRITE = /\b(?:INSERT(?:\s+OR\s+\w+)?\s+INTO|REPLACE\s+INTO|UPDATE|DELETE\s+FROM)\s+(?:recipes|recipe_ingredients|products|recipe_retention|substitution_prefs|substitutions|foreign_ingredients|ingredient_availability)\b/i;

export class Db {
  readonly raw: DatabaseSync;
  private depth = 0;
  private stmts = new Map<string, ReturnType<DatabaseSync['prepare']>>();
  private touchesRecipes = new Map<string, boolean>();
  /**
   * Goes up on every write to what a calculated recipe depends on (recipes, their ingredients, products,
   * counted shares). The recipe cache compares it, so no write path can leave the cache stale.
   */
  recipeVersion = 0;
  /** Called after such a write (the recipe cache uses it to rebuild in the background). */
  onRecipeWrite: (() => void) | null = null;

  constructor(file: string) {
    if (file !== ':memory:') mkdirSync(path.dirname(file), { recursive: true });
    this.raw = new DatabaseSync(file);
    this.raw.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000; PRAGMA synchronous = NORMAL;');
  }

  private prep(sql: string) {
    let s = this.stmts.get(sql);
    if (!s) {
      s = this.raw.prepare(sql);
      this.stmts.set(sql, s);
    }
    return s;
  }

  all<T = Row>(sql: string, ...params: any[]): T[] {
    return this.prep(sql).all(...params) as T[];
  }
  get<T = Row>(sql: string, ...params: any[]): T | undefined {
    return this.prep(sql).get(...params) as T | undefined;
  }
  run(sql: string, ...params: any[]) {
    let t = this.touchesRecipes.get(sql);
    if (t === undefined) this.touchesRecipes.set(sql, (t = RECIPE_WRITE.test(sql)));
    if (t) {
      this.recipeVersion++;
      this.onRecipeWrite?.();
    }
    return this.prep(sql).run(...params);
  }
  exec(sql: string) {
    this.recipeVersion++; // raw SQL (migrations, tests): assume it may change anything
    this.raw.exec(sql);
  }

  /** Insert a row from an object; undefined values are skipped. */
  insert(table: string, row: Row) {
    const keys = Object.keys(row).filter((k) => row[k] !== undefined);
    const sql = `INSERT INTO ${table} (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`;
    return this.run(sql, ...keys.map((k) => normalizeParam(row[k])));
  }

  update(table: string, id: string, patch: Row, idColumn = 'id') {
    const keys = Object.keys(patch).filter((k) => patch[k] !== undefined);
    if (!keys.length) return;
    const sql = `UPDATE ${table} SET ${keys.map((k) => `${k} = ?`).join(', ')} WHERE ${idColumn} = ?`;
    return this.run(sql, ...keys.map((k) => normalizeParam(patch[k])), id);
  }

  /**
   * Run fn inside a write transaction. BEGIN IMMEDIATE takes the write lock up front,
   * so concurrent writers serialise instead of interleaving reads and writes.
   * Nested calls join the outer transaction via savepoints.
   */
  tx<T>(fn: () => T): T {
    if (this.depth > 0) {
      const sp = `sp${this.depth}`;
      this.raw.exec(`SAVEPOINT ${sp}`);
      this.depth++;
      try {
        const r = fn();
        this.raw.exec(`RELEASE ${sp}`);
        return r;
      } catch (e) {
        this.raw.exec(`ROLLBACK TO ${sp}; RELEASE ${sp}`);
        throw e;
      } finally {
        this.depth--;
      }
    }
    this.raw.exec('BEGIN IMMEDIATE');
    this.depth++;
    try {
      const r = fn();
      this.raw.exec('COMMIT');
      return r;
    } catch (e) {
      this.raw.exec('ROLLBACK');
      throw e;
    } finally {
      this.depth--;
    }
  }

  migrate() {
    this.raw.exec('CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL)');
    const applied = new Set(this.all<{ name: string }>('SELECT name FROM schema_migrations').map((r) => r.name));
    const files = readdirSync(MIGRATIONS_DIR).filter((f) => f.endsWith('.sql')).sort();
    for (const f of files) {
      if (applied.has(f)) continue;
      const sql = readFileSync(path.join(MIGRATIONS_DIR, f), 'utf8');
      this.tx(() => {
        this.raw.exec(sql);
        this.run('INSERT INTO schema_migrations (name, applied_at) VALUES (?, ?)', f, new Date().toISOString());
      });
      log.info('migration applied', { file: f });
    }
  }

  /** Consistent online backup into a new file (SQLite VACUUM INTO). */
  backupTo(file: string) {
    mkdirSync(path.dirname(file), { recursive: true });
    this.raw.exec(`VACUUM INTO '${file.replaceAll("'", "''")}'`);
  }

  close() {
    this.raw.close();
  }
}

function normalizeParam(v: any) {
  if (v === null) return null;
  if (typeof v === 'boolean') return v ? 1 : 0;
  if (typeof v === 'object') return JSON.stringify(v);
  return v;
}

export const newId = (prefix: string) => `${prefix}_${randomUUID().replaceAll('-', '').slice(0, 20)}`;

export function parseJson<T>(s: string | null | undefined, fallback: T): T {
  if (s == null) return fallback;
  try {
    return JSON.parse(s) as T;
  } catch {
    return fallback;
  }
}
