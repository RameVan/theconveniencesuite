// What PantryPip knows about ingredients beyond the product rows: families and their variants (asked about
// when you just say "milk"), subcategories, measurement rules, substitutions, ingredients that aren't sold
// in ordinary supermarkets, and countries with their supermarket chains.
//
// Sources and status: culinary relationships and typical Dutch retail packaging are PantryPip's own
// editorial table (general culinary and Dutch retail knowledge), marked as such in the database. Products
// actually listed at a chain come separately from Open Food Facts (retail_products, status 'listed').

// ---------- Families and variants ----------

export interface Family {
  id: string;
  name: string; name_nl: string;
  /** Words that name the family without saying which kind ("milk", "kaas"). */
  words: string[];
  /** Ask which kind when only the family is named (stock accuracy, recipes, nutrition differ). */
  clarify: boolean;
  question: [string, string];
  /** Variants in the order they're offered. A nested group opens a second question. */
  variants: (string | { group: string; name: string; name_nl: string; variants: string[] })[];
}

export const FAMILIES: Family[] = [
  {
    id: 'milk', name: 'Milk', name_nl: 'Melk', words: ['milk', 'melk'], clarify: true, question: ['Which milk?', 'Welke melk?'],
    variants: ['p_milk', 'p_whole_milk', 'p_skimmed_milk', 'p_lactose_free_milk', { group: 'plant_milk', name: 'Plant-based', name_nl: 'Plantaardig', variants: ['p_oat_milk', 'p_soy_drink', 'p_almond_drink', 'p_coconut_drink'] }],
  },
  { id: 'plant_milk', name: 'Plant-based drink', name_nl: 'Plantaardige drank', words: ['plant milk', 'plant-based milk', 'plantaardige melk', 'plantaardige drank', 'vegan milk'], clarify: true, question: ['Which plant drink?', 'Welke plantaardige drank?'], variants: ['p_oat_milk', 'p_soy_drink', 'p_almond_drink', 'p_coconut_drink'] },
  {
    id: 'cheese', name: 'Cheese', name_nl: 'Kaas', words: ['cheese', 'kaas', 'gouda', 'goudse kaas', 'plakken kaas', 'blok kaas'], clarify: true, question: ['Which cheese?', 'Welke kaas?'],
    variants: ['p_cheese', 'p_gouda_mature', 'p_gouda_extra', 'p_gouda_old', 'p_cheddar', 'p_mozzarella', 'p_parmesan', 'p_feta', 'p_goat_cheese'],
  },
  { id: 'cream', name: 'Cream', name_nl: 'Room', words: ['cream', 'room'], clarify: true, question: ['Which cream?', 'Welke room?'], variants: ['p_cream', 'p_whipping_cream', 'p_sour_cream', 'p_creme_fraiche'] },
  { id: 'yoghurt', name: 'Yoghurt', name_nl: 'Yoghurt', words: ['yoghurt', 'yogurt'], clarify: true, question: ['Which yoghurt?', 'Welke yoghurt?'], variants: ['p_plain_yoghurt', 'p_low_fat_yoghurt', 'p_yoghurt', 'p_skyr', 'p_quark'] },
  { id: 'chicken', name: 'Chicken', name_nl: 'Kip', words: ['chicken', 'kip'], clarify: true, question: ['Which chicken?', 'Welke kip?'], variants: ['p_chicken_breast', 'p_chicken_thigh', 'p_chicken_drumsticks', 'p_whole_chicken', 'p_chicken_mince'] },
  { id: 'mince', name: 'Mince', name_nl: 'Gehakt', words: ['mince', 'gehakt', 'ground meat', 'minced meat'], clarify: true, question: ['Which mince?', 'Welk gehakt?'], variants: ['p_minced_beef', 'p_mixed_mince', 'p_pork_mince', 'p_chicken_mince', 'p_lamb_mince', 'p_veggie_mince'] },
  { id: 'beef', name: 'Beef', name_nl: 'Rundvlees', words: ['beef', 'rundvlees'], clarify: true, question: ['Which beef?', 'Welk rundvlees?'], variants: ['p_beef_strips', 'p_minced_beef'] },
  { id: 'pork', name: 'Pork', name_nl: 'Varkensvlees', words: ['pork', 'varkensvlees'], clarify: true, question: ['Which pork?', 'Welk varkensvlees?'], variants: ['p_pork_tenderloin', 'p_pork_chops', 'p_pork_mince'] },
  { id: 'fish', name: 'Fish', name_nl: 'Vis', words: ['fish', 'vis', 'fish fillet', 'visfilet'], clarify: true, question: ['Which fish?', 'Welke vis?'], variants: ['p_white_fish', 'p_salmon', 'p_smoked_mackerel'] },
  { id: 'rice', name: 'Rice', name_nl: 'Rijst', words: ['rice', 'rijst'], clarify: true, question: ['Which rice?', 'Welke rijst?'], variants: ['p_rice', 'p_pandan_rice', 'p_brown_rice', 'p_risotto_rice'] },
  { id: 'noodles', name: 'Noodles', name_nl: 'Noedels', words: ['noodles', 'noedels'], clarify: true, question: ['Which noodles?', 'Welke noedels?'], variants: ['p_noodles', 'p_rice_noodles'] },
];

// ---------- Subcategories ----------

const SUB: Record<string, string[]> = {
  milk: ['milk', 'whole_milk', 'skimmed_milk', 'lactose_free_milk', 'buttermilk', 'evaporated_milk'],
  plant_drink: ['oat_milk', 'soy_drink', 'almond_drink', 'coconut_drink'],
  cream: ['cream', 'whipping_cream', 'sour_cream', 'creme_fraiche'],
  yoghurt_quark: ['yoghurt', 'plain_yoghurt', 'low_fat_yoghurt', 'skyr', 'quark'],
  hard_cheese: ['cheese', 'gouda_mature', 'gouda_extra', 'gouda_old', 'cheddar', 'parmesan'],
  soft_cheese: ['mozzarella', 'feta', 'goat_cheese', 'cream_cheese', 'mascarpone', 'ricotta', 'cottage_cheese', 'halloumi'],
  fat: ['butter', 'margarine', 'olive_oil', 'sunflower_oil', 'sesame_oil', 'ghee'],
  eggs: ['eggs'],
  vegetable: ['pineapple', 'onion', 'red_onion', 'shallot', 'garlic', 'potatoes', 'sweet_potato', 'carrots', 'tomatoes', 'cherry_tomatoes', 'cucumber', 'bell_pepper', 'zucchini', 'broccoli', 'cauliflower', 'spinach', 'lettuce', 'mushrooms', 'leek', 'green_beans', 'avocado', 'kale', 'sauerkraut', 'endive', 'cabbage', 'red_cabbage', 'aubergine', 'celery', 'beetroot', 'pumpkin', 'rocket', 'spring_onion', 'wok_vegetables', 'okra', 'cassava', 'pak_choi', 'bean_sprouts', 'parsnip', 'plantain'],
  chilli: ['chili', 'green_chili', 'madame_jeanette', 'jalapeno'],
  fruit: ['lemon', 'lime', 'apples', 'bananas', 'berries', 'oranges', 'peaches', 'dates'],
  fresh_herb: ['parsley', 'coriander', 'basil', 'dill', 'mint', 'rosemary', 'chives', 'ginger', 'fresh_thyme'],
  poultry: ['chicken_breast', 'chicken_thigh', 'chicken_drumsticks', 'whole_chicken', 'turkey_breast', 'chicken_mince'],
  red_meat: ['minced_beef', 'mixed_mince', 'pork_mince', 'lamb_mince', 'beef_strips', 'pork_tenderloin', 'pork_chops'],
  cured_meat: ['bacon', 'ham', 'smoked_sausage', 'chorizo', 'sausages'],
  fish: ['salmon', 'tuna', 'white_fish', 'smoked_mackerel', 'shrimp'],
  plant_protein: ['tofu', 'tempeh', 'veggie_mince'],
  legume: ['chickpeas', 'kidney_beans', 'black_beans', 'white_beans', 'brown_beans', 'lentils', 'frozen_peas'],
  grain_pasta: ['pasta', 'rice', 'pandan_rice', 'brown_rice', 'risotto_rice', 'noodles', 'rice_noodles', 'couscous', 'bulgur', 'quinoa', 'gnocchi', 'lasagne', 'oats', 'breakfast_cereal'],
  flour_baking: ['semolina', 'cornmeal', 'rice_flour', 'desiccated_coconut', 'flour', 'self_raising_flour', 'wholemeal_flour', 'cornstarch', 'baking_powder', 'baking_soda', 'dry_yeast', 'breadcrumbs', 'puff_pastry'],
  sugar_sweetener: ['sugar', 'brown_sugar', 'powdered_sugar', 'vanilla_sugar', 'honey', 'maple_syrup', 'vanilla_extract', 'condensed_milk', 'cocoa_powder', 'chocolate_chips'],
  sauce_condiment: ['lemon_juice', 'red_wine', 'white_wine', 'soy_sauce', 'sweet_soy', 'fish_sauce', 'oyster_sauce', 'worcestershire', 'sambal', 'ketchup', 'mayonnaise', 'mustard', 'pesto', 'curry_paste', 'vinegar', 'rice_vinegar', 'tahini', 'peanut_butter', 'hummus'],
  canned_jar: ['canned_tomatoes', 'passata', 'tomato_paste', 'coconut_milk', 'corn', 'olives', 'tuna'],
  stock: ['stock_cube', 'broth'],
  spice: ['marjoram', 'mustard_seeds', 'allspice', 'salt', 'pepper', 'paprika_powder', 'cumin', 'curry_powder', 'oregano', 'cinnamon', 'cayenne', 'chili_powder', 'chili_flakes', 'turmeric', 'garam_masala', 'ground_coriander', 'ginger_powder', 'garlic_powder', 'onion_powder', 'nutmeg', 'italian_herbs', 'thyme', 'bay_leaf', 'cloves', 'cardamom'],
  bread: ['bread', 'wraps', 'pita', 'croissants', 'burger_buns'],
  frozen: ['frozen_spinach', 'frozen_berries', 'frozen_pizza', 'ice_cream'],
  drink: ['coffee', 'tea', 'orange_juice', 'sparkling_water', 'beer'],
  snack: ['nuts', 'walnuts', 'almonds', 'cashews', 'peanuts', 'pecans', 'sesame_seeds', 'chocolate', 'crisps', 'raisins'],
};
export const SUBCATEGORY: Record<string, string> = Object.fromEntries(Object.entries(SUB).flatMap(([sub, ids]) => ids.map((id) => [`p_${id}`, sub])));

/** Family of a product, from the family variant lists. */
export const FAMILY_OF: Record<string, string> = {};
for (const f of FAMILIES) for (const v of f.variants) for (const id of typeof v === 'string' ? [v] : v.variants) FAMILY_OF[id] ??= f.id;

// ---------- Measurement definitions ----------

export interface Measure {
  /** How amounts are written in recipes. */
  recipeUnit: 'g' | 'ml' | 'pcs' | 'tsp' | 'tbsp';
  /** Smallest amount worth recording (base unit). */
  minQty: number;
  /** Rounding step for display and shopping (base unit). */
  precision: number;
  /** More than this per serving in a recipe is almost certainly a misread amount (base unit). */
  maxPerServing: number;
  /** Small kitchen measures (pinch, dash, sprig…) make sense for this ingredient. */
  smallMeasures: boolean;
  source: 'pantrypip-table';
}

const BY_SUB: Record<string, Omit<Measure, 'source'>> = {
  spice: { recipeUnit: 'tsp', minQty: 0.1, precision: 0.1, maxPerServing: 8, smallMeasures: true },
  fresh_herb: { recipeUnit: 'g', minQty: 0.5, precision: 1, maxPerServing: 25, smallMeasures: true },
  stock: { recipeUnit: 'ml', minQty: 1, precision: 10, maxPerServing: 500, smallMeasures: false },
  sauce_condiment: { recipeUnit: 'tbsp', minQty: 1, precision: 5, maxPerServing: 80, smallMeasures: true },
  fat: { recipeUnit: 'tbsp', minQty: 1, precision: 5, maxPerServing: 60, smallMeasures: true },
  sugar_sweetener: { recipeUnit: 'g', minQty: 1, precision: 5, maxPerServing: 120, smallMeasures: true },
  flour_baking: { recipeUnit: 'g', minQty: 1, precision: 5, maxPerServing: 250, smallMeasures: true },
  milk: { recipeUnit: 'ml', minQty: 5, precision: 10, maxPerServing: 500, smallMeasures: true },
  plant_drink: { recipeUnit: 'ml', minQty: 5, precision: 10, maxPerServing: 500, smallMeasures: true },
  cream: { recipeUnit: 'ml', minQty: 5, precision: 10, maxPerServing: 200, smallMeasures: true },
  yoghurt_quark: { recipeUnit: 'g', minQty: 5, precision: 10, maxPerServing: 400, smallMeasures: false },
  hard_cheese: { recipeUnit: 'g', minQty: 5, precision: 10, maxPerServing: 150, smallMeasures: false },
  soft_cheese: { recipeUnit: 'g', minQty: 5, precision: 10, maxPerServing: 200, smallMeasures: false },
  eggs: { recipeUnit: 'pcs', minQty: 1, precision: 1, maxPerServing: 4, smallMeasures: false },
  vegetable: { recipeUnit: 'g', minQty: 5, precision: 10, maxPerServing: 600, smallMeasures: false },
  chilli: { recipeUnit: 'pcs', minQty: 0.25, precision: 0.25, maxPerServing: 3, smallMeasures: true },
  fruit: { recipeUnit: 'pcs', minQty: 0.1, precision: 0.25, maxPerServing: 3, smallMeasures: false },
  poultry: { recipeUnit: 'g', minQty: 25, precision: 25, maxPerServing: 500, smallMeasures: false },
  red_meat: { recipeUnit: 'g', minQty: 25, precision: 25, maxPerServing: 450, smallMeasures: false },
  cured_meat: { recipeUnit: 'g', minQty: 10, precision: 10, maxPerServing: 250, smallMeasures: false },
  fish: { recipeUnit: 'g', minQty: 25, precision: 25, maxPerServing: 400, smallMeasures: false },
  plant_protein: { recipeUnit: 'g', minQty: 25, precision: 25, maxPerServing: 400, smallMeasures: false },
  legume: { recipeUnit: 'g', minQty: 10, precision: 10, maxPerServing: 350, smallMeasures: false },
  grain_pasta: { recipeUnit: 'g', minQty: 10, precision: 10, maxPerServing: 200, smallMeasures: false },
  canned_jar: { recipeUnit: 'g', minQty: 10, precision: 10, maxPerServing: 400, smallMeasures: false },
  bread: { recipeUnit: 'pcs', minQty: 1, precision: 1, maxPerServing: 300, smallMeasures: false },
};
const OVERRIDES: Record<string, Partial<Measure>> = {
  p_salt: { maxPerServing: 5, precision: 0.1 },
  p_garlic: { recipeUnit: 'pcs', precision: 0.5, maxPerServing: 6 },
  p_ginger: { maxPerServing: 20 },
  p_onion: { recipeUnit: 'pcs', precision: 0.5, maxPerServing: 2 },
  p_red_onion: { recipeUnit: 'pcs', precision: 0.5, maxPerServing: 2 },
  p_shallot: { recipeUnit: 'pcs', precision: 1, maxPerServing: 4 },
  p_spring_onion: { recipeUnit: 'pcs', precision: 1, maxPerServing: 5 },
  p_stock_cube: { recipeUnit: 'pcs', precision: 0.5, maxPerServing: 1.5, smallMeasures: false },
  p_lemon: { maxPerServing: 1.5 }, p_lime: { maxPerServing: 1.5 },
  p_bay_leaf: { recipeUnit: 'pcs', maxPerServing: 1 },
  p_sugar: { maxPerServing: 150 },
  p_water: {},
};

export function measureFor(p: { id: string; unit: string; category: string }): Measure {
  const sub = SUBCATEGORY[p.id];
  const base = BY_SUB[sub] ?? { recipeUnit: p.unit as Measure['recipeUnit'], minQty: p.unit === 'pcs' ? 0.25 : 1, precision: p.unit === 'pcs' ? 0.5 : 5, maxPerServing: p.unit === 'pcs' ? 6 : 500, smallMeasures: false };
  const m = { ...base, ...(OVERRIDES[p.id] ?? {}), source: 'pantrypip-table' as const };
  // A pcs product can't be measured in spoons in recipes.
  if (p.unit === 'pcs' && (m.recipeUnit === 'tsp' || m.recipeUnit === 'tbsp' || m.recipeUnit === 'g' || m.recipeUnit === 'ml')) m.recipeUnit = 'pcs';
  return m;
}

/** Typical Dutch retail pack sizes (base unit) for products added in 2026-11; older ones are in catalogue.ts. */
export const PACKS: Record<string, number[]> = {
  skimmed_milk: [500, 1000, 1500], lactose_free_milk: [1000], soy_drink: [1000], almond_drink: [1000], coconut_drink: [1000], buttermilk: [500, 1000],
  evaporated_milk: [170, 340, 500], whipping_cream: [200, 250, 500], sour_cream: [125, 200], cream_cheese: [150, 175, 200], mascarpone: [250, 500], ricotta: [250],
  gouda_mature: [150, 200, 400, 500, 1000], gouda_extra: [150, 200, 400, 500], gouda_old: [150, 200, 400, 500], cheddar: [150, 200], goat_cheese: [100, 150],
  halloumi: [200, 225, 250], plain_yoghurt: [500, 1000], low_fat_yoghurt: [500, 1000], margarine: [250, 500],
  shallot: [3, 6, 10], green_chili: [3, 5], madame_jeanette: [3, 5], rosemary: [15, 20], chives: [20, 25], plantain: [1, 2], okra: [200, 250],
  pak_choi: [1, 2], bean_sprouts: [200, 300, 400], parsnip: [500, 1000],
  mixed_mince: [300, 500, 1000], pork_mince: [300, 500], chicken_mince: [300, 400], lamb_mince: [300, 400], turkey_breast: [300, 400, 500],
  chicken_drumsticks: [500, 600, 1000], whole_chicken: [1200, 1300, 1500], sausages: [300, 400],
  broth: [500, 1000], cornstarch: [200, 400], baking_powder: [32, 64, 100], dry_yeast: [7, 21, 30], vanilla_sugar: [8, 80], brown_sugar: [500, 600],
  powdered_sugar: [250, 500], self_raising_flour: [500, 1000], wholemeal_flour: [1000], breadcrumbs: [200, 400],
  pandan_rice: [400, 1000, 2000, 5000], brown_rice: [400, 1000], risotto_rice: [500, 1000], rice_noodles: [200, 250, 400],
  sweet_soy: [150, 250, 500], fish_sauce: [150, 200, 700], oyster_sauce: [150, 250], sesame_oil: [150, 250], rice_vinegar: [150, 250], tahini: [200, 250, 300],
  maple_syrup: [250, 500], worcestershire: [150, 290], lemon_juice: [200, 500], ghee: [250, 500], cocoa_powder: [125, 250], red_wine: [750], white_wine: [750],
  semolina: [500], dates: [200, 250, 500], pineapple: [1], peaches: [4, 6], marjoram: [10], mustard_seeds: [40], burger_buns: [4, 6], allspice: [25, 35], pecans: [100, 150], sesame_seeds: [100, 200], cornmeal: [500, 1000], rice_flour: [400, 500], chocolate_chips: [100, 200], condensed_milk: [397], desiccated_coconut: [100, 200], walnuts: [150, 200, 500], almonds: [150, 200], cashews: [150, 200, 300], peanuts: [300, 500],
};

// ---------- Substitutions ----------

/** 'p_x' is a catalogue product; 'x:name' an ingredient that isn't one (see FOREIGN). */
export interface Substitution {
  from: string;
  to: string;
  /** Extra products to add alongside, per unit of `to` (buttermilk → milk + a little lemon). */
  with?: { product: string; perUnit: number }[];
  kind: 'equivalent' | 'substitute' | 'approximate';
  /** Amount of `to` per amount of `from`. */
  ratio?: number;
  /** Countries where this applies; empty = everywhere. */
  countries?: string[];
  note: [string, string];
  prep?: [string, string];
  /** Changes what the dish is: shown more prominently. */
  identity?: boolean;
}

export const SUBSTITUTIONS: Substitution[] = [
  // Not sold in ordinary supermarkets → realistic Dutch alternatives
  { from: 'x:habanero', to: 'p_madame_jeanette', kind: 'substitute', note: ['Madame Jeanette is a close cousin of the habanero: similar heat and fruity taste.', 'Madame Jeanette is familie van de habanero: vergelijkbaar heet en fruitig.'] },
  { from: 'x:scotch-bonnet', to: 'p_madame_jeanette', kind: 'substitute', note: ['Madame Jeanette is a very similar Caribbean-style pepper.', 'Madame Jeanette lijkt sterk op scotch bonnet.'] },
  { from: 'x:serrano', to: 'p_green_chili', kind: 'substitute', note: ['Green chilli is a little milder; add more if you like it hot.', 'Groene peper is iets milder; neem er meer van voor meer pit.'] },
  { from: 'x:poblano', to: 'p_bell_pepper', with: [{ product: 'p_green_chili', perUnit: 0.25 }], kind: 'approximate', note: ['Bell pepper with a little green chilli: milder and less smoky than poblano.', 'Paprika met wat groene peper: milder en minder rokerig dan poblano.'] },
  { from: 'x:anaheim', to: 'p_bell_pepper', with: [{ product: 'p_green_chili', perUnit: 0.25 }], kind: 'approximate', note: ['Bell pepper plus a little chilli comes close to the mild Anaheim.', 'Paprika met wat peper komt dicht bij de milde Anaheim.'] },
  { from: 'x:chipotle', to: 'p_paprika_powder', with: [{ product: 'p_chili_flakes', perUnit: 0.5 }], kind: 'approximate', note: ['Smoked paprika and chilli flakes give the smoky heat of chipotle.', 'Gerookt paprikapoeder met chilivlokken geeft de rokerige pit van chipotle.'] },
  { from: 'x:ancho', to: 'p_paprika_powder', with: [{ product: 'p_chili_powder', perUnit: 0.3 }], kind: 'approximate', note: ['Mild, fruity ancho is best replaced by smoked paprika with a little chilli powder.', 'Milde, fruitige ancho: gerookt paprikapoeder met wat chilipoeder.'] },
  { from: 'x:fresh-jalapeno', to: 'p_green_chili', kind: 'substitute', note: ['Fresh jalapeños are rare in Dutch shops; a green chilli is similar.', 'Verse jalapeño is zeldzaam; een groene peper lijkt erop.'] },
  { from: 'x:half-and-half', to: 'p_whole_milk', with: [{ product: 'p_whipping_cream', perUnit: 1 }], ratio: 0.5, kind: 'substitute', note: ['Equal parts whole milk and whipping cream make half-and-half.', 'Gelijke delen volle melk en slagroom maken half-and-half.'], prep: ['Mix the milk and cream before using.', 'Meng de melk en de room voor gebruik.'] },
  { from: 'x:cream-of-mushroom-soup', to: 'p_cream', with: [{ product: 'p_mushrooms', perUnit: 0.6 }], kind: 'substitute', note: ['Condensed soup isn’t a Dutch staple: cooking cream with fried mushrooms does the same job.', 'Gecondenseerde soep is hier geen basisproduct: kookroom met gebakken champignons werkt hetzelfde.'], prep: ['Fry the chopped mushrooms first, then add the cream and simmer until thick.', 'Bak eerst de gesneden champignons, voeg de room toe en laat indikken.'] },
  { from: 'x:monterey-jack', to: 'p_cheese', kind: 'approximate', note: ['Young matured Gouda melts and tastes much like Monterey Jack.', 'Jong belegen kaas smelt en smaakt ongeveer als Monterey Jack.'] },
  { from: 'x:american-cheese', to: 'p_cheese', kind: 'approximate', note: ['Young Gouda slices are the closest common melting cheese.', 'Jonge kaasplakken komen het dichtst bij als smeltkaas.'] },
  { from: 'x:colby', to: 'p_cheese', kind: 'approximate', note: ['Mild, semi-hard: young matured Gouda is close.', 'Mild en halfhard: jong belegen kaas komt dichtbij.'] },
  { from: 'x:gruyere', to: 'p_gouda_extra', kind: 'substitute', note: ['Extra mature Gouda has the nutty depth of Gruyère and melts well.', 'Extra belegen kaas heeft de nootachtige smaak van Gruyère en smelt goed.'] },
  { from: 'x:pecorino', to: 'p_parmesan', kind: 'substitute', note: ['Parmesan is milder and less salty than pecorino.', 'Parmezaan is milder en minder zout dan pecorino.'] },
  { from: 'x:queso-fresco', to: 'p_feta', kind: 'substitute', note: ['Feta crumbles the same way but is saltier: use a little less.', 'Feta brokkelt hetzelfde maar is zouter: gebruik iets minder.'], ratio: 0.8 },
  { from: 'x:paneer', to: 'p_halloumi', kind: 'substitute', note: ['Halloumi holds its shape like paneer but is saltier.', 'Halloumi blijft heel zoals paneer maar is zouter.'] },
  { from: 'x:ground-turkey', to: 'p_chicken_mince', kind: 'substitute', note: ['Chicken mince is the closest lean poultry mince in Dutch shops.', 'Kipgehakt is het dichtstbijzijnde magere gevogeltegehakt.'] },
  { from: 'x:whole-turkey', to: 'p_whole_chicken', kind: 'approximate', identity: true, ratio: 0.3, note: ['A whole turkey is a different dish; a whole chicken works for a smaller roast.', 'Een hele kalkoen is een ander gerecht; een hele kip werkt voor een kleiner braadstuk.'], prep: ['Roast a chicken about 1–1.5 hours, far shorter than a turkey.', 'Een kip braadt ongeveer 1–1,5 uur, veel korter dan een kalkoen.'] },
  { from: 'x:andouille', to: 'p_smoked_sausage', kind: 'substitute', note: ['Rookworst is smoked like andouille but milder; add a pinch of cayenne.', 'Rookworst is gerookt zoals andouille maar milder; voeg wat cayenne toe.'] },
  { from: 'x:kielbasa', to: 'p_smoked_sausage', kind: 'substitute', note: ['Rookworst is a very similar smoked sausage.', 'Rookworst is een zeer vergelijkbare gerookte worst.'] },
  { from: 'x:hot-dogs', to: 'p_smoked_sausage', kind: 'approximate', note: ['Rookworst instead of hot dogs: firmer and smokier.', 'Rookworst in plaats van hotdogs: steviger en rokeriger.'] },
  { from: 'x:pancetta', to: 'p_bacon', kind: 'substitute', note: ['Spekblokjes are the everyday Dutch version of pancetta.', 'Spekblokjes zijn de alledaagse versie van pancetta.'] },
  { from: 'x:canadian-bacon', to: 'p_ham', kind: 'substitute', note: ['Cooked ham is closest to Canadian bacon.', 'Gekookte ham komt het dichtst bij Canadian bacon.'] },
  { from: 'x:collard-greens', to: 'p_kale', kind: 'substitute', note: ['Kale cooks the same way as collard greens.', 'Boerenkool laat zich hetzelfde koken als collard greens.'] },
  { from: 'x:swiss-chard', to: 'p_spinach', kind: 'substitute', note: ['Spinach cooks faster than chard; add it at the end.', 'Spinazie is sneller gaar dan snijbiet; voeg het als laatste toe.'] },
  { from: 'x:yellow-squash', to: 'p_zucchini', kind: 'equivalent', note: ['Yellow summer squash and courgette are used the same way.', 'Gele zomerpompoen en courgette gebruik je hetzelfde.'] },
  { from: 'x:tomato-sauce', to: 'p_passata', kind: 'substitute', note: ['US tomato sauce is seasoned passata: season the passata a little.', 'Amerikaanse tomatensaus is gekruide passata: kruid de passata wat bij.'] },
  { from: 'x:sriracha', to: 'p_sambal', kind: 'approximate', note: ['Sambal oelek is hotter and less sweet than sriracha.', 'Sambal oelek is heter en minder zoet dan sriracha.'], ratio: 0.5 },
  { from: 'x:hot-sauce', to: 'p_sambal', kind: 'approximate', note: ['Sambal is hotter and thicker than a vinegar hot sauce: use less.', 'Sambal is heter en dikker dan hete saus: gebruik minder.'], ratio: 0.3 },
  { from: 'x:green-curry-paste', to: 'p_curry_paste', kind: 'approximate', note: ['Red curry paste is hotter and less herby than green.', 'Rode currypasta is heter en minder kruidig-fris dan groene.'] },
  { from: 'x:udon', to: 'p_noodles', kind: 'approximate', note: ['Egg noodles are thinner than udon.', 'Mie is dunner dan udon.'] },
  { from: 'x:soba', to: 'p_noodles', kind: 'approximate', note: ['Egg noodles instead of buckwheat soba: different taste, and they contain egg.', 'Mie in plaats van boekweit-soba: andere smaak, en bevat ei.'] },
  { from: 'x:mirin', to: 'p_rice_vinegar', with: [{ product: 'p_sugar', perUnit: 0.5 }], kind: 'approximate', note: ['Rice vinegar with sugar mimics mirin’s sweet-sour taste.', 'Rijstazijn met suiker benadert de zoetzure smaak van mirin.'] },
  { from: 'x:galangal', to: 'p_ginger', kind: 'substitute', note: ['Ginger is warmer and less citrusy than galangal (laos).', 'Gember is warmer en minder citrusachtig dan laos.'] },
  { from: 'x:lemongrass', to: 'p_lemon', kind: 'approximate', note: ['Lemon zest gives the citrus note of lemongrass.', 'Citroenrasp geeft de citrustoon van citroengras.'], prep: ['Use the grated zest of the lemon, added at the end.', 'Gebruik de geraspte schil van de citroen, aan het eind toegevoegd.'] },
  { from: 'x:kaffir-lime-leaves', to: 'p_lime', kind: 'approximate', note: ['Lime zest instead of lime leaves (djeroek poeroet).', 'Limoenrasp in plaats van djeroek poeroet.'], prep: ['Use the grated zest.', 'Gebruik de geraspte schil.'] },
  { from: 'x:tamarind', to: 'p_lime', with: [{ product: 'p_brown_sugar', perUnit: 5 }], kind: 'approximate', note: ['Lime juice with brown sugar mimics tamarind’s sweet-sour taste.', 'Limoensap met basterdsuiker benadert de zoetzure smaak van tamarinde.'] },
  { from: 'x:sumac', to: 'p_lemon', kind: 'approximate', note: ['Lemon zest gives sumac’s tartness, not its colour.', 'Citroenrasp geeft het zure van sumak, niet de kleur.'] },
  { from: 'x:zaatar', to: 'p_thyme', kind: 'approximate', note: ['Dried thyme with a few sesame seeds comes close to za’atar.', 'Gedroogde tijm met wat sesamzaad komt dicht bij za’atar.'] },
  { from: 'x:berbere', to: 'p_paprika_powder', with: [{ product: 'p_cayenne', perUnit: 0.25 }, { product: 'p_ginger_powder', perUnit: 0.1 }], kind: 'approximate', identity: true, note: ['A homemade paprika–cayenne–ginger mix; berbere is more complex and defines the dish.', 'Een eigen mix van paprika, cayenne en gember; berbere is complexer en bepaalt het gerecht.'] },
  { from: 'x:molasses', to: 'p_brown_sugar', kind: 'approximate', note: ['Dark brown sugar gives some of molasses’ depth; the texture differs.', 'Donkere basterdsuiker geeft iets van de diepe smaak; de structuur verschilt.'] },
  { from: 'x:corn-syrup', to: 'p_honey', kind: 'approximate', note: ['Honey instead of corn syrup: sweeter, with its own taste.', 'Honing in plaats van glucosestroop: zoeter, met eigen smaak.'], ratio: 0.8 },
  { from: 'x:shortening', to: 'p_margarine', kind: 'approximate', note: ['Margarine contains water, so pastry is a little less flaky.', 'Margarine bevat water, dus deeg wordt iets minder bros.'] },
  { from: 'x:refried-beans', to: 'p_kidney_beans', kind: 'substitute', note: ['Mash kidney beans with a little oil and cumin.', 'Prak kidneybonen met wat olie en komijn.'], prep: ['Mash the beans with a little oil and cumin in a pan until thick.', 'Prak de bonen met wat olie en komijn in een pan tot een dikke massa.'] },
  { from: 'x:enchilada-sauce', to: 'p_passata', with: [{ product: 'p_chili_powder', perUnit: 0.02 }, { product: 'p_cumin', perUnit: 0.01 }], kind: 'substitute', note: ['Passata with chilli powder and cumin.', 'Passata met chilipoeder en komijn.'] },
  { from: 'x:garlic-paste', to: 'p_garlic', kind: 'equivalent', note: ['Fresh garlic, crushed: a teaspoon of paste is about one clove.', 'Verse knoflook, geperst: een theelepel pasta is ongeveer één teen.'] },
  { from: 'x:ginger-paste', to: 'p_ginger', kind: 'equivalent', note: ['Fresh ginger, finely grated.', 'Verse gember, fijn geraspt.'] },
  { from: 'x:nigerian-curry', to: 'p_curry_powder', kind: 'approximate', note: ['Ordinary curry powder; the Nigerian blend is milder with more thyme.', 'Gewone kerriepoeder; de Nigeriaanse mix is milder met meer tijm.'] },
  { from: 'x:peanut-oil', to: 'p_sunflower_oil', kind: 'substitute', note: ['A neutral oil works the same; peanut oil adds a light nutty taste.', 'Een neutrale olie werkt hetzelfde; pindaolie geeft een licht nootachtige smaak.'] },
  { from: 'x:egg-yolk', to: 'p_eggs', kind: 'approximate', note: ['Uses whole eggs: keep the whites for something else. Nutrition counts the whole egg.', 'Gebruikt hele eieren: bewaar het eiwit. De voedingswaarde telt het hele ei.'], prep: ['Separate the eggs and use the yolks.', 'Splits de eieren en gebruik de dooiers.'] },
  { from: 'x:egg-white', to: 'p_eggs', kind: 'approximate', note: ['Uses whole eggs: keep the yolks for something else. Nutrition counts the whole egg.', 'Gebruikt hele eieren: bewaar de dooiers. De voedingswaarde telt het hele ei.'], prep: ['Separate the eggs and use the whites.', 'Splits de eieren en gebruik het eiwit.'] },
  // Between catalogue products: alternatives you can pick, never applied automatically
  { from: 'p_sour_cream', to: 'p_creme_fraiche', kind: 'substitute', note: ['Crème fraîche is richer and doesn’t split when heated.', 'Crème fraîche is voller en schift niet bij verhitten.'] },
  { from: 'p_creme_fraiche', to: 'p_sour_cream', kind: 'substitute', note: ['Sour cream is lighter and can split when boiled: add it off the heat.', 'Zure room is lichter en kan schiften: voeg toe van het vuur af.'] },
  { from: 'p_buttermilk', to: 'p_milk', with: [{ product: 'p_lemon', perUnit: 0.004 }], kind: 'substitute', note: ['Milk soured with lemon juice works in baking.', 'Melk aangezuurd met citroensap werkt in bakrecepten.'], prep: ['Stir 1 tbsp lemon juice into 250 ml milk and leave 5 minutes.', 'Roer 1 el citroensap door 250 ml melk en laat 5 minuten staan.'] },
  { from: 'p_cheddar', to: 'p_gouda_mature', kind: 'approximate', note: ['Mature Gouda melts similarly but is milder and sweeter than cheddar.', 'Belegen kaas smelt vergelijkbaar maar is milder en zoeter dan cheddar.'] },
  { from: 'p_parmesan', to: 'p_gouda_old', kind: 'substitute', note: ['Old Gouda is a hard, grating cheese with a similar savoury depth.', 'Oude kaas is een harde raspkaas met een vergelijkbare hartige smaak.'] },
  { from: 'p_whipping_cream', to: 'p_cream', kind: 'substitute', note: ['Cooking cream can’t be whipped; fine in sauces.', 'Kookroom kun je niet opkloppen; prima in sauzen.'] },
  { from: 'p_cream', to: 'p_whipping_cream', kind: 'substitute', note: ['Whipping cream is richer; use the same amount in sauces.', 'Slagroom is voller; gebruik dezelfde hoeveelheid in sauzen.'] },
  { from: 'p_self_raising_flour', to: 'p_flour', with: [{ product: 'p_baking_powder', perUnit: 0.04 }], kind: 'substitute', note: ['Plain flour plus baking powder (4 g per 100 g).', 'Bloem met bakpoeder (4 g per 100 g).'] },
  { from: 'p_risotto_rice', to: 'p_rice', kind: 'approximate', identity: true, note: ['Basmati won’t get creamy: the result is closer to a pilaf.', 'Basmati wordt niet romig: het resultaat lijkt meer op pilav.'] },
  { from: 'p_sweet_soy', to: 'p_soy_sauce', with: [{ product: 'p_brown_sugar', perUnit: 0.5 }], kind: 'substitute', note: ['Soy sauce sweetened with brown sugar.', 'Sojasaus gezoet met basterdsuiker.'] },
  { from: 'p_cayenne', to: 'p_chili_powder', kind: 'substitute', note: ['Chilli powder is milder and often contains cumin.', 'Chilipoeder is milder en bevat vaak komijn.'], ratio: 1.5 },
  { from: 'p_chili_powder', to: 'p_cayenne', kind: 'substitute', note: ['Cayenne is much hotter: use a third.', 'Cayenne is veel heter: gebruik een derde.'], ratio: 0.33 },
  { from: 'p_garam_masala', to: 'p_curry_powder', kind: 'approximate', note: ['Curry powder has turmeric and is less sweet-spiced.', 'Kerriepoeder bevat kurkuma en is minder zoet-kruidig.'] },
  { from: 'p_thyme', to: 'p_italian_herbs', kind: 'approximate', note: ['Italian herbs contain thyme with oregano and basil.', 'Italiaanse kruiden bevatten tijm met oregano en basilicum.'] },
  { from: 'p_oregano', to: 'p_italian_herbs', kind: 'substitute', note: ['Italian herbs contain oregano.', 'Italiaanse kruiden bevatten oregano.'] },
];

/** Ingredients that aren't catalogue products: names and how easy they are to get, per country. */
export interface Foreign { key: string; names: string[]; status: Record<string, 'common' | 'limited' | 'specialist' | 'unavailable'>; note?: [string, string] }
export const FOREIGN: Foreign[] = [
  { key: 'x:habanero', names: ['habanero', 'habaneros', 'habanero pepper', 'habanero peppers', 'habanero chile', 'scotch bonnet', 'scotch bonnets', 'scotch bonnet pepper', 'scotch bonnet peppers', 'scotch bonnet chile pepper', 'scotch bonnet chile peppers'], status: { NL: 'specialist' } },
  { key: 'x:scotch-bonnet', names: ['scotch bonnet', 'scotch bonnets', 'scotch bonnet pepper'], status: { NL: 'specialist' } },
  { key: 'x:serrano', names: ['serrano', 'serranos', 'serrano pepper', 'serrano chile', 'serrano peppers'], status: { NL: 'unavailable' } },
  { key: 'x:poblano', names: ['poblano', 'poblanos', 'poblano pepper', 'poblano peppers', 'poblano chile'], status: { NL: 'unavailable' } },
  { key: 'x:anaheim', names: ['anaheim', 'anaheim pepper', 'anaheim chile', 'anaheim peppers'], status: { NL: 'unavailable' } },
  { key: 'x:chipotle', names: ['chipotle', 'chipotles', 'chipotle chile', 'chipotle pepper', 'chipotle peppers', 'chipotle in adobo', 'chipotles in adobo'], status: { NL: 'specialist' } },
  { key: 'x:ancho', names: ['ancho', 'ancho chile', 'ancho chili', 'ancho chile powder', 'ancho powder'], status: { NL: 'specialist' } },
  { key: 'x:fresh-jalapeno', names: ['fresh jalapeno', 'fresh jalapeño', 'fresh jalapenos'], status: { NL: 'limited' } },
  { key: 'x:half-and-half', names: ['half-and-half', 'half and half', 'half & half'], status: { NL: 'unavailable' } },
  { key: 'x:cream-of-mushroom-soup', names: ['cream of mushroom soup', 'condensed cream of mushroom soup', 'cream of mushroom'], status: { NL: 'limited' } },
  { key: 'x:monterey-jack', names: ['monterey jack', 'monterey jack cheese', 'pepper jack', 'pepper jack cheese'], status: { NL: 'unavailable' } },
  { key: 'x:american-cheese', names: ['american cheese', 'velveeta', 'processed cheese'], status: { NL: 'limited' } },
  { key: 'x:colby', names: ['colby', 'colby cheese', 'colby jack'], status: { NL: 'unavailable' } },
  { key: 'x:gruyere', names: ['gruyere', 'gruyère', 'gruyere cheese', 'swiss cheese', 'emmental', 'emmentaler'], status: { NL: 'limited' } },
  { key: 'x:pecorino', names: ['pecorino', 'pecorino romano', 'romano cheese'], status: { NL: 'limited' } },
  { key: 'x:queso-fresco', names: ['queso fresco', 'cotija', 'queso blanco'], status: { NL: 'unavailable' } },
  { key: 'x:paneer', names: ['paneer'], status: { NL: 'specialist' } },
  { key: 'x:ground-turkey', names: ['ground turkey', 'turkey mince', 'minced turkey'], status: { NL: 'limited' } },
  { key: 'x:whole-turkey', names: ['turkey', 'whole turkey'], status: { NL: 'specialist' } },
  { key: 'x:andouille', names: ['andouille', 'andouille sausage'], status: { NL: 'unavailable' } },
  { key: 'x:kielbasa', names: ['kielbasa', 'polish sausage'], status: { NL: 'limited' } },
  { key: 'x:hot-dogs', names: ['hot dogs', 'hot dog', 'frankfurters', 'wieners'], status: { NL: 'common' } },
  { key: 'x:pancetta', names: ['pancetta'], status: { NL: 'limited' } },
  { key: 'x:canadian-bacon', names: ['canadian bacon', 'back bacon'], status: { NL: 'unavailable' } },
  { key: 'x:collard-greens', names: ['collard greens', 'collards'], status: { NL: 'unavailable' } },
  { key: 'x:swiss-chard', names: ['swiss chard', 'chard', 'snijbiet'], status: { NL: 'limited' } },
  { key: 'x:yellow-squash', names: ['yellow squash', 'summer squash', 'crookneck squash'], status: { NL: 'unavailable' } },
  { key: 'x:tomato-sauce', names: ['tomato sauce', 'canned tomato sauce'], status: { NL: 'limited' } },
  { key: 'x:sriracha', names: ['sriracha', 'sriracha sauce'], status: { NL: 'common' } },
  { key: 'x:hot-sauce', names: ['hot sauce', 'tabasco', 'tabasco sauce', 'hot pepper sauce', 'louisiana hot sauce'], status: { NL: 'common' } },
  { key: 'x:green-curry-paste', names: ['green curry paste', 'groene currypasta'], status: { NL: 'common' } },
  { key: 'x:udon', names: ['udon', 'udon noodles'], status: { NL: 'limited' } },
  { key: 'x:soba', names: ['soba', 'soba noodles', 'buckwheat noodles'], status: { NL: 'limited' } },
  { key: 'x:mirin', names: ['mirin'], status: { NL: 'limited' } },
  { key: 'x:galangal', names: ['galangal', 'laos', 'galanga'], status: { NL: 'limited' } },
  { key: 'x:lemongrass', names: ['lemongrass', 'lemon grass', 'citroengras', 'sereh'], status: { NL: 'limited' } },
  { key: 'x:kaffir-lime-leaves', names: ['kaffir lime leaves', 'lime leaves', 'makrut lime leaves', 'djeroek poeroet'], status: { NL: 'limited' } },
  { key: 'x:tamarind', names: ['tamarind', 'tamarind paste', 'tamarinde', 'asem'], status: { NL: 'specialist' } },
  { key: 'x:sumac', names: ['sumac', 'sumak'], status: { NL: 'specialist' } },
  { key: 'x:zaatar', names: ["za'atar", 'zaatar', 'zatar'], status: { NL: 'specialist' } },
  { key: 'x:berbere', names: ['berbere', 'berbere spice'], status: { NL: 'specialist' } },
  { key: 'x:molasses', names: ['molasses', 'blackstrap molasses', 'treacle', 'black treacle'], status: { NL: 'specialist' } },
  { key: 'x:corn-syrup', names: ['corn syrup', 'light corn syrup', 'karo syrup'], status: { NL: 'unavailable' } },
  { key: 'x:shortening', names: ['shortening', 'vegetable shortening', 'crisco'], status: { NL: 'unavailable' } },
  { key: 'x:refried-beans', names: ['refried beans'], status: { NL: 'limited' } },
  { key: 'x:enchilada-sauce', names: ['enchilada sauce'], status: { NL: 'limited' } },
  { key: 'x:garlic-paste', names: ['garlic paste', 'knoflookpasta'], status: { NL: 'common' } },
  { key: 'x:ginger-paste', names: ['ginger paste', 'gemberpasta'], status: { NL: 'common' } },
  { key: 'x:nigerian-curry', names: ['nigerian curry powder', 'nigerian curry'], status: { NL: 'specialist' } },
  { key: 'x:asafoetida', names: ['asafoetida', 'hing', 'duivelsdrek'], status: { NL: 'specialist' } },
  { key: 'x:west-african-leaves', names: ['uziza leaves', 'uziza', 'utazi', 'bitterleaf', 'bitter leaf', 'ugu', 'ugu leaves', 'scent leaves', 'efirin'], status: { NL: 'specialist' } },
  { key: 'x:locust-beans', names: ['fermented locust beans', 'locust beans', 'iru', 'ogiri', 'dawadawa'], status: { NL: 'specialist' } },
  { key: 'x:ponmo', names: ['ponmo', 'cow skin', 'kpomo'], status: { NL: 'specialist' } },
  { key: 'x:goat-meat', names: ['goat meat', 'goat', 'geitenvlees'], status: { NL: 'specialist' } },
  { key: 'x:potash', names: ['potash', 'kaun', 'akanwu'], status: { NL: 'specialist' } },
  { key: 'x:coconut-oil', names: ['coconut oil', 'kokosolie'], status: { NL: 'common' } },
  { key: 'x:lard', names: ['lard', 'reuzel', 'varkensvet'], status: { NL: 'common' } },
  { key: 'x:spirits', names: ['brandy', 'cognac', 'rum', 'dark rum', 'white rum', 'vodka', 'whisky', 'whiskey', 'sherry', 'port'], status: { NL: 'common' } },
  { key: 'x:jam', names: ['jam', 'jelly', 'preserves', 'apricot jam', 'raspberry jam', 'strawberry jam', 'jam'], status: { NL: 'common' } },
  { key: 'x:palm-oil', names: ['palm oil', 'red palm oil', 'palmolie'], status: { NL: 'specialist' } },
  { key: 'x:crayfish', names: ['crayfish', 'ground crayfish', 'dried crayfish'], status: { NL: 'specialist' } },
  { key: 'x:stockfish', names: ['stockfish', 'stock fish', 'dryfish', 'dry fish', 'dried fish', 'stokvis'], status: { NL: 'specialist' } },
  { key: 'x:curry-leaves', names: ['curry leaves', 'curry leaf', 'kerrieblad'], status: { NL: 'specialist' } },
  { key: 'x:cream-of-tartar', names: ['cream of tartar', 'cream tartar', 'wijnsteenzuur'], status: { NL: 'limited' } },
  { key: 'x:peanut-oil', names: ['peanut oil', 'groundnut oil', 'arachide oil', 'pindaolie'], status: { NL: 'common' } },
  { key: 'x:egg-yolk', names: ['egg yolk', 'egg yolks', 'yolk', 'yolks', 'eidooier', 'eidooiers'], status: { NL: 'common' } },
  { key: 'x:egg-white', names: ['egg white', 'egg whites', 'eiwit', 'eiwitten'], status: { NL: 'common' } },
  // Common in Dutch supermarkets but not tracked as catalogue products yet: no substitution needed.
  { key: 'x:hoisin', names: ['hoisin', 'hoisin sauce'], status: { NL: 'common' } },
  { key: 'x:taco-shells', names: ['taco shells', 'hard taco shells'], status: { NL: 'common' } },
  { key: 'x:salsa', names: ['salsa', 'tomato salsa', 'jarred salsa'], status: { NL: 'common' } },
  { key: 'x:boemboe', names: ['boemboe', 'bumbu', 'boemboe nasi', 'boemboe bami'], status: { NL: 'common' } },
  { key: 'x:capers', names: ['capers', 'kappertjes'], status: { NL: 'common' } },

  { key: 'x:pine-nuts', names: ['pine nuts', 'pignoli', 'pijnboompitten'], status: { NL: 'common' } },
  { key: 'x:fufu', names: ['fufu', 'fufu flour', 'gari', 'garri', 'eba'], status: { NL: 'specialist' } },
  { key: 'x:teff', names: ['teff', 'teff flour', 'injera'], status: { NL: 'specialist' } },
];

/** Availability of catalogue products per country (anything not listed is 'common'). */
export const AVAILABILITY: Record<string, Record<string, 'common' | 'limited' | 'specialist'>> = {
  NL: { p_okra: 'limited', p_cassava: 'specialist', p_madame_jeanette: 'limited', p_plantain: 'limited', p_jalapeno: 'common', p_lamb_mince: 'limited', p_cardamom: 'limited' },
};

// ---------- Countries and chains ----------

export interface Country { code: string; name: string; name_nl: string; supported: boolean; measure: 'metric' | 'us'; bbox: [number, number, number, number] }
export const COUNTRIES: Country[] = [
  { code: 'NL', name: 'Netherlands', name_nl: 'Nederland', supported: true, measure: 'metric', bbox: [50.75, 3.36, 53.56, 7.23] },
  { code: 'BE', name: 'Belgium', name_nl: 'België', supported: false, measure: 'metric', bbox: [49.49, 2.54, 51.5, 6.41] },
  { code: 'DE', name: 'Germany', name_nl: 'Duitsland', supported: false, measure: 'metric', bbox: [47.27, 5.87, 55.06, 15.04] },
];

export interface Chain { id: string; country: string; name: string; /** Open Food Facts store tags and brands that mean this chain. */ off: string[]; online?: boolean; /** The webshop's own search page; {q} is the search term. Only opened by the user, never fetched. */ search?: string }
export const CHAINS: Chain[] = [
  { id: 'ah', country: 'NL', name: 'Albert Heijn', off: ['ah', 'albert heijn', 'albert-heijn', 'albert heijn to go', 'ah to go'], search: 'https://www.ah.nl/zoeken?query={q}' },
  { id: 'jumbo', country: 'NL', name: 'Jumbo', off: ['jumbo'], search: 'https://www.jumbo.com/producten/?searchType=keyword&searchTerms={q}' },
  { id: 'lidl_nl', country: 'NL', name: 'Lidl', off: ['lidl'], search: 'https://www.lidl.nl/q/search?q={q}' },
  { id: 'aldi_nl', country: 'NL', name: 'Aldi', off: ['aldi'], search: 'https://www.aldi.nl/zoeken.html?query={q}' },
  { id: 'plus', country: 'NL', name: 'PLUS', off: ['plus'], search: 'https://www.plus.nl/zoekresultaten?SearchTerm={q}' },
  { id: 'dirk', country: 'NL', name: 'Dirk', off: ['dirk', 'dirk van den broek', '1 de beste', '1de beste'], search: 'https://www.dirk.nl/zoeken/producten/{q}' },
  { id: 'coop', country: 'NL', name: 'Coop', off: ['coop'] },
  { id: 'spar_nl', country: 'NL', name: 'Spar', off: ['spar'] },
  { id: 'hoogvliet', country: 'NL', name: 'Hoogvliet', off: ['hoogvliet'] },
  { id: 'vomar', country: 'NL', name: 'Vomar', off: ['vomar'], search: 'https://www.vomar.nl/zoeken?search={q}' },
  { id: 'dekamarkt', country: 'NL', name: 'DekaMarkt', off: ['dekamarkt'], search: 'https://www.dekamarkt.nl/zoeken?zoekterm={q}' },
  { id: 'poiesz', country: 'NL', name: 'Poiesz', off: ['poiesz'] },
  { id: 'jan_linders', country: 'NL', name: 'Jan Linders', off: ['jan linders', 'jan-linders'] },
  { id: 'picnic', country: 'NL', name: 'Picnic', off: ['picnic'], online: true },
  { id: 'colruyt', country: 'BE', name: 'Colruyt', off: ['colruyt'] },
  { id: 'delhaize', country: 'BE', name: 'Delhaize', off: ['delhaize'] },
  { id: 'carrefour_be', country: 'BE', name: 'Carrefour', off: ['carrefour'] },
  { id: 'rewe', country: 'DE', name: 'REWE', off: ['rewe'] },
  { id: 'edeka', country: 'DE', name: 'Edeka', off: ['edeka'] },
  { id: 'lidl_de', country: 'DE', name: 'Lidl', off: ['lidl'] },
  { id: 'aldi_de', country: 'DE', name: 'Aldi', off: ['aldi'] },
];

/** The country a position is in (offline, by bounding box; first match wins, so smaller countries first). */
export function countryAt(lat: number, lon: number): string | null {
  for (const c of [...COUNTRIES].sort((a, b) => (a.bbox[2] - a.bbox[0]) * (a.bbox[3] - a.bbox[1]) - (b.bbox[2] - b.bbox[0]) * (b.bbox[3] - b.bbox[1]))) {
    if (lat >= c.bbox[0] && lat <= c.bbox[2] && lon >= c.bbox[1] && lon <= c.bbox[3]) return c.code;
  }
  return null;
}

/** A sprig or a leaf of a dried herb means the fresh one. */
export const FRESH_OF: Record<string, string> = { p_thyme: 'p_fresh_thyme' };
