-- Larder schema v1.
-- Quantities are stored in the product's base unit: g, ml or pcs.
-- Timestamps are ISO-8601 UTC strings; dates are YYYY-MM-DD.

CREATE TABLE households (
  id            TEXT PRIMARY KEY,
  name          TEXT NOT NULL,
  invite_code   TEXT NOT NULL UNIQUE,
  locale        TEXT NOT NULL DEFAULT 'nl',
  created_at    TEXT NOT NULL
);

CREATE TABLE users (
  id            TEXT PRIMARY KEY,
  household_id  TEXT NOT NULL REFERENCES households(id),
  email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
  name          TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  created_at    TEXT NOT NULL
);

CREATE TABLE sessions (
  token_hash    TEXT PRIMARY KEY,
  user_id       TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at    TEXT NOT NULL,
  created_at    TEXT NOT NULL
);

CREATE TABLE storage_locations (
  id            TEXT PRIMARY KEY,
  household_id  TEXT NOT NULL REFERENCES households(id),
  name          TEXT NOT NULL,
  kind          TEXT NOT NULL CHECK (kind IN ('fridge','freezer','pantry','other')),
  sort          INTEGER NOT NULL DEFAULT 0
);

-- Global catalogue rows have household_id NULL; households can add their own.
CREATE TABLE products (
  id              TEXT PRIMARY KEY,
  household_id    TEXT REFERENCES households(id),
  name            TEXT NOT NULL,
  name_nl         TEXT,
  brand           TEXT,
  category        TEXT NOT NULL,
  barcode         TEXT,
  image_url       TEXT,
  unit            TEXT NOT NULL CHECK (unit IN ('g','ml','pcs')),
  package_size    REAL NOT NULL,            -- in base unit
  piece_size      REAL,                     -- g or ml per piece, for pcs<->mass conversion
  piece_name      TEXT,                     -- 'slice', 'clove', ...
  price           REAL,                     -- typical package price, EUR
  preferred_store TEXT,
  default_location TEXT NOT NULL DEFAULT 'pantry',
  shelf_life_days INTEGER,                  -- unopened, at default location
  opened_life_days INTEGER,
  freezer_life_days INTEGER,
  synonyms        TEXT NOT NULL DEFAULT '[]', -- JSON array of lower-case names (EN + NL)
  nutrition       TEXT,                     -- JSON per 100 g/ml or per piece: kcal, protein, carbs, fat
  nutrition_basis TEXT,                     -- 'per100' | 'perPiece'
  nutrition_source TEXT,                    -- 'estimate' | 'openfoodfacts' | 'nevo' | 'user'
  staple          INTEGER NOT NULL DEFAULT 0, -- treat as always-in-stock (salt, oil), never suggested when unknown
  created_at      TEXT NOT NULL
);
CREATE UNIQUE INDEX products_barcode ON products(barcode) WHERE barcode IS NOT NULL;
CREATE INDEX products_household ON products(household_id);

-- One row per stock lot (a purchase, a leftover, a frozen portion).
-- quantity is the CONFIRMED quantity: the sum of this lot's ledger events.
-- Estimates are computed at read time and never written here.
CREATE TABLE inventory_lots (
  id                TEXT PRIMARY KEY,
  household_id      TEXT NOT NULL REFERENCES households(id),
  product_id        TEXT REFERENCES products(id),
  label             TEXT,                   -- for leftovers: 'Lasagna (leftover)'
  is_leftover       INTEGER NOT NULL DEFAULT 0,
  recipe_id         TEXT,
  location_id       TEXT REFERENCES storage_locations(id),
  quantity          REAL NOT NULL DEFAULT 0,
  unit              TEXT NOT NULL CHECK (unit IN ('g','ml','pcs','portion')),
  purchased_at      TEXT,
  expires_on        TEXT,
  expiry_estimated  INTEGER NOT NULL DEFAULT 1,
  opened_at         TEXT,
  frozen_at         TEXT,
  source            TEXT NOT NULL,
  last_confirmed_at TEXT NOT NULL,
  unit_price        REAL,                   -- EUR per base unit, for cost estimates
  status            TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','depleted')),
  version           INTEGER NOT NULL DEFAULT 1,
  created_at        TEXT NOT NULL
);
CREATE INDEX lots_household_active ON inventory_lots(household_id, status);
CREATE INDEX lots_product ON inventory_lots(product_id);

-- Append-only ledger. Every change to a lot quantity is one row here.
CREATE TABLE inventory_events (
  id                TEXT PRIMARY KEY,
  household_id      TEXT NOT NULL REFERENCES households(id),
  lot_id            TEXT NOT NULL REFERENCES inventory_lots(id),
  product_id        TEXT,
  type              TEXT NOT NULL CHECK (type IN
                      ('purchase','consume','discard','cook','adjust','transfer','freeze','thaw','leftover','undo','open')),
  delta             REAL NOT NULL,          -- signed change of lot quantity (0 for transfer/open)
  quantity_after    REAL NOT NULL,
  unit              TEXT NOT NULL,
  source            TEXT NOT NULL CHECK (source IN
                      ('manual','voice','assistant_ai','receipt','barcode','shopping_list','recipe','online_order','device','system','import')),
  reason            TEXT,                   -- discard reason etc.
  predicted_before  REAL,                   -- estimate shown at the time of a correction (training signal)
  batch_id          TEXT,                   -- groups events of one command / receipt / cook
  reverses_event_id TEXT REFERENCES inventory_events(id),
  idempotency_key   TEXT UNIQUE,
  user_id           TEXT,
  meta              TEXT,                   -- JSON
  created_at        TEXT NOT NULL
);
CREATE INDEX events_household_time ON inventory_events(household_id, created_at);
CREATE INDEX events_product ON inventory_events(product_id, created_at);
CREATE INDEX events_batch ON inventory_events(batch_id);

-- Purchases, with price, for analytics and prediction.
CREATE TABLE purchases (
  id            TEXT PRIMARY KEY,
  household_id  TEXT NOT NULL REFERENCES households(id),
  receipt_id    TEXT,
  product_id    TEXT REFERENCES products(id),
  quantity      REAL NOT NULL,              -- base units
  packages      REAL NOT NULL DEFAULT 1,
  total_price   REAL,
  store         TEXT,
  purchased_at  TEXT NOT NULL,
  event_id      TEXT REFERENCES inventory_events(id),
  source        TEXT NOT NULL
);
CREATE INDEX purchases_product ON purchases(household_id, product_id, purchased_at);

CREATE TABLE receipts (
  id            TEXT PRIMARY KEY,
  household_id  TEXT NOT NULL REFERENCES households(id),
  store         TEXT,
  purchased_at  TEXT,
  total         REAL,
  fingerprint   TEXT NOT NULL,              -- duplicate-receipt detection
  status        TEXT NOT NULL CHECK (status IN ('draft','committed','discarded')),
  raw_text      TEXT,
  parsed        TEXT NOT NULL,              -- JSON ParsedReceipt incl. match proposals
  parser        TEXT NOT NULL,              -- 'rules' | 'ai'
  batch_id      TEXT,
  created_at    TEXT NOT NULL,
  committed_at  TEXT
);
CREATE UNIQUE INDEX receipts_fingerprint ON receipts(household_id, fingerprint) WHERE status = 'committed';

-- Learned receipt-line -> product mappings, per store ('' = any store).
CREATE TABLE receipt_aliases (
  household_id  TEXT NOT NULL REFERENCES households(id),
  store         TEXT NOT NULL DEFAULT '',
  pattern       TEXT NOT NULL,              -- normalised receipt text
  product_id    TEXT NOT NULL REFERENCES products(id),
  package_qty   REAL,                       -- base units per receipt unit, if learned
  hits          INTEGER NOT NULL DEFAULT 1,
  updated_at    TEXT NOT NULL,
  PRIMARY KEY (household_id, store, pattern)
);

CREATE TABLE shopping_items (
  id            TEXT PRIMARY KEY,
  household_id  TEXT NOT NULL REFERENCES households(id),
  product_id    TEXT REFERENCES products(id),
  name          TEXT NOT NULL,
  quantity      REAL,                       -- base units, NULL = unspecified
  unit          TEXT,
  packages      REAL,                       -- rounded to package size
  category      TEXT NOT NULL DEFAULT 'other',
  reason        TEXT NOT NULL DEFAULT 'manual', -- manual | meal_plan | low_stock | predicted | suggestion
  plan_driven   INTEGER NOT NULL DEFAULT 0,  -- quantity recalculated from the meal plan
  note          TEXT,
  checked       INTEGER NOT NULL DEFAULT 0,
  checked_at    TEXT,
  added_by      TEXT,
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL
);
CREATE INDEX shopping_household ON shopping_items(household_id, checked);

-- Learned accept/reject feedback for suggestions.
CREATE TABLE suggestion_feedback (
  household_id  TEXT NOT NULL,
  product_id    TEXT NOT NULL,
  accepted      INTEGER NOT NULL DEFAULT 0,
  rejected      INTEGER NOT NULL DEFAULT 0,
  last_rejected_at TEXT,
  PRIMARY KEY (household_id, product_id)
);

CREATE TABLE recipes (
  id            TEXT PRIMARY KEY,
  household_id  TEXT REFERENCES households(id),  -- NULL = built-in
  title         TEXT NOT NULL,
  summary       TEXT,
  cuisine       TEXT,
  tags          TEXT NOT NULL DEFAULT '[]',
  diet          TEXT NOT NULL DEFAULT '[]',     -- vegetarian, vegan, gluten-free, ...
  difficulty    TEXT NOT NULL DEFAULT 'easy',
  servings      INTEGER NOT NULL,
  prep_minutes  INTEGER NOT NULL DEFAULT 0,
  cook_minutes  INTEGER NOT NULL DEFAULT 0,
  steps         TEXT NOT NULL,                  -- JSON [{text, timerSeconds?}]
  image_url     TEXT,
  emoji         TEXT,
  color         TEXT,
  origin        TEXT NOT NULL CHECK (origin IN ('builtin','user','ai','external')),
  source_name   TEXT,
  source_url    TEXT,
  attribution   TEXT,
  created_at    TEXT NOT NULL
);

CREATE TABLE recipe_ingredients (
  recipe_id     TEXT NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
  position      INTEGER NOT NULL,
  product_id    TEXT REFERENCES products(id),
  name          TEXT NOT NULL,
  quantity      REAL,                           -- base units of product (for all servings)
  unit          TEXT,
  display       TEXT,                           -- '1 onion, finely chopped'
  optional      INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (recipe_id, position)
);

CREATE TABLE recipe_interactions (
  household_id  TEXT NOT NULL,
  recipe_id     TEXT NOT NULL,
  saved         INTEGER NOT NULL DEFAULT 0,
  rating        INTEGER,
  cooked_count  INTEGER NOT NULL DEFAULT 0,
  skipped_count INTEGER NOT NULL DEFAULT 0,
  last_cooked_at TEXT,
  PRIMARY KEY (household_id, recipe_id)
);

CREATE TABLE meal_slots (
  id            TEXT PRIMARY KEY,
  household_id  TEXT NOT NULL REFERENCES households(id),
  date          TEXT NOT NULL,
  meal          TEXT NOT NULL,                  -- breakfast | lunch | dinner | snack | custom
  position      INTEGER NOT NULL DEFAULT 0,
  recipe_id     TEXT REFERENCES recipes(id),
  leftover_lot_id TEXT REFERENCES inventory_lots(id),
  title         TEXT,                           -- free text ("eating out")
  servings      INTEGER NOT NULL DEFAULT 2,
  status        TEXT NOT NULL DEFAULT 'planned' CHECK (status IN ('planned','cooked','skipped')),
  cook_batch_id TEXT,
  created_at    TEXT NOT NULL
);
CREATE INDEX meal_slots_date ON meal_slots(household_id, date);

CREATE TABLE preferences (
  household_id  TEXT NOT NULL,
  user_id       TEXT NOT NULL DEFAULT '',
  key           TEXT NOT NULL,
  value         TEXT NOT NULL,                  -- JSON
  PRIMARY KEY (household_id, user_id, key)
);

-- Assistant conversation memory (for follow-ups) and command dedupe.
CREATE TABLE assistant_turns (
  id            TEXT PRIMARY KEY,
  household_id  TEXT NOT NULL,
  user_id       TEXT,
  conversation_id TEXT NOT NULL,
  utterance     TEXT NOT NULL,
  normalized    TEXT NOT NULL,
  response      TEXT NOT NULL,                  -- JSON AssistantResponse
  pending       TEXT,                           -- JSON pending clarification state
  batch_id      TEXT,
  created_at    TEXT NOT NULL
);
CREATE INDEX assistant_turns_conv ON assistant_turns(conversation_id, created_at);

CREATE TABLE product_lookups (
  barcode       TEXT PRIMARY KEY,
  found         INTEGER NOT NULL,
  data          TEXT,
  fetched_at    TEXT NOT NULL
);

CREATE TABLE notifications (
  id            TEXT PRIMARY KEY,
  household_id  TEXT NOT NULL,
  kind          TEXT NOT NULL,
  title         TEXT NOT NULL,
  body          TEXT,
  ref           TEXT,
  dedupe_key    TEXT NOT NULL,
  read          INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL,
  UNIQUE (household_id, dedupe_key)
);

CREATE TABLE audit_log (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  household_id  TEXT,
  user_id       TEXT,
  action        TEXT NOT NULL,
  detail        TEXT,
  created_at    TEXT NOT NULL
);
