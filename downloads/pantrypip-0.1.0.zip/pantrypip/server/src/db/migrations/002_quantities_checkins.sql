-- Common package sizes per product (base units), used to ask the right quantity question
-- when a receipt line doesn't say how much was in the package (e.g. a carton of 6, 10 or 12 eggs).
ALTER TABLE products ADD COLUMN package_options TEXT NOT NULL DEFAULT '[]';

-- Web Push subscriptions for the daily "did you cook it?" question.
CREATE TABLE push_subscriptions (
  endpoint      TEXT PRIMARY KEY,
  household_id  TEXT NOT NULL REFERENCES households(id),
  user_id       TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  keys          TEXT NOT NULL,              -- JSON { p256dh, auth }
  created_at    TEXT NOT NULL
);

-- Server-wide settings (VAPID key pair).
CREATE TABLE app_settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
