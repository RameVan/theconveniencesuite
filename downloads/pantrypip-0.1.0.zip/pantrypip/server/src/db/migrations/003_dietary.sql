-- Dietary information per product.
-- allergens: EU-14 allergen keys (gluten, crustaceans, eggs, fish, peanuts, soy, milk, nuts, celery, mustard, sesame, sulphites, lupin, molluscs)
-- diet_flags: what a product is, for diet rules (meat, pork, fish, animal, alcohol)
ALTER TABLE products ADD COLUMN allergens TEXT NOT NULL DEFAULT '[]';
ALTER TABLE products ADD COLUMN diet_flags TEXT NOT NULL DEFAULT '[]';

-- Every cooked meal (also ones cooked with nothing in stock), for stats like streaks and favourites.
CREATE TABLE cook_log (
  id            TEXT PRIMARY KEY,
  household_id  TEXT NOT NULL REFERENCES households(id),
  recipe_id     TEXT NOT NULL,
  servings      REAL NOT NULL,
  batch_id      TEXT NOT NULL,
  created_at    TEXT NOT NULL
);
CREATE INDEX cook_log_household ON cook_log(household_id, created_at);
