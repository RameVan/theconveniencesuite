-- Personal tokens for Siri Shortcuts. A token only allows talking to the assistant (not the full API).
CREATE TABLE api_tokens (
  id              TEXT PRIMARY KEY,               -- short public id, shown in Settings
  token_hash      TEXT NOT NULL UNIQUE,
  household_id    TEXT NOT NULL REFERENCES households(id),
  user_id         TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name            TEXT NOT NULL,
  conversation_id TEXT,                           -- so follow-up questions work across Siri calls
  created_at      TEXT NOT NULL,
  last_used_at    TEXT
);
