-- How often the auto-planner should pick a recipe: -2 never, -1 less often, 0 normal, 1 more often, 2 favourite.
ALTER TABLE recipe_interactions ADD COLUMN priority INTEGER NOT NULL DEFAULT 0;
