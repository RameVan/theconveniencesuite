-- Grams per millilitre, for converting spoons and cups into weight (oil 0.91, flour 0.55, honey 1.42).
ALTER TABLE products ADD COLUMN density REAL;

-- Recipe library: personal notes, "want to try", and how often a recipe was swapped out of a plan.
ALTER TABLE recipe_interactions ADD COLUMN notes TEXT;
ALTER TABLE recipe_interactions ADD COLUMN to_try INTEGER NOT NULL DEFAULT 0;
ALTER TABLE recipe_interactions ADD COLUMN swapped_count INTEGER NOT NULL DEFAULT 0;

-- Planner: locked meals survive "regenerate".
ALTER TABLE meal_slots ADD COLUMN locked INTEGER NOT NULL DEFAULT 0;
