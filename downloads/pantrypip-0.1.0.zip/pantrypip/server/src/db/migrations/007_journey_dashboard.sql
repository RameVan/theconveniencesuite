-- Journey: chapters a household has reached and the tasks picked for it. Picked once, when the
-- chapter unlocks, so the path doesn't shift under the user.
CREATE TABLE journey_chapters (
  household_id  TEXT NOT NULL REFERENCES households(id),
  chapter       INTEGER NOT NULL,
  unlocked_at   TEXT NOT NULL,
  tasks         TEXT NOT NULL,                  -- JSON task ids, in path order
  bonus         TEXT NOT NULL DEFAULT '[]',     -- JSON optional task ids
  boss_since    TEXT,                           -- when all tasks were done (final challenge counts from here)
  completed_at  TEXT,
  celebrated    INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (household_id, chapter)
);

-- Every completed node, once. The primary key is what stops duplicate XP; rows are never deleted,
-- so finished tasks stay finished.
CREATE TABLE journey_nodes (
  household_id  TEXT NOT NULL REFERENCES households(id),
  node_id       TEXT NOT NULL,                  -- 'c1:add5' | 'c1:milestone' | 'c1:boss' | 'track:cooking:3'
  kind          TEXT NOT NULL CHECK (kind IN ('task','milestone','boss','bonus','track')),
  xp            INTEGER NOT NULL,
  completed_at  TEXT NOT NULL,
  celebrated    INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (household_id, node_id)
);

-- What people open, per day, so the dashboard can suggest (never make) layout changes.
CREATE TABLE ui_usage (
  household_id  TEXT NOT NULL,
  user_id       TEXT NOT NULL,
  key           TEXT NOT NULL,
  day           TEXT NOT NULL,
  n             INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (household_id, user_id, key, day)
);
