-- After cooking: how easy it was (1 easy, 2 okay, 3 hard) and whether you'd cook it again (1 yes, 0 no).
ALTER TABLE recipe_interactions ADD COLUMN ease INTEGER;
ALTER TABLE recipe_interactions ADD COLUMN again INTEGER;

-- Share of an ingredient that ends up eaten (frying oil left in the pan, a marinade poured away), per
-- household so it works for built-in recipes too. No row counts all of it: calories are never
-- underestimated by default.
CREATE TABLE recipe_retention (
  household_id  TEXT NOT NULL REFERENCES households(id),
  recipe_id     TEXT NOT NULL,
  position      INTEGER NOT NULL,
  retention     REAL NOT NULL,
  PRIMARY KEY (household_id, recipe_id, position)
);
