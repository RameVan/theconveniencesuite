-- Ingredient ecosystem: canonical identity (family, subcategory, variant), measurement rules, countries and
-- supermarket chains, supermarket products, availability, substitutions and how each recipe ingredient
-- was matched. Built-in data is (re)written by seedCatalogue on every start; household data is never touched.

ALTER TABLE products ADD COLUMN family TEXT;           -- 'milk', 'cheese' … (ingredient-knowledge.ts)
ALTER TABLE products ADD COLUMN subcategory TEXT;      -- 'hard_cheese', 'spice' …
ALTER TABLE products ADD COLUMN measure TEXT NOT NULL DEFAULT '{}'; -- recipeUnit, minQty, precision, maxPerServing, smallMeasures
ALTER TABLE products ADD COLUMN custom INTEGER NOT NULL DEFAULT 0;  -- a household's own type of a family
CREATE INDEX products_family ON products(family);

CREATE TABLE countries (
  code      TEXT PRIMARY KEY,
  name      TEXT NOT NULL,
  name_nl   TEXT NOT NULL,
  supported INTEGER NOT NULL DEFAULT 0,  -- availability data exists
  measure   TEXT NOT NULL DEFAULT 'metric'
);

CREATE TABLE chains (
  id       TEXT PRIMARY KEY,
  country  TEXT NOT NULL REFERENCES countries(code),
  name     TEXT NOT NULL,
  online   INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX chains_country ON chains(country);

-- A product on a supermarket shelf, linked to the canonical ingredient it is.
-- status: 'verified' (confirmed against the chain's own catalogue), 'listed' (open data says this chain sells it),
-- 'unverified' (seen, chain unknown), 'discontinued'.
CREATE TABLE retail_products (
  id            TEXT PRIMARY KEY,
  product_id    TEXT NOT NULL REFERENCES products(id),
  country       TEXT NOT NULL REFERENCES countries(code),
  chain_id      TEXT REFERENCES chains(id),
  name          TEXT NOT NULL,
  brand         TEXT,
  size          REAL,                   -- in the canonical product's base unit, when known
  size_text     TEXT,
  ean           TEXT,
  url           TEXT,
  status        TEXT NOT NULL CHECK (status IN ('verified', 'listed', 'unverified', 'discontinued')),
  source        TEXT NOT NULL,
  nutrition     TEXT,
  last_verified TEXT,
  created_at    TEXT NOT NULL
);
CREATE INDEX retail_product ON retail_products(product_id, country);
CREATE INDEX retail_chain ON retail_products(chain_id);
CREATE UNIQUE INDEX retail_unique ON retail_products(ean, chain_id, country) WHERE ean IS NOT NULL;

-- How easy a catalogue product is to get in a country (missing row = common).
CREATE TABLE ingredient_availability (
  country    TEXT NOT NULL REFERENCES countries(code),
  product_id TEXT NOT NULL REFERENCES products(id),
  status     TEXT NOT NULL CHECK (status IN ('common', 'limited', 'specialist', 'unavailable')),
  source     TEXT NOT NULL,
  PRIMARY KEY (country, product_id)
);

-- Ingredients recipes use that aren't catalogue products (habanero, half-and-half…), per country.
CREATE TABLE foreign_ingredients (
  key      TEXT NOT NULL,              -- 'x:habanero'
  country  TEXT NOT NULL REFERENCES countries(code),
  names    TEXT NOT NULL,              -- JSON
  status   TEXT NOT NULL CHECK (status IN ('common', 'limited', 'specialist', 'unavailable')),
  PRIMARY KEY (key, country)
);

CREATE TABLE substitutions (
  id         TEXT PRIMARY KEY,
  from_key   TEXT NOT NULL,            -- 'p_…' or 'x:…'
  to_product TEXT NOT NULL REFERENCES products(id),
  extra      TEXT NOT NULL DEFAULT '[]', -- JSON [{ product, perUnit }]
  kind       TEXT NOT NULL CHECK (kind IN ('equivalent', 'substitute', 'approximate')),
  ratio      REAL NOT NULL DEFAULT 1,
  countries  TEXT NOT NULL DEFAULT '[]',
  note       TEXT NOT NULL,            -- JSON [en, nl]
  prep       TEXT,                     -- JSON [en, nl]
  identity   INTEGER NOT NULL DEFAULT 0,
  source     TEXT NOT NULL,
  sort       INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX substitutions_from ON substitutions(from_key);

-- A household's choice for an ingredient: 'keep' (the original), or a product id to use instead.
-- Also used to resolve an unmatched ingredient name by hand ('u:<name>').
CREATE TABLE substitution_prefs (
  household_id TEXT NOT NULL REFERENCES households(id),
  from_key     TEXT NOT NULL,
  choice       TEXT NOT NULL,
  updated_at   TEXT NOT NULL,
  PRIMARY KEY (household_id, from_key)
);

-- How each recipe line was matched: 'exact' | 'equivalent' | 'substitute' | 'approximate' | 'unresolved'.
ALTER TABLE recipe_ingredients ADD COLUMN match TEXT;
ALTER TABLE recipe_ingredients ADD COLUMN source_key TEXT;  -- 'x:…' or 'u:<normalised name>' for non-exact lines

-- Shopping: what the plan needs, what's in stock, and the pack size chosen.
ALTER TABLE shopping_items ADD COLUMN need_qty REAL;
ALTER TABLE shopping_items ADD COLUMN have_qty REAL;
ALTER TABLE shopping_items ADD COLUMN pack_size REAL;

-- Servings that were estimated (import without a servings field) are shown as estimates.
ALTER TABLE recipes ADD COLUMN servings_estimated INTEGER NOT NULL DEFAULT 0;
