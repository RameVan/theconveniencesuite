-- Branded products sold in a country (Open Food Facts export), searchable when adding things.
-- product_id: the catalogue ingredient this product is, when its name says so (import/catalogue.ts); NULL = a
-- product of its own, which becomes a household product when someone picks it.
CREATE TABLE catalogue (
  ean        TEXT PRIMARY KEY,
  country    TEXT NOT NULL REFERENCES countries(code),
  name       TEXT NOT NULL,
  brand      TEXT,
  size_text  TEXT,
  size_qty   REAL,
  size_unit  TEXT CHECK (size_unit IN ('g', 'ml', 'pcs')),
  category   TEXT NOT NULL,
  product_id TEXT REFERENCES products(id),
  chains     TEXT NOT NULL DEFAULT '[]',
  image_url  TEXT,
  nutrition  TEXT,
  allergens  TEXT NOT NULL DEFAULT '[]',
  diet_flags TEXT NOT NULL DEFAULT '[]',
  popularity INTEGER NOT NULL DEFAULT 0,
  modified   TEXT,
  source     TEXT NOT NULL
);
CREATE INDEX catalogue_product ON catalogue(product_id);

CREATE VIRTUAL TABLE catalogue_fts USING fts5(name, brand, content = 'catalogue', content_rowid = 'rowid', tokenize = 'unicode61 remove_diacritics 2');
