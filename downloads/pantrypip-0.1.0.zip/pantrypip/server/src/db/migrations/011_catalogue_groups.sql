-- The same product in the catalogue more than once (other pack sizes, entered twice, names typed differently)
-- shares a group_key (import/identity.ts); search shows each group once, with its sizes.
-- words: the identity words ("chili sweet"), so "chilli" finds "chili".
ALTER TABLE catalogue ADD COLUMN group_key TEXT;
ALTER TABLE catalogue ADD COLUMN words TEXT;
-- 0: not shown in search (a name that's only a brand, or a brandless copy of one of several products); barcodes
-- still find it.
ALTER TABLE catalogue ADD COLUMN listed INTEGER NOT NULL DEFAULT 1;
CREATE INDEX catalogue_group ON catalogue(group_key);

DROP TABLE catalogue_fts;
CREATE VIRTUAL TABLE catalogue_fts USING fts5(name, brand, words, content = 'catalogue', content_rowid = 'rowid', tokenize = 'unicode61 remove_diacritics 2');
INSERT INTO catalogue_fts(catalogue_fts) VALUES ('rebuild');

-- A household product made from a catalogue product: the other barcodes and sizes of that product find it.
ALTER TABLE products ADD COLUMN catalogue_group TEXT;
