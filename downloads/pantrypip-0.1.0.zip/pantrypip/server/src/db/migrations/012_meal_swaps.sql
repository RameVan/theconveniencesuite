-- Per-meal ingredient swaps: [{"position": 3, "productId": "p_sushi_rice"}] replaces that recipe line for this meal only
-- (the shopping list and cooking follow it; the recipe itself is unchanged).
ALTER TABLE meal_slots ADD COLUMN swaps TEXT NOT NULL DEFAULT '[]';
