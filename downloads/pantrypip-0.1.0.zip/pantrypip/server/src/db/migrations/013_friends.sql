-- Friends: people (not households) who share their progress numbers with each other.
-- You find a friend by their friend code or link, never by email. Nothing is shared until the
-- request is accepted; declining or removing deletes the row.
CREATE TABLE friend_codes (
  user_id       TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  code          TEXT NOT NULL UNIQUE,
  created_at    TEXT NOT NULL
);

CREATE TABLE friendships (
  id            TEXT PRIMARY KEY,
  requester_id  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  addressee_id  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status        TEXT NOT NULL CHECK (status IN ('pending','accepted')),
  created_at    TEXT NOT NULL,
  accepted_at   TEXT,
  UNIQUE (requester_id, addressee_id)
);
CREATE INDEX friendships_addressee ON friendships(addressee_id, status);
