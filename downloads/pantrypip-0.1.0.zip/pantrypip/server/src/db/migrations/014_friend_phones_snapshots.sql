-- Finding friends from your phone's contacts. Only people who opt in can be found, and the number is
-- stored as a keyed hash (HMAC with a server secret), never in plain text. A few people may claim the
-- same number (numbers aren't verified), so it isn't unique; a request still needs accepting.
CREATE TABLE user_phones (
  user_id       TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  phone_hash    TEXT NOT NULL,
  hint          TEXT NOT NULL,                  -- '+31 •••• 78', to show you which number you gave
  discoverable  INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT NOT NULL
);
CREATE INDEX user_phones_hash ON user_phones(phone_hash);

-- What friends see of a household, kept so the friends screen doesn't redo everyone's progress each time.
-- Rebuilt when the fingerprint (cooks, journey, waste, ratings, challenges) or the day changes.
CREATE TABLE progress_snapshots (
  household_id  TEXT PRIMARY KEY REFERENCES households(id),
  data          TEXT NOT NULL,
  fingerprint   TEXT NOT NULL,
  day           TEXT NOT NULL,
  computed_at   TEXT NOT NULL
);
