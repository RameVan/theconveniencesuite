-- Playing together: rewards from friends, cheers and nudges, duels, passed recipes, shared challenges and
-- team goals, leagues, and how much each friend may see.

-- XP and unlocks earned with friends (duel wins, team goals, passed recipes, invites, seasonal events).
-- Counted in game() like journey XP; the key stops a reward being given twice.
CREATE TABLE social_rewards (
  household_id  TEXT NOT NULL REFERENCES households(id),
  key           TEXT NOT NULL,                  -- 'duel:<id>' | 'goal:<id>' | 'pass:<id>' | 'invite:<friendship>' | 'event:<id>:<year>'
  kind          TEXT NOT NULL,                  -- duel | goal | pass | invite | event
  xp            INTEGER NOT NULL,
  title         TEXT NOT NULL,
  title_nl      TEXT NOT NULL,
  emoji         TEXT NOT NULL,
  unlock        TEXT,                           -- 'skin:pumpkin' | 'stage:heart'
  at            TEXT NOT NULL,
  PRIMARY KEY (household_id, key)
);

-- How did this friendship start (for the invite reward).
ALTER TABLE friendships ADD COLUMN via TEXT;

-- What a friend may see of you: everything, or only your streak.
CREATE TABLE friend_privacy (
  user_id       TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  friend_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  level         TEXT NOT NULL CHECK (level IN ('all','streak')),
  PRIMARY KEY (user_id, friend_id)
);

-- Cheers (👏 for something a friend earned) and nudges (🔥 cook today!). One nudge per pair per day.
CREATE TABLE cheers (
  id            TEXT PRIMARY KEY,
  from_user     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  to_user       TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind          TEXT NOT NULL CHECK (kind IN ('cheer','nudge')),
  ref           TEXT,                           -- what was cheered ('c1:boss', 'badge:first')
  day           TEXT NOT NULL,
  seen          INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL
);
CREATE INDEX cheers_to ON cheers(to_user, seen);
CREATE UNIQUE INDEX cheers_once ON cheers(from_user, to_user, kind, day, COALESCE(ref, ''));

-- Weekly duels: most XP from Monday to Sunday wins.
CREATE TABLE duels (
  id            TEXT PRIMARY KEY,
  challenger    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  opponent      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  week          TEXT NOT NULL,                  -- Monday
  status        TEXT NOT NULL CHECK (status IN ('pending','active','done','declined')),
  winner        TEXT,                           -- user id, or 'tie'
  scores        TEXT,                           -- JSON { userId: xp } once settled
  created_at    TEXT NOT NULL
);
CREATE UNIQUE INDEX duels_once ON duels(challenger, opponent, week);

-- A recipe sent to a friend. Accepting puts it on their to-try list; cooking it earns them XP.
CREATE TABLE recipe_passes (
  id            TEXT PRIMARY KEY,
  from_user     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  to_user       TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recipe_id     TEXT NOT NULL,                  -- in the sender's household (or built in)
  title         TEXT NOT NULL,
  emoji         TEXT,
  cooked_times  INTEGER NOT NULL DEFAULT 0,     -- how often the sender cooked it, at the time
  note          TEXT,
  status        TEXT NOT NULL CHECK (status IN ('sent','added','dismissed')),
  added_recipe_id TEXT,                         -- the recipe in the receiver's household once added
  created_at    TEXT NOT NULL
);
CREATE INDEX recipe_passes_to ON recipe_passes(to_user, status);

-- Things friends do together: a challenge started together, or a team goal ("50 dinners this month").
CREATE TABLE social_groups (
  id            TEXT PRIMARY KEY,
  kind          TEXT NOT NULL CHECK (kind IN ('challenge','goal')),
  ref           TEXT NOT NULL,                  -- challenge id, or the goal's metric ('dinners')
  target        INTEGER,
  starts        TEXT NOT NULL,
  ends          TEXT NOT NULL,
  created_by    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at    TEXT NOT NULL
);
CREATE TABLE social_group_members (
  group_id      TEXT NOT NULL REFERENCES social_groups(id) ON DELETE CASCADE,
  user_id       TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status        TEXT NOT NULL CHECK (status IN ('invited','joined','left')),
  joined_at     TEXT,
  PRIMARY KEY (group_id, user_id)
);

-- Leagues move once a week, from the household's XP of the week before.
CREATE TABLE leagues (
  household_id  TEXT PRIMARY KEY REFERENCES households(id),
  week          TEXT NOT NULL,                  -- the Monday this league holds for
  league        INTEGER NOT NULL,               -- 0 Bronze … 4 Diamond
  moved         INTEGER NOT NULL DEFAULT 0      -- +1 promoted, -1 relegated, 0 stayed (this week)
);
