-- Accounts exist only once the email address is confirmed: until then the sign-up waits here.
CREATE TABLE pending_signups (
  token_hash      TEXT PRIMARY KEY,
  email           TEXT NOT NULL,
  name            TEXT NOT NULL,
  password_hash   TEXT NOT NULL,
  invite_code     TEXT,
  household_name  TEXT,
  created_at      TEXT NOT NULL,
  expires_at      TEXT NOT NULL
);
CREATE INDEX pending_signups_email ON pending_signups(lower(email));

-- "Forgot password" links: one use, short-lived, stored hashed.
CREATE TABLE password_resets (
  token_hash  TEXT PRIMARY KEY,
  user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at  TEXT NOT NULL,
  expires_at  TEXT NOT NULL,
  used_at     TEXT
);

-- Owner test mode: the household's data is snapshotted on entry and put back on exit.
CREATE TABLE test_mode (
  household_id  TEXT PRIMARY KEY REFERENCES households(id),
  user_id       TEXT NOT NULL,
  snapshot      TEXT NOT NULL,                  -- file name in the backups folder
  offset_days   INTEGER NOT NULL DEFAULT 0,     -- time travel, this household only
  unlocked      INTEGER NOT NULL DEFAULT 0,
  started_at    TEXT NOT NULL
);
