-- Shared shopping lists: a named list between people in different households (friends going on one shop).
-- It belongs to people, not to a household, so none of these tables has a household_id: test mode and
-- "reset progress" leave them alone, and a household's own list (shopping_items) is unchanged.
-- Whoever ticks an item bought it; finishing puts it in that person's household stock only.
CREATE TABLE shared_lists (
  id            TEXT PRIMARY KEY,
  name          TEXT NOT NULL,
  owner_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL
);

-- The owner is a member too. Friends are invited and see the list once they join.
CREATE TABLE shared_list_members (
  list_id       TEXT NOT NULL REFERENCES shared_lists(id) ON DELETE CASCADE,
  user_id       TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status        TEXT NOT NULL CHECK (status IN ('invited','joined')),
  invited_by    TEXT REFERENCES users(id) ON DELETE SET NULL,
  created_at    TEXT NOT NULL,
  joined_at     TEXT,
  PRIMARY KEY (list_id, user_id)
);
CREATE INDEX shared_list_members_user ON shared_list_members(user_id, status);

CREATE TABLE shared_list_items (
  id            TEXT PRIMARY KEY,
  list_id       TEXT NOT NULL REFERENCES shared_lists(id) ON DELETE CASCADE,
  product_id    TEXT REFERENCES products(id) ON DELETE SET NULL,   -- as the adder's household knows it
  name          TEXT NOT NULL,
  category      TEXT NOT NULL DEFAULT 'other',
  packages      REAL,
  note          TEXT,
  added_by      TEXT REFERENCES users(id) ON DELETE SET NULL,
  claimed_by    TEXT REFERENCES users(id) ON DELETE SET NULL,      -- "I'll get this"
  checked_by    TEXT REFERENCES users(id) ON DELETE SET NULL,      -- in their cart
  checked_at    TEXT,
  bought_by     TEXT REFERENCES users(id) ON DELETE SET NULL,      -- finished: in their stock
  bought_at     TEXT,
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL
);
CREATE INDEX shared_list_items_list ON shared_list_items(list_id, bought_at);
