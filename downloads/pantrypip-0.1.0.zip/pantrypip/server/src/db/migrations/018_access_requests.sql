-- "Request access" on an invite-only copy: a name, an email and a note, nothing else, until the owner decides.
-- Approving mails a one-time sign-up link (only its hash is stored); declining just closes the request.
CREATE TABLE access_requests (
  id          TEXT PRIMARY KEY,
  email       TEXT NOT NULL,
  name        TEXT NOT NULL,
  note        TEXT,
  lang        TEXT,
  status      TEXT NOT NULL DEFAULT 'pending',   -- pending | approved | declined | used
  token_hash  TEXT UNIQUE,                       -- set when approved
  created_at  TEXT NOT NULL,
  decided_at  TEXT,
  expires_at  TEXT,                              -- of the sign-up link
  used_at     TEXT
);
CREATE INDEX access_requests_email ON access_requests(lower(email));
