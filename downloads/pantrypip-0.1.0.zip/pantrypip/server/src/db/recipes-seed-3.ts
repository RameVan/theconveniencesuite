// Breakfasts, lunches, snacks and desserts, written for this project. Recipes tagged breakfast, sandwich,
// snack, dessert or baking are left out of the dinner planner.
import type { SeedRecipe } from './recipes-seed.ts';

export const DAYTIME_RECIPES: SeedRecipe[] = [
  // Breakfast
  {
    key: 'bircher_muesli', title: 'Bircher muesli with apple', summary: 'Soaked overnight, creamy and ready when you are.',
    cuisine: 'Swiss', tags: ['breakfast', 'no-cook', 'meal-prep'], diet: [], difficulty: 'easy', servings: 2, prep: 10, cook: 0, emoji: '🥣', color: '#D9B26F',
    ingredients: [['oats', 100, '100 g rolled oats'], ['milk', 200, '200 ml milk'], ['yoghurt', 150, '150 g yoghurt'], ['apples', 1, '1 apple, grated'], ['honey', 15, '1 tbsp honey'], ['nuts', 20, 'A handful of nuts', true], ['raisins', 20, '2 tbsp raisins', true]],
    steps: ['Stir oats, milk and yoghurt together with the grated apple and raisins.', 'Cover and leave in the fridge overnight.', 'Top with honey and chopped nuts.'],
  },
  {
    key: 'banana_oat_pancakes', title: 'Banana oat pancakes', summary: 'Three ingredients, blender, done.',
    cuisine: 'American', tags: ['breakfast', 'quick'], diet: [], difficulty: 'easy', servings: 2, prep: 5, cook: 10, emoji: '🥞', color: '#E8C170',
    ingredients: [['bananas', 2, '2 ripe bananas'], ['eggs', 2, '2 eggs'], ['oats', 80, '80 g oats'], ['butter', 10, 'A little butter for the pan'], ['berries', 100, 'Berries, to serve', true], ['honey', 10, 'Honey, to serve', true]],
    steps: ['Blend bananas, eggs and oats into a thick batter.', ['Fry small pancakes in a little butter, 2 minutes a side.', 480], 'Serve with berries and a drizzle of honey.'],
  },
  {
    key: 'porridge_cinnamon_apple', title: 'Cinnamon apple porridge', summary: 'Warm oats with soft spiced apple.',
    cuisine: 'British', tags: ['breakfast', 'quick', 'budget'], diet: [], difficulty: 'easy', servings: 2, prep: 2, cook: 8, emoji: '🍎', color: '#C9A66B',
    ingredients: [['oats', 90, '90 g oats'], ['milk', 400, '400 ml milk'], ['apples', 1, '1 apple, diced'], ['cinnamon', 2, '1 tsp cinnamon'], ['honey', 15, '1 tbsp honey']],
    steps: [['Simmer oats, milk, apple and cinnamon, stirring, until thick.', 360], 'Sweeten with honey.'],
  },
  {
    key: 'avocado_toast_egg', title: 'Avocado toast with a fried egg', summary: 'Crunchy toast, creamy avocado, runny yolk.',
    cuisine: 'Modern', tags: ['breakfast', 'quick'], diet: [], difficulty: 'easy', servings: 2, prep: 5, cook: 5, emoji: '🥑', color: '#7FA650',
    ingredients: [['bread', 140, '4 slices of bread'], ['avocado', 1, '1 ripe avocado'], ['eggs', 2, '2 eggs'], ['lemon', 0.5, '½ lemon'], ['olive_oil', 10, '2 tsp olive oil'], ['chili', 0.5, 'Chilli flakes', true]],
    steps: ['Toast the bread.', 'Mash the avocado with lemon juice, salt and pepper.', ['Fry the eggs in the oil.', 180], 'Spread the avocado on the toast and top with the eggs and chilli.'],
  },
  {
    key: 'scrambled_eggs_toast', title: 'Soft scrambled eggs on toast', summary: 'Low heat, lots of patience, a little butter.',
    cuisine: 'British', tags: ['breakfast', 'quick', 'high-protein'], diet: [], difficulty: 'easy', servings: 2, prep: 2, cook: 6, emoji: '🍳', color: '#F2C94C',
    ingredients: [['eggs', 4, '4 eggs'], ['butter', 15, '15 g butter'], ['milk', 30, '2 tbsp milk'], ['bread', 140, '4 slices of bread'], ['spring_onion', 1, '1 spring onion', true]],
    steps: ['Whisk the eggs with the milk, salt and pepper.', ['Melt the butter on low heat, add the eggs and stir slowly until just set.', 300], 'Pile onto toast and top with spring onion.'],
  },
  {
    key: 'french_toast', title: 'Wentelteefjes (French toast)', summary: 'The Dutch way to rescue yesterday’s bread.',
    cuisine: 'Dutch', tags: ['breakfast', 'use-it-up', 'family'], diet: [], difficulty: 'easy', servings: 2, prep: 5, cook: 10, emoji: '🍞', color: '#D4A055',
    ingredients: [['bread', 210, '6 slices of day-old bread'], ['eggs', 2, '2 eggs'], ['milk', 150, '150 ml milk'], ['cinnamon', 2, '1 tsp cinnamon'], ['sugar', 15, '1 tbsp sugar'], ['butter', 20, '20 g butter']],
    steps: ['Whisk eggs, milk, cinnamon and sugar in a deep plate.', 'Soak each slice briefly on both sides.', ['Fry in butter until golden, about 2 minutes a side.', 480]],
  },
  {
    key: 'skyr_berry_bowl', title: 'Skyr bowl with berries & muesli', summary: 'High in protein, ready in two minutes.',
    cuisine: 'Nordic', tags: ['breakfast', 'no-cook', 'high-protein', 'quick'], diet: [], difficulty: 'easy', servings: 1, prep: 3, cook: 0, emoji: '🫐', color: '#6C7BC4',
    ingredients: [['skyr', 200, '200 g skyr'], ['berries', 80, '80 g berries'], ['breakfast_cereal', 40, '40 g muesli'], ['honey', 10, '2 tsp honey', true]],
    steps: ['Spoon the skyr into a bowl and top with berries, muesli and honey.'],
  },
  {
    key: 'breakfast_burrito', title: 'Breakfast burritos', summary: 'Eggs, beans and cheese rolled up to go.',
    cuisine: 'Mexican', tags: ['breakfast', 'high-protein'], diet: [], difficulty: 'easy', servings: 2, prep: 5, cook: 10, emoji: '🌯', color: '#D97C3A',
    ingredients: [['wraps', 2, '2 wraps'], ['eggs', 4, '4 eggs'], ['black_beans', 120, '½ tin black beans'], ['cheese', 40, '40 g grated cheese'], ['tomatoes', 1, '1 tomato, diced'], ['sunflower_oil', 10, '2 tsp oil'], ['avocado', 1, '1 avocado', true]],
    steps: ['Warm the beans in a small pan.', ['Scramble the eggs in the oil.', 180], 'Fill the wraps with eggs, beans, cheese, tomato and avocado, and roll up.'],
  },
  {
    key: 'shakshuka_green', title: 'Green shakshuka', summary: 'Eggs baked in spinach, courgette and feta.',
    cuisine: 'Middle Eastern', tags: ['breakfast', 'brunch', 'low-carb'], diet: [], difficulty: 'easy', servings: 2, prep: 5, cook: 15, emoji: '🍳', color: '#5E8C4A',
    ingredients: [['spinach', 200, '200 g spinach'], ['zucchini', 1, '1 courgette, diced'], ['spring_onion', 3, '3 spring onions'], ['garlic', 2, '2 garlic cloves'], ['eggs', 4, '4 eggs'], ['feta', 60, '60 g feta'], ['cumin', 2, '1 tsp cumin'], ['olive_oil', 15, '1 tbsp olive oil'], ['bread', 70, 'Bread, to serve', true]],
    steps: ['Soften courgette, spring onion and garlic in the oil for 5 minutes with the cumin.', 'Stir in the spinach until wilted.', ['Make four hollows, crack in the eggs, cover and cook until the whites set.', 360], 'Crumble over the feta and serve with bread.'],
  },
  {
    key: 'yoghurt_granola_parfait', title: 'Yoghurt parfait with orange & nuts', summary: 'Layers of yoghurt, fruit and crunch.',
    cuisine: 'Modern', tags: ['breakfast', 'no-cook'], diet: [], difficulty: 'easy', servings: 2, prep: 5, cook: 0, emoji: '🍊', color: '#F2994A',
    ingredients: [['yoghurt', 300, '300 g Greek yoghurt'], ['oranges', 2, '2 oranges, segmented'], ['breakfast_cereal', 60, '60 g granola'], ['nuts', 20, 'Chopped nuts'], ['honey', 10, 'Honey']],
    steps: ['Layer yoghurt, orange and granola in two glasses.', 'Finish with nuts and a little honey.'],
  },
  {
    key: 'egg_muffins', title: 'Vegetable egg muffins', summary: 'Bake once, grab breakfast all week.',
    cuisine: 'Modern', tags: ['breakfast', 'meal-prep', 'low-carb', 'high-protein'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 20, emoji: '🧁', color: '#E2B33C',
    ingredients: [['eggs', 8, '8 eggs'], ['bell_pepper', 1, '1 pepper, diced'], ['spinach', 80, '80 g spinach, chopped'], ['cheese', 60, '60 g grated cheese'], ['spring_onion', 2, '2 spring onions'], ['ham', 60, '60 g ham, diced', true]],
    steps: ['Heat the oven to 180 °C and grease a 12-hole muffin tin.', 'Whisk the eggs, stir in everything else and season.', ['Divide over the tin and bake until set.', 1200], 'Keep in the fridge for up to 4 days.'],
  },
  {
    key: 'croissant_ham_cheese', title: 'Warm ham & cheese croissants', summary: 'A weekend treat in ten minutes.',
    cuisine: 'French', tags: ['breakfast', 'brunch', 'quick'], diet: [], difficulty: 'easy', servings: 2, prep: 3, cook: 7, emoji: '🥐', color: '#D9A441',
    ingredients: [['croissants', 4, '4 croissants'], ['ham', 60, '4 slices of ham'], ['cheese', 60, '3 slices of cheese'], ['mustard', 5, 'A little mustard', true]],
    steps: ['Heat the oven to 180 °C.', 'Split the croissants and fill with mustard, ham and cheese.', ['Bake until the cheese melts.', 420]],
  },
  {
    key: 'smoothie_bowl', title: 'Berry smoothie bowl', summary: 'Thick, cold and bright purple.',
    cuisine: 'Modern', tags: ['breakfast', 'no-cook', 'quick'], diet: [], difficulty: 'easy', servings: 2, prep: 5, cook: 0, emoji: '🍇', color: '#8E44AD',
    ingredients: [['frozen_berries', 250, '250 g frozen berries'], ['bananas', 1, '1 banana'], ['yoghurt', 150, '150 g yoghurt'], ['oat_milk', 60, 'A splash of milk'], ['breakfast_cereal', 40, 'Granola, to top'], ['nuts', 15, 'Nuts', true]],
    steps: ['Blend berries, banana, yoghurt and milk until thick.', 'Pour into bowls and top with granola and nuts.'],
  },
  {
    key: 'cottage_cheese_toast', title: 'Cottage cheese & tomato toast', summary: 'Savoury, protein-rich and fast.',
    cuisine: 'Modern', tags: ['breakfast', 'quick', 'high-protein'], diet: [], difficulty: 'easy', servings: 2, prep: 5, cook: 2, emoji: '🍅', color: '#E05A47',
    ingredients: [['bread', 140, '4 slices of bread'], ['cottage_cheese', 200, '200 g cottage cheese'], ['cherry_tomatoes', 150, '150 g cherry tomatoes'], ['basil', 5, 'Basil leaves'], ['olive_oil', 10, 'Olive oil']],
    steps: ['Toast the bread.', 'Spread with cottage cheese, top with halved tomatoes and basil, and drizzle with oil.'],
  },
  {
    key: 'baked_oats', title: 'Baked blueberry oats', summary: 'Like cake for breakfast, but mostly oats.',
    cuisine: 'Modern', tags: ['breakfast', 'meal-prep', 'oven'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 30, emoji: '🫐', color: '#5B6DB8',
    ingredients: [['oats', 200, '200 g oats'], ['milk', 400, '400 ml milk'], ['eggs', 2, '2 eggs'], ['bananas', 2, '2 bananas, mashed'], ['berries', 150, '150 g blueberries'], ['cinnamon', 2, '1 tsp cinnamon'], ['honey', 30, '2 tbsp honey']],
    steps: ['Heat the oven to 180 °C.', 'Mix everything except the berries, pour into a dish, then scatter the berries on top.', ['Bake until set and golden.', 1800]],
  },
  {
    key: 'uitsmijter', title: 'Uitsmijter', summary: 'Fried eggs over ham and cheese on bread, the Dutch lunchroom classic.',
    cuisine: 'Dutch', tags: ['breakfast', 'brunch', 'quick', 'high-protein'], diet: [], difficulty: 'easy', servings: 2, prep: 3, cook: 6, emoji: '🍳', color: '#E6B422',
    ingredients: [['bread', 140, '4 slices of bread'], ['ham', 60, '4 slices of ham'], ['cheese', 60, '3 slices of cheese'], ['eggs', 4, '4 eggs'], ['butter', 10, 'Butter'], ['tomatoes', 1, '1 tomato, sliced', true]],
    steps: ['Butter the bread and top with ham and cheese.', ['Fry the eggs in a little butter.', 240], 'Slide the eggs over the bread and serve with tomato.'],
  },

  // Lunch
  {
    key: 'tuna_melt', title: 'Tuna melt', summary: 'Tuna mayo and melted cheese on toast.',
    cuisine: 'American', tags: ['sandwich', 'quick'], diet: [], difficulty: 'easy', servings: 2, prep: 5, cook: 5, emoji: '🥪', color: '#C9A15A',
    ingredients: [['tuna', 145, '1 tin tuna, drained'], ['mayonnaise', 30, '2 tbsp mayonnaise'], ['red_onion', 0.5, '½ red onion, finely chopped'], ['bread', 140, '4 slices of bread'], ['cheese', 60, '3 slices of cheese']],
    steps: ['Mix tuna, mayonnaise and onion with pepper.', 'Toast the bread lightly and spread the tuna over it.', ['Top with cheese and grill until it bubbles.', 240]],
  },
  {
    key: 'hummus_veggie_wrap', title: 'Hummus & crunchy vegetable wraps', summary: 'A packed lunch that doesn’t go soggy.',
    cuisine: 'Mediterranean', tags: ['sandwich', 'no-cook', 'quick'], diet: [], difficulty: 'easy', servings: 2, prep: 10, cook: 0, emoji: '🌯', color: '#9BBF59',
    ingredients: [['wraps', 2, '2 wraps'], ['hummus', 100, '100 g hummus'], ['carrots', 80, '1 carrot, grated'], ['cucumber', 0.5, '½ cucumber, in sticks'], ['lettuce', 40, 'A handful of lettuce'], ['bell_pepper', 0.5, '½ pepper, in strips'], ['feta', 40, 'Feta', true]],
    steps: ['Spread the wraps with hummus.', 'Fill with the vegetables (and feta), roll up tightly and halve.'],
  },
  {
    key: 'club_sandwich', title: 'Chicken club sandwich', summary: 'Triple-decker with bacon, chicken and tomato.',
    cuisine: 'American', tags: ['sandwich', 'high-protein'], diet: [], difficulty: 'easy', servings: 2, prep: 10, cook: 10, emoji: '🥪', color: '#B5733F',
    ingredients: [['bread', 210, '6 slices of bread'], ['chicken_breast', 150, '1 chicken breast'], ['bacon', 60, '4 rashers of bacon'], ['tomatoes', 1, '1 tomato'], ['lettuce', 40, 'Lettuce'], ['mayonnaise', 30, '2 tbsp mayonnaise']],
    steps: [['Fry the chicken until cooked through, then slice.', 600], 'Fry the bacon until crisp and toast the bread.', 'Layer toast, mayo, lettuce, chicken, tomato and bacon in two stacks, then cut diagonally.'],
  },
  {
    key: 'caprese_sandwich', title: 'Caprese sandwich with pesto', summary: 'Mozzarella, tomato and basil in crusty bread.',
    cuisine: 'Italian', tags: ['sandwich', 'quick', 'no-cook'], diet: [], difficulty: 'easy', servings: 2, prep: 5, cook: 0, emoji: '🥖', color: '#D64541',
    ingredients: [['bread', 160, '2 crusty rolls or 4 slices'], ['mozzarella', 125, '1 ball of mozzarella'], ['tomatoes', 2, '2 tomatoes'], ['pesto', 30, '2 tbsp pesto'], ['basil', 5, 'Basil'], ['rocket', 20, 'Rocket', true]],
    steps: ['Spread the bread with pesto.', 'Fill with sliced mozzarella, tomato, basil and rocket. Season.'],
  },
  {
    key: 'egg_salad_sandwich', title: 'Egg salad sandwiches', summary: 'Creamy, mustardy, a lunchbox favourite.',
    cuisine: 'British', tags: ['sandwich', 'budget'], diet: [], difficulty: 'easy', servings: 2, prep: 5, cook: 10, emoji: '🥚', color: '#F0D264',
    ingredients: [['eggs', 4, '4 eggs'], ['mayonnaise', 30, '2 tbsp mayonnaise'], ['mustard', 5, '1 tsp mustard'], ['spring_onion', 1, '1 spring onion'], ['bread', 140, '4 slices of bread'], ['lettuce', 20, 'Lettuce', true]],
    steps: [['Boil the eggs for 9 minutes, cool and peel.', 540], 'Mash with mayonnaise, mustard, spring onion, salt and pepper.', 'Spread between the bread with lettuce.'],
  },
  {
    key: 'mackerel_salad_bread', title: 'Smoked mackerel & beetroot open sandwich', summary: 'Smoky fish, sweet beetroot, fresh dill.',
    cuisine: 'Nordic', tags: ['sandwich', 'quick'], diet: [], difficulty: 'easy', servings: 2, prep: 8, cook: 0, emoji: '🐟', color: '#8E3B5A',
    ingredients: [['smoked_mackerel', 120, '120 g smoked mackerel'], ['beetroot', 100, '1 cooked beetroot'], ['creme_fraiche', 50, '3 tbsp crème fraîche'], ['bread', 140, '4 slices of rye or brown bread'], ['dill', 5, 'Dill'], ['lemon', 0.5, '½ lemon']],
    steps: ['Flake the mackerel and mix with crème fraîche and lemon juice.', 'Top the bread with sliced beetroot and the mackerel, then dill.'],
  },
  {
    key: 'quesadillas', title: 'Bean & cheese quesadillas', summary: 'Crispy, melty and done in 10 minutes.',
    cuisine: 'Mexican', tags: ['quick', 'family', 'budget'], diet: [], difficulty: 'easy', servings: 2, prep: 5, cook: 8, emoji: '🧀', color: '#E39B2E',
    ingredients: [['wraps', 4, '4 wraps'], ['black_beans', 240, '1 tin black beans, drained'], ['cheese', 100, '100 g grated cheese'], ['corn', 100, '100 g sweetcorn'], ['spring_onion', 2, '2 spring onions'], ['cumin', 2, '1 tsp cumin'], ['creme_fraiche', 60, 'Crème fraîche, to serve', true]],
    steps: ['Mash the beans roughly with the cumin.', 'Spread over two wraps, scatter with corn, spring onion and cheese, and close with the other wraps.', ['Dry-fry each one until crisp and melted, flipping once.', 360], 'Cut into wedges.'],
  },
  {
    key: 'couscous_salad', title: 'Lemony couscous salad', summary: 'Cucumber, tomato, herbs and feta. Great for lunchboxes.',
    cuisine: 'Mediterranean', tags: ['lunch', 'salad', 'meal-prep', 'quick'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 5, emoji: '🥗', color: '#C9B458',
    ingredients: [['couscous', 250, '250 g couscous'], ['stock_cube', 1, '1 stock cube'], ['cucumber', 1, '1 cucumber, diced'], ['cherry_tomatoes', 250, '250 g cherry tomatoes'], ['red_onion', 1, '1 red onion'], ['feta', 100, '100 g feta'], ['mint', 10, 'Mint'], ['parsley', 15, 'Parsley'], ['lemon', 1, '1 lemon'], ['olive_oil', 30, '2 tbsp olive oil'], ['chickpeas', 240, '1 tin chickpeas', true]],
    steps: ['Pour 300 ml boiling water with the stock cube over the couscous, cover for 5 minutes, then fluff up.', 'Chop the vegetables and herbs.', 'Mix everything with lemon juice and oil, crumble over the feta.'],
  },
  {
    key: 'tomato_mozzarella_salad', title: 'Tomato, mozzarella & rocket salad', summary: 'Summer on a plate.',
    cuisine: 'Italian', tags: ['lunch', 'salad', 'no-cook', 'quick'], diet: [], difficulty: 'easy', servings: 2, prep: 8, cook: 0, emoji: '🍅', color: '#D33F3F',
    ingredients: [['tomatoes', 3, '3 ripe tomatoes'], ['mozzarella', 125, '1 ball of mozzarella'], ['rocket', 50, '50 g rocket'], ['basil', 5, 'Basil'], ['olive_oil', 20, 'Olive oil'], ['vinegar', 10, 'Balsamic vinegar'], ['bread', 70, 'Bread, to serve', true]],
    steps: ['Slice the tomatoes and mozzarella and arrange on the rocket.', 'Season, then drizzle with oil and vinegar and scatter with basil.'],
  },
  {
    key: 'pita_falafel_style', title: 'Spiced chickpea pitas', summary: 'Crispy chickpeas, yoghurt sauce and salad in warm pita.',
    cuisine: 'Middle Eastern', tags: ['lunch', 'quick'], diet: [], difficulty: 'easy', servings: 2, prep: 10, cook: 10, emoji: '🥙', color: '#C28A3A',
    ingredients: [['pita', 4, '4 pitas'], ['chickpeas', 240, '1 tin chickpeas, drained'], ['cumin', 3, '1 tsp cumin'], ['paprika_powder', 3, '1 tsp paprika'], ['yoghurt', 100, '100 g yoghurt'], ['garlic', 1, '1 garlic clove'], ['cucumber', 0.5, '½ cucumber'], ['tomatoes', 1, '1 tomato'], ['lettuce', 40, 'Lettuce'], ['olive_oil', 15, '1 tbsp oil']],
    steps: [['Fry the chickpeas in the oil with the spices until crisp.', 480], 'Stir the grated garlic into the yoghurt with a pinch of salt.', 'Warm the pitas and fill with lettuce, cucumber, tomato, chickpeas and sauce.'],
  },
  {
    key: 'chicken_caesar_wrap', title: 'Chicken Caesar wraps', summary: 'All the Caesar flavour, wrapped to go.',
    cuisine: 'American', tags: ['sandwich', 'high-protein'], diet: [], difficulty: 'easy', servings: 2, prep: 10, cook: 10, emoji: '🌯', color: '#A7B85A',
    ingredients: [['wraps', 2, '2 wraps'], ['chicken_breast', 250, '2 small chicken breasts'], ['lettuce', 80, 'Romaine or little gem'], ['parmesan', 20, '20 g parmesan'], ['mayonnaise', 30, '2 tbsp mayonnaise'], ['lemon', 0.5, '½ lemon'], ['garlic', 1, '1 garlic clove'], ['olive_oil', 10, '2 tsp oil']],
    steps: [['Fry the chicken in the oil until cooked, then slice.', 600], 'Mix mayonnaise, lemon juice, grated garlic and half the parmesan.', 'Fill the wraps with lettuce, chicken, dressing and the rest of the parmesan.'],
  },
  {
    key: 'lentil_salad_feta', title: 'Warm lentil salad with feta', summary: 'Earthy, filling and good cold the next day.',
    cuisine: 'Mediterranean', tags: ['lunch', 'salad', 'meal-prep'], diet: [], difficulty: 'easy', servings: 3, prep: 10, cook: 15, emoji: '🥗', color: '#8C6E4A',
    ingredients: [['lentils', 200, '200 g lentils'], ['red_onion', 1, '1 red onion'], ['bell_pepper', 1, '1 pepper'], ['cherry_tomatoes', 200, '200 g cherry tomatoes'], ['feta', 100, '100 g feta'], ['parsley', 15, 'Parsley'], ['vinegar', 15, '1 tbsp vinegar'], ['olive_oil', 30, '2 tbsp olive oil'], ['mustard', 5, '1 tsp mustard']],
    steps: [['Cook the lentils until just tender, then drain.', 720], 'Whisk oil, vinegar and mustard; toss with the warm lentils.', 'Add the chopped vegetables and parsley, crumble over the feta.'],
  },
  {
    key: 'tuna_nicoise', title: 'Salade niçoise', summary: 'Tuna, egg, beans, potato and olives.',
    cuisine: 'French', tags: ['lunch', 'salad', 'high-protein'], diet: [], difficulty: 'easy', servings: 2, prep: 10, cook: 15, emoji: '🥗', color: '#4E8C6E',
    ingredients: [['potatoes', 300, '300 g small potatoes'], ['green_beans', 150, '150 g green beans'], ['eggs', 2, '2 eggs'], ['tuna', 145, '1 tin tuna'], ['cherry_tomatoes', 150, '150 g cherry tomatoes'], ['olives', 40, 'A handful of olives'], ['lettuce', 80, 'Lettuce'], ['olive_oil', 30, '2 tbsp olive oil'], ['vinegar', 10, '2 tsp vinegar'], ['mustard', 5, '1 tsp mustard']],
    steps: [['Boil the potatoes; add the beans for the last 4 minutes.', 900], ['Boil the eggs for 8 minutes.', 480], 'Whisk oil, vinegar and mustard.', 'Arrange everything on the lettuce and drizzle with the dressing.'],
  },
  {
    key: 'tosti', title: 'Tosti ham-kaas', summary: 'The Dutch toastie, with ketchup on the side.',
    cuisine: 'Dutch', tags: ['sandwich', 'quick', 'family'], diet: [], difficulty: 'easy', servings: 2, prep: 2, cook: 5, emoji: '🧀', color: '#E3A33B',
    ingredients: [['bread', 140, '4 slices of bread'], ['ham', 60, '4 slices of ham'], ['cheese', 80, '4 slices of cheese'], ['butter', 10, 'Butter'], ['ketchup', 30, 'Ketchup', true]],
    steps: ['Butter the outsides of the bread.', ['Fill with ham and cheese and toast in a pan or toastie maker until golden.', 300], 'Serve with ketchup.'],
  },
  {
    key: 'quinoa_power_salad', title: 'Quinoa power salad', summary: 'Quinoa, roasted squash, rocket and seeds.',
    cuisine: 'Modern', tags: ['lunch', 'salad', 'meal-prep'], diet: [], difficulty: 'easy', servings: 3, prep: 10, cook: 25, emoji: '🥗', color: '#E58B3A',
    ingredients: [['quinoa', 150, '150 g quinoa'], ['pumpkin', 0.5, '½ butternut squash, in cubes'], ['rocket', 50, '50 g rocket'], ['feta', 80, '80 g feta', true], ['nuts', 30, '30 g nuts'], ['olive_oil', 30, '2 tbsp olive oil'], ['lemon', 1, '1 lemon'], ['honey', 10, '2 tsp honey']],
    steps: [['Roast the squash with half the oil at 200 °C.', 1500], ['Cook the quinoa meanwhile.', 900], 'Whisk the rest of the oil with lemon juice and honey.', 'Toss everything together with the rocket and nuts.'],
  },

  // Snacks & desserts
  {
    key: 'banana_bread', title: 'Banana bread', summary: 'The best use for brown bananas.',
    cuisine: 'American', tags: ['baking', 'use-it-up'], diet: [], difficulty: 'easy', servings: 10, prep: 15, cook: 55, emoji: '🍌', color: '#B8864B',
    ingredients: [['bananas', 3, '3 very ripe bananas'], ['flour', 250, '250 g self-raising flour'], ['sugar', 100, '100 g sugar'], ['butter', 100, '100 g butter, melted'], ['eggs', 2, '2 eggs'], ['cinnamon', 2, '1 tsp cinnamon'], ['nuts', 50, '50 g walnuts', true]],
    steps: ['Heat the oven to 175 °C and line a loaf tin.', 'Mash the bananas; stir in butter, sugar and eggs, then flour, cinnamon and nuts.', ['Bake until a skewer comes out clean.', 3300], 'Cool before slicing.'],
  },
  {
    key: 'apple_crumble', title: 'Apple crumble', summary: 'Soft cinnamon apples under a buttery crumble.',
    cuisine: 'British', tags: ['dessert', 'baking', 'family'], diet: [], difficulty: 'easy', servings: 6, prep: 15, cook: 35, emoji: '🍏', color: '#C78F4E',
    ingredients: [['apples', 5, '5 apples'], ['flour', 150, '150 g flour'], ['butter', 100, '100 g cold butter'], ['sugar', 100, '100 g sugar'], ['oats', 50, '50 g oats'], ['cinnamon', 3, '1 tsp cinnamon'], ['ice_cream', 300, 'Ice cream, to serve', true]],
    steps: ['Heat the oven to 190 °C.', 'Slice the apples into a dish and toss with the cinnamon and a third of the sugar.', 'Rub flour and butter into crumbs, then stir in oats and the rest of the sugar.', ['Scatter over the apples and bake until golden.', 2100]],
  },
  {
    key: 'appeltaart', title: 'Dutch apple pie', summary: 'Tall, lattice-topped and full of apples and raisins.',
    cuisine: 'Dutch', tags: ['baking', 'dessert', 'weekend'], diet: [], difficulty: 'medium', servings: 10, prep: 30, cook: 60, emoji: '🥧', color: '#B97A3C',
    ingredients: [['flour', 300, '300 g flour'], ['butter', 200, '200 g butter'], ['sugar', 150, '150 g sugar'], ['eggs', 1, '1 egg'], ['apples', 6, '6 tart apples'], ['raisins', 50, '50 g raisins'], ['cinnamon', 5, '2 tsp cinnamon'], ['lemon', 0.5, '½ lemon']],
    steps: ['Knead flour, butter, 100 g sugar, most of the egg and a pinch of salt into a dough. Chill 20 minutes.', 'Heat the oven to 175 °C. Line a greased springform with two thirds of the dough.', 'Slice the apples and mix with raisins, cinnamon, lemon juice and the rest of the sugar; fill the tin.', 'Cover with strips of the remaining dough and brush with the rest of the egg.', ['Bake until deep golden.', 3600]],
  },
  {
    key: 'chocolate_mousse', title: 'Easy chocolate mousse', summary: 'Two ingredients and a whisk.',
    cuisine: 'French', tags: ['dessert'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 0, emoji: '🍫', color: '#5B3A29',
    ingredients: [['chocolate', 150, '150 g dark chocolate'], ['cream', 250, '250 ml whipping cream'], ['berries', 100, 'Berries, to serve', true]],
    steps: ['Melt the chocolate and let it cool slightly.', 'Whip the cream to soft peaks and fold it into the chocolate.', ['Spoon into glasses and chill.', 3600]],
  },
  {
    key: 'yoghurt_bark', title: 'Frozen yoghurt berry bark', summary: 'A cold, fruity snack for warm days.',
    cuisine: 'Modern', tags: ['snack', 'dessert', 'no-cook'], diet: [], difficulty: 'easy', servings: 6, prep: 10, cook: 0, emoji: '🍓', color: '#E85D75',
    ingredients: [['yoghurt', 400, '400 g Greek yoghurt'], ['honey', 30, '2 tbsp honey'], ['berries', 150, '150 g berries'], ['chocolate', 30, '30 g dark chocolate', true]],
    steps: ['Mix the yoghurt and honey and spread thinly on a lined tray.', 'Scatter over the berries and grated chocolate.', ['Freeze until solid, then break into pieces.', 10800]],
  },
  {
    key: 'roasted_chickpeas', title: 'Crunchy roasted chickpeas', summary: 'A salty snack straight from the store cupboard.',
    cuisine: 'Modern', tags: ['snack', 'budget'], diet: [], difficulty: 'easy', servings: 4, prep: 5, cook: 30, emoji: '🫘', color: '#C99A4B',
    ingredients: [['chickpeas', 480, '2 tins chickpeas, drained and dried'], ['olive_oil', 15, '1 tbsp olive oil'], ['paprika_powder', 4, '2 tsp smoked paprika'], ['cumin', 2, '1 tsp cumin']],
    steps: ['Heat the oven to 200 °C.', 'Toss the chickpeas with oil, spices and salt on a tray.', ['Roast until crunchy, shaking the tray now and then.', 1800]],
  },
  {
    key: 'apple_peanut_slices', title: 'Apple slices with peanut butter', summary: 'The two-minute after-school snack.',
    cuisine: 'Modern', tags: ['snack', 'no-cook', 'quick'], diet: [], difficulty: 'easy', servings: 2, prep: 3, cook: 0, emoji: '🍎', color: '#D9534F',
    ingredients: [['apples', 2, '2 apples'], ['peanut_butter', 40, '2 tbsp peanut butter'], ['cinnamon', 1, 'A pinch of cinnamon', true]],
    steps: ['Slice the apples and serve with peanut butter for dipping, dusted with cinnamon.'],
  },
  {
    key: 'oat_cookies', title: 'Oat & raisin cookies', summary: 'Chewy cookies with a hint of cinnamon.',
    cuisine: 'British', tags: ['baking', 'snack'], diet: [], difficulty: 'easy', servings: 12, prep: 15, cook: 12, emoji: '🍪', color: '#B5834A',
    ingredients: [['oats', 150, '150 g oats'], ['flour', 100, '100 g flour'], ['butter', 100, '100 g soft butter'], ['sugar', 100, '100 g sugar'], ['eggs', 1, '1 egg'], ['raisins', 75, '75 g raisins'], ['cinnamon', 2, '1 tsp cinnamon']],
    steps: ['Heat the oven to 180 °C and line two trays.', 'Beat butter and sugar, then the egg; stir in flour, oats, cinnamon and raisins.', ['Spoon onto the trays, flatten slightly and bake until golden at the edges.', 720]],
  },
  {
    key: 'poffertjes_style', title: 'Mini pancakes (poffertjes-style)', summary: 'Little fluffy pancakes with butter and sugar.',
    cuisine: 'Dutch', tags: ['dessert', 'snack', 'family'], diet: [], difficulty: 'medium', servings: 4, prep: 10, cook: 20, emoji: '🥞', color: '#E0B25B',
    ingredients: [['flour', 200, '200 g self-raising flour'], ['milk', 300, '300 ml milk'], ['eggs', 1, '1 egg'], ['sugar', 15, '1 tbsp sugar'], ['butter', 40, '40 g butter']],
    steps: ['Whisk flour, milk, egg and sugar into a smooth batter. Rest 10 minutes.', ['Drop teaspoons into a buttered pan, flip when bubbles appear.', 900], 'Serve with a knob of butter and a little sugar.'],
  },
  {
    key: 'rice_pudding', title: 'Creamy rice pudding', summary: 'Slow-simmered with cinnamon.',
    cuisine: 'Dutch', tags: ['dessert', 'comfort', 'budget'], diet: [], difficulty: 'easy', servings: 4, prep: 5, cook: 40, emoji: '🍚', color: '#EADBC8',
    ingredients: [['rice', 120, '120 g short-grain rice'], ['whole_milk', 1000, '1 litre whole milk'], ['sugar', 60, '60 g sugar'], ['cinnamon', 2, '1 tsp cinnamon'], ['berries', 100, 'Fruit, to serve', true]],
    steps: [['Simmer rice, milk and sugar very gently, stirring often, until thick and creamy.', 2400], 'Dust with cinnamon and serve warm or cold with fruit.'],
  },
];
