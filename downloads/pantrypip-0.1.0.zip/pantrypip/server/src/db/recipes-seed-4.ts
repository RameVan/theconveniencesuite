// Dutch and European dinners, written for this project.
import type { SeedRecipe } from './recipes-seed.ts';

export const EUROPEAN_RECIPES: SeedRecipe[] = [
  // Dutch
  {
    key: 'boerenkool_stamppot', title: 'Boerenkool stamppot with smoked sausage', summary: 'Kale mashed into potatoes, the Dutch winter classic.',
    cuisine: 'Dutch', tags: ['comfort', 'winter', 'family'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 25, emoji: '🥬', color: '#4F7A3A',
    ingredients: [['potatoes', 1200, '1.2 kg floury potatoes'], ['kale', 500, '500 g curly kale'], ['smoked_sausage', 275, '1 smoked sausage'], ['milk', 150, '150 ml warm milk'], ['butter', 30, '30 g butter'], ['mustard', 10, 'Mustard, to serve'], ['bacon', 100, 'Bacon bits', true]],
    steps: [['Boil the potatoes with the kale on top until soft.', 1200], ['Heat the sausage in hot (not boiling) water.', 900], 'Drain, then mash with butter and milk. Stir in crisp-fried bacon if you like.', 'Serve with sliced sausage and mustard.'],
  },
  {
    key: 'zuurkool_stamppot', title: 'Sauerkraut stamppot with bacon', summary: 'Tangy sauerkraut mash with crisp bacon.',
    cuisine: 'Dutch', tags: ['comfort', 'winter'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 25, emoji: '🥔', color: '#C7B26A',
    ingredients: [['potatoes', 1200, '1.2 kg potatoes'], ['sauerkraut', 500, '500 g sauerkraut'], ['bacon', 150, '150 g bacon bits'], ['milk', 100, '100 ml milk'], ['butter', 20, '20 g butter'], ['smoked_sausage', 275, '1 smoked sausage', true]],
    steps: [['Boil the potatoes until soft.', 1200], ['Heat the sauerkraut with a splash of water.', 600], 'Fry the bacon until crisp.', 'Mash the potatoes with milk and butter, stir through the sauerkraut and bacon.'],
  },
  {
    key: 'andijvie_stamppot', title: 'Endive stamppot with meatballs', summary: 'Raw greens stirred into hot mash with gravy meatballs.',
    cuisine: 'Dutch', tags: ['comfort', 'family'], diet: [], difficulty: 'easy', servings: 4, prep: 20, cook: 25, emoji: '🥔', color: '#8DAE5A',
    ingredients: [['potatoes', 1200, '1.2 kg potatoes'], ['lettuce', 400, '400 g endive (andijvie), finely sliced'], ['minced_beef', 400, '400 g mince'], ['eggs', 1, '1 egg'], ['bread', 35, '1 slice of bread, crumbled'], ['milk', 150, '150 ml milk'], ['butter', 40, '40 g butter'], ['onion', 1, '1 onion']],
    steps: ['Mix mince, egg, breadcrumbs, grated onion, salt and pepper; roll into 4 balls.', ['Brown the meatballs in half the butter, then add a splash of water, cover and simmer.', 1200], ['Boil the potatoes until soft.', 1200], 'Mash with milk and the rest of the butter, stir in the raw endive and serve with the meatballs and pan gravy.'],
  },
  {
    key: 'witlof_ham_kaas', title: 'Baked endive with ham & cheese', summary: 'Belgian endive wrapped in ham under a cheese sauce.',
    cuisine: 'Dutch', tags: ['oven', 'comfort', 'low-carb'], diet: [], difficulty: 'medium', servings: 4, prep: 20, cook: 30, emoji: '🧀', color: '#E2C15A',
    ingredients: [['endive', 750, '6 heads of endive'], ['ham', 90, '6 slices of ham'], ['butter', 30, '30 g butter'], ['flour', 30, '30 g flour'], ['milk', 400, '400 ml milk'], ['cheese', 100, '100 g grated cheese'], ['potatoes', 800, 'Potatoes, to serve', true]],
    steps: [['Simmer the endive for 5 minutes, then drain well.', 300], 'Melt the butter, stir in flour, then whisk in the milk until thick; add half the cheese.', 'Wrap each endive in ham, lay in a dish, pour over the sauce and top with the rest of the cheese.', ['Bake at 200 °C until golden.', 1500]],
  },
  {
    key: 'hachee', title: 'Hachee (Dutch beef & onion stew)', summary: 'Slow-cooked beef with lots of onions and a hint of cloves.',
    cuisine: 'Dutch', tags: ['comfort', 'winter', 'batch-cook', 'freezer-friendly'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 150, emoji: '🍲', color: '#6E3B1F',
    ingredients: [['beef_strips', 600, '600 g stewing beef, in chunks'], ['onion', 4, '4 onions, sliced'], ['butter', 30, '30 g butter'], ['flour', 20, '1 tbsp flour'], ['vinegar', 30, '2 tbsp vinegar'], ['stock_cube', 1, '1 stock cube'], ['potatoes', 1000, '1 kg potatoes'], ['red_cabbage', 0.5, 'Red cabbage, to serve', true]],
    steps: ['Brown the beef in the butter, then dust with flour.', 'Add the onions, vinegar, stock cube and 500 ml water.', ['Simmer, lid on, until the beef falls apart.', 9000], ['Boil the potatoes before serving.', 1200]],
  },
  {
    key: 'rode_kool_appel', title: 'Red cabbage with apple & pork chops', summary: 'Sweet-sour braised cabbage with a seared chop.',
    cuisine: 'Dutch', tags: ['comfort', 'winter'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 45, emoji: '🥩', color: '#7B2D5B',
    ingredients: [['red_cabbage', 1, '1 small red cabbage, shredded'], ['apples', 2, '2 apples, diced'], ['vinegar', 30, '2 tbsp vinegar'], ['sugar', 20, '1½ tbsp sugar'], ['cinnamon', 1, 'A pinch of cinnamon'], ['butter', 30, '30 g butter'], ['pork_chops', 600, '4 pork chops'], ['potatoes', 1000, '1 kg potatoes']],
    steps: [['Braise cabbage, apple, vinegar, sugar, cinnamon and half the butter with a splash of water, lid on.', 2700], ['Boil the potatoes.', 1200], ['Fry the chops in the rest of the butter, 4–5 minutes a side.', 600], 'Serve together.'],
  },
  {
    key: 'bruine_bonen_soep', title: 'Brown bean soup with bacon', summary: 'Thick, smoky Dutch soup that fills you up.',
    cuisine: 'Dutch', tags: ['soup', 'winter', 'budget'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 30, emoji: '🍲', color: '#7A4E2D',
    ingredients: [['brown_beans', 800, '2 jars brown beans'], ['bacon', 150, '150 g bacon bits'], ['onion', 1, '1 onion'], ['carrots', 150, '2 carrots'], ['celery', 0.25, '2 sticks of celery'], ['stock_cube', 2, '2 stock cubes'], ['curry_powder', 3, '1 tsp curry powder'], ['bread', 140, 'Bread, to serve', true]],
    steps: ['Fry the bacon, then add onion, carrot and celery for 5 minutes.', ['Add the beans, curry powder, stock cubes and 1 litre water; simmer.', 1200], 'Blend half the soup and stir back in. Season.'],
  },
  {
    key: 'erwtensoep', title: 'Erwtensoep (split pea style)', summary: 'Thick pea soup with sausage, the quick way with frozen peas.',
    cuisine: 'Dutch', tags: ['soup', 'winter', 'batch-cook'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 40, emoji: '🫛', color: '#7FA03F',
    ingredients: [['frozen_peas', 900, '900 g frozen peas'], ['potatoes', 300, '2 potatoes, diced'], ['leek', 1, '1 leek'], ['carrots', 150, '2 carrots'], ['celery', 0.25, '2 sticks of celery'], ['onion', 1, '1 onion'], ['stock_cube', 2, '2 stock cubes'], ['smoked_sausage', 275, '1 smoked sausage'], ['bacon', 100, '100 g bacon', true]],
    steps: ['Soften the onion, leek, carrot and celery (and bacon) for 8 minutes.', ['Add potatoes, peas, stock cubes and 1.2 litres water; simmer.', 1800], 'Blend until thick, then slice the sausage in and warm through.'],
  },
  {
    key: 'kapsalon', title: 'Homemade kapsalon', summary: 'Fries, spiced chicken, melted cheese and salad in one tray.',
    cuisine: 'Dutch', tags: ['weekend', 'family', 'oven'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 35, emoji: '🍟', color: '#D9902E',
    ingredients: [['potatoes', 1000, '1 kg potatoes, in fries'], ['chicken_thigh', 500, '500 g chicken thigh, in strips'], ['paprika_powder', 5, '2 tsp paprika'], ['cumin', 3, '1 tsp cumin'], ['cheese', 150, '150 g grated cheese'], ['lettuce', 100, 'Lettuce'], ['cucumber', 0.5, '½ cucumber'], ['yoghurt', 100, 'Garlic yoghurt sauce'], ['garlic', 1, '1 garlic clove'], ['sunflower_oil', 30, '2 tbsp oil'], ['sambal', 10, 'Sambal', true]],
    steps: [['Toss the fries with half the oil and bake at 220 °C until crisp.', 1800], ['Fry the chicken with the spices in the rest of the oil.', 600], ['Pile chicken and cheese on the fries and bake until melted.', 300], 'Top with lettuce, cucumber, garlic yoghurt and sambal.'],
  },
  {
    key: 'babi_ketjap', title: 'Babi ketjap style pork', summary: 'Sweet soy-braised pork with rice and cucumber.',
    cuisine: 'Indonesian', tags: ['family'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 45, emoji: '🍖', color: '#5A3420',
    ingredients: [['pork_tenderloin', 500, '500 g pork, in cubes'], ['soy_sauce', 60, '4 tbsp sweet soy sauce'], ['onion', 1, '1 onion'], ['garlic', 2, '2 garlic cloves'], ['ginger', 10, 'Ginger'], ['tomato_paste', 30, '2 tbsp tomato paste'], ['sambal', 10, '1 tsp sambal'], ['rice', 300, '300 g rice'], ['cucumber', 1, '1 cucumber'], ['sunflower_oil', 15, '1 tbsp oil']],
    steps: ['Brown the pork in the oil, then add onion, garlic and ginger.', ['Add soy sauce, tomato paste, sambal and 250 ml water; simmer until tender and sticky.', 2400], ['Cook the rice.', 720], 'Serve with rice and cucumber.'],
  },
  {
    key: 'gehaktballen_jus', title: 'Meatballs in gravy with green beans', summary: 'Sunday-style meatballs, any day of the week.',
    cuisine: 'Dutch', tags: ['family', 'comfort'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 30, emoji: '🧆', color: '#7B4A2A',
    ingredients: [['minced_beef', 500, '500 g mince'], ['eggs', 1, '1 egg'], ['bread', 35, '1 slice of bread'], ['onion', 1, '1 onion'], ['butter', 50, '50 g butter'], ['green_beans', 500, '500 g green beans'], ['potatoes', 1000, '1 kg potatoes']],
    steps: ['Mix mince, egg, crumbled bread and grated onion with salt and pepper; shape 8 balls.', ['Brown the balls in the butter, add 150 ml water, cover and simmer.', 1500], ['Boil the potatoes and beans.', 1200], 'Serve with the gravy from the pan.'],
  },
  {
    key: 'vispakketje', title: 'Fish parcels with leek & lemon', summary: 'Steamed in paper: tender fish, no smell.',
    cuisine: 'Dutch', tags: ['fish', 'quick', 'low-carb', 'high-protein'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 20, emoji: '🐟', color: '#7EB6C9',
    ingredients: [['white_fish', 500, '4 white fish fillets'], ['leek', 1, '1 leek, thinly sliced'], ['carrots', 150, '2 carrots, in thin strips'], ['lemon', 1, '1 lemon'], ['butter', 20, '20 g butter'], ['dill', 5, 'Dill'], ['potatoes', 800, 'Potatoes, to serve', true]],
    steps: ['Heat the oven to 200 °C.', 'Divide leek and carrot over 4 sheets of baking paper, top with fish, lemon slices, a little butter and dill. Fold shut.', ['Bake until the fish flakes.', 1200]],
  },
  {
    key: 'pumpkin_soup', title: 'Roasted pumpkin soup', summary: 'Velvety, sweet and warming.',
    cuisine: 'European', tags: ['soup', 'autumn', 'batch-cook', 'freezer-friendly'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 40, emoji: '🎃', color: '#E6862E',
    ingredients: [['pumpkin', 1, '1 butternut squash, in chunks'], ['onion', 1, '1 onion'], ['garlic', 2, '2 garlic cloves'], ['carrots', 150, '2 carrots'], ['stock_cube', 2, '2 stock cubes'], ['olive_oil', 20, 'Olive oil'], ['creme_fraiche', 60, 'Crème fraîche, to serve', true], ['bread', 140, 'Bread, to serve', true]],
    steps: [['Roast squash, onion, carrot and garlic with the oil at 200 °C.', 1800], ['Add to a pan with stock cubes and 900 ml water; simmer.', 600], 'Blend until smooth and season.'],
  },

  // Italian
  {
    key: 'lasagne_classic', title: 'Classic lasagne', summary: 'Layers of ragù, pasta and cheese sauce.',
    cuisine: 'Italian', tags: ['family', 'weekend', 'oven', 'freezer-friendly'], diet: [], difficulty: 'medium', servings: 6, prep: 30, cook: 60, emoji: '🍝', color: '#B8432F',
    ingredients: [['lasagne', 250, '250 g lasagne sheets'], ['minced_beef', 500, '500 g mince'], ['onion', 1, '1 onion'], ['carrots', 100, '1 carrot'], ['garlic', 2, '2 garlic cloves'], ['passata', 500, '500 g passata'], ['canned_tomatoes', 400, '1 tin chopped tomatoes'], ['oregano', 2, '1 tsp oregano'], ['butter', 40, '40 g butter'], ['flour', 40, '40 g flour'], ['milk', 600, '600 ml milk'], ['cheese', 100, '100 g grated cheese']],
    steps: ['Brown the mince with onion, carrot and garlic.', ['Add passata, tomatoes and oregano and simmer.', 1200], 'For the sauce, melt the butter, stir in the flour and whisk in the milk until thick.', 'Layer ragù, pasta and sauce three times, finishing with sauce and cheese.', ['Bake at 190 °C until golden and bubbling.', 2400]],
  },
  {
    key: 'veggie_lasagne', title: 'Spinach & ricotta-style vegetable lasagne', summary: 'Courgette, spinach and cottage cheese layers.',
    cuisine: 'Italian', tags: ['oven', 'family'], diet: [], difficulty: 'medium', servings: 6, prep: 25, cook: 45, emoji: '🥬', color: '#5C8A3A',
    ingredients: [['lasagne', 250, '250 g lasagne sheets'], ['frozen_spinach', 450, '450 g frozen spinach, thawed'], ['cottage_cheese', 400, '400 g cottage cheese'], ['zucchini', 2, '2 courgettes'], ['passata', 500, '500 g passata'], ['garlic', 2, '2 garlic cloves'], ['mozzarella', 125, '1 ball of mozzarella'], ['parmesan', 30, '30 g parmesan'], ['olive_oil', 15, 'Olive oil']],
    steps: ['Fry the sliced courgette and garlic in the oil for 5 minutes, then stir in the passata.', 'Squeeze the spinach dry and mix with cottage cheese and parmesan.', 'Layer tomato, pasta and spinach mix three times; finish with tomato and torn mozzarella.', ['Bake at 190 °C.', 2400]],
  },
  {
    key: 'gnocchi_tomato_mozzarella', title: 'Baked gnocchi with tomato & mozzarella', summary: 'A bubbling one-dish dinner in 25 minutes.',
    cuisine: 'Italian', tags: ['quick', 'family', 'oven'], diet: [], difficulty: 'easy', servings: 4, prep: 5, cook: 20, emoji: '🧀', color: '#C9483A',
    ingredients: [['gnocchi', 1000, '2 packs of gnocchi'], ['passata', 500, '500 g passata'], ['garlic', 2, '2 garlic cloves'], ['mozzarella', 250, '2 balls of mozzarella'], ['basil', 10, 'Basil'], ['spinach', 150, '150 g spinach', true], ['olive_oil', 15, 'Olive oil']],
    steps: ['Warm the garlic in the oil, add passata (and spinach) and simmer 5 minutes.', 'Stir in the raw gnocchi and pour into a dish.', ['Top with torn mozzarella and bake at 220 °C until bubbling.', 1200], 'Finish with basil.'],
  },
  {
    key: 'gnocchi_pesto_beans', title: 'Crispy gnocchi with pesto & green beans', summary: 'Pan-fried gnocchi, no boiling needed.',
    cuisine: 'Italian', tags: ['quick'], diet: [], difficulty: 'easy', servings: 3, prep: 5, cook: 15, emoji: '🌿', color: '#5F9341',
    ingredients: [['gnocchi', 500, '500 g gnocchi'], ['green_beans', 250, '250 g green beans'], ['pesto', 90, '90 g pesto'], ['cherry_tomatoes', 200, '200 g cherry tomatoes'], ['parmesan', 20, 'Parmesan'], ['olive_oil', 20, 'Olive oil']],
    steps: [['Blanch the beans.', 240], ['Fry the gnocchi in the oil until golden on all sides.', 480], 'Add beans and tomatoes for 2 minutes, then stir in the pesto. Top with parmesan.'],
  },
  {
    key: 'pasta_puttanesca', title: 'Pasta puttanesca', summary: 'Tomato, olives and chilli: big flavour from the cupboard.',
    cuisine: 'Italian', tags: ['pasta', 'quick', 'budget'], diet: [], difficulty: 'easy', servings: 4, prep: 5, cook: 15, emoji: '🍝', color: '#A8322D',
    ingredients: [['pasta', 400, '400 g spaghetti'], ['canned_tomatoes', 400, '1 tin chopped tomatoes'], ['olives', 80, '80 g black olives'], ['garlic', 3, '3 garlic cloves'], ['chili', 1, '1 chilli'], ['tuna', 145, '1 tin tuna', true], ['parsley', 10, 'Parsley'], ['olive_oil', 30, '2 tbsp olive oil']],
    steps: [['Cook the pasta.', 600], 'Warm garlic and chilli in the oil, add tomatoes and olives (and tuna), simmer 10 minutes.', 'Toss with the pasta and parsley.'],
  },
  {
    key: 'pasta_alla_norma', title: 'Pasta alla Norma', summary: 'Silky fried aubergine in tomato sauce.',
    cuisine: 'Italian', tags: ['pasta'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 25, emoji: '🍆', color: '#6B3A6E',
    ingredients: [['pasta', 400, '400 g pasta'], ['aubergine', 2, '2 aubergines, diced'], ['canned_tomatoes', 400, '1 tin chopped tomatoes'], ['garlic', 2, '2 garlic cloves'], ['basil', 10, 'Basil'], ['olive_oil', 45, '3 tbsp olive oil'], ['parmesan', 30, 'Parmesan or ricotta-style cheese']],
    steps: [['Fry the aubergine in the oil until soft and golden.', 600], ['Add garlic, then tomatoes; simmer.', 600], ['Cook the pasta.', 600], 'Toss together with basil and cheese.'],
  },
  {
    key: 'creamy_salmon_pasta', title: 'Creamy salmon & spinach pasta', summary: 'Ready in the time it takes to boil pasta.',
    cuisine: 'Italian', tags: ['pasta', 'quick', 'fish'], diet: [], difficulty: 'easy', servings: 4, prep: 5, cook: 12, emoji: '🍝', color: '#F08A6B',
    ingredients: [['pasta', 400, '400 g pasta'], ['salmon', 250, '2 salmon fillets'], ['spinach', 150, '150 g spinach'], ['cream', 200, '200 ml cream'], ['lemon', 1, '1 lemon'], ['garlic', 1, '1 garlic clove'], ['dill', 5, 'Dill', true]],
    steps: [['Cook the pasta.', 600], ['Pan-fry the salmon, then flake it.', 480], 'Warm cream, garlic and lemon zest; add spinach, salmon and the pasta with a splash of pasta water.'],
  },
  {
    key: 'chicken_cacciatore', title: 'Chicken cacciatore', summary: 'Hunter-style chicken braised with peppers and tomato.',
    cuisine: 'Italian', tags: ['one-pan', 'family'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 40, emoji: '🍗', color: '#A63D2A',
    ingredients: [['chicken_thigh', 700, '700 g chicken thighs'], ['bell_pepper', 2, '2 peppers'], ['onion', 1, '1 onion'], ['mushrooms', 200, '200 g mushrooms'], ['garlic', 2, '2 garlic cloves'], ['canned_tomatoes', 400, '1 tin chopped tomatoes'], ['olives', 50, 'Olives', true], ['oregano', 2, '1 tsp oregano'], ['olive_oil', 15, 'Olive oil'], ['bread', 140, 'Bread or pasta, to serve', true]],
    steps: ['Brown the chicken in the oil, then set aside.', 'Fry onion, peppers, mushrooms and garlic for 5 minutes.', ['Return the chicken with tomatoes, oregano and olives; simmer, lid on.', 1800]],
  },
  {
    key: 'risotto_pea_lemon', title: 'Pea & lemon risotto', summary: 'Bright, creamy and green.',
    cuisine: 'Italian', tags: ['comfort'], diet: [], difficulty: 'medium', servings: 4, prep: 5, cook: 25, emoji: '🍚', color: '#9CC25A',
    ingredients: [['rice', 300, '300 g risotto rice'], ['frozen_peas', 300, '300 g peas'], ['onion', 1, '1 onion'], ['stock_cube', 2, '2 stock cubes'], ['butter', 30, '30 g butter'], ['parmesan', 40, '40 g parmesan'], ['lemon', 1, '1 lemon'], ['mint', 5, 'Mint', true]],
    steps: ['Soften the onion in half the butter, then stir in the rice.', ['Add 1.1 litres hot stock a ladle at a time, stirring, until creamy.', 1200], ['Stir in the peas for the last 3 minutes.', 180], 'Finish with butter, parmesan, lemon zest and juice.'],
  },
  {
    key: 'minestrone_beans', title: 'White bean & kale soup', summary: 'A Tuscan-style soup that gets better the next day.',
    cuisine: 'Italian', tags: ['soup', 'batch-cook', 'budget'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 30, emoji: '🍲', color: '#7E9B54',
    ingredients: [['white_beans', 480, '2 tins white beans'], ['kale', 200, '200 g kale'], ['onion', 1, '1 onion'], ['carrots', 150, '2 carrots'], ['celery', 0.25, '2 sticks of celery'], ['garlic', 2, '2 garlic cloves'], ['canned_tomatoes', 400, '1 tin tomatoes'], ['stock_cube', 2, '2 stock cubes'], ['olive_oil', 30, 'Olive oil'], ['parmesan', 20, 'Parmesan', true]],
    steps: ['Soften onion, carrot, celery and garlic in the oil for 8 minutes.', ['Add tomatoes, beans, stock and 1 litre water; simmer.', 1200], ['Add the kale and cook until tender.', 300], 'Serve with parmesan and a drizzle of oil.'],
  },
  {
    key: 'pizza_flatbread', title: 'Quick flatbread pizzas', summary: 'Wraps as crispy pizza bases, ready in 10 minutes.',
    cuisine: 'Italian', tags: ['quick', 'family'], diet: [], difficulty: 'easy', servings: 2, prep: 5, cook: 8, emoji: '🍕', color: '#D9483B',
    ingredients: [['wraps', 4, '4 wraps'], ['passata', 150, '150 g passata'], ['mozzarella', 125, '1 ball of mozzarella'], ['oregano', 1, 'Oregano'], ['ham', 60, 'Ham', true], ['mushrooms', 100, 'Mushrooms', true], ['rocket', 30, 'Rocket', true]],
    steps: ['Heat the oven to 220 °C.', 'Spread the wraps with passata, top with mozzarella, oregano and toppings.', ['Bake on a tray until crisp.', 480], 'Finish with rocket.'],
  },

  // French, Spanish & Greek
  {
    key: 'ratatouille', title: 'Ratatouille', summary: 'Slow-cooked summer vegetables in olive oil.',
    cuisine: 'French', tags: ['batch-cook', 'low-carb'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 40, emoji: '🍆', color: '#B5452E',
    ingredients: [['aubergine', 1, '1 aubergine'], ['zucchini', 2, '2 courgettes'], ['bell_pepper', 2, '2 peppers'], ['onion', 1, '1 onion'], ['garlic', 3, '3 garlic cloves'], ['canned_tomatoes', 400, '1 tin tomatoes'], ['oregano', 2, '1 tsp dried herbs'], ['olive_oil', 45, '3 tbsp olive oil'], ['basil', 10, 'Basil'], ['bread', 140, 'Bread, to serve', true]],
    steps: ['Cut all the vegetables into chunks.', ['Soften onion and garlic in the oil, add the rest of the vegetables and fry for 10 minutes.', 600], ['Add tomatoes and herbs, simmer until soft.', 1800], 'Finish with basil.'],
  },
  {
    key: 'quiche_lorraine', title: 'Leek & bacon quiche', summary: 'Puff pastry, creamy eggs, smoky bacon.',
    cuisine: 'French', tags: ['oven', 'weekend'], diet: [], difficulty: 'medium', servings: 6, prep: 15, cook: 35, emoji: '🥧', color: '#E0B04F',
    ingredients: [['puff_pastry', 300, '4 sheets of puff pastry'], ['bacon', 150, '150 g bacon bits'], ['leek', 1, '1 leek'], ['eggs', 4, '4 eggs'], ['cream', 200, '200 ml cream'], ['cheese', 100, '100 g grated cheese'], ['lettuce', 100, 'Salad, to serve', true]],
    steps: ['Heat the oven to 200 °C and line a tin with the pastry.', 'Fry the bacon and leek for 6 minutes.', 'Whisk eggs, cream and cheese; add the leek and bacon and pour into the case.', ['Bake until set and golden.', 2100]],
  },
  {
    key: 'veggie_quiche', title: 'Spinach & feta quiche', summary: 'A vegetarian quiche that’s good warm or cold.',
    cuisine: 'French', tags: ['oven', 'meal-prep'], diet: [], difficulty: 'medium', servings: 6, prep: 15, cook: 35, emoji: '🥧', color: '#6E9C4A',
    ingredients: [['puff_pastry', 300, '4 sheets of puff pastry'], ['spinach', 300, '300 g spinach'], ['feta', 150, '150 g feta'], ['eggs', 4, '4 eggs'], ['milk', 200, '200 ml milk'], ['red_onion', 1, '1 red onion'], ['cherry_tomatoes', 150, 'Cherry tomatoes']],
    steps: ['Heat the oven to 200 °C and line a tin with the pastry.', 'Wilt the spinach and squeeze dry; soften the onion.', 'Whisk eggs and milk, stir in spinach, onion and crumbled feta; pour into the case and dot with tomatoes.', ['Bake until set.', 2100]],
  },
  {
    key: 'spanish_chorizo_potatoes', title: 'Chorizo, potato & pepper traybake', summary: 'Paprika-red potatoes with crispy chorizo.',
    cuisine: 'Spanish', tags: ['traybake', 'one-pan'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 40, emoji: '🥔', color: '#C2452D',
    ingredients: [['potatoes', 900, '900 g potatoes, in chunks'], ['chorizo', 150, '150 g chorizo, sliced'], ['bell_pepper', 2, '2 peppers'], ['red_onion', 2, '2 red onions'], ['paprika_powder', 5, '2 tsp smoked paprika'], ['olive_oil', 30, '2 tbsp olive oil'], ['eggs', 4, '4 eggs', true], ['parsley', 10, 'Parsley']],
    steps: [['Toss potatoes with oil and paprika and roast at 210 °C.', 1200], ['Add peppers, onion and chorizo; roast until crisp.', 1200], ['Crack in the eggs if you like and bake until set.', 360], 'Scatter with parsley.'],
  },
  {
    key: 'paella_style_rice', title: 'Chicken & chorizo paella-style rice', summary: 'Saffron-free weeknight paella in one pan.',
    cuisine: 'Spanish', tags: ['one-pan', 'family'], diet: [], difficulty: 'medium', servings: 4, prep: 10, cook: 35, emoji: '🥘', color: '#E0A030',
    ingredients: [['rice', 300, '300 g rice'], ['chicken_thigh', 400, '400 g chicken thigh'], ['chorizo', 100, '100 g chorizo'], ['bell_pepper', 1, '1 pepper'], ['onion', 1, '1 onion'], ['garlic', 2, '2 garlic cloves'], ['canned_tomatoes', 200, '½ tin tomatoes'], ['paprika_powder', 5, '2 tsp paprika'], ['stock_cube', 2, '2 stock cubes'], ['frozen_peas', 150, '150 g peas'], ['lemon', 1, '1 lemon'], ['shrimp', 150, '150 g shrimp', true]],
    steps: ['Brown chicken and chorizo in a wide pan.', 'Add onion, pepper and garlic for 5 minutes, then rice, paprika and tomatoes.', ['Pour in 800 ml stock and simmer without stirring.', 1200], ['Scatter over peas (and shrimp) for the last minutes.', 300], 'Serve with lemon wedges.'],
  },
  {
    key: 'greek_moussaka_light', title: 'Moussaka', summary: 'Aubergine, spiced mince and a golden yoghurt topping.',
    cuisine: 'Greek', tags: ['oven', 'weekend'], diet: [], difficulty: 'medium', servings: 6, prep: 30, cook: 60, emoji: '🍆', color: '#8C4A3A',
    ingredients: [['aubergine', 3, '3 aubergines'], ['minced_beef', 500, '500 g mince'], ['onion', 1, '1 onion'], ['garlic', 2, '2 garlic cloves'], ['canned_tomatoes', 400, '1 tin tomatoes'], ['cinnamon', 2, '1 tsp cinnamon'], ['oregano', 2, '1 tsp oregano'], ['yoghurt', 400, '400 g Greek yoghurt'], ['eggs', 2, '2 eggs'], ['parmesan', 40, '40 g parmesan'], ['olive_oil', 45, 'Olive oil']],
    steps: [['Slice the aubergines, brush with oil and roast at 200 °C.', 1200], ['Brown the mince with onion and garlic; add tomatoes, cinnamon and oregano and simmer.', 1200], 'Whisk yoghurt, eggs and half the parmesan.', 'Layer aubergine and mince in a dish; top with the yoghurt and remaining cheese.', ['Bake until golden.', 1800]],
  },
  {
    key: 'souvlaki_pita', title: 'Chicken souvlaki pitas with tzatziki', summary: 'Lemon-oregano chicken, cool tzatziki, warm pita.',
    cuisine: 'Greek', tags: ['family', 'high-protein'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 15, emoji: '🥙', color: '#4A90A4',
    ingredients: [['chicken_breast', 600, '600 g chicken breast, in cubes'], ['lemon', 1, '1 lemon'], ['oregano', 3, '1 tbsp oregano'], ['garlic', 3, '3 garlic cloves'], ['olive_oil', 30, '2 tbsp olive oil'], ['yoghurt', 250, '250 g Greek yoghurt'], ['cucumber', 1, '1 cucumber'], ['pita', 4, '4 pitas'], ['tomatoes', 2, '2 tomatoes'], ['red_onion', 1, '1 red onion']],
    steps: ['Marinate the chicken in oil, lemon juice, oregano and 2 garlic cloves for 10 minutes.', 'Grate half the cucumber, squeeze dry and stir into the yoghurt with the last garlic clove.', ['Fry or grill the chicken until cooked.', 600], 'Fill warm pitas with chicken, tzatziki, tomato, onion and cucumber.'],
  },
  {
    key: 'greek_baked_beans', title: 'Greek baked white beans (gigantes)', summary: 'Beans baked in a herby tomato sauce with feta.',
    cuisine: 'Greek', tags: ['oven', 'budget', 'batch-cook'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 40, emoji: '🫘', color: '#C5513A',
    ingredients: [['white_beans', 720, '3 tins white beans'], ['onion', 1, '1 onion'], ['garlic', 3, '3 garlic cloves'], ['carrots', 100, '1 carrot'], ['passata', 500, '500 g passata'], ['oregano', 2, '1 tsp oregano'], ['dill', 5, 'Dill'], ['feta', 100, '100 g feta'], ['olive_oil', 45, '3 tbsp olive oil'], ['bread', 140, 'Bread, to serve', true]],
    steps: ['Soften onion, garlic and carrot in the oil.', 'Add passata, oregano and the beans; pour into a dish.', ['Bake at 190 °C until thick and bubbling.', 1800], 'Top with crumbled feta and dill.'],
  },
  {
    key: 'fish_chips_oven', title: 'Oven fish & chips with peas', summary: 'Crispy crumbed fish and oven chips, no deep fryer.',
    cuisine: 'British', tags: ['fish', 'family', 'oven'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 35, emoji: '🐟', color: '#D9A646',
    ingredients: [['white_fish', 500, '4 white fish fillets'], ['potatoes', 1000, '1 kg potatoes'], ['bread', 70, '2 slices of bread, as crumbs'], ['eggs', 1, '1 egg'], ['flour', 30, '2 tbsp flour'], ['frozen_peas', 300, '300 g peas'], ['lemon', 1, '1 lemon'], ['sunflower_oil', 30, '2 tbsp oil'], ['mayonnaise', 40, 'Mayonnaise or tartare', true]],
    steps: [['Cut the potatoes into chips, toss with oil and bake at 220 °C.', 2100], 'Dip the fish in flour, beaten egg and breadcrumbs.', ['Add the fish to the oven for the last part.', 900], ['Cook the peas and lightly crush them.', 300], 'Serve with lemon.'],
  },
  {
    key: 'shepherds_pie', title: 'Cottage pie', summary: 'Savoury mince under fluffy mash.',
    cuisine: 'British', tags: ['comfort', 'family', 'freezer-friendly', 'oven'], diet: [], difficulty: 'easy', servings: 6, prep: 20, cook: 45, emoji: '🥧', color: '#A0663A',
    ingredients: [['minced_beef', 500, '500 g mince'], ['onion', 1, '1 onion'], ['carrots', 200, '2 carrots'], ['frozen_peas', 150, '150 g peas'], ['tomato_paste', 30, '2 tbsp tomato paste'], ['stock_cube', 1, '1 stock cube'], ['potatoes', 1200, '1.2 kg potatoes'], ['milk', 100, '100 ml milk'], ['butter', 30, '30 g butter'], ['cheese', 60, '60 g cheese', true]],
    steps: ['Brown the mince with onion and carrot, stir in tomato paste.', ['Add stock and 250 ml water and simmer; add the peas at the end.', 1200], ['Boil the potatoes and mash with milk and butter.', 1200], ['Top the mince with the mash (and cheese) and bake at 200 °C.', 1500]],
  },
  {
    key: 'goulash', title: 'Hungarian-style goulash', summary: 'Paprika beef stew with peppers.',
    cuisine: 'Hungarian', tags: ['comfort', 'winter', 'batch-cook', 'freezer-friendly'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 120, emoji: '🍲', color: '#9E2F1F',
    ingredients: [['beef_strips', 600, '600 g stewing beef'], ['onion', 2, '2 onions'], ['bell_pepper', 2, '2 peppers'], ['garlic', 2, '2 garlic cloves'], ['paprika_powder', 10, '1½ tbsp paprika'], ['tomato_paste', 30, '2 tbsp tomato paste'], ['stock_cube', 1, '1 stock cube'], ['potatoes', 500, '500 g potatoes'], ['sunflower_oil', 20, 'Oil'], ['creme_fraiche', 60, 'Crème fraîche', true]],
    steps: ['Brown the beef in the oil, then add onions and garlic.', 'Stir in paprika and tomato paste, then 600 ml water and the stock cube.', ['Simmer, lid on.', 5400], ['Add the peppers and potato chunks and cook until tender.', 1800]],
  },
  {
    key: 'pork_mustard_cream', title: 'Pork tenderloin with mustard cream sauce', summary: 'Tender pork medallions in a quick pan sauce.',
    cuisine: 'French', tags: ['quick', 'high-protein'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 20, emoji: '🥩', color: '#C7A04A',
    ingredients: [['pork_tenderloin', 500, '500 g pork tenderloin'], ['mustard', 30, '2 tbsp mustard'], ['cream', 200, '200 ml cream'], ['mushrooms', 250, '250 g mushrooms'], ['onion', 1, '1 onion'], ['butter', 20, '20 g butter'], ['green_beans', 400, '400 g green beans'], ['potatoes', 800, '800 g potatoes']],
    steps: [['Boil the potatoes and beans.', 1200], ['Slice the pork into medallions and fry in butter, 3 minutes a side, then rest.', 360], 'Fry onion and mushrooms in the same pan, then stir in cream and mustard.', 'Return the pork to warm through.'],
  },
];
