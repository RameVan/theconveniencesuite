// Dinners from around the world, written for this project.
import type { SeedRecipe } from './recipes-seed.ts';

export const WORLD_RECIPES: SeedRecipe[] = [
  // Asian
  {
    key: 'beef_broccoli', title: 'Beef & broccoli stir-fry', summary: 'Takeaway-style, glossy and fast.',
    cuisine: 'Chinese', tags: ['quick', 'high-protein', 'stir-fry'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 12, emoji: '🥦', color: '#3E6B35',
    ingredients: [['beef_strips', 400, '400 g beef strips'], ['broccoli', 400, '1 head of broccoli'], ['soy_sauce', 45, '3 tbsp soy sauce'], ['honey', 15, '1 tbsp honey'], ['garlic', 2, '2 garlic cloves'], ['ginger', 10, 'Ginger'], ['flour', 10, '2 tsp cornflour or flour'], ['sunflower_oil', 20, 'Oil'], ['rice', 300, '300 g rice']],
    steps: [['Cook the rice.', 720], ['Stir-fry the beef in hot oil in two batches, then set aside.', 240], ['Stir-fry the broccoli with garlic and ginger and a splash of water.', 240], 'Mix soy, honey, flour and 4 tbsp water; add with the beef and toss until glossy.'],
  },
  {
    key: 'kung_pao_chicken', title: 'Kung pao-style chicken', summary: 'Sticky, nutty and a little spicy.',
    cuisine: 'Chinese', tags: ['quick', 'stir-fry'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 12, emoji: '🌶️', color: '#B43B2A',
    ingredients: [['chicken_thigh', 500, '500 g chicken thigh, diced'], ['bell_pepper', 1, '1 pepper'], ['spring_onion', 4, '4 spring onions'], ['nuts', 60, '60 g peanuts or cashews'], ['soy_sauce', 45, '3 tbsp soy sauce'], ['vinegar', 15, '1 tbsp vinegar'], ['honey', 15, '1 tbsp honey'], ['chili', 2, '2 dried or fresh chillies'], ['garlic', 2, '2 garlic cloves'], ['sunflower_oil', 20, 'Oil'], ['rice', 300, '300 g rice']],
    steps: [['Cook the rice.', 720], ['Fry the chicken until golden.', 360], 'Add pepper, chilli, garlic and spring onion for 2 minutes.', 'Stir in soy, vinegar and honey until sticky, then the nuts.'],
  },
  {
    key: 'sweet_sour_chicken', title: 'Sweet & sour chicken', summary: 'Pineapple-free and still tangy.',
    cuisine: 'Chinese', tags: ['family', 'quick'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 15, emoji: '🍗', color: '#E2622D',
    ingredients: [['chicken_breast', 500, '500 g chicken breast'], ['bell_pepper', 2, '2 peppers'], ['onion', 1, '1 onion'], ['ketchup', 60, '4 tbsp ketchup'], ['vinegar', 30, '2 tbsp vinegar'], ['sugar', 20, '1½ tbsp sugar'], ['soy_sauce', 15, '1 tbsp soy sauce'], ['flour', 20, '2 tbsp cornflour'], ['sunflower_oil', 30, 'Oil'], ['rice', 300, '300 g rice']],
    steps: [['Cook the rice.', 720], ['Toss the chicken in flour and fry until crisp.', 480], ['Fry the pepper and onion.', 180], 'Add ketchup, vinegar, sugar, soy and 4 tbsp water; toss the chicken through.'],
  },
  {
    key: 'chow_mein', title: 'Vegetable chow mein', summary: 'Noodles, crunchy veg and soy in one wok.',
    cuisine: 'Chinese', tags: ['quick', 'noodles'], diet: [], difficulty: 'easy', servings: 3, prep: 10, cook: 10, emoji: '🍜', color: '#B07A3A',
    ingredients: [['noodles', 250, '250 g noodles'], ['cabbage', 0.25, '¼ pointed cabbage'], ['carrots', 100, '1 carrot'], ['mushrooms', 150, '150 g mushrooms'], ['spring_onion', 3, '3 spring onions'], ['soy_sauce', 45, '3 tbsp soy sauce'], ['garlic', 2, '2 garlic cloves'], ['sunflower_oil', 20, 'Oil'], ['eggs', 2, '2 eggs', true]],
    steps: [['Cook the noodles and drain.', 240], ['Stir-fry the shredded vegetables and garlic.', 240], 'Add noodles and soy sauce and toss on high heat. Push aside to scramble the eggs if using.'],
  },
  {
    key: 'teriyaki_tofu_bowl', title: 'Teriyaki tofu rice bowls', summary: 'Crispy tofu, sticky sauce, crunchy veg.',
    cuisine: 'Japanese', tags: ['bowl', 'quick'], diet: [], difficulty: 'easy', servings: 3, prep: 10, cook: 15, emoji: '🍱', color: '#7A5230',
    ingredients: [['tofu', 400, '400 g firm tofu'], ['soy_sauce', 45, '3 tbsp soy sauce'], ['honey', 20, '1 tbsp honey or sugar'], ['ginger', 10, 'Ginger'], ['rice', 225, '225 g rice'], ['cucumber', 1, '1 cucumber'], ['carrots', 100, '1 carrot'], ['spring_onion', 2, '2 spring onions'], ['flour', 15, '1 tbsp cornflour'], ['sunflower_oil', 20, 'Oil']],
    steps: [['Cook the rice.', 720], ['Dust tofu cubes in flour and fry until crisp.', 600], 'Add soy, honey, ginger and 3 tbsp water and toss until sticky.', 'Serve on rice with ribboned cucumber and carrot, topped with spring onion.'],
  },
  {
    key: 'katsu_curry', title: 'Chicken katsu curry', summary: 'Crispy chicken with a mild, sweet curry sauce.',
    cuisine: 'Japanese', tags: ['family', 'weekend'], diet: [], difficulty: 'medium', servings: 4, prep: 20, cook: 30, emoji: '🍛', color: '#C98F2B',
    ingredients: [['chicken_breast', 500, '4 small chicken breasts'], ['bread', 105, '3 slices of bread, as crumbs'], ['eggs', 1, '1 egg'], ['flour', 50, 'Flour'], ['onion', 1, '1 onion'], ['carrots', 150, '2 carrots'], ['curry_powder', 10, '1 tbsp curry powder'], ['honey', 10, '2 tsp honey'], ['soy_sauce', 15, '1 tbsp soy'], ['stock_cube', 1, '1 stock cube'], ['sunflower_oil', 40, 'Oil'], ['rice', 300, '300 g rice']],
    steps: [['Cook the rice.', 720], 'Soften onion and carrot, stir in 1 tbsp flour and the curry powder, then 400 ml stock, honey and soy. Simmer and blend.', 'Flatten the chicken, coat in flour, egg and crumbs.', ['Shallow-fry until golden and cooked.', 600], 'Slice and serve with rice and sauce.'],
  },
  {
    key: 'chicken_noodle_soup', title: 'Quick chicken noodle soup (ramen-style)', summary: 'A gingery broth with noodles and a soft egg.',
    cuisine: 'Japanese', tags: ['soup', 'noodles', 'comfort'], diet: [], difficulty: 'easy', servings: 2, prep: 10, cook: 15, emoji: '🍜', color: '#D9A35B',
    ingredients: [['noodles', 150, '150 g noodles'], ['chicken_breast', 200, '1 chicken breast'], ['stock_cube', 2, '2 stock cubes'], ['soy_sauce', 30, '2 tbsp soy sauce'], ['ginger', 15, 'Ginger'], ['garlic', 2, '2 garlic cloves'], ['eggs', 2, '2 eggs'], ['spinach', 80, 'Spinach'], ['spring_onion', 2, '2 spring onions'], ['sambal', 5, 'Chilli', true]],
    steps: [['Simmer 900 ml stock with ginger, garlic and soy; poach the chicken in it.', 900], ['Boil the eggs for 6½ minutes, then cool and halve.', 390], ['Cook the noodles.', 240], 'Slice the chicken; divide noodles, spinach and chicken over bowls and pour over the hot broth. Top with egg and spring onion.'],
  },
  {
    key: 'thai_green_curry', title: 'Thai green chicken curry', summary: 'Fragrant coconut curry with green beans.',
    cuisine: 'Thai', tags: ['curry'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 20, emoji: '🍛', color: '#6A9A3A',
    ingredients: [['chicken_thigh', 500, '500 g chicken thigh'], ['curry_paste', 50, '3 tbsp green curry paste'], ['coconut_milk', 400, '1 tin coconut milk'], ['green_beans', 200, '200 g green beans'], ['zucchini', 1, '1 courgette'], ['lime', 1, '1 lime'], ['basil', 10, 'Basil'], ['soy_sauce', 15, '1 tbsp soy or fish sauce'], ['rice', 300, '300 g rice']],
    steps: [['Cook the rice.', 720], 'Fry the curry paste in a splash of coconut milk for a minute.', ['Add chicken, the rest of the coconut milk and vegetables; simmer.', 900], 'Season with soy and lime and finish with basil.'],
  },
  {
    key: 'pad_thai_style', title: 'Pad thai-style noodles', summary: 'Tangy, sweet and topped with peanuts.',
    cuisine: 'Thai', tags: ['noodles', 'quick'], diet: [], difficulty: 'medium', servings: 3, prep: 10, cook: 10, emoji: '🍜', color: '#D98A3B',
    ingredients: [['noodles', 250, '250 g flat noodles'], ['shrimp', 200, '200 g shrimp or tofu'], ['eggs', 2, '2 eggs'], ['spring_onion', 4, '4 spring onions'], ['nuts', 40, 'Peanuts, chopped'], ['lime', 2, '2 limes'], ['soy_sauce', 30, '2 tbsp soy sauce'], ['sugar', 15, '1 tbsp sugar'], ['ketchup', 15, '1 tbsp ketchup'], ['sunflower_oil', 20, 'Oil'], ['chili', 1, 'Chilli', true]],
    steps: [['Soak or cook the noodles until just soft.', 300], 'Mix soy, sugar, ketchup and the juice of 1 lime.', ['Stir-fry the shrimp, push aside and scramble the eggs.', 240], 'Add noodles, sauce and spring onion and toss. Serve with peanuts and lime.'],
  },
  {
    key: 'thai_basil_mince', title: 'Thai basil mince with rice', summary: 'Pad krapow-style: fast, hot and herby.',
    cuisine: 'Thai', tags: ['quick'], diet: [], difficulty: 'easy', servings: 3, prep: 5, cook: 10, emoji: '🌿', color: '#4D7A2E',
    ingredients: [['minced_beef', 400, '400 g mince'], ['garlic', 3, '3 garlic cloves'], ['chili', 2, '2 chillies'], ['green_beans', 150, '150 g green beans'], ['soy_sauce', 30, '2 tbsp soy sauce'], ['sugar', 5, '1 tsp sugar'], ['basil', 20, 'A big handful of basil'], ['rice', 225, '225 g rice'], ['eggs', 3, 'Fried eggs, to serve', true]],
    steps: [['Cook the rice.', 720], ['Fry garlic and chilli, then the mince until browned.', 360], ['Add beans, soy and sugar for 2 minutes.', 120], 'Stir through the basil and serve on rice with a fried egg.'],
  },
  {
    key: 'tempeh_sambal_goreng', title: 'Sambal goreng tempeh', summary: 'Crispy tempeh in a sweet-spicy glaze.',
    cuisine: 'Indonesian', tags: ['quick'], diet: [], difficulty: 'easy', servings: 3, prep: 10, cook: 15, emoji: '🌶️', color: '#8B3A1E',
    ingredients: [['tempeh', 400, '2 blocks of tempeh'], ['sambal', 20, '1 tbsp sambal'], ['soy_sauce', 45, '3 tbsp sweet soy sauce'], ['onion', 1, '1 onion'], ['garlic', 2, '2 garlic cloves'], ['green_beans', 200, '200 g green beans'], ['sunflower_oil', 30, 'Oil'], ['rice', 225, '225 g rice']],
    steps: [['Cook the rice.', 720], ['Fry thin strips of tempeh in the oil until crisp.', 480], 'Fry onion, garlic and beans for 3 minutes.', 'Add sambal and soy sauce, toss with the tempeh until glazed.'],
  },
  {
    key: 'bami_goreng', title: 'Bami goreng', summary: 'Indonesian fried noodles, a Dutch weeknight staple.',
    cuisine: 'Indonesian', tags: ['family', 'noodles'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 15, emoji: '🍜', color: '#A9672D',
    ingredients: [['noodles', 250, '250 g egg noodles'], ['pork_tenderloin', 300, '300 g pork or chicken'], ['cabbage', 0.25, '¼ pointed cabbage'], ['leek', 1, '1 leek'], ['carrots', 100, '1 carrot'], ['soy_sauce', 45, '3 tbsp sweet soy sauce'], ['sambal', 10, '1 tsp sambal'], ['garlic', 2, '2 garlic cloves'], ['sunflower_oil', 20, 'Oil'], ['eggs', 4, 'Fried eggs', true]],
    steps: [['Cook the noodles and drain.', 240], ['Fry the meat with garlic and sambal.', 360], ['Add the sliced vegetables and stir-fry.', 300], 'Toss in noodles and soy sauce. Serve with a fried egg.'],
  },
  {
    key: 'gado_gado', title: 'Gado-gado', summary: 'Vegetables, egg and potato with peanut sauce.',
    cuisine: 'Indonesian', tags: ['salad'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 20, emoji: '🥜', color: '#B78A4A',
    ingredients: [['potatoes', 500, '500 g small potatoes'], ['green_beans', 200, '200 g green beans'], ['cabbage', 0.25, '¼ pointed cabbage'], ['eggs', 4, '4 eggs'], ['cucumber', 1, '1 cucumber'], ['tofu', 200, '200 g tofu', true], ['peanut_butter', 100, '5 tbsp peanut butter'], ['soy_sauce', 30, '2 tbsp sweet soy sauce'], ['sambal', 5, 'Sambal'], ['lime', 1, '1 lime']],
    steps: [['Boil the potatoes, adding beans and cabbage for the last 4 minutes.', 1200], ['Boil the eggs.', 480], 'Warm peanut butter, soy, sambal, lime juice and 150 ml water into a sauce.', 'Arrange everything on plates and pour over the sauce.'],
  },
  {
    key: 'korean_beef_bowl', title: 'Korean-style beef rice bowls', summary: 'Sweet-savoury mince with quick pickles.',
    cuisine: 'Korean', tags: ['bowl', 'quick'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 12, emoji: '🍚', color: '#7C3B2A',
    ingredients: [['minced_beef', 500, '500 g mince'], ['soy_sauce', 45, '3 tbsp soy sauce'], ['honey', 20, '1 tbsp honey'], ['garlic', 3, '3 garlic cloves'], ['ginger', 10, 'Ginger'], ['sambal', 10, 'Chilli paste'], ['cucumber', 1, '1 cucumber'], ['vinegar', 30, '2 tbsp vinegar'], ['carrots', 100, '1 carrot'], ['rice', 300, '300 g rice'], ['spring_onion', 2, 'Spring onion']],
    steps: [['Cook the rice.', 720], 'Toss sliced cucumber and carrot with the vinegar and a pinch of sugar and salt.', ['Brown the mince with garlic and ginger, then add soy, honey and chilli.', 480], 'Serve on rice with the pickles and spring onion.'],
  },
  {
    key: 'vietnamese_noodle_salad', title: 'Vietnamese-style noodle salad', summary: 'Cold noodles, herbs and lime with chicken.',
    cuisine: 'Vietnamese', tags: ['salad', 'noodles'], diet: [], difficulty: 'easy', servings: 3, prep: 15, cook: 10, emoji: '🥗', color: '#7BB661',
    ingredients: [['noodles', 200, '200 g rice noodles'], ['chicken_breast', 300, '2 chicken breasts'], ['carrots', 100, '1 carrot'], ['cucumber', 1, '1 cucumber'], ['lettuce', 80, 'Lettuce'], ['mint', 10, 'Mint'], ['coriander', 10, 'Coriander'], ['lime', 2, '2 limes'], ['soy_sauce', 30, '2 tbsp fish or soy sauce'], ['sugar', 15, '1 tbsp sugar'], ['nuts', 30, 'Peanuts'], ['chili', 1, 'Chilli', true]],
    steps: [['Cook the noodles, then rinse cold.', 240], ['Fry the chicken until cooked and slice.', 600], 'Mix lime juice, soy, sugar and chilli.', 'Toss noodles, vegetables and herbs with the dressing; top with chicken and peanuts.'],
  },

  // Indian & South Asian
  {
    key: 'butter_chicken', title: 'Butter chicken', summary: 'Mild, creamy tomato curry the whole family likes.',
    cuisine: 'Indian', tags: ['curry', 'family'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 30, emoji: '🍛', color: '#D1572E',
    ingredients: [['chicken_thigh', 600, '600 g chicken thigh'], ['yoghurt', 100, '100 g yoghurt'], ['curry_powder', 15, '1½ tbsp curry powder or garam masala'], ['onion', 1, '1 onion'], ['garlic', 3, '3 garlic cloves'], ['ginger', 15, 'Ginger'], ['passata', 400, '400 g passata'], ['cream', 150, '150 ml cream'], ['butter', 30, '30 g butter'], ['rice', 300, '300 g rice']],
    steps: ['Marinate the chicken in yoghurt and half the spice for at least 10 minutes.', ['Cook the rice.', 720], ['Soften onion, garlic and ginger in the butter; add the rest of the spice and the passata and simmer.', 600], ['Add the chicken and cook through, then stir in the cream.', 900]],
  },
  {
    key: 'chana_masala', title: 'Chana masala', summary: 'Spiced chickpeas in tomato, cheap and so good.',
    cuisine: 'Indian', tags: ['curry', 'budget', 'batch-cook'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 25, emoji: '🫘', color: '#C2622D',
    ingredients: [['chickpeas', 720, '3 tins chickpeas'], ['onion', 2, '2 onions'], ['garlic', 3, '3 garlic cloves'], ['ginger', 15, 'Ginger'], ['canned_tomatoes', 400, '1 tin tomatoes'], ['curry_powder', 15, '1½ tbsp curry powder'], ['cumin', 3, '1 tsp cumin'], ['lemon', 1, '1 lemon'], ['sunflower_oil', 30, 'Oil'], ['coriander', 10, 'Coriander'], ['rice', 300, 'Rice or bread, to serve']],
    steps: ['Fry the onion in the oil until golden, then garlic, ginger and spices.', ['Add tomatoes and chickpeas with 200 ml water and simmer.', 1200], 'Finish with lemon juice and coriander. Serve with rice.'],
  },
  {
    key: 'saag_aloo', title: 'Saag aloo', summary: 'Spiced potatoes with spinach.',
    cuisine: 'Indian', tags: ['curry', 'budget'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 25, emoji: '🥔', color: '#567D2E',
    ingredients: [['potatoes', 800, '800 g potatoes'], ['frozen_spinach', 450, '450 g frozen spinach'], ['onion', 1, '1 onion'], ['garlic', 3, '3 garlic cloves'], ['ginger', 10, 'Ginger'], ['cumin', 3, '1 tsp cumin'], ['curry_powder', 10, '1 tbsp curry powder'], ['sunflower_oil', 30, 'Oil'], ['yoghurt', 100, 'Yoghurt, to serve', true]],
    steps: [['Parboil the potato cubes.', 480], ['Fry onion, garlic, ginger and spices, then the potatoes until golden.', 600], ['Add the spinach and cook until hot and dry.', 480]],
  },
  {
    key: 'fish_curry', title: 'Coconut fish curry', summary: 'Gentle, fragrant and quick.',
    cuisine: 'Indian', tags: ['curry', 'fish', 'quick'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 20, emoji: '🐟', color: '#E2A33A',
    ingredients: [['white_fish', 500, '500 g white fish'], ['coconut_milk', 400, '1 tin coconut milk'], ['canned_tomatoes', 200, '½ tin tomatoes'], ['onion', 1, '1 onion'], ['garlic', 2, '2 garlic cloves'], ['ginger', 10, 'Ginger'], ['curry_powder', 10, '1 tbsp curry powder'], ['spinach', 100, 'Spinach'], ['lime', 1, '1 lime'], ['rice', 300, '300 g rice'], ['sunflower_oil', 15, 'Oil']],
    steps: [['Cook the rice.', 720], 'Soften onion, garlic and ginger in the oil; add the curry powder.', ['Add tomatoes and coconut milk and simmer.', 480], ['Add fish chunks and spinach; poach until the fish flakes.', 360], 'Finish with lime.'],
  },
  {
    key: 'keema_peas', title: 'Keema with peas', summary: 'Spiced mince and peas, great with rice or bread.',
    cuisine: 'Indian', tags: ['curry', 'batch-cook', 'freezer-friendly'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 25, emoji: '🍛', color: '#8E4A2A',
    ingredients: [['minced_beef', 500, '500 g mince'], ['frozen_peas', 250, '250 g peas'], ['onion', 1, '1 onion'], ['garlic', 3, '3 garlic cloves'], ['ginger', 10, 'Ginger'], ['canned_tomatoes', 400, '1 tin tomatoes'], ['curry_powder', 15, '1½ tbsp curry powder'], ['rice', 300, '300 g rice'], ['yoghurt', 100, 'Yoghurt', true]],
    steps: [['Cook the rice.', 720], 'Brown the mince with the onion, garlic and ginger, then the spices.', ['Add tomatoes and simmer.', 900], ['Add the peas for the last 5 minutes.', 300]],
  },
  {
    key: 'pumpkin_lentil_curry', title: 'Squash & lentil curry', summary: 'Sweet squash, red lentils and coconut.',
    cuisine: 'Indian', tags: ['curry', 'batch-cook', 'autumn'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 30, emoji: '🎃', color: '#E07B26',
    ingredients: [['pumpkin', 0.75, '¾ butternut squash, cubed'], ['lentils', 150, '150 g red lentils'], ['coconut_milk', 400, '1 tin coconut milk'], ['onion', 1, '1 onion'], ['garlic', 2, '2 garlic cloves'], ['curry_paste', 40, '2 tbsp curry paste'], ['spinach', 100, 'Spinach'], ['rice', 300, '300 g rice'], ['sunflower_oil', 15, 'Oil']],
    steps: ['Soften the onion and garlic, then fry the curry paste for a minute.', ['Add squash, lentils, coconut milk and 400 ml water; simmer until soft.', 1500], ['Cook the rice.', 720], 'Stir in the spinach.'],
  },

  // Americas
  {
    key: 'beef_tacos', title: 'Beef tacos with quick salsa', summary: 'Spiced mince, fresh salsa, all the toppings.',
    cuisine: 'Mexican', tags: ['family', 'quick'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 12, emoji: '🌮', color: '#C8642D',
    ingredients: [['minced_beef', 500, '500 g mince'], ['wraps', 8, '8 small wraps'], ['cumin', 3, '1 tsp cumin'], ['paprika_powder', 5, '2 tsp paprika'], ['tomatoes', 3, '3 tomatoes'], ['red_onion', 1, '1 red onion'], ['lime', 1, '1 lime'], ['coriander', 10, 'Coriander'], ['lettuce', 80, 'Lettuce'], ['cheese', 80, '80 g grated cheese'], ['creme_fraiche', 100, 'Crème fraîche', true]],
    steps: ['Dice tomatoes and onion and mix with lime juice and coriander.', ['Brown the mince with the spices and a splash of water.', 600], 'Warm the wraps and fill with mince, lettuce, salsa and cheese.'],
  },
  {
    key: 'black_bean_tacos', title: 'Black bean & sweet potato tacos', summary: 'Roasted sweet potato with smoky beans.',
    cuisine: 'Mexican', tags: ['family'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 25, emoji: '🌮', color: '#5A3E5D',
    ingredients: [['sweet_potato', 500, '500 g sweet potato, diced'], ['black_beans', 480, '2 tins black beans'], ['wraps', 8, '8 small wraps'], ['paprika_powder', 5, '2 tsp smoked paprika'], ['cumin', 3, '1 tsp cumin'], ['avocado', 1, '1 avocado'], ['lime', 1, '1 lime'], ['red_onion', 1, '1 red onion'], ['coriander', 10, 'Coriander'], ['olive_oil', 20, 'Oil']],
    steps: [['Roast the sweet potato with oil and spices at 210 °C.', 1500], 'Warm the beans with a splash of water and mash a little.', 'Mash the avocado with lime and salt.', 'Fill warm wraps with beans, sweet potato, avocado, onion and coriander.'],
  },
  {
    key: 'enchiladas', title: 'Chicken enchiladas', summary: 'Rolled wraps baked in tomato sauce with cheese.',
    cuisine: 'Mexican', tags: ['oven', 'family', 'freezer-friendly'], diet: [], difficulty: 'easy', servings: 4, prep: 20, cook: 25, emoji: '🌯', color: '#B93E2C',
    ingredients: [['chicken_breast', 400, '400 g chicken'], ['wraps', 6, '6 wraps'], ['black_beans', 240, '1 tin black beans'], ['corn', 140, '½ tin sweetcorn'], ['passata', 500, '500 g passata'], ['cumin', 3, '1 tsp cumin'], ['paprika_powder', 5, '2 tsp paprika'], ['cheese', 120, '120 g grated cheese'], ['onion', 1, '1 onion'], ['sunflower_oil', 15, 'Oil']],
    steps: [['Fry the chicken strips and onion with the spices.', 600], 'Mix with beans, corn and a third of the passata.', 'Fill and roll the wraps, lay in a dish, pour over the rest of the passata and top with cheese.', ['Bake at 200 °C.', 1200]],
  },
  {
    key: 'chili_con_carne_corn', title: 'Chili con carne with corn', summary: 'A big pot for the freezer.',
    cuisine: 'Tex-Mex', tags: ['batch-cook', 'freezer-friendly', 'family'], diet: [], difficulty: 'easy', servings: 6, prep: 15, cook: 45, emoji: '🌶️', color: '#9B2D20',
    ingredients: [['minced_beef', 750, '750 g mince'], ['kidney_beans', 480, '2 tins kidney beans'], ['corn', 285, '1 tin sweetcorn'], ['canned_tomatoes', 800, '2 tins tomatoes'], ['onion', 2, '2 onions'], ['bell_pepper', 2, '2 peppers'], ['garlic', 3, '3 garlic cloves'], ['cumin', 5, '2 tsp cumin'], ['paprika_powder', 10, '1 tbsp paprika'], ['chocolate', 10, 'A square of dark chocolate', true], ['rice', 450, 'Rice, to serve']],
    steps: ['Brown the mince, then add onion, pepper, garlic and spices.', ['Add tomatoes and beans and simmer, lid ajar.', 2400], 'Stir in corn and chocolate, season. Serve with rice.'],
  },
  {
    key: 'stuffed_peppers', title: 'Stuffed peppers with rice & beans', summary: 'Colourful, filling and freezer-friendly.',
    cuisine: 'Mexican', tags: ['oven'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 35, emoji: '🫑', color: '#E1452D',
    ingredients: [['bell_pepper', 4, '4 large peppers'], ['rice', 150, '150 g rice'], ['black_beans', 240, '1 tin black beans'], ['corn', 140, '½ tin sweetcorn'], ['passata', 250, '250 g passata'], ['cumin', 3, '1 tsp cumin'], ['cheese', 100, '100 g grated cheese'], ['spring_onion', 2, '2 spring onions']],
    steps: [['Cook the rice.', 720], 'Halve and deseed the peppers.', 'Mix rice, beans, corn, half the passata, cumin and half the cheese; fill the peppers.', ['Pour the rest of the passata around, top with cheese and bake at 200 °C.', 1800]],
  },
  {
    key: 'pulled_chicken_wraps', title: 'BBQ-style pulled chicken & slaw', summary: 'Sticky shredded chicken with crunchy cabbage.',
    cuisine: 'American', tags: ['family', 'weekend'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 30, emoji: '🍗', color: '#8C3B22',
    ingredients: [['chicken_thigh', 600, '600 g chicken thigh'], ['ketchup', 100, '100 ml ketchup'], ['honey', 20, '1 tbsp honey'], ['vinegar', 20, '1 tbsp vinegar'], ['paprika_powder', 5, '2 tsp smoked paprika'], ['cabbage', 0.25, '¼ cabbage'], ['carrots', 100, '1 carrot'], ['mayonnaise', 40, '3 tbsp mayonnaise'], ['bread', 280, '4 rolls or wraps']],
    steps: [['Simmer chicken with ketchup, honey, vinegar, paprika and 100 ml water, lid on.', 1500], 'Shred the chicken in the sauce and reduce until sticky.', 'Mix shredded cabbage and carrot with mayonnaise.', 'Pile into rolls with the slaw.'],
  },
  {
    key: 'mac_cheese', title: 'Baked mac & cheese with broccoli', summary: 'Cheesy comfort with a bit of green.',
    cuisine: 'American', tags: ['comfort', 'family', 'oven'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 30, emoji: '🧀', color: '#E8B33A',
    ingredients: [['pasta', 350, '350 g macaroni'], ['broccoli', 300, '300 g broccoli'], ['butter', 40, '40 g butter'], ['flour', 40, '40 g flour'], ['milk', 600, '600 ml milk'], ['cheese', 200, '200 g grated cheese'], ['mustard', 5, '1 tsp mustard'], ['bread', 35, '1 slice of bread, as crumbs']],
    steps: [['Cook the pasta, adding the broccoli for the last 3 minutes.', 540], 'Melt the butter, stir in the flour and whisk in the milk until thick; add mustard and most of the cheese.', 'Mix with the pasta, pour into a dish, top with crumbs and the rest of the cheese.', ['Bake at 200 °C until golden.', 1200]],
  },
  {
    key: 'beef_burgers_wedges', title: 'Homemade burgers with oven wedges', summary: 'Juicy beef burgers, crispy wedges.',
    cuisine: 'American', tags: ['weekend', 'family'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 35, emoji: '🍔', color: '#A2522B',
    ingredients: [['minced_beef', 500, '500 g mince'], ['onion', 1, '1 onion'], ['bread', 280, '4 burger buns'], ['cheese', 80, '4 slices of cheese'], ['tomatoes', 2, '2 tomatoes'], ['lettuce', 50, 'Lettuce'], ['potatoes', 900, '900 g potatoes'], ['sunflower_oil', 30, 'Oil'], ['ketchup', 40, 'Ketchup'], ['mayonnaise', 40, 'Mayonnaise', true]],
    steps: [['Cut the potatoes into wedges, toss with oil and bake at 220 °C.', 2100], 'Mix the mince with grated onion, salt and pepper; shape 4 burgers.', ['Fry the burgers, 4 minutes a side, adding cheese at the end.', 480], 'Build the burgers with lettuce, tomato and sauces.'],
  },
  {
    key: 'veggie_burgers', title: 'Bean burgers', summary: 'Crispy outside, soft inside, no meat.',
    cuisine: 'American', tags: ['family', 'budget'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 15, emoji: '🍔', color: '#6B4A2D',
    ingredients: [['black_beans', 480, '2 tins black beans'], ['oats', 60, '60 g oats'], ['eggs', 1, '1 egg'], ['red_onion', 1, '1 red onion'], ['cumin', 3, '1 tsp cumin'], ['paprika_powder', 3, '1 tsp paprika'], ['bread', 280, '4 buns'], ['lettuce', 50, 'Lettuce'], ['tomatoes', 2, '2 tomatoes'], ['sunflower_oil', 30, 'Oil'], ['avocado', 1, 'Avocado', true]],
    steps: ['Mash the dried beans; mix with oats, egg, grated onion and spices. Shape 4 burgers and chill 10 minutes.', ['Fry in the oil until crisp, 4 minutes a side.', 480], 'Serve in buns with salad.'],
  },
  {
    key: 'jambalaya', title: 'Chicken & sausage jambalaya', summary: 'Spicy one-pot rice from Louisiana.',
    cuisine: 'Cajun', tags: ['one-pan', 'family'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 35, emoji: '🍲', color: '#B8452A',
    ingredients: [['chicken_thigh', 400, '400 g chicken'], ['smoked_sausage', 200, '200 g smoked sausage'], ['rice', 300, '300 g rice'], ['onion', 1, '1 onion'], ['bell_pepper', 1, '1 pepper'], ['celery', 0.25, '2 sticks of celery'], ['garlic', 2, '2 garlic cloves'], ['canned_tomatoes', 400, '1 tin tomatoes'], ['paprika_powder', 5, '2 tsp paprika'], ['stock_cube', 1, '1 stock cube'], ['chili', 1, 'Chilli', true]],
    steps: ['Brown the chicken and sausage.', 'Add onion, pepper, celery and garlic for 5 minutes, then paprika and rice.', ['Add tomatoes and 700 ml stock; simmer, lid on, until the rice is tender.', 1200]],
  },

  // Middle East & Africa
  {
    key: 'chicken_shawarma_bowl', title: 'Chicken shawarma bowls', summary: 'Spiced chicken, garlic yoghurt, crunchy salad.',
    cuisine: 'Middle Eastern', tags: ['bowl', 'high-protein'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 25, emoji: '🥙', color: '#C97A2B',
    ingredients: [['chicken_thigh', 600, '600 g chicken thigh'], ['cumin', 3, '1 tsp cumin'], ['paprika_powder', 5, '2 tsp paprika'], ['cinnamon', 1, '½ tsp cinnamon'], ['garlic', 3, '3 garlic cloves'], ['lemon', 1, '1 lemon'], ['yoghurt', 200, '200 g yoghurt'], ['couscous', 250, '250 g couscous'], ['cucumber', 1, '1 cucumber'], ['tomatoes', 2, '2 tomatoes'], ['red_onion', 1, '1 red onion'], ['olive_oil', 30, 'Olive oil']],
    steps: ['Toss the chicken with spices, 2 garlic cloves, half the lemon and oil.', ['Roast at 220 °C or pan-fry until charred.', 1500], 'Soak the couscous in 300 ml boiling water for 5 minutes.', 'Mix yoghurt with the last garlic clove. Serve everything in bowls with chopped salad.'],
  },
  {
    key: 'chickpea_tagine', title: 'Moroccan chickpea & vegetable tagine', summary: 'Sweet-spiced stew with couscous.',
    cuisine: 'Moroccan', tags: ['batch-cook', 'budget'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 35, emoji: '🍲', color: '#C76A2B',
    ingredients: [['chickpeas', 480, '2 tins chickpeas'], ['carrots', 200, '2 carrots'], ['sweet_potato', 400, '1 large sweet potato'], ['zucchini', 1, '1 courgette'], ['onion', 1, '1 onion'], ['garlic', 2, '2 garlic cloves'], ['canned_tomatoes', 400, '1 tin tomatoes'], ['cumin', 3, '1 tsp cumin'], ['cinnamon', 2, '1 tsp cinnamon'], ['raisins', 40, '40 g raisins'], ['couscous', 250, '250 g couscous'], ['olive_oil', 20, 'Oil']],
    steps: ['Soften onion and garlic in the oil, add the spices.', ['Add vegetables, chickpeas, tomatoes, raisins and 300 ml water; simmer.', 1800], 'Soak the couscous in 300 ml boiling water for 5 minutes and serve with the stew.'],
  },
  {
    key: 'kofta_bulgur', title: 'Beef kofta with bulgur salad', summary: 'Spiced beef koftas, herby bulgur, yoghurt.',
    cuisine: 'Turkish', tags: ['high-protein'], diet: [], difficulty: 'easy', servings: 4, prep: 20, cook: 15, emoji: '🍢', color: '#9A4F2B',
    ingredients: [['minced_beef', 500, '500 g mince'], ['onion', 1, '1 onion'], ['cumin', 3, '1 tsp cumin'], ['cinnamon', 1, '½ tsp cinnamon'], ['parsley', 20, 'Parsley'], ['mint', 10, 'Mint'], ['bulgur', 200, '200 g bulgur'], ['tomatoes', 2, '2 tomatoes'], ['cucumber', 1, '1 cucumber'], ['lemon', 1, '1 lemon'], ['yoghurt', 150, 'Yoghurt'], ['olive_oil', 30, 'Olive oil']],
    steps: ['Mix mince, grated onion, spices and half the parsley; shape 12 sausages.', ['Pour 400 ml boiling water over the bulgur, cover for 15 minutes.', 900], ['Fry or grill the koftas until cooked.', 600], 'Mix the bulgur with chopped tomato, cucumber, herbs, lemon and oil. Serve with yoghurt.'],
  },
  {
    key: 'mujadara', title: 'Mujadara (lentils & rice with crispy onions)', summary: 'Humble, cheap and deeply savoury.',
    cuisine: 'Lebanese', tags: ['budget', 'comfort'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 35, emoji: '🧅', color: '#8A6338',
    ingredients: [['lentils', 200, '200 g lentils'], ['rice', 200, '200 g rice'], ['onion', 3, '3 onions, sliced'], ['cumin', 3, '1 tsp cumin'], ['olive_oil', 45, '3 tbsp olive oil'], ['yoghurt', 150, 'Yoghurt, to serve'], ['cucumber', 1, 'Cucumber salad', true]],
    steps: [['Fry the onions slowly in the oil until deep brown and crisp; set half aside.', 1200], 'Add cumin, rice and lentils to the pan with the rest of the onions.', ['Add 800 ml water and simmer, lid on, until tender.', 1200], 'Top with the crispy onions and serve with yoghurt.'],
  },
  {
    key: 'roast_aubergine_tahini', title: 'Roasted aubergine with yoghurt & chickpeas', summary: 'Smoky aubergine halves loaded with toppings.',
    cuisine: 'Middle Eastern', tags: ['oven'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 35, emoji: '🍆', color: '#5D3A5E',
    ingredients: [['aubergine', 2, '2 aubergines'], ['chickpeas', 240, '1 tin chickpeas'], ['yoghurt', 200, '200 g yoghurt'], ['garlic', 1, '1 garlic clove'], ['lemon', 1, '1 lemon'], ['cumin', 3, '1 tsp cumin'], ['mint', 10, 'Mint'], ['olive_oil', 30, 'Olive oil'], ['pita', 4, 'Pitas, to serve']],
    steps: [['Halve the aubergines, score, brush with oil and roast at 220 °C until soft.', 1800], ['Roast the chickpeas with cumin on the same tray for the last 15 minutes.', 900], 'Mix yoghurt with garlic and lemon.', 'Top the aubergines with yoghurt, chickpeas and mint. Serve with warm pita.'],
  },
  {
    key: 'peanut_stew', title: 'West African peanut stew', summary: 'Rich, warming sweet potato and peanut stew.',
    cuisine: 'West African', tags: ['batch-cook', 'budget'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 30, emoji: '🥜', color: '#B0632B',
    ingredients: [['sweet_potato', 600, '600 g sweet potato'], ['peanut_butter', 100, '5 tbsp peanut butter'], ['canned_tomatoes', 400, '1 tin tomatoes'], ['onion', 1, '1 onion'], ['garlic', 3, '3 garlic cloves'], ['ginger', 15, 'Ginger'], ['chili', 1, '1 chilli'], ['kale', 150, '150 g kale or spinach'], ['stock_cube', 1, '1 stock cube'], ['rice', 300, '300 g rice'], ['chicken_thigh', 400, '400 g chicken', true]],
    steps: ['Soften onion, garlic, ginger and chilli (brown the chicken first if using).', ['Add sweet potato, tomatoes, peanut butter and 600 ml stock; simmer.', 1500], ['Cook the rice.', 720], ['Add the kale until tender.', 300]],
  },
  {
    key: 'harissa_style_traybake', title: 'Spiced chicken & vegetable couscous traybake', summary: 'Everything roasts together, couscous soaks it up.',
    cuisine: 'North African', tags: ['traybake', 'one-pan'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 35, emoji: '🍗', color: '#B6452C',
    ingredients: [['chicken_thigh', 600, '600 g chicken thighs'], ['zucchini', 1, '1 courgette'], ['red_onion', 2, '2 red onions'], ['bell_pepper', 2, '2 peppers'], ['cherry_tomatoes', 200, '200 g cherry tomatoes'], ['paprika_powder', 5, '2 tsp paprika'], ['cumin', 3, '1 tsp cumin'], ['chili', 1, '1 chilli'], ['olive_oil', 30, 'Oil'], ['couscous', 250, '250 g couscous'], ['yoghurt', 150, 'Yoghurt', true]],
    steps: ['Toss chicken and vegetables with oil and spices on a tray.', ['Roast at 210 °C.', 2100], 'Soak the couscous in 300 ml boiling water and stir it through the tray juices.'],
  },
];
