// Vegetarian and vegan dinners, fish, soups and fast weeknight meals, written for this project.
import type { SeedRecipe } from './recipes-seed.ts';

export const WEEKNIGHT_RECIPES: SeedRecipe[] = [
  // Vegetarian & vegan
  {
    key: 'veggie_mince_bolognese', title: 'Vegetarian mince bolognese', summary: 'The family favourite, meat-free.',
    cuisine: 'Italian', tags: ['pasta', 'family', 'freezer-friendly'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 25, emoji: '🍝', color: '#B04A32',
    ingredients: [['veggie_mince', 400, '2 packs vegetarian mince'], ['pasta', 400, '400 g spaghetti'], ['onion', 1, '1 onion'], ['carrots', 100, '1 carrot'], ['garlic', 2, '2 garlic cloves'], ['passata', 500, '500 g passata'], ['oregano', 2, '1 tsp oregano'], ['olive_oil', 15, 'Olive oil'], ['parmesan', 30, 'Parmesan', true]],
    steps: ['Soften onion, carrot and garlic in the oil.', ['Add the mince and fry until browned, then passata and oregano; simmer.', 900], ['Cook the pasta.', 600], 'Serve with parmesan.'],
  },
  {
    key: 'veggie_mince_chili', title: 'Vegetarian chili with corn', summary: 'Smoky, hearty and ready in 30 minutes.',
    cuisine: 'Tex-Mex', tags: ['batch-cook', 'freezer-friendly'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 25, emoji: '🌶️', color: '#9F3A26',
    ingredients: [['veggie_mince', 400, '2 packs vegetarian mince'], ['kidney_beans', 240, '1 tin kidney beans'], ['corn', 140, '½ tin sweetcorn'], ['canned_tomatoes', 400, '1 tin tomatoes'], ['onion', 1, '1 onion'], ['bell_pepper', 1, '1 pepper'], ['cumin', 3, '1 tsp cumin'], ['paprika_powder', 5, '2 tsp smoked paprika'], ['rice', 300, '300 g rice'], ['sunflower_oil', 15, 'Oil']],
    steps: [['Cook the rice.', 720], 'Fry onion and pepper, then the mince and spices.', ['Add tomatoes, beans and corn and simmer.', 900]],
  },
  {
    key: 'cauliflower_steaks', title: 'Roasted cauliflower with lentils & yoghurt', summary: 'Golden cauliflower on spiced lentils.',
    cuisine: 'Modern', tags: ['oven', 'high-protein'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 30, emoji: '🥦', color: '#D9B23A',
    ingredients: [['cauliflower', 1, '1 cauliflower'], ['lentils', 200, '200 g lentils'], ['curry_powder', 10, '1 tbsp curry powder'], ['olive_oil', 30, 'Olive oil'], ['yoghurt', 150, 'Yoghurt'], ['lemon', 1, '1 lemon'], ['parsley', 15, 'Parsley'], ['nuts', 30, 'Toasted nuts', true]],
    steps: [['Cut the cauliflower into thick slices and florets, toss with oil and curry powder; roast at 220 °C.', 1800], ['Cook the lentils and season with lemon.', 900], 'Serve the cauliflower on the lentils with yoghurt, parsley and nuts.'],
  },
  {
    key: 'mushroom_tacos', title: 'Crispy mushroom tacos', summary: 'Smoky mushrooms with lime slaw.',
    cuisine: 'Mexican', tags: ['quick'], diet: [], difficulty: 'easy', servings: 3, prep: 10, cook: 12, emoji: '🍄', color: '#6E4E37',
    ingredients: [['mushrooms', 500, '500 g mushrooms'], ['wraps', 6, '6 small wraps'], ['paprika_powder', 5, '2 tsp smoked paprika'], ['cumin', 3, '1 tsp cumin'], ['cabbage', 0.25, '¼ cabbage'], ['lime', 2, '2 limes'], ['avocado', 1, '1 avocado'], ['coriander', 10, 'Coriander'], ['olive_oil', 30, 'Oil']],
    steps: [['Fry the sliced mushrooms in hot oil until they lose their water and crisp up; add the spices.', 600], 'Toss the shredded cabbage with lime juice and salt.', 'Fill warm wraps with mushrooms, slaw, avocado and coriander.'],
  },
  {
    key: 'tofu_scramble_wraps', title: 'Tofu scramble wraps', summary: 'A plant-based scramble with spinach and peppers.',
    cuisine: 'Modern', tags: ['quick', 'high-protein'], diet: [], difficulty: 'easy', servings: 2, prep: 5, cook: 10, emoji: '🌯', color: '#E5BC3A',
    ingredients: [['tofu', 300, '300 g firm tofu'], ['bell_pepper', 1, '1 pepper'], ['spinach', 80, 'Spinach'], ['curry_powder', 3, '1 tsp curry powder or turmeric'], ['wraps', 2, '2 wraps'], ['olive_oil', 15, 'Oil'], ['avocado', 1, 'Avocado', true]],
    steps: [['Fry the pepper, then crumble in the tofu with the spice.', 360], 'Stir in the spinach until wilted. Season.', 'Fill the wraps.'],
  },
  {
    key: 'tofu_veg_skewers', title: 'Vegetable & tofu skewers with couscous', summary: 'Charred skewers with a lemony couscous.',
    cuisine: 'Mediterranean', tags: ['summer'], diet: [], difficulty: 'easy', servings: 4, prep: 20, cook: 15, emoji: '🍢', color: '#D1663A',
    ingredients: [['tofu', 400, '400 g firm tofu'], ['zucchini', 1, '1 courgette'], ['bell_pepper', 2, '2 peppers'], ['red_onion', 1, '1 red onion'], ['cherry_tomatoes', 200, '200 g cherry tomatoes'], ['olive_oil', 30, 'Oil'], ['oregano', 2, 'Oregano'], ['lemon', 1, '1 lemon'], ['couscous', 250, '250 g couscous'], ['mint', 5, 'Mint']],
    steps: ['Cube the tofu and vegetables, toss with oil, oregano and lemon zest, then thread onto skewers.', ['Grill or griddle, turning, until charred.', 720], 'Soak the couscous in 300 ml boiling water, then add lemon juice and mint.'],
  },
  {
    key: 'spinach_dal_coconut', title: 'Coconut dal with spinach', summary: 'Creamy lentils for a cosy weeknight.',
    cuisine: 'Indian', tags: ['curry', 'budget', 'batch-cook'], diet: [], difficulty: 'easy', servings: 4, prep: 5, cook: 25, emoji: '🍲', color: '#E0A238',
    ingredients: [['lentils', 250, '250 g red lentils'], ['coconut_milk', 400, '1 tin coconut milk'], ['onion', 1, '1 onion'], ['garlic', 3, '3 garlic cloves'], ['ginger', 15, 'Ginger'], ['curry_powder', 10, '1 tbsp curry powder'], ['spinach', 200, '200 g spinach'], ['lime', 1, '1 lime'], ['rice', 300, 'Rice or bread']],
    steps: ['Soften onion, garlic and ginger, then add the spices.', ['Add lentils, coconut milk and 600 ml water; simmer until soft.', 1200], 'Stir in the spinach and lime juice.'],
  },
  {
    key: 'stuffed_courgettes', title: 'Stuffed courgettes with feta', summary: 'Courgette boats with a herby rice filling.',
    cuisine: 'Greek', tags: ['oven', 'summer'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 35, emoji: '🥒', color: '#6E9E45',
    ingredients: [['zucchini', 4, '4 courgettes'], ['rice', 150, '150 g rice'], ['cherry_tomatoes', 200, '200 g cherry tomatoes'], ['feta', 150, '150 g feta'], ['red_onion', 1, '1 red onion'], ['dill', 5, 'Dill'], ['mint', 5, 'Mint'], ['olive_oil', 30, 'Olive oil']],
    steps: [['Cook the rice.', 720], 'Halve the courgettes and scoop out the middle; chop the scooped flesh.', 'Fry onion and chopped courgette, then mix with rice, tomatoes, herbs and half the feta.', ['Fill the courgettes, top with the rest of the feta and bake at 200 °C.', 1500]],
  },
  {
    key: 'pumpkin_risotto', title: 'Roast squash risotto', summary: 'Sweet squash stirred into creamy rice.',
    cuisine: 'Italian', tags: ['autumn', 'comfort'], diet: [], difficulty: 'medium', servings: 4, prep: 10, cook: 35, emoji: '🎃', color: '#E58A2B',
    ingredients: [['pumpkin', 0.5, '½ butternut squash'], ['rice', 300, '300 g risotto rice'], ['onion', 1, '1 onion'], ['stock_cube', 2, '2 stock cubes'], ['parmesan', 40, '40 g parmesan'], ['butter', 30, '30 g butter'], ['olive_oil', 15, 'Oil'], ['nuts', 30, 'Toasted nuts', true]],
    steps: [['Roast the squash cubes with the oil at 200 °C.', 1500], 'Soften the onion in half the butter, stir in the rice.', ['Add 1.1 litres hot stock a ladle at a time, stirring.', 1200], 'Stir in the squash, parmesan and the rest of the butter.'],
  },
  {
    key: 'bean_kale_stew', title: 'Smoky white bean & kale stew', summary: 'One pot, crusty bread, done.',
    cuisine: 'Spanish', tags: ['one-pan', 'budget'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 25, emoji: '🫘', color: '#9C5233',
    ingredients: [['white_beans', 720, '3 tins white beans'], ['kale', 200, '200 g kale'], ['onion', 1, '1 onion'], ['garlic', 3, '3 garlic cloves'], ['canned_tomatoes', 400, '1 tin tomatoes'], ['paprika_powder', 5, '2 tsp smoked paprika'], ['olive_oil', 30, 'Olive oil'], ['bread', 140, 'Crusty bread'], ['chorizo', 80, '80 g chorizo', true]],
    steps: ['Fry onion and garlic (and chorizo) in the oil with the paprika.', ['Add tomatoes, beans and 200 ml water; simmer.', 900], ['Add the kale until tender.', 360], 'Serve with bread.'],
  },
  {
    key: 'egg_curry', title: 'Egg & potato curry', summary: 'A thrifty curry with boiled eggs in tomato sauce.',
    cuisine: 'Indian', tags: ['curry', 'budget'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 25, emoji: '🥚', color: '#D07A2B',
    ingredients: [['eggs', 6, '6 eggs'], ['potatoes', 500, '500 g potatoes'], ['onion', 1, '1 onion'], ['garlic', 2, '2 garlic cloves'], ['ginger', 10, 'Ginger'], ['canned_tomatoes', 400, '1 tin tomatoes'], ['curry_powder', 15, '1½ tbsp curry powder'], ['coconut_milk', 200, '200 ml coconut milk'], ['rice', 300, '300 g rice'], ['sunflower_oil', 15, 'Oil']],
    steps: [['Boil the eggs for 9 minutes, then peel.', 540], 'Fry onion, garlic, ginger and spices.', ['Add potato cubes, tomatoes and coconut milk and simmer until soft.', 1200], ['Cook the rice.', 720], 'Halve the eggs into the curry.'],
  },
  {
    key: 'quinoa_black_bean_bowl', title: 'Quinoa & black bean burrito bowls', summary: 'Everything good about a burrito, in a bowl.',
    cuisine: 'Mexican', tags: ['bowl', 'meal-prep'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 15, emoji: '🥗', color: '#4A3B5C',
    ingredients: [['quinoa', 200, '200 g quinoa'], ['black_beans', 480, '2 tins black beans'], ['corn', 285, '1 tin sweetcorn'], ['tomatoes', 2, '2 tomatoes'], ['red_onion', 1, '1 red onion'], ['avocado', 2, '2 avocados'], ['lime', 2, '2 limes'], ['cumin', 3, '1 tsp cumin'], ['coriander', 10, 'Coriander'], ['cheese', 60, 'Cheese', true]],
    steps: [['Cook the quinoa.', 900], 'Warm the beans with the cumin.', 'Make a salsa of tomato, onion, lime and coriander; slice the avocado.', 'Build bowls with quinoa, beans, corn, salsa and avocado.'],
  },
  {
    key: 'greek_pasta_salad', title: 'Greek pasta salad', summary: 'Pasta, cucumber, olives, feta and a lemony dressing.',
    cuisine: 'Greek', tags: ['salad', 'lunch', 'meal-prep'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 10, emoji: '🥗', color: '#3D7FA5',
    ingredients: [['pasta', 300, '300 g small pasta'], ['cucumber', 1, '1 cucumber'], ['cherry_tomatoes', 250, '250 g cherry tomatoes'], ['red_onion', 1, '1 red onion'], ['olives', 80, '80 g olives'], ['feta', 150, '150 g feta'], ['oregano', 2, '1 tsp oregano'], ['lemon', 1, '1 lemon'], ['olive_oil', 45, '3 tbsp olive oil']],
    steps: [['Cook the pasta, then rinse cold.', 600], 'Chop the vegetables.', 'Toss everything with lemon juice, oil and oregano; crumble over the feta.'],
  },
  {
    key: 'baked_feta_pasta', title: 'Baked feta pasta', summary: 'The famous one: roasted tomatoes and feta stirred into pasta.',
    cuisine: 'Mediterranean', tags: ['pasta', 'oven', 'quick'], diet: [], difficulty: 'easy', servings: 4, prep: 5, cook: 30, emoji: '🍅', color: '#D8423A',
    ingredients: [['cherry_tomatoes', 500, '500 g cherry tomatoes'], ['feta', 200, '1 block of feta'], ['garlic', 3, '3 garlic cloves'], ['olive_oil', 45, '3 tbsp olive oil'], ['pasta', 400, '400 g pasta'], ['basil', 10, 'Basil'], ['spinach', 100, 'Spinach', true]],
    steps: ['Heat the oven to 200 °C.', ['Put the feta in a dish, surround with tomatoes and garlic, drizzle with oil and bake.', 1800], ['Cook the pasta.', 600], 'Mash the feta and tomatoes together, then stir in the pasta, spinach and basil.'],
  },
  {
    key: 'kale_pesto_pasta', title: 'Kale & walnut pesto pasta', summary: 'A green pesto from kale, nuts and parmesan.',
    cuisine: 'Italian', tags: ['pasta', 'quick', 'use-it-up'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 10, emoji: '🌿', color: '#3F6E2E',
    ingredients: [['kale', 150, '150 g kale'], ['nuts', 50, '50 g walnuts'], ['parmesan', 40, '40 g parmesan'], ['garlic', 1, '1 garlic clove'], ['lemon', 1, '1 lemon'], ['olive_oil', 60, '4 tbsp olive oil'], ['pasta', 400, '400 g pasta']],
    steps: [['Blanch the kale for 2 minutes, then drain.', 120], 'Blend kale, nuts, parmesan, garlic, lemon and oil into a pesto.', ['Cook the pasta.', 600], 'Toss with the pesto and a splash of pasta water.'],
  },

  // Fish
  {
    key: 'salmon_rice_bowl', title: 'Salmon poke-style bowls', summary: 'Soy-glazed salmon, rice, avocado and cucumber.',
    cuisine: 'Hawaiian', tags: ['bowl', 'fish', 'high-protein'], diet: [], difficulty: 'easy', servings: 2, prep: 10, cook: 15, emoji: '🍣', color: '#F08060',
    ingredients: [['salmon', 250, '2 salmon fillets'], ['rice', 150, '150 g rice'], ['soy_sauce', 30, '2 tbsp soy sauce'], ['honey', 10, '2 tsp honey'], ['avocado', 1, '1 avocado'], ['cucumber', 0.5, '½ cucumber'], ['carrots', 80, '1 carrot'], ['spring_onion', 2, 'Spring onion'], ['vinegar', 10, '2 tsp vinegar']],
    steps: [['Cook the rice and season with the vinegar.', 720], ['Roast or pan-fry the salmon, brushing with soy and honey at the end.', 600], 'Build bowls with rice, flaked salmon, avocado, cucumber and carrot.'],
  },
  {
    key: 'cod_tomato_olives', title: 'Cod baked with tomatoes & olives', summary: 'Mediterranean fish in one dish.',
    cuisine: 'Mediterranean', tags: ['fish', 'low-carb', 'one-pan'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 20, emoji: '🐟', color: '#C9523A',
    ingredients: [['white_fish', 500, '4 cod fillets'], ['cherry_tomatoes', 300, '300 g cherry tomatoes'], ['olives', 60, '60 g olives'], ['garlic', 2, '2 garlic cloves'], ['lemon', 1, '1 lemon'], ['olive_oil', 30, 'Olive oil'], ['parsley', 10, 'Parsley'], ['bread', 140, 'Bread or potatoes', true]],
    steps: [['Roast tomatoes, olives and garlic with the oil at 200 °C.', 600], ['Nestle the fish in, top with lemon slices and bake until it flakes.', 720], 'Scatter with parsley.'],
  },
  {
    key: 'fish_tacos', title: 'Crispy fish tacos with lime slaw', summary: 'Spiced fish, crunchy cabbage, cool sauce.',
    cuisine: 'Mexican', tags: ['fish', 'quick'], diet: [], difficulty: 'easy', servings: 4, prep: 15, cook: 10, emoji: '🌮', color: '#5BA3B5',
    ingredients: [['white_fish', 500, '500 g white fish'], ['flour', 30, 'Flour'], ['paprika_powder', 3, '1 tsp paprika'], ['wraps', 8, '8 small wraps'], ['cabbage', 0.25, '¼ cabbage'], ['lime', 2, '2 limes'], ['yoghurt', 100, 'Yoghurt or mayonnaise'], ['coriander', 10, 'Coriander'], ['sunflower_oil', 30, 'Oil']],
    steps: ['Toss shredded cabbage with lime juice and salt.', ['Dust fish pieces in flour and paprika and fry until crisp.', 360], 'Fill warm wraps with fish, slaw, yoghurt and coriander.'],
  },
  {
    key: 'shrimp_coconut_curry', title: 'Shrimp & coconut curry', summary: 'Quick, creamy and ready in 20 minutes.',
    cuisine: 'Thai', tags: ['curry', 'fish', 'quick'], diet: [], difficulty: 'easy', servings: 4, prep: 5, cook: 15, emoji: '🍤', color: '#E79B3E',
    ingredients: [['shrimp', 400, '400 g shrimp'], ['curry_paste', 50, '3 tbsp red curry paste'], ['coconut_milk', 400, '1 tin coconut milk'], ['bell_pepper', 1, '1 pepper'], ['spinach', 100, 'Spinach'], ['lime', 1, '1 lime'], ['rice', 300, '300 g rice']],
    steps: [['Cook the rice.', 720], 'Fry the paste briefly, add coconut milk and pepper and simmer 5 minutes.', ['Add the shrimp and spinach until the shrimp are pink.', 180], 'Finish with lime.'],
  },
  {
    key: 'tuna_fishcakes', title: 'Tuna & potato fishcakes', summary: 'Crispy cakes from cupboard staples.',
    cuisine: 'British', tags: ['fish', 'budget', 'family'], diet: [], difficulty: 'easy', servings: 4, prep: 20, cook: 20, emoji: '🐟', color: '#C9A15A',
    ingredients: [['potatoes', 600, '600 g potatoes'], ['tuna', 290, '2 tins tuna'], ['spring_onion', 3, '3 spring onions'], ['eggs', 1, '1 egg'], ['flour', 30, 'Flour'], ['lemon', 1, '1 lemon'], ['sunflower_oil', 30, 'Oil'], ['lettuce', 100, 'Salad'], ['mayonnaise', 40, 'Mayonnaise', true]],
    steps: [['Boil the potatoes and mash.', 1200], 'Mix with tuna, spring onion, egg, lemon zest and seasoning; shape 8 cakes and dust in flour.', ['Fry until golden on both sides.', 480], 'Serve with salad and lemon.'],
  },
  {
    key: 'mackerel_potato_salad', title: 'Warm potato salad with smoked mackerel', summary: 'Smoky fish and a mustard dressing on warm potatoes.',
    cuisine: 'Nordic', tags: ['fish', 'salad', 'quick'], diet: [], difficulty: 'easy', servings: 3, prep: 10, cook: 15, emoji: '🥔', color: '#A07A3E',
    ingredients: [['potatoes', 600, '600 g small potatoes'], ['smoked_mackerel', 200, '200 g smoked mackerel'], ['green_beans', 200, '200 g green beans'], ['red_onion', 1, '1 red onion'], ['mustard', 10, '2 tsp mustard'], ['vinegar', 15, '1 tbsp vinegar'], ['olive_oil', 30, '2 tbsp oil'], ['dill', 5, 'Dill']],
    steps: [['Boil the potatoes, adding the beans for the last 4 minutes.', 900], 'Whisk mustard, vinegar and oil.', 'Toss the warm potatoes and beans with dressing, onion and flaked mackerel; top with dill.'],
  },
  {
    key: 'salmon_sweet_potato', title: 'Honey-mustard salmon with sweet potato', summary: 'A sheet-pan dinner with broccoli.',
    cuisine: 'Modern', tags: ['fish', 'traybake', 'high-protein'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 30, emoji: '🐟', color: '#E77F5A',
    ingredients: [['salmon', 500, '4 salmon fillets'], ['sweet_potato', 700, '700 g sweet potato'], ['broccoli', 400, '1 head of broccoli'], ['honey', 20, '1 tbsp honey'], ['mustard', 20, '1 tbsp mustard'], ['olive_oil', 30, 'Oil'], ['lemon', 1, 'Lemon']],
    steps: [['Roast the sweet potato with half the oil at 210 °C.', 900], ['Add broccoli and salmon brushed with honey and mustard.', 900], 'Serve with lemon.'],
  },

  // Soups
  {
    key: 'chicken_noodle_classic', title: 'Chicken & vegetable soup', summary: 'A big pot of comfort for cold days.',
    cuisine: 'European', tags: ['soup', 'comfort', 'batch-cook'], diet: [], difficulty: 'easy', servings: 6, prep: 15, cook: 35, emoji: '🍲', color: '#D9A85B',
    ingredients: [['chicken_thigh', 400, '400 g chicken thigh'], ['carrots', 200, '2 carrots'], ['celery', 0.25, '2 sticks of celery'], ['leek', 1, '1 leek'], ['onion', 1, '1 onion'], ['stock_cube', 3, '3 stock cubes'], ['pasta', 100, '100 g small pasta or vermicelli'], ['parsley', 10, 'Parsley']],
    steps: [['Simmer chicken, chopped vegetables and stock cubes in 1.8 litres water.', 1500], 'Take out the chicken and shred it.', ['Add the pasta and cook until tender.', 480], 'Return the chicken and add parsley.'],
  },
  {
    key: 'broccoli_cheese_soup', title: 'Broccoli & cheese soup', summary: 'Creamy, cheesy and green.',
    cuisine: 'British', tags: ['soup', 'quick'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 20, emoji: '🥦', color: '#6A9C3E',
    ingredients: [['broccoli', 500, '1 large head of broccoli'], ['potatoes', 200, '1 potato'], ['onion', 1, '1 onion'], ['stock_cube', 2, '2 stock cubes'], ['cheese', 100, '100 g grated cheese'], ['milk', 200, '200 ml milk'], ['butter', 15, 'Butter'], ['bread', 140, 'Bread', true]],
    steps: ['Soften the onion in butter.', ['Add broccoli, potato and 800 ml stock; simmer.', 900], 'Blend with the milk and stir in the cheese.'],
  },
  {
    key: 'carrot_ginger_soup', title: 'Carrot & ginger soup', summary: 'Bright, smooth and cheap.',
    cuisine: 'European', tags: ['soup', 'budget', 'freezer-friendly'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 25, emoji: '🥕', color: '#E8792B',
    ingredients: [['carrots', 750, '750 g carrots'], ['onion', 1, '1 onion'], ['ginger', 25, 'A big thumb of ginger'], ['stock_cube', 2, '2 stock cubes'], ['coconut_milk', 200, '200 ml coconut milk'], ['olive_oil', 15, 'Oil'], ['coriander', 10, 'Coriander', true]],
    steps: ['Soften onion and ginger in the oil.', ['Add carrots and 1 litre stock; simmer until soft.', 1200], 'Blend with the coconut milk and season.'],
  },
  {
    key: 'mushroom_soup', title: 'Creamy mushroom soup', summary: 'Earthy and rich with a splash of cream.',
    cuisine: 'French', tags: ['soup'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 25, emoji: '🍄', color: '#8C6B4A',
    ingredients: [['mushrooms', 500, '500 g mushrooms'], ['onion', 1, '1 onion'], ['garlic', 2, '2 garlic cloves'], ['potatoes', 200, '1 potato'], ['stock_cube', 2, '2 stock cubes'], ['cream', 100, '100 ml cream'], ['butter', 20, 'Butter'], ['parsley', 10, 'Parsley'], ['bread', 140, 'Bread', true]],
    steps: [['Fry the mushrooms, onion and garlic in butter until golden.', 600], ['Add potato and 900 ml stock; simmer.', 900], 'Blend, stir in cream and parsley.'],
  },
  {
    key: 'tomato_lentil_soup', title: 'Tomato & red lentil soup', summary: 'Thick, warming and full of protein.',
    cuisine: 'European', tags: ['soup', 'budget', 'batch-cook'], diet: [], difficulty: 'easy', servings: 4, prep: 5, cook: 25, emoji: '🍅', color: '#C8432F',
    ingredients: [['lentils', 150, '150 g red lentils'], ['canned_tomatoes', 800, '2 tins tomatoes'], ['onion', 1, '1 onion'], ['carrots', 100, '1 carrot'], ['garlic', 2, '2 garlic cloves'], ['paprika_powder', 3, '1 tsp paprika'], ['stock_cube', 2, '2 stock cubes'], ['olive_oil', 15, 'Oil'], ['yoghurt', 80, 'Yoghurt', true]],
    steps: ['Soften onion, carrot and garlic with the paprika.', ['Add lentils, tomatoes and 800 ml stock; simmer.', 1200], 'Blend until smooth.'],
  },
  {
    key: 'cauliflower_bacon_soup', title: 'Cauliflower soup with crispy bacon', summary: 'Velvety cauliflower with a salty crunch.',
    cuisine: 'European', tags: ['soup', 'low-carb'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 25, emoji: '🥣', color: '#E8DDC0',
    ingredients: [['cauliflower', 1, '1 cauliflower'], ['onion', 1, '1 onion'], ['stock_cube', 2, '2 stock cubes'], ['cream', 100, '100 ml cream'], ['bacon', 100, '100 g bacon bits'], ['butter', 15, 'Butter']],
    steps: ['Soften the onion in butter.', ['Add cauliflower and 900 ml stock; simmer until soft.', 1200], 'Blend with the cream.', 'Fry the bacon until crisp and scatter on top.'],
  },
  {
    key: 'beet_soup', title: 'Beetroot soup with dill', summary: 'Ruby-red, earthy and fresh.',
    cuisine: 'Eastern European', tags: ['soup'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 25, emoji: '🥣', color: '#8E1F4A',
    ingredients: [['beetroot', 500, '500 g cooked beetroot'], ['potatoes', 300, '2 potatoes'], ['onion', 1, '1 onion'], ['carrots', 100, '1 carrot'], ['cabbage', 0.25, '¼ cabbage'], ['stock_cube', 2, '2 stock cubes'], ['vinegar', 15, '1 tbsp vinegar'], ['creme_fraiche', 100, 'Crème fraîche'], ['dill', 5, 'Dill']],
    steps: ['Soften onion and carrot.', ['Add potato, cabbage and 1 litre stock; simmer.', 1200], ['Add diced beetroot and vinegar and heat through.', 300], 'Serve with crème fraîche and dill.'],
  },

  // Fast weeknight
  {
    key: 'chicken_pesto_traybake', title: 'Pesto chicken with roasted vegetables', summary: 'Ten minutes of work, the oven does the rest.',
    cuisine: 'Italian', tags: ['traybake', 'one-pan', 'low-carb'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 30, emoji: '🍗', color: '#5E8F3A',
    ingredients: [['chicken_breast', 600, '4 chicken breasts'], ['pesto', 90, '90 g pesto'], ['zucchini', 2, '2 courgettes'], ['cherry_tomatoes', 300, '300 g cherry tomatoes'], ['red_onion', 2, '2 red onions'], ['mozzarella', 125, 'Mozzarella', true], ['olive_oil', 20, 'Oil']],
    steps: ['Toss the vegetables with oil on a tray.', 'Spread the chicken with pesto and nestle in (top with mozzarella if using).', ['Roast at 210 °C until the chicken is cooked through.', 1800]],
  },
  {
    key: 'sausage_traybake', title: 'Smoked sausage & vegetable traybake', summary: 'Potatoes, peppers and sausage, all on one tray.',
    cuisine: 'Dutch', tags: ['traybake', 'one-pan', 'family'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 35, emoji: '🌭', color: '#A3462E',
    ingredients: [['smoked_sausage', 275, '1 smoked sausage'], ['potatoes', 800, '800 g potatoes'], ['bell_pepper', 2, '2 peppers'], ['red_onion', 2, '2 red onions'], ['zucchini', 1, '1 courgette'], ['paprika_powder', 5, '2 tsp paprika'], ['olive_oil', 30, 'Oil'], ['mustard', 10, 'Mustard']],
    steps: [['Toss potato chunks with oil and paprika and roast at 210 °C.', 1200], ['Add the vegetables and sliced sausage and roast until golden.', 1200], 'Serve with mustard.'],
  },
  {
    key: 'cabbage_egg_rice', title: 'Leftover rice with cabbage & egg', summary: 'A five-ingredient clear-out dinner.',
    cuisine: 'Asian', tags: ['use-it-up', 'quick', 'budget'], diet: [], difficulty: 'easy', servings: 2, prep: 5, cook: 10, emoji: '🍳', color: '#D9A23A',
    ingredients: [['rice', 150, 'Leftover rice (150 g dry)'], ['cabbage', 0.2, 'A wedge of cabbage'], ['eggs', 3, '3 eggs'], ['soy_sauce', 20, 'Soy sauce'], ['sambal', 5, 'Sambal'], ['sunflower_oil', 15, 'Oil'], ['spring_onion', 2, 'Spring onion']],
    steps: [['Fry the shredded cabbage until charred.', 300], 'Add the rice, soy and sambal and fry until hot.', 'Push aside, scramble the eggs and mix through. Top with spring onion.'],
  },
  {
    key: 'chicken_couscous_quick', title: '15-minute chicken & pepper couscous', summary: 'Dinner faster than delivery.',
    cuisine: 'Mediterranean', tags: ['quick', 'high-protein'], diet: [], difficulty: 'easy', servings: 3, prep: 5, cook: 10, emoji: '🍗', color: '#D4884A',
    ingredients: [['chicken_breast', 400, '400 g chicken'], ['couscous', 200, '200 g couscous'], ['bell_pepper', 2, '2 peppers'], ['red_onion', 1, '1 red onion'], ['paprika_powder', 3, '1 tsp paprika'], ['cumin', 2, '1 tsp cumin'], ['stock_cube', 1, '1 stock cube'], ['lemon', 1, '1 lemon'], ['olive_oil', 20, 'Oil'], ['feta', 60, 'Feta', true]],
    steps: ['Soak the couscous in 250 ml hot stock, covered.', ['Fry chicken strips, pepper and onion with the spices.', 600], 'Fluff the couscous, mix everything with lemon juice and top with feta.'],
  },
  {
    key: 'pork_stir_fry_cabbage', title: 'Ginger pork & cabbage stir-fry', summary: 'A fast stir-fry with sweet soy and ginger.',
    cuisine: 'Asian', tags: ['quick', 'stir-fry', 'budget'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 10, emoji: '🥬', color: '#7D8F3A',
    ingredients: [['pork_tenderloin', 400, '400 g pork, in strips'], ['cabbage', 0.5, '½ pointed cabbage'], ['carrots', 100, '1 carrot'], ['ginger', 15, 'Ginger'], ['garlic', 2, '2 garlic cloves'], ['soy_sauce', 45, '3 tbsp soy sauce'], ['honey', 10, '2 tsp honey'], ['sunflower_oil', 20, 'Oil'], ['rice', 300, '300 g rice']],
    steps: [['Cook the rice.', 720], ['Stir-fry the pork until browned, then set aside.', 240], ['Stir-fry cabbage, carrot, ginger and garlic.', 240], 'Return the pork with soy and honey and toss.'],
  },
  {
    key: 'pasta_e_fagioli', title: 'Pasta e fagioli', summary: 'Italian pasta and bean soup, thick enough to eat with a fork.',
    cuisine: 'Italian', tags: ['soup', 'budget', 'comfort'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 25, emoji: '🍲', color: '#B5653A',
    ingredients: [['white_beans', 480, '2 tins white beans'], ['pasta', 150, '150 g small pasta'], ['onion', 1, '1 onion'], ['carrots', 100, '1 carrot'], ['celery', 0.25, '2 sticks of celery'], ['garlic', 2, '2 garlic cloves'], ['canned_tomatoes', 400, '1 tin tomatoes'], ['stock_cube', 2, '2 stock cubes'], ['parmesan', 30, 'Parmesan'], ['olive_oil', 30, 'Olive oil']],
    steps: ['Soften the vegetables in the oil.', ['Add tomatoes, beans and 1 litre stock; simmer.', 600], ['Add the pasta and cook until tender.', 600], 'Mash some beans to thicken; serve with parmesan.'],
  },
];
