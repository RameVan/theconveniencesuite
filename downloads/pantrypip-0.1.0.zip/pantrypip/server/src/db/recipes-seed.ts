// Built-in recipes, written for this project (no third-party recipe text).
// Ingredient quantities are in the product's base unit (g, ml or pcs) for the stated servings.

export interface SeedRecipe {
  key: string;
  title: string;
  summary: string;
  cuisine: string;
  tags: string[];
  diet: string[];
  difficulty: 'easy' | 'medium' | 'hard';
  servings: number;
  prep: number;
  cook: number;
  emoji: string;
  color: string;
  ingredients: [product: string, qty: number, display: string, optional?: boolean][];
  steps: (string | [string, number])[];
}

export const SEED_RECIPES: SeedRecipe[] = [
  {
    key: 'spaghetti_bolognese', title: 'Weeknight spaghetti bolognese', summary: 'A rich, slow-tasting ragù that is ready in 35 minutes.',
    cuisine: 'Italian', tags: ['pasta', 'family', 'batch-cook'], diet: [], difficulty: 'easy', servings: 4, prep: 10, cook: 25, emoji: '🍝', color: '#C8553D',
    ingredients: [['pasta', 400, '400 g spaghetti'], ['minced_beef', 500, '500 g minced beef'], ['onion', 1, '1 onion, finely chopped'], ['garlic', 2, '2 garlic cloves, crushed'],
      ['carrots', 100, '1 carrot, grated'], ['canned_tomatoes', 400, '1 tin chopped tomatoes'], ['tomato_paste', 70, '1 small tin tomato paste'], ['oregano', 2, '1 tsp dried oregano'],
      ['olive_oil', 15, '1 tbsp olive oil'], ['parmesan', 40, '40 g parmesan, to serve', true]],
    steps: ['Heat the oil in a wide pan. Fry the onion, carrot and garlic for 5 minutes until soft.', ['Add the mince and brown it well, breaking it up with a spoon.', 300],
      'Stir in the tomato paste for 1 minute, then add the tomatoes, oregano and a splash of water. Season.', ['Simmer gently while you cook the pasta.', 900],
      ['Cook the spaghetti in salted water until al dente.', 600], 'Toss the pasta with the sauce and serve with parmesan.'],
  },
  {
    key: 'chicken_curry', title: 'Creamy chicken coconut curry', summary: 'Mild, fragrant and on the table in under 30 minutes.',
    cuisine: 'Thai', tags: ['curry', 'quick', 'high-protein'], diet: ['gluten-free', 'dairy-free'], difficulty: 'easy', servings: 4, prep: 10, cook: 20, emoji: '🍛', color: '#E0A526',
    ingredients: [['chicken_breast', 500, '500 g chicken breast, in strips'], ['coconut_milk', 400, '1 tin coconut milk'], ['curry_paste', 50, '2 tbsp red curry paste'],
      ['bell_pepper', 2, '2 bell peppers, sliced'], ['onion', 1, '1 onion, sliced'], ['rice', 300, '300 g basmati rice'], ['lime', 1, '1 lime', true], ['coriander', 15, 'Fresh coriander', true],
      ['sunflower_oil', 15, '1 tbsp oil']],
    steps: [['Rinse the rice and cook it.', 720], 'Fry the curry paste in the oil for 1 minute until fragrant.', ['Add the chicken and onion and cook until the chicken is coloured.', 300],
      ['Add the peppers and coconut milk and simmer until the chicken is cooked through.', 600], 'Finish with lime juice and coriander. Serve with the rice.'],
  },
  {
    key: 'shakshuka', title: 'Shakshuka with feta', summary: 'Eggs poached in a spiced pepper and tomato sauce.',
    cuisine: 'Middle Eastern', tags: ['eggs', 'brunch', 'one-pan', 'quick'], diet: ['vegetarian', 'gluten-free'], difficulty: 'easy', servings: 2, prep: 5, cook: 20, emoji: '🍳', color: '#D1495B',
    ingredients: [['eggs', 4, '4 eggs'], ['canned_tomatoes', 400, '1 tin chopped tomatoes'], ['bell_pepper', 1, '1 bell pepper, diced'], ['onion', 1, '1 onion, diced'],
      ['garlic', 2, '2 garlic cloves'], ['cumin', 3, '1 tsp cumin'], ['paprika_powder', 3, '1 tsp paprika'], ['feta', 75, '75 g feta', true], ['bread', 140, '4 slices of bread', true], ['olive_oil', 15, '1 tbsp olive oil']],
    steps: [['Soften the onion and pepper in the oil.', 420], 'Add garlic and spices, cook 1 minute, then add the tomatoes.', ['Simmer until thickened.', 480],
      ['Make 4 hollows, crack in the eggs, cover and cook until the whites are set.', 360], 'Crumble over the feta and serve with bread.'],
  },
  {
    key: 'salmon_traybake', title: 'Salmon & vegetable traybake', summary: 'One tray, ten minutes of work, very little washing up.',
    cuisine: 'Nordic', tags: ['fish', 'traybake', 'high-protein'], diet: ['gluten-free', 'dairy-free'], difficulty: 'easy', servings: 2, prep: 10, cook: 25, emoji: '🐟', color: '#F28F3B',
    ingredients: [['salmon', 250, '2 salmon fillets'], ['potatoes', 500, '500 g potatoes, in wedges'], ['broccoli', 250, '½ head of broccoli'], ['lemon', 1, '1 lemon'],
      ['olive_oil', 30, '2 tbsp olive oil'], ['garlic', 1, '1 garlic clove']],
    steps: ['Heat the oven to 210 °C.', ['Toss the potatoes with half the oil and roast.', 900], 'Add the broccoli and salmon, drizzle with oil, garlic and lemon slices.',
      ['Roast until the salmon flakes easily.', 720], 'Squeeze over lemon and serve.'],
  },
  {
    key: 'stamppot', title: 'Spinach stamppot with smoked sausage', summary: 'Dutch comfort food: creamy mash with fresh spinach.',
    cuisine: 'Dutch', tags: ['comfort', 'winter', 'family'], diet: ['gluten-free'], difficulty: 'easy', servings: 4, prep: 10, cook: 25, emoji: '🥔', color: '#6A994E',
    ingredients: [['potatoes', 1200, '1.2 kg floury potatoes'], ['spinach', 300, '300 g spinach'], ['smoked_sausage', 275, '1 smoked sausage'], ['milk', 150, '150 ml milk'],
      ['butter', 30, '30 g butter'], ['mustard', 15, 'Mustard, to serve', true]],
    steps: [['Peel and boil the potatoes until tender.', 1200], ['Heat the sausage in hot water.', 600], 'Drain the potatoes and mash with warm milk and butter.',
      'Stir the raw spinach through the hot mash until it wilts. Season.', 'Serve with sliced sausage and mustard.'],
  },
  {
    key: 'veggie_stirfry', title: 'Tofu & vegetable stir-fry', summary: 'Crispy tofu, crunchy vegetables and a quick soy-ginger glaze.',
    cuisine: 'Chinese', tags: ['quick', 'stir-fry'], diet: ['vegan', 'vegetarian', 'dairy-free'], difficulty: 'easy', servings: 2, prep: 10, cook: 10, emoji: '🥢', color: '#386641',
    ingredients: [['tofu', 375, '1 block firm tofu, cubed'], ['wok_vegetables', 400, '400 g stir-fry vegetables'], ['noodles', 125, '125 g noodles'], ['soy_sauce', 45, '3 tbsp soy sauce'],
      ['ginger', 10, '1 thumb ginger, grated'], ['garlic', 2, '2 garlic cloves'], ['honey', 15, '1 tbsp honey (or sugar)'], ['sunflower_oil', 30, '2 tbsp oil'], ['spring_onion', 2, '2 spring onions', true]],
    steps: [['Cook the noodles, drain and rinse.', 240], ['Fry the tofu in oil until golden on all sides.', 360], 'Add vegetables, ginger and garlic and stir-fry on high heat for 3 minutes.',
      'Add noodles, soy sauce and honey and toss until glossy. Top with spring onion.'],
  },
  {
    key: 'overnight_oats', title: 'Overnight oats with berries', summary: 'Five minutes in the evening, breakfast is ready when you wake up.',
    cuisine: 'International', tags: ['breakfast', 'no-cook', 'meal-prep'], diet: ['vegetarian'], difficulty: 'easy', servings: 2, prep: 5, cook: 0, emoji: '🥣', color: '#7B5EA7',
    ingredients: [['oats', 100, '100 g rolled oats'], ['milk', 200, '200 ml milk'], ['yoghurt', 150, '150 g yoghurt'], ['berries', 125, '1 punnet berries'], ['honey', 15, '1 tbsp honey', true]],
    steps: ['Stir the oats, milk and yoghurt together in two jars.', 'Cover and refrigerate overnight.', 'Top with berries and honey in the morning.'],
  },
  {
    key: 'tomato_soup', title: 'Roasted tomato & red pepper soup', summary: 'Sweet, smoky and great for using up soft tomatoes.',
    cuisine: 'International', tags: ['soup', 'use-it-up', 'batch-cook'], diet: ['vegan', 'vegetarian', 'gluten-free', 'dairy-free'], difficulty: 'easy', servings: 4, prep: 10, cook: 35, emoji: '🍅', color: '#BC4749',
    ingredients: [['tomatoes', 6, '6 tomatoes, halved'], ['bell_pepper', 2, '2 red peppers'], ['onion', 1, '1 onion'], ['garlic', 3, '3 garlic cloves'], ['stock_cube', 1, '1 stock cube'],
      ['olive_oil', 30, '2 tbsp olive oil'], ['canned_tomatoes', 400, '1 tin chopped tomatoes'], ['basil', 15, 'Basil', true]],
    steps: ['Heat the oven to 200 °C.', ['Roast the tomatoes, peppers, onion and garlic with the oil.', 1500], 'Tip everything into a pan with the tinned tomatoes and 500 ml stock.',
      ['Simmer briefly, then blend until smooth.', 600], 'Season and serve with basil.'],
  },
  {
    key: 'pasta_pesto', title: '15-minute pesto pasta with peas', summary: 'Pantry-friendly, vibrant and quick.',
    cuisine: 'Italian', tags: ['pasta', 'quick', 'pantry'], diet: ['vegetarian'], difficulty: 'easy', servings: 2, prep: 2, cook: 12, emoji: '🌿', color: '#6A994E',
    ingredients: [['pasta', 200, '200 g pasta'], ['pesto', 95, '½ jar pesto'], ['frozen_peas', 150, '150 g frozen peas'], ['parmesan', 30, '30 g parmesan'], ['lemon', 1, '½ lemon', true]],
    steps: [['Cook the pasta; add the peas for the last 3 minutes.', 600], 'Drain, keeping a splash of cooking water.', 'Toss with pesto, a little water, lemon and parmesan.'],
  },
  {
    key: 'lentil_dal', title: 'Red lentil dal', summary: 'Cheap, comforting and packed with protein and fibre.',
    cuisine: 'Indian', tags: ['budget', 'batch-cook', 'high-protein'], diet: ['vegan', 'vegetarian', 'gluten-free', 'dairy-free'], difficulty: 'easy', servings: 4, prep: 10, cook: 25, emoji: '🫘', color: '#E09F3E',
    ingredients: [['lentils', 250, '250 g red lentils'], ['coconut_milk', 400, '1 tin coconut milk'], ['canned_tomatoes', 400, '1 tin chopped tomatoes'], ['onion', 1, '1 onion'],
      ['garlic', 3, '3 garlic cloves'], ['ginger', 15, '1 thumb ginger'], ['curry_powder', 10, '1 tbsp curry powder'], ['spinach', 100, '2 handfuls spinach', true], ['rice', 250, '250 g rice', true], ['sunflower_oil', 15, '1 tbsp oil']],
    steps: ['Soften the onion, garlic and ginger in the oil.', 'Add the curry powder and fry for 1 minute.', ['Add lentils, tomatoes, coconut milk and 400 ml water. Simmer until soft.', 1200],
      'Stir in the spinach until wilted. Serve with rice.'],
  },
  {
    key: 'chicken_wraps', title: 'Paprika chicken wraps', summary: 'Smoky chicken, crunchy salad and a quick yoghurt sauce.',
    cuisine: 'Mexican', tags: ['quick', 'high-protein', 'lunch'], diet: [], difficulty: 'easy', servings: 2, prep: 10, cook: 10, emoji: '🌯', color: '#D68C45',
    ingredients: [['chicken_breast', 300, '300 g chicken breast, in strips'], ['wraps', 4, '4 wraps'], ['paprika_powder', 5, '2 tsp smoked paprika'], ['lettuce', 100, 'Lettuce'],
      ['tomatoes', 2, '2 tomatoes'], ['cucumber', 0.5, '½ cucumber'], ['yoghurt', 100, '100 g yoghurt'], ['lime', 1, '1 lime', true], ['sunflower_oil', 15, '1 tbsp oil']],
    steps: ['Toss the chicken with paprika, salt and oil.', ['Fry in a hot pan until cooked through.', 480], 'Mix the yoghurt with lime juice and salt.', 'Fill the warmed wraps with salad, chicken and sauce.'],
  },
  {
    key: 'mushroom_risotto', title: 'Mushroom & parmesan risotto', summary: 'Patient stirring, big reward.',
    cuisine: 'Italian', tags: ['comfort', 'rice'], diet: ['vegetarian', 'gluten-free'], difficulty: 'medium', servings: 3, prep: 10, cook: 30, emoji: '🍄', color: '#8C6A4F',
    ingredients: [['rice', 250, '250 g risotto or other rice'], ['mushrooms', 250, '250 g mushrooms'], ['onion', 1, '1 onion'], ['garlic', 2, '2 garlic cloves'], ['stock_cube', 2, '2 stock cubes'],
      ['parmesan', 50, '50 g parmesan'], ['butter', 30, '30 g butter'], ['parsley', 10, 'Parsley', true]],
    steps: ['Dissolve the stock in 1 litre of hot water.', 'Fry the mushrooms in half the butter until golden; set aside.', 'Soften onion and garlic, add the rice and stir for 1 minute.',
      ['Add stock a ladle at a time, stirring, until the rice is creamy.', 1200], 'Stir in mushrooms, parmesan and the rest of the butter. Rest 2 minutes.'],
  },
  {
    key: 'greek_salad', title: 'Greek salad with chickpeas', summary: 'A crunchy no-cook dinner for warm evenings.',
    cuisine: 'Greek', tags: ['salad', 'no-cook', 'quick'], diet: ['vegetarian', 'gluten-free'], difficulty: 'easy', servings: 2, prep: 10, cook: 0, emoji: '🥗', color: '#4D908E',
    ingredients: [['cucumber', 1, '1 cucumber'], ['tomatoes', 3, '3 tomatoes'], ['red_onion', 0.5, '½ red onion'], ['feta', 150, '150 g feta'], ['chickpeas', 400, '1 tin chickpeas'],
      ['olive_oil', 30, '2 tbsp olive oil'], ['oregano', 1, 'Dried oregano'], ['lemon', 0.5, '½ lemon', true]],
    steps: ['Chop the cucumber, tomatoes and onion into chunks.', 'Rinse the chickpeas and add them.', 'Top with feta, oregano, olive oil and lemon.'],
  },
  {
    key: 'omelette', title: 'Cheese & vegetable omelette', summary: 'The fastest way to use up odds and ends.',
    cuisine: 'French', tags: ['eggs', 'quick', 'use-it-up', 'breakfast'], diet: ['vegetarian', 'gluten-free'], difficulty: 'easy', servings: 1, prep: 5, cook: 5, emoji: '🧀', color: '#E9C46A',
    ingredients: [['eggs', 3, '3 eggs'], ['cheese', 30, '30 g cheese, grated'], ['spinach', 40, 'Handful of spinach', true], ['mushrooms', 60, 'A few mushrooms', true], ['butter', 10, 'Knob of butter']],
    steps: ['Beat the eggs with salt and pepper.', 'Fry any vegetables in the butter for 2 minutes.', ['Pour in the eggs and cook until almost set.', 120], 'Add the cheese, fold and serve.'],
  },
  {
    key: 'chili', title: 'Smoky bean & beef chili', summary: 'Makes plenty and freezes beautifully.',
    cuisine: 'Mexican', tags: ['batch-cook', 'freezer-friendly', 'high-protein'], diet: ['gluten-free', 'dairy-free'], difficulty: 'easy', servings: 6, prep: 15, cook: 45, emoji: '🌶️', color: '#9E2A2B',
    ingredients: [['minced_beef', 500, '500 g minced beef'], ['kidney_beans', 800, '2 tins kidney beans'], ['canned_tomatoes', 800, '2 tins chopped tomatoes'], ['onion', 2, '2 onions'],
      ['bell_pepper', 2, '2 peppers'], ['garlic', 3, '3 garlic cloves'], ['cumin', 6, '2 tsp cumin'], ['paprika_powder', 6, '2 tsp smoked paprika'], ['chili', 1, '1 chilli'],
      ['rice', 400, '400 g rice', true], ['sunflower_oil', 15, '1 tbsp oil']],
    steps: ['Brown the mince in a large pot; remove.', 'Soften onions, peppers, garlic and chilli. Add the spices.', ['Return the mince with tomatoes and beans. Simmer gently.', 2400], 'Season and serve with rice. Freeze leftovers in portions.'],
  },
  {
    key: 'fried_rice', title: 'Egg fried rice', summary: 'Best with yesterday\'s rice, done in 10 minutes.',
    cuisine: 'Chinese', tags: ['quick', 'use-it-up', 'leftovers'], diet: ['vegetarian', 'dairy-free'], difficulty: 'easy', servings: 2, prep: 5, cook: 10, emoji: '🍚', color: '#F4A259',
    ingredients: [['rice', 200, '200 g rice (cooked weight ~500 g)'], ['eggs', 2, '2 eggs'], ['frozen_peas', 100, '100 g peas'], ['carrots', 80, '1 carrot, diced'],
      ['spring_onion', 3, '3 spring onions'], ['soy_sauce', 30, '2 tbsp soy sauce'], ['sunflower_oil', 30, '2 tbsp oil']],
    steps: ['Fry carrot and peas in hot oil for 2 minutes.', 'Push aside, scramble the eggs, then mix in.', ['Add the rice and fry until hot and slightly crisp.', 240], 'Season with soy sauce and top with spring onion.'],
  },
  {
    key: 'yoghurt_bowl', title: 'Greek yoghurt power bowl', summary: '30 g of protein before 8 am.',
    cuisine: 'International', tags: ['breakfast', 'high-protein', 'no-cook', 'quick'], diet: ['vegetarian', 'gluten-free'], difficulty: 'easy', servings: 1, prep: 3, cook: 0, emoji: '🫐', color: '#5E60CE',
    ingredients: [['skyr', 250, '250 g skyr or Greek yoghurt'], ['berries', 60, 'Handful of berries'], ['breakfast_cereal', 40, '40 g granola'], ['nuts', 15, 'Some nuts', true], ['honey', 10, 'Drizzle of honey', true]],
    steps: ['Spoon the skyr into a bowl.', 'Top with berries, granola and nuts. Drizzle with honey.'],
  },
  {
    key: 'chicken_thigh_traybake', title: 'Lemon chicken thighs with potatoes', summary: 'Crispy skin-on flavour without the effort.',
    cuisine: 'Mediterranean', tags: ['traybake', 'family', 'high-protein'], diet: ['gluten-free', 'dairy-free'], difficulty: 'easy', servings: 4, prep: 10, cook: 40, emoji: '🍋', color: '#C9A227',
    ingredients: [['chicken_thigh', 600, '600 g chicken thighs'], ['potatoes', 800, '800 g potatoes'], ['lemon', 1, '1 lemon'], ['garlic', 4, '4 garlic cloves'], ['oregano', 2, '1 tsp oregano'],
      ['olive_oil', 30, '2 tbsp olive oil'], ['green_beans', 300, '300 g green beans', true]],
    steps: ['Heat the oven to 200 °C.', 'Toss everything (except beans) with oil, lemon juice, oregano and salt in a tray.', ['Roast, turning once.', 2100], ['Add the beans for the last 10 minutes.', 600]],
  },
  {
    key: 'tuna_pasta_salad', title: 'Tuna pasta salad', summary: 'A lunchbox favourite that keeps for days.',
    cuisine: 'Italian', tags: ['lunch', 'meal-prep', 'high-protein'], diet: ['dairy-free'], difficulty: 'easy', servings: 3, prep: 10, cook: 10, emoji: '🥫', color: '#457B9D',
    ingredients: [['pasta', 250, '250 g pasta'], ['tuna', 145, '1 tin tuna'], ['cherry_tomatoes', 200, '200 g cherry tomatoes'], ['cucumber', 0.5, '½ cucumber'], ['red_onion', 0.5, '½ red onion'],
      ['mayonnaise', 45, '3 tbsp mayonnaise'], ['lemon', 0.5, '½ lemon', true]],
    steps: [['Cook the pasta, then rinse under cold water.', 600], 'Mix the tuna with mayonnaise and lemon.', 'Fold through the pasta with the chopped vegetables.'],
  },
  {
    key: 'pancakes', title: 'Dutch pannenkoeken', summary: 'Thin, large pancakes: sweet or savoury.',
    cuisine: 'Dutch', tags: ['weekend', 'family', 'sweet'], diet: ['vegetarian'], difficulty: 'easy', servings: 4, prep: 10, cook: 25, emoji: '🥞', color: '#E76F51',
    ingredients: [['flour', 250, '250 g flour'], ['milk', 500, '500 ml milk'], ['eggs', 2, '2 eggs'], ['butter', 40, 'Butter for frying'], ['bacon', 150, 'Bacon, for savoury pancakes', true], ['cheese', 80, 'Cheese', true]],
    steps: ['Whisk the flour with half the milk to a smooth batter, then add the rest of the milk and the eggs.', 'Rest the batter for 10 minutes if you can.',
      ['Fry thin pancakes in butter, about 2 minutes per side.', 120], 'Top with bacon and cheese, or syrup and sugar.'],
  },
  {
    key: 'veg_soup', title: 'Clear-out-the-fridge vegetable soup', summary: 'Turns tired vegetables into four bowls of dinner.',
    cuisine: 'International', tags: ['soup', 'use-it-up', 'budget', 'batch-cook'], diet: ['vegan', 'vegetarian', 'gluten-free', 'dairy-free'], difficulty: 'easy', servings: 4, prep: 15, cook: 25, emoji: '🥕', color: '#F77F00',
    ingredients: [['carrots', 300, '3 carrots'], ['leek', 1, '1 leek'], ['potatoes', 300, '2 potatoes'], ['zucchini', 1, '1 courgette', true], ['onion', 1, '1 onion'], ['stock_cube', 2, '2 stock cubes'], ['olive_oil', 15, '1 tbsp olive oil'], ['parsley', 10, 'Parsley', true]],
    steps: ['Chop all vegetables into small chunks.', 'Soften the onion and leek in the oil.', ['Add the rest with 1.2 litres of stock and simmer.', 1200], 'Blend half for a thicker soup. Season and finish with parsley.'],
  },
];
