import type { Db } from './db.ts';
import { newId } from './db.ts';
import { CATALOGUE } from './catalogue.ts';
import { SEED_RECIPES } from './recipes-seed.ts';
import { MORE_RECIPES } from './recipes-seed-2.ts';
import { DAYTIME_RECIPES } from './recipes-seed-3.ts';
import { EUROPEAN_RECIPES } from './recipes-seed-4.ts';
import { WORLD_RECIPES } from './recipes-seed-5.ts';
import { WEEKNIGHT_RECIPES } from './recipes-seed-6.ts';
import { NUTRITION_SOURCE } from './nutrition-data.ts';
import { listedPackSizes } from '../import/retail.ts';
import { FAMILY_OF, SUBCATEGORY, PACKS, SUBSTITUTIONS, FOREIGN, AVAILABILITY, COUNTRIES, CHAINS, measureFor } from './ingredient-knowledge.ts';
import { clock, addDays } from '../clock.ts';
import { log } from '../log.ts';
import { hashPassword } from '../http/auth.ts';
import { addStock, deduct, newCtx, setProductQuantity } from '../domain/ledger.ts';
import { getProduct } from '../domain/products.ts';
import { createRecipe } from '../domain/recipes.ts';

// Test credentials for the local demo household. Change or remove for a real deployment (SEED_DEMO=0).
export const DEMO_USER = { email: 'demo@larder.test', password: 'larder-demo-2026', name: 'Demo' };

/** Upsert the built-in catalogue and recipes. Safe to run on every start. */
export function seedCatalogue(db: Db) {
  const now = clock.iso();
  db.tx(() => {
    for (const p of CATALOGUE) {
      const exists = db.get('SELECT 1 FROM products WHERE id = ?', p.id);
      const row = {
        name: p.name, name_nl: p.name_nl, category: p.category, unit: p.unit, package_size: p.package_size, piece_size: p.piece_size, piece_name: p.piece_name,
        default_location: p.default_location, shelf_life_days: p.shelf_life_days, opened_life_days: p.opened_life_days, freezer_life_days: p.freezer_life_days,
        synonyms: p.synonyms, nutrition: p.nutrition, nutrition_basis: 'per100', nutrition_source: NUTRITION_SOURCE, density: p.density, staple: p.staple,
        // Typical sizes from the table, plus any size seen in at least two Dutch supermarket listings.
        package_options: [...new Set([...(p.package_options.length ? p.package_options : PACKS[p.id.slice(2)] ?? []), ...listedPackSizes(db, p.id)])].sort((a, b) => a - b),
        allergens: p.allergens, diet_flags: p.diet_flags,
        family: FAMILY_OF[p.id] ?? null, subcategory: SUBCATEGORY[p.id] ?? null, measure: measureFor(p),
      };
      if (exists) db.update('products', p.id, row);
      else db.insert('products', { id: p.id, household_id: null, price: p.price, created_at: now, ...row });
    }
    seedKnowledge(db);
    // The app was renamed from Larder to PantryPip; built-in recipes follow.
    db.run("UPDATE recipes SET source_name = 'PantryPip kitchen' WHERE origin = 'builtin' AND source_name = 'Larder kitchen'");
    for (const r of [...SEED_RECIPES, ...MORE_RECIPES, ...DAYTIME_RECIPES, ...EUROPEAN_RECIPES, ...WORLD_RECIPES, ...WEEKNIGHT_RECIPES]) {
      const id = `r_${r.key}`;
      if (db.get('SELECT 1 FROM recipes WHERE id = ?', id)) continue;
      createRecipe(db, null, {
        title: r.title, summary: r.summary, cuisine: r.cuisine, tags: r.tags, diet: r.diet, difficulty: r.difficulty, servings: r.servings,
        prep_minutes: r.prep, cook_minutes: r.cook, emoji: r.emoji, color: r.color, origin: 'builtin', source_name: 'PantryPip kitchen',
        steps: r.steps.map((s) => (Array.isArray(s) ? { text: s[0], timerSeconds: s[1] } : { text: s })),
        ingredients: r.ingredients.map(([pid, qty, display, optional]) => {
          const p = getProduct(db, `p_${pid}`);
          if (!p) throw new Error(`Seed recipe ${r.key}: unknown product ${pid}`);
          return { product_id: p.id, name: p.name, quantity: qty, unit: p.unit, display, optional: !!optional };
        }),
      }, id);
    }
  });
}

/**
 * Countries, chains, availability, foreign ingredients and substitutions from ingredient-knowledge.ts.
 * Rewritten on every start (built-in rows only); retail_products and household choices are left alone.
 */
function seedKnowledge(db: Db) {
  for (const c of COUNTRIES) db.run('INSERT INTO countries (code, name, name_nl, supported, measure) VALUES (?, ?, ?, ?, ?) ON CONFLICT(code) DO UPDATE SET name = excluded.name, name_nl = excluded.name_nl, supported = excluded.supported, measure = excluded.measure', c.code, c.name, c.name_nl, c.supported ? 1 : 0, c.measure);
  for (const c of CHAINS) db.run('INSERT INTO chains (id, country, name, online) VALUES (?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET country = excluded.country, name = excluded.name, online = excluded.online', c.id, c.country, c.name, c.online ? 1 : 0);
  db.run("DELETE FROM ingredient_availability WHERE source = 'pantrypip-table'");
  for (const [country, map] of Object.entries(AVAILABILITY)) for (const [pid, status] of Object.entries(map)) db.run("INSERT OR REPLACE INTO ingredient_availability (country, product_id, status, source) VALUES (?, ?, ?, 'pantrypip-table')", country, pid, status);
  db.run('DELETE FROM foreign_ingredients');
  for (const f of FOREIGN) for (const [country, status] of Object.entries(f.status)) db.run('INSERT INTO foreign_ingredients (key, country, names, status) VALUES (?, ?, ?, ?)', f.key, country, JSON.stringify(f.names), status);
  db.run("DELETE FROM substitutions WHERE source = 'pantrypip-table'");
  SUBSTITUTIONS.forEach((x, i) => db.insert('substitutions', {
    id: `sub_${i}_${x.from.replace(/[^a-z0-9]/gi, '')}_${x.to.slice(2)}`, from_key: x.from, to_product: x.to, extra: x.with ?? [], kind: x.kind, ratio: x.ratio ?? 1,
    countries: x.countries ?? [], note: x.note, prep: x.prep ?? null, identity: x.identity ? 1 : 0, source: 'pantrypip-table', sort: i,
  }));
}

export function createHousehold(db: Db, name: string, locale = 'nl'): string {
  const id = newId('h');
  db.insert('households', { id, name, invite_code: newId('inv').slice(4, 14).toUpperCase(), locale, created_at: clock.iso() });
  const locs: [string, 'fridge' | 'freezer' | 'pantry'][] = [['Fridge', 'fridge'], ['Freezer', 'freezer'], ['Pantry', 'pantry']];
  locs.forEach(([n, kind], i) => db.insert('storage_locations', { id: newId('loc'), household_id: id, name: n, kind, sort: i }));
  return id;
}

/**
 * Demo household with ten weeks of realistic purchase history, so predictions,
 * suggestions and analytics have something to work with on first launch.
 */
export function seedDemo(db: Db) {
  if (db.get('SELECT 1 FROM users WHERE email = ?', DEMO_USER.email)) return;
  const realNow = clock.now();
  const hid = createHousehold(db, 'Demo household');
  db.insert('users', { id: newId('u'), household_id: hid, email: DEMO_USER.email, name: DEMO_USER.name, password_hash: hashPassword(DEMO_USER.password), created_at: clock.iso() });
  const pref = (key: string, value: unknown) => db.run("INSERT OR REPLACE INTO preferences (household_id, user_id, key, value) VALUES (?, '', ?, ?)", hid, key, JSON.stringify(value));
  pref('householdSize', 2);
  pref('quickActions', [
    { productId: 'p_milk', quantity: 250, label: '250 ml milk' },
    { productId: 'p_eggs', quantity: 2, label: '2 eggs' },
    { productId: 'p_bread', quantity: 70, label: '2 slices bread' },
    { productId: 'p_butter', quantity: 30, label: '30 g butter' },
  ]);

  // Regulars: [product, interval days, packages per trip, logged share of consumption]
  const regulars: [string, number, number][] = [
    ['milk', 4, 2], ['bread', 4, 1], ['eggs', 8, 1], ['bananas', 7, 1], ['coffee', 21, 1], ['chicken_breast', 7, 1],
    ['yoghurt', 6, 1], ['cheese', 14, 1], ['apples', 10, 1], ['butter', 18, 1], ['pasta', 14, 1], ['tomatoes', 7, 1],
    ['onion', 14, 1], ['orange_juice', 7, 1], ['spinach', 9, 1], ['oats', 20, 1],
  ];
  const start = new Date(realNow.getTime() - 70 * 86_400_000);
  db.tx(() => {
    for (const [key, interval, packs] of regulars) {
      const p = getProduct(db, `p_${key}`)!;
      let t = start.getTime() + Math.random() * interval * 86_400_000;
      let prevLot: string | null = null;
      while (t < realNow.getTime()) {
        clock.set(new Date(t));
        // Previous purchase is used up by now (unlogged, as in real life): close it with an adjustment.
        if (prevLot) {
          const ctx = newCtx(db, hid, 'manual');
          const lot = db.get<{ quantity: number }>('SELECT quantity FROM inventory_lots WHERE id = ?', prevLot)!;
          if (lot.quantity > 0) deduct(ctx, { lotId: prevLot, quantity: 'all', type: 'adjust', meta: { seed: true } });
        }
        const ctx = newCtx(db, hid, Math.random() < 0.6 ? 'receipt' : 'shopping_list');
        const store = Math.random() < 0.7 ? 'Albert Heijn' : 'Jumbo';
        const price = (p.price ?? 2) * (0.92 + Math.random() * 0.16);
        const { lot } = addStock(ctx, { productId: p.id, quantity: p.package_size * packs, packages: packs, totalPrice: Math.round(price * packs * 100) / 100, store });
        prevLot = lot.id;
        t += (interval + (Math.random() - 0.5) * interval * 0.4) * 86_400_000;
      }
    }
    clock.set(null);

    // Today's state: some things partly used (confirmed by the user a few days ago), a few extras.
    const extras: [string, number, string | null, number][] = [
      // product, quantity, location, days ago purchased
      ['minced_beef', 500, 'fridge', 1], ['canned_tomatoes', 800, null, 12], ['rice', 1000, null, 20], ['garlic', 20, null, 15],
      ['bell_pepper', 2, null, 3], ['frozen_peas', 450, 'freezer', 30], ['coconut_milk', 400, null, 25], ['curry_paste', 100, null, 40],
      ['olive_oil', 400, null, 30], ['salt', 400, null, 90], ['pepper', 40, null, 90], ['cumin', 30, null, 60], ['paprika_powder', 30, null, 60],
      ['oregano', 10, null, 60], ['stock_cube', 8, null, 50], ['soy_sauce', 200, null, 40], ['lentils', 500, null, 35], ['parmesan', 120, null, 6],
      ['carrots', 600, null, 5], ['potatoes', 1500, null, 6], ['mushrooms', 250, null, 2], ['feta', 200, null, 9], ['lemon', 2, null, 6],
      ['frozen_berries', 300, 'freezer', 20], ['honey', 300, null, 60], ['flour', 800, null, 60], ['sunflower_oil', 700, null, 50],
    ];
    for (const [key, qty, loc, ago] of extras) {
      clock.set(new Date(realNow.getTime() - ago * 86_400_000));
      const p = getProduct(db, `p_${key}`)!;
      addStock(newCtx(db, hid, 'receipt'), { productId: p.id, quantity: qty, location: loc, packages: qty / p.package_size, totalPrice: p.price ?? null, store: 'Albert Heijn' });
    }
    // The user told us a few days ago how much was left of some items.
    clock.set(new Date(realNow.getTime() - 2 * 86_400_000));
    setProductQuantity(newCtx(db, hid, 'voice'), 'p_eggs', 4);
    setProductQuantity(newCtx(db, hid, 'voice'), 'p_cheese', 150);
    // Spinach is about to go off.
    db.run("UPDATE inventory_lots SET expires_on = ? WHERE household_id = ? AND product_id = 'p_spinach' AND status = 'active'", addDays(realNow.toISOString().slice(0, 10), 1), hid);

    // Leftovers
    clock.set(new Date(realNow.getTime() - 20 * 86_400_000));
    addStock(newCtx(db, hid, 'recipe'), { quantity: 2, unit: 'portion', label: 'Lasagna', isLeftover: true, location: 'freezer', type: 'leftover', expiresOn: addDays(realNow.toISOString().slice(0, 10), 70) });
    clock.set(new Date(realNow.getTime() - 1 * 86_400_000));
    addStock(newCtx(db, hid, 'recipe'), { quantity: 1, unit: 'portion', label: 'Smoky bean & beef chili', isLeftover: true, recipeId: 'r_chili', location: 'fridge', type: 'leftover', expiresOn: addDays(realNow.toISOString().slice(0, 10), 2) });
    clock.set(null);

    // Meal plan for this week
    const today = clock.today();
    const plan: [number, string, string, number][] = [
      [0, 'dinner', 'r_spaghetti_bolognese', 2], [1, 'dinner', 'r_chicken_curry', 2], [2, 'dinner', 'r_shakshuka', 2],
      [3, 'dinner', 'r_salmon_traybake', 2], [1, 'breakfast', 'r_overnight_oats', 2], [5, 'dinner', 'r_lentil_dal', 4],
    ];
    for (const [d, meal, rid, servings] of plan) {
      db.insert('meal_slots', { id: newId('ms'), household_id: hid, date: addDays(today, d), meal, position: 0, recipe_id: rid, servings, status: 'planned', created_at: clock.iso() });
    }
    // A couple of manual list items
    for (const [pid, n] of [['p_sparkling_water', 2], ['p_crisps', 1]] as const) {
      const p = getProduct(db, pid)!;
      db.insert('shopping_items', { id: newId('si'), household_id: hid, product_id: p.id, name: p.name, quantity: p.package_size * n, unit: p.unit, packages: n, category: p.category, reason: 'manual', plan_driven: 0, checked: 0, created_at: clock.iso(), updated_at: clock.iso() });
    }
    // Ten weeks of cooking history (for "Your year in food"): most evenings, favourites more often.
    const favourites = ['r_chicken_curry', 'r_chicken_curry', 'r_spaghetti_bolognese', 'r_spaghetti_bolognese', 'r_stamppot', 'r_shakshuka', 'r_lentil_dal', 'r_veggie_stirfry', 'r_salmon_traybake', 'r_omelette', 'r_chili', 'r_pasta_pesto', 'r_pancakes'];
    for (let d = 70; d >= 1; d--) {
      if (d % 9 === 4 || d % 13 === 7) continue; // nights out
      const rid = favourites[(d * 7) % favourites.length];
      db.insert('cook_log', { id: newId('ck'), household_id: hid, recipe_id: rid, servings: 2, batch_id: newId('b'), created_at: new Date(realNow.getTime() - d * 86_400_000 + 3_600_000).toISOString() });
    }
    pref('people', [{ id: 'me', name: DEMO_USER.name, diets: [], allergies: [], avoid: [], kcal: 2200, protein: 90 }]);
    db.run("INSERT OR REPLACE INTO recipe_interactions (household_id, recipe_id, saved, rating, cooked_count, last_cooked_at) VALUES (?, 'r_chicken_curry', 1, 5, 4, ?)", hid, addDays(today, -12));
    db.run("INSERT OR REPLACE INTO recipe_interactions (household_id, recipe_id, saved, rating, cooked_count, last_cooked_at) VALUES (?, 'r_stamppot', 1, 4, 2, ?)", hid, addDays(today, -30));
  });
  clock.set(null);
  log.info('demo household seeded', { email: DEMO_USER.email });
  return hid;
}
