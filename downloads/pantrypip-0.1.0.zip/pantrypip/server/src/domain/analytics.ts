// Spending, waste and consumption statistics.
import type { Db } from '../db/db.ts';
import { clock, addDays } from '../clock.ts';

export function analytics(db: Db, householdId: string, days = 90) {
  const from = addDays(clock.today(), -days);
  const notUndone = 'NOT EXISTS (SELECT 1 FROM inventory_events u WHERE u.reverses_event_id = e.id)';
  const weekly = db.all<{ week: string; total: number }>(
    `SELECT strftime('%Y-W%W', purchased_at) week, ROUND(SUM(COALESCE(total_price, 0)), 2) total FROM purchases
     WHERE household_id = ? AND purchased_at >= ? GROUP BY week ORDER BY week`,
    householdId,
    from,
  );
  const monthly = db.all<{ month: string; total: number }>(
    `SELECT substr(purchased_at, 1, 7) month, ROUND(SUM(COALESCE(total_price, 0)), 2) total FROM purchases
     WHERE household_id = ? GROUP BY month ORDER BY month DESC LIMIT 12`,
    householdId,
  );
  const topProducts = db.all<{ product_id: string; name: string; times: number; spent: number }>(
    `SELECT pu.product_id, p.name, COUNT(DISTINCT substr(pu.purchased_at,1,10)) times, ROUND(SUM(COALESCE(pu.total_price,0)),2) spent
     FROM purchases pu JOIN products p ON p.id = pu.product_id WHERE pu.household_id = ? AND pu.purchased_at >= ?
     GROUP BY pu.product_id ORDER BY times DESC, spent DESC LIMIT 10`,
    householdId,
    from,
  );
  const waste = db.all<{ product_id: string | null; name: string; events: number; quantity: number; unit: string; value: number }>(
    `SELECT e.product_id, COALESCE(p.name, l.label, 'Leftovers') name, COUNT(*) events, ROUND(SUM(-e.delta), 1) quantity, e.unit,
       ROUND(SUM(-e.delta * COALESCE(l.unit_price, 0)), 2) value
     FROM inventory_events e LEFT JOIN products p ON p.id = e.product_id JOIN inventory_lots l ON l.id = e.lot_id
     WHERE e.household_id = ? AND e.type = 'discard' AND e.created_at >= ? AND ${notUndone}
     GROUP BY COALESCE(e.product_id, l.label) ORDER BY value DESC, events DESC LIMIT 10`,
    householdId,
    from,
  );
  const wasteReasons = db.all<{ reason: string; events: number }>(
    `SELECT COALESCE(reason, 'other') reason, COUNT(*) events FROM inventory_events e
     WHERE household_id = ? AND type = 'discard' AND created_at >= ? AND ${notUndone} GROUP BY reason`,
    householdId,
    from,
  );
  const priceHistory = db.all<{ product_id: string; name: string; date: string; unit_price: number }>(
    `SELECT pu.product_id, p.name, substr(pu.purchased_at, 1, 10) date, ROUND(pu.total_price / pu.packages, 2) unit_price
     FROM purchases pu JOIN products p ON p.id = pu.product_id
     WHERE pu.household_id = ? AND pu.total_price IS NOT NULL AND pu.packages > 0 AND pu.purchased_at >= ?
     ORDER BY pu.purchased_at`,
    householdId,
    addDays(clock.today(), -365),
  );
  const spent = db.get<{ total: number }>('SELECT ROUND(SUM(COALESCE(total_price,0)),2) total FROM purchases WHERE household_id = ? AND purchased_at >= ?', householdId, from)?.total ?? 0;
  const wasted = waste.reduce((s, w) => s + w.value, 0);
  const inputs = db.all<{ source: string; events: number }>(
    `SELECT source, COUNT(*) events FROM inventory_events WHERE household_id = ? AND created_at >= ? AND type != 'undo' GROUP BY source ORDER BY events DESC`,
    householdId,
    from,
  );
  return { days, spent, wasted: Math.round(wasted * 100) / 100, weekly, monthly, topProducts, waste, wasteReasons, priceHistory, inputs };
}
