// "Plan my week": picks a dinner for every open day in one go, walking through the week with a simulated
// stock. Each recipe gets an explainable score: enjoyment (rating, favourite, how often), learned
// preferences, novelty, stock use and spoilage risk (FIFO), extra purchases, ingredient overlap with the
// rest of the week, variety and recency. Locked meals are never touched.
import type { Db } from '../db/db.ts';
import { parseJson } from '../db/db.ts';
import { clock, addDays, daysBetween } from '../clock.ts';
import { listRecipes, suitabilityFor, recordInteraction, costFor, type Recipe } from './recipes.ts';
import { dietaryNeeds } from './dietary.ts';
import { mealScore, isVeg, gramsOf } from './health.ts';
import { targetsFor } from './targets.ts';
import { learnedProfile } from './learn.ts';
import { householdSetting } from './settings.ts';
import { displayName, getProduct } from './products.ts';
import { addSlot, updateSlot, getSlot, type MealSlot } from './planner.ts';

/** Recipes with these tags aren't dinners, so the week planner leaves them out. */
const NOT_DINNER = ['breakfast', 'snack', 'dessert', 'baking', 'sandwich', 'side', 'drink'];

export type FifoMode = 'off' | 'balanced' | 'strong';

export interface AutoPlanOptions {
  start?: string;
  days?: number;
  servings?: number;
  /** How hard to push food that spoils first. `true`/`false` are accepted as balanced/off. */
  fifo?: FifoMode | boolean;
  /** Mon–Thu dinners at most this many minutes (null = no limit). */
  maxWeeknightMinutes?: number | null;
  /** Re-plan days that already have a planned (not cooked, not locked) dinner. */
  replace?: boolean;
  /** Different number = different (but equally good) plan. */
  seed?: number;
  /** Recipe ids not to use (e.g. "swap this day"). */
  avoid?: string[];
  /** Only plan these dates (e.g. swapping one day). */
  only?: string[];
}

export interface PlannedDay {
  date: string;
  recipeId: string | null;
  slotId?: string | null;
  title: string;
  emoji: string | null;
  color: string | null;
  minutes: number;
  kcal: number | null;
  health: number;
  reasons: string[];
  usesUp: string[];
  /** Score breakdown, biggest factors first. */
  why: { factor: string; points: number }[];
  extraCost: number;
  existing: boolean;
  locked: boolean;
}

/** Above 1.5× this many candidates, the week is planned from a shortlist (see proposeWeek). */
const SHORTLIST = 500;
const PRIORITY_WEIGHT: Record<number, number> = { [-1]: -0.5, 0: 0, 1: 0.45, 2: 0.9 };
const FIFO_WEIGHT: Record<FifoMode, number> = { off: 0, balanced: 1.2, strong: 3 };
const FIFO_CAP: Record<FifoMode, number> = { off: 0, balanced: 2, strong: 6 };

/** Small deterministic PRNG so "shuffle" gives a new plan and the same seed gives the same plan. */
function rng(seed: number) {
  let a = seed >>> 0 || 1;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const toMode = (v: unknown): FifoMode => (v === true ? 'balanced' : v === false ? 'off' : v === 'off' || v === 'strong' || v === 'balanced' ? v : 'balanced');

export function autoPlanPrefs(db: Db, householdId: string) {
  // Validated reads (settings.ts): a broken or outdated stored value falls back to the default.
  const get = (k: string, _d: any) => householdSetting(db, householdId, k as any);
  return {
    favouriteFoods: get('favouriteFoods', []) as string[],
    fifo: toMode(get('autoPlanFifo', 'balanced')),
    maxWeeknightMinutes: get('maxWeeknightMinutes', 45) as number | null,
    householdSize: get('householdSize', 2) as number,
    // Personalisation (Settings → Personalise). Defaults leave the planner as it was.
    planDays: get('planDays', [0, 1, 2, 3, 4, 5, 6]) as number[],
    planningDay: get('planningDay', 0) as number,
    maxWeekendMinutes: get('maxWeekendMinutes', null) as number | null,
    maxDifficulty: get('maxDifficulty', 'hard') as 'easy' | 'medium' | 'hard',
    mealTypes: get('mealTypes', []) as string[],
    cuisines: get('cuisines', []) as string[],
    ratingWeight: get('ratingWeight', 'normal') as Level,
    overlap: get('overlap', 'normal') as Level,
    variety: get('variety', 'normal') as Level,
    budgetPerServing: get('budgetPerServing', null) as number | null,
    newPerWeek: get('newPerWeek', null) as number | null,
    nutritionPriorities: get('nutritionPriorities', []) as string[],
  };
}

type Level = 'low' | 'normal' | 'high';
const MULT: Record<Level, Record<'rating' | 'overlap' | 'variety', number>> = {
  low: { rating: 0.5, overlap: 0.4, variety: 0.5 },
  normal: { rating: 1, overlap: 1, variety: 1 },
  high: { rating: 1.6, overlap: 1.8, variety: 1.6 },
};
const DIFFICULTY: Record<string, number> = { easy: 0, medium: 1, hard: 2 };

interface SimLot { qty: number; expires: string | null; added: string; opened: boolean }

/**
 * Spoilage risk of the first lot of a product on a given day: perishability (short shelf life) times
 * closeness to expiry, higher when opened. Dry goods are never urgent just because they're old.
 */
export function riskOf(lot: SimLot, shelfLife: number | null, date: string): number {
  const perish = Math.max(0.1, Math.min(1, 7 / Math.max(1, shelfLife ?? 30)));
  const left = lot.expires ? daysBetween(date, lot.expires) : null;
  if (left != null && left < 0) return 0; // would already be off by then
  const time = left == null ? Math.min(0.3, daysBetween(lot.added, date) / 60) : 1 / (1 + left);
  return perish * time * (lot.opened ? 1.4 : 1);
}

const isStaple = (p: { staple?: boolean; category?: string } | null | undefined) => !!p && (p.staple || p.category === 'spices');

export function proposeWeek(db: Db, householdId: string, o: AutoPlanOptions = {}) {
  const prefs = autoPlanPrefs(db, householdId);
  const start = o.start ?? clock.today();
  const days = Math.min(14, o.days ?? 7);
  const servings = o.servings ?? prefs.householdSize;
  const fifo = o.fifo === undefined ? prefs.fifo : toMode(o.fifo);
  const maxWeeknight = o.maxWeeknightMinutes === undefined ? prefs.maxWeeknightMinutes : o.maxWeeknightMinutes;
  const random = rng(o.seed ?? 1);
  const needs = dietaryNeeds(db, householdId);
  const targets = targetsFor(db, householdId);
  const favourites = new Set(prefs.favouriteFoods);
  const all = listRecipes(db, householdId);
  const byId = new Map(all.map((r) => [r.id, r]));
  const learned = learnedProfile(db, householdId, byId);

  const inter = new Map(db.all<any>('SELECT * FROM recipe_interactions WHERE household_id = ?', householdId).map((r) => [r.recipe_id, r]));
  const triedCount = [...inter.values()].filter((i) => i.cooked_count > 0).length;
  // Exploration bonus for untried recipes, smaller once you've built up favourites.
  const novelty = triedCount < 8 ? 0.4 : triedCount < 20 ? 0.3 : 0.2;
  const candidates = all.filter((r) => {
    if (NOT_DINNER.some((t) => r.tags.includes(t))) return false;
    if ((inter.get(r.id)?.priority ?? 0) <= -2) return false;
    if (o.avoid?.includes(r.id)) return false;
    const s = suitabilityFor(db, r, needs);
    return s.ok || s.adaptable;
  });

  const productCache = new Map<string, ReturnType<typeof getProduct>>();
  const product = (id: string) => {
    if (!productCache.has(id)) productCache.set(id, getProduct(db, id));
    return productCache.get(id);
  };

  // Stock to simulate, soonest-expiring / oldest first.
  const stock = new Map<string, SimLot[]>();
  for (const l of db.all<any>("SELECT product_id, quantity, expires_on, opened_at, COALESCE(purchased_at, created_at) added FROM inventory_lots WHERE household_id = ? AND status = 'active' AND is_leftover = 0 AND product_id IS NOT NULL AND quantity > 0", householdId)) {
    const list = stock.get(l.product_id) ?? [];
    list.push({ qty: l.quantity, expires: l.expires_on, added: l.added, opened: !!l.opened_at });
    stock.set(l.product_id, list);
  }
  for (const list of stock.values()) list.sort((a, b) => (a.expires ?? '9999').localeCompare(b.expires ?? '9999') || a.added.localeCompare(b.added));
  const have = (pid: string) => (stock.get(pid) ?? []).reduce((s, l) => s + l.qty, 0);
  const take = (pid: string, qty: number) => {
    for (const l of stock.get(pid) ?? []) {
      if (qty <= 0) break;
      const t = Math.min(l.qty, qty);
      l.qty -= t;
      qty -= t;
    }
  };
  // Large libraries: score every recipe once on what doesn't change during the week, then plan day by day
  // from the best SHORTLIST. Food at risk, favourites and to-try recipes get a head start, and the seed adds
  // the same kind of randomness as the daily choice, so "shuffle" still draws different recipes.
  let pool = candidates;
  if (candidates.length > SHORTLIST * 1.5) {
    const atRisk = new Set([...stock.entries()].filter(([pid, lots]) => lots[0] && riskOf(lots[0], product(pid)?.shelf_life_days ?? null, start) >= 0.12).map(([pid]) => pid));
    const pick = rng((o.seed ?? 1) * 31 + 7);
    const scored = candidates.map((r) => {
      const it = inter.get(r.id);
      const req = r.ingredients.filter((i) => !i.optional && i.product_id);
      const inStock = req.length ? req.filter((i) => have(i.product_id!) > 0).length / req.length : 0;
      const marked = (it?.priority ?? 0) >= 1 || !!it?.to_try || (it?.rating ?? 0) >= 4;
      const risky = req.some((i) => atRisk.has(i.product_id!));
      const score = inStock * 0.6 + ((it?.rating ?? 3) - 3) * 0.25 + (PRIORITY_WEIGHT[it?.priority ?? 0] ?? 0) + (it?.again === 0 ? -1.2 : 0)
        + (it?.cooked_count ? 0 : 0.3) + (marked ? 1 : 0) + (risky && fifo !== 'off' ? 0.8 : 0) + pick() * 0.6;
      return { r, score };
    });
    pool = scored.sort((a, b) => b.score - a.score).slice(0, SHORTLIST).map((x) => x.r);
  }

  /** What's left of packs bought for earlier meals this week, usable later in the week. */
  const spare = new Map<string, number>();

  const existing = new Map<string, MealSlot & { locked?: number }>();
  for (const s of db.all<MealSlot & { locked: number }>("SELECT * FROM meal_slots WHERE household_id = ? AND meal = 'dinner' AND date BETWEEN ? AND ? AND status != 'skipped' ORDER BY position", householdId, start, addDays(start, days - 1))) {
    if (!existing.has(s.date)) existing.set(s.date, s);
  }
  const chosen: Recipe[] = [];
  const out: PlannedDay[] = [];

  const consume = (r: Recipe, f: number) => {
    for (const i of r.ingredients) {
      if (!i.product_id || !i.quantity || i.optional) continue;
      const need = i.quantity * f;
      const fromStock = Math.min(have(i.product_id), need);
      take(i.product_id, fromStock);
      const short = need - fromStock;
      const p = product(i.product_id);
      if (short > 0 && p?.package_size) {
        const left = spare.get(i.product_id) ?? 0;
        const fromSpare = Math.min(left, short);
        const toBuy = short - fromSpare;
        const packs = Math.ceil(toBuy / p.package_size - 1e-9);
        spare.set(i.product_id, left - fromSpare + packs * p.package_size - toBuy);
      }
    }
  };

  for (let d = 0; d < days; d++) {
    const date = addDays(start, d);
    const ex = existing.get(date);
    const outside = !!o.only && !o.only.includes(date);
    const keep = ex && (ex.status === 'cooked' || !!ex.locked || !o.replace || outside);
    if (keep || outside) {
      const r = ex?.recipe_id ? byId.get(ex.recipe_id) : undefined;
      if (r) {
        chosen.push(r);
        if (ex!.status === 'planned') consume(r, ex!.servings / r.servings);
      }
      if (ex) out.push({ date, recipeId: ex.recipe_id, slotId: ex.id, title: r?.title ?? ex.title ?? '', emoji: r?.emoji ?? null, color: r?.color ?? null, minutes: r ? r.prep_minutes + r.cook_minutes : 0, kcal: r?.nutritionPerServing?.kcal ?? null, health: r?.health.score ?? 0, reasons: [], usesUp: [], why: [], extraCost: 0, existing: true, locked: !!ex.locked });
      continue;
    }
    const weekday = new Date(date + 'T12:00:00Z').getUTCDay(); // 0 Sun … 6 Sat
    if (!o.only && !prefs.planDays.includes(weekday)) continue; // not a day you plan dinner
    const weeknight = weekday >= 1 && weekday <= 4;
    const newSoFar = out.filter((d) => !d.existing && d.recipeId && !inter.get(d.recipeId)?.cooked_count).length;
    const daysAhead = daysBetween(clock.today(), date);
    const prev = chosen[chosen.length - 1];
    const weekProducts = new Set(chosen.flatMap((c) => c.ingredients.filter((i) => !i.optional && i.product_id).map((i) => i.product_id!)));
    let best: { r: Recipe; score: number; reasons: string[]; usesUp: string[]; why: PlannedDay['why']; extraCost: number } | null = null;
    for (const r of pool) {
      if (chosen.some((c) => c.id === r.id)) continue;
      const minutes = r.prep_minutes + r.cook_minutes;
      if (weeknight && maxWeeknight && minutes > maxWeeknight) continue;
      if (!weeknight && prefs.maxWeekendMinutes && minutes > prefs.maxWeekendMinutes) continue;
      if ((DIFFICULTY[r.difficulty] ?? 0) > DIFFICULTY[prefs.maxDifficulty]) continue;
      const it = inter.get(r.id);
      const reasons: string[] = [];
      const usesUp: string[] = [];
      const why: PlannedDay['why'] = [];
      const add = (factor: string, points: number) => {
        if (points) why.push({ factor, points: Math.round(points * 100) / 100 });
      };

      if (it?.rating) {
        add('rating', (it.rating - 3) * 0.25 * MULT[prefs.ratingWeight].rating);
        if (it.rating >= 4) reasons.push(`You rated it ${it.rating}★`);
      }
      const pr = it?.priority ?? 0;
      add('how often', (PRIORITY_WEIGHT[pr] ?? 0) * MULT[prefs.ratingWeight].rating);
      if (pr >= 1) reasons.push(pr === 2 ? 'A favourite' : 'You want this more often');
      // After-cooking answers: "not again" weighs heavily (without excluding it: that's "Never"), and
      // a recipe you found hard is held back on weeknights, an easy one helps there.
      if (it?.again === 0) add('not again', -1.2);
      else if (it?.again === 1) add('would cook again', 0.15);
      if (weeknight && it?.ease === 3) add('hard to make', -0.35);
      else if (weeknight && it?.ease === 1) {
        add('easy to make', 0.15);
        reasons.push('Easy to make');
      }
      if (!it?.cooked_count) {
        // With a "new recipes per week" setting: a nudge until it's reached, then hold back.
        const enough = prefs.newPerWeek != null && newSoFar >= prefs.newPerWeek;
        add('new to try', enough ? -0.6 : novelty + (it?.to_try ? 0.4 : 0) + (prefs.newPerWeek ? 0.3 : 0));
        if (!enough) reasons.push(it?.to_try ? 'On your to-try list' : 'Something new');
      }
      if (prefs.mealTypes.length && r.tags.some((t) => prefs.mealTypes.includes(t))) add('meal types you like', 0.2);
      if (r.cuisine && prefs.cuisines.includes(r.cuisine)) add('favourite cuisine', 0.2);
      // Practical in your country: specialist shops or unknown ingredients count against a recipe.
      const compat = r.compat?.level;
      if (compat === 'specialist') add('needs a specialist shop', -1);
      else if (compat === 'partial') add('ingredients to check', -0.35);
      else if (compat === 'substitutions') add('with substitutions', -0.05);
      add('swapped before', -Math.min(0.4, (it?.swapped_count ?? 0) * 0.1) - Math.min(0.15, (it?.skipped_count ?? 0) * 0.04));

      const required = r.ingredients.filter((i) => !i.optional && i.product_id);
      const favHits = required.filter((i) => favourites.has(i.product_id!));
      if (favHits.length) {
        add('favourite foods', Math.min(0.6, 0.3 * favHits.length));
        reasons.push(`With ${favHits.map((i) => (i.product?.name ?? i.name).toLowerCase()).slice(0, 2).join(' & ')}`);
      }
      add('learned: quick', minutes <= 30 ? learned.quickBias : 0);
      add('learned: protein', learned.proteinBonus[r.protein] ?? 0);
      add('learned: cuisine', learned.cuisineBonus[r.cuisine ?? ''] ?? 0);
      add('learned: high protein', learned.highProtein * Math.max(0, ((r.nutritionPerServing?.protein ?? 0) - 25) / 10));

      const f = servings / r.servings;
      const avail = (pid: string) => have(pid) + (spare.get(pid) ?? 0);
      const inStock = required.filter((i) => avail(i.product_id!) >= (i.quantity ?? 0) * f * 0.5);
      add('in stock', required.length ? (inStock.length / required.length) * 0.6 : 0);

      if (fifo !== 'off') {
        let urgency = 0;
        for (const i of inStock) {
          const first = (stock.get(i.product_id!) ?? []).find((l) => l.qty > 0);
          if (!first) continue;
          const risk = riskOf(first, product(i.product_id!)?.shelf_life_days ?? null, date) * (learned.wasted.has(i.product_id!) ? 1.5 : 1);
          if (risk >= 0.12) usesUp.push((i.product?.name ?? i.name).toLowerCase());
          urgency += risk;
        }
        add(`use first (${fifo})`, Math.min(FIFO_CAP[fifo], urgency * FIFO_WEIGHT[fifo]));
        if (usesUp.length) reasons.unshift(`Uses up ${usesUp.slice(0, 2).join(' & ')}`);
      }

      // Extra shopping: the cost of what's missing, in whole packs.
      let extraCost = 0;
      for (const i of required) {
        const need = (i.quantity ?? 0) * f - avail(i.product_id!);
        const p = i.product;
        if (need > 0 && p?.package_size) extraCost += costFor(p, Math.ceil(need / p.package_size - 1e-9) * p.package_size) ?? 0;
      }
      add('extra shopping', -Math.min(0.6, extraCost * 0.06));
      if (extraCost === 0 && required.length) reasons.push('Nothing to buy');

      // Shared ingredients with the rest of the week: open packs get finished.
      const shared = required.filter((i) => weekProducts.has(i.product_id!) && !isStaple(i.product));
      if (shared.length) {
        add('shares ingredients', Math.min(0.45, 0.15 * shared.length) * MULT[prefs.overlap].overlap);
        reasons.push(`Shares ${shared.map((i) => (i.product?.name ?? i.name).toLowerCase()).slice(0, 2).join(' & ')} with another day`);
      }

      if (it?.last_cooked_at) {
        const ago = daysBetween(it.last_cooked_at, date);
        add('recently eaten', (ago < 10 ? -0.6 : ago < 21 ? -0.25 : 0) * MULT[prefs.variety].variety);
      }
      add('variety', ((prev && prev.protein === r.protein && r.protein !== 'veg' ? -0.3 : 0) + (prev && prev.cuisine === r.cuisine ? -0.25 : 0) + (chosen.filter((c) => c.protein === r.protein && r.protein !== 'veg').length >= 2 ? -0.35 : 0)) * MULT[prefs.variety].variety);
      if (prefs.budgetPerServing && r.costPerServing != null && r.costPerServing > prefs.budgetPerServing) add('over budget', -Math.min(0.8, (r.costPerServing - prefs.budgetPerServing) * 0.3));
      if (prefs.nutritionPriorities.length && r.nutritionPerServing) {
        const n = r.nutritionPerServing;
        const p = prefs.nutritionPriorities;
        const sum = (p.includes('protein') ? ((n.protein - 25) / 20) * 0.2 : 0) + (p.includes('fibre') ? ((n.fibre ?? 0) / 10) * 0.15 : 0) + (p.includes('veg') ? (r.health.vegGrams / 200) * 0.2 : 0)
          - (p.includes('lessSalt') ? (n.salt ?? 0) * 0.1 : 0) - (p.includes('lessSugar') ? ((n.sugars ?? 0) / 20) * 0.15 : 0) - (p.includes('lessSatFat') ? ((n.satFat ?? 0) / 10) * 0.15 : 0);
        add('your nutrition priorities', Math.max(-0.3, Math.min(0.3, sum)));
      }
      const health = mealScore(r.nutritionPerServing, r.health.vegGrams, r.health.vegKinds, targets).score;
      add('balance', ((health - 60) / 100) * 0.5);
      add('quick weeknight', weeknight && minutes <= 25 ? 0.1 : 0);
      add('fresh late in week', daysAhead > 3 && required.some((i) => i.product && (i.product.shelf_life_days ?? 99) <= 3 && have(i.product_id!) <= 0) ? -0.15 : 0);
      const score = 1 + why.reduce((s, w) => s + w.points, 0) + random() * 0.35;
      if (!best || score > best.score) best = { r, score, reasons, usesUp, why: why.sort((a, b) => Math.abs(b.points) - Math.abs(a.points)), extraCost };
    }
    if (!best) continue;
    const r = best.r;
    chosen.push(r);
    consume(r, servings / r.servings);
    out.push({
      date, recipeId: r.id, slotId: ex?.id ?? null, title: r.title, emoji: r.emoji, color: r.color, minutes: r.prep_minutes + r.cook_minutes, kcal: r.nutritionPerServing?.kcal ?? null,
      health: mealScore(r.nutritionPerServing, r.health.vegGrams, r.health.vegKinds, targets).score, reasons: best.reasons.slice(0, 3), usesUp: best.usesUp,
      why: best.why.slice(0, 6), extraCost: Math.round(best.extraCost * 100) / 100, existing: false, locked: false,
    });
  }
  const planned = out.filter((d) => !d.existing);
  return {
    start, days, servings, fifo, maxWeeknightMinutes: maxWeeknight,
    plan: out,
    summary: {
      dinners: planned.length,
      usesUp: [...new Set(planned.flatMap((d) => d.usesUp))],
      avgHealth: planned.length ? Math.round(planned.reduce((s, d) => s + d.health, 0) / planned.length) : 0,
      extraCost: Math.round(planned.reduce((s, d) => s + d.extraCost, 0) * 100) / 100,
      learned: learned.insights.filter((i) => i.active).map((i) => i.text),
    },
  };
}

/** Put a proposal on the planner (replacing planned, unlocked dinners on those days). Swapped-out recipes are remembered. */
export function applyPlan(db: Db, householdId: string, days: { date: string; recipeId: string }[], servings: number) {
  let added = 0;
  db.tx(() => {
    for (const d of days) {
      const ex = db.get<MealSlot & { locked: number }>("SELECT * FROM meal_slots WHERE household_id = ? AND date = ? AND meal = 'dinner' AND status = 'planned' ORDER BY position LIMIT 1", householdId, d.date);
      if (ex?.locked) continue;
      if (ex) {
        if (ex.recipe_id && ex.recipe_id !== d.recipeId) recordInteraction(db, householdId, ex.recipe_id, { swapped: true });
        updateSlot(db, householdId, ex.id, { recipeId: d.recipeId, servings, title: null });
      } else addSlot(db, householdId, { date: d.date, meal: 'dinner', recipeId: d.recipeId, servings });
      added++;
    }
  });
  return { added };
}

/** Swap one planned meal for the next-best recipe for that day (the old one counts as swapped out). */
export function swapSlot(db: Db, householdId: string, slotId: string, seed = Date.now()) {
  const slot = getSlot(db, householdId, slotId);
  const near = db.all<{ recipe_id: string }>('SELECT recipe_id FROM meal_slots WHERE household_id = ? AND date BETWEEN ? AND ? AND recipe_id IS NOT NULL', householdId, addDays(slot.date, -6), addDays(slot.date, 6)).map((x) => x.recipe_id);
  const p = proposeWeek(db, householdId, { start: slot.date, days: 1, servings: slot.servings, replace: true, only: [slot.date], avoid: [...near, slot.recipe_id ?? ''], seed: seed % 1e9 });
  const day = p.plan.find((d) => !d.existing);
  if (!day?.recipeId) return null;
  db.tx(() => {
    if (slot.recipe_id) recordInteraction(db, householdId, slot.recipe_id, { swapped: true });
    updateSlot(db, householdId, slot.id, { recipeId: day.recipeId, title: null });
  });
  return day;
}

/** Product names for the favourite-food picker. */
export function favouriteFoodOptions(db: Db, lang: 'en' | 'nl') {
  const ids = ['chicken_breast', 'chicken_thigh', 'minced_beef', 'salmon', 'shrimp', 'tuna', 'tofu', 'eggs', 'chickpeas', 'lentils', 'pasta', 'rice', 'noodles', 'potatoes', 'sweet_potato', 'broccoli', 'spinach', 'mushrooms', 'bell_pepper', 'cauliflower', 'avocado', 'cheese', 'feta', 'coconut_milk'];
  return ids.map((k) => getProduct(db, `p_${k}`)).filter(Boolean).map((p) => ({ id: p!.id, name: displayName(p!, lang), category: p!.category, veg: isVeg(p!), grams: gramsOf(p!, 1) }));
}
