// Barcode → product. Local products first, then the catalogue (Open Food Facts' Dutch products, imported),
// then Open Food Facts itself (cached permanently, because OFF allows ~15 product reads per minute per IP).
import type { Db } from '../db/db.ts';
import { parseJson } from '../db/db.ts';
import { clock } from '../clock.ts';
import { config } from '../config.ts';
import { log } from '../log.ts';
import { createProduct, getProduct, matchProducts, normalizeText, rowToProduct, type Product } from './products.ts';
import { parseSize } from './receipts.ts';
import { fromOpenFoodFacts } from './dietary.ts';
import { catalogueAsOff, catalogueRow } from './catalogue.ts';

export interface OffProduct {
  barcode: string;
  name: string;
  brand: string | null;
  quantityText: string | null;
  size: { qty: number; unit: 'g' | 'ml' | 'pcs' } | null;
  imageUrl: string | null;
  categories: string[];
  nutrition: { kcal: number; protein: number; carbs: number; fat: number; sugars?: number; satFat?: number; fibre?: number; salt?: number } | null;
  allergens: string[];
  diet_flags: string[];
}

export interface BarcodeResult {
  barcode: string;
  product: Product | null;        // a product this household already knows
  external: OffProduct | null;    // what Open Food Facts says
  suggestion: Product | null;     // closest catalogue product, for linking instead of creating
  source: 'local' | 'openfoodfacts' | 'none';
}

export function validBarcode(code: string): boolean {
  if (!/^\d{8}$|^\d{12,14}$/.test(code)) return false;
  // GTIN check digit
  const digits = code.split('').map(Number);
  const check = digits.pop()!;
  const sum = digits.reverse().reduce((s, d, i) => s + d * (i % 2 === 0 ? 3 : 1), 0);
  return (10 - (sum % 10)) % 10 === check;
}

type Fetcher = (url: string, init?: RequestInit) => Promise<Response>;
let fetcher: Fetcher = (url, init) => fetch(url, init);
export function setFetcher(f: Fetcher) {
  fetcher = f;
}

async function fetchOff(barcode: string): Promise<OffProduct | null> {
  const url = `https://world.openfoodfacts.org/api/v2/product/${barcode}.json?fields=product_name,product_name_nl,product_name_en,brands,quantity,image_front_small_url,image_url,categories_tags,nutriments,allergens_tags,ingredients_analysis_tags`;
  const res = await fetcher(url, { headers: { 'User-Agent': config.offUserAgent }, signal: AbortSignal.timeout(6000) });
  if (res.status === 404) return null;
  if (!res.ok) throw new Error(`Open Food Facts returned ${res.status}`);
  const body: any = await res.json();
  if (body.status !== 1 || !body.product) return null;
  const p = body.product;
  const name = p.product_name_nl || p.product_name || p.product_name_en;
  if (!name) return null;
  const n = p.nutriments ?? {};
  return {
    barcode,
    name,
    brand: (p.brands ?? '').split(',')[0]?.trim() || null,
    quantityText: p.quantity ?? null,
    size: p.quantity ? (parseSize(p.quantity) ?? null) : null,
    imageUrl: p.image_front_small_url ?? p.image_url ?? null,
    categories: p.categories_tags ?? [],
    nutrition: n['energy-kcal_100g'] != null ? { kcal: n['energy-kcal_100g'], protein: n.proteins_100g ?? 0, carbs: n.carbohydrates_100g ?? 0, fat: n.fat_100g ?? 0, sugars: n.sugars_100g, satFat: n['saturated-fat_100g'], fibre: n.fiber_100g, salt: n.salt_100g } : null,
    ...fromOpenFoodFacts(p.allergens_tags, p.ingredients_analysis_tags),
  };
}

export async function lookupBarcode(db: Db, householdId: string, barcode: string): Promise<BarcodeResult> {
  const known = catalogueRow(db, barcode);
  // Your product, by this barcode or as another size of the catalogue product it was made from.
  const local = db.get('SELECT * FROM products WHERE barcode = ? AND (household_id IS NULL OR household_id = ?)', barcode, householdId)
    ?? (known?.group_key ? db.get('SELECT * FROM products WHERE household_id = ? AND catalogue_group = ?', householdId, known.group_key) : undefined);
  if (local) return { barcode, product: rowToProduct(local), external: null, suggestion: null, source: 'local' };
  let external: OffProduct | null = null;
  const cached = db.get<{ found: number; data: string; fetched_at: string }>('SELECT * FROM product_lookups WHERE barcode = ?', barcode);
  if (known) external = catalogueAsOff(known);
  else if (cached) external = cached.found ? parseJson<OffProduct | null>(cached.data, null) : null;
  else if (config.offLookup) {
    try {
      external = await fetchOff(barcode);
      db.run('INSERT OR REPLACE INTO product_lookups (barcode, found, data, fetched_at) VALUES (?, ?, ?, ?)', barcode, external ? 1 : 0, JSON.stringify(external), clock.iso());
    } catch (e: any) {
      log.warn('openfoodfacts lookup failed', { barcode, err: e.message });
    }
  }
  // The catalogue already knows which ingredient it is, when it's one of ours.
  const linked = known?.product_id ? getProduct(db, known.product_id) : undefined;
  const suggestion = linked ? { product: linked, score: 1 } : external ? matchProducts(db, householdId, external.name, 1)[0] : undefined;
  return {
    barcode,
    product: null,
    external,
    suggestion: suggestion && suggestion.score >= 0.7 ? suggestion.product : null,
    source: external ? 'openfoodfacts' : 'none',
  };
}

/** Remember a barcode: link it to an existing product, or create a product from OFF data / user input. */
export function linkBarcode(
  db: Db,
  householdId: string,
  barcode: string,
  input: { productId?: string | null; name?: string; packageSize?: number | null; unit?: 'g' | 'ml' | 'pcs' | null; category?: string | null },
): Product {
  const cached = db.get<{ data: string }>('SELECT data FROM product_lookups WHERE barcode = ? AND found = 1', barcode);
  const known = catalogueRow(db, barcode);
  const off = known ? catalogueAsOff(known) : cached ? parseJson<OffProduct | null>(cached.data, null) : null;
  if (input.productId) {
    const existing = getProduct(db, input.productId);
    if (!existing) throw new Error('Product not found');
    // Catalogue products are shared; a barcode makes it household-specific, so create a linked variant.
    if (!existing.household_id) {
      const sizeMatches = off?.size && off.size.unit === existing.unit;
      return createProduct(db, householdId, {
        name: existing.name, name_nl: existing.name_nl, brand: off?.brand ?? null, category: existing.category, barcode, image_url: off?.imageUrl ?? null,
        unit: existing.unit, package_size: input.packageSize ?? (sizeMatches ? off!.size!.qty : existing.package_size), piece_size: existing.piece_size, piece_name: existing.piece_name,
        price: existing.price, default_location: existing.default_location, shelf_life_days: existing.shelf_life_days,
        synonyms: [...existing.synonyms, ...(off ? [normalizeText(off.name)] : [])], nutrition: off?.nutrition ?? existing.nutrition,
        nutrition_source: off?.nutrition ? 'openfoodfacts' : existing.nutrition_source,
        allergens: [...new Set([...existing.allergens, ...(off?.allergens ?? [])])], diet_flags: [...new Set([...existing.diet_flags, ...(off?.diet_flags ?? [])])],
      });
    }
    db.run('UPDATE products SET barcode = ? WHERE id = ?', barcode, existing.id);
    return getProduct(db, existing.id)!;
  }
  const size = off?.size;
  return createProduct(db, householdId, {
    name: input.name ?? off?.name ?? `Product ${barcode}`,
    brand: off?.brand ?? null,
    barcode,
    image_url: off?.imageUrl ?? null,
    unit: input.unit ?? size?.unit ?? undefined,
    package_size: input.packageSize ?? size?.qty ?? undefined,
    category: input.category ?? undefined,
    nutrition: off?.nutrition ?? null,
    nutrition_source: off?.nutrition ? 'openfoodfacts' : null,
    allergens: off?.allergens ?? [],
    diet_flags: off?.diet_flags ?? [],
  });
}
