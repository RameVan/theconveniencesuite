// Searching the product catalogue (import/catalogue.ts) and picking a product from it. A product that is one
// of our ingredients is that ingredient, so stock and recipes count it; any other product becomes the
// household's own product, with Open Food Facts' brand, size, photo and nutrition.
import type { Db } from '../db/db.ts';
import { parseJson } from '../db/db.ts';
import { notFound } from '../errors.ts';
import { CHAINS } from '../db/ingredient-knowledge.ts';
import { createProduct, getProduct, normalizeText, rowToProduct, type Product } from './products.ts';
import { householdCountry } from './substitutions.ts';
import { householdSetting } from './settings.ts';
import { withoutOwnBrand } from './ingredients.ts';
import type { OffProduct } from './barcode.ts';
import { formatQty } from './units.ts';
import { canonicalText } from '../import/identity.ts';

export interface CatalogueRow {
  ean: string; country: string; name: string; brand: string | null; size_text: string | null; size_qty: number | null; size_unit: 'g' | 'ml' | 'pcs' | null;
  category: string; product_id: string | null; chains: string; image_url: string | null; nutrition: string | null; allergens: string; diet_flags: string;
  popularity: number; modified: string | null; source: string; group_key: string | null; words: string | null; listed: number;
}

const chainName = (id: string) => CHAINS.find((c) => c.id === id)?.name ?? id;

/** A row as shown: own brands ("AH Kokosmelk") as just the product at that supermarket. */
function view(r: CatalogueRow) {
  const chains = parseJson<string[]>(r.chains, []);
  const shown = withoutOwnBrand({ name: r.name, brand: r.brand, chain_id: chains[0] ?? null, chain_name: chains[0] ? chainName(chains[0]) : null });
  const all = [...new Set([...(shown.chain_id ? [shown.chain_id] : []), ...chains])];
  // A "brand" that is just the name again ("Kipfilet" by "Kipfilet") says nothing.
  const brand = shown.brand && normalizeText(shown.brand) !== normalizeText(shown.name) ? shown.brand : null;
  return { name: shown.name, brand, chains: all.map((id) => ({ id, name: chainName(id) })) };
}

/**
 * One product from all its entries (catalogue.group_key): the most scanned entry's name and photo, every shop it's
 * listed at, and its sizes in its usual unit, the most entered first (fresh fish comes in many weights), at most 6.
 */
function summarize(members: CatalogueRow[]) {
  const best = [...members].sort((x, y) => y.popularity - x.popularity || Number(!!y.image_url) - Number(!!x.image_url))[0];
  const v = view(best);
  const chains = new Map<string, { id: string; name: string }>();
  for (const m of members) for (const ch of view(m).chains) chains.set(ch.id, ch);
  const units = new Map<string, number>();
  for (const m of members) if (m.size_unit && m.size_qty) units.set(m.size_unit, (units.get(m.size_unit) ?? 0) + 1);
  const unit = ([...units.entries()].sort((x, y) => y[1] - x[1])[0]?.[0] ?? null) as CatalogueRow['size_unit'];
  const bySize = new Map<number, { ean: string; n: number; pop: number }>();
  for (const m of members) {
    if (m.size_unit !== unit || !m.size_qty) continue;
    const qty = Math.round(m.size_qty * 100) / 100;
    const e = bySize.get(qty);
    if (!e) bySize.set(qty, { ean: m.ean, n: 1, pop: m.popularity });
    else {
      e.n++;
      if (m.popularity > e.pop) Object.assign(e, { ean: m.ean, pop: m.popularity });
    }
  }
  const sizes = [...bySize.entries()].sort((x, y) => y[1].n - x[1].n || y[1].pop - x[1].pop).slice(0, 6)
    .sort((x, y) => x[0] - y[0]).map(([qty, e]) => ({ ean: e.ean, qty, unit: unit!, text: formatQty(qty, unit!) }));
  const productId = best.product_id ?? members.find((m) => m.product_id)?.product_id ?? null;
  return { best, v, chains: [...chains.values()], image: best.image_url ?? members.find((m) => m.image_url)?.image_url ?? null, unit, sizes, productId };
}

const members = (db: Db, groups: string[]) => groups.length
  ? db.all<CatalogueRow>(`SELECT * FROM catalogue WHERE group_key IN (${groups.map(() => '?').join(',')})`, ...groups)
  : [];

/**
 * Products whose name or brand has every word typed (prefixes count: "halfv mel"; "chilli" finds "chili"), each
 * once with its sizes. Best first: matching words, then products people scan often, with a photo, or sold at your
 * supermarkets.
 */
export function searchCatalogue(db: Db, householdId: string, q: string, limit = 20) {
  const words = canonicalText(q).split(' ').filter((w) => w.length >= 2);
  if (!words.length) return [];
  const match = words.map((w) => `"${w.replace(/"/g, '')}"*`).join(' ');
  const mine = new Set(householdSetting(db, householdId, 'chains') as string[]);
  const rows = db.all<CatalogueRow & { rank: number }>(
    `SELECT c.*, bm25(catalogue_fts, 4, 1, 2) AS rank FROM catalogue_fts JOIN catalogue c ON c.rowid = catalogue_fts.rowid
     WHERE catalogue_fts MATCH ? AND c.country = ? AND c.listed = 1 ORDER BY rank LIMIT 400`,
    match, householdCountry(db, householdId),
  );
  const first = words[0];
  // The best entry of a product decides its place.
  const groups = new Map<string, number>();
  for (const r of rows) {
    const v = view(r);
    const score = -r.rank + Math.log1p(r.popularity) * 0.6 + (r.image_url ? 1 : 0) + (normalizeText(v.name).startsWith(first) ? 1.5 : 0)
      + (v.chains.some((c) => mine.has(c.id)) ? 1 : v.chains.length ? 0.5 : 0);
    const key = r.group_key ?? `ean:${r.ean}`;
    groups.set(key, Math.max(groups.get(key) ?? -Infinity, score));
  }
  const top = [...groups.entries()].sort((x, y) => y[1] - x[1]).slice(0, limit).map(([k]) => k);
  const byGroup = new Map<string, CatalogueRow[]>();
  for (const m of members(db, top)) (byGroup.get(m.group_key!) ?? byGroup.set(m.group_key!, []).get(m.group_key!)!).push(m);
  return top.filter((k) => byGroup.has(k)).map((k) => {
    const g = summarize(byGroup.get(k)!);
    const ingredient = g.productId ? getProduct(db, g.productId) : undefined;
    return {
      // An ingredient keeps its own measure: eggs come in 6s and 10s, not in grams.
      ean: g.best.ean, name: g.v.name, brand: g.v.brand, sizes: ingredient && ingredient.unit !== g.unit ? [] : g.sizes, size: g.sizes.length ? null : g.best.size_text,
      image_url: g.image, category: g.best.category, chains: g.chains,
      ingredient: ingredient ? { id: ingredient.id, name: ingredient.name, name_nl: ingredient.name_nl } : null,
    };
  });
}

export function catalogueRow(db: Db, ean: string): CatalogueRow | undefined {
  return db.get<CatalogueRow>('SELECT * FROM catalogue WHERE ean = ?', ean);
}

/** The catalogue's data for a barcode in the shape of an Open Food Facts lookup (barcode.ts). */
export function catalogueAsOff(r: CatalogueRow): OffProduct {
  const v = view(r);
  return {
    barcode: r.ean, name: v.name, brand: v.brand, quantityText: r.size_text, size: r.size_qty && r.size_unit ? { qty: r.size_qty, unit: r.size_unit } : null,
    imageUrl: r.image_url, categories: [], nutrition: parseJson(r.nutrition, null), allergens: parseJson(r.allergens, []), diet_flags: parseJson(r.diet_flags, []),
  };
}

/**
 * Picking a catalogue product: the ingredient it is, your product made from it before (any size or barcode of it),
 * or a new product of yours with all its sizes as pack options.
 */
export function useCatalogueItem(db: Db, householdId: string, ean: string): Product {
  const r = catalogueRow(db, ean);
  if (!r) throw notFound('Product');
  const own = db.get('SELECT * FROM products WHERE household_id = ? AND (barcode = ? OR catalogue_group = ?)', householdId, ean, r.group_key);
  if (own) return rowToProduct(own);
  const all = r.group_key ? members(db, [r.group_key]) : [r];
  const g = summarize(all.length ? all : [r]);
  if (g.productId) return getProduct(db, g.productId)!;
  const off = catalogueAsOff(r);
  const size = r.size_unit === g.unit && r.size_qty ? r.size_qty : g.sizes[0]?.qty;
  const p = createProduct(db, householdId, {
    name: g.v.name, brand: g.v.brand, barcode: ean, image_url: off.imageUrl ?? g.image, category: r.category,
    unit: g.unit ?? undefined, package_size: size,
    nutrition: off.nutrition, nutrition_source: off.nutrition ? 'openfoodfacts' : null, allergens: off.allergens, diet_flags: off.diet_flags,
  });
  db.update('products', p.id, { package_options: g.sizes.map((x) => x.qty), catalogue_group: r.group_key });
  return getProduct(db, p.id)!;
}
