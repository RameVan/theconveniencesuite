// Daily cooking check-in: "Did you cook X?" for planned meals that haven't been confirmed.
// Planning never deducts ingredients; this question closes the loop with one tap (or one word).
import { interactionPrefs } from './personal.ts';
import { householdSetting } from './settings.ts';
import type { Db } from '../db/db.ts';
import { parseJson } from '../db/db.ts';
import { clock, addDays } from '../clock.ts';
import { AppError, notFound } from '../errors.ts';
import { getRecipe, cookRecipe } from './recipes.ts';
import { getSlot, updateSlot } from './planner.ts';
import { syncPlanToShopping } from './shopping.ts';
import type { Ctx } from './ledger.ts';

export interface CheckinSettings {
  enabled: boolean;
  time: string; // HH:MM, local server time
}

export const DEFAULT_CHECKIN: CheckinSettings = { enabled: true, time: '20:00' };

export function checkinSettings(db: Db, householdId: string): CheckinSettings {
  return householdSetting(db, householdId, 'cookCheckin');
}

export interface Checkin {
  slotId: string;
  date: string;
  meal: string;
  recipeId: string;
  title: string;
  emoji: string | null;
  color: string | null;
  servings: number;
  when: 'today' | 'yesterday';
}

/** Minutes since local midnight for an "HH:MM" string or a Date. */
const minutes = (x: string | Date) => (typeof x === 'string' ? Number(x.slice(0, 2)) * 60 + Number(x.slice(3, 5)) : x.getHours() * 60 + x.getMinutes());

/**
 * Planned recipe meals still waiting for an answer: yesterday's always, today's once the
 * check-in time has passed (or always, with `includeToday`, for the assistant and Home card).
 */
export function pendingCheckins(db: Db, householdId: string, opts: { includeToday?: boolean } = {}): Checkin[] {
  const settings = checkinSettings(db, householdId);
  const today = clock.today();
  const yesterday = addDays(today, -1);
  const todayDue = opts.includeToday || minutes(clock.now()) >= minutes(settings.time);
  const rows = db.all<{ id: string; date: string; meal: string; recipe_id: string; servings: number }>(
    `SELECT id, date, meal, recipe_id, servings FROM meal_slots
     WHERE household_id = ? AND status = 'planned' AND recipe_id IS NOT NULL AND date IN (?, ?)
     ORDER BY date, CASE meal WHEN 'breakfast' THEN 0 WHEN 'lunch' THEN 1 WHEN 'dinner' THEN 2 ELSE 3 END`,
    householdId,
    yesterday,
    today,
  );
  return rows
    .filter((r) => r.date === yesterday || todayDue)
    .map((r) => {
      const recipe = getRecipe(db, householdId, r.recipe_id);
      return { slotId: r.id, date: r.date, meal: r.meal, recipeId: r.recipe_id, title: recipe.title, emoji: recipe.emoji, color: recipe.color, servings: r.servings, when: r.date === today ? 'today' : 'yesterday' };
    });
}

export type CheckinAnswer = 'cooked' | 'not_cooked' | 'tomorrow';

/** Answer a check-in. "cooked" deducts the ingredients through the ledger, like any cooked meal. */
export function answerCheckin(ctx: Ctx, slotId: string, answer: CheckinAnswer, opts: { servings?: number; leftovers?: { fridge?: number; freezer?: number } } = {}) {
  const slot = getSlot(ctx.db, ctx.householdId, slotId);
  if (!slot.recipe_id) throw notFound('Planned recipe');
  if (slot.status !== 'planned') return { already: slot.status, slot };
  if (answer === 'cooked') {
    const result = cookRecipe(ctx, { recipeId: slot.recipe_id, servings: opts.servings ?? slot.servings, leftovers: opts.leftovers, mealSlotId: slot.id, deduct: interactionPrefs(ctx.db, ctx.householdId).autoDeduct });
    syncPlanToShopping(ctx.db, ctx.householdId, { quiet: true });
    return { already: null, slot: getSlot(ctx.db, ctx.householdId, slotId), result, batchId: ctx.batchId };
  }
  if (answer === 'not_cooked') {
    updateSlot(ctx.db, ctx.householdId, slotId, { status: 'skipped' });
  } else if (answer === 'tomorrow') {
    updateSlot(ctx.db, ctx.householdId, slotId, { date: addDays(clock.today(), 1) });
  } else throw new AppError(400, 'bad_answer', 'Unknown answer');
  syncPlanToShopping(ctx.db, ctx.householdId, { quiet: true });
  return { already: null, slot: getSlot(ctx.db, ctx.householdId, slotId) };
}
