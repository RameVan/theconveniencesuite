// The personal home dashboard: a widget library, ready-made arrangements, saved layouts per person
// and per device size, live data for each widget, and suggestions learned from what someone opens.
// Suggestions are only ever offered; the layout changes when the person taps "apply".
import type { Db } from '../db/db.ts';
import { parseJson } from '../db/db.ts';
import { clock, addDays } from '../clock.ts';
import { inventorySummary, recentEvents } from './inventory.ts';
import { listShopping, shoppingSuggestions, syncPlanToShopping } from './shopping.ts';
import { searchRecipes, listRecipes, type RecipeMatch } from './recipes.ts';
import { todaysMeals, weekPlan } from './planner.ts';
import { analytics } from './analytics.ts';
import { game, weekOf } from './game.ts';
import { journey } from './journey.ts';
import { riskOf } from './autoplan.ts';
import { targetsFor } from './targets.ts';
import { displayName } from './products.ts';
import { AppError } from '../errors.ts';

type Txt = [string, string];
export type Size = 's' | 'm' | 'l';
export interface WidgetDef { type: string; group: string; emoji: string; title: Txt; desc: Txt; sizes: Size[]; size: Size }

const W = (type: string, group: string, emoji: string, title: Txt, desc: Txt, sizes: Size[] = ['s', 'm', 'l'], size: Size = 'm'): WidgetDef => ({ type, group, emoji, title, desc, sizes, size });

export const WIDGETS: WidgetDef[] = [
  W('quickAdd', 'groceries', '⚡', ['Quick add', 'Snel toevoegen'], ['Receipt, voice list, barcode, use and add buttons.', 'Bon, inspreken, barcode, gebruiken en toevoegen.'], ['m', 'l'], 'l'),
  W('shopping', 'groceries', '🛒', ['Shopping list', 'Boodschappenlijst'], ['Tick items off and add new ones right here.', 'Vink af en voeg direct iets toe.'], ['m', 'l'], 'm'),
  W('inventory', 'groceries', '🧊', ['Grocery inventory', 'Voorraad'], ['What you have, per category.', 'Wat je hebt, per categorie.']),
  W('expiring', 'groceries', '⏰', ['Expiring soon', 'Bijna over de datum'], ['Food to use first.', 'Eten om eerst te gebruiken.']),
  W('low', 'groceries', '📉', ['Low stock', 'Bijna op'], ['Things you use often that are running low.', 'Dingen die je vaak gebruikt en bijna op zijn.']),
  W('recent', 'groceries', '🧾', ['Recently added', 'Net toegevoegd'], ['Your latest groceries.', 'Je laatste boodschappen.']),
  W('leftovers', 'groceries', '🥡', ['Leftovers', 'Restjes'], ['Leftovers in the fridge and freezer.', 'Restjes in koelkast en vriezer.']),
  W('listSuggestions', 'groceries', '💡', ['Suggested for your list', 'Voorstellen voor je lijst'], ['Things you’ll probably need soon.', 'Dingen die je waarschijnlijk binnenkort nodig hebt.']),
  W('fifo', 'groceries', '🔄', ['Use first (FIFO)', 'Eerst op (FIFO)'], ['What spoils first, with a recipe for each.', 'Wat het eerst bederft, met een recept per product.']),
  W('favourites', 'recipes', '❤️', ['Favourite recipes', 'Favoriete recepten'], ['Your best-rated dishes, one tap to cook.', 'Je best beoordeelde gerechten, één tik om te koken.'], ['m', 'l'], 'l'),
  W('recipeOfDay', 'recipes', '🌟', ['Recipe of the day', 'Recept van de dag'], ['A pick that fits what you have.', 'Een keuze die past bij wat je hebt.']),
  W('recentlyCooked', 'recipes', '🍽️', ['Recently cooked', 'Recent gekookt'], ['Your cooking history.', 'Wat je laatst kookte.']),
  W('toTry', 'recipes', '🔖', ['Recipes to try', 'Nog proberen'], ['Saved but not made yet.', 'Bewaard maar nog niet gemaakt.'], ['m', 'l'], 'l'),
  W('quickMeals', 'recipes', '⏱️', ['Quick meals', 'Snelle maaltijden'], ['25 minutes or less.', '25 minuten of minder.'], ['m', 'l'], 'l'),
  W('highProtein', 'recipes', '💪', ['High-protein recipes', 'Eiwitrijke recepten'], ['Most protein per serving.', 'Meeste eiwit per portie.'], ['m', 'l'], 'l'),
  W('fromStock', 'recipes', '🥕', ['From your ingredients', 'Met wat je hebt'], ['Almost everything already in your kitchen.', 'Bijna alles ligt al in huis.'], ['m', 'l'], 'l'),
  W('weekPlan', 'planning', '🗓️', ['Weekly meal planner', 'Weekplanning'], ['The next seven dinners.', 'De komende zeven avondmaaltijden.'], ['m', 'l'], 'l'),
  W('tonight', 'planning', '🍳', ['Today’s dinner', 'Vanavond'], ['What’s planned, with a cook button.', 'Wat er gepland is, met een kookknop.'], ['s', 'm', 'l'], 'm'),
  W('missing', 'planning', '🧩', ['Missing ingredients', 'Ontbrekende ingrediënten'], ['What upcoming meals still need.', 'Wat de komende maaltijden nog nodig hebben.']),
  W('planProgress', 'planning', '✅', ['Meal plan progress', 'Voortgang planning'], ['Cooked versus planned this week.', 'Gekookt versus gepland deze week.'], ['s', 'm']),
  W('autoPlan', 'planning', '✨', ['Plan my week', 'Plan mijn week'], ['One tap plans the week’s dinners.', 'Eén tik plant de avondmaaltijden van de week.'], ['s', 'm', 'l'], 'm'),
  W('dailyNutrition', 'nutrition', '📊', ['Daily nutrition', 'Voeding vandaag'], ['Energy, protein, carbs and fat from meals you logged.', 'Energie, eiwit, koolhydraten en vet uit gelogde maaltijden.']),
  W('protein', 'nutrition', '🥚', ['Protein progress', 'Eiwit'], ['Today’s protein towards your target.', 'Eiwit vandaag richting je doel.'], ['s', 'm']),
  W('weeklyNutrition', 'nutrition', '📈', ['Weekly nutrition', 'Voeding deze week'], ['Balance scores across the week.', 'Balansscores over de week.']),
  W('nutritionScore', 'nutrition', '⚖️', ['Daily nutrition score', 'Voedingsscore'], ['Today’s balance score, 0–100.', 'De balansscore van vandaag, 0–100.'], ['s', 'm']),
  W('nutritionStreak', 'nutrition', '🥗', ['Nutrition streak', 'Balansreeks'], ['Balanced cooking days in a row.', 'Gebalanceerde kookdagen op rij.'], ['s', 'm']),
  W('cookingStreak', 'game', '🔥', ['Cooking streak', 'Kookreeks'], ['Days in a row you cooked.', 'Dagen op rij gekookt.'], ['s', 'm']),
  W('xp', 'game', '⭐', ['XP progress', 'XP-voortgang'], ['XP and your next level.', 'XP en je volgende niveau.'], ['s', 'm']),
  W('challenge', 'game', '🎯', ['Current challenge', 'Huidige uitdaging'], ['Your 7-day challenge, or a suggestion.', 'Je uitdaging van 7 dagen, of een voorstel.']),
  W('journey', 'game', '🧭', ['Progression path', 'Je reis'], ['Where you are and the next step.', 'Waar je bent en de volgende stap.'], ['m', 'l'], 'm'),
  W('achievements', 'game', '🏅', ['Recent achievements', 'Recente prestaties'], ['What you unlocked lately.', 'Wat je onlangs ontgrendelde.']),
  W('wasteStats', 'stats', '♻️', ['Food waste reduction', 'Minder verspilling'], ['Food used before its date versus thrown away.', 'Eten gebruikt voor de datum versus weggegooid.']),
  W('moneySaved', 'stats', '💶', ['Estimated money saved', 'Geschat bespaard'], ['From rescued food and eaten leftovers.', 'Door gered eten en opgegeten restjes.'], ['s', 'm']),
  W('cookingStats', 'stats', '👩‍🍳', ['Cooking statistics', 'Kookstatistieken'], ['Meals cooked, recipes explored, average time.', 'Gekookt, recepten ontdekt, gemiddelde tijd.']),
  W('spending', 'stats', '🧮', ['Weekly spending', 'Uitgaven per week'], ['Grocery spending where prices are known.', 'Boodschappen-uitgaven waar prijzen bekend zijn.']),
  W('topIngredients', 'stats', '🏆', ['Most used ingredients', 'Meest gebruikt'], ['What you use most (90 days).', 'Wat je het meest gebruikt (90 dagen).']),
  W('activity', 'stats', '🕑', ['Recent activity', 'Recente activiteit'], ['The latest changes to your stock.', 'De laatste wijzigingen in je voorraad.']),
];
export const WIDGET_TYPES = WIDGETS.map((w) => w.type);
const DEF = new Map(WIDGETS.map((w) => [w.type, w]));

export interface Widget { id: string; type: string; size: Size; view: 'compact' | 'expanded'; pinned?: boolean; hidden?: boolean }
export type Device = 'phone' | 'tablet' | 'desktop';
export interface Profile { id: string; name: string; preset: string; layouts: Partial<Record<Device, Widget[]>> }
export interface DashboardConfig { version: 1; active: string; profiles: Profile[] }

const w = (type: string, size?: Size, view: Widget['view'] = 'expanded'): Widget => ({ id: type, type, size: size ?? DEF.get(type)?.size ?? 'm', view });

// A few useful starting points; every widget stays available in the library.
export const PRESETS: { id: string; emoji: string; title: Txt; desc: Txt; widgets: Widget[] }[] = [
  { id: 'everyday', emoji: '🏡', title: ['Everyday', 'Dagelijks'], desc: ['Tonight, your list, what to use first, ideas.', 'Vanavond, je lijst, wat eerst op moet, ideeën.'], widgets: [w('tonight', 'l'), w('shopping', 'm'), w('expiring', 'm'), w('fromStock', 'l')] },
  { id: 'minimal', emoji: '🍃', title: ['Minimal', 'Minimaal'], desc: ['Just tonight and the shopping list.', 'Alleen vanavond en de boodschappenlijst.'], widgets: [w('tonight', 'l'), w('shopping', 'm')] },
  { id: 'planner', emoji: '🗓️', title: ['Planner', 'Planner'], desc: ['Your week up front.', 'Je week vooraan.'], widgets: [w('weekPlan', 'l'), w('autoPlan', 'm'), w('missing', 'm'), w('favourites', 'l')] },
  { id: 'zerowaste', emoji: '♻️', title: ['Zero waste', 'Niets verspillen'], desc: ['Use what you have, first.', 'Gebruik eerst wat je hebt.'], widgets: [w('expiring', 'm'), w('fifo', 'm'), w('leftovers', 'm'), w('fromStock', 'l')] },
  { id: 'progress', emoji: '🏆', title: ['Progress', 'Voortgang'], desc: ['Your journey, streak and challenge.', 'Je reis, reeks en uitdaging.'], widgets: [w('journey', 'l'), w('cookingStreak', 's'), w('xp', 's'), w('challenge', 'm')] },
];

export function defaultConfig(): DashboardConfig {
  return { version: 1, active: 'home', profiles: [{ id: 'home', name: 'Home', preset: 'everyday', layouts: { phone: structuredClone(PRESETS[0].widgets) } }] };
}

const prefKey = 'dashboard';
export function getDashboard(db: Db, h: string, userId: string): DashboardConfig {
  const v = parseJson<DashboardConfig | null>(db.get<{ value: string }>('SELECT value FROM preferences WHERE household_id = ? AND user_id = ? AND key = ?', h, userId, prefKey)?.value, null);
  return v && v.profiles?.length ? v : defaultConfig();
}

export function saveDashboard(db: Db, h: string, userId: string, cfg: DashboardConfig) {
  for (const p of cfg.profiles) for (const list of Object.values(p.layouts)) for (const x of list ?? []) {
    if (!DEF.has(x.type)) throw new AppError(400, 'dashboard', `Unknown widget ${x.type}`);
    if (!DEF.get(x.type)!.sizes.includes(x.size)) x.size = DEF.get(x.type)!.size;
  }
  if (!cfg.profiles.some((p) => p.id === cfg.active)) cfg.active = cfg.profiles[0].id;
  db.run('INSERT INTO preferences (household_id, user_id, key, value) VALUES (?, ?, ?, ?) ON CONFLICT(household_id, user_id, key) DO UPDATE SET value = excluded.value', h, userId, prefKey, JSON.stringify(cfg));
  return cfg;
}

// ---------- Usage and suggestions ----------

export function recordUsage(db: Db, h: string, userId: string, key: string) {
  db.run('INSERT INTO ui_usage (household_id, user_id, key, day, n) VALUES (?, ?, ?, ?, 1) ON CONFLICT(household_id, user_id, key, day) DO UPDATE SET n = n + 1', h, userId, key.slice(0, 60), clock.today());
}

export interface Suggestion { id: string; text: string; text_nl: string; action: { kind: 'add' | 'move' | 'resize' | 'compact'; type: string; size?: Size; index?: number; types?: string[] } }

/** Layout suggestions from the last 14 days of use. Read-only: nothing here changes the layout. */
export function dashboardSuggestions(db: Db, h: string, userId: string, device: Device = 'phone'): Suggestion[] {
  const since = addDays(clock.today(), -14);
  const use = new Map(db.all<{ key: string; n: number }>('SELECT key, SUM(n) n FROM ui_usage WHERE household_id = ? AND user_id = ? AND day >= ? GROUP BY key', h, userId, since).map((r) => [r.key, r.n]));
  const n = (k: string) => use.get(k) ?? 0;
  const cfg = getDashboard(db, h, userId);
  const profile = cfg.profiles.find((p) => p.id === cfg.active)!;
  const layout = (profile.layouts[device] ?? profile.layouts.phone ?? []).filter((x) => !x.hidden);
  const at = (type: string) => layout.findIndex((x) => x.type === type);
  const dismissed = new Set(parseJson<string[]>(db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = ? AND key = 'dashboardDismissed'", h, userId)?.value, []));
  const out: Suggestion[] = [];

  const shoppingUse = n('open:shopping') + n('widget:shopping');
  if (shoppingUse >= 5) {
    if (at('shopping') < 0) out.push({ id: 'add-shopping', text: `You opened the shopping list ${shoppingUse}× in two weeks. Add it to your home screen?`, text_nl: `Je opende de boodschappenlijst ${shoppingUse}× in twee weken. Op je startscherm zetten?`, action: { kind: 'add', type: 'shopping', index: 0 } });
    else if (at('shopping') > 1) out.push({ id: 'move-shopping', text: 'You use the shopping list a lot. Move it to the top?', text_nl: 'Je gebruikt de boodschappenlijst vaak. Bovenaan zetten?', action: { kind: 'move', type: 'shopping', index: 0 } });
  }
  if (n('recipe:favourite') >= 3 && at('favourites') < 0) out.push({ id: 'add-favourites', text: 'You often open your favourite recipes. Add a Favourites widget?', text_nl: 'Je opent vaak je favoriete recepten. Een Favorieten-widget toevoegen?', action: { kind: 'add', type: 'favourites', index: 1 } });
  const planUse = n('open:plan') + n('widget:weekPlan') + n('widget:tonight');
  if (planUse >= 6) {
    if (at('weekPlan') < 0) out.push({ id: 'add-weekPlan', text: 'You plan meals often. Add the week planner to your home screen?', text_nl: 'Je plant vaak. De weekplanning op je startscherm zetten?', action: { kind: 'add', type: 'weekPlan', size: 'l', index: 1 } });
    else if (at('weekPlan') > 2) out.push({ id: 'move-weekPlan', text: 'You use the meal planner every few days. Make it more prominent?', text_nl: 'Je gebruikt de planner om de paar dagen. Meer naar voren halen?', action: { kind: 'move', type: 'weekPlan', size: 'l', index: 1 } });
  }
  const nutritionTypes = ['dailyNutrition', 'weeklyNutrition', 'protein', 'nutritionScore', 'nutritionStreak'].filter((t) => layout.some((x) => x.type === t && x.view !== 'compact'));
  const nutritionUse = nutritionTypes.reduce((s, t) => s + n(`widget:${t}`), 0) + n('open:progress');
  if (nutritionTypes.length && n('open:home') >= 7 && nutritionUse <= 1) out.push({ id: 'compact-nutrition', text: 'You rarely look at the nutrition widgets. Show them compact to save space?', text_nl: 'Je kijkt zelden naar de voedingswidgets. Compact tonen om ruimte te sparen?', action: { kind: 'compact', type: nutritionTypes[0], types: nutritionTypes } });
  const inventoryUse = n('open:inventory');
  if (inventoryUse >= 8 && at('inventory') < 0 && at('expiring') < 0) out.push({ id: 'add-expiring', text: 'You check your inventory often. Show what expires soon on Home?', text_nl: 'Je kijkt vaak in je voorraad. Wat bijna over de datum is op je startscherm?', action: { kind: 'add', type: 'expiring', index: 1 } });
  return out.filter((s) => !dismissed.has(s.id));
}

export function dismissSuggestion(db: Db, h: string, userId: string, id: string) {
  const cur = parseJson<string[]>(db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = ? AND key = 'dashboardDismissed'", h, userId)?.value, []);
  db.run("INSERT INTO preferences (household_id, user_id, key, value) VALUES (?, ?, 'dashboardDismissed', ?) ON CONFLICT(household_id, user_id, key) DO UPDATE SET value = excluded.value", h, userId, JSON.stringify([...new Set([...cur, id])]));
}

// ---------- Live widget data ----------

const slimRecipe = (m: RecipeMatch) => ({ id: m.recipe.id, title: m.recipe.title, emoji: m.recipe.emoji, color: m.recipe.color, image_url: m.recipe.image_url, minutes: m.recipe.prep_minutes + m.recipe.cook_minutes, matchPct: m.matchPct, missing: m.missing.length, protein: Math.round(m.recipe.nutritionPerServing?.protein ?? 0), kcal: Math.round(m.recipe.nutritionPerServing?.kcal ?? 0), score: m.recipe.health.score, usesExpiring: m.usesExpiring });
const stock = (s: any) => ({ id: s.product.id, name: s.product.name, name_nl: s.product.name_nl ?? null, emoji: s.product.emoji ?? null, category: s.product.category, qty: s.showEstimate ? s.estimated : s.confirmed, unit: s.product.unit, daysToExpiry: s.daysToExpiry, status: s.status });
const notUndone = 'NOT EXISTS (SELECT 1 FROM inventory_events u WHERE u.reverses_event_id = e.id)';

/** Data for the requested widgets only. Shared lookups are computed once per request. */
export function dashboardData(db: Db, h: string, types: string[]) {
  const today = clock.today();
  const memo = <T>(fn: () => T) => { let v: T | undefined; let done = false; return () => (done ? v! : ((done = true), (v = fn()))); };
  const inv = memo(() => inventorySummary(db, h));
  const g = memo(() => game(db, h));
  const recipes = memo(() => searchRecipes(db, h, { limit: 80 }));
  const inter = memo(() => new Map(db.all<any>('SELECT * FROM recipe_interactions WHERE household_id = ?', h).map((r) => [r.recipe_id, r])));
  const week = memo(() => weekPlan(db, h, today, 7));
  const dinnerDays = () => (week() as any).days?.map((d: any) => ({ date: d.date, slot: d.slots?.find((s: any) => s.meal === 'dinner') ?? null })) ?? [];
  const targets = memo(() => targetsFor(db, h));
  const cooksToday = memo(() => db.all<{ recipe_id: string; servings: number }>('SELECT recipe_id, servings FROM cook_log WHERE household_id = ? AND substr(created_at, 1, 10) = ?', h, today));
  const recipeMap = memo(() => new Map(listRecipes(db, h).map((r) => [r.id, r])));

  const make: Record<string, () => unknown> = {
    quickAdd: () => ({ quick: parseJson(db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = '' AND key = 'quickActions'", h)?.value, []) }),
    shopping: () => {
      syncPlanToShopping(db, h, { quiet: true });
      const l = listShopping(db, h);
      return { count: l.count, items: l.groups.flatMap((gr) => gr.items).slice(0, 12).map((i: any) => ({ id: i.id, name: i.name, detail: i.label || null, productId: i.product_id })) };
    },
    inventory: () => {
      const items = inv().items.filter((s) => s.confirmed > 0 || s.estimated > 0);
      const byCat = new Map<string, number>();
      for (const s of items) byCat.set(s.product.category, (byCat.get(s.product.category) ?? 0) + 1);
      return { total: items.length, leftovers: inv().leftovers.length, categories: [...byCat].sort((a, b) => b[1] - a[1]).map(([category, n]) => ({ category, n })), items: items.slice(0, 10).map(stock) };
    },
    expiring: () => ({ items: inv().items.filter((s) => s.daysToExpiry != null && s.daysToExpiry <= 3 && s.confirmed > 0).sort((a, b) => a.daysToExpiry! - b.daysToExpiry!).slice(0, 8).map(stock) }),
    low: () => ({ items: inv().items.filter((s) => (s.status === 'low' || s.status === 'out') && !s.product.staple).slice(0, 8).map(stock) }),
    recent: () => {
      const rows = db.all<any>(`SELECT e.product_id, MAX(e.created_at) at, SUM(e.delta) qty, e.unit FROM inventory_events e WHERE e.household_id = ? AND e.type = 'purchase' AND e.product_id IS NOT NULL AND ${notUndone} GROUP BY e.product_id ORDER BY at DESC LIMIT 8`, h);
      const names = new Map(inv().items.map((s) => [s.product.id, s.product]));
      return { items: rows.map((r) => ({ id: r.product_id, name: names.get(r.product_id)?.name ?? r.product_id, name_nl: (names.get(r.product_id) as any)?.name_nl ?? null, qty: r.qty, unit: r.unit, at: r.at })) };
    },
    leftovers: () => ({ items: inv().leftovers.map((l) => ({ id: l.id, title: l.title, quantity: l.quantity, location: l.location_name, freezer: l.location_kind === 'freezer', daysToExpiry: l.days_to_expiry })) }),
    listSuggestions: () => ({ items: shoppingSuggestions(db, h).slice(0, 5) }),
    fifo: () => {
      const items = inv().items.filter((s) => s.confirmed > 0).map((s) => {
        const lot = s.lots.find((l: any) => l.quantity > 0) as any;
        const risk = lot ? riskOf({ qty: lot.quantity, expires: lot.expires_on, added: lot.purchased_at ?? lot.created_at, opened: !!lot.opened_at }, s.product.shelf_life_days ?? null, today) : 0;
        return { s, risk };
      }).filter((x) => x.risk >= 0.08).sort((a, b) => b.risk - a.risk).slice(0, 5);
      return { items: items.map(({ s, risk }) => ({ ...stock(s), risk: Math.round(risk * 100) / 100, recipe: (() => { const m = recipes().find((r) => r.recipe.ingredients.some((i) => i.product_id === s.product.id)); return m ? { id: m.recipe.id, title: m.recipe.title, emoji: m.recipe.emoji } : null; })() })) };
    },
    favourites: () => {
      const it = inter();
      const fav = recipes().filter((m) => (it.get(m.recipe.id)?.rating ?? 0) >= 4 || (it.get(m.recipe.id)?.priority ?? 0) >= 2 || it.get(m.recipe.id)?.saved);
      fav.sort((a, b) => (it.get(b.recipe.id)?.rating ?? 0) - (it.get(a.recipe.id)?.rating ?? 0));
      return { items: fav.slice(0, 8).map((m) => ({ ...slimRecipe(m), rating: it.get(m.recipe.id)?.rating ?? null })) };
    },
    recipeOfDay: () => {
      const top = recipes().filter((m) => m.matchPct >= 0.5).slice(0, 6);
      const pool = top.length ? top : recipes().slice(0, 6);
      const seed = [...today].reduce((s, c) => s + c.charCodeAt(0), 0);
      const m = pool[seed % Math.max(1, pool.length)];
      return { recipe: m ? { ...slimRecipe(m), reasons: m.reasons.slice(0, 2) } : null };
    },
    recentlyCooked: () => ({ items: g().recent.slice(0, 6).map((e: any) => ({ id: e.recipeId, title: e.title, emoji: e.emoji, date: e.date, score: e.score, rating: inter().get(e.recipeId)?.rating ?? null })) }),
    toTry: () => {
      const it = inter();
      return { items: recipes().filter((m) => it.get(m.recipe.id)?.to_try && !it.get(m.recipe.id)?.cooked_count).slice(0, 8).map(slimRecipe) };
    },
    quickMeals: () => ({ items: recipes().filter((m) => m.recipe.prep_minutes + m.recipe.cook_minutes <= 25).slice(0, 8).map(slimRecipe) }),
    highProtein: () => ({ items: [...recipes()].sort((a, b) => (b.recipe.nutritionPerServing?.protein ?? 0) - (a.recipe.nutritionPerServing?.protein ?? 0)).slice(0, 8).map(slimRecipe) }),
    fromStock: () => ({ items: [...recipes()].filter((m) => m.matchPct >= 0.7).sort((a, b) => b.matchPct - a.matchPct || b.usesExpiring.length - a.usesExpiring.length).slice(0, 8).map(slimRecipe) }),
    weekPlan: () => ({ days: dinnerDays().map((d: any) => ({ date: d.date, id: d.slot?.id ?? null, title: d.slot?.recipe?.title ?? d.slot?.title ?? null, emoji: d.slot?.recipe?.emoji ?? null, recipeId: d.slot?.recipe?.id ?? null, status: d.slot?.status ?? null, servings: d.slot?.servings ?? null, locked: !!d.slot?.locked })) }),
    tonight: () => {
      const s = todaysMeals(db, h).find((x: any) => x.meal === 'dinner') as any;
      return { slot: s ? { id: s.id, status: s.status, servings: s.servings, title: s.recipe?.title ?? s.title ?? null, emoji: s.recipe?.emoji ?? null, recipeId: s.recipe?.id ?? null, minutes: s.recipe?.minutes ?? null, color: s.recipe?.color ?? null } : null };
    },
    missing: () => {
      syncPlanToShopping(db, h, { quiet: true });
      const items = db.all<any>("SELECT id, name, packages, checked FROM shopping_items WHERE household_id = ? AND (plan_driven = 1 OR reason = 'meal_plan') AND checked = 0 ORDER BY created_at", h);
      return { items: items.slice(0, 10).map((i) => ({ id: i.id, name: i.name, packages: i.packages })), count: items.length };
    },
    planProgress: () => {
      const start = weekOf(today);
      const rows = db.all<{ status: string }>("SELECT status FROM meal_slots WHERE household_id = ? AND meal = 'dinner' AND recipe_id IS NOT NULL AND date BETWEEN ? AND ? AND status != 'skipped'", h, start, addDays(start, 6));
      return { planned: rows.length, cooked: rows.filter((r) => r.status === 'cooked').length, weekStart: start };
    },
    autoPlan: () => ({ plannedNext7: db.get<{ n: number }>("SELECT COUNT(DISTINCT date) n FROM meal_slots WHERE household_id = ? AND meal = 'dinner' AND status != 'skipped' AND date BETWEEN ? AND ?", h, today, addDays(today, 6))!.n }),
    dailyNutrition: () => {
      const tot = { kcal: 0, protein: 0, carbs: 0, fat: 0 };
      for (const c of cooksToday()) {
        const n = recipeMap().get(c.recipe_id)?.nutritionPerServing;
        if (!n) continue;
        for (const k of Object.keys(tot) as (keyof typeof tot)[]) tot[k] += n[k] ?? 0;
      }
      const t = targets();
      return { logged: cooksToday().length, totals: Object.fromEntries(Object.entries(tot).map(([k, v]) => [k, Math.round(v)])), targets: { kcal: Math.round(t.kcal), protein: Math.round(t.protein), carbs: Math.round((t.kcal * 0.5) / 4), fat: Math.round((t.kcal * 0.3) / 9) } };
    },
    protein: () => {
      const p = cooksToday().reduce((s, c) => s + (recipeMap().get(c.recipe_id)?.nutritionPerServing?.protein ?? 0), 0);
      return { today: Math.round(p), target: Math.round(targets().protein), dinnerTarget: Math.round(targets().protein * 0.35) };
    },
    weeklyNutrition: () => ({ days: g().week, average: g().nutrition.weekAverage }),
    nutritionScore: () => ({ today: g().nutrition.today, weekAverage: g().nutrition.weekAverage }),
    nutritionStreak: () => ({ current: g().streaks.nutrition.current }),
    cookingStreak: () => ({ ...g().streaks.cooking }),
    xp: () => ({ xp: g().xp, level: g().level }),
    challenge: () => ({ current: g().challenge.current, suggestion: g().challenge.suggestions[0] ?? null, all: g().challenge.all }),
    journey: () => {
      const j = journey(db, h);
      const ch = j.chapters.find((c) => c.unlocked && !c.completed) ?? j.chapters[j.chapters.length - 1];
      return { chapter: { n: ch.n, title: ch.title, title_nl: ch.title_nl, emoji: ch.emoji, env: ch.env, done: ch.tasksDone, total: ch.tasksTotal }, next: j.current, companion: { skin: j.companion.skin, stage: j.companion.stage, name: j.companion.name }, nodes: ch.path.map((n: any) => ({ id: n.id, state: n.state, emoji: n.emoji, kind: n.kind })) };
    },
    achievements: () => {
      const nodes = db.all<{ node_id: string; kind: string; xp: number; completed_at: string }>("SELECT * FROM journey_nodes WHERE household_id = ? ORDER BY completed_at DESC LIMIT 6", h);
      const j = nodes.length ? journey(db, h) : null;
      const title = (id: string) => {
        if (!j) return null;
        for (const c of j.chapters) for (const n of [...c.path, ...c.bonus]) if (n.id === id) return { title: n.title, title_nl: n.title_nl, emoji: n.emoji };
        for (const t of j.tracks) for (const n of t.nodes) if (n.id === id) return { title: `${t.title}: ${n.name}`, title_nl: `${t.title_nl}: ${n.name_nl}`, emoji: t.emoji };
        return null;
      };
      const badges = g().achievements.filter((a: any) => a.done).slice(-3).map((a: any) => ({ id: a.id, title: a.title, title_nl: a.title_nl, emoji: a.emoji, xp: a.xp, at: null }));
      return { items: [...nodes.map((n) => ({ id: n.node_id, ...(title(n.node_id) ?? { title: n.node_id, title_nl: n.node_id, emoji: '⭐' }), xp: n.xp, at: n.completed_at })), ...badges].slice(0, 6) };
    },
    wasteStats: () => {
      const from = addDays(today, -30);
      const rescued = db.get<{ n: number }>(`SELECT COUNT(DISTINCT e.product_id || COALESCE(e.batch_id, e.id)) n FROM inventory_events e JOIN inventory_lots l ON l.id = e.lot_id WHERE e.household_id = ? AND e.type IN ('cook','consume') AND l.expires_on IS NOT NULL AND julianday(l.expires_on) - julianday(substr(e.created_at, 1, 10)) BETWEEN 0 AND 2 AND e.created_at >= ? AND ${notUndone}`, h, from)!.n;
      const used = db.get<{ n: number }>(`SELECT COUNT(*) n FROM inventory_events e WHERE e.household_id = ? AND e.type IN ('cook','consume') AND e.created_at >= ? AND ${notUndone}`, h, from)!.n;
      const thrown = db.get<{ n: number }>(`SELECT COUNT(*) n FROM inventory_events e WHERE e.household_id = ? AND e.type = 'discard' AND e.created_at >= ? AND ${notUndone}`, h, from)!.n;
      const a = analytics(db, h, 30);
      return { rescued, used, thrown, wastedValue: a.wasted, usedPct: used + thrown ? Math.round((used / (used + thrown)) * 100) : null, lowWasteStreak: g().streaks.lowWaste.current };
    },
    moneySaved: () => {
      const from = addDays(today, -30);
      const rescuedValue = db.get<{ v: number }>(`SELECT COALESCE(SUM(-e.delta * COALESCE(l.unit_price, 0)), 0) v FROM inventory_events e JOIN inventory_lots l ON l.id = e.lot_id WHERE e.household_id = ? AND e.type IN ('cook','consume') AND l.is_leftover = 0 AND l.expires_on IS NOT NULL AND julianday(l.expires_on) - julianday(substr(e.created_at, 1, 10)) BETWEEN 0 AND 2 AND e.created_at >= ? AND ${notUndone}`, h, from)!.v;
      const leftovers = db.all<{ recipe_id: string | null; portions: number }>(`SELECT l.recipe_id, SUM(-e.delta) portions FROM inventory_events e JOIN inventory_lots l ON l.id = e.lot_id WHERE e.household_id = ? AND e.type = 'consume' AND l.is_leftover = 1 AND e.created_at >= ? AND ${notUndone} GROUP BY l.recipe_id`, h, from);
      const leftoverValue = leftovers.reduce((s, l) => s + l.portions * (recipeMap().get(l.recipe_id ?? '')?.costPerServing ?? 2.5), 0);
      return { total: Math.round((rescuedValue + leftoverValue) * 100) / 100, rescued: Math.round(rescuedValue * 100) / 100, leftovers: Math.round(leftoverValue * 100) / 100, days: 30 };
    },
    cookingStats: () => {
      const all = db.all<{ recipe_id: string; created_at: string }>('SELECT recipe_id, created_at FROM cook_log WHERE household_id = ?', h);
      const last30 = all.filter((c) => c.created_at >= addDays(today, -30));
      const mins = all.map((c) => recipeMap().get(c.recipe_id)).filter(Boolean).map((r) => r!.prep_minutes + r!.cook_minutes);
      return { total: all.length, last30: last30.length, distinct: new Set(all.map((c) => c.recipe_id)).size, avgMinutes: mins.length ? Math.round(mins.reduce((a, b) => a + b, 0) / mins.length) : null };
    },
    spending: () => {
      const weeks = Array.from({ length: 6 }, (_, i) => addDays(weekOf(today), -7 * (5 - i)));
      const rows = db.all<{ d: string; total: number }>('SELECT substr(purchased_at, 1, 10) d, SUM(COALESCE(total_price, 0)) total FROM purchases WHERE household_id = ? AND purchased_at >= ? GROUP BY d', h, weeks[0]);
      const per = weeks.map((w) => ({ week: w, total: Math.round(rows.filter((r) => weekOf(r.d) === w).reduce((s, r) => s + r.total, 0) * 100) / 100 }));
      const priced = db.get<{ n: number; p: number }>('SELECT COUNT(*) n, COUNT(total_price) p FROM purchases WHERE household_id = ? AND purchased_at >= ?', h, weeks[0])!;
      return { weeks: per, thisWeek: per[per.length - 1].total, pricedShare: priced.n ? Math.round((priced.p / priced.n) * 100) : null };
    },
    topIngredients: () => {
      const rows = db.all<{ product_id: string; n: number }>(`SELECT e.product_id, COUNT(*) n FROM inventory_events e WHERE e.household_id = ? AND e.type IN ('cook','consume') AND e.product_id IS NOT NULL AND e.created_at >= ? AND ${notUndone} GROUP BY e.product_id ORDER BY n DESC LIMIT 8`, h, addDays(today, -90));
      const prods = new Map(db.all<any>(`SELECT * FROM products WHERE id IN (${rows.map(() => '?').join(',') || "''"})`, ...rows.map((r) => r.product_id)).map((p) => [p.id, p]));
      return { items: rows.map((r) => ({ id: r.product_id, name: prods.get(r.product_id) ? displayName(prods.get(r.product_id), 'en') : r.product_id, name_nl: prods.get(r.product_id) ? displayName(prods.get(r.product_id), 'nl') : r.product_id, n: r.n })) };
    },
    activity: () => ({ items: recentEvents(db, h, 8) }),
  };
  const out: Record<string, unknown> = {};
  for (const t of new Set(types)) {
    if (!make[t]) continue;
    try {
      out[t] = make[t]();
    } catch (e: any) {
      out[t] = { error: e.message };
    }
  }
  return out;
}
