// Dietary needs: who eats in this household, their diets, allergies, things they avoid, and
// nutrition targets. Recipe suitability is computed from the actual ingredients (product allergens
// and diet flags), not from hand-written recipe tags, so user and imported recipes are checked too.
import type { Db } from '../db/db.ts';
import { parseJson } from '../db/db.ts';
import type { Product } from './products.ts';

export const ALLERGENS = ['gluten', 'crustaceans', 'eggs', 'fish', 'peanuts', 'soy', 'milk', 'nuts', 'celery', 'mustard', 'sesame', 'sulphites', 'lupin', 'molluscs'] as const;
export const DIETS = ['vegetarian', 'vegan', 'pescatarian', 'gluten-free', 'dairy-free', 'halal', 'no-pork', 'no-alcohol', 'low-carb'] as const;
export type Diet = (typeof DIETS)[number];

export interface Person {
  id: string;
  name: string;
  diets: string[];
  allergies: string[];
  avoid: string[]; // product ids
  kcal?: number | null;     // daily target
  protein?: number | null;  // grams per day
}

export interface DietaryNeeds {
  people: Person[];
  diets: Set<string>;       // union over everyone eating together
  allergies: Set<string>;
  avoid: Set<string>;
}

const LOW_CARB_MAX = 30; // g carbs per serving

export function getPeople(db: Db, householdId: string): Person[] {
  const pref = (k: string) => db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = '' AND key = ?", householdId, k)?.value;
  const people = parseJson<Person[] | null>(pref('people'), null);
  if (people?.length) return people;
  // Before people were introduced, needs were stored household-wide; present them as one person.
  return [{ id: 'everyone', name: 'Everyone', diets: parseJson<string[]>(pref('diet'), []), allergies: parseJson<string[]>(pref('allergies'), []), avoid: parseJson<string[]>(pref('dislikes'), []) }];
}

export function savePeople(db: Db, householdId: string, people: Person[]) {
  db.run("INSERT OR REPLACE INTO preferences (household_id, user_id, key, value) VALUES (?, '', 'people', ?)", householdId, JSON.stringify(people));
}

export function dietaryNeeds(db: Db, householdId: string): DietaryNeeds {
  const people = getPeople(db, householdId);
  return {
    people,
    diets: new Set(people.flatMap((p) => p.diets)),
    allergies: new Set(people.flatMap((p) => p.allergies)),
    avoid: new Set(people.flatMap((p) => p.avoid)),
  };
}

/** Why a single product doesn't fit a diet or allergy list (empty = fine). */
export function productConflicts(p: Pick<Product, 'id' | 'allergens' | 'diet_flags'>, needs: { diets: Set<string>; allergies: Set<string>; avoid?: Set<string> }): string[] {
  const out: string[] = [];
  for (const a of p.allergens) if (needs.allergies.has(a)) out.push(`allergy:${a}`);
  const f = new Set(p.diet_flags);
  if (needs.diets.has('vegan') && f.has('animal')) out.push('diet:vegan');
  if (needs.diets.has('vegetarian') && (f.has('meat') || f.has('fish'))) out.push('diet:vegetarian');
  if (needs.diets.has('pescatarian') && f.has('meat')) out.push('diet:pescatarian');
  if (needs.diets.has('gluten-free') && p.allergens.includes('gluten')) out.push('diet:gluten-free');
  if (needs.diets.has('dairy-free') && p.allergens.includes('milk')) out.push('diet:dairy-free');
  if ((needs.diets.has('halal') || needs.diets.has('no-pork')) && f.has('pork')) out.push(needs.diets.has('halal') ? 'diet:halal' : 'diet:no-pork');
  if ((needs.diets.has('halal') || needs.diets.has('no-alcohol')) && f.has('alcohol')) out.push(needs.diets.has('halal') ? 'diet:halal' : 'diet:no-alcohol');
  if (needs.avoid?.has(p.id)) out.push('avoid');
  return [...new Set(out)];
}

export interface Suitability {
  ok: boolean;
  conflicts: { position: number; name: string; reasons: string[] }[];         // required ingredients
  optionalConflicts: { position: number; name: string; reasons: string[] }[]; // "leave out the feta"
  notes: string[];                                                             // e.g. low-carb
}

interface IngredientLike { position: number; name: string; optional: boolean; product?: Pick<Product, 'id' | 'name' | 'allergens' | 'diet_flags'> | null }

export function recipeSuitability(r: { ingredients: IngredientLike[]; nutritionPerServing: { carbs: number } | null }, needs: DietaryNeeds): Suitability {
  const conflicts: Suitability['conflicts'] = [];
  const optionalConflicts: Suitability['optionalConflicts'] = [];
  for (const i of r.ingredients) {
    if (!i.product) continue;
    const reasons = productConflicts(i.product, needs);
    if (!reasons.length) continue;
    (i.optional ? optionalConflicts : conflicts).push({ position: i.position, name: i.product.name, reasons });
  }
  const notes: string[] = [];
  let ok = conflicts.length === 0;
  if (needs.diets.has('low-carb') && r.nutritionPerServing && r.nutritionPerServing.carbs > LOW_CARB_MAX) {
    ok = false;
    notes.push(`diet:low-carb`);
  }
  return { ok, conflicts, optionalConflicts, notes };
}

/** Diets a recipe fits, computed from its ingredients. */
export function recipeDiets(r: { ingredients: IngredientLike[]; nutritionPerServing: { carbs: number } | null }): string[] {
  const out: string[] = [];
  for (const d of DIETS) {
    const s = recipeSuitability(r, { people: [], diets: new Set([d]), allergies: new Set(), avoid: new Set() });
    if (s.ok) out.push(d);
  }
  return out;
}

/** Allergens in a recipe's required ingredients (and separately in optional ones). */
export function recipeAllergens(r: { ingredients: IngredientLike[] }): { required: string[]; optional: string[] } {
  const req = new Set<string>();
  const opt = new Set<string>();
  for (const i of r.ingredients) for (const a of i.product?.allergens ?? []) (i.optional ? opt : req).add(a);
  return { required: [...req], optional: [...opt].filter((a) => !req.has(a)) };
}

/** Map Open Food Facts tags to our allergen keys and diet flags. */
export function fromOpenFoodFacts(allergenTags: string[] = [], analysisTags: string[] = []): { allergens: string[]; diet_flags: string[] } {
  const map: Record<string, string> = {
    'en:gluten': 'gluten', 'en:crustaceans': 'crustaceans', 'en:eggs': 'eggs', 'en:fish': 'fish', 'en:peanuts': 'peanuts', 'en:soybeans': 'soy',
    'en:milk': 'milk', 'en:nuts': 'nuts', 'en:celery': 'celery', 'en:mustard': 'mustard', 'en:sesame-seeds': 'sesame',
    'en:sulphur-dioxide-and-sulphites': 'sulphites', 'en:lupin': 'lupin', 'en:molluscs': 'molluscs',
  };
  const allergens = [...new Set(allergenTags.map((t) => map[t]).filter(Boolean))];
  const flags = new Set<string>();
  if (analysisTags.includes('en:non-vegan')) flags.add('animal');
  if (analysisTags.includes('en:non-vegetarian')) {
    flags.add('meat');
    flags.add('animal');
  }
  return { allergens, diet_flags: [...flags] };
}
