// Seasonal events: a month (or two) with a theme. Cook three matching recipes in the window for bonus XP and
// a Pip look you can only get then. Friends see each other's count on the event board.
import type { Db } from '../db/db.ts';

export interface SeasonEvent { id: string; emoji: string; title: [string, string]; desc: [string, string]; from: string; to: string; words: string[]; goal: number; xp: number; skin: string }

/** Month-day windows; the same every year. */
export const EVENTS: SeasonEvent[] = [
  { id: 'greens', emoji: '🥬', title: ['Spring Greens', 'Lentegroen'], desc: ['Cook 3 dishes with fresh greens', 'Kook 3 gerechten met vers groen'], from: '04-01', to: '04-30', words: ['salad', 'salade', 'asparagus', 'asperge', 'spinach', 'spinazie', 'erwten', 'doperwt', 'groene'], goal: 3, xp: 40, skin: 'mint' },
  { id: 'summer', emoji: '🥗', title: ['Summer Salads & Grills', 'Zomersalades & BBQ'], desc: ['Cook 3 salads or grilled dishes', 'Kook 3 salades of gegrilde gerechten'], from: '07-01', to: '08-31', words: ['salad', 'salade', 'bbq', 'grill', 'gegrild', 'barbecue', 'skewer', 'spies'], goal: 3, xp: 40, skin: 'watermelon' },
  { id: 'pumpkin', emoji: '🎃', title: ['Pumpkin Month', 'Pompoenmaand'], desc: ['Cook 3 pumpkin or squash dishes', 'Kook 3 gerechten met pompoen'], from: '10-01', to: '10-31', words: ['pumpkin', 'pompoen', 'squash', 'butternut', 'flespompoen'], goal: 3, xp: 40, skin: 'pumpkin' },
  { id: 'soup', emoji: '🍲', title: ['Soup Season', 'Soepseizoen'], desc: ['Cook 3 soups', 'Kook 3 soepen'], from: '11-01', to: '11-30', words: ['soup', 'soep', 'broth', 'bouillon', 'ramen', 'pho', 'minestrone', 'chowder', 'bisque'], goal: 3, xp: 40, skin: 'beet' },
  { id: 'winter', emoji: '🫕', title: ['Winter Warmers', 'Winterkost'], desc: ['Cook 3 stews, stamppots or curries', 'Kook 3 stoofpotten, stamppotten of curry’s'], from: '12-01', to: '12-31', words: ['stew', 'stoof', 'stamppot', 'hutspot', 'chili', 'curry', 'casserole', 'goulash', 'ovenschotel'], goal: 3, xp: 40, skin: 'cocoa' },
];

export const eventWindow = (e: SeasonEvent, today: string) => ({ start: `${today.slice(0, 4)}-${e.from}`, end: `${today.slice(0, 4)}-${e.to}` });
export const currentEvent = (today: string) => EVENTS.find((e) => today.slice(5) >= e.from && today.slice(5) <= e.to) ?? null;
/** The next one, to show what's coming. */
export const nextEvent = (today: string) => EVENTS.find((e) => e.from > today.slice(5)) ?? EVENTS[0];

/** Matching meals this household cooked during the event. */
export function eventCount(db: Db, h: string, e: SeasonEvent, today: string): number {
  const w = eventWindow(e, today);
  const rows = db.all<{ title: string | null; tags: string | null; cuisine: string | null }>(
    "SELECT r.title, r.tags, r.cuisine FROM cook_log c LEFT JOIN recipes r ON r.id = c.recipe_id WHERE c.household_id = ? AND substr(c.created_at, 1, 10) BETWEEN ? AND ?",
    h, w.start, w.end,
  );
  return rows.filter((r) => {
    const text = `${r.title ?? ''} ${r.tags ?? ''}`.toLowerCase();
    return e.words.some((word) => text.includes(word));
  }).length;
}
