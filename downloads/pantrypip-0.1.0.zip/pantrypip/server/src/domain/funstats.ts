// "Your year in food": playful statistics from the ledger, purchases and cooking log.
// "Eaten" includes consumption nobody logged: a product that was bought and is now gone was used
// (consume + cook + negative corrections, net of positive corrections, never counting undone events).
import type { Db } from '../db/db.ts';
import { clock, daysBetween } from '../clock.ts';
import { rowToProduct } from './products.ts';
import { getRecipe } from './recipes.ts';

export type Period = 'month' | 'year' | 'all';

export function periodStart(period: Period, now = clock.now()): string {
  if (period === 'all') return '0000-01-01';
  const d = new Date(Date.UTC(now.getUTCFullYear(), period === 'month' ? now.getUTCMonth() : 0, 1));
  return d.toISOString();
}

const NOT_UNDONE = 'NOT EXISTS (SELECT 1 FROM inventory_events u WHERE u.reverses_event_id = e.id)';

export function funStats(db: Db, householdId: string, period: Period = 'year') {
  const from = periodStart(period);
  const p = [householdId, from];

  // ---- What you ate ----
  const eatenRows = db.all<any>(
    `SELECT e.product_id, -SUM(e.delta) AS qty, COUNT(DISTINCT substr(e.created_at, 1, 10)) AS days, pr.*
     FROM inventory_events e JOIN products pr ON pr.id = e.product_id
     WHERE e.household_id = ? AND e.created_at >= ? AND e.type IN ('consume', 'cook', 'adjust') AND ${NOT_UNDONE}
     GROUP BY e.product_id HAVING qty > 0`,
    ...p,
  );
  const eaten = eatenRows.map((r) => {
    const product = rowToProduct(r);
    const grams = product.unit === 'pcs' ? r.qty * (product.piece_size ?? 0) : r.qty;
    return { productId: product.id, name: product.name, name_nl: product.name_nl, unit: product.unit, category: product.category, quantity: r.qty, packages: r.qty / (product.package_size || 1), grams, days: r.days, synonyms: product.synonyms };
  });
  eaten.sort((a, b) => b.packages - a.packages);
  const sumWhere = (pred: (x: (typeof eaten)[number]) => boolean, f: (x: (typeof eaten)[number]) => number) => eaten.filter(pred).reduce((s, x) => s + f(x), 0);
  const eggs = sumWhere((x) => x.unit === 'pcs' && x.synonyms.includes('eggs'), (x) => x.quantity);
  const milkLitres = sumWhere((x) => x.unit === 'ml' && x.synonyms.some((s) => s === 'milk' || s === 'melk' || s.endsWith(' milk')), (x) => x.quantity) / 1000;
  const coffeeGrams = sumWhere((x) => x.synonyms.includes('coffee'), (x) => x.quantity);
  const fruitVegKg = sumWhere((x) => x.category === 'produce', (x) => x.grams) / 1000;
  const breadSlices = sumWhere((x) => x.synonyms.includes('bread'), (x) => x.quantity / 35);
  const pastaKg = sumWhere((x) => x.synonyms.includes('pasta') || x.synonyms.includes('rice'), (x) => x.quantity) / 1000;

  // Different fruit & veg: eaten or bought in the period (variety is the fun part, not volume).
  const plants = db.all<{ name: string }>(
    `SELECT DISTINCT pr.name FROM products pr WHERE pr.category = 'produce' AND pr.id IN (
       SELECT product_id FROM purchases WHERE household_id = ? AND purchased_at >= ?
       UNION SELECT e.product_id FROM inventory_events e WHERE e.household_id = ? AND e.created_at >= ? AND e.type IN ('consume','cook'))`,
    householdId, from, householdId, from,
  );

  // Food rescued: used within two days of its (estimated) best-before date.
  const rescued = db.get<{ n: number }>(
    `SELECT COUNT(DISTINCT e.lot_id) n FROM inventory_events e JOIN inventory_lots l ON l.id = e.lot_id
     WHERE e.household_id = ? AND e.created_at >= ? AND e.type IN ('consume','cook') AND l.expires_on IS NOT NULL
       AND julianday(l.expires_on) - julianday(substr(e.created_at, 1, 10)) BETWEEN 0 AND 2 AND ${NOT_UNDONE}`,
    ...p,
  )!.n;

  // ---- Cooking ----
  const cooks = db.all<{ recipe_id: string; servings: number; created_at: string }>('SELECT recipe_id, servings, created_at FROM cook_log WHERE household_id = ? AND created_at >= ? ORDER BY created_at', ...p);
  const recipeCache = new Map<string, ReturnType<typeof getRecipe> | null>();
  const recipe = (id: string) => {
    if (!recipeCache.has(id)) {
      try {
        recipeCache.set(id, getRecipe(db, householdId, id));
      } catch {
        recipeCache.set(id, null);
      }
    }
    return recipeCache.get(id)!;
  };
  const countBy = <T,>(xs: T[], key: (x: T) => string | null | undefined) => {
    const m = new Map<string, number>();
    for (const x of xs) {
      const k = key(x);
      if (k) m.set(k, (m.get(k) ?? 0) + 1);
    }
    return [...m.entries()].sort((a, b) => b[1] - a[1]);
  };
  const topRecipes = countBy(cooks, (c) => c.recipe_id).slice(0, 3).map(([id, n]) => ({ id, title: recipe(id)?.title ?? 'Recipe', emoji: recipe(id)?.emoji ?? '🍽️', times: n }));
  const cuisines = countBy(cooks, (c) => recipe(c.recipe_id)?.cuisine);
  const weekdays = countBy(cooks, (c) => String(new Date(c.created_at).getDay()));
  const firstEver = new Map(db.all<{ recipe_id: string; first: string }>('SELECT recipe_id, MIN(created_at) first FROM cook_log WHERE household_id = ? GROUP BY recipe_id', householdId).map((r) => [r.recipe_id, r.first]));
  const newRecipes = [...firstEver.values()].filter((d) => d >= from).length;
  const servingsCooked = cooks.reduce((s, c) => s + c.servings, 0);
  const kcalCooked = cooks.reduce((s, c) => s + (recipe(c.recipe_id)?.nutritionPerServing?.kcal ?? 0) * c.servings, 0);
  const proteinCooked = cooks.reduce((s, c) => s + (recipe(c.recipe_id)?.nutritionPerServing?.protein ?? 0) * c.servings, 0);

  // Streaks: consecutive days with at least one cooked meal.
  const days = [...new Set(cooks.map((c) => c.created_at.slice(0, 10)))].sort();
  let longest = 0, run = 0, prev: string | null = null;
  for (const d of days) {
    run = prev && Math.round(daysBetween(prev, d)) === 1 ? run + 1 : 1;
    longest = Math.max(longest, run);
    prev = d;
  }
  const today = clock.today();
  const current = days.length && Math.round(daysBetween(days[days.length - 1], today)) <= 1 ? run : 0;

  // ---- Shopping & waste ----
  const shop = db.get<{ spent: number; trips: number }>("SELECT ROUND(COALESCE(SUM(total_price), 0), 2) spent, COUNT(DISTINCT substr(purchased_at, 1, 10)) trips FROM purchases WHERE household_id = ? AND purchased_at >= ?", ...p)!;
  const stores = db.all<{ store: string; trips: number; spent: number }>(
    "SELECT store, COUNT(DISTINCT substr(purchased_at, 1, 10)) trips, ROUND(SUM(COALESCE(total_price, 0)), 2) spent FROM purchases WHERE household_id = ? AND purchased_at >= ? AND store IS NOT NULL GROUP BY store ORDER BY trips DESC, spent DESC LIMIT 3",
    ...p,
  );
  const biggestShop = db.get<{ day: string; total: number }>(
    'SELECT substr(purchased_at, 1, 10) day, ROUND(SUM(COALESCE(total_price, 0)), 2) total FROM purchases WHERE household_id = ? AND purchased_at >= ? GROUP BY day ORDER BY total DESC LIMIT 1',
    ...p,
  );
  const waste = db.get<{ items: number; value: number }>(
    `SELECT COUNT(*) items, ROUND(SUM(-e.delta * COALESCE(l.unit_price, 0)), 2) value FROM inventory_events e JOIN inventory_lots l ON l.id = e.lot_id
     WHERE e.household_id = ? AND e.created_at >= ? AND e.type = 'discard' AND ${NOT_UNDONE}`,
    ...p,
  )!;
  const wasteRate = shop.spent > 0 ? Math.round(((waste.value ?? 0) / shop.spent) * 1000) / 10 : 0;

  // ---- Effort the app saved ----
  const bySource = new Map(db.all<{ source: string; n: number }>("SELECT source, COUNT(DISTINCT batch_id) n FROM inventory_events WHERE household_id = ? AND created_at >= ? AND type != 'undo' GROUP BY source", ...p).map((r) => [r.source, r.n]));
  const receipts = db.get<{ n: number }>("SELECT COUNT(*) n FROM receipts WHERE household_id = ? AND status = 'committed' AND committed_at >= ?", ...p)!.n;
  const voice = db.get<{ n: number }>('SELECT COUNT(*) n FROM assistant_turns WHERE household_id = ? AND created_at >= ? AND batch_id IS NOT NULL', ...p)!.n;

  return {
    period,
    from: period === 'all' ? null : from.slice(0, 10),
    mostEaten: eaten.slice(0, 5).map(({ synonyms, grams, ...x }) => (void synonyms, void grams, x)),
    eggs: Math.round(eggs),
    milkLitres: Math.round(milkLitres * 10) / 10,
    coffeeCups: Math.round(coffeeGrams / 7),
    fruitVegKg: Math.round(fruitVegKg * 10) / 10,
    breadSlices: Math.round(breadSlices),
    pastaKg: Math.round(pastaKg * 10) / 10,
    plantVariety: plants.length,
    plants: plants.map((x) => x.name).slice(0, 30),
    foodRescued: rescued,
    cooking: {
      meals: cooks.length,
      servings: Math.round(servingsCooked),
      kcal: Math.round(kcalCooked),
      protein: Math.round(proteinCooked),
      differentRecipes: new Set(cooks.map((c) => c.recipe_id)).size,
      newRecipes,
      topRecipes,
      favouriteCuisine: cuisines[0] ? { name: cuisines[0][0], times: cuisines[0][1] } : null,
      busiestWeekday: weekdays[0] ? { day: Number(weekdays[0][0]), times: weekdays[0][1] } : null,
      longestStreak: longest,
      currentStreak: current,
    },
    shopping: { spent: shop.spent, trips: shop.trips, topStores: stores, biggestShop: biggestShop ?? null },
    waste: { items: waste.items, value: waste.value ?? 0, ratePct: wasteRate },
    effort: { receipts, voiceCommands: voice, barcodeScans: bySource.get('barcode') ?? 0, cookedFromPlan: bySource.get('recipe') ?? 0, listTrips: bySource.get('shopping_list') ?? 0 },
  };
}
