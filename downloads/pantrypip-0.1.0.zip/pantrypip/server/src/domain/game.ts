// Progress: XP, ranks, five streaks, daily nutrition score, weekly quests, challenges and badges, all
// derived from what actually happened (cook log, plan, ledger). Only settings (XP values, the joined
// challenge, the chosen accent) are stored, so undoing a meal also undoes its XP.
// XP rewards outcomes (cooking, trying, rescuing food, balanced eating), never app taps, and the
// nutrition reward stops growing at 70: consistency beats perfection, and eating less never scores.
import type { Db } from '../db/db.ts';
import { parseJson } from '../db/db.ts';
import { clock, addDays, daysBetween } from '../clock.ts';
import { listRecipes, type Recipe } from './recipes.ts';
import { mealScore, DINNER_SHARE } from './health.ts';
import { targetsFor } from './targets.ts';

export const RANKS: { name: string; name_nl: string; emoji: string; accent: string }[] = [
  { name: 'Kitchen Beginner', name_nl: 'Keukenbeginner', emoji: '🥄', accent: 'herb' },
  { name: 'Home Cook', name_nl: 'Thuiskok', emoji: '🍳', accent: 'saffron' },
  { name: 'Ingredient Explorer', name_nl: 'Ingrediëntenontdekker', emoji: '🧭', accent: 'ocean' },
  { name: 'Confident Cook', name_nl: 'Zelfverzekerde kok', emoji: '🔪', accent: 'berry' },
  { name: 'Nutrition Apprentice', name_nl: 'Voedingsleerling', emoji: '🥦', accent: 'plum' },
  { name: 'Kitchen Expert', name_nl: 'Keukenexpert', emoji: '👩‍🍳', accent: 'copper' },
  { name: 'Culinary Master', name_nl: 'Culinaire meester', emoji: '🏆', accent: 'gold' },
];
const TIER_XP = [0, 50, 120, 200, 300, 420, 560, 720, 900, 1100, 1350, 1650, 2000, 2400, 2850, 3350, 3900, 4500, 5200, 6000, 7000];
const ROMAN = ['I', 'II', 'III'];
export const LEVELS = TIER_XP.map((xp, i) => {
  const r = RANKS[Math.floor(i / 3)];
  return { xp, name: `${r.name} ${ROMAN[i % 3]}`, name_nl: `${r.name_nl} ${ROMAN[i % 3]}`, emoji: r.emoji, rank: Math.floor(i / 3), tier: i % 3 };
});

export const DEFAULT_XP = {
  cooked: 10, // any meal cooked at home
  newRecipe: 20, // first time cooking a recipe
  favourite: 5, // cooking something you love (4★+ or favourite)
  planned: 5, // cooking the meal you planned
  balanced: 20, // up to this for the meal's balance; full at 70/100
  rescued: 5, // per food used just before it expires (max 3)
  newCuisine: 15, // first time cooking a cuisine
  streak: 10, // up to this for an ongoing cooking streak
  planWeek: 30, // a week where you cooked ≥ 5 planned dinners
  zeroWasteWeek: 40, // a week with ≥ 3 cooking days and nothing thrown away
  badge: 50,
  challenge: 100,
  journeyTask: 15, // a task on the journey path
  journeyMilestone: 25, // the reward chest halfway a chapter
  journeyBoss: 60, // a chapter's final challenge
  journeyBonus: 20, // an optional bonus task
  trackLevel: 15, // a level on a skill track (plus 5 per level)
};
export type XpRules = typeof DEFAULT_XP;

export const ACCENTS: Record<string, { herb: string; soft: string }> = {
  herb: { herb: '#3E7C59', soft: '#E3EFE7' }, saffron: { herb: '#C98A12', soft: '#FBEFD4' }, ocean: { herb: '#2D7DA8', soft: '#DDEEF7' }, berry: { herb: '#B23A62', soft: '#F6DEE7' },
  plum: { herb: '#6E4FA3', soft: '#ECE5F6' }, copper: { herb: '#B5602E', soft: '#F6E4D8' }, gold: { herb: '#9C7A16', soft: '#F4EBCB' },
};

export interface XpPart { key: string; label: string; label_nl: string; xp: number }
export interface CookEntry { id: string; batchId: string; date: string; at: string; recipeId: string; title: string; emoji: string | null; score: number; xp: number; parts: XpPart[] }

const BALANCED = 70;
const day = (iso: string) => iso.slice(0, 10);
/** Monday of the week a date falls in. */
export const weekOf = (date: string) => addDays(date, -((new Date(date + 'T12:00:00Z').getUTCDay() + 6) % 7));

const pref = <T>(db: Db, h: string, key: string, d: T): T => parseJson(db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = '' AND key = ?", h, key)?.value, d);
export const xpRules = (db: Db, h: string): XpRules => ({ ...DEFAULT_XP, ...pref(db, h, 'xpRules', {}) });

/**
 * Consecutive cooking days up to today (today stays open until it ends). Two kinds of forgiveness:
 * a rest day (one missed day per 7, like a streak freeze) and a repair (a gap of up to 2 days is
 * bridged when you cook the 2 days after it), so one off weekend doesn't wipe out weeks of habit.
 */
export function streakOf(days: Set<string>, today: string) {
  let d = days.has(today) ? today : addDays(today, -1);
  let count = 0;
  let restDaysUsed = 0;
  let repaired = false;
  let sinceRest = 99;
  let run = 0; // cooking days in a row just after the current position (towards today)
  for (let guard = 0; guard < 4000; guard++) {
    if (days.has(d)) {
      count++;
      sinceRest++;
      run++;
      d = addDays(d, -1);
      continue;
    }
    if (count > 0 && sinceRest >= 7 && days.has(addDays(d, -1))) {
      restDaysUsed++;
      sinceRest = 0;
      run = 0;
      d = addDays(d, -1);
      continue;
    }
    if (count > 0 && !repaired && run >= 2 && (days.has(addDays(d, -2)) || days.has(addDays(d, -1)))) {
      repaired = true;
      run = 0;
      d = days.has(addDays(d, -1)) ? addDays(d, -1) : addDays(d, -2);
      continue;
    }
    break;
  }
  return { count, restDaysUsed, repaired };
}

function bestRun(days: string[]): number {
  const sorted = [...new Set(days)].sort();
  let best = 0;
  let run = 0;
  let prev: string | null = null;
  for (const d of sorted) {
    run = prev && addDays(prev, 1) === d ? run + 1 : 1;
    best = Math.max(best, run);
    prev = d;
  }
  return best;
}

/** Consecutive weeks meeting a goal, counting back from last week (this week counts once it's met). */
function weeklyStreak(met: (week: string) => boolean, today: string): number {
  let w = weekOf(today);
  let n = met(w) ? 1 : 0;
  w = addDays(w, -7);
  for (let i = 0; i < 520 && met(w); i++) {
    n++;
    w = addDays(w, -7);
  }
  return n;
}

export function levelFor(xp: number) {
  let i = 0;
  while (i + 1 < LEVELS.length && xp >= LEVELS[i + 1].xp) i++;
  const cur = LEVELS[i];
  const next = LEVELS[i + 1] ?? null;
  return { n: i + 1, ...cur, rankName: RANKS[cur.rank].name, rankName_nl: RANKS[cur.rank].name_nl, from: cur.xp, to: next?.xp ?? null, progress: next ? (xp - cur.xp) / (next.xp - cur.xp) : 1 };
}

export const CHALLENGES = [
  { id: 'protein', emoji: '💪', title: 'Protein Week', title_nl: 'Eiwitweek', desc: '5 dinners with 30 g+ protein', desc_nl: '5 avondmaaltijden met 30 g+ eiwit', goal: 5 },
  { id: 'zerowaste', emoji: '♻️', title: 'Zero Waste Challenge', title_nl: 'Niets-weggooien-uitdaging', desc: 'A week without throwing food away (and 3+ cooking days)', desc_nl: 'Een week niets weggooien (en 3+ kookdagen)', goal: 7 },
  { id: 'explorer', emoji: '🧭', title: 'Explorer Challenge', title_nl: 'Ontdekkersuitdaging', desc: 'Cook 3 recipes you’ve never made', desc_nl: 'Kook 3 recepten die je nog nooit maakte', goal: 3 },
  { id: 'homechef', emoji: '👨‍🍳', title: 'Home Chef', title_nl: 'Thuischef', desc: 'Cook dinner 6 days this week', desc_nl: 'Kook 6 dagen deze week', goal: 6 },
  { id: 'balanced', emoji: '⚖️', title: 'Balanced Week', title_nl: 'Gebalanceerde week', desc: '5 meals scoring 70+', desc_nl: '5 maaltijden met 70+', goal: 5 },
  { id: 'cuisines', emoji: '🌍', title: 'Cuisine Explorer', title_nl: 'Wereldkeuken', desc: 'Cook 3 different cuisines', desc_nl: 'Kook 3 verschillende keukens', goal: 3 },
  { id: 'budget', emoji: '💶', title: 'Budget Chef', title_nl: 'Budgetchef', desc: '5 dinners under €2.50 per serving', desc_nl: '5 avondmaaltijden onder € 2,50 per portie', goal: 5 },
] as const;

/** Every meal cooked, in order, with the XP it earned and its balance score (shared with the journey). */
/** When progress last started over ('' = never). */
export const progressSince = (db: Db, h: string): string => pref(db, h, 'progressSince', '');

export function cookHistory(db: Db, householdId: string) {
  const rules = xpRules(db, householdId);
  const targets = targetsFor(db, householdId);
  const recipes = new Map<string, Recipe>(listRecipes(db, householdId).map((r) => [r.id, r]));
  // After "reset all progress", only what's cooked from then on counts (the history itself is kept).
  const since = progressSince(db, householdId);
  const cooks = db.all<{ id: string; recipe_id: string; servings: number; batch_id: string; created_at: string }>('SELECT * FROM cook_log WHERE household_id = ? AND created_at >= ? ORDER BY created_at', householdId, since);
  const inter = new Map(db.all<any>('SELECT recipe_id, rating, priority FROM recipe_interactions WHERE household_id = ?', householdId).map((r) => [r.recipe_id, r]));

  // Food rescued: ingredients taken from a lot that would have expired within 2 days.
  const rescuedByBatch = new Map<string, Set<string>>();
  for (const r of db.all<{ batch_id: string; product_id: string }>(
    `SELECT e.batch_id, e.product_id FROM inventory_events e JOIN inventory_lots l ON l.id = e.lot_id
     WHERE e.household_id = ? AND e.type = 'cook' AND l.expires_on IS NOT NULL AND julianday(l.expires_on) - julianday(substr(e.created_at, 1, 10)) <= 2
       AND NOT EXISTS (SELECT 1 FROM inventory_events u WHERE u.reverses_event_id = e.id)`,
    householdId,
  )) {
    const s = rescuedByBatch.get(r.batch_id) ?? new Set();
    s.add(r.product_id);
    rescuedByBatch.set(r.batch_id, s);
  }
  const plannedBatches = new Set(db.all<{ b: string }>("SELECT cook_batch_id b FROM meal_slots WHERE household_id = ? AND status = 'cooked' AND cook_batch_id IS NOT NULL", householdId).map((r) => r.b));

  const seen = new Set<string>();
  const seenCuisines = new Set<string>();
  const cookDays = new Set<string>();
  const entries: CookEntry[] = [];
  for (const c of cooks) {
    const r = recipes.get(c.recipe_id);
    const date = day(c.created_at);
    const it = inter.get(c.recipe_id);
    const parts: XpPart[] = [{ key: 'cooked', label: 'Cooked a meal', label_nl: 'Gekookt', xp: rules.cooked }];
    if (!seen.has(c.recipe_id)) parts.push({ key: 'new', label: 'New recipe', label_nl: 'Nieuw recept', xp: rules.newRecipe });
    else if ((it?.rating ?? 0) >= 4 || (it?.priority ?? 0) >= 2) parts.push({ key: 'favourite', label: 'A favourite', label_nl: 'Een favoriet', xp: rules.favourite });
    if (r?.cuisine && !seenCuisines.has(r.cuisine)) {
      if (seenCuisines.size > 0) parts.push({ key: 'cuisine', label: `New cuisine: ${r.cuisine}`, label_nl: `Nieuwe keuken: ${r.cuisine}`, xp: rules.newCuisine });
      seenCuisines.add(r.cuisine);
    }
    const score = r ? mealScore(r.nutritionPerServing, r.health.vegGrams, r.health.vegKinds, targets).score : 0;
    // Full reward from 70: chasing 100 earns nothing extra.
    if (score) parts.push({ key: 'health', label: `Balance ${score}/100`, label_nl: `Balans ${score}/100`, xp: Math.round((rules.balanced * Math.min(score, BALANCED)) / BALANCED) });
    const rescued = rescuedByBatch.get(c.batch_id)?.size ?? 0;
    if (rescued) parts.push({ key: 'rescued', label: `Rescued ${rescued} expiring`, label_nl: `${rescued} bijna-over-datum gered`, xp: Math.min(3, rescued) * rules.rescued });
    if (plannedBatches.has(c.batch_id)) parts.push({ key: 'planned', label: 'Cooked as planned', label_nl: 'Volgens plan', xp: rules.planned });
    if (!cookDays.has(date)) {
      const s = streakOf(new Set([...cookDays, date]), date).count;
      if (s >= 2) parts.push({ key: 'streak', label: `${s}-day streak`, label_nl: `${s} dagen op rij`, xp: Math.min(rules.streak, s * 2) });
    }
    seen.add(c.recipe_id);
    cookDays.add(date);
    entries.push({ id: c.id, batchId: c.batch_id, date, at: c.created_at, recipeId: c.recipe_id, title: r?.title ?? 'Meal', emoji: r?.emoji ?? '🍽️', score, xp: parts.reduce((s, p) => s + p.xp, 0), parts });
  }
  return { rules, targets, recipes, inter, entries, rescuedByBatch, seenCuisines, cookDays };
}

/** XP from journey tasks, milestones and track levels (stored once each, see journey.ts). */
export const journeyXp = (db: Db, householdId: string) => db.get<{ xp: number }>('SELECT COALESCE(SUM(xp), 0) xp FROM journey_nodes WHERE household_id = ?', householdId)!.xp;

export function game(db: Db, householdId: string) {
  const today = clock.today();
  const { rules, targets, recipes, entries, rescuedByBatch, seenCuisines, cookDays } = cookHistory(db, householdId);

  // Daily nutrition score: the average balance of what was cooked that day.
  const dayScores = new Map<string, number>();
  for (const d of cookDays) {
    const es = entries.filter((e) => e.date === d && e.score > 0);
    if (es.length) dayScores.set(d, Math.round(es.reduce((s, e) => s + e.score, 0) / es.length));
  }

  const discardsByWeek = new Map<string, number>();
  for (const r of db.all<{ d: string; n: number }>("SELECT substr(created_at, 1, 10) d, COUNT(*) n FROM inventory_events e WHERE household_id = ? AND type = 'discard' AND created_at >= ? AND NOT EXISTS (SELECT 1 FROM inventory_events u WHERE u.reverses_event_id = e.id) GROUP BY d", householdId, progressSince(db, householdId))) {
    const w = weekOf(r.d);
    discardsByWeek.set(w, (discardsByWeek.get(w) ?? 0) + r.n);
  }
  const plannedByWeek = new Map<string, number>();
  for (const r of db.all<{ date: string }>("SELECT date FROM meal_slots WHERE household_id = ? AND meal = 'dinner' AND status != 'skipped' AND recipe_id IS NOT NULL AND date >= ?", householdId, progressSince(db, householdId).slice(0, 10))) {
    const w = weekOf(r.date);
    plannedByWeek.set(w, (plannedByWeek.get(w) ?? 0) + 1);
  }
  const weekEntries = (w: string) => entries.filter((e) => weekOf(e.date) === w);
  const cookDaysIn = (w: string) => new Set(weekEntries(w).map((e) => e.date)).size;

  // Weekly bonuses: a plan you followed, a week without waste.
  const weeks = [...new Set(entries.map((e) => weekOf(e.date)))];
  const weekBonuses: { week: string; key: string; xp: number }[] = [];
  for (const w of weeks) {
    if (weekEntries(w).filter((e) => e.parts.some((p) => p.key === 'planned')).length >= 5) weekBonuses.push({ week: w, key: 'planWeek', xp: rules.planWeek });
    if (w < weekOf(today) && !discardsByWeek.get(w) && cookDaysIn(w) >= 3) weekBonuses.push({ week: w, key: 'zeroWasteWeek', xp: rules.zeroWasteWeek });
  }

  // Weekly quests (bonus XP every week they're completed).
  const quests = (week: string) => {
    const es = weekEntries(week);
    const firstTimes = es.filter((e) => e.parts.some((p) => p.key === 'new')).length;
    const balanced = es.filter((e) => e.score >= BALANCED).length;
    const rescued = es.reduce((s, e) => s + (rescuedByBatch.get(e.batchId)?.size ?? 0), 0);
    return [
      { id: 'cook4', title: 'Cook 4 dinners', title_nl: 'Kook 4 avondmaaltijden', progress: cookDaysIn(week), goal: 4, xp: 40, emoji: '🍳' },
      { id: 'new1', title: 'Try a new recipe', title_nl: 'Probeer een nieuw recept', progress: firstTimes, goal: 1, xp: 30, emoji: '✨' },
      { id: 'balanced3', title: `3 balanced meals (${BALANCED}+)`, title_nl: `3 gebalanceerde maaltijden (${BALANCED}+)`, progress: balanced, goal: 3, xp: 30, emoji: '🥗' },
      { id: 'rescue2', title: 'Rescue 2 expiring foods', title_nl: 'Red 2 producten die bijna over de datum zijn', progress: rescued, goal: 2, xp: 20, emoji: '🛟' },
    ].map((q) => ({ ...q, progress: Math.min(q.progress, q.goal), done: q.progress >= q.goal }));
  };
  const questXp = weeks.reduce((s, w) => s + quests(w).filter((q) => q.done).reduce((a, q) => a + q.xp, 0), 0);

  // Challenges: optional, one at a time, suggested from behaviour.
  const challenge = challengeState(db, householdId, entries, recipes, discardsByWeek, today);
  const challengeXp = challenge.completed.length * rules.challenge;

  // Badges.
  const distinct = new Set(entries.map((e) => e.recipeId)).size;
  const best = bestRun([...cookDays]);
  const balancedCount = entries.filter((e) => e.score >= BALANCED).length;
  const proteinMeals = entries.filter((e) => (recipes.get(e.recipeId)?.nutritionPerServing?.protein ?? 0) >= 30).length;
  const plantMeals = entries.filter((e) => recipes.get(e.recipeId)?.diet.includes('vegetarian')).length;
  const cuisines = seenCuisines.size;
  const rescuedTotal = entries.reduce((s, e) => s + (rescuedByBatch.get(e.batchId)?.size ?? 0), 0);
  const zeroWasteWeeks = weekBonuses.filter((b) => b.key === 'zeroWasteWeek').length;
  const plannedWeeks = weekBonuses.filter((b) => b.key === 'planWeek').length;
  const badge = (id: string, emoji: string, title: string, title_nl: string, desc: string, desc_nl: string, progress: number, goal: number) => ({ id, emoji, title, title_nl, desc, desc_nl, progress: Math.min(progress, goal), goal, done: progress >= goal, xp: rules.badge });
  const achievements = [
    badge('first', '🍽️', 'First dish', 'Eerste gerecht', 'Cook your first meal', 'Kook je eerste maaltijd', entries.length, 1),
    badge('explorer5', '🧭', 'Explorer', 'Ontdekker', 'Cook 5 different recipes', 'Kook 5 verschillende recepten', distinct, 5),
    badge('explorer15', '🗺️', 'Adventurer', 'Avonturier', 'Cook 15 different recipes', 'Kook 15 verschillende recepten', distinct, 15),
    badge('explorer30', '🌍', 'Globetrotter', 'Wereldreiziger', 'Cook 30 different recipes', 'Kook 30 verschillende recepten', distinct, 30),
    badge('streak3', '🔥', 'Warming up', 'Opwarmen', 'Cook 3 days in a row', 'Kook 3 dagen op rij', best, 3),
    badge('streak7', '🔥', 'On fire', 'In vuur en vlam', 'Cook 7 days in a row', 'Kook 7 dagen op rij', best, 7),
    badge('streak30', '☄️', 'Unstoppable', 'Niet te stoppen', 'Cook 30 days in a row', 'Kook 30 dagen op rij', best, 30),
    badge('balanced10', '⚖️', 'Balanced 10', 'Balans 10', `10 meals scoring ${BALANCED}+`, `10 maaltijden met ${BALANCED}+`, balancedCount, 10),
    badge('protein10', '💪', 'Protein pro', 'Eiwitprof', '10 meals with 30 g+ protein', '10 maaltijden met 30 g+ eiwit', proteinMeals, 10),
    badge('plants10', '🌱', 'Plant power', 'Plantenkracht', 'Cook 10 vegetarian meals', 'Kook 10 vegetarische maaltijden', plantMeals, 10),
    badge('world5', '🧳', 'World tour', 'Wereldreis', 'Cook 5 different cuisines', 'Kook 5 verschillende keukens', cuisines, 5),
    badge('rescue10', '🛟', 'Food rescuer', 'Voedselredder', 'Use 10 foods before they expire', 'Gebruik 10 producten voor de datum', rescuedTotal, 10),
    badge('zerowaste', '♻️', 'Zero-waste week', 'Week zonder verspilling', 'A week with 3+ cooking days and nothing thrown away', 'Een week met 3+ kookdagen en niets weggegooid', zeroWasteWeeks, 1),
    badge('planner', '🗓️', 'Planner', 'Planner', 'Cook 5 planned dinners in one week', 'Kook 5 geplande avondmaaltijden in één week', plannedWeeks, 1),
    badge('challenger', '🎯', 'Challenger', 'Uitdager', 'Complete a challenge', 'Voltooi een uitdaging', challenge.completed.length, 1),
  ];
  const badgeXp = achievements.filter((a) => a.done).length * rules.badge;

  const fromJourney = journeyXp(db, householdId);
  // Rewards from friends: duels won, team goals, passed recipes, invites (see social.ts).
  const social = db.all<{ xp: number; at: string }>('SELECT xp, at FROM social_rewards WHERE household_id = ?', householdId);
  const fromSocial = social.reduce((s, r) => s + r.xp, 0);
  const xp = entries.reduce((s, e) => s + e.xp, 0) + questXp + badgeXp + challengeXp + weekBonuses.reduce((s, b) => s + b.xp, 0) + fromJourney + fromSocial;
  const level = levelFor(xp);
  // XP earned per week (for the weekly leaderboard, duels and leagues). Badges carry no date, so they count all-time only.
  const nodes = db.all<{ xp: number; at: string }>('SELECT xp, completed_at at FROM journey_nodes WHERE household_id = ?', householdId);
  const xpIn = (w: string) => {
    const end = addDays(w, 7);
    const inWeek = (at: string) => at >= w && at < end;
    return weekEntries(w).reduce((s, e) => s + e.xp, 0)
      + quests(w).filter((q) => q.done).reduce((s, q) => s + q.xp, 0)
      + weekBonuses.filter((b) => b.week === w).reduce((s, b) => s + b.xp, 0)
      + challenge.completed.filter((c) => inWeek(c.at)).length * rules.challenge
      + nodes.filter((n) => inWeek(n.at)).reduce((s, n) => s + n.xp, 0)
      + social.filter((r) => inWeek(r.at)).reduce((s, r) => s + r.xp, 0);
  };
  const thisWeek = weekOf(today);
  const weekXp = xpIn(thisWeek);
  const weeklyXp: Record<string, number> = Object.fromEntries(Array.from({ length: 12 }, (_, i) => addDays(thisWeek, -7 * i)).map((w) => [w, xpIn(w)]));
  const cooking = streakOf(cookDays, today);
  // Nutrition streak: cooking days in a row scoring 70+ (days you didn't cook don't break it).
  let nutrition = 0;
  for (const d of [...dayScores.keys()].sort().reverse()) {
    if ((dayScores.get(d) ?? 0) >= BALANCED) nutrition++;
    else break;
  }
  const streaks = {
    cooking: { current: cooking.count, best: Math.max(best, cooking.count), unit: 'days', restDaysUsed: cooking.restDaysUsed, repaired: cooking.repaired, cookedToday: cookDays.has(today), atRisk: !cookDays.has(today) && cooking.count > 0 },
    nutrition: { current: nutrition, unit: 'days' },
    exploration: { current: weeklyStreak((w) => weekEntries(w).some((e) => e.parts.some((p) => p.key === 'new')), today), unit: 'weeks' },
    lowWaste: { current: weeklyStreak((w) => (discardsByWeek.get(w) ?? 0) <= 1 && cookDaysIn(w) > 0, today), unit: 'weeks' },
    planning: { current: weeklyStreak((w) => (plannedByWeek.get(w) ?? 0) >= 4, today), unit: 'weeks' },
  };
  const todays = entries.filter((e) => e.date === today);
  const last7 = Array.from({ length: 7 }, (_, i) => {
    const d = addDays(today, i - 6);
    const es = entries.filter((e) => e.date === d);
    return { date: d, cooked: es.length > 0, best: es.reduce((m, e) => Math.max(m, e.score), 0), score: dayScores.get(d) ?? null };
  });
  const scored = last7.filter((d) => d.score != null);

  return {
    xp,
    weekXp,
    weeklyXp,
    socialXp: fromSocial,
    journeyXp: fromJourney,
    level,
    ranks: RANKS.map((r, i) => ({ ...r, unlocked: i <= level.rank, from: TIER_XP[i * 3] })),
    path: LEVELS.map((l, i) => ({ n: i + 1, ...l, state: i + 1 < level.n ? 'done' : i + 1 === level.n ? 'current' : 'locked' })),
    streak: streaks.cooking,
    streaks,
    balancedStreak: nutrition,
    week: last7,
    nutrition: { today: dayScores.get(today) ?? null, weekAverage: scored.length ? Math.round(scored.reduce((s, d) => s + (d.score ?? 0), 0) / scored.length) : null, daysScored: scored.length },
    today: { xp: todays.reduce((s, e) => s + e.xp, 0), meals: todays.length },
    quests: quests(weekOf(today)),
    challenge,
    achievements,
    recent: entries.slice(-8).reverse(),
    rules,
    accent: pref(db, householdId, 'accent', 'herb') as string,
    dinnerTarget: Math.round(targets.kcal * DINNER_SHARE),
    targets,
    daysSinceStart: entries.length ? Math.floor(daysBetween(entries[0].date, today)) : 0,
  };
}

function challengeState(db: Db, h: string, entries: CookEntry[], recipes: Map<string, Recipe>, discardsByWeek: Map<string, number>, today: string) {
  const active = pref<{ id: string; start: string } | null>(db, h, 'challenge', null);
  const completed = pref<{ id: string; at: string }[]>(db, h, 'challengesDone', []);
  const progressOf = (id: string, start: string) => {
    const end = addDays(start, 6);
    const es = entries.filter((e) => e.date >= start && e.date <= end);
    const before = new Set(entries.filter((e) => e.date < start).map((e) => e.recipeId));
    switch (id) {
      case 'protein': return es.filter((e) => (recipes.get(e.recipeId)?.nutritionPerServing?.protein ?? 0) >= 30).length;
      case 'zerowaste': {
        const wasted = db.get<{ n: number }>("SELECT COUNT(*) n FROM inventory_events e WHERE household_id = ? AND type = 'discard' AND substr(created_at, 1, 10) BETWEEN ? AND ? AND NOT EXISTS (SELECT 1 FROM inventory_events u WHERE u.reverses_event_id = e.id)", h, start, end)!.n;
        const daysIn = Math.min(7, Math.floor(daysBetween(start, today)) + 1);
        return wasted ? 0 : new Set(es.map((e) => e.date)).size >= 3 ? daysIn : Math.min(daysIn, 6);
      }
      case 'explorer': return new Set(es.filter((e) => !before.has(e.recipeId)).map((e) => e.recipeId)).size;
      case 'homechef': return new Set(es.map((e) => e.date)).size;
      case 'balanced': return es.filter((e) => e.score >= BALANCED).length;
      case 'cuisines': return new Set(es.map((e) => recipes.get(e.recipeId)?.cuisine).filter(Boolean)).size;
      case 'budget': return es.filter((e) => (recipes.get(e.recipeId)?.costPerServing ?? 99) <= 2.5).length;
      default: return 0;
    }
  };
  let current = null as null | { id: string; start: string; end: string; progress: number; goal: number; done: boolean; expired: boolean };
  if (active) {
    const def = CHALLENGES.find((c) => c.id === active.id);
    if (def) {
      const progress = progressOf(def.id, active.start);
      const end = addDays(active.start, 6);
      current = { id: def.id, start: active.start, end, progress: Math.min(progress, def.goal), goal: def.goal, done: progress >= def.goal, expired: today > end };
      // Record a completion once; it stays even if the challenge is left afterwards.
      if (current.done && !completed.some((c) => c.id === def.id && c.at >= active.start)) {
        completed.push({ id: def.id, at: today });
        db.run("INSERT INTO preferences (household_id, user_id, key, value) VALUES (?, '', 'challengesDone', ?) ON CONFLICT(household_id, user_id, key) DO UPDATE SET value = excluded.value", h, JSON.stringify(completed));
      }
    }
  }
  // Suggestions from behaviour (last 30 days), at most two, never the active one.
  const recent = entries.filter((e) => e.date >= addDays(today, -30));
  const wasted30 = [...discardsByWeek].filter(([w]) => w >= addDays(today, -30)).reduce((s, [, n]) => s + n, 0);
  const why: [string, boolean, string, string][] = [
    ['zerowaste', wasted30 >= 3, `You threw food away ${wasted30}× this month`, `Je gooide deze maand ${wasted30}× eten weg`],
    ['explorer', recent.length >= 6 && new Set(recent.map((e) => e.recipeId)).size <= recent.length / 2, 'You’ve been cooking the same few recipes', 'Je kookt steeds dezelfde paar recepten'],
    ['protein', recent.length >= 4 && recent.reduce((s, e) => s + (recipes.get(e.recipeId)?.nutritionPerServing?.protein ?? 0), 0) / recent.length < 22, 'Your dinners are on the low side for protein', 'Je avondeten bevat vrij weinig eiwit'],
    ['balanced', recent.length >= 4 && recent.reduce((s, e) => s + e.score, 0) / recent.length < 65, 'Room to balance your meals a bit more', 'Je maaltijden kunnen iets gebalanceerder'],
    ['homechef', recent.length < 8, 'Cooking more often at home saves money', 'Vaker zelf koken scheelt geld'],
    ['cuisines', recent.length >= 4 && new Set(recent.map((e) => recipes.get(e.recipeId)?.cuisine)).size < 3, 'Try a few new cuisines', 'Probeer eens andere keukens'],
    ['budget', true, 'A fun way to save on groceries', 'Leuke manier om op boodschappen te besparen'],
  ];
  const suggestions = why.filter(([id, yes]) => yes && id !== current?.id).slice(0, 2).map(([id, , reason, reason_nl]) => ({ ...CHALLENGES.find((c) => c.id === id)!, reason, reason_nl }));
  return { current: current && !current.expired ? current : null, lastExpired: current?.expired ? current : null, suggestions, completed, all: CHALLENGES };
}

/** XP for one cook (for the "you earned" moment right after cooking), and whether it levelled you up. */
export function rewardFor(db: Db, householdId: string, batchId: string, journey: { id: string; xp: number; title: string; title_nl: string; kind: string }[] = []) {
  const g = game(db, householdId);
  const e = g.recent.find((x) => x.batchId === batchId);
  if (!e) return null;
  const extra = journey.reduce((s, n) => s + n.xp, 0);
  const before = levelFor(g.xp - e.xp - extra);
  return { xp: e.xp + extra, parts: [...e.parts, ...journey.map((n) => ({ key: `journey:${n.id}`, label: n.title, label_nl: n.title_nl, xp: n.xp }))], score: e.score, streak: g.streak.current, level: g.level, levelUp: before.n < g.level.n, rankUp: before.rank < g.level.rank, totalXp: g.xp, nutritionToday: g.nutrition.today, journey };
}
