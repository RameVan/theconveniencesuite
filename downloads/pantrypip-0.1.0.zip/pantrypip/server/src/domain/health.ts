// Nutrition: full nutrient sums and a friendly 0–100 balance score. Targets follow WHO/EFSA reference
// intakes (fat 20–35 % energy, saturated fat < 10 %, sugars capped, salt ≤ 6 g/day, fibre ≥ 30 g/day),
// scaled to the share of the day a meal represents. Energy is scored both ways: eating less than the
// target loses points just like eating more, so the score never rewards restriction. Not medical advice.
import type { Product } from './products.ts';

export interface Nutrition { kcal: number; protein: number; carbs: number; fat: number; sugars?: number; satFat?: number; fibre?: number; salt?: number }
export const NUTRIENTS = ['kcal', 'protein', 'carbs', 'sugars', 'fat', 'satFat', 'fibre', 'salt'] as const;
export type NutrientKey = (typeof NUTRIENTS)[number];
export type FullNutrition = Record<NutrientKey, number>;
export const zero = (): FullNutrition => ({ kcal: 0, protein: 0, carbs: 0, sugars: 0, fat: 0, satFat: 0, fibre: 0, salt: 0 });

export interface DailyTargets { kcal: number; protein: number; fibre: number; saltMax: number; satFatPct: number; sugarPct: number; fatMinPct: number; fatMaxPct: number; carbMinPct: number; carbMaxPct: number; /** How quickly points fall off outside the targets: 1.5 gentle, 1 standard, 0.7 strict. */ sensitivity?: number }
export const DEFAULT_TARGETS: DailyTargets = { kcal: 2000, protein: 70, fibre: 30, saltMax: 6, satFatPct: 10, sugarPct: 12.5, fatMinPct: 20, fatMaxPct: 35, carbMinPct: 40, carbMaxPct: 60 };
/** Share of the day's intake a dinner usually is. */
export const DINNER_SHARE = 0.35;
export const DEFAULT_DAILY_KCAL = DEFAULT_TARGETS.kcal;

export interface MealScore {
  score: number;
  grade: 'excellent' | 'balanced' | 'ok' | 'light' | 'treat';
  vegGrams: number;
  vegKinds: number;
  parts: { key: 'energy' | 'protein' | 'fibre' | 'veg' | 'carbs' | 'fat' | 'satFat' | 'sugar' | 'salt'; points: number; max: number; value: number; target: string }[];
}

// Potatoes are a starch in dietary guidance, not a vegetable; legumes count.
const NOT_VEG = new Set(['p_potatoes']);
const VEG_EXTRA = new Set(['p_chickpeas', 'p_lentils', 'p_kidney_beans', 'p_frozen_peas', 'p_frozen_spinach', 'p_canned_tomatoes', 'p_tomato_paste']);

export function isVeg(p: Pick<Product, 'id' | 'category'>): boolean {
  if (NOT_VEG.has(p.id)) return false;
  return p.category === 'produce' || VEG_EXTRA.has(p.id);
}

/** Grams of a product quantity (pieces through their typical weight, ml through density). */
export function gramsOf(p: Pick<Product, 'unit' | 'piece_size'> & { density?: number | null }, qty: number): number {
  if (p.unit === 'pcs') return qty * (p.piece_size ?? 100);
  if (p.unit === 'ml') return qty * (p.density ?? 1);
  return qty;
}

const lin = (x: number, zeroAt: number, fullAt: number) => Math.max(0, Math.min(1, (x - zeroAt) / (fullAt - zeroAt)));
/** 1 inside [lo, hi], falling to 0 at lo - slackLo and hi + slackHi. */
const band = (x: number, lo: number, hi: number, slackLo: number, slackHi: number) => (x < lo ? lin(x, lo - slackLo, lo) : x > hi ? lin(-x, -(hi + slackHi), -hi) : 1);

/** Targets for one meal that is `share` of the day. */
export function mealTargets(daily: DailyTargets, share = DINNER_SHARE) {
  return { kcal: daily.kcal * share, protein: daily.protein * share, fibre: daily.fibre * share, salt: daily.saltMax * share, veg: 200 * (share / DINNER_SHARE) };
}

export function mealScore(n: Nutrition | null, vegGrams: number, vegKinds: number, daily: DailyTargets = DEFAULT_TARGETS, share = DINNER_SHARE): MealScore {
  if (!n || !n.kcal) return { score: 0, grade: 'treat', vegGrams: Math.round(vegGrams), vegKinds, parts: [] };
  const t = mealTargets(daily, share);
  const k = daily.sensitivity ?? 1;
  const pct = (g: number, kcalPerG: number) => ((g * kcalPerG) / n.kcal) * 100;
  const fatPct = pct(n.fat, 9);
  const carbPct = pct(n.carbs, 4);
  const satPct = pct(n.satFat ?? 0, 9);
  const sugarPct = pct(n.sugars ?? 0, 4);
  const salt = n.salt ?? 0;
  const parts: MealScore['parts'] = [
    // Symmetric: within 15 % either side is perfect, 60 % off is zero.
    { key: 'energy' as const, max: 20, points: 20 * band(n.kcal, t.kcal * 0.85, t.kcal * 1.15, t.kcal * 0.45 * k, t.kcal * 0.45 * k), value: Math.round(n.kcal), target: `≈${Math.round(t.kcal)} kcal` },
    { key: 'protein' as const, max: 15, points: 15 * lin(n.protein, t.protein * 0.3, t.protein), value: Math.round(n.protein), target: `≥${Math.round(t.protein)} g` },
    { key: 'fibre' as const, max: 15, points: 15 * lin(n.fibre ?? 0, 0, t.fibre), value: Math.round((n.fibre ?? 0) * 10) / 10, target: `≥${Math.round(t.fibre)} g` },
    { key: 'veg' as const, max: 10, points: 10 * lin(vegGrams, 0, t.veg) * (vegKinds >= 2 || vegGrams >= t.veg ? 1 : 0.8), value: Math.round(vegGrams), target: `≥${Math.round(t.veg)} g` },
    // EFSA: 45–60 % of daily energy from carbohydrate; one meal gets a little more room. Low-carb households get ≤ 26 %.
    { key: 'carbs' as const, max: 10, points: 10 * band(carbPct, daily.carbMinPct, daily.carbMaxPct, 15 * k, 15 * k), value: Math.round(carbPct), target: `${daily.carbMinPct}–${daily.carbMaxPct} %` },
    { key: 'fat' as const, max: 10, points: 10 * band(fatPct, daily.fatMinPct, daily.fatMaxPct, 10 * k, 15 * k), value: Math.round(fatPct), target: `${daily.fatMinPct}–${daily.fatMaxPct} %` },
    { key: 'satFat' as const, max: 10, points: 10 * (satPct <= daily.satFatPct ? 1 : lin(-satPct, -daily.satFatPct * (1 + k), -daily.satFatPct)), value: Math.round(satPct), target: `≤${daily.satFatPct} %` },
    { key: 'sugar' as const, max: 5, points: 5 * (sugarPct <= daily.sugarPct ? 1 : lin(-sugarPct, -daily.sugarPct * (1 + k), -daily.sugarPct)), value: Math.round(sugarPct), target: `≤${daily.sugarPct} %` },
    { key: 'salt' as const, max: 5, points: 5 * (salt <= t.salt ? 1 : lin(-salt, -t.salt * (1 + k), -t.salt)), value: Math.round(salt * 10) / 10, target: `≤${Math.round(t.salt * 10) / 10} g` },
  ].map((p) => ({ ...p, points: Math.round(p.points) }));
  const score = Math.min(100, parts.reduce((s, p) => s + p.points, 0));
  // Low scores from a small meal (a light soup) read differently from a heavy one.
  const grade = score >= 85 ? 'excellent' : score >= 70 ? 'balanced' : score >= 50 ? 'ok' : n.kcal < t.kcal * 0.6 ? 'light' : 'treat';
  return { score, grade, vegGrams: Math.round(vegGrams), vegKinds, parts };
}

/** Household daily targets: the average of everyone's set targets, defaults elsewhere, plus household overrides. */
export function householdTargets(people: { kcal?: number | null; protein?: number | null }[], overrides: Partial<DailyTargets> = {}): DailyTargets {
  const avg = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null);
  const kcal = avg(people.map((p) => p.kcal).filter((k): k is number => !!k && k > 0)) ?? DEFAULT_TARGETS.kcal;
  const protein = avg(people.map((p) => p.protein).filter((k): k is number => !!k && k > 0)) ?? Math.max(50, Math.round((kcal * 0.15) / 4));
  return { ...DEFAULT_TARGETS, kcal, protein, ...overrides };
}

/** Dinner energy target from everyone's daily targets (default 2000 kcal/day). */
export function dinnerTarget(people: { kcal?: number | null }[]): number {
  return Math.round(householdTargets(people).kcal * DINNER_SHARE);
}

// Frying, roasting and stir-frying use fat even when a recipe doesn't list it.
const FRYING = /\b(fry|fried|frying|sauté|saute|sauteed|roast|roasted|stir-fry|stir fry|brown|sear|seared|bak|bakken|braad|braden|roerbak|roerbakken|aanbraden|fruit|fruiten|wok)\b/i;
const FAT_IDS = new Set(['p_olive_oil', 'p_sunflower_oil', 'p_butter']);
const FAT_WORDS = /\b(oil|olie|butter|boter|ghee|lard|reuzel|margarine|bakvet)\b/i;
/** Oil assumed per serving when a recipe fries without listing fat: about 1 tsp. */
export const ASSUMED_OIL_PER_SERVING = 5;
export const OIL_NUTRITION: FullNutrition = { kcal: 824, protein: 0, carbs: 0, sugars: 0, fat: 91.6, satFat: 13, fibre: 0, salt: 0 }; // per 100 ml olive oil

export function needsAssumedFat(ingredients: { product_id: string | null; name: string }[], steps: { text: string }[]): boolean {
  if (ingredients.some((i) => (i.product_id && FAT_IDS.has(i.product_id)) || FAT_WORDS.test(i.name))) return false;
  return steps.some((s) => FRYING.test(s.text));
}
