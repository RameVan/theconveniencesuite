// Identify an ingredient from a phrase ("2 boneless chicken breasts", "chicken broth", "old cheese").
//
// Coverage, not similarity: a candidate name only matches when every one of its words is in the phrase, the
// candidate covering the most words wins, and whatever the winner leaves uncovered must be harmless
// (preparation, size, freshness, packaging). A word that changes what the thing is ("sour" cream, chicken
// "broth", "cheddar" cheese) is never ignored, so similar names can't stand in for each other. Candidates are
// catalogue products (and the household's own types), family words ("milk": ask which) and ingredients that
// aren't catalogue products (habanero: substitute). Anything else is unresolved, never guessed.
import type { Db } from '../db/db.ts';
import { FAMILIES, FOREIGN, type Family } from '../db/ingredient-knowledge.ts';
import { listProducts, normalizeText, stem, type Product } from './products.ts';

/** Words that describe preparation, size, state or packaging: they never change what an ingredient is. */
const HARMLESS = new Set([
  // Colours: coloured products (red onion, red lentils, green beans) still win by covering more words.
  'red', 'green', 'yellow', 'orange', 'white', 'purple', 'rode', 'groene', 'gele', 'oranje', 'witte',
  // Filler from speech.
  'uh', 'um', 'uhm', 'eh', 'ehm', 'er', 'erm', 'so', 'then', 'also', 'ook', 'dan', 'nog', 'even', 'please', 'graag',
  // Form, origin and kitchen notes that don't change the ingredient ("ground cinnamon", "kosher salt").
  'standard', 'medium-sized', 'good-quality',
  'ground', 'dried', 'dry', 'purpose', 'all', 'squeezed', 'sized', 'size', 'bite', 'inch', 'inches', 'cm', 'deep', 'frying', 'fry', 'boiled', 'hard', 'kosher', 'sea', 'coarse', 'flaky',
  'unbleached', 'bleached', 'zest', 'zested', 'grated', 'shelled', 'cut', 'thin', 'thick', 'roasted', 'toasted', 'blanched', 'refined', 'unrefined', 'light', 'dark', 'mild', 'medium',
  'fresh', 'freshly', 'large', 'small', 'medium', 'big', 'extra', 'jumbo', 'mini', 'baby', 'young', 'ripe', 'firm', 'soft', 'organic', 'bio', 'free', 'range', 'scharrel',
  'chopped', 'diced', 'sliced', 'minced', 'grated', 'shredded', 'crushed', 'peeled', 'halved', 'quartered', 'cubed', 'trimmed', 'rinsed', 'drained', 'washed', 'pitted', 'seeded', 'deseeded', 'cored',
  'finely', 'roughly', 'coarsely', 'thinly', 'thickly', 'lightly', 'well', 'packed', 'heaping', 'heaped', 'level', 'loosely', 'firmly', 'about', 'approximately', 'around', 'roughly',
  'boneless', 'skinless', 'bone', 'skin', 'lean', 'extra-lean', 'trimmed', 'raw', 'uncooked', 'cooked', 'leftover', 'cold', 'warm', 'room', 'temperature', 'melted', 'softened', 'beaten', 'whisked', 'sifted',
  'canned', 'tinned', 'jarred', 'bottled', 'store', 'bought', 'storebought', 'homemade', 'good', 'quality', 'best', 'plain', 'natural', 'regular', 'whole', 'pure', 'virgin', 'unsalted', 'salted', 'low', 'sodium', 'reduced',
  'of', 'the', 'a', 'an', 'some', 'few', 'plus', 'more', 'or', 'and', 'to', 'taste', 'for', 'serving', 'serve', 'garnish', 'optional', 'divided', 'needed', 'as', 'if', 'in', 'into', 'pieces', 'piece', 'chunks', 'strips', 'rings', 'wedges', 'florets', 'leaves', 'stalks', 'stalk', 'sprigs', 'sprig', 'bunch', 'handful', 'can', 'cans', 'tin', 'tins', 'jar', 'pack', 'package', 'packet', 'bag', 'box', 'carton', 'bottle',
  'vers', 'verse', 'grote', 'groot', 'kleine', 'klein', 'gesneden', 'gehakte', 'fijngehakt', 'fijngesneden', 'geraspt', 'geraspte', 'gepeld', 'gepelde', 'uitgelekt', 'stukjes', 'blokjes', 'plakjes', 'reepjes', 'naar', 'smaak', 'optioneel', 'een', 'de', 'het', 'van', 'en', 'of', 'met', 'zak', 'pak', 'blik', 'pot', 'fles', 'bakje', 'doos',
].map(stem));
// Some words describe a variant only together with a product ("whole milk", "young gouda"): those come from
// the matched name, and only leftover words are checked against HARMLESS.

export type MatchKind = 'product' | 'family' | 'foreign' | 'none';
export interface IngredientMatch {
  kind: MatchKind;
  product?: Product;
  family?: Family;
  foreignKey?: string;
  /** Other candidates covering as many words (ambiguous), or partial matches worth asking about. */
  alternatives: Product[];
  /** Words the match left uncovered that do change identity (only for kind 'none'). */
  leftover: string[];
}

interface Entry { words: string[]; kind: 'product' | 'family' | 'foreign'; product?: Product; family?: Family; foreignKey?: string }

const words = (s: string) => normalizeText(s).replace(/-/g, ' ').split(' ').filter(Boolean).map(stem);

let indexMemo: { db: Db; key: string; entries: Entry[]; byWord: Map<string, Entry[]> } | null = null;

function index(db: Db, householdId: string, country: string, products?: Product[]) {
  const key = `${householdId}|${country}|${db.recipeVersion}|${products ? products.length : 'db'}`;
  if (indexMemo && indexMemo.db === db && indexMemo.key === key) return indexMemo;
  const entries: Entry[] = [];
  for (const p of products ?? listProducts(db, householdId)) {
    for (const n of new Set([p.name, p.name_nl ?? '', ...p.synonyms])) {
      const w = words(n.replace(/\(.*?\)/g, ' '));
      if (w.length) entries.push({ words: w, kind: 'product', product: p });
    }
  }
  for (const f of FAMILIES) for (const n of f.words) entries.push({ words: words(n), kind: 'family', family: f });
  for (const f of FOREIGN) if (f.status[country]) for (const n of f.names) entries.push({ words: words(n), kind: 'foreign', foreignKey: f.key });
  const byWord = new Map<string, Entry[]>();
  for (const e of entries) for (const w of e.words) (byWord.get(w) ?? byWord.set(w, []).get(w)!).push(e);
  indexMemo = { db, key, entries, byWord };
  return indexMemo;
}

const KIND_RANK = { product: 3, foreign: 2, family: 1 } as const;

/** Identify the ingredient a phrase names. See the file comment for the rules. */
export function identifyIngredient(db: Db, householdId: string, phrase: string, opts: { country?: string; products?: Product[] } = {}): IngredientMatch {
  const pw = words(phrase.replace(/\(.*?\)/g, ' '));
  const set = new Set(pw);
  if (!set.size) return { kind: 'none', alternatives: [], leftover: [] };
  const { byWord } = index(db, householdId, opts.country ?? 'NL', opts.products);
  // Candidates: entries all of whose words appear in the phrase.
  const seen = new Set<Entry>();
  const hits: Entry[] = [];
  for (const w of set) for (const e of byWord.get(w) ?? []) {
    if (seen.has(e)) continue;
    seen.add(e);
    if (e.words.every((x) => set.has(x))) hits.push(e);
  }
  if (!hits.length) return { kind: 'none', alternatives: [], leftover: [...set].filter((w) => !HARMLESS.has(w)) };
  // Most words covered wins; then products over foreign over family; then the household's own types.
  hits.sort((a, b) => b.words.length - a.words.length || KIND_RANK[b.kind] - KIND_RANK[a.kind] || Number(!!b.product?.household_id) - Number(!!a.product?.household_id));
  // The largest candidate that leaves nothing meaningful uncovered: "chicken stock cubes" is stock cubes
  // (leaving "chicken"? no: "chicken stock cube" covers all), never broth with "cubes" left over.
  // A product's own family word may be left over: "parmesan cheese" is parmesan, "oat milk drink" oat milk.
  const leftoverOf = (e: Entry) => {
    const own = e.product?.family ? new Set(words(FAMILIES.find((f) => f.id === e.product!.family)?.words.join(' ') ?? '')) : null;
    return [...set].filter((w) => !e.words.includes(w) && !HARMLESS.has(w) && !own?.has(w));
  };
  const best = hits.find((h) => !leftoverOf(h).length) ?? hits[0];
  const leftover = leftoverOf(best);
  const sameSize = hits.filter((h) => h.words.length === best.words.length && h.kind === 'product' && h.product!.id !== best.product?.id && !leftoverOf(h).length).map((h) => h.product!);
  const alternatives = [...new Map(sameSize.map((p) => [p.id, p])).values()];
  if (leftover.length) {
    // "chicken broth" with no broth product would come here: the extra word changes identity.
    const partial = [...new Map(hits.filter((h) => h.kind === 'product').map((h) => [h.product!.id, h.product!])).values()].slice(0, 4);
    return { kind: 'none', alternatives: partial, leftover };
  }
  if (best.kind === 'product') return { kind: 'product', product: best.product, alternatives, leftover: [] };
  if (best.kind === 'family') return { kind: 'family', family: best.family, alternatives: [], leftover: [] };
  return { kind: 'foreign', foreignKey: best.foreignKey, alternatives: [], leftover: [] };
}

/** True when every word of `extra` is harmless (used to stop "chicken" matching "chicken broth" by similarity). */
export function onlyHarmless(extra: string[]): boolean {
  return extra.every((w) => HARMLESS.has(stem(w)));
}

export function familyById(id: string): Family | undefined {
  return FAMILIES.find((f) => f.id === id);
}
