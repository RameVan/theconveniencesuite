// Ingredient details for the app: variants of a family, availability and supermarket products in your
// country, substitutions, ingredients that need review, and correcting a wrongly matched stock item.
import type { Db } from '../db/db.ts';
import { parseJson } from '../db/db.ts';
import { AppError, notFound } from '../errors.ts';
import { bus } from '../bus.ts';
import { FAMILIES, FOREIGN, COUNTRIES, CHAINS, countryAt } from '../db/ingredient-knowledge.ts';
import { getProduct, listProducts, normalizeText, type Product } from './products.ts';
import { householdCountry, subContext, type SubRow } from './substitutions.ts';
import { householdSetting } from './settings.ts';
import type { Ctx } from './ledger.ts';

// Supermarkets' own brands, as people type them into Open Food Facts ("Albert Heiin", "Ah bio", "Jumbo Wapenaer").
const OWN_BRANDS: [string, RegExp][] = [
  ['ah', /^(?:ah|albert[ -]?he[ij]{1,2}n|albert hein)\b/i],
  ['jumbo', /^jumbo\b/i],
];
const BRAND_PREFIX = /^(?:ah|albert heijn|jumbo)(?:\s+(?:bio|basic|terra|excellent))?\s+/i;

/** The chain whose own brand this is, or null. */
export function ownBrandChain(brand: string | null | undefined): string | null {
  const first = (brand ?? '').split(',')[0].trim();
  return OWN_BRANDS.find(([, re]) => re.test(first))?.[0] ?? null;
}

/**
 * A supermarket's own-brand product shown as just the product: no brand, and no "AH "/"Jumbo " in front of the
 * name. An own brand is only sold at that chain, so it also says where when the listing didn't.
 */
export function withoutOwnBrand<T extends { name: string; brand: string | null; chain_id: string | null; chain_name: string | null }>(r: T): T {
  const chain = ownBrandChain(r.brand) ?? ownBrandChain(r.name);
  if (!chain) return r;
  const name = r.name.replace(BRAND_PREFIX, '').trim();
  return { ...r, name: name ? name[0].toUpperCase() + name.slice(1) : r.name, brand: null, chain_id: r.chain_id ?? chain, chain_name: r.chain_name ?? CHAINS.find((c) => c.id === chain)!.name };
}

const slim = (p: Product) => ({ id: p.id, name: p.name, name_nl: p.name_nl, unit: p.unit, family: p.family, subcategory: p.subcategory, custom: p.custom, household: !!p.household_id });

/** Everything about one ingredient: its family's other types, how available it is, and supermarket products. */
export function ingredientDetail(db: Db, householdId: string, productId: string) {
  const p = getProduct(db, productId);
  if (!p || (p.household_id && p.household_id !== householdId)) throw notFound('Ingredient');
  const country = householdCountry(db, householdId);
  const ctx = subContext(db, householdId, country);
  const family = p.family ? FAMILIES.find((f) => f.id === p.family) ?? null : null;
  const variants = family ? listProducts(db, householdId).filter((x) => x.family === family.id).map(slim) : [];
  const chains = householdSetting(db, householdId, 'chains') as string[];
  const retail = db.all<any>(
    `SELECT r.*, c.name AS chain_name FROM retail_products r LEFT JOIN chains c ON c.id = r.chain_id
     WHERE r.product_id = ? AND r.country = ? ORDER BY r.status = 'verified' DESC, r.status = 'listed' DESC, c.name, r.name LIMIT 200`,
    p.id, country,
  ).map(withoutOwnBrand).filter((r) => !chains.length || !r.chain_id || chains.includes(r.chain_id));
  const byChain = new Map<string, number>();
  for (const r of retail) if (r.chain_id) byChain.set(r.chain_name, (byChain.get(r.chain_name) ?? 0) + 1);
  const subs = (ctx.subs.get(p.id) ?? []).map((s) => subView(db, s));
  return {
    product: { ...slim(p), measure: p.measure, package_options: p.package_options, density: p.density, piece_size: p.piece_size, nutrition_source: p.nutrition_source },
    family: family ? { id: family.id, name: family.name, name_nl: family.name_nl } : null,
    variants,
    country,
    availability: ctx.availability.get(p.id) ?? 'common',
    chains: [...byChain.entries()].map(([name, count]) => ({ name, count })),
    shops: shopLinks(db, householdId),
    searchTerm: country === 'NL' ? p.name_nl || p.name : p.name,
    retail: retail.map((r) => ({ id: r.id, chain: r.chain_name, name: r.name, brand: r.brand, size: r.size, size_text: r.size_text, ean: r.ean, url: r.url, status: r.status, source: r.source, last_verified: r.last_verified })),
    alternatives: subs,
    preferred: db.get<{ choice: string }>('SELECT choice FROM substitution_prefs WHERE household_id = ? AND from_key = ?', householdId, p.id)?.choice ?? null,
  };
}

/**
 * Webshops to search for an ingredient yourself: the household's chains (or all of its country's) that have a
 * search page. Only links; PantryPip never fetches these sites (their terms don't allow automated collection).
 */
export function shopLinks(db: Db, householdId: string) {
  const country = householdCountry(db, householdId);
  const chosen = householdSetting(db, householdId, 'chains') as string[];
  const all = CHAINS.filter((c) => c.country === country && c.search);
  const mine = all.filter((c) => chosen.includes(c.id));
  return (mine.length ? mine : all).map((c) => ({ id: c.id, name: c.name, search: c.search! }));
}

function subView(db: Db, s: SubRow) {
  const to = getProduct(db, s.to_product);
  return { to: to ? slim(to) : null, kind: s.kind, note: s.note, prep: s.prep, identity: s.identity, ratio: s.ratio, with: s.extra.map((e) => ({ ...e, name: getProduct(db, e.product)?.name ?? e.product })) };
}

/**
 * Recipe ingredients that aren't an exact product, across the recipes this household sees: unresolved ones to
 * match by hand, and substitutions to review. Grouped by ingredient, most used first.
 */
export function reviewList(db: Db, householdId: string, opts: { all?: boolean } = {}) {
  const country = householdCountry(db, householdId);
  const ctx = subContext(db, householdId, country);
  const rows = db.all<{ source_key: string; match: string; n: number; example: string; title: string; product_id: string | null }>(
    `SELECT ri.source_key, ri.match, COUNT(*) n, MIN(COALESCE(ri.display, ri.name)) example, MIN(r.title) title, MIN(ri.product_id) product_id
     FROM recipe_ingredients ri JOIN recipes r ON r.id = ri.recipe_id
     WHERE (r.household_id IS NULL OR r.household_id = ?) AND ri.source_key IS NOT NULL AND ri.source_key != 'u:water' AND ri.source_key NOT LIKE 'f:%'
     GROUP BY ri.source_key ORDER BY n DESC`,
    householdId,
  );
  const foreign = new Map(FOREIGN.map((f) => [f.key, f]));
  return rows
    .filter((r) => opts.all || !r.product_id || ctx.prefs.has(r.source_key) || r.match === 'approximate')
    .map((r) => {
      const choice = ctx.prefs.get(r.source_key) ?? null;
      const f = foreign.get(r.source_key);
      return {
        key: r.source_key, name: f?.names[0] ?? r.source_key.slice(2), recipes: r.n, example: r.example, exampleRecipe: r.title,
        status: f ? ctx.foreign.get(r.source_key)?.status ?? null : null,
        suggestion: r.product_id ? slim(getProduct(db, r.product_id)!) : null,
        match: r.match, choice,
        options: (ctx.subs.get(r.source_key) ?? []).map((s) => subView(db, s)),
      };
    });
}

/**
 * "That wasn't milk, it was oat milk": move a stock item, with its history, to another product measured the
 * same way. The ledger stays consistent because the lot and its events change together.
 */
export function reassignLot(ctx: Ctx, lotId: string, productId: string) {
  const lot = ctx.db.get<{ id: string; product_id: string | null; household_id: string }>('SELECT id, product_id, household_id FROM inventory_lots WHERE id = ?', lotId);
  if (!lot || lot.household_id !== ctx.householdId) throw notFound('Inventory item');
  const to = getProduct(ctx.db, productId);
  if (!to || (to.household_id && to.household_id !== ctx.householdId)) throw notFound('Product');
  const from = lot.product_id ? getProduct(ctx.db, lot.product_id) : null;
  if (from && from.unit !== to.unit) throw new AppError(422, 'unit_mismatch', `${from.name} is measured in ${from.unit} and ${to.name} in ${to.unit}: add it again as ${to.name} instead.`);
  ctx.db.tx(() => {
    ctx.db.run('UPDATE inventory_lots SET product_id = ? WHERE id = ?', productId, lotId);
    ctx.db.run('UPDATE inventory_events SET product_id = ? WHERE lot_id = ?', productId, lotId);
  });
  bus.touch(ctx.householdId, 'inventory');
  return { lotId, from: from?.id ?? null, to: productId };
}

/** Countries, their chains, and the household's current choice. */
export function countryOptions(db: Db, householdId: string) {
  return {
    country: householdCountry(db, householdId),
    source: householdSetting(db, householdId, 'countrySource'),
    chains: householdSetting(db, householdId, 'chains'),
    countries: COUNTRIES.map((c) => ({ code: c.code, name: c.name, name_nl: c.name_nl, supported: c.supported, chains: CHAINS.filter((x) => x.country === c.code).map((x) => ({ id: x.id, name: x.name, online: !!x.online, products: db.get<{ n: number }>('SELECT COUNT(*) n FROM retail_products WHERE chain_id = ?', x.id)!.n })) })),
  };
}

export { countryAt };

/** Your usual type per family ("milk" → semi-skimmed), with the names to show. */
export function familyPrefs(db: Db, householdId: string) {
  return db.all<{ from_key: string; choice: string }>("SELECT from_key, choice FROM substitution_prefs WHERE household_id = ? AND from_key LIKE 'f:%'", householdId).map((r) => {
    const f = FAMILIES.find((x) => x.id === r.from_key.slice(2));
    const p = getProduct(db, r.choice);
    return { family: r.from_key.slice(2), name: f?.name ?? r.from_key, name_nl: f?.name_nl ?? r.from_key, choice: p ? slim(p) : null };
  });
}

export const keyFor = (name: string) => `u:${normalizeText(name)}`;
export { parseJson };
