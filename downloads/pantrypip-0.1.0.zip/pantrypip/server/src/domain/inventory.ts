// Inventory read model: per-product stock with confirmed vs estimated quantities.
import type { Db } from '../db/db.ts';
import { clock, daysBetween } from '../clock.ts';
import { getProduct, rowToProduct, type Product } from './products.ts';
import { predictProduct, estimateStock, usageRatio, type Prediction } from './prediction.ts';
import { setProductQuantity, type Ctx, type Lot } from './ledger.ts';

export interface LotView extends Lot {
  location_name: string | null;
  location_kind: string | null;
  days_to_expiry: number | null;
}

export interface StockItem {
  product: Product;
  lots: LotView[];
  confirmed: number;
  estimated: number;
  showEstimate: boolean;
  confidence: number;
  daysLeft: number | null;
  runOutOn: string | null;
  soonestExpiry: string | null;
  daysToExpiry: number | null;
  expiryEstimated: boolean;
  low: boolean;
  status: 'ok' | 'low' | 'out' | 'expiring' | 'expired';
  locations: string[];
  lastPurchaseAt: string | null;
  lastConfirmedAt: string | null;
  prediction: Prediction;
}

export interface LeftoverItem extends LotView {
  title: string;
}

function lotViews(db: Db, householdId: string): LotView[] {
  const today = clock.today();
  return db
    .all<any>(
      `SELECT l.*, s.name AS location_name, s.kind AS location_kind FROM inventory_lots l
       LEFT JOIN storage_locations s ON s.id = l.location_id
       WHERE l.household_id = ? AND l.status = 'active' ORDER BY l.expires_on IS NULL, l.expires_on`,
      householdId,
    )
    .map((l) => ({ ...l, days_to_expiry: l.expires_on ? Math.round(daysBetween(today, l.expires_on)) : null }));
}

export function stockForProduct(db: Db, householdId: string, product: Product, lots: LotView[]): StockItem {
  const pred = predictProduct(db, householdId, product.id);
  const est = estimateStock(lots, pred);
  const expiries = lots.filter((l) => l.expires_on).sort((a, b) => a.expires_on!.localeCompare(b.expires_on!));
  const soonest = expiries[0] ?? null;
  const daysToExpiry = soonest?.days_to_expiry ?? null;
  const qty = est.showEstimate ? est.estimated : est.confirmed;
  // Low stock: under ~3 days of use, or under a quarter of a package when we have no rate.
  const rate = pred.ratePerDay;
  const threshold = rate && pred.confidence >= 0.4 ? Math.max(rate * 3, product.package_size * 0.15) : product.package_size * 0.25;
  const low = !product.staple && qty <= threshold + 1e-9;
  let status: StockItem['status'] = 'ok';
  if (qty <= 1e-6) status = 'out';
  else if (daysToExpiry != null && daysToExpiry < 0) status = 'expired';
  else if (daysToExpiry != null && daysToExpiry <= 2) status = 'expiring';
  else if (low) status = 'low';
  return {
    product,
    lots,
    confirmed: est.confirmed,
    estimated: est.estimated,
    showEstimate: est.showEstimate,
    confidence: est.confidence,
    daysLeft: est.daysLeft,
    runOutOn: est.runOutOn,
    soonestExpiry: soonest?.expires_on ?? null,
    daysToExpiry,
    expiryEstimated: !!soonest?.expiry_estimated,
    low,
    status,
    locations: [...new Set(lots.map((l) => l.location_name).filter(Boolean) as string[])],
    lastPurchaseAt: pred.lastPurchaseAt,
    lastConfirmedAt: lots.reduce<string | null>((m, l) => (!m || l.last_confirmed_at > m ? l.last_confirmed_at : m), null),
    prediction: pred,
  };
}

export function inventorySummary(db: Db, householdId: string): { items: StockItem[]; leftovers: LeftoverItem[] } {
  const lots = lotViews(db, householdId);
  const byProduct = new Map<string, LotView[]>();
  const leftovers: LeftoverItem[] = [];
  for (const l of lots) {
    if (l.is_leftover || !l.product_id) {
      leftovers.push({ ...l, title: l.label ?? 'Leftovers' });
      continue;
    }
    const arr = byProduct.get(l.product_id) ?? [];
    arr.push(l);
    byProduct.set(l.product_id, arr);
  }
  const products = new Map(
    db.all(`SELECT * FROM products WHERE id IN (${[...byProduct.keys()].map(() => '?').join(',') || "''"})`, ...byProduct.keys()).map((r) => [r.id, rowToProduct(r)]),
  );
  const items: StockItem[] = [];
  for (const [pid, plots] of byProduct) {
    const p = products.get(pid);
    if (p) items.push(stockForProduct(db, householdId, p, plots));
  }
  items.sort((a, b) => a.product.name.localeCompare(b.product.name));
  return { items, leftovers };
}

export function stockItem(db: Db, householdId: string, productId: string): StockItem | null {
  const p = getProduct(db, productId);
  if (!p) return null;
  const lots = lotViews(db, householdId).filter((l) => l.product_id === productId && !l.is_leftover);
  return stockForProduct(db, householdId, p, lots);
}

/** Quantity we believe is available right now (estimate if trustworthy, else confirmed). */
export function availableQty(db: Db, householdId: string, productId: string): number {
  const s = stockItem(db, householdId, productId);
  if (!s) return 0;
  return s.showEstimate ? s.estimated : s.confirmed;
}

/** A user-stated quantity: record it with the estimate they would have seen (trains the predictor). */
export function correctQuantity(ctx: Ctx, productId: string, actual: number, opts: { expectedTotal?: number | null } = {}) {
  const s = stockItem(ctx.db, ctx.householdId, productId);
  const predicted = s ? (s.showEstimate ? s.estimated : s.confirmed) : 0;
  const confirmed = s?.confirmed ?? 0;
  const ratio = s && s.estimated < s.confirmed - 1e-6 ? usageRatio(confirmed, predicted, actual) : null;
  return setProductQuantity(ctx, productId, actual, {
    expectedTotal: opts.expectedTotal,
    predictedBefore: predicted,
    meta: ratio != null ? { usageRatio: ratio, predicted, confirmed } : { predicted, confirmed },
  });
}

export function recentEvents(db: Db, householdId: string, limit = 50, productId?: string) {
  return db.all(
    `SELECT e.*, p.name AS product_name, p.name_nl AS product_name_nl, l.label AS lot_label FROM inventory_events e
     LEFT JOIN products p ON p.id = e.product_id
     LEFT JOIN inventory_lots l ON l.id = e.lot_id
     WHERE e.household_id = ? ${productId ? 'AND e.product_id = ?' : ''}
     ORDER BY e.created_at DESC, e.rowid DESC LIMIT ?`,
    ...(productId ? [householdId, productId, limit] : [householdId, limit]),
  );
}
