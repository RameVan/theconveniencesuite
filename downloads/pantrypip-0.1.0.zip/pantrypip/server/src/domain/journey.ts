// The journey: seven chapters of real kitchen tasks, five skill tracks, and a small companion that
// travels along. Everything is measured from verified records (cook log, ledger, plan, recipes),
// never from taps. Each completed node is stored once (journey_nodes primary key), so XP can't be
// earned twice and finished tasks stay finished even if the underlying record is later undone.
// Tasks are picked when a chapter unlocks, preferring ones the household can actually do right now.
import type { Db } from '../db/db.ts';
import { parseJson } from '../db/db.ts';
import { clock, addDays } from '../clock.ts';
import { cookHistory, weekOf, xpRules, type CookEntry } from './game.ts';
import { mealTargets } from './health.ts';
import { searchRecipes } from './recipes.ts';
import { AppError } from '../errors.ts';

type Txt = [string, string];
interface Facts {
  now: string;
  entries: (CookEntry & { protein: number; fibre: number; vegOk: boolean; minutes: number; cuisine: string | null; rated: number; vegetarian: boolean; cost: number | null; planned: boolean; mine: boolean })[];
  purchases: { at: string; productId: string; source: string; batch: string | null }[];
  events: { at: string; type: string; leftover: boolean }[];
  rescues: { at: string; productId: string; batch: string | null }[];
  cookIngredients: Map<string, number>;
  saved: number;
  own: number;
  rated: number;
  slots: { date: string; status: string }[];
  trips: string[];
  challengesDone: { id: string; at: string }[];
  /** Dinner share of the day's protein and fibre (g). */
  proteinTarget: number;
  fibreTarget: number;
  feasible: Record<string, () => boolean>;
}

interface TaskDef {
  id: string;
  emoji: string;
  title: Txt;
  desc: Txt;
  goal: number;
  /** 'ever' counts everything you've done; 'since' only what happened after the chapter opened. */
  scope: 'ever' | 'since';
  measure: (f: Facts, since: string) => number;
  cta: { href: string; label: Txt };
  feasible?: (f: Facts) => boolean;
  hint?: Txt;
}

const at = (since: string) => <T extends { at: string }>(xs: T[]) => xs.filter((x) => x.at >= since);
const distinct = <T>(xs: T[]) => new Set(xs).size;
/** Most of something in any one calendar week. */
const bestWeek = <T>(xs: T[], dateOf: (x: T) => string, count: (xs: T[]) => number = (a) => a.length) => {
  const byWeek = new Map<string, T[]>();
  for (const x of xs) byWeek.set(weekOf(dateOf(x)), [...(byWeek.get(weekOf(dateOf(x))) ?? []), x]);
  return Math.max(0, ...[...byWeek.values()].map(count));
};
const bestRun = (dates: string[]) => {
  let best = 0;
  let run = 0;
  let prev: string | null = null;
  for (const d of [...new Set(dates)].sort()) {
    run = prev && addDays(prev, 1) === d ? run + 1 : 1;
    best = Math.max(best, run);
    prev = d;
  }
  return best;
};
const cooks = (f: Facts, since: string) => at(since)(f.entries);
const cookDays = (f: Facts, since: string) => distinct(cooks(f, since).map((e) => e.date));

const CTA = {
  bought: { href: '#/?do=list', label: ['Add what you bought', 'Voeg boodschappen toe'] as Txt },
  voice: { href: '#/?do=voice', label: ['Tell PantryPip', 'Zeg het tegen PantryPip'] as Txt },
  recipes: { href: '#/discover', label: ['Find a recipe', 'Zoek een recept'] as Txt },
  fromStock: { href: '#/discover', label: ['Recipes from your stock', 'Recepten met je voorraad'] as Txt },
  plan: { href: '#/plan?auto=1', label: ['Plan my week', 'Plan mijn week'] as Txt },
  tonight: { href: '#/plan', label: ['See tonight’s dinner', 'Bekijk het avondeten'] as Txt },
  inventory: { href: '#/inventory', label: ['Open inventory', 'Open voorraad'] as Txt },
  shopping: { href: '#/shopping', label: ['Open shopping list', 'Open boodschappenlijst'] as Txt },
  addRecipe: { href: '#/discover?add=1', label: ['Add a recipe', 'Recept toevoegen'] as Txt },
  progress: { href: '#/progress', label: ['See challenges', 'Bekijk uitdagingen'] as Txt },
};

const T = (d: Omit<TaskDef, 'scope'> & { scope?: TaskDef['scope'] }): TaskDef => ({ scope: 'since', ...d });

const balancedMeal = (e: Facts['entries'][number]) => e.score >= 70;

export const TASKS: Record<string, TaskDef> = Object.fromEntries(
  [
    // 1 · The First Kitchen
    T({ id: 'add5', emoji: '🛒', title: ['Add your first five groceries', 'Voeg je eerste vijf boodschappen toe'], desc: ['Say or scan what you bought. Five different products.', 'Zeg of scan wat je kocht. Vijf verschillende producten.'], goal: 5, scope: 'ever', measure: (f) => distinct(f.purchases.map((p) => p.productId)), cta: CTA.bought }),
    T({ id: 'save1', emoji: '🔖', title: ['Save your first recipe', 'Bewaar je eerste recept'], desc: ['Bookmark one you like, or add your own.', 'Bewaar er een die je lekker lijkt, of voeg je eigen toe.'], goal: 1, scope: 'ever', measure: (f) => f.saved + f.own, cta: CTA.recipes }),
    T({ id: 'cook1', emoji: '🍽️', title: ['Complete your first dinner', 'Kook je eerste avondeten'], desc: ['Cook any recipe and tap “Cooked it”.', 'Kook een recept en tik op “Gekookt”.'], goal: 1, scope: 'ever', measure: (f) => f.entries.length, cta: CTA.fromStock }),
    T({ id: 'plan1', emoji: '🗓️', title: ['Plan your first week', 'Plan je eerste week'], desc: ['Three or more dinners in one week. One tap does it.', 'Drie of meer avondmaaltijden in één week. Eén tik is genoeg.'], goal: 3, scope: 'ever', measure: (f) => bestWeek(f.slots, (s) => s.date), cta: CTA.plan }),
    T({ id: 'used1', emoji: '🥛', title: ['Tell PantryPip you used something', 'Vertel PantryPip dat je iets gebruikte'], desc: ['“I finished the milk” keeps your stock right.', '“De melk is op” houdt je voorraad klopend.'], goal: 1, scope: 'ever', measure: (f) => f.events.filter((e) => e.type === 'consume').length, cta: CTA.voice }),
    T({ id: 'rate1', emoji: '⭐', title: ['Rate a recipe', 'Geef een recept sterren'], desc: ['Ratings make your week plans better.', 'Sterren maken je weekplanning beter.'], goal: 1, scope: 'ever', measure: (f) => f.rated, cta: CTA.recipes }),
    // 2 · The Ingredient Explorer
    T({ id: 'newIngr3', emoji: '🧺', title: ['Try three new ingredients', 'Probeer drie nieuwe ingrediënten'], desc: ['Buy something you’ve never had in PantryPip before.', 'Koop iets wat nog nooit in PantryPip stond.'], goal: 3, measure: (f, since) => { const first = new Map<string, string>(); for (const p of f.purchases) if (!first.has(p.productId) || p.at < first.get(p.productId)!) first.set(p.productId, p.at); return [...first.values()].filter((a) => a >= since).length; }, cta: CTA.shopping }),
    T({ id: 'rescue3', emoji: '🛟', title: ['Use three ingredients close to their date', 'Gebruik drie producten vlak voor de datum'], desc: ['Cook with or use up food within 2 days of its date.', 'Kook met of gebruik eten binnen 2 dagen voor de datum.'], goal: 3, measure: (f, since) => at(since)(f.rescues).length, cta: CTA.fromStock, feasible: (f) => f.feasible.expiringSoon(), hint: ['Shows up when something is close to its date.', 'Komt vanzelf als iets bijna over de datum is.'] }),
    T({ id: 'fromStock1', emoji: '🥕', title: ['Cook a meal from what you have', 'Kook een maaltijd met wat je hebt'], desc: ['A dinner that uses at least 3 things from your stock.', 'Een maaltijd met minstens 3 dingen uit je voorraad.'], goal: 1, measure: (f, since) => cooks(f, since).filter((e) => (f.cookIngredients.get(e.batchId) ?? 0) >= 3).length, cta: CTA.fromStock, feasible: (f) => f.feasible.cookableNow(), hint: ['Add a few groceries first.', 'Voeg eerst wat boodschappen toe.'] }),
    T({ id: 'open1', emoji: '🫙', title: ['Tell PantryPip when you open something', 'Meld het als je iets opent'], desc: ['“I opened the yoghurt” updates its use-by date.', '“Ik heb de yoghurt geopend” past de datum aan.'], goal: 1, measure: (f, since) => at(since)(f.events).filter((e) => e.type === 'open').length, cta: CTA.voice }),
    T({ id: 'leftover1', emoji: '🥡', title: ['Save leftovers', 'Bewaar restjes'], desc: ['Cooked too much? Keep it for another day.', 'Te veel gekookt? Bewaar het voor een andere dag.'], goal: 1, measure: (f, since) => at(since)(f.events).filter((e) => e.type === 'leftover').length, cta: CTA.tonight }),
    T({ id: 'freeze1', emoji: '🧊', title: ['Freeze something before it goes off', 'Vries iets in voor het bederft'], desc: ['Bread, meat, leftovers: the freezer buys time.', 'Brood, vlees, restjes: de vriezer koopt tijd.'], goal: 1, measure: (f, since) => at(since)(f.events).filter((e) => e.type === 'freeze').length, cta: CTA.inventory }),
    // 3 · The Home Cook
    T({ id: 'planned3', emoji: '✅', title: ['Cook three planned dinners', 'Kook drie geplande maaltijden'], desc: ['Cook what your plan says.', 'Kook wat in je planning staat.'], goal: 3, measure: (f, since) => cooks(f, since).filter((e) => e.planned).length, cta: CTA.tonight }),
    T({ id: 'week5', emoji: '📅', title: ['Five dinners in one week', 'Vijf keer koken in één week'], desc: ['Cook on five days of the same week.', 'Kook op vijf dagen in dezelfde week.'], goal: 5, measure: (f, since) => bestWeek(cooks(f, since), (e) => e.date, (es) => distinct(es.map((e) => e.date))), cta: CTA.plan }),
    T({ id: 'loved3', emoji: '❤️', title: ['Cook three highly rated recipes', 'Kook drie recepten met 4+ sterren'], desc: ['Your 4★ and 5★ favourites count.', 'Je favorieten met 4 of 5 sterren tellen.'], goal: 3, measure: (f, since) => cooks(f, since).filter((e) => e.rated >= 4).length, cta: CTA.recipes, feasible: (f) => f.rated > 0 && f.feasible.hasLoved(), hint: ['Rate a few recipes 4★ or more first.', 'Geef eerst een paar recepten 4 sterren of meer.'] }),
    T({ id: 'streak3', emoji: '🔥', title: ['Cook three days in a row', 'Kook drie dagen op rij'], desc: ['Small habits add up.', 'Kleine gewoontes tellen op.'], goal: 3, measure: (f, since) => bestRun(cooks(f, since).map((e) => e.date)), cta: CTA.plan }),
    T({ id: 'eatLeftover', emoji: '🍲', title: ['Eat your leftovers', 'Eet je restjes op'], desc: ['Tap “1” on a leftover when you eat it.', 'Tik op “1” bij een restje als je het eet.'], goal: 1, measure: (f, since) => at(since)(f.events).filter((e) => e.type === 'consume' && e.leftover).length, cta: CTA.inventory, feasible: (f) => f.feasible.hasLeftovers(), hint: ['Save leftovers after cooking first.', 'Bewaar eerst restjes na het koken.'] }),
    T({ id: 'cook6', emoji: '🍳', title: ['Cook six dinners', 'Kook zes keer'], desc: ['Any dinners, any days.', 'Welk gerecht en welke dag dan ook.'], goal: 6, measure: (f, since) => cooks(f, since).length, cta: CTA.fromStock }),
    // 4 · The Recipe Adventurer
    T({ id: 'newCuisine', emoji: '🌍', title: ['Cook a recipe from a different cuisine', 'Kook uit een andere keuken'], desc: ['A cuisine you haven’t cooked before.', 'Een keuken die je nog niet kookte.'], goal: 1, measure: (f, since) => { const before = new Set(f.entries.filter((e) => e.at < since).map((e) => e.cuisine)); return distinct(cooks(f, since).map((e) => e.cuisine).filter((c) => c && !before.has(c))); }, cta: CTA.recipes, feasible: (f) => f.feasible.newCuisine() }),
    T({ id: 'save5', emoji: '📚', title: ['Save five recipes', 'Bewaar vijf recepten'], desc: ['Build a library you actually want to cook.', 'Bouw een verzameling die je echt wilt koken.'], goal: 5, scope: 'ever', measure: (f) => f.saved + f.own, cta: CTA.recipes }),
    T({ id: 'newRecipe', emoji: '✨', title: ['Cook a recipe you’ve never made', 'Kook een recept dat je nog nooit maakte'], desc: ['Something new for dinner.', 'Iets nieuws op tafel.'], goal: 1, measure: (f, since) => cooks(f, since).filter((e) => e.parts.some((p) => p.key === 'new')).length, cta: CTA.recipes }),
    T({ id: 'ownRecipe', emoji: '📝', title: ['Add a recipe of your own', 'Voeg een eigen recept toe'], desc: ['Type it, dictate it or paste a link.', 'Typ het, spreek het in of plak een link.'], goal: 1, scope: 'ever', measure: (f) => f.own, cta: CTA.addRecipe }),
    T({ id: 'cuisines3', emoji: '🗺️', title: ['Cook three cuisines', 'Kook drie keukens'], desc: ['Three different cuisines in total.', 'Drie verschillende keukens in totaal.'], goal: 3, scope: 'ever', measure: (f) => distinct(f.entries.map((e) => e.cuisine).filter(Boolean)), cta: CTA.recipes }),
    T({ id: 'rate3', emoji: '🌟', title: ['Rate three recipes', 'Geef drie recepten sterren'], desc: ['Tell PantryPip what you liked.', 'Laat weten wat je lekker vond.'], goal: 3, scope: 'ever', measure: (f) => f.rated, cta: CTA.recipes }),
    // 5 · The Balanced Kitchen
    T({ id: 'protein1', emoji: '💪', title: ['Reach your protein target', 'Haal je eiwitdoel'], desc: ['A dinner with your share of the day’s protein.', 'Een avondmaal met jouw deel van het eiwit van de dag.'], goal: 1, measure: (f, since) => cooks(f, since).filter((e) => e.protein >= f.proteinTarget).length, cta: CTA.recipes, feasible: (f) => f.feasible.proteinPossible() }),
    T({ id: 'balancedDay', emoji: '⚖️', title: ['Have a balanced day', 'Heb een gebalanceerde dag'], desc: ['A day whose dinner scores 70 or more.', 'Een dag waarop je avondeten 70 of meer scoort.'], goal: 1, measure: (f, since) => distinct(cooks(f, since).filter(balancedMeal).map((e) => e.date)), cta: CTA.plan }),
    T({ id: 'balanced3', emoji: '🥗', title: ['Three balanced meals', 'Drie gebalanceerde maaltijden'], desc: ['Score 70+ three times. Higher doesn’t earn more.', 'Drie keer 70+. Hoger levert niet meer op.'], goal: 3, measure: (f, since) => cooks(f, since).filter(balancedMeal).length, cta: CTA.plan }),
    T({ id: 'veg2', emoji: '🥦', title: ['Two veg-packed dinners', 'Twee keer flink groente'], desc: ['200 g of vegetables per serving.', '200 g groente per portie.'], goal: 2, measure: (f, since) => cooks(f, since).filter((e) => e.vegOk).length, cta: CTA.recipes }),
    T({ id: 'steadyWeek', emoji: '📈', title: ['A steady week', 'Een stabiele week'], desc: ['Four cooking days in one week, each scoring 60+.', 'Vier kookdagen in één week, elk met 60+.'], goal: 4, measure: (f, since) => bestWeek(cooks(f, since).filter((e) => e.score >= 60), (e) => e.date, (es) => distinct(es.map((e) => e.date))), cta: CTA.plan }),
    T({ id: 'fibre2', emoji: '🌾', title: ['Two high-fibre dinners', 'Twee vezelrijke maaltijden'], desc: ['Your dinner share of the day’s fibre.', 'Jouw avonddeel van de vezels van de dag.'], goal: 2, measure: (f, since) => cooks(f, since).filter((e) => e.fibre >= f.fibreTarget).length, cta: CTA.recipes }),
    // 6 · The Confident Chef
    T({ id: 'fullWeek', emoji: '🗓️', title: ['Plan a full week', 'Plan een hele week'], desc: ['Six or more dinners planned in one week.', 'Zes of meer avondmaaltijden in één week gepland.'], goal: 6, measure: (f, since) => bestWeek(f.slots.filter((s) => s.date >= since.slice(0, 10)), (s) => s.date), cta: CTA.plan }),
    T({ id: 'plannedWeek4', emoji: '🎯', title: ['Follow your plan', 'Volg je planning'], desc: ['Cook four planned dinners in one week.', 'Kook vier geplande maaltijden in één week.'], goal: 4, measure: (f, since) => bestWeek(cooks(f, since).filter((e) => e.planned), (e) => e.date), cta: CTA.tonight }),
    T({ id: 'trip1', emoji: '🛍️', title: ['Shop from your list', 'Doe boodschappen met je lijst'], desc: ['Tick items off and finish the trip.', 'Vink af en rond je boodschappen af.'], goal: 1, measure: (f, since) => f.trips.filter((t) => t >= since).length, cta: CTA.shopping }),
    T({ id: 'quick3', emoji: '⏱️', title: ['Three quick dinners', 'Drie snelle maaltijden'], desc: ['Ready in 30 minutes or less.', 'Klaar in 30 minuten of minder.'], goal: 3, measure: (f, since) => cooks(f, since).filter((e) => e.minutes <= 30).length, cta: CTA.recipes }),
    T({ id: 'rescue5', emoji: '🛟', title: ['Rescue five foods', 'Red vijf producten'], desc: ['Use food within 2 days of its date.', 'Gebruik eten binnen 2 dagen voor de datum.'], goal: 5, measure: (f, since) => at(since)(f.rescues).length, cta: CTA.fromStock, feasible: (f) => f.feasible.expiringSoon(), hint: ['Shows up when something is close to its date.', 'Komt vanzelf als iets bijna over de datum is.'] }),
    T({ id: 'cook20', emoji: '🍳', title: ['Twenty dinners cooked', 'Twintig keer gekookt'], desc: ['In total, since you started.', 'In totaal, sinds je begon.'], goal: 20, scope: 'ever', measure: (f) => f.entries.length, cta: CTA.fromStock }),
    // 7 · The Culinary Master
    T({ id: 'distinct30', emoji: '📖', title: ['Thirty different recipes', 'Dertig verschillende recepten'], desc: ['Cooked at least once each.', 'Elk minstens één keer gekookt.'], goal: 30, scope: 'ever', measure: (f) => distinct(f.entries.map((e) => e.recipeId)), cta: CTA.recipes }),
    T({ id: 'cuisines6', emoji: '🧳', title: ['Six cuisines', 'Zes keukens'], desc: ['A real world tour.', 'Een echte wereldreis.'], goal: 6, scope: 'ever', measure: (f) => distinct(f.entries.map((e) => e.cuisine).filter(Boolean)), cta: CTA.recipes }),
    T({ id: 'rescue25', emoji: '♻️', title: ['Twenty-five foods rescued', 'Vijfentwintig producten gered'], desc: ['Used before they went off.', 'Gebruikt voor ze bedierven.'], goal: 25, scope: 'ever', measure: (f) => f.rescues.length, cta: CTA.fromStock }),
    T({ id: 'balanced30', emoji: '🥇', title: ['Thirty balanced meals', 'Dertig gebalanceerde maaltijden'], desc: ['Meals scoring 70+.', 'Maaltijden met 70+.'], goal: 30, scope: 'ever', measure: (f) => f.entries.filter(balancedMeal).length, cta: CTA.plan }),
    T({ id: 'streak14', emoji: '☄️', title: ['Two weeks of home cooking', 'Twee weken thuis koken'], desc: ['Cook 14 days in a row (once).', 'Kook (één keer) 14 dagen op rij.'], goal: 14, scope: 'ever', measure: (f) => bestRun(f.entries.map((e) => e.date)), cta: CTA.plan }),
    T({ id: 'cook60', emoji: '🏅', title: ['Sixty dinners cooked', 'Zestig keer gekookt'], desc: ['In total, since you started.', 'In totaal, sinds je begon.'], goal: 60, scope: 'ever', measure: (f) => f.entries.length, cta: CTA.fromStock }),
    // Bonus (optional, never block the path)
    T({ id: 'receipt1', emoji: '🧾', title: ['Bonus: scan a receipt', 'Bonus: scan een kassabon'], desc: ['Everything you bought in one photo.', 'Alles wat je kocht in één foto.'], goal: 1, measure: (f, since) => distinct(at(since)(f.purchases).filter((p) => p.source === 'receipt').map((p) => p.batch)), cta: { href: '#/?do=receipt', label: ['Scan a receipt', 'Scan een bon'] } }),
    T({ id: 'voiceList', emoji: '🎙️', title: ['Bonus: add groceries by voice', 'Bonus: boodschappen inspreken'], desc: ['“I bought eggs, milk and spinach.”', '“Ik kocht eieren, melk en spinazie.”'], goal: 1, measure: (f, since) => distinct(at(since)(f.purchases).filter((p) => p.source === 'voice').map((p) => p.batch)), cta: CTA.bought }),
    T({ id: 'weekend', emoji: '🥘', title: ['Bonus: cook on Saturday and Sunday', 'Bonus: kook op zaterdag én zondag'], desc: ['A weekend of home cooking.', 'Een weekend thuis koken.'], goal: 2, measure: (f, since) => bestWeek(cooks(f, since).filter((e) => [0, 6].includes(new Date(e.date + 'T12:00:00Z').getUTCDay())), (e) => e.date, (es) => distinct(es.map((e) => e.date))), cta: CTA.plan }),
    T({ id: 'cookMine', emoji: '📝', title: ['Bonus: cook one of your own recipes', 'Bonus: kook een eigen recept'], desc: ['A recipe you added, on the table.', 'Een recept dat je zelf toevoegde, op tafel.'], goal: 1, measure: (f, since) => cooks(f, since).filter((e) => e.mine).length, cta: CTA.addRecipe }),
    T({ id: 'plants2', emoji: '🌱', title: ['Bonus: two vegetarian dinners', 'Bonus: twee vegetarische maaltijden'], desc: ['Plants on the plate.', 'Planten op je bord.'], goal: 2, measure: (f, since) => cooks(f, since).filter((e) => e.vegetarian).length, cta: CTA.recipes }),
    T({ id: 'budget3', emoji: '💶', title: ['Bonus: three budget dinners', 'Bonus: drie budgetmaaltijden'], desc: ['€2.50 or less per serving.', '€ 2,50 of minder per portie.'], goal: 3, measure: (f, since) => cooks(f, since).filter((e) => e.cost != null && e.cost <= 2.5).length, cta: CTA.recipes }),
    T({ id: 'challenge1', emoji: '🎯', title: ['Bonus: finish a challenge', 'Bonus: voltooi een uitdaging'], desc: ['Any 7-day challenge.', 'Een uitdaging van 7 dagen.'], goal: 1, measure: (f, since) => f.challengesDone.filter((c) => c.at >= since.slice(0, 10)).length, cta: CTA.progress }),
    // Final chapter challenges
    T({ id: 'boss1', emoji: '🏁', title: ['Chapter challenge: three dinners', 'Hoofdstukuitdaging: drie keer koken'], desc: ['Cook three dinners to finish The First Kitchen.', 'Kook drie keer om De Eerste Keuken af te ronden.'], goal: 3, measure: (f, since) => cooks(f, since).length, cta: CTA.fromStock }),
    T({ id: 'boss2', emoji: '🏁', title: ['Chapter challenge: a week without waste', 'Hoofdstukuitdaging: een week niets weggooien'], desc: ['Seven days with nothing thrown away, cooking on 3 of them.', 'Zeven dagen niets weggooien, en op 3 daarvan koken.'], goal: 7, measure: (f, since) => { const last = [since, ...at(since)(f.events).filter((e) => e.type === 'discard').map((e) => e.at)].sort().pop()!; const days = Math.min(7, Math.floor((Date.parse(f.now) - Date.parse(last)) / 86_400_000)); return cookDays(f, last) >= 3 ? days : Math.min(days, 6); }, cta: CTA.fromStock }),
    T({ id: 'boss3', emoji: '🏁', title: ['Chapter challenge: eight dinners', 'Hoofdstukuitdaging: acht keer koken'], desc: ['Eight home-cooked dinners. Take your time.', 'Acht keer zelf koken. Neem je tijd.'], goal: 8, measure: (f, since) => cooks(f, since).length, cta: CTA.plan }),
    T({ id: 'boss4', emoji: '🏁', title: ['Chapter challenge: three new recipes', 'Hoofdstukuitdaging: drie nieuwe recepten'], desc: ['Three recipes you’ve never cooked.', 'Drie recepten die je nog nooit kookte.'], goal: 3, measure: (f, since) => cooks(f, since).filter((e) => e.parts.some((p) => p.key === 'new')).length, cta: CTA.recipes }),
    T({ id: 'boss5', emoji: '🏁', title: ['Chapter challenge: five balanced meals', 'Hoofdstukuitdaging: vijf gebalanceerde maaltijden'], desc: ['Five meals scoring 70+. Consistency, not perfection.', 'Vijf maaltijden met 70+. Regelmaat, geen perfectie.'], goal: 5, measure: (f, since) => cooks(f, since).filter(balancedMeal).length, cta: CTA.plan }),
    T({ id: 'boss6', emoji: '🏁', title: ['Chapter challenge: a week as planned', 'Hoofdstukuitdaging: een week volgens plan'], desc: ['Five planned dinners cooked in one week.', 'Vijf geplande maaltijden gekookt in één week.'], goal: 5, measure: (f, since) => bestWeek(cooks(f, since).filter((e) => e.planned), (e) => e.date), cta: CTA.plan }),
    T({ id: 'boss7', emoji: '👑', title: ['Final challenge: two challenges', 'Eindopdracht: twee uitdagingen'], desc: ['Finish two 7-day challenges.', 'Voltooi twee uitdagingen van 7 dagen.'], goal: 2, measure: (f, since) => f.challengesDone.filter((c) => c.at >= since.slice(0, 10)).length, cta: CTA.progress }),
  ].map((t) => [t.id, t]),
);

export interface Reward { kind: 'decor' | 'skin' | 'stage' | 'collection' | 'badge'; id: string; emoji: string; title: Txt }

export const CHAPTERS: {
  id: string; emoji: string; title: Txt; intro: Txt; env: string; pool: string[]; bonus: string[]; boss: string; milestone: Reward; rewards: Reward[];
}[] = [
  { id: 'first-kitchen', emoji: '🏠', env: 'tiles', title: ['The First Kitchen', 'De Eerste Keuken'], intro: ['Every kitchen starts with a few groceries and one good dinner. Learn the basics: stock, recipes, a plan.', 'Elke keuken begint met wat boodschappen en één goed avondeten. Leer de basis: voorraad, recepten, een planning.'], pool: ['add5', 'save1', 'cook1', 'plan1', 'used1', 'rate1'], bonus: ['receipt1'], boss: 'boss1', milestone: { kind: 'decor', id: 'herbs', emoji: '🪴', title: ['Herb pot', 'Kruidenpotje'] }, rewards: [{ kind: 'stage', id: 'apron', emoji: '🧑‍🍳', title: ['Pip gets an apron', 'Pip krijgt een schort'] }, { kind: 'skin', id: 'tomato', emoji: '🍅', title: ['Tomato Pip', 'Tomaat-Pip'] }] },
  { id: 'ingredient-explorer', emoji: '🧺', env: 'market', title: ['The Ingredient Explorer', 'De Ingrediëntenontdekker'], intro: ['Get to know what’s in your kitchen: try new ingredients and use things before they go off.', 'Leer kennen wat er in je keuken ligt: probeer nieuwe ingrediënten en gebruik dingen voor ze bederven.'], pool: ['newIngr3', 'rescue3', 'fromStock1', 'open1', 'leftover1', 'freeze1'], bonus: ['voiceList'], boss: 'boss2', milestone: { kind: 'decor', id: 'basket', emoji: '🧺', title: ['Market basket', 'Marktmand'] }, rewards: [{ kind: 'skin', id: 'lemon', emoji: '🍋', title: ['Lemon Pip', 'Citroen-Pip'] }, { kind: 'collection', id: 'useitup', emoji: '🥕', title: ['Use-it-up recipes', 'Opmaakrecepten'] }] },
  { id: 'home-cook', emoji: '🍳', env: 'home', title: ['The Home Cook', 'De Thuiskok'], intro: ['Make cooking a habit: follow your plan, cook a few days in a row, and enjoy the favourites.', 'Maak koken een gewoonte: volg je planning, kook een paar dagen op rij en geniet van je favorieten.'], pool: ['planned3', 'week5', 'streak3', 'loved3', 'eatLeftover', 'cook6'], bonus: ['weekend'], boss: 'boss3', milestone: { kind: 'decor', id: 'pan', emoji: '🍳', title: ['Cast-iron pan', 'Gietijzeren pan'] }, rewards: [{ kind: 'stage', id: 'hat', emoji: '👨‍🍳', title: ['Pip earns a chef’s hat', 'Pip verdient een koksmuts'] }, { kind: 'skin', id: 'aubergine', emoji: '🍆', title: ['Aubergine Pip', 'Aubergine-Pip'] }] },
  { id: 'recipe-adventurer', emoji: '🧭', env: 'world', title: ['The Recipe Adventurer', 'De Receptavonturier'], intro: ['Explore: new cuisines, new recipes, and a library of dishes you love.', 'Op ontdekking: nieuwe keukens, nieuwe recepten en een verzameling gerechten die je lekker vindt.'], pool: ['newCuisine', 'newRecipe', 'save5', 'ownRecipe', 'cuisines3', 'rate3'], bonus: ['cookMine'], boss: 'boss4', milestone: { kind: 'decor', id: 'spices', emoji: '🌶️', title: ['Spice rack', 'Kruidenrek'] }, rewards: [{ kind: 'skin', id: 'blueberry', emoji: '🫐', title: ['Blueberry Pip', 'Bosbes-Pip'] }, { kind: 'collection', id: 'world', emoji: '🌍', title: ['World tour collection', 'Wereldreis-collectie'] }] },
  { id: 'balanced-kitchen', emoji: '🥗', env: 'garden', title: ['The Balanced Kitchen', 'De Gebalanceerde Keuken'], intro: ['Sustainable habits, not diets: enough protein, plenty of veg, steady weeks. Eating less never scores more.', 'Duurzame gewoontes, geen diëten: genoeg eiwit, veel groente, stabiele weken. Minder eten scoort nooit beter.'], pool: ['protein1', 'balancedDay', 'balanced3', 'veg2', 'steadyWeek', 'fibre2'], bonus: ['plants2'], boss: 'boss5', milestone: { kind: 'decor', id: 'fruit', emoji: '🍎', title: ['Fruit bowl', 'Fruitschaal'] }, rewards: [{ kind: 'skin', id: 'pea', emoji: '🫛', title: ['Pea-pod Pip', 'Peul-Pip'] }, { kind: 'collection', id: 'balanced', emoji: '⚖️', title: ['Balanced plates', 'Gebalanceerde borden'] }] },
  { id: 'confident-chef', emoji: '🔪', env: 'studio', title: ['The Confident Chef', 'De Zelfverzekerde Kok'], intro: ['Plan, shop and cook like it’s nothing: full weeks, quick dinners, nothing wasted.', 'Plannen, boodschappen en koken alsof het niets is: hele weken, snelle maaltijden, niets verspild.'], pool: ['fullWeek', 'plannedWeek4', 'trip1', 'quick3', 'rescue5', 'cook20'], bonus: ['budget3'], boss: 'boss6', milestone: { kind: 'decor', id: 'knives', emoji: '🔪', title: ['Knife block', 'Messenblok'] }, rewards: [{ kind: 'stage', id: 'scarf', emoji: '🧣', title: ['Pip gets a chef’s scarf', 'Pip krijgt een koksdas'] }, { kind: 'skin', id: 'copper', emoji: '🥘', title: ['Copper Pip', 'Koper-Pip'] }] },
  { id: 'culinary-master', emoji: '👑', env: 'hall', title: ['The Culinary Master', 'De Culinaire Meester'], intro: ['The long game: a big repertoire, a world of cuisines, and years of good food.', 'De lange adem: een groot repertoire, een wereld aan keukens en jaren lekker eten.'], pool: ['distinct30', 'cuisines6', 'rescue25', 'balanced30', 'streak14', 'cook60'], bonus: ['challenge1'], boss: 'boss7', milestone: { kind: 'decor', id: 'whisk', emoji: '🥇', title: ['Golden whisk', 'Gouden garde'] }, rewards: [{ kind: 'skin', id: 'golden', emoji: '✨', title: ['Golden Pip', 'Gouden Pip'] }, { kind: 'badge', id: 'master', emoji: '👑', title: ['Culinary Master', 'Culinaire Meester'] }] },
];

const TASKS_PER_CHAPTER = 5;

export const TRACKS: { id: string; emoji: string; title: Txt; unit: Txt; levels: number[]; value: (f: Facts) => number; cta: TaskDef['cta'] }[] = [
  { id: 'cooking', emoji: '🍳', title: ['Cooking Mastery', 'Kookmeesterschap'], unit: ['meals cooked', 'maaltijden gekookt'], levels: [1, 5, 10, 20, 35, 50, 75, 100], value: (f) => f.entries.length, cta: CTA.fromStock },
  { id: 'nutrition', emoji: '🥗', title: ['Nutrition Journey', 'Voedingsreis'], unit: ['balanced meals', 'gebalanceerde maaltijden'], levels: [1, 3, 7, 15, 25, 40, 60, 90], value: (f) => f.entries.filter(balancedMeal).length, cta: CTA.plan },
  { id: 'waste', emoji: '♻️', title: ['Food Waste Champion', 'Kampioen tegen verspilling'], unit: ['foods rescued', 'producten gered'], levels: [1, 3, 6, 10, 20, 35, 50, 75], value: (f) => f.rescues.length, cta: CTA.fromStock },
  { id: 'explorer', emoji: '🧭', title: ['Recipe Explorer', 'Receptontdekker'], unit: ['different recipes', 'verschillende recepten'], levels: [1, 3, 5, 10, 15, 20, 30, 45], value: (f) => distinct(f.entries.map((e) => e.recipeId)), cta: CTA.recipes },
  { id: 'planning', emoji: '🗓️', title: ['Meal Planning Expert', 'Planningsexpert'], unit: ['planned dinners cooked', 'geplande maaltijden gekookt'], levels: [1, 3, 7, 12, 20, 30, 45, 60], value: (f) => f.entries.filter((e) => e.planned).length, cta: CTA.plan },
];
const TRACK_LEVEL: Txt[] = [['Novice', 'Beginner'], ['Apprentice', 'Leerling'], ['Regular', 'Vaste klant'], ['Skilled', 'Bedreven'], ['Adept', 'Gevorderd'], ['Expert', 'Expert'], ['Master', 'Meester'], ['Legend', 'Legende']];

export const SKINS = [
  { id: 'sprout', emoji: '🌱', title: ['Sprout', 'Spruit'] as Txt, body: '#6FAE7B', leaf: '#3E7C59' },
  { id: 'tomato', emoji: '🍅', title: ['Tomato', 'Tomaat'] as Txt, body: '#E0603E', leaf: '#3E7C59' },
  { id: 'lemon', emoji: '🍋', title: ['Lemon', 'Citroen'] as Txt, body: '#EBC447', leaf: '#5E8C3A' },
  { id: 'aubergine', emoji: '🍆', title: ['Aubergine', 'Aubergine'] as Txt, body: '#7C5BA6', leaf: '#4E7A3A' },
  { id: 'blueberry', emoji: '🫐', title: ['Blueberry', 'Bosbes'] as Txt, body: '#4D74B8', leaf: '#3E7C59' },
  { id: 'pea', emoji: '🫛', title: ['Pea pod', 'Peul'] as Txt, body: '#8CC063', leaf: '#3F7A2E' },
  { id: 'copper', emoji: '🥘', title: ['Copper', 'Koper'] as Txt, body: '#C27445', leaf: '#5B4632' },
  { id: 'golden', emoji: '✨', title: ['Golden', 'Goud'] as Txt, body: '#D4AA3A', leaf: '#8A6A12' },
];

const pref = <T>(db: Db, h: string, key: string, d: T): T => parseJson(db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = '' AND key = ?", h, key)?.value, d);

function gatherFacts(db: Db, h: string): Facts {
  const now = clock.iso();
  const hist = cookHistory(db, h);
  const targets = mealTargets(hist.targets);
  const planned = new Set(db.all<{ b: string }>("SELECT cook_batch_id b FROM meal_slots WHERE household_id = ? AND status = 'cooked' AND cook_batch_id IS NOT NULL", h).map((r) => r.b));
  const entries = hist.entries.map((e) => {
    const r = hist.recipes.get(e.recipeId);
    const n = r?.nutritionPerServing;
    return {
      ...e,
      protein: n?.protein ?? 0,
      fibre: n?.fibre ?? 0,
      vegOk: (r?.health.vegGrams ?? 0) >= targets.veg,
      minutes: r ? r.prep_minutes + r.cook_minutes : 99,
      cuisine: r?.cuisine ?? null,
      rated: hist.inter.get(e.recipeId)?.rating ?? 0,
      vegetarian: !!r?.diet.includes('vegetarian'),
      cost: r?.costPerServing ?? null,
      planned: planned.has(e.batchId),
      mine: !!r && r.origin !== 'builtin',
    };
  });
  const notUndone = 'NOT EXISTS (SELECT 1 FROM inventory_events u WHERE u.reverses_event_id = e.id)';
  const purchases = db.all<{ at: string; productId: string; source: string; batch: string | null }>(`SELECT e.created_at at, e.product_id productId, e.source, e.batch_id batch FROM inventory_events e WHERE e.household_id = ? AND e.type = 'purchase' AND e.product_id IS NOT NULL AND ${notUndone}`, h);
  const events = db.all<{ at: string; type: string; leftover: number }>(`SELECT e.created_at at, e.type, l.is_leftover leftover FROM inventory_events e JOIN inventory_lots l ON l.id = e.lot_id WHERE e.household_id = ? AND e.type IN ('consume','discard','open','freeze','leftover') AND ${notUndone}`, h).map((e) => ({ ...e, leftover: !!e.leftover }));
  const rescues = db.all<{ at: string; productId: string; batch: string | null }>(
    `SELECT MIN(e.created_at) at, e.product_id productId, e.batch_id batch FROM inventory_events e JOIN inventory_lots l ON l.id = e.lot_id
     WHERE e.household_id = ? AND e.type IN ('cook','consume') AND l.is_leftover = 0 AND e.product_id IS NOT NULL AND l.expires_on IS NOT NULL
       AND julianday(l.expires_on) - julianday(substr(e.created_at, 1, 10)) BETWEEN 0 AND 2 AND ${notUndone}
     GROUP BY e.product_id, COALESCE(e.batch_id, e.id)`,
    h,
  );
  const cookIngredients = new Map(db.all<{ b: string; n: number }>(`SELECT e.batch_id b, COUNT(DISTINCT e.product_id) n FROM inventory_events e WHERE e.household_id = ? AND e.type = 'cook' AND e.batch_id IS NOT NULL AND ${notUndone} GROUP BY e.batch_id`, h).map((r) => [r.b, r.n]));
  const inter = db.get<{ saved: number; rated: number }>('SELECT COALESCE(SUM(saved), 0) saved, COUNT(rating) rated FROM recipe_interactions WHERE household_id = ?', h)!;
  const own = db.get<{ n: number }>('SELECT COUNT(*) n FROM recipes WHERE household_id = ?', h)!.n;
  const slots = db.all<{ date: string; status: string }>("SELECT date, status FROM meal_slots WHERE household_id = ? AND meal = 'dinner' AND recipe_id IS NOT NULL AND status != 'skipped'", h);
  const trips = db.all<{ at: string }>(`SELECT MIN(e.created_at) at FROM inventory_events e WHERE e.household_id = ? AND e.type = 'purchase' AND e.source = 'shopping_list' AND ${notUndone} GROUP BY COALESCE(e.batch_id, e.id)`, h).map((r) => r.at);

  // Feasibility: only checked when a task needs it.
  const memo = <T>(fn: () => T) => { let v: T | undefined; let done = false; return () => (done ? v! : ((done = true), (v = fn()))); };
  const matches = memo(() => { try { return searchRecipes(db, h, { limit: 60 }); } catch { return []; } });
  const cooked = new Set(entries.map((e) => e.cuisine));
  const feasible: Facts['feasible'] = {
    expiringSoon: memo(() => !!db.get("SELECT 1 FROM inventory_lots WHERE household_id = ? AND status = 'active' AND is_leftover = 0 AND quantity > 0 AND expires_on IS NOT NULL AND expires_on <= ?", h, addDays(clock.today(), 5))),
    cookableNow: memo(() => matches().some((m) => m.matchPct >= 0.6)),
    hasLoved: memo(() => [...hist.inter.values()].some((i: any) => (i.rating ?? 0) >= 4)),
    hasLeftovers: memo(() => !!db.get("SELECT 1 FROM inventory_lots WHERE household_id = ? AND status = 'active' AND is_leftover = 1 AND quantity > 0", h) || events.some((e) => e.type === 'leftover')),
    newCuisine: memo(() => matches().some((m) => m.recipe.cuisine && !cooked.has(m.recipe.cuisine))),
    proteinPossible: memo(() => matches().some((m) => (m.recipe.nutritionPerServing?.protein ?? 0) >= targets.protein)),
  };
  return {
    now, entries, purchases, events, rescues, cookIngredients, saved: inter.saved, own, rated: inter.rated, slots, trips,
    challengesDone: pref(db, h, 'challengesDone', [] as { id: string; at: string }[]), proteinTarget: Math.round(targets.protein), fibreTarget: Math.round(targets.fibre), feasible,
  };
}

/** Pick a chapter's tasks: ones you can do now first, in the chapter's order. */
function pickTasks(f: Facts, pool: string[], n: number, exclude: string[] = []) {
  const ok = pool.filter((id) => !exclude.includes(id));
  const can = (id: string) => !TASKS[id].feasible || TASKS[id].feasible!(f);
  return [...ok.filter(can), ...ok.filter((id) => !can(id))].slice(0, n);
}

interface ChapterRow { chapter: number; unlocked_at: string; tasks: string; bonus: string; boss_since: string | null; completed_at: string | null; celebrated: number }
const rowsOf = (db: Db, h: string) => db.all<ChapterRow>('SELECT * FROM journey_chapters WHERE household_id = ? ORDER BY chapter', h);

export interface NewNode { id: string; kind: string; xp: number; title: string; title_nl: string; emoji: string }

/**
 * Check every open node against what actually happened and record the ones that are done (once).
 * Returns what was newly completed, for the "you moved forward" moment.
 */
export function evaluateJourney(db: Db, h: string): NewNode[] {
  const f = gatherFacts(db, h);
  const rules = xpRules(db, h);
  const done = new Set(db.all<{ node_id: string }>('SELECT node_id FROM journey_nodes WHERE household_id = ?', h).map((r) => r.node_id));
  const fresh: NewNode[] = [];
  const complete = (id: string, kind: 'task' | 'milestone' | 'boss' | 'bonus' | 'track', xp: number, title: Txt, emoji: string) => {
    if (done.has(id)) return;
    const r = db.run('INSERT OR IGNORE INTO journey_nodes (household_id, node_id, kind, xp, completed_at) VALUES (?, ?, ?, ?, ?)', h, id, kind, xp, f.now);
    done.add(id);
    if (r.changes) fresh.push({ id, kind, xp, title: title[0], title_nl: title[1], emoji });
  };
  if (!rowsOf(db, h).length) unlockChapter(db, h, f, 0);

  for (let guard = 0; guard < CHAPTERS.length; guard++) {
    const rows = rowsOf(db, h);
    const row = rows.find((r) => !r.completed_at);
    if (!row) break;
    const ch = CHAPTERS[row.chapter];
    const prefix = `c${row.chapter + 1}`;
    const tasks = parseJson<string[]>(row.tasks, []);
    for (const id of tasks) {
      const t = TASKS[id];
      if (t && t.measure(f, t.scope === 'ever' ? '' : row.unlocked_at) >= t.goal) complete(`${prefix}:${id}`, 'task', rules.journeyTask, t.title, t.emoji);
    }
    for (const id of parseJson<string[]>(row.bonus, [])) {
      const t = TASKS[id];
      if (t && t.measure(f, row.unlocked_at) >= t.goal) complete(`${prefix}:${id}`, 'bonus', rules.journeyBonus, t.title, t.emoji);
    }
    const tasksDone = tasks.filter((id) => done.has(`${prefix}:${id}`)).length;
    if (tasksDone >= Math.ceil(tasks.length / 2)) complete(`${prefix}:milestone`, 'milestone', rules.journeyMilestone, ch.milestone.title, ch.milestone.emoji);
    if (tasksDone < tasks.length) break;
    let since = row.boss_since;
    if (!since) {
      since = f.now;
      db.run('UPDATE journey_chapters SET boss_since = ? WHERE household_id = ? AND chapter = ?', since, h, row.chapter);
    }
    const boss = TASKS[ch.boss];
    if (boss.measure(f, since) < boss.goal) break;
    complete(`${prefix}:boss`, 'boss', rules.journeyBoss, boss.title, boss.emoji);
    db.run('UPDATE journey_chapters SET completed_at = ? WHERE household_id = ? AND chapter = ?', f.now, h, row.chapter);
    if (row.chapter + 1 < CHAPTERS.length) unlockChapter(db, h, f, row.chapter + 1);
  }

  for (const t of TRACKS) {
    const v = t.value(f);
    t.levels.forEach((need, i) => {
      if (v >= need) complete(`track:${t.id}:${i + 1}`, 'track', rules.trackLevel + 5 * i, [`${t.title[0]}: ${TRACK_LEVEL[i][0]}`, `${t.title[1]}: ${TRACK_LEVEL[i][1]}`], t.emoji);
    });
  }
  return fresh;
}

function unlockChapter(db: Db, h: string, f: Facts, chapter: number) {
  const ch = CHAPTERS[chapter];
  db.run(
    'INSERT OR IGNORE INTO journey_chapters (household_id, chapter, unlocked_at, tasks, bonus) VALUES (?, ?, ?, ?, ?)',
    h, chapter, f.now, JSON.stringify(pickTasks(f, ch.pool, TASKS_PER_CHAPTER)), JSON.stringify(ch.bonus),
  );
}

/** Swap an open task that doesn't fit right now for another one from the same chapter. */
export function swapTask(db: Db, h: string, nodeId: string) {
  const [prefix, id] = nodeId.split(':');
  const chapter = Number(prefix.slice(1)) - 1;
  const row = rowsOf(db, h).find((r) => r.chapter === chapter && !r.completed_at);
  if (!row) throw new AppError(400, 'journey', 'That chapter is not open');
  if (db.get('SELECT 1 FROM journey_nodes WHERE household_id = ? AND node_id = ?', h, nodeId)) throw new AppError(400, 'journey', 'That task is already done');
  const tasks = parseJson<string[]>(row.tasks, []);
  const i = tasks.indexOf(id);
  if (i < 0) throw new AppError(404, 'journey', 'Unknown task');
  const f = gatherFacts(db, h);
  const swapped = pref<string[]>(db, h, 'journeySwapped', []);
  const [next] = pickTasks(f, CHAPTERS[chapter].pool, 1, [...tasks, ...swapped]);
  if (!next) throw new AppError(409, 'journey', 'No other task available in this chapter');
  tasks[i] = next;
  db.run('UPDATE journey_chapters SET tasks = ? WHERE household_id = ? AND chapter = ?', JSON.stringify(tasks), h, chapter);
  db.run("INSERT INTO preferences (household_id, user_id, key, value) VALUES (?, '', 'journeySwapped', ?) ON CONFLICT(household_id, user_id, key) DO UPDATE SET value = excluded.value", h, JSON.stringify([...swapped, id]));
  return { replaced: id, with: next };
}

/** Title and emoji for a stored node id (for toasts and history). */
export function describeNode(id: string): { title: string; title_nl: string; emoji: string } {
  const track = id.match(/^track:(\w+):(\d+)$/);
  if (track) {
    const t = TRACKS.find((x) => x.id === track[1]);
    const lvl = TRACK_LEVEL[Number(track[2]) - 1];
    if (t && lvl) return { title: `${t.title[0]}: ${lvl[0]}`, title_nl: `${t.title[1]}: ${lvl[1]}`, emoji: t.emoji };
  }
  const m = id.match(/^c(\d+):(\w+)$/);
  const ch = m ? CHAPTERS[Number(m[1]) - 1] : null;
  if (ch && m) {
    if (m[2] === 'milestone') return { title: ch.milestone.title[0], title_nl: ch.milestone.title[1], emoji: ch.milestone.emoji };
    const t = TASKS[m[2] === 'boss' ? ch.boss : m[2]];
    if (t) return { title: t.title[0], title_nl: t.title[1], emoji: t.emoji };
  }
  return { title: id, title_nl: id, emoji: '⭐' };
}

export function markCelebrated(db: Db, h: string) {
  db.run('UPDATE journey_nodes SET celebrated = 1 WHERE household_id = ? AND celebrated = 0', h);
  db.run('UPDATE journey_chapters SET celebrated = 1 WHERE household_id = ? AND completed_at IS NOT NULL AND celebrated = 0', h);
}

export function setCompanion(db: Db, h: string, patch: { skin?: string; name?: string }) {
  const cur = pref(db, h, 'companion', { skin: 'sprout', name: 'Pip' });
  const unlocked = unlockedSkins(db, h);
  if (patch.skin && !unlocked.includes(patch.skin)) throw new AppError(403, 'journey', 'That look is still locked');
  const next = { ...cur, ...patch };
  db.run("INSERT INTO preferences (household_id, user_id, key, value) VALUES (?, '', 'companion', ?) ON CONFLICT(household_id, user_id, key) DO UPDATE SET value = excluded.value", h, JSON.stringify(next));
  return next;
}

const completedChapters = (db: Db, h: string) => rowsOf(db, h).filter((r) => r.completed_at).map((r) => r.chapter);
function unlockedSkins(db: Db, h: string) {
  const skins = ['sprout'];
  for (const c of completedChapters(db, h)) for (const r of CHAPTERS[c].rewards) if (r.kind === 'skin') skins.push(r.id);
  return skins;
}

/** The whole journey as the Progress screen shows it. Evaluates first, so it's always current. */
export function journey(db: Db, h: string) {
  evaluateJourney(db, h);
  const f = gatherFacts(db, h);
  const nodes = new Map(db.all<{ node_id: string; kind: string; xp: number; completed_at: string; celebrated: number }>('SELECT * FROM journey_nodes WHERE household_id = ?', h).map((n) => [n.node_id, n]));
  const rules = xpRules(db, h);
  const rows = rowsOf(db, h);
  const lang = (t: Txt) => ({ title: t[0], title_nl: t[1] });
  const node = (id: string, t: TaskDef, kind: 'task' | 'bonus' | 'boss', since: string | null, open: boolean, xp: number) => {
    const n = nodes.get(id);
    const progress = n ? t.goal : since != null ? Math.min(t.goal, t.measure(f, t.scope === 'ever' ? '' : since)) : 0;
    const feasible = !t.feasible || t.feasible(f);
    return {
      id, kind, emoji: t.emoji, ...lang(t.title), desc: t.desc[0], desc_nl: t.desc[1], goal: t.goal, progress, xp,
      done: !!n, completedAt: n?.completed_at ?? null, fresh: n ? !n.celebrated : false, open, feasible,
      hint: !feasible && t.hint ? { en: t.hint[0], nl: t.hint[1] } : null, cta: { href: t.cta.href, label: t.cta.label[0], label_nl: t.cta.label[1] },
      state: '' as string,
    };
  };

  const chapters = CHAPTERS.map((ch, i) => {
    const row = rows.find((r) => r.chapter === i);
    const prefix = `c${i + 1}`;
    const unlocked = !!row;
    const taskIds = row ? parseJson<string[]>(row.tasks, []) : pickTasks(f, ch.pool, TASKS_PER_CHAPTER);
    const tasks = taskIds.map((id) => node(`${prefix}:${id}`, TASKS[id], 'task', row?.unlocked_at ?? null, unlocked, rules.journeyTask));
    const tasksDone = tasks.filter((t) => t.done).length;
    const bonus = (row ? parseJson<string[]>(row.bonus, []) : ch.bonus).map((id) => node(`${prefix}:${id}`, TASKS[id], 'bonus', row?.unlocked_at ?? null, unlocked, rules.journeyBonus));
    const boss = node(`${prefix}:boss`, TASKS[ch.boss], 'boss', row?.boss_since ?? null, !!row?.boss_since, rules.journeyBoss);
    const half = Math.ceil(tasks.length / 2);
    const ms = nodes.get(`${prefix}:milestone`);
    const milestone = {
      id: `${prefix}:milestone`, kind: 'milestone', emoji: ch.milestone.emoji, title: `${ch.milestone.title[0]}`, title_nl: ch.milestone.title[1], desc: `Reward chest: complete ${half} tasks`, desc_nl: `Beloningskist: voltooi ${half} taken`,
      goal: half, progress: Math.min(half, tasksDone), xp: rules.journeyMilestone, done: !!ms, completedAt: ms?.completed_at ?? null, fresh: ms ? !ms.celebrated : false, open: unlocked, feasible: true, hint: null, cta: null as any, state: '', reward: ch.milestone,
    };
    // Path order: three tasks, the chest, the rest, then the chapter's final challenge. The bonus sits beside the path.
    const path = [...tasks.slice(0, half), milestone, ...tasks.slice(half), boss];
    return {
      n: i + 1, id: ch.id, emoji: ch.emoji, env: ch.env, ...lang(ch.title), intro: ch.intro[0], intro_nl: ch.intro[1],
      unlocked, unlockedAt: row?.unlocked_at ?? null, completed: !!row?.completed_at, completedAt: row?.completed_at ?? null, fresh: !!row?.completed_at && !row.celebrated,
      tasksDone, tasksTotal: tasks.length, path, bonus, rewards: ch.rewards,
    };
  });

  // States: done, current (the one to do next), available, locked, bonus.
  let current: any = null;
  for (const ch of chapters) {
    for (const n of ch.path) {
      if (n.done) n.state = 'completed';
      else if (!ch.unlocked || !n.open) n.state = 'locked';
      else if (n.kind === 'milestone') n.state = 'locked';
      else n.state = 'available';
    }
    for (const b of ch.bonus) b.state = b.done ? 'completed' : ch.unlocked ? 'bonus' : 'locked';
  }
  const open = chapters.find((c) => c.unlocked && !c.completed);
  if (open) {
    const avail = open.path.filter((n) => n.state === 'available');
    // The next step: something you can do now, closest to done, in path order.
    const pick = avail.filter((n) => n.feasible).sort((a, b) => b.progress / b.goal - a.progress / a.goal)[0] ?? avail[0];
    const firstOpen = avail[0];
    if (firstOpen) firstOpen.state = 'current';
    current = pick ? { ...pick, chapter: open.n } : null;
  }

  const unlockedSkinIds = unlockedSkins(db, h);
  const companion = pref(db, h, 'companion', { skin: 'sprout', name: 'Pip' });
  const finished = completedChapters(db, h);
  const stages = ['seedling', ...CHAPTERS.flatMap((c, i) => (finished.includes(i) ? c.rewards.filter((r) => r.kind === 'stage').map((r) => r.id) : []))];
  const tracks = TRACKS.map((t) => {
    const v = t.value(f);
    const level = t.levels.filter((need) => v >= need).length;
    return {
      id: t.id, emoji: t.emoji, ...lang(t.title), unit: t.unit[0], unit_nl: t.unit[1], value: v, level, max: t.levels.length,
      levelName: level ? TRACK_LEVEL[level - 1][0] : 'Not started', levelName_nl: level ? TRACK_LEVEL[level - 1][1] : 'Nog niet begonnen',
      next: t.levels[level] ?? null, prev: t.levels[level - 1] ?? 0,
      nodes: t.levels.map((need, i) => ({ id: `track:${t.id}:${i + 1}`, need, name: TRACK_LEVEL[i][0], name_nl: TRACK_LEVEL[i][1], xp: rules.trackLevel + 5 * i, done: nodes.has(`track:${t.id}:${i + 1}`), fresh: !!nodes.get(`track:${t.id}:${i + 1}`) && !nodes.get(`track:${t.id}:${i + 1}`)!.celebrated })),
      cta: { href: t.cta.href, label: t.cta.label[0], label_nl: t.cta.label[1] },
    };
  });
  const decor = CHAPTERS.map((c, i) => ({ ...c.milestone, unlocked: nodes.has(`c${i + 1}:milestone`) }));
  const collections = CHAPTERS.flatMap((c, i) => c.rewards.filter((r) => r.kind === 'collection').map((r) => ({ ...r, unlocked: finished.includes(i), chapter: i + 1 })));
  const fresh = [...nodes.values()].filter((n) => !n.celebrated).map((n) => n.node_id);
  return {
    chapters,
    current,
    tracks,
    companion: { ...companion, stage: stages.length - 1, stages, skins: SKINS.map((s) => ({ ...s, unlocked: unlockedSkinIds.includes(s.id) })) },
    decor,
    collections,
    fresh,
    freshXp: [...nodes.values()].filter((n) => !n.celebrated).reduce((s, n) => s + n.xp, 0),
    chapterDone: chapters.filter((c) => c.fresh).map((c) => c.n),
    xp: [...nodes.values()].reduce((s, n) => s + n.xp, 0),
    completedNodes: nodes.size,
  };
}

/** Recipes in an unlocked reward collection. */
export function collection(db: Db, h: string, id: string) {
  const all = searchRecipes(db, h, { limit: 200 });
  const take = (xs: typeof all) => xs.slice(0, 8).map((m) => ({ id: m.recipe.id, title: m.recipe.title, emoji: m.recipe.emoji, color: m.recipe.color, image_url: m.recipe.image_url, minutes: m.recipe.prep_minutes + m.recipe.cook_minutes, matchPct: m.matchPct }));
  if (id === 'useitup') return take([...all].sort((a, b) => b.usesExpiring.length - a.usesExpiring.length || b.matchPct - a.matchPct));
  if (id === 'world') {
    const seen = new Set<string>();
    return take(all.filter((m) => m.recipe.cuisine && !seen.has(m.recipe.cuisine) && seen.add(m.recipe.cuisine)));
  }
  if (id === 'balanced') return take([...all].sort((a, b) => b.recipe.health.score - a.recipe.health.score));
  throw new AppError(404, 'journey', 'Unknown collection');
}
