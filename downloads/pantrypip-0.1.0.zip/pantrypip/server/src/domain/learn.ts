// What PantryPip learns from behaviour: preferences derived from the last 90 days of cooking, swapping,
// rating and wasting. Nothing is stored: insights fade when behaviour changes, and each one can be
// switched off (the planner then ignores it).
import type { Db } from '../db/db.ts';
import { parseJson } from '../db/db.ts';
import { clock, addDays } from '../clock.ts';
import type { Recipe } from './recipes.ts';
import { displayName, getProduct } from './products.ts';

export interface Insight {
  id: string;
  text: string;
  text_nl: string;
  /** What it changes in the planner. */
  effect: string;
  effect_nl: string;
  strength: number; // 0..1
  active: boolean;
}

export interface LearnedProfile {
  insights: Insight[];
  quickBias: number; // bonus for ≤ 30 min meals
  proteinBonus: Record<string, number>;
  cuisineBonus: Record<string, number>;
  highProtein: number; // bonus per 10 g protein per serving above 25 g
  wasted: Set<string>; // product ids that are often thrown away
}

const PROTEIN_LABEL: Record<string, [string, string]> = {
  chicken: ['chicken', 'kip'], beef: ['beef', 'rundvlees'], pork: ['pork', 'varkensvlees'], fish: ['fish', 'vis'], eggs: ['egg dishes', 'eiergerechten'], plant: ['plant protein (beans, lentils, tofu)', 'plantaardige eiwitten (bonen, linzen, tofu)'], veg: ['vegetable dishes', 'groentegerechten'],
};

export function dismissedInsights(db: Db, householdId: string): string[] {
  return parseJson(db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = '' AND key = 'dismissedInsights'", householdId)?.value, []);
}

export function learnedProfile(db: Db, householdId: string, recipes: Map<string, Recipe>): LearnedProfile {
  const since = addDays(clock.today(), -90);
  const off = new Set(dismissedInsights(db, householdId));
  const cooks = db.all<{ recipe_id: string }>('SELECT recipe_id FROM cook_log WHERE household_id = ? AND created_at >= ?', householdId, since)
    .map((c) => recipes.get(c.recipe_id))
    .filter((r): r is Recipe => !!r);
  const n = cooks.length;
  const profile: LearnedProfile = { insights: [], quickBias: 0, proteinBonus: {}, cuisineBonus: {}, highProtein: 0, wasted: new Set() };
  const add = (i: Omit<Insight, 'active'>, apply: () => void) => {
    const active = !off.has(i.id);
    profile.insights.push({ ...i, strength: Math.round(i.strength * 100) / 100, active });
    if (active) apply();
  };

  if (n >= 5) {
    const quick = cooks.filter((r) => r.prep_minutes + r.cook_minutes <= 30).length / n;
    if (quick >= 0.65) {
      add({ id: 'quick', strength: quick, text: `You usually cook meals under 30 minutes (${Math.round(quick * 100)}%).`, text_nl: `Je kookt meestal maaltijden onder de 30 minuten (${Math.round(quick * 100)}%).`, effect: 'Quick recipes get a boost.', effect_nl: 'Snelle recepten krijgen voorrang.' }, () => (profile.quickBias = 0.3 * quick));
    }
    const byProtein = new Map<string, number>();
    for (const r of cooks) byProtein.set(r.protein, (byProtein.get(r.protein) ?? 0) + 1);
    for (const [p, c] of byProtein) {
      const share = c / n;
      if (share >= 0.35 && c >= 3) {
        const [en, nl] = PROTEIN_LABEL[p] ?? [p, p];
        add({ id: `protein:${p}`, strength: share, text: `You often choose ${en} (${c} of your last ${n} meals).`, text_nl: `Je kiest vaak ${nl} (${c} van je laatste ${n} maaltijden).`, effect: `More ${en} in your plans, still with variety.`, effect_nl: `Vaker ${nl} in je planning, met afwisseling.` }, () => (profile.proteinBonus[p] = 0.25 * share));
      }
    }
    const byCuisine = new Map<string, number>();
    for (const r of cooks) if (r.cuisine) byCuisine.set(r.cuisine, (byCuisine.get(r.cuisine) ?? 0) + 1);
    const [topCuisine, tc] = [...byCuisine].sort((a, b) => b[1] - a[1])[0] ?? [null, 0];
    if (topCuisine && tc / n >= 0.3 && tc >= 3) {
      add({ id: `cuisine:${topCuisine}`, strength: tc / n, text: `${topCuisine} food is your favourite cuisine lately.`, text_nl: `De ${topCuisine.toLowerCase()} keuken is je favoriet van de laatste tijd.`, effect: `${topCuisine} recipes get a small boost.`, effect_nl: `Recepten uit die keuken krijgen een klein voordeel.` }, () => (profile.cuisineBonus[topCuisine] = 0.15));
    }
    const avgProtein = cooks.reduce((s, r) => s + (r.nutritionPerServing?.protein ?? 0), 0) / n;
    if (avgProtein >= 30) {
      add({ id: 'high-protein', strength: Math.min(1, avgProtein / 45), text: `You prefer high-protein meals (≈${Math.round(avgProtein)} g per serving).`, text_nl: `Je kiest graag eiwitrijk (≈${Math.round(avgProtein)} g per portie).`, effect: 'High-protein recipes get a boost.', effect_nl: 'Eiwitrijke recepten krijgen voorrang.' }, () => (profile.highProtein = 0.08));
    }
  }

  const loved = db.all<{ recipe_id: string; rating: number; cooked_count: number }>('SELECT recipe_id, rating, cooked_count FROM recipe_interactions WHERE household_id = ? AND rating >= 4 AND cooked_count >= 2 ORDER BY rating DESC, cooked_count DESC LIMIT 3', householdId);
  if (loved.length) {
    const titles = loved.map((l) => recipes.get(l.recipe_id)?.title).filter(Boolean) as string[];
    if (titles.length) add({ id: 'loved', strength: 1, text: `Consistently rated highly: ${titles.join(', ')}.`, text_nl: `Altijd hoog beoordeeld: ${titles.join(', ')}.`, effect: 'These come back regularly (ratings already count).', effect_nl: 'Deze komen regelmatig terug (sterren tellen al mee).' }, () => {});
  }

  const swapped = db.all<{ recipe_id: string; swapped_count: number }>('SELECT recipe_id, swapped_count FROM recipe_interactions WHERE household_id = ? AND swapped_count >= 2 ORDER BY swapped_count DESC LIMIT 3', householdId);
  if (swapped.length) {
    const titles = swapped.map((s) => recipes.get(s.recipe_id)?.title).filter(Boolean) as string[];
    if (titles.length) add({ id: 'swapped', strength: Math.min(1, swapped[0].swapped_count / 4), text: `You often swap out: ${titles.join(', ')}.`, text_nl: `Je wisselt vaak weg: ${titles.join(', ')}.`, effect: 'They’re suggested less often.', effect_nl: 'Die worden minder vaak voorgesteld.' }, () => {});
  }

  const waste = db.all<{ product_id: string; n: number }>(
    `SELECT e.product_id, COUNT(*) n FROM inventory_events e WHERE e.household_id = ? AND e.type = 'discard' AND e.created_at >= ? AND e.product_id IS NOT NULL
       AND NOT EXISTS (SELECT 1 FROM inventory_events u WHERE u.reverses_event_id = e.id) GROUP BY e.product_id HAVING n >= 2 ORDER BY n DESC LIMIT 4`,
    householdId,
    since,
  );
  for (const w of waste) {
    const p = getProduct(db, w.product_id);
    if (!p) continue;
    add({ id: `waste:${p.id}`, strength: Math.min(1, w.n / 4), text: `${displayName(p, 'en')} is often thrown away (${w.n}× in 3 months).`, text_nl: `${displayName(p, 'nl')} wordt vaak weggegooid (${w.n}× in 3 maanden).`, effect: 'Meals that use it up get priority when you have it.', effect_nl: 'Maaltijden die het opmaken krijgen voorrang als je het hebt.' }, () => profile.wasted.add(p.id));
  }
  return profile;
}
