// The inventory ledger. Every quantity change is an append-only event; lot quantities are a
// materialised sum of their events and can be rebuilt from them. Nothing else may write
// inventory_lots.quantity, which is how AI- and voice-driven changes stay auditable.
import { createHash } from 'node:crypto';
import type { Db, Row } from '../db/db.ts';
import { newId } from '../db/db.ts';
import { clock, addDays } from '../clock.ts';
import { AppError, conflict, notFound } from '../errors.ts';
import { getProduct, type Product } from './products.ts';
import { bus } from '../bus.ts';

export type EventType = 'purchase' | 'consume' | 'discard' | 'cook' | 'adjust' | 'transfer' | 'freeze' | 'thaw' | 'leftover' | 'undo' | 'open';
export type EventSource = 'manual' | 'voice' | 'assistant_ai' | 'receipt' | 'barcode' | 'shopping_list' | 'recipe' | 'online_order' | 'device' | 'system' | 'import';

export interface Ctx {
  db: Db;
  householdId: string;
  userId?: string | null;
  source: EventSource;
  batchId: string;
}

export interface Lot {
  id: string;
  household_id: string;
  product_id: string | null;
  label: string | null;
  is_leftover: number;
  recipe_id: string | null;
  location_id: string | null;
  quantity: number;
  unit: string;
  purchased_at: string | null;
  expires_on: string | null;
  expiry_estimated: number;
  opened_at: string | null;
  frozen_at: string | null;
  source: string;
  last_confirmed_at: string;
  unit_price: number | null;
  status: 'active' | 'depleted';
  version: number;
  created_at: string;
}

export interface LedgerEvent {
  id: string;
  lot_id: string;
  product_id: string | null;
  type: EventType;
  delta: number;
  quantity_after: number;
  unit: string;
  source: EventSource;
  reason: string | null;
  batch_id: string | null;
  created_at: string;
}

const EPS = 1e-6;

/**
 * Derive a batch id from a client request id so retries of the same request
 * (double taps, repeated voice submissions, network retries) map to the same batch.
 */
export function batchIdFor(householdId: string, clientRequestId?: string | null): string {
  if (!clientRequestId) return newId('b');
  return 'b_' + createHash('sha256').update(householdId + ':' + clientRequestId).digest('hex').slice(0, 24);
}

export function batchExists(db: Db, batchId: string): boolean {
  // A meal cooked with nothing in stock leaves no ledger events, only a cook log entry.
  return !!db.get('SELECT 1 FROM inventory_events WHERE batch_id = ? LIMIT 1', batchId) || !!db.get('SELECT 1 FROM cook_log WHERE batch_id = ? LIMIT 1', batchId);
}

export function newCtx(db: Db, householdId: string, source: EventSource, opts: { userId?: string | null; clientRequestId?: string | null } = {}): Ctx {
  return { db, householdId, userId: opts.userId ?? null, source, batchId: batchIdFor(householdId, opts.clientRequestId) };
}

export function getLot(db: Db, id: string): Lot | undefined {
  return db.get<Lot>('SELECT * FROM inventory_lots WHERE id = ?', id);
}

function nextSeq(ctx: Ctx): number {
  const r = ctx.db.get<{ n: number }>('SELECT COUNT(*) AS n FROM inventory_events WHERE batch_id = ?', ctx.batchId);
  return r?.n ?? 0;
}

function writeEvent(ctx: Ctx, lot: Lot, e: { type: EventType; delta: number; reason?: string | null; predictedBefore?: number | null; reverses?: string | null; meta?: Row | null }): LedgerEvent {
  const after = round6(lot.quantity + e.delta);
  if (after < -EPS) throw new AppError(422, 'negative_stock', 'Quantity would become negative');
  const now = clock.iso();
  const id = newId('ev');
  const seq = nextSeq(ctx);
  ctx.db.insert('inventory_events', {
    id,
    household_id: ctx.householdId,
    lot_id: lot.id,
    product_id: lot.product_id,
    type: e.type,
    delta: round6(e.delta),
    quantity_after: Math.max(0, after),
    unit: lot.unit,
    source: ctx.source,
    reason: e.reason ?? null,
    predicted_before: e.predictedBefore ?? null,
    batch_id: ctx.batchId,
    reverses_event_id: e.reverses ?? null,
    idempotency_key: `${ctx.batchId}:${seq}`,
    user_id: ctx.userId ?? null,
    meta: e.meta ?? null,
    created_at: now,
  });
  const quantity = Math.max(0, after);
  const status = quantity <= EPS ? 'depleted' : 'active';
  // Every event is a human- or rule-confirmed observation, so it refreshes the confirmation time.
  ctx.db.run(
    'UPDATE inventory_lots SET quantity = ?, status = ?, last_confirmed_at = ?, version = version + 1 WHERE id = ?',
    quantity,
    status,
    now,
    lot.id,
  );
  lot.quantity = quantity;
  lot.status = status;
  lot.version += 1;
  bus.touch(ctx.householdId, 'inventory');
  return ctx.db.get<LedgerEvent>('SELECT * FROM inventory_events WHERE id = ?', id)!;
}

const round6 = (n: number) => Math.round(n * 1e6) / 1e6;

export function locationIdFor(db: Db, householdId: string, kindOrId?: string | null): string | null {
  if (!kindOrId) return null;
  const byId = db.get<{ id: string }>('SELECT id FROM storage_locations WHERE household_id = ? AND id = ?', householdId, kindOrId);
  if (byId) return byId.id;
  const byKind = db.get<{ id: string }>('SELECT id FROM storage_locations WHERE household_id = ? AND (kind = ? OR lower(name) = lower(?)) ORDER BY sort LIMIT 1', householdId, kindOrId, kindOrId);
  return byKind?.id ?? null;
}

function locationKind(db: Db, locationId: string | null): string | null {
  if (!locationId) return null;
  return db.get<{ kind: string }>('SELECT kind FROM storage_locations WHERE id = ?', locationId)?.kind ?? null;
}

export function estimateExpiry(p: Product | undefined, locationKindValue: string | null, from = clock.today()): string | null {
  if (!p) return null;
  const days = locationKindValue === 'freezer' ? (p.freezer_life_days ?? p.shelf_life_days) : p.shelf_life_days;
  return days ? addDays(from, days) : null;
}

export interface AddStockInput {
  productId?: string | null;
  quantity: number;
  unit?: string;
  location?: string | null;
  expiresOn?: string | null;
  label?: string | null;
  isLeftover?: boolean;
  recipeId?: string | null;
  unitPrice?: number | null;
  totalPrice?: number | null;
  packages?: number;
  store?: string | null;
  receiptId?: string | null;
  purchasedAt?: string | null;
  type?: 'purchase' | 'leftover' | 'adjust';
  meta?: Row;
}

/** Add stock as a new lot (one lot per purchase keeps expiry dates and FIFO accurate). */
export function addStock(ctx: Ctx, input: AddStockInput): { lot: Lot; event: LedgerEvent } {
  if (!(input.quantity > 0)) throw new AppError(422, 'invalid_quantity', 'Quantity must be positive');
  const product = input.productId ? getProduct(ctx.db, input.productId) : undefined;
  if (input.productId && !product) throw notFound('Product');
  const locId = locationIdFor(ctx.db, ctx.householdId, input.location ?? product?.default_location ?? 'pantry');
  const kind = locationKind(ctx.db, locId);
  const now = clock.iso();
  const expires = input.expiresOn ?? estimateExpiry(product, kind);
  const lot: Lot = {
    id: newId('lot'),
    household_id: ctx.householdId,
    product_id: product?.id ?? null,
    label: input.label ?? null,
    is_leftover: input.isLeftover ? 1 : 0,
    recipe_id: input.recipeId ?? null,
    location_id: locId,
    quantity: 0,
    unit: input.unit ?? product?.unit ?? 'pcs',
    purchased_at: input.purchasedAt ?? now,
    expires_on: expires,
    expiry_estimated: input.expiresOn ? 0 : 1,
    opened_at: null,
    frozen_at: kind === 'freezer' ? now : null,
    source: ctx.source,
    last_confirmed_at: now,
    unit_price: input.unitPrice ?? (input.totalPrice != null ? input.totalPrice / input.quantity : product?.price != null ? product.price / product.package_size : null),
    status: 'active',
    version: 0,
    created_at: now,
  };
  ctx.db.insert('inventory_lots', lot as any);
  const event = writeEvent(ctx, lot, { type: input.type ?? 'purchase', delta: input.quantity, meta: input.meta ?? null });
  if ((input.type ?? 'purchase') === 'purchase' && product) {
    ctx.db.insert('purchases', {
      id: newId('pu'),
      household_id: ctx.householdId,
      receipt_id: input.receiptId ?? null,
      product_id: product.id,
      quantity: input.quantity,
      packages: input.packages ?? input.quantity / (product.package_size || 1),
      total_price: input.totalPrice ?? null,
      store: input.store ?? null,
      purchased_at: input.purchasedAt ?? now,
      event_id: event.id,
      source: ctx.source,
    });
  }
  return { lot, event };
}

/** Active lots of a product in FIFO order: soonest expiry first, opened first, then oldest. */
export function activeLots(db: Db, householdId: string, productId: string): Lot[] {
  return db.all<Lot>(
    `SELECT * FROM inventory_lots WHERE household_id = ? AND product_id = ? AND status = 'active'
     ORDER BY (opened_at IS NULL), COALESCE(expires_on, '9999-12-31'), created_at`,
    householdId,
    productId,
  );
}

export function productTotal(db: Db, householdId: string, productId: string): number {
  return db.get<{ q: number }>("SELECT COALESCE(SUM(quantity),0) AS q FROM inventory_lots WHERE household_id = ? AND product_id = ? AND status = 'active'", householdId, productId)!.q;
}

export interface DeductInput {
  productId?: string | null;
  lotId?: string | null;
  quantity: number | 'all';
  type: 'consume' | 'discard' | 'cook' | 'adjust';
  reason?: string | null;
  predictedBefore?: number | null;
  meta?: Row;
}

export interface DeductResult {
  requested: number | 'all';
  deducted: number;
  shortfall: number;
  events: LedgerEvent[];
}

/** Remove stock FIFO across lots. Never goes below zero; reports any shortfall instead. */
export function deduct(ctx: Ctx, input: DeductInput): DeductResult {
  let lots: Lot[];
  if (input.lotId) {
    const l = getLot(ctx.db, input.lotId);
    if (!l || l.household_id !== ctx.householdId) throw notFound('Inventory item');
    lots = l.status === 'active' ? [l] : [];
  } else if (input.productId) {
    lots = activeLots(ctx.db, ctx.householdId, input.productId);
  } else throw new AppError(422, 'missing_target', 'Product or lot required');

  let remaining = input.quantity === 'all' ? Infinity : input.quantity;
  if (remaining !== Infinity && !(remaining > 0)) throw new AppError(422, 'invalid_quantity', 'Quantity must be positive');
  const events: LedgerEvent[] = [];
  let deducted = 0;
  for (const lot of lots) {
    if (remaining <= EPS) break;
    const take = Math.min(lot.quantity, remaining);
    if (take <= EPS) continue;
    markOpened(ctx, lot);
    events.push(writeEvent(ctx, lot, { type: input.type, delta: -take, reason: input.reason, predictedBefore: input.predictedBefore, meta: input.meta ?? null }));
    remaining -= take;
    deducted += take;
  }
  return {
    requested: input.quantity,
    deducted: round6(deducted),
    shortfall: input.quantity === 'all' ? 0 : round6(Math.max(0, remaining)),
    events,
  };
}

/**
 * "I opened the milk": open the oldest unopened lot. Recorded as an 'open' event (no quantity change)
 * with the previous state, so undo restores it.
 */
export function openProduct(ctx: Ctx, productId: string): Lot | null {
  const lot = activeLots(ctx.db, ctx.householdId, productId).find((l) => !l.opened_at && !l.is_leftover);
  if (!lot) return null;
  const prev = { openedAt: lot.opened_at, expiresOn: lot.expires_on };
  markOpened(ctx, lot);
  writeEvent(ctx, lot, { type: 'open', delta: 0, meta: { prev } });
  return lot;
}

/** The first use of a lot opens it, which can shorten its estimated shelf life. */
function markOpened(ctx: Ctx, lot: Lot) {
  if (lot.opened_at || !lot.product_id || lot.is_leftover) return;
  const p = getProduct(ctx.db, lot.product_id);
  const now = clock.iso();
  let expires = lot.expires_on;
  const kind = locationKind(ctx.db, lot.location_id);
  if (p?.opened_life_days && kind !== 'freezer') {
    const openedExpiry = addDays(clock.today(), p.opened_life_days);
    if (!expires || openedExpiry < expires) expires = openedExpiry;
  }
  ctx.db.run('UPDATE inventory_lots SET opened_at = ?, expires_on = ? WHERE id = ?', now, expires, lot.id);
  lot.opened_at = now;
  lot.expires_on = expires;
}

/**
 * Set the observed total for a product ("I have 3 eggs left").
 * Records the difference as 'adjust' events plus the prediction that was shown, which trains the predictor.
 * expectedTotal enables optimistic concurrency for absolute edits from the UI.
 */
export function setProductQuantity(
  ctx: Ctx,
  productId: string,
  newTotal: number,
  opts: { expectedTotal?: number | null; predictedBefore?: number | null; location?: string | null; meta?: Row } = {},
): { before: number; after: number; events: LedgerEvent[] } {
  if (newTotal < 0) throw new AppError(422, 'invalid_quantity', 'Quantity cannot be negative');
  const before = productTotal(ctx.db, ctx.householdId, productId);
  if (opts.expectedTotal != null && Math.abs(opts.expectedTotal - before) > EPS) {
    throw conflict('Inventory changed since you loaded it', { current: before });
  }
  const diff = newTotal - before;
  const events: LedgerEvent[] = [];
  if (diff < -EPS) {
    events.push(...deduct(ctx, { productId, quantity: -diff, type: 'adjust', predictedBefore: opts.predictedBefore, meta: opts.meta }).events);
  } else if (diff > EPS) {
    const lots = activeLots(ctx.db, ctx.householdId, productId);
    const target = lots[lots.length - 1];
    if (target) events.push(writeEvent(ctx, target, { type: 'adjust', delta: diff, predictedBefore: opts.predictedBefore, meta: opts.meta ?? null }));
    else events.push(addStock(ctx, { productId, quantity: diff, location: opts.location, type: 'adjust', meta: { ...(opts.meta ?? {}) } }).event);
  } else {
    // No change, but the user confirmed the quantity: refresh confirmation on all lots.
    const now = clock.iso();
    ctx.db.run("UPDATE inventory_lots SET last_confirmed_at = ? WHERE household_id = ? AND product_id = ? AND status = 'active'", now, ctx.householdId, productId);
    const lots = activeLots(ctx.db, ctx.householdId, productId);
    if (lots[0]) events.push(writeEvent(ctx, lots[0], { type: 'adjust', delta: 0, predictedBefore: opts.predictedBefore, meta: { confirm: true, ...(opts.meta ?? {}) } }));
    bus.touch(ctx.householdId, 'inventory');
  }
  return { before, after: newTotal, events };
}

/** Set a single lot's quantity (UI edit on a specific lot), with version check. */
export function setLotQuantity(ctx: Ctx, lotId: string, newQuantity: number, expectedVersion?: number | null): LedgerEvent | null {
  const lot = getLot(ctx.db, lotId);
  if (!lot || lot.household_id !== ctx.householdId) throw notFound('Inventory item');
  if (expectedVersion != null && expectedVersion !== lot.version) throw conflict('Inventory item changed since you loaded it', { current: lot });
  const diff = newQuantity - lot.quantity;
  if (Math.abs(diff) <= EPS) return null;
  if (newQuantity < 0) throw new AppError(422, 'invalid_quantity', 'Quantity cannot be negative');
  return writeEvent(ctx, lot, { type: 'adjust', delta: diff });
}

/** Move a lot to another location. Freezing extends the expiry, thawing shortens it. */
export function moveLot(ctx: Ctx, lotId: string, toLocation: string, opts: { quantity?: number } = {}): { lot: Lot; event: LedgerEvent } {
  let lot = getLot(ctx.db, lotId);
  if (!lot || lot.household_id !== ctx.householdId || lot.status !== 'active') throw notFound('Inventory item');
  const locId = locationIdFor(ctx.db, ctx.householdId, toLocation);
  if (!locId) throw notFound('Storage location');
  // Partial move: split the lot first (deduct from the original, add a new lot with the same metadata).
  if (opts.quantity && opts.quantity < lot.quantity - EPS) {
    writeEvent(ctx, lot, { type: 'transfer', delta: -opts.quantity, meta: { split: true } });
    const copy: Lot = { ...lot, id: newId('lot'), quantity: 0, version: 0, status: 'active', created_at: clock.iso() };
    ctx.db.insert('inventory_lots', copy as any);
    writeEvent(ctx, copy, { type: 'transfer', delta: opts.quantity, meta: { split_from: lot.id } });
    lot = copy;
  }
  const fromKind = locationKind(ctx.db, lot.location_id);
  const toKind = locationKind(ctx.db, locId);
  const p = lot.product_id ? getProduct(ctx.db, lot.product_id) : undefined;
  let type: EventType = 'transfer';
  let expires = lot.expires_on;
  let frozenAt = lot.frozen_at;
  if (toKind === 'freezer' && fromKind !== 'freezer') {
    type = 'freeze';
    frozenAt = clock.iso();
    const days = p?.freezer_life_days ?? (lot.is_leftover ? 90 : 90);
    expires = addDays(clock.today(), days);
  } else if (fromKind === 'freezer' && toKind !== 'freezer') {
    type = 'thaw';
    frozenAt = null;
    expires = addDays(clock.today(), lot.is_leftover ? 2 : Math.min(2, p?.shelf_life_days ?? 2));
  }
  ctx.db.run('UPDATE inventory_lots SET location_id = ?, expires_on = ?, frozen_at = ?, expiry_estimated = 1 WHERE id = ?', locId, expires, frozenAt, lot.id);
  const updated = getLot(ctx.db, lot.id)!;
  const event = writeEvent(ctx, updated, { type, delta: 0, meta: { from: lot.location_id, to: locId } });
  return { lot: getLot(ctx.db, lot.id)!, event };
}

/** Reverse every event of a batch (undo a command, a receipt, a cooked meal). Idempotent. */
export function undoBatch(ctx: Ctx, batchId: string): LedgerEvent[] {
  const events = ctx.db.all<LedgerEvent & { reverses_event_id: string | null; meta: string | null }>(
    "SELECT * FROM inventory_events WHERE household_id = ? AND batch_id = ? AND type != 'undo' ORDER BY rowid DESC",
    ctx.householdId,
    batchId,
  );
  const out: LedgerEvent[] = [];
  for (const e of events) {
    const already = ctx.db.get('SELECT 1 FROM inventory_events WHERE reverses_event_id = ?', e.id);
    if (already) continue;
    const lot = getLot(ctx.db, e.lot_id)!;
    // Undoing a deduction re-activates the lot; undoing a purchase empties it.
    // If part of an undone purchase was already used, only the remainder can be removed.
    const delta = Math.max(-e.delta, -lot.quantity);
    out.push(writeEvent(ctx, lot, { type: 'undo', delta, reverses: e.id }));
    if (e.type === 'open') {
      const prev = e.meta ? JSON.parse(e.meta).prev : null;
      if (prev) ctx.db.run('UPDATE inventory_lots SET opened_at = ?, expires_on = ? WHERE id = ?', prev.openedAt, prev.expiresOn, lot.id);
    }
    if (e.type === 'freeze' || e.type === 'thaw' || e.type === 'transfer') {
      const meta = e.meta ? JSON.parse(e.meta) : null;
      if (meta?.from) ctx.db.run('UPDATE inventory_lots SET location_id = ? WHERE id = ?', meta.from, lot.id);
    }
  }
  ctx.db.run('DELETE FROM purchases WHERE event_id IN (SELECT reverses_event_id FROM inventory_events WHERE batch_id = ? AND type = ?)', ctx.batchId, 'undo');
  return out;
}

/** Recompute lot quantities from the ledger and report mismatches (used by tests and the /admin/verify endpoint). */
export function verifyLedger(db: Db, householdId: string): { lots: number; mismatches: { lotId: string; stored: number; ledger: number }[] } {
  const rows = db.all<{ id: string; quantity: number; ledger: number }>(
    `SELECT l.id, l.quantity, COALESCE((SELECT SUM(delta) FROM inventory_events e WHERE e.lot_id = l.id), 0) AS ledger
     FROM inventory_lots l WHERE l.household_id = ?`,
    householdId,
  );
  const mismatches = rows.filter((r) => Math.abs(r.quantity - Math.max(0, r.ledger)) > 1e-4).map((r) => ({ lotId: r.id, stored: r.quantity, ledger: r.ledger }));
  return { lots: rows.length, mismatches };
}

export function eventsForBatch(db: Db, batchId: string): LedgerEvent[] {
  return db.all<LedgerEvent>('SELECT * FROM inventory_events WHERE batch_id = ? ORDER BY rowid', batchId);
}
