// Household-wide personal settings with their defaults: which reminders to send and how often, and
// how the app behaves (voice first, automatic deductions, cooking mode). Declared and validated in
// settings.ts; these are the typed views the rest of the server uses.
import type { Db } from '../db/db.ts';
import { householdSetting, MEAL_TYPES, DEFAULT_NOTIFICATIONS, DEFAULT_INTERACTION } from './settings.ts';

export { MEAL_TYPES, DEFAULT_NOTIFICATIONS, DEFAULT_INTERACTION };
export type NotificationPrefs = typeof DEFAULT_NOTIFICATIONS;
export type InteractionPrefs = typeof DEFAULT_INTERACTION;
export const notificationPrefs = (db: Db, h: string): NotificationPrefs => householdSetting(db, h, 'notifications');
export const interactionPrefs = (db: Db, h: string): InteractionPrefs => householdSetting(db, h, 'interaction');
