// A recipe from a photo or screenshot, without AI: the phone reads the text on the device (Tesseract), and
// this splits that text into a title, servings, time, ingredient lines and a method of separate steps.
// Cookbook pages, recipe apps and screenshots of websites mostly use headings ("Ingrediënten", "Bereiding");
// without them each line is judged on its own: an amount at the start makes it an ingredient, a sentence
// makes it part of the method. With no method in the photo, a plain one is written from the ingredients.
import type { Db } from '../db/db.ts';
import { AppError } from '../errors.ts';
import { finishDraft, nameIndex, parseIngredientLine, timerOf, type RecipeDraft } from './recipe-import.ts';
import { genericSteps } from './quick-recipe.ts';
import { getProduct, listProducts, type Product } from './products.ts';

type Lang = 'en' | 'nl';
export type PhotoDraft = RecipeDraft & { stepsGuessed: boolean };

const INGREDIENTS = /^(ingredi[eëé]nten|ingredients?|benodigdheden|wat (?:heb|je) (?:je )?nodig|je hebt nodig|nodig|boodschappen(?:lijst)?|shopping list|you(?:'|’)?(?:ll)? need|what you(?:'|’)?ll need)\b/i;
const METHOD = /^(bereiding(?:swijze)?|werkwijze|zo maak je(?: het)?|aan de slag|instructies|method|instructions|directions|preparation|steps|stappen|how to make(?: it)?)\b/i;
// Sections after the recipe that are neither ingredients nor method.
const OTHER = /^(tips?|variatie|variaties|serveertips?|voedingswaarden?|nutrition(?: facts)?|notes?|opmerkingen?|bewaren|storage|allergenen|allergens)\b/i;
const SERVINGS = /(\d+)\s*(?:personen|persoon|pers\b\.?|porties?|servings?|people|persons)\b|\b(?:serves|voor|porties?|servings?|yield|makes|aantal personen)\s*:?\s*(\d+)\b/i;
const QUANTITY = /^(\d|[½¼¾⅓⅔⅛]|(?:een|één|half|halve|a|an|one|two|three|twee|drie|vier|snuf|snufje|scheut|handje|handvol|pinch|dash|handful)\s)/i;
// "1.", "2)", "Stap 3", a bullet, or "4 Snijd" (OCR often drops the dot); "6 minuten" continues a sentence.
const STEP_MARK = /^(?:(?:[Ss]tap|[Ss]tep|STAP|STEP)\s*\d+\s*[:.)-]?|\d{1,2}\s*[.)]|\d{1,2}\s+(?=\p{Lu})|[•·*▪►-])\s*/u;

/** Make OCR text into clean lines: hyphenated words rejoined, checkbox and bullet glyphs and screen clutter dropped. */
function cleanLines(text: string): string[] {
  return text
    .replace(/\r/g, '')
    .replace(/(\p{L})-\n\s*(\p{Ll})/gu, '$1$2')
    .split('\n')
    .map((l) => l.replace(/[|_~=]+/g, ' ').replace(/^\s*(?:[oO0©®□■▢◯○●☐✓✔]|\[\s?\])\s+(?=\S)/, '').replace(/\s+/g, ' ').trim())
    .map((l) => ((l.match(/\p{L}/gu)?.length ?? 0) >= 2 || /^\d{1,2}\s*[.)]?$/.test(l) || /^[\d½¼¾⅓⅔.,/\s-]+\s*\p{L}{0,3}\.?$/u.test(l) ? l : ''));
}

// Buttons and tabs of a recipe app or website in a screenshot.
const SCREEN = /^(terug|back|delen|share|opslaan|bewaren|bewaar|save|saved|menu|zoeken|search|home|recepten|recipes|inloggen|log in|sign in|volgen|follow|print|printen|favoriet(?:en)?|advertentie|advertisement|ad)\b/i;

const isHeading = (l: string, re: RegExp) => l.length <= 40 && re.test(l.replace(/[:.]+$/, ''));
const metaLine = (l: string) => l.length <= 60 && (SERVINGS.test(l) || /\b\d+\s*(?:min|minuten|minutes|mins|uur|hours?|hrs?)\b/i.test(l)) && !/[.!?]$/.test(l);

/** Total minutes from lines like "Bereidingstijd: 30 min", "Prep 10 min · Cook 20 min" or "1 uur 15 min". */
function minutesOf(lines: string[]): number {
  const total = (l: string) => {
    const h = l.match(/(\d+(?:[.,]\d+)?)\s*(?:uur|hours?|hrs?|u)\b/i);
    const m = l.match(/(\d+)\s*(?:min|minuten|minutes|mins)\b/i);
    return Math.round((h ? Number(h[1].replace(',', '.')) * 60 : 0) + (m ? Number(m[1]) : 0));
  };
  const tot = lines.find((l) => /\b(totaal|total|totale)\b/i.test(l) && total(l));
  if (tot) return total(tot);
  const parts = lines.filter((l) => /\b(voorbereid|bereid|prep|kook|oven|cook|bak|wacht)/i.test(l) && total(l));
  if (parts.length) return parts.reduce((s, l) => s + total(l), 0);
  const any = lines.find((l) => total(l));
  return any ? total(any) : 0;
}

/** Method text as separate steps: numbered steps as they are, otherwise one step per sentence (short ones joined). */
function stepsFrom(lines: string[]): string[] {
  const numbered = lines.filter((l) => STEP_MARK.test(l) || /^\d{1,2}\s*[.)]?$/.test(l)).length >= 2;
  const steps: string[] = [];
  let cur = '';
  const flush = () => {
    if (cur.trim()) steps.push(cur.trim());
    cur = '';
  };
  for (const l of lines) {
    if (!l) {
      if (!numbered) flush();
      continue;
    }
    if (numbered && /^\d{1,2}\s*[.)]?$/.test(l)) {
      flush();
      continue;
    }
    if (numbered && STEP_MARK.test(l)) {
      flush();
      cur = l.replace(STEP_MARK, '');
    } else cur = cur ? `${cur} ${l}` : l;
  }
  flush();
  if (numbered) return steps;
  // Paragraphs into sentences; a short sentence ("Roer goed.") stays with the one before it.
  const out: string[] = [];
  for (const p of steps) {
    for (const s of p.split(/(?<=[.!?])\s+(?=[A-ZÀ-Ý])/)) {
      if (out.length && (s.length < 30 || out[out.length - 1].length < 25)) out[out.length - 1] += ` ${s}`;
      else out.push(s);
    }
  }
  return out;
}

/** Ingredient lines: an amount printed on a line of its own ("500 g") belongs to the name on the next line. */
function ingredientLines(lines: string[]): string[] {
  const out: string[] = [];
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    if (!l || /:$/.test(l) || SERVINGS.test(l) && !/\d\s*(?:g|kg|ml|l|el|tl)\b/i.test(l)) continue;
    const next = lines[i + 1];
    if (/^[\d½¼¾⅓⅔.,/\s-]+\s*(?:g|gr|gram|kg|ml|l|cl|dl|el|tl|eetlepels?|theelepels?|tbsp|tsp|cups?|oz|stuks?|teen(?:tjes)?|blik(?:je)?|zakje)?\.?$/i.test(l) && next && !QUANTITY.test(next)) {
      out.push(`${l} ${next}`);
      i++;
    } else out.push(l);
  }
  return out.filter((l) => l.length <= 120);
}

export function draftFromPhotoText(db: Db, householdId: string, text: string, lang: Lang = 'nl'): PhotoDraft {
  const lines = cleanLines(text);
  const ing: string[] = [];
  const method: string[] = [];
  const intro: string[] = [];
  let section: 'intro' | 'ing' | 'method' | 'other' = 'intro';
  const headed = lines.some((l) => isHeading(l, INGREDIENTS) || isHeading(l, METHOD));
  const index = nameIndex(listProducts(db, householdId));
  // Without headings: does this line read as an ingredient? An amount first, or a short line naming a product.
  const looksLikeIngredient = (l: string) =>
    l.length <= 70 && !/[.!?]$/.test(l) && !/^(?:(?:stap|step)\s*\d+|\d{1,2}\s*[.)]\s)/i.test(l) &&
    (QUANTITY.test(l) || (l.length <= 35 && !!parseIngredientLine(db, householdId, l, index).productId));

  for (const l of lines) {
    if (isHeading(l, INGREDIENTS)) { section = 'ing'; continue; }
    if (isHeading(l, METHOD)) { section = 'method'; continue; }
    if (l && isHeading(l, OTHER)) { section = 'other'; continue; }
    if (section === 'other') continue;
    if (headed) {
      if (section === 'ing') {
        // A sentence under the ingredients is the method starting without a heading.
        if (l.length > 70 && /[.!?]$/.test(l) && ing.length) { section = 'method'; method.push(l); }
        else ing.push(l);
      } else if (section === 'method') method.push(l);
      else intro.push(l);
      continue;
    }
    if (!l) { (method.length ? method : intro).push(l); continue; }
    if (metaLine(l) && !method.length) intro.push(l);
    else if (looksLikeIngredient(l) && !(method.length && method[method.length - 1] && !/[.!?]$/.test(method[method.length - 1]))) ing.push(l);
    else if (ing.length) method.push(l);
    else intro.push(l);
  }

  const ingredients = ingredientLines(ing);
  if (!ingredients.length) throw new AppError(422, 'no_recipe', lang === 'nl' ? 'Geen ingrediënten gevonden op de foto. Zorg dat de ingrediëntenlijst goed leesbaar in beeld is, of typ ze over.' : 'No ingredients found in the photo. Make sure the ingredient list is sharp and in view, or type them in.');

  const meta = [...intro, ...ing].filter(Boolean).filter(metaLine);
  const servingsMatch = meta.map((l) => l.match(SERVINGS)).find(Boolean);
  const servings = servingsMatch ? Math.min(40, Math.max(1, Number(servingsMatch[1] ?? servingsMatch[2]))) : 2;
  const minutes = Math.min(1440, minutesOf(meta));
  // The title: the first line before the ingredients that isn't a time, a serving count or screen clutter.
  const title = intro.find((l) => l && !metaLine(l) && l.length >= 3 && l.length <= 80 && (l.match(/\p{L}/gu)?.length ?? 0) >= 4 && !/[.!?]$/.test(l) && /^\p{L}/u.test(l) && !SCREEN.test(l))
    ?? (lang === 'nl' ? 'Recept van foto' : 'Recipe from photo');

  const draft = finishDraft(db, householdId, {
    title, summary: null, servings, prep_minutes: 0, cook_minutes: minutes || 30, cuisine: null, image_url: null, source_url: null,
    source_name: lang === 'nl' ? 'Foto' : 'Photo',
    steps: stepsFrom(method).filter((s) => s.length >= 8).map((s) => ({ text: s.slice(0, 1000), timerSeconds: timerOf(s) })),
    ingredientLines: ingredients,
  });
  const stepsGuessed = !method.some((l) => l.length >= 8);
  if (stepsGuessed) {
    const ps = draft.ingredients.map((i) => (i.productId ? getProduct(db, i.productId) : undefined)).filter((p): p is Product => !!p);
    draft.steps = genericSteps(ps, lang);
  }
  return { ...draft, stepsGuessed };
}
