// Weekly meal planner. Planning never touches inventory; only cooking does.
import type { Db } from '../db/db.ts';
import { newId } from '../db/db.ts';
import { clock, addDays } from '../clock.ts';
import { AppError, notFound } from '../errors.ts';
import { getRecipe, recordInteraction, type Nutrition } from './recipes.ts';
import { bus } from '../bus.ts';

export const MEALS = ['breakfast', 'lunch', 'dinner', 'snack'] as const;

export interface MealSlot {
  id: string;
  date: string;
  meal: string;
  position: number;
  recipe_id: string | null;
  leftover_lot_id: string | null;
  title: string | null;
  servings: number;
  status: 'planned' | 'cooked' | 'skipped';
  cook_batch_id: string | null;
  recipe?: { id: string; title: string; emoji: string | null; color: string | null; image_url: string | null; minutes: number; servings: number; nutritionPerServing: Nutrition | null; origin: string } | null;
}

function decorate(db: Db, householdId: string, s: MealSlot): MealSlot {
  if (!s.recipe_id) {
    if (s.leftover_lot_id) {
      const lot = db.get('SELECT label FROM inventory_lots WHERE id = ?', s.leftover_lot_id);
      return { ...s, title: s.title ?? `${lot?.label ?? 'Leftovers'} (leftovers)`, recipe: null };
    }
    return { ...s, recipe: null };
  }
  try {
    const r = getRecipe(db, householdId, s.recipe_id);
    return {
      ...s,
      recipe: { id: r.id, title: r.title, emoji: r.emoji, color: r.color, image_url: r.image_url, minutes: r.prep_minutes + r.cook_minutes, servings: r.servings, nutritionPerServing: r.nutritionPerServing, origin: r.origin },
    };
  } catch {
    return { ...s, recipe: null };
  }
}

export function weekPlan(db: Db, householdId: string, start: string, days = 7) {
  const end = addDays(start, days - 1);
  const slots = db
    .all<MealSlot>('SELECT * FROM meal_slots WHERE household_id = ? AND date BETWEEN ? AND ? ORDER BY date, meal, position', householdId, start, end)
    .map((s) => decorate(db, householdId, s));
  const daysOut = Array.from({ length: days }, (_, i) => {
    const date = addDays(start, i);
    const daySlots = slots.filter((s) => s.date === date);
    const nutrition = daySlots.reduce(
      (acc, s) => {
        const n = s.recipe?.nutritionPerServing;
        if (!n || s.status === 'skipped') return acc;
        // Per-person nutrition: one serving of each planned meal.
        return { kcal: acc.kcal + n.kcal, protein: acc.protein + n.protein, carbs: acc.carbs + n.carbs, fat: acc.fat + n.fat };
      },
      { kcal: 0, protein: 0, carbs: 0, fat: 0 },
    );
    return { date, slots: daySlots, nutrition };
  });
  const totals = daysOut.reduce((a, d) => ({ kcal: a.kcal + d.nutrition.kcal, protein: a.protein + d.nutrition.protein, carbs: a.carbs + d.nutrition.carbs, fat: a.fat + d.nutrition.fat }), { kcal: 0, protein: 0, carbs: 0, fat: 0 });
  return { start, end, days: daysOut, weekNutrition: totals };
}

export interface SlotInput {
  date: string;
  meal: string;
  recipeId?: string | null;
  leftoverLotId?: string | null;
  title?: string | null;
  servings?: number;
}

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

export function addSlot(db: Db, householdId: string, input: SlotInput): MealSlot {
  if (!DATE_RE.test(input.date)) throw new AppError(422, 'invalid_date', 'Date must be YYYY-MM-DD');
  if (!input.recipeId && !input.title && !input.leftoverLotId) throw new AppError(422, 'empty_slot', 'Recipe, leftovers or a title is required');
  let servings = input.servings;
  if (input.recipeId) {
    const r = getRecipe(db, householdId, input.recipeId);
    servings ??= defaultServings(db, householdId) ?? r.servings;
  }
  const pos = db.get<{ n: number }>('SELECT COUNT(*) n FROM meal_slots WHERE household_id = ? AND date = ? AND meal = ?', householdId, input.date, input.meal)!.n;
  const id = newId('ms');
  db.insert('meal_slots', {
    id,
    household_id: householdId,
    date: input.date,
    meal: input.meal,
    position: pos,
    recipe_id: input.recipeId ?? null,
    leftover_lot_id: input.leftoverLotId ?? null,
    title: input.title ?? null,
    servings: servings ?? 1,
    status: 'planned',
    created_at: clock.iso(),
  });
  bus.touch(householdId, 'planner');
  return getSlot(db, householdId, id);
}

function defaultServings(db: Db, householdId: string): number | null {
  const v = db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = '' AND key = 'householdSize'", householdId)?.value;
  return v ? Number(JSON.parse(v)) : null;
}

export function getSlot(db: Db, householdId: string, id: string): MealSlot {
  const s = db.get<MealSlot>('SELECT * FROM meal_slots WHERE id = ? AND household_id = ?', id, householdId);
  if (!s) throw notFound('Meal');
  return decorate(db, householdId, s);
}

export function updateSlot(db: Db, householdId: string, id: string, patch: { date?: string; meal?: string; position?: number; servings?: number; status?: 'planned' | 'skipped'; recipeId?: string | null; title?: string | null; locked?: boolean }) {
  const s = getSlot(db, householdId, id);
  if (patch.date && !DATE_RE.test(patch.date)) throw new AppError(422, 'invalid_date', 'Date must be YYYY-MM-DD');
  if (patch.servings != null && !(patch.servings > 0)) throw new AppError(422, 'invalid_servings', 'Servings must be positive');
  if (patch.status === 'skipped' && s.recipe_id && s.status !== 'skipped') recordInteraction(db, householdId, s.recipe_id, { skipped: true });
  db.update('meal_slots', id, {
    date: patch.date,
    meal: patch.meal,
    position: patch.position,
    servings: patch.servings,
    status: patch.status,
    recipe_id: patch.recipeId,
    title: patch.title,
    locked: patch.locked === undefined ? undefined : patch.locked ? 1 : 0,
  });
  bus.touch(householdId, 'planner');
  return getSlot(db, householdId, id);
}

export function removeSlot(db: Db, householdId: string, id: string) {
  getSlot(db, householdId, id);
  db.run('DELETE FROM meal_slots WHERE id = ? AND household_id = ?', id, householdId);
  bus.touch(householdId, 'planner');
}

/**
 * Clear a stretch of the planner: every meal still planned (or skipped) in [from, to] goes, locked ones
 * too; cooked meals stay, they're history. Returns the removed rows so the change can be undone.
 */
export function clearPlan(db: Db, householdId: string, from: string, to: string) {
  if (!DATE_RE.test(from) || !DATE_RE.test(to)) throw new AppError(422, 'invalid_date', 'Dates must be YYYY-MM-DD');
  const rows = db.all<MealSlot & { locked: number }>("SELECT * FROM meal_slots WHERE household_id = ? AND date BETWEEN ? AND ? AND status != 'cooked'", householdId, from, to);
  db.run("DELETE FROM meal_slots WHERE household_id = ? AND date BETWEEN ? AND ? AND status != 'cooked'", householdId, from, to);
  if (rows.length) bus.touch(householdId, 'planner');
  return rows;
}

/** Undo a clear: put the removed meals back as they were (same ids, so nothing is duplicated). */
export function restoreSlots(db: Db, householdId: string, rows: { id: string; date: string; meal: string; position?: number; recipe_id?: string | null; leftover_lot_id?: string | null; title?: string | null; servings: number; status?: string; locked?: number; created_at?: string }[]) {
  let restored = 0;
  for (const r of rows) {
    if (!DATE_RE.test(r.date)) continue;
    if (r.recipe_id) getRecipe(db, householdId, r.recipe_id); // must still exist and be visible to this household
    const res = db.run(
      'INSERT OR IGNORE INTO meal_slots (id, household_id, date, meal, position, recipe_id, leftover_lot_id, title, servings, status, locked, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      r.id, householdId, r.date, r.meal, r.position ?? 0, r.recipe_id ?? null, r.leftover_lot_id ?? null, r.title ?? null, r.servings, r.status === 'skipped' ? 'skipped' : 'planned', r.locked ? 1 : 0, r.created_at ?? new Date().toISOString(),
    );
    restored += Number(res.changes);
  }
  if (restored) bus.touch(householdId, 'planner');
  return restored;
}

/** Aggregate ingredient needs of planned (not yet cooked) meals in the window. */
export function planRequirements(db: Db, householdId: string, from: string, days: number) {
  const to = addDays(from, days - 1);
  const slots = db.all<MealSlot>(
    "SELECT * FROM meal_slots WHERE household_id = ? AND status = 'planned' AND recipe_id IS NOT NULL AND date BETWEEN ? AND ?",
    householdId,
    from,
    to,
  );
  const req = new Map<string, { productId: string; quantity: number; recipes: string[]; replaces: string[] }>();
  for (const s of slots) {
    let r;
    try {
      r = getRecipe(db, householdId, s.recipe_id!);
    } catch {
      continue;
    }
    const f = s.servings / r.servings;
    for (const ing of r.ingredients) {
      if (ing.optional || !ing.product_id || ing.quantity == null) continue;
      const e = req.get(ing.product_id) ?? { productId: ing.product_id, quantity: 0, recipes: [], replaces: [] };
      e.quantity += ing.quantity * f;
      if (!e.recipes.includes(r.title)) e.recipes.push(r.title);
      // Bought in place of something the recipe asked for: say so on the list.
      if (ing.sub && !e.replaces.includes(ing.sub.original)) e.replaces.push(ing.sub.original);
      req.set(ing.product_id, e);
    }
  }
  return [...req.values()];
}

/** Slots planned for today (shown on Home with a one-tap "Cooked it"). */
export function todaysMeals(db: Db, householdId: string) {
  return db
    .all<MealSlot>('SELECT * FROM meal_slots WHERE household_id = ? AND date = ? ORDER BY meal, position', householdId, clock.today())
    .map((s) => decorate(db, householdId, s));
}
