// Weekly meal planner. Planning never touches inventory; only cooking does.
import type { Db } from '../db/db.ts';
import { newId, parseJson } from '../db/db.ts';
import { clock, addDays } from '../clock.ts';
import { AppError, notFound } from '../errors.ts';
import { getRecipe, recordInteraction, type Nutrition, type Recipe } from './recipes.ts';
import { getProduct } from './products.ts';
import { convertQty } from './substitutions.ts';
import { bus } from '../bus.ts';
import { householdSetting } from './settings.ts';

/**
 * Cooking on fewer days spreads the plan over more weeks, so about a week's worth of dinners is in view:
 * 7 days → 1 week, 4–6 → 2, 2–3 → 3, 1 → 4. The planner shows this span and the shopping list covers it.
 */
export const planWeeks = (cookDays: number) => (cookDays >= 7 || cookDays <= 0 ? 1 : cookDays >= 4 ? 2 : cookDays >= 2 ? 3 : 4);
export function planHorizonDays(db: Db, householdId: string) {
  return planWeeks((householdSetting(db, householdId, 'planDays') as number[]).length) * 7;
}

export const MEALS = ['breakfast', 'lunch', 'dinner', 'snack'] as const;

export interface MealSlot {
  id: string;
  date: string;
  meal: string;
  position: number;
  recipe_id: string | null;
  leftover_lot_id: string | null;
  title: string | null;
  servings: number;
  status: 'planned' | 'cooked' | 'skipped';
  cook_batch_id: string | null;
  /** Ingredient swaps for this meal only (stored as JSON, returned with names). */
  swaps?: any;
  recipe?: { id: string; title: string; emoji: string | null; color: string | null; image_url: string | null; minutes: number; servings: number; nutritionPerServing: Nutrition | null; origin: string } | null;
}

/** One recipe line changed for this meal: another product, or left out (omit). */
export interface SlotSwap { position: number; productId?: string; omit?: boolean }
export const slotSwaps = (s: { swaps?: any }): SlotSwap[] => (Array.isArray(s.swaps) ? s.swaps : parseJson<SlotSwap[]>(s.swaps ?? '[]', []));

/**
 * A recipe line as this meal uses it: the swapped-in product where one was chosen (quantity converted
 * between units where possible, else the same amount), otherwise the recipe's own.
 */
export function lineFor(db: Db, ing: Recipe['ingredients'][number], swaps: SlotSwap[], factor: number) {
  const qty = ing.quantity == null ? null : ing.quantity * factor;
  const sw = swaps.find((x) => x.position === ing.position);
  if (sw?.omit) return { productId: null, quantity: 0, swappedFrom: ing.product?.name ?? ing.name };
  const to = sw?.productId && ing.product ? getProduct(db, sw.productId) : undefined;
  if (!to || !ing.product) return { productId: ing.product_id, quantity: qty, swappedFrom: null as string | null };
  return { productId: to.id, quantity: qty == null ? null : convertQty(qty, ing.product, to) ?? qty, swappedFrom: ing.product.name };
}

function decorate(db: Db, householdId: string, s: MealSlot): MealSlot {
  const swaps = slotSwaps(s);
  if (!s.recipe_id) {
    if (s.leftover_lot_id) {
      const lot = db.get('SELECT label FROM inventory_lots WHERE id = ?', s.leftover_lot_id);
      return { ...s, title: s.title ?? `${lot?.label ?? 'Leftovers'} (leftovers)`, recipe: null };
    }
    return { ...s, recipe: null };
  }
  try {
    const r = getRecipe(db, householdId, s.recipe_id);
    type Named = { position: number; from: string; fromId: string | null; omit?: boolean; productId: string | null; to: string | null; to_nl: string | null };
    const named = swaps.flatMap((w): Named[] => {
      const ing = r.ingredients.find((i) => i.position === w.position);
      if (!ing) return [];
      const from = { position: w.position, from: ing.product?.name ?? ing.name, fromId: ing.product_id };
      if (w.omit) return [{ ...from, omit: true, productId: null, to: null, to_nl: null }];
      const to = w.productId ? getProduct(db, w.productId) : undefined;
      return to ? [{ ...from, productId: to.id, to: to.name, to_nl: to.name_nl ?? to.name }] : [];
    });
    return {
      ...s,
      swaps: named,
      recipe: { id: r.id, title: r.title, emoji: r.emoji, color: r.color, image_url: r.image_url, minutes: r.prep_minutes + r.cook_minutes, servings: r.servings, nutritionPerServing: r.nutritionPerServing, origin: r.origin },
    };
  } catch {
    return { ...s, swaps: [], recipe: null };
  }
}

/** Use another product for one recipe line in this meal, or leave it out; null puts the recipe's own back. */
export function setSlotSwap(db: Db, householdId: string, id: string, position: number, productId: string | null, omit = false) {
  const s = db.get<MealSlot>('SELECT * FROM meal_slots WHERE id = ? AND household_id = ?', id, householdId);
  if (!s) throw notFound('Meal');
  if (!s.recipe_id) throw new AppError(422, 'no_recipe', 'This meal has no recipe');
  const ing = getRecipe(db, householdId, s.recipe_id).ingredients.find((i) => i.position === position);
  if (!ing) throw notFound('Ingredient');
  if (productId) {
    const p = getProduct(db, productId);
    if (!p || (p.household_id && p.household_id !== householdId)) throw notFound('Product');
  }
  const next = slotSwaps(s).filter((w) => w.position !== position);
  if (omit) next.push({ position, omit: true });
  else if (productId && productId !== ing.product_id) next.push({ position, productId });
  db.update('meal_slots', id, { swaps: JSON.stringify(next) });
  bus.touch(householdId, 'planner');
  return getSlot(db, householdId, id);
}

export function weekPlan(db: Db, householdId: string, start: string, days = 7) {
  const end = addDays(start, days - 1);
  const slots = db
    .all<MealSlot>('SELECT * FROM meal_slots WHERE household_id = ? AND date BETWEEN ? AND ? ORDER BY date, meal, position', householdId, start, end)
    .map((s) => decorate(db, householdId, s));
  const daysOut = Array.from({ length: days }, (_, i) => {
    const date = addDays(start, i);
    const daySlots = slots.filter((s) => s.date === date);
    const nutrition = daySlots.reduce(
      (acc, s) => {
        const n = s.recipe?.nutritionPerServing;
        if (!n || s.status === 'skipped') return acc;
        // Per-person nutrition: one serving of each planned meal.
        return { kcal: acc.kcal + n.kcal, protein: acc.protein + n.protein, carbs: acc.carbs + n.carbs, fat: acc.fat + n.fat };
      },
      { kcal: 0, protein: 0, carbs: 0, fat: 0 },
    );
    return { date, slots: daySlots, nutrition };
  });
  const totals = daysOut.reduce((a, d) => ({ kcal: a.kcal + d.nutrition.kcal, protein: a.protein + d.nutrition.protein, carbs: a.carbs + d.nutrition.carbs, fat: a.fat + d.nutrition.fat }), { kcal: 0, protein: 0, carbs: 0, fat: 0 });
  return { start, end, days: daysOut, weekNutrition: totals };
}

export interface SlotInput {
  date: string;
  meal: string;
  swaps?: SlotSwap[];
  recipeId?: string | null;
  leftoverLotId?: string | null;
  title?: string | null;
  servings?: number;
}

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

export function addSlot(db: Db, householdId: string, input: SlotInput): MealSlot {
  if (!DATE_RE.test(input.date)) throw new AppError(422, 'invalid_date', 'Date must be YYYY-MM-DD');
  if (!input.recipeId && !input.title && !input.leftoverLotId) throw new AppError(422, 'empty_slot', 'Recipe, leftovers or a title is required');
  let servings = input.servings;
  if (input.recipeId) {
    const r = getRecipe(db, householdId, input.recipeId);
    servings ??= defaultServings(db, householdId) ?? r.servings;
  }
  const pos = db.get<{ n: number }>('SELECT COUNT(*) n FROM meal_slots WHERE household_id = ? AND date = ? AND meal = ?', householdId, input.date, input.meal)!.n;
  const id = newId('ms');
  db.insert('meal_slots', {
    id,
    household_id: householdId,
    date: input.date,
    meal: input.meal,
    position: pos,
    recipe_id: input.recipeId ?? null,
    leftover_lot_id: input.leftoverLotId ?? null,
    title: input.title ?? null,
    servings: servings ?? 1,
    status: 'planned',
    swaps: JSON.stringify(input.recipeId ? (input.swaps ?? []) : []),
    created_at: clock.iso(),
  });
  bus.touch(householdId, 'planner');
  return getSlot(db, householdId, id);
}

function defaultServings(db: Db, householdId: string): number | null {
  const v = db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = '' AND key = 'householdSize'", householdId)?.value;
  return v ? Number(JSON.parse(v)) : null;
}

export function getSlot(db: Db, householdId: string, id: string): MealSlot {
  const s = db.get<MealSlot>('SELECT * FROM meal_slots WHERE id = ? AND household_id = ?', id, householdId);
  if (!s) throw notFound('Meal');
  return decorate(db, householdId, s);
}

export function updateSlot(db: Db, householdId: string, id: string, patch: { date?: string; meal?: string; position?: number; servings?: number; status?: 'planned' | 'skipped'; recipeId?: string | null; title?: string | null; locked?: boolean }) {
  const s = getSlot(db, householdId, id);
  if (patch.date && !DATE_RE.test(patch.date)) throw new AppError(422, 'invalid_date', 'Date must be YYYY-MM-DD');
  if (patch.servings != null && !(patch.servings > 0)) throw new AppError(422, 'invalid_servings', 'Servings must be positive');
  if (patch.status === 'skipped' && s.recipe_id && s.status !== 'skipped') recordInteraction(db, householdId, s.recipe_id, { skipped: true });
  db.update('meal_slots', id, {
    date: patch.date,
    meal: patch.meal,
    position: patch.position,
    servings: patch.servings,
    status: patch.status,
    recipe_id: patch.recipeId,
    // Swaps belong to the recipe's lines: another recipe starts without them.
    swaps: patch.recipeId !== undefined && patch.recipeId !== s.recipe_id ? '[]' : undefined,
    title: patch.title,
    locked: patch.locked === undefined ? undefined : patch.locked ? 1 : 0,
  });
  bus.touch(householdId, 'planner');
  return getSlot(db, householdId, id);
}

export function removeSlot(db: Db, householdId: string, id: string) {
  getSlot(db, householdId, id);
  db.run('DELETE FROM meal_slots WHERE id = ? AND household_id = ?', id, householdId);
  bus.touch(householdId, 'planner');
}

/**
 * Clear a stretch of the planner: every meal still planned (or skipped) in [from, to] goes, locked ones
 * too; cooked meals stay, they're history. Returns the removed rows so the change can be undone.
 */
export function clearPlan(db: Db, householdId: string, from: string, to: string) {
  if (!DATE_RE.test(from) || !DATE_RE.test(to)) throw new AppError(422, 'invalid_date', 'Dates must be YYYY-MM-DD');
  const rows = db.all<MealSlot & { locked: number }>("SELECT * FROM meal_slots WHERE household_id = ? AND date BETWEEN ? AND ? AND status != 'cooked'", householdId, from, to);
  db.run("DELETE FROM meal_slots WHERE household_id = ? AND date BETWEEN ? AND ? AND status != 'cooked'", householdId, from, to);
  if (rows.length) bus.touch(householdId, 'planner');
  return rows;
}

/** Undo a clear: put the removed meals back as they were (same ids, so nothing is duplicated). */
export function restoreSlots(db: Db, householdId: string, rows: { id: string; date: string; meal: string; position?: number; recipe_id?: string | null; leftover_lot_id?: string | null; title?: string | null; servings: number; status?: string; locked?: number; swaps?: any; created_at?: string }[]) {
  let restored = 0;
  for (const r of rows) {
    if (!DATE_RE.test(r.date)) continue;
    if (r.recipe_id) getRecipe(db, householdId, r.recipe_id); // must still exist and be visible to this household
    const res = db.run(
      'INSERT OR IGNORE INTO meal_slots (id, household_id, date, meal, position, recipe_id, leftover_lot_id, title, servings, status, locked, swaps, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      r.id, householdId, r.date, r.meal, r.position ?? 0, r.recipe_id ?? null, r.leftover_lot_id ?? null, r.title ?? null, r.servings, r.status === 'skipped' ? 'skipped' : 'planned', r.locked ? 1 : 0,
      JSON.stringify(slotSwaps(r).map((w) => (w.omit ? { position: w.position, omit: true } : { position: w.position, productId: w.productId }))), r.created_at ?? new Date().toISOString(),
    );
    restored += Number(res.changes);
  }
  if (restored) bus.touch(householdId, 'planner');
  return restored;
}

/** Aggregate ingredient needs of planned (not yet cooked) meals in the window. */
export function planRequirements(db: Db, householdId: string, from: string, days: number) {
  const to = addDays(from, days - 1);
  const slots = db.all<MealSlot>(
    "SELECT * FROM meal_slots WHERE household_id = ? AND status = 'planned' AND recipe_id IS NOT NULL AND date BETWEEN ? AND ?",
    householdId,
    from,
    to,
  );
  const req = new Map<string, { productId: string; quantity: number; recipes: string[]; replaces: string[]; uses: { slotId: string; date: string; title: string; position: number; ingredient: string }[] }>();
  for (const s of slots) {
    let r;
    try {
      r = getRecipe(db, householdId, s.recipe_id!);
    } catch {
      continue;
    }
    const f = s.servings / r.servings;
    const swaps = slotSwaps(s);
    for (const ing of r.ingredients) {
      if (ing.optional || !ing.product_id || ing.quantity == null) continue;
      const line = lineFor(db, ing, swaps, f);
      if (!line.productId) continue; // left out of this meal
      const pid = line.productId;
      const e = req.get(pid) ?? { productId: pid, quantity: 0, recipes: [], replaces: [], uses: [] };
      e.quantity += line.quantity ?? 0;
      if (!e.recipes.includes(r.title)) e.recipes.push(r.title);
      // Bought in place of something the recipe asked for (a household choice, or swapped for this meal): say so.
      const replaced = line.swappedFrom ?? ing.sub?.original;
      if (replaced && !e.replaces.includes(replaced)) e.replaces.push(replaced);
      e.uses.push({ slotId: s.id, date: s.date, title: r.title, position: ing.position, ingredient: ing.product?.name ?? ing.name });
      req.set(pid, e);
    }
  }
  return [...req.values()];
}

/** Slots planned for today (shown on Home with a one-tap "Cooked it"). */
export function todaysMeals(db: Db, householdId: string) {
  return db
    .all<MealSlot>('SELECT * FROM meal_slots WHERE household_id = ? AND date = ? ORDER BY meal, position', householdId, clock.today())
    .map((s) => decorate(db, householdId, s));
}
