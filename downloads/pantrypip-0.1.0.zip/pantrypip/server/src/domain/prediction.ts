// Consumption prediction. Purely advisory: nothing here writes to the ledger.
//
// For each product we estimate a total consumption rate (units/day) from two signals:
//   1. purchase cycles: quantity bought / days until the next purchase (recency-weighted)
//   2. logged usage: consume/cook/discard events per day over the recent window
// Usage that is never logged ("implicit" usage) is total minus logged. The estimated
// remaining quantity is the confirmed quantity minus implicit usage since the last
// confirmation, scaled by a correction factor learned from the user's own corrections.
import type { Db } from '../db/db.ts';
import { clock, daysBetween } from '../clock.ts';

export interface Prediction {
  productId: string;
  ratePerDay: number | null;        // total consumption rate
  implicitRatePerDay: number;       // part of the rate that is not logged
  correctionFactor: number;
  observations: number;             // purchase intervals + logged-usage days used
  confidence: number;               // 0..1
  avgIntervalDays: number | null;   // typical days between purchases
  lastPurchaseAt: string | null;
  nextPurchaseDue: string | null;   // date a regular purchase is expected
  overdue: boolean;
}

const HALF_LIFE_DAYS = 45;
const LOG_WINDOW_DAYS = 60;

interface PurchaseRow { purchased_at: string; quantity: number }
interface UsageRow { created_at: string; delta: number; type: string }

export function predictProduct(db: Db, householdId: string, productId: string, now = clock.now()): Prediction {
  // Purchases from the same day are one shopping trip.
  const purchases = mergeSameDay(
    db.all<PurchaseRow>('SELECT purchased_at, quantity FROM purchases WHERE household_id = ? AND product_id = ? ORDER BY purchased_at', householdId, productId),
  );

  // Purchase-cycle rate: what was bought at trip i lasted until trip i+1.
  const intervals: { days: number; rate: number; ageDays: number }[] = [];
  for (let i = 0; i + 1 < purchases.length; i++) {
    const days = daysBetween(purchases[i].purchased_at, purchases[i + 1].purchased_at);
    if (days < 0.5) continue;
    intervals.push({ days, rate: purchases[i].quantity / days, ageDays: daysBetween(purchases[i + 1].purchased_at, now) });
  }
  const cycleRate = weightedMean(intervals.map((x) => ({ v: x.rate, age: x.ageDays })));
  const avgInterval = weightedMean(intervals.map((x) => ({ v: x.days, age: x.ageDays })));

  // Logged usage over the recent window (manual, voice, recipes, discards).
  const since = new Date(now.getTime() - LOG_WINDOW_DAYS * 86_400_000).toISOString();
  const usage = db.all<UsageRow>(
    `SELECT created_at, delta, type FROM inventory_events
     WHERE household_id = ? AND product_id = ? AND type IN ('consume','cook','discard') AND created_at >= ?`,
    householdId,
    productId,
    since,
  );
  const firstSeen = purchases[0]?.purchased_at ?? usage[0]?.created_at;
  const observedDays = firstSeen ? Math.min(LOG_WINDOW_DAYS, Math.max(1, daysBetween(firstSeen, now))) : 0;
  const loggedTotal = usage.reduce((s, u) => s + -u.delta, 0);
  const loggedRate = observedDays > 0 ? loggedTotal / observedDays : 0;

  let rate: number | null = null;
  if (cycleRate != null) rate = Math.max(cycleRate, loggedRate);
  else if (loggedTotal > 0 && observedDays >= 3) rate = loggedRate;

  const correctionFactor = learnCorrection(db, householdId, productId);
  const implicit = rate != null ? Math.max(0, rate - loggedRate) * correctionFactor : 0;

  // Confidence grows with the number of cycles and falls with their variability.
  const n = intervals.length;
  const base = n === 0 ? (loggedTotal > 0 ? 0.3 : 0.15) : n === 1 ? 0.45 : n === 2 ? 0.6 : n <= 4 ? 0.7 : 0.82;
  const cv = coefficientOfVariation(intervals.map((x) => x.rate));
  const confidence = clamp(base * (1 - Math.min(0.5, cv * 0.5)), 0.05, 0.95);

  const last = purchases[purchases.length - 1]?.purchased_at ?? null;
  let nextDue: string | null = null;
  let overdue = false;
  if (last && avgInterval != null && n >= 2) {
    const due = new Date(new Date(last).getTime() + avgInterval * 86_400_000);
    nextDue = due.toISOString().slice(0, 10);
    overdue = now.getTime() > due.getTime() + Math.max(1, avgInterval * 0.25) * 86_400_000;
  }

  return {
    productId,
    ratePerDay: rate,
    implicitRatePerDay: implicit,
    correctionFactor,
    observations: n + (loggedTotal > 0 ? 1 : 0),
    confidence,
    avgIntervalDays: avgInterval,
    lastPurchaseAt: last,
    nextPurchaseDue: nextDue,
    overdue,
  };
}

export interface StockEstimate {
  confirmed: number;
  estimated: number;
  confidence: number;          // confidence in `estimated`
  daysLeft: number | null;
  runOutOn: string | null;
  showEstimate: boolean;       // false when we don't know enough to show a number
}

/** Estimate remaining stock for a product from its confirmed lots and the prediction. */
export function estimateStock(
  lots: { quantity: number; last_confirmed_at: string; location_kind?: string | null }[],
  pred: Prediction,
  now = clock.now(),
): StockEstimate {
  const confirmed = lots.reduce((s, l) => s + l.quantity, 0);
  if (!lots.length) return { confirmed: 0, estimated: 0, confidence: 1, daysLeft: 0, runOutOn: null, showEstimate: false };
  // Frozen stock is not consumed implicitly.
  const live = lots.filter((l) => l.location_kind !== 'freezer');
  const lastConfirmed = live.reduce((m, l) => (l.last_confirmed_at > m ? l.last_confirmed_at : m), live[0]?.last_confirmed_at ?? now.toISOString());
  const daysSince = Math.max(0, daysBetween(lastConfirmed, now));
  const liveQty = live.reduce((s, l) => s + l.quantity, 0);
  const used = Math.min(liveQty, pred.implicitRatePerDay * daysSince);
  const estimated = confirmed - used;
  // Confidence in the estimate decays as time passes since someone confirmed it.
  const decay = Math.exp(-daysSince / 21);
  const confidence = used <= 1e-9 ? Math.max(0.6, decay) : clamp(pred.confidence * (0.5 + 0.5 * decay), 0.05, 0.95);
  const rate = pred.ratePerDay;
  const daysLeft = rate && rate > 0 ? estimated / rate : null;
  const runOutOn = daysLeft != null ? new Date(now.getTime() + daysLeft * 86_400_000).toISOString().slice(0, 10) : null;
  return {
    confirmed,
    estimated: Math.max(0, estimated),
    confidence,
    daysLeft,
    runOutOn,
    showEstimate: used <= 1e-9 || pred.confidence >= 0.4,
  };
}

/**
 * Learn from corrections: when the user corrects a quantity we stored the estimate they saw.
 * actual usage / predicted usage, recency-weighted, tells us whether we over- or under-estimate.
 */
function learnCorrection(db: Db, householdId: string, productId: string): number {
  // Each correction stores usageRatio (actual usage / predicted usage) in its event meta.
  const rows = db.all<{ meta: string; created_at: string }>(
    `SELECT meta, created_at FROM inventory_events WHERE household_id = ? AND product_id = ? AND type = 'adjust'
     AND meta LIKE '%usageRatio%' ORDER BY created_at DESC LIMIT 12`,
    householdId,
    productId,
  );
  const signal = rows
    .map((r) => ({ v: Number(JSON.parse(r.meta).usageRatio), age: daysBetween(r.created_at, clock.now()) }))
    .filter((x) => Number.isFinite(x.v));
  const m = weightedMean(signal);
  return m == null ? 1 : clamp(m, 0.2, 3);
}

/**
 * Usage ratio for a correction: how much was actually used since the last confirmation,
 * relative to how much we predicted. >1 means we under-estimated consumption.
 */
export function usageRatio(confirmedBefore: number, predictedNow: number, actualNow: number): number | null {
  const predictedUsage = confirmedBefore - predictedNow;
  const actualUsage = confirmedBefore - actualNow;
  if (predictedUsage <= 1e-6) return null;
  return clamp(actualUsage / predictedUsage, 0, 5);
}

function mergeSameDay(rows: PurchaseRow[]): PurchaseRow[] {
  const out: PurchaseRow[] = [];
  for (const r of rows) {
    const last = out[out.length - 1];
    if (last && last.purchased_at.slice(0, 10) === r.purchased_at.slice(0, 10)) last.quantity += r.quantity;
    else out.push({ ...r });
  }
  return out;
}

function weightedMean(xs: { v: number; age: number }[]): number | null {
  if (!xs.length) return null;
  let sw = 0, s = 0;
  for (const x of xs) {
    const w = Math.pow(0.5, Math.max(0, x.age) / HALF_LIFE_DAYS);
    sw += w;
    s += w * x.v;
  }
  return sw > 0 ? s / sw : null;
}

function coefficientOfVariation(xs: number[]): number {
  if (xs.length < 2) return 0;
  const mean = xs.reduce((a, b) => a + b, 0) / xs.length;
  if (mean <= 0) return 0;
  const variance = xs.reduce((a, b) => a + (b - mean) ** 2, 0) / (xs.length - 1);
  return Math.sqrt(variance) / mean;
}

const clamp = (x: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, x));
