import type { Db, Row } from '../db/db.ts';
import { identifyIngredient, onlyHarmless } from './ingredient-match.ts';
import type { Family } from '../db/ingredient-knowledge.ts';
import { newId, parseJson } from '../db/db.ts';
import { clock } from '../clock.ts';
import type { BaseUnit } from './units.ts';

export interface Product {
  id: string;
  household_id: string | null;
  name: string;
  name_nl: string | null;
  brand: string | null;
  category: string;
  barcode: string | null;
  image_url: string | null;
  unit: BaseUnit;
  package_size: number;
  piece_size: number | null;
  piece_name: string | null;
  price: number | null;
  preferred_store: string | null;
  default_location: string;
  shelf_life_days: number | null;
  opened_life_days: number | null;
  freezer_life_days: number | null;
  synonyms: string[];
  /** Per 100 g (or per 100 ml for products measured in ml). */
  nutrition: { kcal: number; protein: number; carbs: number; fat: number; sugars?: number; satFat?: number; fibre?: number; salt?: number } | null;
  /** g per ml, for converting spoons and cups; null = 1. */
  density: number | null;
  nutrition_basis: string | null;
  nutrition_source: string | null;
  staple: boolean;
  package_options: number[]; // common package sizes in base units; empty = one standard size
  allergens: string[];       // EU-14 allergen keys
  diet_flags: string[];      // meat, pork, fish, animal, alcohol
  /** Canonical identity: the family ('milk') and subcategory ('hard_cheese'); custom = a household's own type. */
  family: string | null;
  subcategory: string | null;
  custom: boolean;
  /** Made from a catalogue product: its group (catalogue.group_key), so its other sizes and barcodes find it. */
  catalogue_group?: string | null;
  measure: { recipeUnit?: string; minQty?: number; precision?: number; maxPerServing?: number; smallMeasures?: boolean; source?: string };
}

export function rowToProduct(r: Row): Product {
  return {
    ...(r as any),
    synonyms: parseJson<string[]>(r.synonyms, []),
    nutrition: parseJson(r.nutrition, null),
    staple: !!r.staple,
    package_options: parseJson<number[]>(r.package_options, []),
    allergens: parseJson<string[]>(r.allergens, []),
    diet_flags: parseJson<string[]>(r.diet_flags, []),
    custom: !!r.custom,
    measure: parseJson(r.measure, {}),
  };
}

/** Lower-case, strip accents and punctuation, collapse whitespace. */
export function normalizeText(s: string): string {
  return s
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9%&' ]+/g, ' ')
    .replace(/'s\b/g, 's')
    .replace(/'/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Crude singularisation for English and Dutch plurals, good enough for matching. */
export function stem(word: string): string {
  let w = word;
  if (/^chil+ies$/.test(w)) return w.slice(0, -2); // chillies → chilli, chilies → chili
  if (w.length > 4 && w.endsWith('ies')) return w.slice(0, -3) + 'y';
  if (w.length > 4 && w.endsWith('oes')) return w.slice(0, -2);
  // English "-es" only after s, x, z, ch, sh (boxes, dishes); elsewhere just the "s" (cloves → clove).
  if (w.length > 5 && w.endsWith('en')) w = w.slice(0, -2);
  else if (w.length > 4 && /(s|x|z|ch|sh)es$/.test(w)) w = w.slice(0, -2);
  else if (w.length > 3 && w.endsWith('s') && !w.endsWith('ss')) w = w.slice(0, -1);
  // Dutch doubled consonant after plural removal (tomaten → tomat, bessen → bess → bes)
  if (w.length > 3 && w[w.length - 1] === w[w.length - 2]) w = w.slice(0, -1);
  return w;
}

const stemPhrase = (s: string) => normalizeText(s).split(' ').map(stem).join(' ');

/**
 * A lower bound on the edit distance from letter counts alone (each edit changes at most two counts):
 * cheap enough to rule out most pairs before the full comparison.
 */
function bagDistance(a: string, b: string): number {
  const counts = new Map<string, number>();
  for (const c of a) counts.set(c, (counts.get(c) ?? 0) + 1);
  for (const c of b) counts.set(c, (counts.get(c) ?? 0) - 1);
  let pos = 0, neg = 0;
  for (const v of counts.values()) if (v > 0) pos += v; else neg -= v;
  return Math.max(pos, neg);
}

function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  const m = a.length, n = b.length;
  if (!m) return n;
  if (!n) return m;
  let prev = Array.from({ length: n + 1 }, (_, i) => i);
  for (let i = 1; i <= m; i++) {
    const cur = [i];
    for (let j = 1; j <= n; j++) {
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    }
    prev = cur;
  }
  return prev[n];
}

export interface MatchCandidate {
  product: Product;
  score: number; // 0..1
  matched: string;
}

/**
 * Score how well a free-text name matches a product.
 * 1.0 exact synonym, ~0.9 stem-exact, ~0.75 all query tokens contained, fuzzy below that.
 */
// Normalised and stemmed names per product object, computed once (a product row is re-read as a new object,
// so changes to a product are picked up).
const namesMemo = new WeakMap<Product, { name: string; n: string; ns: string; nt: string[] }[]>();
function normalisedNames(p: Product) {
  let v = namesMemo.get(p);
  if (!v) {
    v = [p.name, p.name_nl ?? '', ...p.synonyms].filter(Boolean).map((name) => {
      const ns = stemPhrase(name);
      return { name, n: normalizeText(name), ns, nt: ns.split(' ') };
    });
    namesMemo.set(p, v);
  }
  return v;
}

export function scoreName(query: string, p: Product): { score: number; matched: string } {
  const q = normalizeText(query);
  const qs = stemPhrase(query);
  if (!q) return { score: 0, matched: '' };
  // Only packaging and filler ("a bag", "uh") names nothing.
  if (onlyHarmless(qs.split(' '))) return { score: 0, matched: '' };
  let best = { score: 0, matched: '' };
  const qt = qs.split(' ');
  for (const { name, n, ns, nt } of normalisedNames(p)) {
    let s = 0;
    if (n === q) s = 1;
    else if (ns === qs) s = 0.95;
    else {
      const contained = qt.every((t) => nt.includes(t));
      const reverse = nt.every((t) => qt.includes(t));
      if (contained) s = 0.7 + 0.2 * (qt.length / nt.length);
      // The product's name inside a longer phrase only counts when the other words are harmless ("fresh
      // spinach" is spinach; "chicken broth" is not chicken).
      else if (reverse && nt.length >= 1 && ns.length >= 3 && onlyHarmless(qt.filter((t) => !nt.includes(t)))) s = 0.65 + 0.2 * (nt.length / qt.length);
      // An edit-distance ratio of 0.75 needs lengths within a quarter of each other: skip the rest.
      else if (Math.abs(qs.length - ns.length) <= Math.max(qs.length, ns.length) * 0.25 && bagDistance(qs, ns) <= Math.max(qs.length, ns.length) * 0.25) {
        const d = levenshtein(qs, ns);
        const ratio = 1 - d / Math.max(qs.length, ns.length);
        if (ratio >= 0.75 && Math.min(qs.length, ns.length) >= 4) s = ratio * 0.8;
      }
    }
    if (s > best.score) best = { score: s, matched: name };
  }
  return best;
}

export function listProducts(db: Db, householdId: string): Product[] {
  return db
    .all('SELECT * FROM products WHERE household_id IS NULL OR household_id = ? ORDER BY name', householdId)
    .map(rowToProduct);
}

export function getProduct(db: Db, id: string): Product | undefined {
  const r = db.get('SELECT * FROM products WHERE id = ?', id);
  return r ? rowToProduct(r) : undefined;
}

/**
 * Find products matching a name. Household products and products currently in stock
 * get a small boost, so "the milk" resolves to the milk you actually have.
 */
export function matchProducts(db: Db, householdId: string, query: string, limit = 5, products?: Product[]): MatchCandidate[] {
  // Without a household (the bulk importer) nothing is in stock; the importer also passes the product list once.
  const inStock = new Set(
    householdId ? db.all<{ product_id: string }>("SELECT DISTINCT product_id FROM inventory_lots WHERE household_id = ? AND status = 'active'", householdId).map((r) => r.product_id) : [],
  );
  const out: MatchCandidate[] = [];
  for (const p of products ?? listProducts(db, householdId)) {
    const { score, matched } = scoreName(query, p);
    if (score <= 0.5) continue;
    let s = score;
    if (inStock.has(p.id)) s += 0.04;
    if (p.household_id) s += 0.02;
    out.push({ product: p, score: Math.min(1, s), matched });
  }
  return out.sort((a, b) => b.score - a.score).slice(0, limit);
}

/**
 * Type-ahead: products whose name (English, Dutch or a synonym) starts with what's typed so far, then those
 * with a word starting with it, then those containing it. Shorter names first, so "olive" offers Olives
 * before Olive oil. Falls back to the fuzzy match for typos.
 */
export function suggestProducts(db: Db, householdId: string, query: string, limit = 8, products?: Product[]): Product[] {
  const q = normalizeText(query);
  if (q.length < 2) return [];
  const all = products ?? listProducts(db, householdId);
  const ranked: { p: Product; rank: number; len: number }[] = [];
  for (const p of all) {
    let rank = 0;
    let len = Infinity;
    for (const { n } of normalisedNames(p)) {
      const r = n.startsWith(q) ? 3 : n.split(' ').some((w) => w.startsWith(q)) ? 2 : q.length >= 3 && n.includes(q) ? 1 : 0;
      if (r > rank || (r === rank && r > 0 && n.length < len)) {
        rank = r;
        len = n.length;
      }
    }
    if (rank) ranked.push({ p, rank, len });
  }
  ranked.sort((a, b) => b.rank - a.rank || a.len - b.len || a.p.name.localeCompare(b.p.name));
  const out = ranked.slice(0, limit).map((r) => r.p);
  if (out.length < limit && q.length >= 4) {
    for (const c of matchProducts(db, householdId, query, limit, all)) if (!out.includes(c.product) && out.length < limit) out.push(c.product);
  }
  return out;
}

/**
 * Several items typed at once ("mushrooms, olives and coriander"): one product per item, or null when
 * nothing fits. An exact or confident match wins; otherwise the best type-ahead suggestion.
 */
export function resolveList(db: Db, householdId: string, text: string): { term: string; product: Product | null }[] {
  const all = listProducts(db, householdId);
  const terms = [...new Set(text.split(/\s*(?:[,;\n/+]|\s(?:and|en|&)\s)\s*/i).map((t) => t.trim()).filter((t) => t.length > 1))].slice(0, 30);
  return terms.map((term) => {
    const r = resolveProduct(db, householdId, term, all);
    return { term, product: r.product ?? suggestProducts(db, householdId, term, 1, all)[0] ?? r.candidates[0]?.product ?? null };
  });
}

/** Best confident match or null. Confident = high score and clear lead over the runner-up. */
export interface Resolved { product: Product | null; candidates: MatchCandidate[]; family?: Family; foreignKey?: string }

/**
 * The product a name refers to. First by coverage (ingredient-match.ts): an exact product, a family to ask
 * about ("milk"), or a known foreign ingredient ("habanero"). Only then fuzzy, for typos.
 */
export function resolveProduct(db: Db, householdId: string, query: string, products?: Product[]): Resolved {
  const m = identifyIngredient(db, householdId, query, { products });
  if (m.kind === 'product') return { product: m.product!, candidates: [{ product: m.product!, score: 1, matched: query }, ...m.alternatives.map((p) => ({ product: p, score: 0.9, matched: query }))] };
  if (m.kind === 'family') {
    const ids = m.family!.variants.flatMap((v) => (typeof v === 'string' ? [v] : v.variants));
    const all = products ?? listProducts(db, householdId);
    const own = all.filter((p) => p.family === m.family!.id && p.household_id);
    const variants = [...ids.map((id) => all.find((p) => p.id === id)).filter((p): p is Product => !!p), ...own];
    return { product: null, family: m.family, candidates: variants.map((p) => ({ product: p, score: 0.9, matched: query })) };
  }
  if (m.kind === 'foreign') return { product: null, foreignKey: m.foreignKey, candidates: [] };
  const c = matchProducts(db, householdId, query, 5, products);
  if (!c.length) return { product: null, candidates: [] };
  const [a, b] = c;
  const clear = !b || a.score - b.score >= 0.08 || a.score >= 0.99;
  return { product: a.score >= 0.7 && clear ? a.product : null, candidates: c };
}

export interface NewProductInput {
  name: string;
  name_nl?: string | null;
  brand?: string | null;
  category?: string;
  barcode?: string | null;
  image_url?: string | null;
  unit?: BaseUnit;
  package_size?: number;
  piece_size?: number | null;
  piece_name?: string | null;
  price?: number | null;
  preferred_store?: string | null;
  default_location?: string;
  shelf_life_days?: number | null;
  synonyms?: string[];
  nutrition?: Product['nutrition'];
  nutrition_source?: string | null;
  density?: number | null;
  allergens?: string[];
  diet_flags?: string[];
  family?: string | null;
  subcategory?: string | null;
  custom?: boolean;
  measure?: Product['measure'];
}

/** Guess sensible defaults for a product nobody has seen before. */
export function guessDefaults(name: string): Pick<Product, 'category' | 'unit' | 'package_size' | 'default_location' | 'shelf_life_days'> {
  const n = normalizeText(name);
  const has = (...w: string[]) => w.some((x) => n.includes(x));
  if (has('diepvries', 'frozen', 'ijs ')) return { category: 'frozen', unit: 'g', package_size: 450, default_location: 'freezer', shelf_life_days: 180 };
  if (has('melk', 'milk', 'sap', 'juice', 'drink', 'water', 'cola', 'bier', 'wijn', 'wine')) return { category: 'drinks', unit: 'ml', package_size: 1000, default_location: 'fridge', shelf_life_days: 10 };
  if (has('kaas', 'cheese', 'yoghurt', 'kwark', 'vla', 'room')) return { category: 'dairy', unit: 'g', package_size: 250, default_location: 'fridge', shelf_life_days: 14 };
  if (has('kip', 'chicken', 'gehakt', 'beef', 'rund', 'varken', 'pork', 'vis', 'fish', 'zalm', 'worst', 'sausage')) return { category: 'meat_fish', unit: 'g', package_size: 300, default_location: 'fridge', shelf_life_days: 4 };
  if (has('brood', 'bread', 'bol', 'roll')) return { category: 'bakery', unit: 'pcs', package_size: 1, default_location: 'pantry', shelf_life_days: 4 };
  return { category: 'other', unit: 'pcs', package_size: 1, default_location: 'pantry', shelf_life_days: 30 };
}

export function createProduct(db: Db, householdId: string, input: NewProductInput): Product {
  const d = guessDefaults(input.name);
  const id = newId('p');
  const syn = new Set((input.synonyms ?? []).map((s) => normalizeText(s)));
  syn.add(normalizeText(input.name));
  if (input.name_nl) syn.add(normalizeText(input.name_nl));
  db.insert('products', {
    id,
    household_id: householdId,
    name: input.name.trim(),
    name_nl: input.name_nl ?? null,
    brand: input.brand ?? null,
    category: input.category ?? d.category,
    barcode: input.barcode || null,
    image_url: input.image_url ?? null,
    unit: input.unit ?? d.unit,
    package_size: input.package_size ?? d.package_size,
    piece_size: input.piece_size ?? null,
    piece_name: input.piece_name ?? null,
    price: input.price ?? null,
    preferred_store: input.preferred_store ?? null,
    default_location: input.default_location ?? d.default_location,
    shelf_life_days: input.shelf_life_days ?? d.shelf_life_days,
    synonyms: [...syn],
    nutrition: input.nutrition ?? null,
    density: input.density ?? null,
    nutrition_basis: input.nutrition ? 'per100' : null,
    nutrition_source: input.nutrition_source ?? (input.nutrition ? 'user' : null),
    allergens: input.allergens ?? [],
    diet_flags: input.diet_flags ?? [],
    family: input.family ?? null,
    subcategory: input.subcategory ?? null,
    custom: input.custom ? 1 : 0,
    measure: input.measure ?? {},
    created_at: clock.iso(),
  });
  return getProduct(db, id)!;
}

/**
 * A household's own type of a family ("goat milk", "Old Amsterdam"), when none of the built-in variants fits.
 * It takes the family's structure (unit, pack size, storage, allergens, diet) from the everyday variant, so stock
 * and recipes work, but not its nutrition: that stays empty unless you give it, rather than being guessed.
 * Kept in the household's own products; the shared catalogue isn't touched.
 */
export function createCustomType(db: Db, householdId: string, familyId: string, name: string, extra: Partial<NewProductInput> = {}): Product {
  const base = db.get('SELECT * FROM products WHERE family = ? AND household_id IS NULL ORDER BY id LIMIT 1', familyId);
  const template = base ? rowToProduct(base) : null;
  const clean = name.trim().replace(/\s+/g, ' ');
  const existing = db.get("SELECT * FROM products WHERE household_id = ? AND family = ? AND lower(name) = lower(?)", householdId, familyId, clean);
  if (existing) return rowToProduct(existing);
  return createProduct(db, householdId, {
    name: clean.charAt(0).toUpperCase() + clean.slice(1),
    category: template?.category, unit: template?.unit, package_size: template?.package_size, piece_size: template?.piece_size ?? null, piece_name: template?.piece_name ?? null,
    default_location: template?.default_location, shelf_life_days: template?.shelf_life_days ?? null, density: template?.density ?? null,
    allergens: template?.allergens, diet_flags: template?.diet_flags, family: familyId, subcategory: template?.subcategory ?? null, measure: template?.measure, custom: true,
    ...extra,
  });
}

export function updateProduct(db: Db, householdId: string, id: string, patch: Partial<NewProductInput>) {
  const p = getProduct(db, id);
  if (!p) return undefined;
  // Built-in catalogue rows are shared: copy-on-write would be needed for per-household edits.
  // For simplicity a household may edit price/store/location/barcode on catalogue rows (single-tenant deployments).
  const allowed: Row = {};
  for (const k of ['name', 'name_nl', 'brand', 'category', 'barcode', 'image_url', 'unit', 'package_size', 'piece_size', 'piece_name', 'price', 'preferred_store', 'default_location', 'shelf_life_days'] as const) {
    if (patch[k] !== undefined) allowed[k] = patch[k];
  }
  if (patch.synonyms) allowed.synonyms = [...new Set([...p.synonyms, ...patch.synonyms.map(normalizeText)])];
  if (p.household_id && p.household_id !== householdId) return undefined;
  db.update('products', id, allowed);
  return getProduct(db, id);
}

/** Remember an extra name for a product (learning from corrections). */
export function addSynonym(db: Db, productId: string, name: string) {
  const p = getProduct(db, productId);
  if (!p) return;
  const n = normalizeText(name);
  if (!n || p.synonyms.includes(n)) return;
  db.update('products', productId, { synonyms: [...p.synonyms, n] });
}

export function displayName(p: Pick<Product, 'name' | 'name_nl'>, lang: 'en' | 'nl') {
  return lang === 'nl' && p.name_nl ? p.name_nl : p.name;
}
