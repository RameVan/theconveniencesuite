// Recipes without typing them out, and without AI:
// - from one sentence ("Save this recipe: chicken fajitas with peppers, onion, rice and avocado"), with
//   amounts and method borrowed from the closest library recipe, or sensible per-serving defaults;
// - from what's in stock: the most at-risk food, combined by a small set of cooking patterns
//   (stir-fry, curry, pasta, frittata, traybake, soup, pan).
// Every amount that was guessed says so, and the recipe is saved to My recipes, where it can be edited.
import type { Db } from '../db/db.ts';
import { AppError } from '../errors.ts';
import { parseIngredientLine } from './recipe-import.ts';
import { listProducts, normalizeText, stem, displayName, type Product } from './products.ts';
import { createRecipe, listRecipes, recordInteraction, type Recipe, type RecipeInput } from './recipes.ts';
import { inventorySummary } from './inventory.ts';
import { autoPlanPrefs } from './autoplan.ts';
import { FAMILIES } from '../db/ingredient-knowledge.ts';
import { familyPref } from './substitutions.ts';

type Lang = 'en' | 'nl';

const STARCH: Record<string, number> = {
  p_rice: 75, p_pasta: 90, p_noodles: 80, p_couscous: 70, p_bulgur: 70, p_quinoa: 65, p_gnocchi: 200, p_lasagne: 60,
  p_potatoes: 250, p_sweet_potato: 200, p_bread: 70, p_oats: 50,
};
const HERBS = new Set(['p_parsley', 'p_coriander', 'p_basil', 'p_dill', 'p_mint']);
const NOT_COOKING_VEG = new Set(['p_apples', 'p_bananas', 'p_berries', 'p_oranges', 'p_lemon', 'p_lime', 'p_avocado', 'p_potatoes', 'p_sweet_potato']);
const PROTEIN_IDS = new Set(['p_eggs', 'p_tofu', 'p_tempeh', 'p_veggie_mince', 'p_chickpeas', 'p_kidney_beans', 'p_black_beans', 'p_white_beans', 'p_brown_beans', 'p_lentils']);
const PER_SERVING: Record<string, number> = {
  p_eggs: 2, p_garlic: 1, p_onion: 0.5, p_red_onion: 0.5, p_spring_onion: 1, p_lemon: 0.25, p_lime: 0.25, p_chili: 0.25, p_avocado: 0.5, p_bell_pepper: 0.5,
  p_ginger: 5, p_spinach: 75, p_kale: 75, p_tofu: 100, p_tempeh: 100, p_veggie_mince: 100, p_wraps: 2, p_pita: 1, p_stock_cube: 0.5,
  p_olive_oil: 7.5, p_sunflower_oil: 7.5, p_butter: 10, p_soy_sauce: 10, p_pesto: 40, p_curry_paste: 15, p_tomato_paste: 15, p_peanut_butter: 20,
  p_mustard: 5, p_honey: 7, p_sambal: 3, p_ketchup: 15, p_mayonnaise: 15, p_cream: 50, p_creme_fraiche: 50, p_coconut_milk: 100, p_yoghurt: 75,
  p_milk: 100, p_cheese: 30, p_parmesan: 15, p_feta: 35, p_mozzarella: 40, p_canned_tomatoes: 100, p_passata: 100, p_corn: 70,
  p_chickpeas: 100, p_kidney_beans: 100, p_black_beans: 100, p_white_beans: 100, p_brown_beans: 100, p_lentils: 60,
};

/** A sensible amount of a product for a number of servings, in its base unit. */
export function defaultAmount(p: Product, servings: number): number {
  let per = STARCH[p.id] ?? PER_SERVING[p.id];
  if (per == null) {
    if (HERBS.has(p.id)) per = 3;
    else if (p.category === 'spices') per = 1;
    else if (p.category === 'meat_fish') per = p.unit === 'pcs' ? 1 : 125;
    else if (p.unit === 'pcs') per = Math.min(1, Math.max(0.25, 80 / (p.piece_size ?? 100)));
    else if (p.category === 'produce') per = 80;
    else per = 50;
  }
  const total = per * servings;
  if (p.unit === 'pcs') return Math.max(1, Math.round(total * 2) / 2);
  return total >= 50 ? Math.round(total / 5) * 5 : Math.round(total * 10) / 10;
}

const STOP = new Set(['with', 'and', 'the', 'a', 'met', 'en', 'de', 'het', 'een', 'van', 'of', 'in']);
const words = (s: string) => normalizeText(s).split(' ').filter((w) => w && !STOP.has(w)).map(stem);

/** The library recipe whose title shares the most words with this one (at least half of them). */
function closestRecipe(recipes: Recipe[], title: string): Recipe | null {
  const q = new Set(words(title));
  if (!q.size) return null;
  let best: { r: Recipe; s: number } | null = null;
  for (const r of recipes) {
    const t = new Set(words(r.title));
    const hit = [...q].filter((w) => t.has(w)).length;
    const s = hit / q.size - t.size * 0.01; // the shorter, closer title wins a tie
    if (hit && hit / q.size >= 0.5 && (!best || s > best.s)) best = { r, s };
  }
  return best?.r ?? null;
}

const EMOJI: [RegExp, string][] = [
  [/taco|fajita|burrito|quesadilla|enchilada/, '🌮'], [/curry|dal|masala|korma/, '🍛'], [/pasta|spaghetti|lasagn|macaroni|penne/, '🍝'], [/soup|soep|stew|stoof/, '🍲'],
  [/salad|salade/, '🥗'], [/pizza/, '🍕'], [/burger/, '🍔'], [/noodle|ramen|bami|mie/, '🍜'], [/rice|rijst|nasi|risotto|paella/, '🍚'], [/fish|vis|salmon|zalm|cod|kabeljauw/, '🐟'],
  [/egg|omelet|frittata|ei\b/, '🍳'], [/pancake|pannenkoe/, '🥞'], [/stamppot|potato|aardappel/, '🥔'], [/wrap|pita/, '🌯'],
];
export const emojiFor = (title: string) => EMOJI.find(([re]) => re.test(title.toLowerCase()))?.[1] ?? '🍽️';
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);
const nameOf = (p: Product, lang: Lang) => displayName(p, lang).toLowerCase();
const listOf = (xs: string[], lang: Lang) => (xs.length <= 1 ? xs.join('') : `${xs.slice(0, -1).join(', ')} ${lang === 'nl' ? 'en' : 'and'} ${xs[xs.length - 1]}`);

/** A plain method from what each ingredient is: starch, protein, vegetables, herbs. */
export function genericSteps(ps: Product[], lang: Lang): { text: string; timerSeconds?: number }[] {
  const nl = lang === 'nl';
  const starch = ps.find((p) => STARCH[p.id] != null);
  const protein = ps.filter((p) => p.category === 'meat_fish' || PROTEIN_IDS.has(p.id));
  const veg = ps.filter((p) => p.category === 'produce' && !HERBS.has(p.id) && !NOT_COOKING_VEG.has(p.id));
  const herbs = ps.filter((p) => HERBS.has(p.id) || p.id === 'p_avocado' || p.id === 'p_lime' || p.id === 'p_lemon');
  const out: { text: string; timerSeconds?: number }[] = [];
  if (starch) out.push({ text: nl ? `Kook of bereid de ${nameOf(starch, lang)} volgens de verpakking.` : `Cook the ${nameOf(starch, lang)} as the pack says.`, timerSeconds: starch.id === 'p_potatoes' ? 1200 : 720 });
  if (veg.length) out.push({ text: nl ? `Was en snijd ${listOf(veg.map((p) => `de ${nameOf(p, lang)}`), lang)}.` : `Wash and cut the ${listOf(veg.map((p) => nameOf(p, lang)), lang)}.` });
  if (protein.length) out.push({ text: nl ? `Bak ${listOf(protein.map((p) => `de ${nameOf(p, lang)}`), lang)} in wat olie gaar.` : `Cook the ${listOf(protein.map((p) => nameOf(p, lang)), lang)} in a little oil until done.`, timerSeconds: 480 });
  if (veg.length) out.push({ text: nl ? 'Voeg de groente toe en bak tot ze net zacht is.' : 'Add the vegetables and cook until just tender.', timerSeconds: 360 });
  out.push({ text: nl ? `Breng op smaak met zout en peper${herbs.length ? ` en maak af met ${listOf(herbs.map((p) => nameOf(p, lang)), lang)}` : ''}.` : `Season with salt and pepper${herbs.length ? ` and finish with ${listOf(herbs.map((p) => nameOf(p, lang)), lang)}` : ''}.` });
  if (starch) out.push({ text: nl ? `Serveer met de ${nameOf(starch, lang)}.` : `Serve with the ${nameOf(starch, lang)}.` });
  return out;
}

const PREFIX = /^(?:please\s+|graag\s+)?(?:save|add|create|make|store|new|bewaar|sla|maak|voeg|nieuw)\b(?:\s+(?:this|a|an|my|the|dit|een|mijn|het|nieuw|new))*\s*(?:recipe|recept)\b(?:\s+(?:for|voor|op|toe|called|genaamd|named))*\s*[:\-–]?\s*/i;

/** "Save this recipe: X with a, b and c" → the part after the command. */
export function stripRecipeCommand(text: string) {
  return text.trim().replace(PREFIX, '').replace(/\s+(?:op|toe)\s*$/i, '').trim();
}

export interface QuickResult { recipe: Recipe; existing: boolean; template: string | null; guessed: number; unmatched: string[] }

/**
 * Structure a recipe from one sentence and save it. Without ingredients, a library recipe with that name
 * is saved instead.
 */
export function recipeFromSentence(db: Db, householdId: string, text: string, opts: { servings?: number; lang?: Lang } = {}): QuickResult {
  const lang = opts.lang ?? 'en';
  const body = stripRecipeCommand(text).replace(/[.!?]+$/, '');
  const [titlePart, ...rest] = body.split(/\s+(?:with|met)\s+/i);
  const title = cap(titlePart.trim());
  if (!title) throw new AppError(422, 'no_title', lang === 'nl' ? 'Welk recept? Bijvoorbeeld “bewaar recept: kip fajitas met paprika, ui en rijst”.' : 'Which recipe? For example “save recipe: chicken fajitas with peppers, onion and rice”.');
  const recipes = listRecipes(db, householdId);
  const template = closestRecipe(recipes, title);

  const parts = rest.join(' with ').split(/,|;|\s+(?:and|en|&|plus)\s+/i).map((s) => s.trim()).filter(Boolean);
  if (!parts.length) {
    if (template) {
      recordInteraction(db, householdId, template.id, { saved: true });
      return { recipe: template, existing: true, template: template.title, guessed: 0, unmatched: [] };
    }
    throw new AppError(422, 'no_ingredients', lang === 'nl' ? `Wat gaat er in ${title}? Zeg bijvoorbeeld “${title} met kip, paprika en rijst”.` : `What goes into ${title}? Say for example “${title} with chicken, peppers and rice”.`);
  }

  const servings = opts.servings ?? autoPlanPrefs(db, householdId).householdSize ?? 2;
  const all = listProducts(db, householdId);
  const byId = new Map(all.map((p) => [p.id, p]));
  let guessed = 0;
  const unmatched: string[] = [];
  const ingredients: RecipeInput['ingredients'] = [];
  const seen = new Set<string>();
  for (const part of parts) {
    const line = parseIngredientLine(db, householdId, part);
    const p = line.productId ? byId.get(line.productId) : undefined;
    if (!p) {
      unmatched.push(part);
      ingredients.push({ name: part, display: part });
      continue;
    }
    if (seen.has(p.id)) continue;
    seen.add(p.id);
    let qty = line.quantity;
    if (qty == null) {
      const fromTemplate = template?.ingredients.find((i) => i.product_id === p.id && i.quantity != null);
      qty = fromTemplate ? Math.round(((fromTemplate.quantity! * servings) / template!.servings) * 10) / 10 : defaultAmount(p, servings);
      guessed++;
    }
    ingredients.push({ product_id: p.id, name: p.name, quantity: qty, unit: p.unit, display: part });
  }
  // Food named in the title counts too: "chicken fajitas with peppers…" has chicken. Prefer the product the
  // matching library recipe uses (chicken breast rather than thighs), then the longest name.
  const tw = new Set(words(title));
  const inTemplate = new Set(template?.ingredients.map((i) => i.product_id) ?? []);
  const named = all
    .filter((p) => !seen.has(p.id) && (p.category === 'meat_fish' || PROTEIN_IDS.has(p.id) || p.category === 'produce' || STARCH[p.id] != null))
    .map((p) => ({ p, n: Math.max(0, ...[p.name, p.name_nl ?? '', ...p.synonyms].map((s) => words(s)).filter((w) => w.length && w.every((x) => tw.has(x))).map((w) => w.length)) }))
    .filter((x) => x.n > 0)
    .sort((a, b) => Number(inTemplate.has(b.p.id)) - Number(inTemplate.has(a.p.id)) || b.n - a.n);
  // At most one protein, one starch and three foods in all from the title.
  let proteinTaken = false;
  let starchTaken = [...seen].some((id) => STARCH[id] != null);
  let fromTitle = 0;
  for (const { p } of named) {
    if (fromTitle >= 3) break;
    const isProtein = p.category === 'meat_fish' || PROTEIN_IDS.has(p.id);
    const isStarch = STARCH[p.id] != null;
    if ((isProtein && proteinTaken) || (isStarch && starchTaken)) continue;
    proteinTaken ||= isProtein;
    starchTaken ||= isStarch;
    fromTitle++;
    seen.add(p.id);
    const fromTemplate = template?.ingredients.find((i) => i.product_id === p.id && i.quantity != null);
    const qty = fromTemplate ? Math.round(((fromTemplate.quantity! * servings) / template!.servings) * 10) / 10 : defaultAmount(p, servings);
    guessed++;
    ingredients.unshift({ product_id: p.id, name: p.name, quantity: qty, unit: p.unit, display: displayName(p, lang) });
  }
  // A family word in the title ("chicken fajitas"): the household's usual type, the one the matching
  // library recipe uses, or the everyday default.
  if (!proteinTaken) {
    for (const f of FAMILIES) {
      if (!f.words.some((w) => words(w).every((x) => tw.has(x)))) continue;
      const ids = f.variants.flatMap((v) => (typeof v === 'string' ? [v] : v.variants));
      const pick = familyPref(db, householdId, f.id) ?? ids.find((id) => inTemplate.has(id)) ?? ids[0];
      const p = byId.get(pick);
      if (!p || seen.has(p.id)) continue;
      seen.add(p.id);
      const fromTemplate = template?.ingredients.find((i) => i.product_id === p.id && i.quantity != null);
      const qty = fromTemplate ? Math.round(((fromTemplate.quantity! * servings) / template!.servings) * 10) / 10 : defaultAmount(p, servings);
      guessed++;
      ingredients.unshift({ product_id: p.id, name: p.name, quantity: qty, unit: p.unit, display: displayName(p, lang), match: 'equivalent', source_key: `f:${f.id}` });
      break;
    }
  }
  // Borrow the method only when the library recipe really is the same dish (shares most ingredients).
  const shared = template ? template.ingredients.filter((i) => i.product_id && seen.has(i.product_id)).length : 0;
  const useTemplate = !!template && shared >= Math.max(1, Math.ceil(seen.size / 2));
  const products = [...seen].map((id) => byId.get(id)!);
  const nl = lang === 'nl';
  const input: RecipeInput = {
    title,
    summary: guessed
      ? nl ? 'Hoeveelheden zijn geschat: pas ze aan na de eerste keer koken.' : 'Amounts are estimates: adjust them after the first time you cook it.'
      : null,
    cuisine: useTemplate ? template!.cuisine : null,
    tags: useTemplate ? template!.tags.filter((t) => t !== 'breakfast') : [],
    servings,
    prep_minutes: useTemplate ? template!.prep_minutes : 15,
    cook_minutes: useTemplate ? template!.cook_minutes : 20,
    difficulty: 'easy',
    emoji: useTemplate ? template!.emoji : emojiFor(title),
    color: useTemplate ? template!.color : null,
    origin: 'user',
    steps: useTemplate ? template!.steps.map((s: any) => ({ text: s.text, timerSeconds: s.timerSeconds })) : genericSteps(products, lang),
    ingredients,
  };
  const recipe = createRecipe(db, householdId, input);
  recordInteraction(db, householdId, recipe.id, { saved: true });
  return { recipe, existing: false, template: useTemplate ? template!.title : null, guessed, unmatched };
}

// ---------- From what's in stock ----------

type Pattern = 'stir-fry' | 'curry' | 'pasta' | 'frittata' | 'traybake' | 'soup' | 'pan';

/**
 * A use-it-up recipe from the food at most risk of going off, saved to My recipes. Amounts never exceed
 * what's in stock.
 */
export function recipeFromStock(db: Db, householdId: string, opts: { servings?: number; lang?: Lang } = {}) {
  const lang = opts.lang ?? 'en';
  const nl = lang === 'nl';
  const servings = opts.servings ?? autoPlanPrefs(db, householdId).householdSize ?? 2;
  const items = inventorySummary(db, householdId).items.filter((s) => s.confirmed > 0 && s.status !== 'expired');
  // Most urgent first: closest expiry, then the shortest shelf life.
  const urgency = (s: (typeof items)[number]) => (s.daysToExpiry ?? 60) + (s.product.shelf_life_days ?? 60) / 30;
  const sorted = [...items].sort((a, b) => urgency(a) - urgency(b));
  const have = (id: string) => items.find((s) => s.product.id === id);
  const first = (pred: (p: Product) => boolean) => sorted.find((s) => pred(s.product));

  const protein = first((p) => (p.category === 'meat_fish' && p.id !== 'p_tuna') || PROTEIN_IDS.has(p.id));
  const veg = sorted.filter((s) => s.product.category === 'produce' && !HERBS.has(s.product.id) && !NOT_COOKING_VEG.has(s.product.id) && !['p_onion', 'p_red_onion', 'p_garlic', 'p_ginger', 'p_chili', 'p_spring_onion'].includes(s.product.id)).slice(0, 3);
  if (!protein && veg.length < 2) {
    throw new AppError(422, 'too_little_stock', nl ? 'Er is te weinig in huis om iets van te maken. Voeg eerst je boodschappen toe.' : 'There isn’t enough in stock to make something yet. Add your groceries first.');
  }
  const has = (id: string) => !!have(id);
  const starchItem = first((p) => STARCH[p.id] != null && p.id !== 'p_bread' && p.id !== 'p_oats' && p.id !== 'p_lasagne');
  let pattern: Pattern = 'pan';
  if ((has('p_curry_paste') || has('p_curry_powder')) && has('p_coconut_milk')) pattern = 'curry';
  else if (starchItem && ['p_pasta', 'p_gnocchi'].includes(starchItem.product.id) && (has('p_pesto') || has('p_canned_tomatoes') || has('p_passata') || has('p_cream'))) pattern = 'pasta';
  else if (starchItem && ['p_noodles', 'p_rice'].includes(starchItem.product.id) && has('p_soy_sauce')) pattern = 'stir-fry';
  else if (protein?.product.id === 'p_eggs' || (!protein && has('p_eggs'))) pattern = 'frittata';
  else if (starchItem && ['p_potatoes', 'p_sweet_potato'].includes(starchItem.product.id) && !['p_minced_beef', 'p_veggie_mince'].includes(protein?.product.id ?? '')) pattern = 'traybake';
  else if (veg.length >= 2 && has('p_stock_cube') && !protein) pattern = 'soup';

  const picked: { s: (typeof items)[number]; qty?: number }[] = [];
  const add = (s: (typeof items)[number] | undefined, qty?: number) => {
    if (s && !picked.some((x) => x.s.product.id === s.product.id)) picked.push({ s, qty });
  };
  const mainProtein = pattern === 'frittata' ? have('p_eggs') : protein;
  add(mainProtein);
  veg.forEach((v) => add(v));
  if (['curry', 'pasta', 'stir-fry', 'traybake', 'pan'].includes(pattern)) add(starchItem);
  add(have('p_onion') ?? have('p_red_onion'));
  add(have('p_garlic'));
  const sauce: Record<Pattern, string[]> = {
    curry: ['p_curry_paste', 'p_curry_powder', 'p_coconut_milk'], pasta: ['p_pesto', 'p_passata', 'p_canned_tomatoes', 'p_cream', 'p_parmesan'],
    'stir-fry': ['p_soy_sauce', 'p_ginger'], frittata: ['p_cheese', 'p_feta', 'p_milk'], traybake: ['p_paprika_powder'], soup: ['p_stock_cube', 'p_canned_tomatoes'], pan: ['p_paprika_powder', 'p_soy_sauce'],
  };
  for (const id of sauce[pattern]) {
    if (pattern === 'pasta' && picked.some((x) => ['p_pesto', 'p_passata', 'p_canned_tomatoes', 'p_cream'].includes(x.s.product.id)) && id !== 'p_parmesan') continue;
    add(have(id));
  }
  if (pattern !== 'soup') add(have('p_olive_oil') ?? have('p_sunflower_oil') ?? have('p_butter'));

  const ingredients: RecipeInput['ingredients'] = picked.map(({ s }) => {
    const p = s.product;
    const wanted = pattern === 'frittata' && p.id === 'p_eggs' ? Math.max(2, Math.round(2.5 * servings)) : defaultAmount(p, servings);
    const qty = Math.min(wanted, p.unit === 'pcs' ? Math.floor(s.confirmed * 2) / 2 || s.confirmed : Math.round(s.confirmed));
    return { product_id: p.id, name: p.name, quantity: qty, unit: p.unit, display: p.unit === 'pcs' ? `${qty} ${nameOf(p, lang)}` : `${qty} ${p.unit} ${nameOf(p, lang)}` };
  });

  const main = mainProtein ? nameOf(mainProtein.product, lang) : null;
  const vegNames = veg.slice(0, 2).map((v) => nameOf(v.product, lang));
  const what = listOf([main, ...vegNames].filter(Boolean) as string[], lang).replace(/ and /, ' & ').replace(/ en /, ' & ');
  const PATTERN_NAME: Record<Pattern, [string, string]> = { 'stir-fry': ['stir-fry', 'roerbak'], curry: ['curry', 'curry'], pasta: ['pasta', 'pasta'], frittata: ['frittata', 'frittata'], traybake: ['traybake', 'ovenschotel'], soup: ['soup', 'soep'], pan: ['pan', 'pan'] };
  const title = cap(`${nl ? 'Opmaak-' : 'Use-it-up '}${what} ${PATTERN_NAME[pattern][nl ? 1 : 0]}`);
  const v = listOf(veg.map((x) => nameOf(x.product, lang)), lang);
  const st = starchItem && picked.some((x) => x.s === starchItem) ? nameOf(starchItem.product, lang) : null;
  const S = (en: string, nlT: string, t?: number) => ({ text: nl ? nlT : en, timerSeconds: t });
  const steps: { text: string; timerSeconds?: number }[] = [];
  if (pattern === 'frittata') {
    steps.push(S('Heat the oven grill or keep the pan lid handy.', 'Zet de grill van de oven aan of houd een deksel bij de hand.'));
    steps.push(S(`Fry the onion and ${v || 'vegetables'} in the oil until soft.`, `Bak de ui en ${v || 'de groente'} in de olie zacht.`, 420));
    steps.push(S('Beat the eggs with salt, pepper and the cheese (or a splash of milk) and pour over.', 'Klop de eieren los met zout, peper en de kaas (of een scheutje melk) en giet erover.'));
    steps.push(S('Cook on low heat until almost set, then finish under the grill or with the lid on.', 'Laat op laag vuur bijna stollen en maak af onder de grill of met de deksel erop.', 600));
  } else if (pattern === 'soup') {
    steps.push(S('Chop all the vegetables.', 'Snijd alle groente.'));
    steps.push(S('Soften the onion and garlic, add the vegetables, the stock cube and water to cover.', 'Fruit ui en knoflook, voeg de groente, het bouillonblokje en water tot net onder toe.'));
    steps.push(S('Simmer until everything is soft.', 'Laat zachtjes koken tot alles zacht is.', 1200));
    steps.push(S('Blend (all or half) and season.', 'Pureer (alles of de helft) en breng op smaak.'));
  } else if (pattern === 'traybake') {
    steps.push(S('Heat the oven to 210 °C.', 'Verwarm de oven voor op 210 °C.'));
    steps.push(S(`Cut the ${st ?? 'potatoes'} into chunks, toss with oil and spices and roast.`, `Snijd de ${st ?? 'aardappelen'} in stukken, hussel met olie en kruiden en rooster.`, 1200));
    steps.push(S(`Add ${main ? `the ${main} and ` : ''}${v || 'the vegetables'} and roast until cooked through.`, `Voeg ${main ? `de ${main} en ` : ''}${v || 'de groente'} toe en rooster tot alles gaar is.`, 1200));
  } else {
    if (st) steps.push(S(`Cook the ${st} as the pack says.`, `Kook de ${st} volgens de verpakking.`, 720));
    if (main) steps.push(S(`Cook the ${main} in the oil until done, then take it out of the pan.`, `Bak de ${main} gaar in de olie en haal uit de pan.`, 480));
    steps.push(S(`Fry the onion and garlic, then the ${v || 'vegetables'} until just tender.`, `Fruit ui en knoflook, bak dan ${v || 'de groente'} beetgaar.`, 360));
    if (pattern === 'curry') steps.push(S('Stir in the curry paste for a minute, add the coconut milk and simmer.', 'Roer de currypasta een minuut door, voeg de kokosmelk toe en laat sudderen.', 600));
    if (pattern === 'pasta') steps.push(S('Add the sauce, warm through and toss with the pasta.', 'Voeg de saus toe, warm door en meng met de pasta.'));
    if (pattern === 'stir-fry') steps.push(S('Add the soy sauce (and ginger), toss everything together on high heat.', 'Voeg de sojasaus (en gember) toe en hussel alles op hoog vuur door elkaar.', 120));
    if (main) steps.push(S(`Return the ${main} and season.`, `Doe de ${main} terug in de pan en breng op smaak.`));
    if (st && pattern !== 'pasta') steps.push(S(`Serve with the ${st}.`, `Serveer met de ${st}.`));
  }
  const recipe = createRecipe(db, householdId, {
    title,
    summary: nl ? `Gemaakt van wat je in huis hebt, met ${listOf(sorted.slice(0, 2).filter((s) => picked.some((x) => x.s === s)).map((s) => nameOf(s.product, lang)), lang) || 'je voorraad'} eerst.` : `Made from what you have, using ${listOf(sorted.slice(0, 2).filter((s) => picked.some((x) => x.s === s)).map((s) => nameOf(s.product, lang)), lang) || 'your stock'} first.`,
    tags: ['use-it-up'],
    servings,
    prep_minutes: 10,
    cook_minutes: pattern === 'traybake' ? 40 : pattern === 'soup' ? 30 : 20,
    difficulty: 'easy',
    emoji: { 'stir-fry': '🥘', curry: '🍛', pasta: '🍝', frittata: '🍳', traybake: '🥔', soup: '🍲', pan: '🍳' }[pattern],
    origin: 'user',
    steps,
    ingredients,
  });
  recordInteraction(db, householdId, recipe.id, { saved: true });
  return { recipe, pattern, usesFirst: picked.slice(0, 3).map((x) => nameOf(x.s.product, lang)) };
}
