// Receipt processing: text → structured lines → product matches → review → ledger.
// The rule-based parser handles common Dutch receipt layouts (AH, Jumbo, Lidl, Plus, Dirk, Aldi)
// and generic "name … price" receipts. An AI parser can produce the same ParsedReceipt shape.
import { createHash } from 'node:crypto';
import type { Db } from '../db/db.ts';
import { newId, parseJson } from '../db/db.ts';
import { clock, daysBetween } from '../clock.ts';
import { AppError, conflict, notFound } from '../errors.ts';
import { createProduct, getProduct, matchProducts, normalizeText, type MatchCandidate, type Product } from './products.ts';
import { addStock, deduct, getLot, setLotQuantity, type Ctx } from './ledger.ts';
import { bus } from '../bus.ts';

export interface ReceiptLine {
  raw: string;
  name: string;
  count: number;              // number of units bought (packages or pieces)
  weightKg?: number | null;   // weighed products
  unitPrice?: number | null;
  price: number | null;       // line total before discounts
  discount: number;           // positive amount
  size?: { qty: number; unit: 'g' | 'ml' | 'pcs' } | null; // package size parsed from the name
}

export interface ParsedReceipt {
  store: string | null;
  date: string | null;
  total: number | null;
  lines: ReceiptLine[];
  deposit: number;
  /** Bags and other non-groceries: counted towards the total, never added to stock. */
  extras?: number;
  warnings: string[];
}

const STORES: [RegExp, string][] = [
  [/albert\s*heijn|\bah\b.*(to go|xl)?|ah\.nl/i, 'Albert Heijn'],
  [/jumbo/i, 'Jumbo'],
  [/\blidl\b/i, 'Lidl'],
  [/\bplus\b/i, 'Plus'],
  [/\bdirk\b/i, 'Dirk'],
  [/\baldi\b/i, 'Aldi'],
  [/\bcoop\b/i, 'Coop'],
  [/\bspar\b/i, 'Spar'],
  [/hoogvliet/i, 'Hoogvliet'],
  [/vomar/i, 'Vomar'],
  [/dekamarkt|\bdeka\b/i, 'DekaMarkt'],
  [/ekoplaza/i, 'Ekoplaza'],
  [/picnic/i, 'Picnic'],
];

const SKIP = /\b(btw|vat|pin|pinnen|bankpas|betaald|betaling|wisselgeld|contant|kassa|kassabon|bon\s*nr|transactie|terminal|filiaal|winkel|bedankt|thank|tot ziens|klantenkaart|bonuskaart|airmiles|koopzegel|spaarzegel|aantal|omschrijving|bedrag|prijs|artikelen|subtotaal|sub totaal|maestro|v pay|vpay|visa|mastercard|contactloos|merchant|auth|autorisatie|kaart|app|www|http|tel|kvk|openingstijden|bonus box|uw voordeel|jouw voordeel|waarvan|totaal voordeel|u heeft|gespaard|retour)\b/i;
const TOTAL = /^(totaal|total|te betalen|eindtotaal|totaal te betalen)\b[^\d-]*(-?\d+[.,]\d{2})/i;
const DISCOUNT = /\b(bonus|korting|actie|voordeel|discount|aanbieding|2e halve prijs|1\+1|%)\b/i;
const DEPOSIT = /\b(statiegeld|emballage|deposit|leeggoed)\b/i;
const SUBTOTAL = /^(?:\d{1,3}\s+)?(sub\s*totaal|subtotal)\b[^\d-]*(-?\d+[.,]\d{2})/i;
// Carrier bags are on the receipt but are not groceries.
const NOT_FOOD = /^(draagtas|tas|tasje|plastic tas|papieren tas|boodschappentas|shopper|tassen|carrier bag|bag)\b/i;
// Once the payment starts nothing is a product, even when OCR lost the "TOTAAL" line.
const PAYMENT = /^(betaald met|pinnen|kopie|terminal|merchant|contactloze? betaling|kaarthouder|transactie)\b/i;
const PRICE_AT_END = /(-?\d{1,4}[.,]\d{2})(?:\s*(?:eur|€))?(?:\s+[A-Z]{1,2}|\s+\d{1,2}%?)?\s*$/i;
const QTY_TIMES = /(\d+)\s*[xX×]\s*(?:€\s*)?(\d+[.,]\d{2})/;
const WEIGHT = /(\d+[.,]\d{1,3})\s*kg\s*[xX×@]?\s*(?:€\s*)?(\d+[.,]\d{2})?/i;

const num = (s: string) => Number(s.replace(',', '.'));

/** Parse a package size out of a product name: "1L", "500 g", "10 st", "6x33cl". */
export function parseSize(name: string): ReceiptLine['size'] {
  const m = name.match(/(?:(\d+)\s*[xX]\s*)?(\d+(?:[.,]\d+)?)\s*(kg|g|gr|gram|l|lt|liter|ml|cl|st|stuks|pcs)\b/i);
  if (!m) return null;
  const mult = m[1] ? Number(m[1]) : 1;
  const v = num(m[2]) * mult;
  switch (m[3].toLowerCase()) {
    case 'kg': return { qty: v * 1000, unit: 'g' };
    case 'g': case 'gr': case 'gram': return { qty: v, unit: 'g' };
    case 'l': case 'lt': case 'liter': return { qty: v * 1000, unit: 'ml' };
    case 'ml': return { qty: v, unit: 'ml' };
    case 'cl': return { qty: v * 10, unit: 'ml' };
    default: return { qty: v, unit: 'pcs' };
  }
}

function parseDate(text: string): string | null {
  let m = text.match(/\b(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})\b/);
  if (m) {
    const y = m[3].length === 2 ? `20${m[3]}` : m[3];
    const d = `${y}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
    if (!Number.isNaN(Date.parse(d))) return d;
  }
  m = text.match(/\b(20\d{2})-(\d{2})-(\d{2})\b/);
  return m ? `${m[1]}-${m[2]}-${m[3]}` : null;
}

export function parseReceiptText(text: string): ParsedReceipt {
  // OCR splits amounts ("10, 30") and adds stray marks before the quantity ("SG 1 ROOMK SWEETP").
  const rawLines = text.split(/\r?\n/)
    .map((l) => l.replace(/\s+/g, ' ').trim().replace(/(\d)\s?([.,])\s(\d{2})\b/g, '$1$2$3').replace(/^[^\d\s]{1,3}\s+(?=\d{1,2}\s+\p{L})/u, ''))
    .filter(Boolean);
  const head = rawLines.slice(0, 8).join(' ');
  const store = STORES.find(([re]) => re.test(head))?.[1] ?? STORES.find(([re]) => re.test(text))?.[1] ?? null;
  const out: ParsedReceipt = { store, date: parseDate(text), total: null, lines: [], deposit: 0, warnings: [] };
  let pendingName: string | null = null;
  let pendingQty: number | null = null;
  let subtotal: number | null = null;
  let seenHeader = false;

  for (const line of rawLines) {
    const t = TOTAL.exec(line);
    if (t) {
      out.total = num(t[2]);
      break; // everything after the total is payment details
    }
    if (PAYMENT.test(line)) break;
    const sub = SUBTOTAL.exec(line);
    if (sub) {
      subtotal = num(sub[2]);
      continue;
    }
    if (/\b(aantal|omschrijving)\b/i.test(line)) seenHeader = true;
    // After the subtotal only discounts follow (AH lists bonus there).
    if (subtotal != null && !(DISCOUNT.test(line) && /-\s?\d|\d\s?-/.test(line))) continue;
    if (DEPOSIT.test(line)) {
      const p = PRICE_AT_END.exec(line);
      if (p) out.deposit += num(p[1]);
      continue;
    }
    const priceM = PRICE_AT_END.exec(line);
    const weightM = WEIGHT.exec(line);
    const qtyOnly = line.match(/^(\d+)\s*[xX×]\s*(\d+[.,]\d{2})(?:\s+(-?\d+[.,]\d{2}))?(?:\s*[A-Z]{1,2})?$/);

    // "0,846 kg x 1,99   1,68" — weight line belonging to the pending/previous name
    if (weightM && (!priceM || line.replace(WEIGHT, '').replace(PRICE_AT_END, '').replace(/eur\/kg|€\/kg|\/kg|eur|€/gi, '').trim().length < 3)) {
      const weight = num(weightM[1]);
      const unitPrice = weightM[2] ? num(weightM[2]) : null;
      const price = priceM ? num(priceM[1]) : unitPrice != null ? Math.round(weight * unitPrice * 100) / 100 : null;
      if (pendingName) {
        out.lines.push({ raw: `${pendingName} ${line}`, name: pendingName, count: 1, weightKg: weight, unitPrice, price, discount: 0, size: null });
        pendingName = null;
      } else {
        const prev = out.lines[out.lines.length - 1];
        if (prev) {
          prev.weightKg = weight;
          prev.unitPrice = unitPrice;
          if (price != null && prev.price == null) prev.price = price;
          prev.raw += ` ${line}`;
        }
      }
      continue;
    }

    // "2 x 0,79" on its own line (Jumbo/Plus style): quantity for the previous or next item
    if (qtyOnly) {
      const count = Number(qtyOnly[1]);
      const unit = num(qtyOnly[2]);
      const prev = out.lines[out.lines.length - 1];
      if (qtyOnly[3] && pendingName) {
        out.lines.push({ raw: `${pendingName} ${line}`, name: pendingName, count, unitPrice: unit, price: num(qtyOnly[3]), discount: 0, size: parseSize(pendingName) });
        pendingName = null;
      } else if (prev && prev.price != null && Math.abs(prev.price - count * unit) < 0.02 && prev.count === 1) {
        prev.count = count;
        prev.unitPrice = unit;
      } else if (pendingName) {
        out.lines.push({ raw: `${pendingName} ${line}`, name: pendingName, count, unitPrice: unit, price: Math.round(count * unit * 100) / 100, discount: 0, size: parseSize(pendingName) });
        pendingName = null;
      } else pendingQty = count;
      continue;
    }

    if (!priceM) {
      // "1 ROOMK SWEETP" with the price unreadable: keep the product; a price on the next line fills it in.
      const counted = line.match(/^(\d{1,2})\s+(\p{L}[\p{L}\d .'&/()-]{2,})$/u);
      if (counted && (seenHeader || out.lines.length) && !SKIP.test(line) && !NOT_FOOD.test(counted[2])) {
        // The unreadable price itself ("1798", "DEE)") is not part of the name.
        const name = counted[2].replace(/(?:\s+(?:\d{3,4}|\S*[^\p{L}\d\s]\S*))+$/u, '').trim();
        out.lines.push({ raw: line, name, count: Number(counted[1]), unitPrice: null, price: null, discount: 0, size: parseSize(name) });
        pendingName = null;
        continue;
      }
      // A name without a price: AH puts weighed items' name and weight on separate lines.
      if (!SKIP.test(line) && /[a-z]{3,}/i.test(line) && out.lines.length + (pendingName ? 1 : 0) >= 0 && line.length <= 40) {
        if (out.lines.length || pendingName || !STORES.some(([re]) => re.test(line))) pendingName = line;
      }
      continue;
    }
    if (SKIP.test(line)) continue;

    const price = num(priceM[1]);
    let body = line.slice(0, priceM.index).trim();
    if (DISCOUNT.test(body) || price < 0) {
      const amount = Math.abs(price);
      const target = findDiscountTarget(out.lines, body);
      if (target) target.discount += amount;
      else out.warnings.push(`Unmatched discount: ${line}`);
      continue;
    }
    let count = 1;
    let unitPrice: number | null = null;
    const times = QTY_TIMES.exec(body);
    if (times) {
      count = Number(times[1]);
      unitPrice = num(times[2]);
      body = body.replace(QTY_TIMES, '').trim();
    }
    const lead = body.match(/^(\d{1,2})\s+(?=\D)/);
    if (lead && !/^\d+\s*(g|kg|l|ml|cl|st)\b/i.test(body)) {
      count = Number(lead[1]);
      body = body.slice(lead[0].length).trim();
    }
    if (pendingQty) {
      count = pendingQty;
      pendingQty = null;
    }
    const prev = out.lines[out.lines.length - 1];
    if (body.length < 3 && !pendingName && prev && prev.price == null) {
      // The price of the line above, printed (or read) on a line of its own.
      prev.price = price;
      prev.unitPrice = Math.round((price / (prev.count || 1)) * 100) / 100;
      prev.raw += ` ${line}`;
      continue;
    }
    if (pendingName && body.length < 3) body = pendingName;
    pendingName = null;
    // "2 SOURCY 1,79 3,58": the unit price column stays out of the name.
    const unitCol = body.match(/\s(\d{1,4}[.,]\d{2})$/);
    if (unitCol && count > 1 && Math.abs(num(unitCol[1]) * count - price) < 0.02) {
      unitPrice = num(unitCol[1]);
      body = body.slice(0, unitCol.index).trim();
    }
    const name = body.replace(/\s+[A-Z]$/, '').replace(/[*#|]+/g, '').trim();
    if (name.length < 2 || !/[a-z]{2}/i.test(name)) continue;
    if (NOT_FOOD.test(name)) {
      out.extras = Math.round(((out.extras ?? 0) + price) * 100) / 100;
      continue;
    }
    out.lines.push({ raw: line, name, count, unitPrice: unitPrice ?? (count > 1 ? Math.round((price / count) * 100) / 100 : price), price, discount: 0, size: parseSize(name) });
  }
  if (out.total == null && subtotal != null) out.total = Math.round((subtotal - out.lines.reduce((s, l) => s + l.discount, 0)) * 100) / 100;
  if (out.lines.some((l) => l.price == null)) out.warnings.push('Some prices could not be read.');
  else if (out.total != null) {
    const sum = out.lines.reduce((s, l) => s + (l.price ?? 0) - l.discount, 0) + out.deposit + (out.extras ?? 0);
    if (Math.abs(sum - out.total) > 0.05) out.warnings.push(`Line items add up to €${sum.toFixed(2)}, receipt total is €${out.total.toFixed(2)}. Some lines may be missing.`);
  }
  if (!out.lines.length) out.warnings.push('No products found on this receipt.');
  return out;
}

function findDiscountTarget(lines: ReceiptLine[], body: string): ReceiptLine | undefined {
  const words = normalizeText(body.replace(DISCOUNT, ' ')).split(' ').filter((w) => w.length >= 3);
  for (let i = lines.length - 1; i >= 0; i--) {
    const n = normalizeText(lines[i].name);
    if (words.some((w) => n.includes(w))) return lines[i];
  }
  return lines[lines.length - 1];
}

// ---------- Matching ----------

/** Strip store brand prefixes and size tokens so "AH HALFVOLLE MELK 1L" matches "Halfvolle melk". */
export function cleanName(name: string): string {
  return normalizeText(name)
    .replace(/^(ah|jumbo|lidl|plus|dirk|aldi|coop|spar|g woon|euroshopper|1 de beste|milbona|everyday|biologisch|bio|ah biologisch|ah terra|terra|excellent|basic)\s+/g, '')
    .replace(/\b(\d+[.,]?\d*)\s*(kg|g|gr|gram|l|lt|liter|ml|cl|st|stuks|pcs|x)\b/g, ' ')
    .replace(/\b\d+\b/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export interface LineProposal {
  index: number;
  line: ReceiptLine;
  productId: string | null;
  productName: string | null;
  confidence: number;
  matchedBy: 'alias' | 'name' | 'none';
  candidates: { productId: string; name: string; score: number }[];
  quantity: number | null;     // base units
  unit: string | null;
  packages: number;
  pricePaid: number | null;
  needsReview: boolean;
  /** False when the receipt doesn't say how much was in the package and the product comes in several sizes. */
  quantityCertain: boolean;
  product: Pick<Product, 'id' | 'name' | 'name_nl' | 'unit' | 'package_size' | 'piece_size' | 'piece_name' | 'package_options' | 'category'> | null;
  duplicateOf: { lotId: string; source: string; quantity: number } | null;
}

function aliasFor(db: Db, householdId: string, store: string | null, pattern: string) {
  return (
    db.get<{ product_id: string; package_qty: number | null }>('SELECT product_id, package_qty FROM receipt_aliases WHERE household_id = ? AND store = ? AND pattern = ?', householdId, store ?? '', pattern) ??
    db.get<{ product_id: string; package_qty: number | null }>("SELECT product_id, package_qty FROM receipt_aliases WHERE household_id = ? AND pattern = ? ORDER BY hits DESC LIMIT 1", householdId, pattern)
  );
}

export function quantityFor(line: ReceiptLine, p: Product, learnedPackageQty?: number | null): { quantity: number; packages: number } {
  if (line.weightKg) {
    const grams = line.weightKg * 1000;
    if (p.unit === 'g') return { quantity: grams, packages: grams / p.package_size };
    if (p.unit === 'pcs' && p.piece_size) return { quantity: Math.max(1, Math.round(grams / p.piece_size)), packages: 1 };
    if (p.unit === 'ml') return { quantity: grams, packages: grams / p.package_size };
  }
  const packages = line.count || 1;
  let per = learnedPackageQty ?? p.package_size;
  if (!learnedPackageQty && line.size) {
    if (line.size.unit === p.unit) per = line.size.qty;
    else if (line.size.unit === 'g' && p.unit === 'pcs' && p.piece_size) per = Math.max(1, Math.round(line.size.qty / p.piece_size));
  }
  return { quantity: packages * per, packages };
}

/**
 * The quantity is certain if the line was weighed, states a size we can use ("10ST", "1L"),
 * was learned from an earlier correction, or the product only comes in one size.
 */
export function isQuantityCertain(line: ReceiptLine, p: Product, learned: boolean): boolean {
  if (line.weightKg || learned) return true;
  if (line.size && (line.size.unit === p.unit || (line.size.unit === 'g' && p.unit === 'pcs' && p.piece_size))) return true;
  return !p.package_options.length;
}

export function productSummary(p: Product) {
  return { id: p.id, name: p.name, name_nl: p.name_nl, unit: p.unit, package_size: p.package_size, piece_size: p.piece_size, piece_name: p.piece_name, package_options: p.package_options, category: p.category };
}

export function proposeMatches(db: Db, householdId: string, parsed: ParsedReceipt): LineProposal[] {
  const recentCutoff = new Date(clock.now().getTime() - 36 * 3_600_000).toISOString();
  return parsed.lines.map((line, index) => {
    const pattern = cleanName(line.name);
    const alias = aliasFor(db, householdId, parsed.store, pattern);
    let product: Product | undefined;
    let confidence = 0;
    let matchedBy: LineProposal['matchedBy'] = 'none';
    let candidates: MatchCandidate[] = [];
    if (alias) {
      product = getProduct(db, alias.product_id);
      confidence = 0.98;
      matchedBy = 'alias';
    }
    if (!product) {
      candidates = matchProducts(db, householdId, pattern || line.name, 4);
      // Also try the longest meaningful word alone ("KIPFILET NATUREL" → "kipfilet").
      if (!candidates.length || candidates[0].score < 0.8) {
        for (const w of pattern.split(' ').filter((x) => x.length >= 4).sort((a, b) => b.length - a.length)) {
          const c = matchProducts(db, householdId, w, 3).map((x) => ({ ...x, score: x.score * 0.92 }));
          candidates = [...candidates, ...c].sort((a, b) => b.score - a.score).filter((x, i, arr) => arr.findIndex((y) => y.product.id === x.product.id) === i).slice(0, 4);
        }
      }
      if (candidates[0] && candidates[0].score >= 0.6) {
        product = candidates[0].product;
        confidence = candidates[0].score;
        matchedBy = 'name';
      }
    }
    const q = product ? quantityFor(line, product, alias?.package_qty) : null;
    // Possible duplicate: the same product was added from the shopping list (or another receipt) very recently.
    let duplicateOf: LineProposal['duplicateOf'] = null;
    if (product) {
      const recent = db.get<{ lot_id: string; source: string; delta: number; meta: string | null }>(
        `SELECT lot_id, source, delta, meta FROM inventory_events WHERE household_id = ? AND product_id = ? AND type = 'purchase'
         AND source IN ('shopping_list','voice','manual','barcode') AND created_at >= ? AND (meta IS NULL OR meta NOT LIKE '%reconciledReceipt%')
         AND NOT EXISTS (SELECT 1 FROM inventory_events u WHERE u.reverses_event_id = inventory_events.id)
         ORDER BY created_at DESC LIMIT 1`,
        householdId,
        product.id,
        recentCutoff,
      );
      if (recent) {
        const lot = getLot(db, recent.lot_id);
        if (lot && lot.status === 'active') duplicateOf = { lotId: recent.lot_id, source: recent.source, quantity: recent.delta };
      }
    }
    return {
      index,
      line,
      productId: product?.id ?? null,
      productName: product?.name ?? null,
      confidence: Math.round(confidence * 100) / 100,
      matchedBy,
      candidates: candidates.map((c) => ({ productId: c.product.id, name: c.product.name, score: Math.round(c.score * 100) / 100 })),
      quantity: q?.quantity ?? null,
      unit: product?.unit ?? null,
      packages: q?.packages ?? line.count,
      pricePaid: line.price != null ? Math.round((line.price - line.discount) * 100) / 100 : null,
      needsReview: !product || confidence < 0.8,
      quantityCertain: product ? isQuantityCertain(line, product, matchedBy === 'alias') : false,
      product: product ? productSummary(product) : null,
      duplicateOf,
    };
  });
}

export function fingerprint(parsed: ParsedReceipt): string {
  const items = parsed.lines.map((l) => `${cleanName(l.name)}:${l.price ?? ''}`).sort().join('|');
  return createHash('sha256').update(`${parsed.store ?? ''}|${parsed.date ?? ''}|${parsed.total ?? ''}|${items}`).digest('hex').slice(0, 32);
}

export interface ReceiptDraft {
  id: string;
  status: string;
  parser: string;
  parsed: ParsedReceipt;
  proposals: LineProposal[];
  duplicateReceipt: { id: string; committed_at: string } | null;
  summary: { lines: number; confident: number; needsReview: number; quantityQuestions: number; total: number | null; store: string | null; date: string | null };
}

export function createDraft(db: Db, householdId: string, parsed: ParsedReceipt, opts: { rawText?: string | null; parser: 'rules' | 'ai' }): ReceiptDraft {
  const id = newId('rc');
  const fp = fingerprint(parsed);
  const proposals = proposeMatches(db, householdId, parsed);
  db.insert('receipts', {
    id,
    household_id: householdId,
    store: parsed.store,
    purchased_at: parsed.date,
    total: parsed.total,
    fingerprint: fp,
    status: 'draft',
    raw_text: opts.rawText ?? null,
    parsed: { parsed, proposals },
    parser: opts.parser,
    created_at: clock.iso(),
  });
  return getDraft(db, householdId, id);
}

export function getDraft(db: Db, householdId: string, id: string): ReceiptDraft {
  const r = db.get('SELECT * FROM receipts WHERE id = ? AND household_id = ?', id, householdId);
  if (!r) throw notFound('Receipt');
  const { parsed, proposals } = parseJson<{ parsed: ParsedReceipt; proposals: LineProposal[] }>(r.parsed, { parsed: { store: null, date: null, total: null, lines: [], deposit: 0, warnings: [] }, proposals: [] });
  const dup = db.get<{ id: string; committed_at: string }>("SELECT id, committed_at FROM receipts WHERE household_id = ? AND fingerprint = ? AND status = 'committed' AND id != ?", householdId, r.fingerprint, id);
  return {
    id: r.id,
    status: r.status,
    parser: r.parser,
    parsed,
    proposals,
    duplicateReceipt: dup ?? null,
    summary: {
      lines: proposals.length,
      confident: proposals.filter((p) => !p.needsReview).length,
      needsReview: proposals.filter((p) => p.needsReview).length,
      quantityQuestions: proposals.filter((p) => p.productId && !p.quantityCertain).length,
      total: parsed.total,
      store: parsed.store,
      date: parsed.date,
    },
  };
}

export interface CommitLine {
  index: number;
  action: 'add' | 'skip';
  productId?: string | null;
  newProduct?: { name: string; category?: string; unit?: 'g' | 'ml' | 'pcs'; package_size?: number } | null;
  quantity?: number | null;      // base units; defaults to proposal
  packages?: number | null;
  location?: string | null;
  expiresOn?: string | null;
  /** For a duplicate of a recent shopping-list purchase: 'reconcile' (default) adjusts that lot, 'add' adds anyway. */
  duplicate?: 'reconcile' | 'add';
  /** Arrived broken or already bad (base units): added, then logged straight away as waste with reason 'damaged'. */
  damaged?: number | null;
}

/** Commit a reviewed receipt. Learns aliases from every confirmed line. Idempotent per receipt. */
export function commitReceipt(ctx: Ctx, receiptId: string, lines: CommitLine[], opts: { force?: boolean } = {}) {
  const draft = getDraft(ctx.db, ctx.householdId, receiptId);
  if (draft.status === 'committed') return { receiptId, alreadyCommitted: true, added: [], reconciled: [], skipped: [] };
  if (draft.duplicateReceipt && !opts.force) throw conflict('This receipt was already added', draft.duplicateReceipt);
  const store = draft.parsed.store;
  const purchasedAt = draft.parsed.date && daysBetween(draft.parsed.date, clock.today()) < 60 && daysBetween(draft.parsed.date, clock.today()) >= 0
    ? `${draft.parsed.date}T${clock.iso().slice(11)}` : clock.iso();
  const added: { index: number; productId: string; lotId: string; quantity: number }[] = [];
  const reconciled: { index: number; productId: string; lotId: string; delta: number }[] = [];
  const skipped: number[] = [];
  ctx.db.tx(() => {
    const byIndex = new Map(lines.map((l) => [l.index, l]));
    for (const prop of draft.proposals) {
      const decision = byIndex.get(prop.index) ?? (prop.productId && !prop.needsReview ? { index: prop.index, action: 'add' as const } : { index: prop.index, action: 'skip' as const });
      if (decision.action === 'skip') {
        skipped.push(prop.index);
        continue;
      }
      let product = decision.productId ? getProduct(ctx.db, decision.productId) : prop.productId ? getProduct(ctx.db, prop.productId) : undefined;
      if (!product && decision.newProduct) product = createProduct(ctx.db, ctx.householdId, { ...decision.newProduct, price: prop.line.unitPrice ?? prop.pricePaid, preferred_store: store, synonyms: [cleanName(prop.line.name)] });
      if (!product) throw new AppError(422, 'unmatched_line', `Line ${prop.index + 1} ("${prop.line.name}") needs a product`);
      const q = decision.quantity != null ? { quantity: decision.quantity, packages: decision.packages ?? 1 } : product.id === prop.productId && prop.quantity != null ? { quantity: prop.quantity, packages: prop.packages } : quantityFor(prop.line, product);
      if (!(q.quantity > 0)) throw new AppError(422, 'invalid_quantity', `Line ${prop.index + 1} has no quantity`);

      // Learn: this receipt text means this product (and this package size when it differs from the default).
      const pattern = cleanName(prop.line.name);
      if (pattern) {
        const perPackage = !prop.line.weightKg && q.packages ? q.quantity / q.packages : null;
        ctx.db.run(
          `INSERT INTO receipt_aliases (household_id, store, pattern, product_id, package_qty, hits, updated_at) VALUES (?, ?, ?, ?, ?, 1, ?)
           ON CONFLICT(household_id, store, pattern) DO UPDATE SET product_id = excluded.product_id, package_qty = excluded.package_qty, hits = hits + 1, updated_at = excluded.updated_at`,
          ctx.householdId, store ?? '', pattern, product.id, perPackage && Math.abs(perPackage - product.package_size) > 1e-6 ? perPackage : null, clock.iso(),
        );
      }
      // Update the typical price for this product.
      if (prop.pricePaid != null && q.packages > 0 && !prop.line.weightKg) {
        ctx.db.run('UPDATE products SET price = ?, preferred_store = COALESCE(preferred_store, ?) WHERE id = ?', Math.round((prop.pricePaid / q.packages) * 100) / 100, store, product.id);
      }

      const dup = product.id === prop.productId ? prop.duplicateOf : null;
      if (dup && (decision.duplicate ?? 'reconcile') === 'reconcile') {
        // The shopping list (or a voice command) already added this purchase: correct it instead of adding again.
        const lot = getLot(ctx.db, dup.lotId);
        if (lot && lot.status === 'active') {
          const delta = q.quantity - dup.quantity;
          if (Math.abs(delta) > 1e-6) applyLotDelta(ctx, lot.id, delta);
          ctx.db.run(`UPDATE inventory_events SET meta = json_set(COALESCE(meta,'{}'), '$.reconciledReceipt', ?) WHERE lot_id = ? AND type = 'purchase'`, receiptId, lot.id);
          ctx.db.run('UPDATE purchases SET receipt_id = ?, total_price = ?, store = ?, quantity = ? WHERE event_id IN (SELECT id FROM inventory_events WHERE lot_id = ? AND type = ?)', receiptId, prop.pricePaid, store, q.quantity, lot.id, 'purchase');
          reconciled.push({ index: prop.index, productId: product.id, lotId: lot.id, delta });
          if (decision.damaged && decision.damaged > 0) deduct(ctx, { lotId: lot.id, quantity: Math.min(decision.damaged, q.quantity), type: 'discard', reason: 'damaged' });
          continue;
        }
      }
      const { lot } = addStock(ctx, {
        productId: product.id,
        quantity: q.quantity,
        packages: q.packages,
        totalPrice: prop.pricePaid,
        store,
        receiptId,
        purchasedAt,
        location: decision.location ?? null,
        expiresOn: decision.expiresOn ?? null,
        meta: { receiptId, line: prop.index },
      });
      added.push({ index: prop.index, productId: product.id, lotId: lot.id, quantity: q.quantity });
      if (decision.damaged && decision.damaged > 0) deduct(ctx, { lotId: lot.id, quantity: Math.min(decision.damaged, q.quantity), type: 'discard', reason: 'damaged' });
    }
    ctx.db.run("UPDATE receipts SET status = 'committed', committed_at = ?, batch_id = ? WHERE id = ?", clock.iso(), ctx.batchId, receiptId);
  });
  bus.touch(ctx.householdId, 'receipts');
  return { receiptId, alreadyCommitted: false, added, reconciled, skipped, batchId: ctx.batchId };
}

// Receipt reconciliation goes through the ledger's adjust path.
function applyLotDelta(ctx: Ctx, lotId: string, delta: number) {
  const lot = getLot(ctx.db, lotId)!;
  return setLotQuantity(ctx, lotId, Math.max(0, lot.quantity + delta));
}

export function listReceipts(db: Db, householdId: string, limit = 30) {
  return db.all('SELECT id, store, purchased_at, total, status, parser, created_at, committed_at FROM receipts WHERE household_id = ? ORDER BY created_at DESC LIMIT ?', householdId, limit);
}

export function discardDraft(db: Db, householdId: string, id: string) {
  db.run("UPDATE receipts SET status = 'discarded' WHERE id = ? AND household_id = ? AND status = 'draft'", id, householdId);
}
