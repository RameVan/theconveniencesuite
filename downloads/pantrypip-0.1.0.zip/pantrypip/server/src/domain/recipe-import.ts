// Save recipes from anywhere: a link (most recipe sites publish schema.org/Recipe data in the page) or
// pasted text. Ingredient lines are matched to products so stock, shopping and macros work like built-ins.
import type { Db } from '../db/db.ts';
import { AppError } from '../errors.ts';
import { parseItem, splitItems } from '../assistant/parser.ts';
import { segmentPhrase } from '../assistant/list.ts';
import { listProducts, normalizeText, resolveProduct, stem, displayName, type Product } from './products.ts';
import { toBase, parseNumber } from './units.ts';
import { identifyIngredient } from './ingredient-match.ts';
import { FRESH_OF } from '../db/ingredient-knowledge.ts';
import { familyPref, householdCountry, type MatchKind } from './substitutions.ts';
import { parseJson } from '../db/db.ts';

export interface DraftIngredient {
  line: string; name: string; productId: string | null; productName: string | null; quantity: number | null; unit: string | null; optional: boolean;
  /** How it was matched; sourceKey for anything that isn't an exact product ('f:milk', 'x:habanero', 'u:name'). */
  match: MatchKind; sourceKey: string | null;
  /** Products that matched part of the name, for review. */
  alternatives?: string[];
}
export interface RecipeDraft {
  title: string;
  summary: string | null;
  servings: number;
  prep_minutes: number;
  cook_minutes: number;
  cuisine: string | null;
  image_url: string | null;
  source_url: string | null;
  source_name: string | null;
  emoji: string;
  steps: { text: string; timerSeconds?: number }[];
  ingredients: DraftIngredient[];
}

const FRACTIONS: Record<string, string> = { '½': '.5', '¼': '.25', '¾': '.75', '⅓': '.33', '⅔': '.67', '⅛': '.125' };
const PREP_WORDS = /\b(finely|roughly|thinly|freshly|chopped|diced|sliced|minced|grated|crushed|peeled|halved|cubed|drained|rinsed|fresh|large|small|medium|ripe|to taste|to serve|optional|gesnipperd|fijngesneden|fijngehakt|gehakt|gesneden|in blokjes|in plakjes|in reepjes|geraspt|uitgelekt|geperst|vers|verse|grote|groot|kleine|klein|naar smaak|optioneel)\b/g;

const decode = (s: string) =>
  s.replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#0?39;|&apos;|&rsquo;/g, '’').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n))).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();

/** Stemmed word lists of every product name, for finding a product inside a longer phrase. */
export function nameIndex(products: Product[]) {
  const out: { p: Product; words: string[] }[] = [];
  for (const p of products) for (const n of [p.name, p.name_nl ?? '', ...p.synonyms]) if (n) out.push({ p, words: normalizeText(n).split(' ').map(stem) });
  return out;
}

/** "2 tbsp olive oil", "1 ui, gesnipperd", "400 g chopped tomatoes (1 tin)" → product + base quantity. */
export function parseIngredientLine(db: Db, householdId: string, line: string, index = nameIndex(listProducts(db, householdId)), products?: Product[]): DraftIngredient {
  const raw = decode(line);
  const optional = /\b(optional|optioneel|to serve|om te serveren|garnish|garnering|to taste|naar smaak)\b/i.test(raw);
  let t = raw.toLowerCase();
  for (const [f, v] of Object.entries(FRACTIONS)) t = t.replace(new RegExp(`(\\d)\\s*${f}`, 'g'), (_, d) => `${Number(d) + Number(v)}`).replaceAll(f, `0${v}`);
  t = t.replace(/\(.*?\)/g, ' ').replace(/(\d+)\s+(\d+)\/(\d+)/g, (_, a, b, c) => String(Number(a) + Number(b) / Number(c)))
    .replace(/(\d+(?:[.,]\d+)?)\s*[-–]\s*\d+(?:[.,]\d+)?/g, '$1').replace(/(\d),(\d)/g, '$1.$2').replace(/(\d)(g|kg|ml|l|cl|dl|el|tl)\b/g, '$1 $2');
  // "all-purpose flour" is plain flour (and "all" isn't "all of it"); "butter or margarine" means the first,
  // and "beef or chicken broth" means beef broth (the shared noun comes along); a US stick of butter is 113 g.
  t = t.replace(/\ball[- ]purpose\b/g, 'plain').replace(/\b(\d+(?:\.\d+)?|a|one|half a)\s+sticks?\s+(?:of\s+)?((?:un)?salted\s+)?butter\b/g, (_m, n: string) => `${(n === 'a' || n === 'one' ? 1 : n === 'half a' ? 0.5 : Number(n)) * 113} g butter`);
  const head = t.split(/[,;]| - /)[0].replace(/\s+(?:or|of)\s+([a-z][a-z ]*)$/, (m, alt: string, at: number, whole: string) => {
    if (/ of /.test(m)) return m;
    const tail = alt.trim().split(' ').slice(1);
    return tail.length && !whole.slice(0, at).trim().endsWith(tail[tail.length - 1]) ? ` ${tail.join(' ')}` : '';
  });
  const spec = parseItem(head.replace(PREP_WORDS, ' ').replace(/\s+/g, ' '));
  const name = (spec?.name ?? head).replace(/\s+/g, ' ').trim();
  // "Salt and pepper" is seasoning: the pepper is black pepper, not a bell pepper.
  const seasoning = /\b(salt|zout)\b/.test(name) && /\b(pepper|peper)\b/.test(name);
  const all = products ?? listProducts(db, householdId);
  const country = householdId ? householdCountry(db, householdId) : 'NL';
  let product: Product | null = null;
  let match: MatchKind = 'unresolved';
  let sourceKey: string | null = null;
  let ratio = 1;
  let alternatives: string[] | undefined;
  // A bare "pepper" measured in spoons or "to taste" is ground black pepper; counted, it is a bell pepper.
  const blackPepper = /^(?:ground |freshly ground )?pepper$/.test(name) && (spec?.amount == null || /^(tsp|tbsp|pinch|dash|g)$/.test(spec?.unit ?? '') || /\b(tsp|tbsp|teaspoons?|tablespoons?|pinch|dash|to taste)\b/.test(t));
  if (seasoning || blackPepper) {
    product = all.find((p) => p.id === 'p_pepper') ?? null;
    match = 'exact';
  } else if (name) {
    // The whole name first ("chopped tomatoes" is the tin), then without preparation words.
    const fullName = (parseItem(head)?.name ?? head).trim();
    let m = identifyIngredient(db, householdId, fullName, { products: all, country });
    if (m.kind === 'none' && fullName !== name) m = identifyIngredient(db, householdId, name, { products: all, country });
    // The line's own words too (the item parser drops words like "stock" in "1 stock cube").
    if (m.kind === 'none') m = identifyIngredient(db, householdId, head.replace(/[0-9.,/]+/g, ' '), { products: all, country });
    if (m.kind === 'product') {
      product = m.product!;
      // "3 sprigs of thyme" is fresh thyme, whatever the shortest name matched.
      const fresh = FRESH_OF[product.id];
      if (fresh && spec?.unit && /^(sprigs?|takjes?|leaves|leaf|blaadjes?)$/i.test(spec.unit)) product = all.find((p) => p.id === fresh) ?? product;
      match = 'exact';
    } else if (m.kind === 'family') {
      // Only the family was named ("milk"): your usual type, or the family's everyday default.
      const f = m.family!;
      const first = typeof f.variants[0] === 'string' ? f.variants[0] : f.variants[0].variants[0];
      const pick = (householdId && familyPref(db, householdId, f.id)) || first;
      product = all.find((p) => p.id === pick) ?? null;
      match = 'equivalent';
      sourceKey = `f:${f.id}`;
    } else if (m.kind === 'foreign') {
      sourceKey = m.foreignKey!;
      const sub = db.get<{ to_product: string; kind: MatchKind; ratio: number; countries: string }>('SELECT to_product, kind, ratio, countries FROM substitutions WHERE from_key = ? ORDER BY sort', sourceKey);
      if (sub && (!parseJson<string[]>(sub.countries, []).length || parseJson<string[]>(sub.countries, []).includes(country))) {
        product = all.find((p) => p.id === sub.to_product) ?? null;
        match = sub.kind;
        ratio = sub.ratio;
      }
    } else {
      // A typo is still the same thing ("tomatoe"); anything vaguer stays unresolved for review.
      const fuzzy = resolveProduct(db, householdId, name, all).candidates[0];
      if (fuzzy && fuzzy.score >= 0.85 && fuzzy.score < 1) {
        product = fuzzy.product;
        match = 'exact';
      } else {
        sourceKey = `u:${normalizeText(name)}`;
        alternatives = m.alternatives.map((p) => p.id);
      }
    }
  }
  let quantity: number | null = null;
  if (product && spec?.amount != null) {
    try {
      // A stalk (rib) of celery is about a tenth of the head it's sold as.
      const stalks = product.id === 'p_celery' && /\b(stalks?|ribs?|sticks?|stengels?)\b/.test(t) ? 0.1 : 1;
      quantity = Math.round(toBase(spec.amount, spec.unit, product).qty * ratio * stalks * 100) / 100;
    } catch {
      quantity = null;
    }
  } else if (product && spec?.amount == null && product.unit === 'pcs' && parseNumber(head.trim().split(' ')[0]) == null) quantity = null;
  return { line: raw, name: name || raw, productId: product?.id ?? null, productName: product ? displayName(product, 'en') : null, quantity, unit: product?.unit ?? null, optional, match, sourceKey, alternatives };
}

function isoMinutes(d: unknown): number {
  if (typeof d !== 'string') return 0;
  const m = d.match(/P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?/i);
  return m ? Number(m[1] ?? 0) * 1440 + Number(m[2] ?? 0) * 60 + Number(m[3] ?? 0) : 0;
}

export const timerOf = (text: string) => {
  const m = text.match(/(\d+)\s*(?:-\s*\d+\s*)?(minutes|minute|mins|min|minuten|minuut)\b/i);
  return m ? Number(m[1]) * 60 : undefined;
};

function stepsOf(ins: unknown): string[] {
  if (!ins) return [];
  if (typeof ins === 'string') return decode(ins).split(/(?<=\.)\s+(?=[A-Z])|\n+/).map((s) => s.trim()).filter(Boolean);
  if (Array.isArray(ins)) return ins.flatMap(stepsOf);
  if (typeof ins === 'object') {
    const o = ins as any;
    if (o.itemListElement) return stepsOf(o.itemListElement);
    if (o.text) return [decode(String(o.text))];
    if (o.name) return [decode(String(o.name))];
  }
  return [];
}

const firstString = (v: unknown): string | null => (typeof v === 'string' ? v : Array.isArray(v) ? firstString(v[0]) : v && typeof v === 'object' ? firstString((v as any).url ?? (v as any)['@id']) : null);

function findRecipe(node: any): any {
  if (!node || typeof node !== 'object') return null;
  if (Array.isArray(node)) {
    for (const n of node) {
      const r = findRecipe(n);
      if (r) return r;
    }
    return null;
  }
  const type = node['@type'];
  if (type === 'Recipe' || (Array.isArray(type) && type.includes('Recipe'))) return node;
  return findRecipe(node['@graph']) ?? findRecipe(node.mainEntity);
}

const EMOJI: [RegExp, string][] = [
  [/pasta|spaghetti|penne|lasagn|macaroni/, '🍝'], [/curry|dal|masala/, '🍛'], [/soup|soep/, '🥣'], [/salad|salade/, '🥗'], [/pizza/, '🍕'], [/burger/, '🍔'],
  [/taco|burrito|fajita|wrap/, '🌯'], [/chicken|kip/, '🍗'], [/salmon|zalm|fish|vis|tuna|tonijn/, '🐟'], [/shrimp|prawn|garnal/, '🍤'], [/rice|rijst|risotto/, '🍚'],
  [/noodle|ramen|wok/, '🍜'], [/egg|omelet|frittata|ei/, '🍳'], [/cake|taart|brownie|cookie|koek/, '🍰'], [/pancake|pannenkoek/, '🥞'], [/beef|rund|steak|gehakt/, '🥩'],
];

export function finishDraft(db: Db, householdId: string, d: Omit<RecipeDraft, 'ingredients' | 'emoji'> & { ingredientLines: string[] }): RecipeDraft {
  const index = nameIndex(listProducts(db, householdId));
  const ingredients = d.ingredientLines.map((l) => decode(l)).filter(Boolean).slice(0, 60).map((l) => parseIngredientLine(db, householdId, l, index));
  const title = d.title.trim().slice(0, 120) || 'My recipe';
  const emoji = EMOJI.find(([re]) => re.test(title.toLowerCase()))?.[1] ?? '🍽️';
  const { ingredientLines: _, ...rest } = d;
  return { ...rest, title, emoji, ingredients, steps: d.steps.length ? d.steps.slice(0, 60) : [{ text: 'Follow the original recipe.' }] };
}

/** Read the schema.org Recipe from a recipe page. */
export async function draftFromUrl(db: Db, householdId: string, url: string): Promise<RecipeDraft> {
  let u: URL;
  try {
    u = new URL(url);
  } catch {
    throw new AppError(422, 'bad_url', 'That doesn’t look like a link.');
  }
  if (!/^https?:$/.test(u.protocol)) throw new AppError(422, 'bad_url', 'Only http and https links can be imported.');
  let html: string;
  try {
    const res = await fetch(u, { headers: { 'user-agent': 'Mozilla/5.0 (compatible; PantryPip recipe import)', accept: 'text/html,application/xhtml+xml' }, signal: AbortSignal.timeout(12000), redirect: 'follow' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    html = (await res.text()).slice(0, 4_000_000);
  } catch (e: any) {
    throw new AppError(502, 'fetch_failed', `Couldn’t open that page (${e?.message ?? 'network error'}). Paste the ingredients and steps instead.`);
  }
  return draftFromHtml(db, householdId, html, u.toString());
}

export function draftFromHtml(db: Db, householdId: string, html: string, url: string): RecipeDraft {
  let recipe: any = null;
  for (const m of html.matchAll(/<script[^>]*type=["']?application\/ld\+json["']?[^>]*>([\s\S]*?)<\/script>/gi)) {
    try {
      recipe = findRecipe(JSON.parse(m[1].trim()));
    } catch {
      try {
        recipe = findRecipe(JSON.parse(decode(m[1])));
      } catch {
        /* not JSON we can read */
      }
    }
    if (recipe) break;
  }
  if (!recipe) throw new AppError(422, 'no_recipe', 'No recipe found on that page. Paste the ingredients and steps instead.');
  const yieldText = firstString(recipe.recipeYield) ?? String(recipe.recipeYield ?? '');
  const servings = Math.min(40, Math.max(1, Math.round(Number(yieldText.match(/\d+/)?.[0] ?? 4))));
  const total = isoMinutes(recipe.totalTime);
  const prep = isoMinutes(recipe.prepTime);
  const cook = isoMinutes(recipe.cookTime) || Math.max(0, total - prep);
  const u = new URL(url);
  return finishDraft(db, householdId, {
    title: decode(String(recipe.name ?? '')),
    summary: recipe.description ? decode(String(recipe.description)).slice(0, 400) : null,
    servings,
    prep_minutes: Math.min(1440, prep),
    cook_minutes: Math.min(1440, cook),
    cuisine: firstString(recipe.recipeCuisine)?.slice(0, 40) ?? null,
    image_url: (() => {
      try {
        const img = firstString(recipe.image);
        return img ? new URL(img, url).toString() : null;
      } catch {
        return null;
      }
    })(),
    source_url: url,
    source_name: u.hostname.replace(/^www\./, ''),
    steps: stepsOf(recipe.recipeInstructions).map((text) => ({ text: text.slice(0, 1000), timerSeconds: timerOf(text) })),
    ingredientLines: (Array.isArray(recipe.recipeIngredient) ? recipe.recipeIngredient : Array.isArray(recipe.ingredients) ? recipe.ingredients : []).map(String),
  });
}

/**
 * Ingredient lines from typed or dictated text. A dictated list arrives as one run-on line
 * ("500 grams chicken two tablespoons olive oil and an onion"), so split those per ingredient.
 */
function splitSpoken(db: Db, householdId: string, text: string): string[] {
  const lines = text.split(/\n+/).map((s) => s.replace(/^\s*[-•*]\s*/, '').trim()).filter(Boolean);
  if (lines.length > 1) return lines;
  const products = listProducts(db, householdId);
  return lines.flatMap((line) =>
    splitItems(line.toLowerCase()).flatMap((part) => {
      const parts = segmentPhrase(part, products);
      return parts ? parts.map((p) => `${p.amount != null ? `${p.amount} ${p.unit ?? ''} ` : ''}${p.name}`.replace(/\s+/g, ' ').trim()) : [part];
    }),
  );
}

/** A recipe typed or pasted by hand: one ingredient per line, steps separated by lines. */
export function draftFromText(db: Db, householdId: string, input: { title: string; servings?: number; minutes?: number; ingredients: string; steps?: string }): RecipeDraft {
  return finishDraft(db, householdId, {
    title: input.title,
    summary: null,
    servings: input.servings ?? 2,
    prep_minutes: 0,
    cook_minutes: input.minutes ?? 30,
    cuisine: null,
    image_url: null,
    source_url: null,
    source_name: null,
    // One spoken paragraph becomes one step per sentence.
    steps: (input.steps ?? '').split(/\n+|(?<=[.!?])\s+(?=\S)/).map((s) => s.replace(/^\s*(\d+[.)]|[-•*])\s*/, '').trim()).filter(Boolean).map((text) => ({ text, timerSeconds: timerOf(text) })),
    ingredientLines: splitSpoken(db, householdId, input.ingredients),
  });
}
