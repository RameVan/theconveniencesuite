import type { Db, Row } from '../db/db.ts';
import { newId, parseJson } from '../db/db.ts';
import { clock, addDays, daysBetween } from '../clock.ts';
import { AppError, notFound } from '../errors.ts';
import { rowToProduct, getProduct, type Product } from './products.ts';
import { resolveLine, subContext, compatOf, householdCountry, convertQty, type SubContext, type SubInfo, type MatchKind, type LineRow, type Compat } from './substitutions.ts';
import { dietaryNeeds, productConflicts, recipeAllergens, recipeDiets, recipeSuitability, type DietaryNeeds, type Suitability } from './dietary.ts';
import { addStock, deduct, type Ctx } from './ledger.ts';
import { inventorySummary, type StockItem } from './inventory.ts';
import { bus } from '../bus.ts';
import { mealScore, isVeg, gramsOf, needsAssumedFat, ASSUMED_OIL_PER_SERVING, OIL_NUTRITION, NUTRIENTS, zero, type MealScore, type Nutrition, type FullNutrition } from './health.ts';

export type { Nutrition } from './health.ts';

export interface Ingredient {
  position: number;
  product_id: string | null;
  name: string;
  quantity: number | null;
  unit: string | null;
  display: string | null;
  optional: boolean;
  product?: Product | null;
  /** How the line was matched for this household (see substitutions.ts). */
  match: MatchKind;
  source_key: string | null;
  /** Shown when the line uses something other than what the recipe wrote. */
  sub: SubInfo | null;
  /** Set on lines added by a substitution ("lemon, for the buttermilk"): the key they belong to. */
  extra_for: string | null;
}

export interface Recipe {
  id: string;
  household_id: string | null;
  title: string;
  summary: string | null;
  cuisine: string | null;
  tags: string[];
  diet: string[];
  difficulty: string;
  servings: number;
  prep_minutes: number;
  cook_minutes: number;
  steps: { text: string; timerSeconds?: number }[];
  image_url: string | null;
  emoji: string | null;
  color: string | null;
  origin: 'builtin' | 'user' | 'ai' | 'external';
  source_name: string | null;
  source_url: string | null;
  attribution: string | null;
  ingredients: Ingredient[];
  nutritionPerServing: FullNutrition | null;
  nutritionTotal: FullNutrition | null;
  /** How every ingredient contributed (or why it couldn't), for traceable nutrition. */
  nutritionAudit: NutritionLine[];
  allergens: { required: string[]; optional: string[] };
  nutritionEstimated: boolean;
  /** Required ingredients with known nutrition / all required ingredients. */
  nutritionCoverage: { known: number; total: number };
  /** Grams of oil per serving added because the method fries without listing fat. */
  assumedFat: number;
  health: MealScore;
  /** Main protein, for variety in the week planner. */
  protein: 'chicken' | 'beef' | 'pork' | 'fish' | 'eggs' | 'plant' | 'veg';
  costPerServing: number | null;
  /** Can you make it with what's sold in your country: full, with substitutions, partially, or needs specialist shops. */
  compat: Compat;
  servings_estimated?: number;
}

export interface NutritionLine {
  position: number | null;
  name: string;
  productId: string | null;
  productName: string | null;
  source: string | null;
  quantity: number | null;
  unit: string | null;
  grams: number | null;
  status: 'counted' | 'assumed' | 'optional' | 'no_product' | 'no_amount' | 'no_data';
  /** Share of this ingredient counted as eaten (1 = all of it, the default). */
  retention?: number;
  /** Fats, marinades and frying liquids: part of them can stay behind, so the share can be set. */
  adjustable?: boolean;
  /** Nutrients the product's data doesn't have (counted as 0). */
  missing: string[];
  contribution: FullNutrition | null;
}

const PROTEIN_OF: [RegExp, Recipe['protein']][] = [
  [/^p_(chicken_breast|chicken_thigh)$/, 'chicken'],
  [/^p_minced_beef$/, 'beef'],
  [/^p_(bacon|ham|smoked_sausage)$/, 'pork'],
  [/^p_(salmon|tuna|shrimp)$/, 'fish'],
  [/^p_(tofu|chickpeas|lentils|kidney_beans)$/, 'plant'],
  [/^p_eggs$/, 'eggs'],
];


function loadIngredients(db: Db, recipeId: string, products: Map<string, Product>, ctx: SubContext, rows?: Row[]): Ingredient[] {
  const out: Ingredient[] = [];
  for (const r of rows ?? db.all(`SELECT ri.* FROM recipe_ingredients ri WHERE ri.recipe_id = ? ORDER BY position`, recipeId)) {
    // Substitutions and your choices are applied here, per household (substitutions.ts).
    const res = resolveLine(r as LineRow, ctx, products);
    const product = res.productId ? products.get(res.productId) ?? null : null;
    out.push({
      position: r.position, product_id: product ? res.productId : null, name: r.name, quantity: res.quantity, unit: product?.unit ?? r.unit, display: r.display,
      optional: !!r.optional, product, match: res.match, source_key: r.source_key ?? null, sub: res.sub, extra_for: null,
    });
    // A substitution that needs something extra (buttermilk → milk + lemon) adds its own lines.
    res.extra.forEach((e, i) => {
      const p = products.get(e.product);
      if (p) out.push({ position: 1000 + r.position * 10 + i, product_id: p.id, name: p.name, quantity: e.quantity, unit: p.unit, display: null, optional: !!r.optional, product: p, match: 'substitute', source_key: null, sub: null, extra_for: res.sub?.fromKey ?? null });
    });
  }
  return out;
}

/** All products a household can see, by id. */
function productMap(db: Db, householdId: string) {
  return new Map(db.all('SELECT * FROM products WHERE household_id IS NULL OR household_id = ?', householdId).map((x) => [x.id as string, rowToProduct(x)]));
}

/**
 * Nutrients for a quantity of product. Values are per 100 g, or per 100 ml for products measured in ml;
 * pieces convert through their typical weight. Nutrients the data lacks count as 0 and are listed.
 */
export function nutritionFor(p: Product, qty: number): (FullNutrition & { missing: string[] }) | null {
  if (!p.nutrition) return null;
  const f = (p.unit === 'pcs' ? qty * (p.piece_size ?? 100) : qty) / 100;
  const out = { ...zero(), missing: [] as string[] };
  for (const k of NUTRIENTS) {
    const v = (p.nutrition as Record<string, number | undefined>)[k];
    if (v == null) out.missing.push(k);
    out[k] = (v ?? 0) * f;
  }
  return out;
}

const FAT_IDS = new Set(['p_olive_oil', 'p_sunflower_oil', 'p_butter']);
const LEFT_BEHIND = /\b(marinade|marinate|marineer|for frying|to fry|deep[- ]fry|frituur|frying oil|bakolie|brine|pekel|dipping|dressing)\b/i;
/** Ingredients where part can stay behind in the pan or the bowl. */
const isAdjustable = (i: Pick<Ingredient, 'product_id' | 'display' | 'name'>) => FAT_IDS.has(i.product_id ?? '') || LEFT_BEHIND.test(`${i.display ?? ''} ${i.name}`);

/** Total nutrition with one audit line per ingredient. */
export function recipeNutrition(ingredients: Ingredient[], steps: { text: string }[], servings: number, retention?: Map<number, number>) {
  const total = zero();
  const audit: NutritionLine[] = [];
  let known = 0;
  const required = ingredients.filter((i) => !i.optional);
  for (const i of ingredients) {
    const base = { position: i.position, name: i.display ?? i.name, productId: i.product_id, productName: i.product?.name ?? null, source: i.product?.nutrition_source ?? null, unit: i.product?.unit ?? i.unit, missing: [] as string[] };
    if (!i.product) {
      audit.push({ ...base, quantity: i.quantity, grams: null, status: 'no_product', contribution: null });
      continue;
    }
    let qty = i.quantity;
    let status: NutritionLine['status'] = i.optional ? 'optional' : 'counted';
    // Never silently drop cooking fat: "oil for frying" without an amount counts as 1 tsp per serving.
    if (qty == null && FAT_IDS.has(i.product.id) && !i.optional) {
      qty = (ASSUMED_OIL_PER_SERVING * servings) / (i.product.unit === 'g' ? 1 : i.product.density ?? 1);
      status = 'assumed';
    }
    if (qty == null) {
      audit.push({ ...base, quantity: null, grams: null, status: i.optional ? 'optional' : 'no_amount', contribution: null });
      continue;
    }
    const n = nutritionFor(i.product, qty);
    const grams = Math.round(gramsOf(i.product, qty) * 10) / 10;
    if (!n) {
      audit.push({ ...base, quantity: qty, grams, status: 'no_data', contribution: null });
      continue;
    }
    const { missing, ...full } = n;
    const adjustable = isAdjustable(i);
    // Only an explicit setting lowers the count, and only for fats and marinades.
    const share = adjustable ? Math.min(1, Math.max(0.1, retention?.get(i.position) ?? 1)) : 1;
    const contribution = share === 1 ? full : (Object.fromEntries(NUTRIENTS.map((k) => [k, full[k] * share])) as FullNutrition);
    audit.push({ ...base, quantity: qty, grams, status, missing, contribution, retention: share, adjustable });
    if (status === 'optional') continue;
    known++;
    for (const k of NUTRIENTS) total[k] += contribution[k];
  }
  // Frying without a listed fat still uses some: about 1 tsp oil per serving.
  const assumedFat = known && needsAssumedFat(required, steps) ? ASSUMED_OIL_PER_SERVING : 0;
  if (assumedFat) {
    const ml = assumedFat * servings;
    const c = zero();
    for (const k of NUTRIENTS) c[k] = (OIL_NUTRITION[k] * ml) / 100;
    for (const k of NUTRIENTS) total[k] += c[k];
    audit.push({ position: null, name: `Oil for frying (≈1 tsp per serving, not listed)`, productId: 'p_olive_oil', productName: 'Olive oil', source: 'assumed', quantity: ml, unit: 'ml', grams: Math.round(ml * 0.91 * 10) / 10, status: 'assumed', missing: [], contribution: c });
  }
  return { total, audit, known, required: required.length, assumedFat };
}

export function costFor(p: Product, qty: number): number | null {
  if (p.price == null || !p.package_size) return null;
  return (p.price / p.package_size) * qty;
}

function hydrate(db: Db, r: Row, products: Map<string, Product>, ctx: SubContext, retention?: Map<number, number>, ingredientRows?: Row[]): Recipe {
  const ingredients = loadIngredients(db, r.id, products, ctx, ingredientRows);
  let cost = 0;
  let costKnown = 0;
  const required = ingredients.filter((i) => !i.optional);
  for (const i of required) {
    if (!i.product || i.quantity == null) continue;
    const c = costFor(i.product, i.quantity);
    if (c != null) {
      cost += c;
      costKnown++;
    }
  }
  const steps = parseJson<{ text: string }[]>(r.steps, []);
  const nut = recipeNutrition(ingredients, steps, r.servings, retention);
  const known = nut.known;
  const assumedFat = nut.assumedFat;
  const round = (x: number, d: number) => Math.round(x * 10 ** d) / 10 ** d;
  const perServing = (t: FullNutrition): FullNutrition => {
    const o = zero();
    for (const k of NUTRIENTS) o[k] = k === 'kcal' ? Math.round(t[k] / r.servings) : round(t[k] / r.servings, k === 'salt' ? 2 : 1);
    return o;
  };
  const nutritionPerServing = known ? perServing(nut.total) : null;
  const nutritionTotal = known ? (Object.fromEntries(NUTRIENTS.map((k) => [k, round(nut.total[k], 1)])) as FullNutrition) : null;
  const veg = required.filter((i) => i.product && i.quantity != null && isVeg(i.product));
  const vegGrams = veg.reduce((g, i) => g + gramsOf(i.product!, i.quantity!), 0) / r.servings;
  const health = mealScore(nutritionPerServing, vegGrams, new Set(veg.map((i) => i.product_id)).size);
  let protein: Recipe['protein'] = 'veg';
  for (const [re, kind] of PROTEIN_OF) if (required.some((i) => i.product_id && re.test(i.product_id))) { protein = kind; break; }
  return {
    ...(r as any),
    tags: parseJson(r.tags, []),
    // Diets and allergens come from the ingredients themselves, so every recipe is checked the same way.
    diet: recipeDiets({ ingredients, nutritionPerServing }),
    allergens: recipeAllergens({ ingredients }),
    steps: parseJson(r.steps, []),
    ingredients,
    nutritionPerServing,
    nutritionTotal,
    nutritionAudit: nut.audit,
    nutritionEstimated: true,
    nutritionCoverage: { known, total: required.length },
    assumedFat,
    health,
    protein,
    costPerServing: costKnown ? Math.round((cost / r.servings) * 100) / 100 : null,
    compat: compatOf(ingredients.filter((i) => !i.extra_for).map((i) => ({ optional: i.optional, match: i.match, productId: i.product_id, sub: i.sub })), ctx),
  };
}

export function getRecipe(db: Db, householdId: string, id: string): Recipe {
  const r = db.get('SELECT * FROM recipes WHERE id = ? AND (household_id IS NULL OR household_id = ?)', id, householdId);
  if (!r) throw notFound('Recipe');
  return hydrate(db, r, productMap(db, householdId), subContext(db, householdId), retentionFor(db, householdId).get(id));
}

/** This household's "counted share" settings, per recipe and ingredient position. */
function retentionFor(db: Db, householdId: string) {
  const out = new Map<string, Map<number, number>>();
  for (const x of db.all<{ recipe_id: string; position: number; retention: number }>('SELECT recipe_id, position, retention FROM recipe_retention WHERE household_id = ?', householdId)) {
    const m = out.get(x.recipe_id) ?? new Map();
    m.set(x.position, x.retention);
    out.set(x.recipe_id, m);
  }
  return out;
}

/** Set (or with null, reset to "all of it") the share of a fat or marinade that counts as eaten. */
export function setRetention(db: Db, householdId: string, recipeId: string, position: number, retention: number | null) {
  const r = getRecipe(db, householdId, recipeId);
  const ing = r.ingredients.find((i) => i.position === position);
  if (!ing) throw notFound('Ingredient');
  if (!isAdjustable(ing)) throw new AppError(422, 'not_adjustable', 'Only fats, marinades and frying liquids can be partly counted.');
  if (retention == null || retention >= 1) db.run('DELETE FROM recipe_retention WHERE household_id = ? AND recipe_id = ? AND position = ?', householdId, recipeId, position);
  else db.run('INSERT INTO recipe_retention (household_id, recipe_id, position, retention) VALUES (?, ?, ?, ?) ON CONFLICT (household_id, recipe_id, position) DO UPDATE SET retention = excluded.retention', householdId, recipeId, position, Math.max(0.1, retention));
  bus.touch(householdId, 'recipes');
  return getRecipe(db, householdId, recipeId);
}

// Calculated recipes per database and household. Rebuilt only when db.recipeVersion has moved, i.e. after a
// write to recipes, ingredients, products or counted shares. About 10 KB per recipe: 20,000 ≈ 200 MB.
const recipeCache = new WeakMap<Db, Map<string, { version: string; list: readonly Recipe[]; byId: Map<string, Recipe> }>>();

/** This connection's writes, plus SQLite's counter for writes by other connections (the import script). */
const cacheVersion = (db: Db, householdId: string) => `${db.recipeVersion}:${db.get<{ data_version: number }>('PRAGMA data_version')?.data_version ?? 0}:${householdCountry(db, householdId)}`;

/** Freeze a calculated recipe so code that tries to change a shared, cached object fails loudly. */
function deepFreeze<T>(o: T): T {
  if (o && typeof o === 'object' && !Object.isFrozen(o)) {
    Object.freeze(o);
    for (const v of Object.values(o as any)) deepFreeze(v);
  }
  return o;
}

function cachedRecipes(db: Db, householdId: string) {
  let perHousehold = recipeCache.get(db);
  if (!perHousehold) {
    recipeCache.set(db, (perHousehold = new Map()));
    // Rebuild in the background shortly after a change (a save, a new price), so the next screen
    // usually finds a fresh cache instead of waiting for it.
    let timer: ReturnType<typeof setTimeout> | null = null;
    db.onRecipeWrite = () => {
      if (timer) return;
      timer = setTimeout(() => {
        timer = null;
        for (const h of perHousehold!.keys()) {
          try {
            cachedRecipes(db, h);
          } catch {
            /* database closed (tests) or busy: the next request rebuilds instead */
          }
        }
      }, 500);
      timer.unref?.();
    };
  }
  const hit = perHousehold.get(householdId);
  const version = cacheVersion(db, householdId);
  if (hit && hit.version === version) return hit;
  // One product query and one ingredient query for the whole library instead of one per recipe.
  const products = new Map(db.all('SELECT * FROM products WHERE household_id IS NULL OR household_id = ?', householdId).map((x) => [x.id as string, rowToProduct(x)]));
  const ingredients = new Map<string, Row[]>();
  for (const r of db.all('SELECT ri.* FROM recipe_ingredients ri JOIN recipes rc ON rc.id = ri.recipe_id WHERE rc.household_id IS NULL OR rc.household_id = ? ORDER BY ri.recipe_id, ri.position', householdId)) {
    const list = ingredients.get(r.recipe_id as string);
    if (list) list.push(r);
    else ingredients.set(r.recipe_id as string, [r]);
  }
  const retention = retentionFor(db, householdId);
  const ctx = subContext(db, householdId);
  const list = db
    .all('SELECT * FROM recipes WHERE household_id IS NULL OR household_id = ? ORDER BY title', householdId)
    .map((r) => deepFreeze(hydrate(db, r, products, ctx, retention.get(r.id as string), ingredients.get(r.id as string) ?? [])));
  const entry = { version, list: Object.freeze(list), byId: new Map(list.map((r) => [r.id, r])) };
  perHousehold.set(householdId, entry);
  return entry;
}

/** Every recipe this household can see, calculated (nutrition, score, diets, cost). Shared and read-only. */
export function listRecipes(db: Db, householdId: string): Recipe[] {
  // Frozen at runtime: callers copy (map/filter/slice) instead of changing it.
  return cachedRecipes(db, householdId).list as Recipe[];
}

/** A calculated recipe from the cache, read-only (getRecipe returns a fresh copy that may be changed). */
export function cachedRecipe(db: Db, householdId: string, id: string): Recipe | undefined {
  return cachedRecipes(db, householdId).byId.get(id);
}

export interface RecipeInput {
  title: string;
  summary?: string | null;
  cuisine?: string | null;
  tags?: string[];
  diet?: string[];
  difficulty?: string;
  servings: number;
  prep_minutes?: number;
  cook_minutes?: number;
  steps: { text: string; timerSeconds?: number }[];
  image_url?: string | null;
  emoji?: string | null;
  color?: string | null;
  origin: Recipe['origin'];
  source_name?: string | null;
  source_url?: string | null;
  attribution?: string | null;
  ingredients: { product_id?: string | null; name: string; quantity?: number | null; unit?: string | null; display?: string | null; optional?: boolean; match?: MatchKind | null; source_key?: string | null }[];
  servings_estimated?: boolean;
}

export function createRecipe(db: Db, householdId: string | null, input: RecipeInput, id = newId('r')): Recipe {
  db.tx(() => {
    db.insert('recipes', {
      id,
      household_id: householdId,
      title: input.title,
      summary: input.summary ?? null,
      cuisine: input.cuisine ?? null,
      tags: input.tags ?? [],
      diet: input.diet ?? [],
      difficulty: input.difficulty ?? 'easy',
      servings: input.servings,
      prep_minutes: input.prep_minutes ?? 0,
      cook_minutes: input.cook_minutes ?? 0,
      steps: input.steps,
      image_url: input.image_url ?? null,
      emoji: input.emoji ?? '🍽️',
      color: input.color ?? '#7A8B6F',
      origin: input.origin,
      source_name: input.source_name ?? null,
      source_url: input.source_url ?? null,
      attribution: input.attribution ?? null,
      servings_estimated: input.servings_estimated ? 1 : 0,
      created_at: clock.iso(),
    });
    input.ingredients.forEach((ing, i) =>
      db.insert('recipe_ingredients', {
        recipe_id: id,
        position: i,
        product_id: ing.product_id ?? null,
        name: ing.name,
        quantity: ing.quantity ?? null,
        unit: ing.unit ?? null,
        display: ing.display ?? null,
        optional: ing.optional ? 1 : 0,
        match: ing.match ?? (ing.product_id ? 'exact' : 'unresolved'),
        source_key: ing.source_key ?? (ing.product_id ? null : `u:${ing.name.toLowerCase().trim()}`),
      }),
    );
  });
  if (householdId) bus.touch(householdId, 'recipes');
  return getRecipe(db, householdId ?? '', id);
}

/** Replace an own recipe's content (title, amounts, matches, steps). Built-in recipes are copied first. */
export function updateRecipe(db: Db, householdId: string, id: string, input: Omit<RecipeInput, 'origin'>): Recipe {
  const own = db.get<{ id: string }>('SELECT id FROM recipes WHERE id = ? AND household_id = ?', id, householdId);
  if (!own) throw new AppError(403, 'not_own', 'Only recipes you added can be edited. Edit a copy instead.');
  db.tx(() => {
    db.update('recipes', id, {
      title: input.title, summary: input.summary ?? null, cuisine: input.cuisine ?? null, tags: input.tags ?? [], difficulty: input.difficulty ?? 'easy',
      servings: input.servings, prep_minutes: input.prep_minutes ?? 0, cook_minutes: input.cook_minutes ?? 0, steps: input.steps,
      ...(input.emoji ? { emoji: input.emoji } : {}),
    });
    db.run('DELETE FROM recipe_ingredients WHERE recipe_id = ?', id);
    input.ingredients.forEach((ing, i) =>
      db.insert('recipe_ingredients', { recipe_id: id, position: i, product_id: ing.product_id ?? null, name: ing.name, quantity: ing.quantity ?? null, unit: ing.unit ?? null, display: ing.display ?? null, optional: ing.optional ? 1 : 0, match: ing.match ?? (ing.product_id ? 'exact' : 'unresolved'), source_key: ing.source_key ?? (ing.product_id ? null : `u:${ing.name.toLowerCase().trim()}`) }),
    );
    // Positions may have changed: counted-share settings no longer point at the same ingredient.
    db.run('DELETE FROM recipe_retention WHERE household_id = ? AND recipe_id = ?', householdId, id);
  });
  bus.touch(householdId, 'recipes');
  return getRecipe(db, householdId, id);
}

/** Your own editable copy of any recipe (kept with its ratings history on the original). */
export function copyRecipe(db: Db, householdId: string, id: string): Recipe {
  const r = getRecipe(db, householdId, id);
  const copy = createRecipe(db, householdId, {
    title: r.title, summary: r.summary, cuisine: r.cuisine, tags: r.tags, difficulty: r.difficulty, servings: r.servings, prep_minutes: r.prep_minutes, cook_minutes: r.cook_minutes,
    steps: r.steps as any, image_url: r.image_url, emoji: r.emoji, color: r.color, origin: 'user', source_name: r.source_name, source_url: r.source_url, attribution: r.attribution,
    ingredients: r.ingredients.map((i) => ({ product_id: i.product_id, name: i.name, quantity: i.quantity, unit: i.unit, display: i.display, optional: i.optional })),
  });
  recordInteraction(db, householdId, copy.id, { saved: true });
  return copy;
}

// ---------- Matching against inventory ----------

export interface IngredientStatus {
  position: number;
  name: string;
  product_id: string | null;
  needed: number | null;
  available: number;
  unit: string | null;
  status: 'have' | 'partial' | 'missing' | 'staple' | 'unknown';
  expiringSoon: boolean;
  optional: boolean;
  substitutes: Substitute[];
}

export interface RecipeMatch {
  recipe: Recipe;
  servings: number;
  matchPct: number;
  missing: IngredientStatus[];
  ingredients: IngredientStatus[];
  usesExpiring: string[];
  missingCost: number;
  score: number;
  reasons: string[];
  suitability?: Suitability & { swaps: DietSwap[]; adaptable: boolean };
}

export interface Substitute { productId: string; name: string; ratio: number; note: string; available: number }
export interface DietSwap { position: number; from: string; to: { id: string; name: string }; note: string; ratio: number }

// Curated, role-based substitutions (ingredient function, not name similarity). ratio = substitute qty per original qty.
const SUBSTITUTIONS: [from: string, to: string, ratio: number, note: string][] = [
  ['p_cream', 'p_creme_fraiche', 1, 'Richer and slightly tangy; add off the boil'],
  ['p_cream', 'p_coconut_milk', 1, 'Dairy-free; adds a light coconut flavour'],
  ['p_cream', 'p_yoghurt', 1, 'Lighter; stir in at the end so it does not split'],
  ['p_creme_fraiche', 'p_cream', 1, 'Less tangy'],
  ['p_creme_fraiche', 'p_yoghurt', 1, 'Lighter; do not boil'],
  ['p_yoghurt', 'p_skyr', 1, 'Thicker and higher in protein'],
  ['p_yoghurt', 'p_quark', 1, 'Thicker; loosen with a little milk'],
  ['p_skyr', 'p_yoghurt', 1, 'Slightly runnier'],
  ['p_chicken_breast', 'p_chicken_thigh', 1, 'Juicier; cook 2–3 minutes longer'],
  ['p_chicken_breast', 'p_tofu', 1, 'Vegetarian; press and fry until golden first'],
  ['p_chicken_thigh', 'p_chicken_breast', 1, 'Leaner; take care not to overcook'],
  ['p_minced_beef', 'p_lentils', 0.5, 'Vegetarian; use half the weight of dry red lentils plus extra water'],
  ['p_minced_beef', 'p_kidney_beans', 1, 'Vegetarian and cheaper'],
  ['p_spinach', 'p_frozen_spinach', 1, 'Squeeze out excess water'],
  ['p_frozen_spinach', 'p_spinach', 1, 'Wilt it a little longer'],
  ['p_onion', 'p_red_onion', 1, 'Slightly sweeter'],
  ['p_onion', 'p_leek', 1.5, 'Milder; use the white and light green parts'],
  ['p_onion', 'p_spring_onion', 0.1, 'Use about 3 spring onions per onion'],
  ['p_red_onion', 'p_onion', 1, 'Sharper'],
  ['p_lemon', 'p_lime', 1.5, 'More aromatic'],
  ['p_lime', 'p_lemon', 0.7, 'Less floral'],
  ['p_parsley', 'p_coriander', 1, 'Different flavour, same freshness'],
  ['p_coriander', 'p_parsley', 1, 'Milder'],
  ['p_basil', 'p_parsley', 1, 'Less sweet; works in sauces'],
  ['p_butter', 'p_olive_oil', 0.8, 'For frying and sauces, not for baking'],
  ['p_olive_oil', 'p_sunflower_oil', 1, 'Neutral flavour'],
  ['p_sunflower_oil', 'p_olive_oil', 1, 'Fine for frying at medium heat'],
  ['p_parmesan', 'p_cheese', 1.2, 'Milder; grate finely'],
  ['p_cheese', 'p_parmesan', 0.7, 'Stronger flavour'],
  ['p_feta', 'p_mozzarella', 1, 'Milder, less salty'],
  ['p_canned_tomatoes', 'p_tomatoes', 4, 'About 4 fresh tomatoes per tin; cook a bit longer'],
  ['p_tomatoes', 'p_cherry_tomatoes', 6, 'About 6 cherry tomatoes per tomato'],
  ['p_tomatoes', 'p_canned_tomatoes', 100, 'For cooked dishes only (100 g per tomato)'],
  ['p_bell_pepper', 'p_zucchini', 1, 'Less sweet; similar texture when cooked'],
  ['p_zucchini', 'p_bell_pepper', 1, 'Sweeter'],
  ['p_broccoli', 'p_cauliflower', 1, 'Similar cooking time'],
  ['p_broccoli', 'p_green_beans', 1, 'Similar cooking time'],
  ['p_rice', 'p_noodles', 0.8, 'Changes the dish but works for stir-fries and curries'],
  ['p_noodles', 'p_pasta', 1, 'Spaghetti works well in stir-fries'],
  ['p_pasta', 'p_noodles', 1, 'For Asian-style dishes'],
  ['p_milk', 'p_whole_milk', 1, 'Creamier'],
  ['p_milk', 'p_oat_milk', 1, 'Dairy-free'],
  ['p_whole_milk', 'p_milk', 1, 'Lighter'],
  ['p_honey', 'p_sugar', 0.8, 'Use a little less'],
  ['p_wraps', 'p_bread', 1, 'Make it a sandwich'],
  ['p_salmon', 'p_tuna', 0.6, 'Tinned; add at the end'],
  ['p_kidney_beans', 'p_chickpeas', 1, 'Nuttier texture'],
  ['p_chickpeas', 'p_kidney_beans', 1, 'Softer texture'],
  ['p_berries', 'p_frozen_berries', 1, 'Thaw first or use straight from frozen in porridge'],
  ['p_skyr', 'p_quark', 1, 'Similar protein, slightly drier'],
  ['p_wok_vegetables', 'p_bell_pepper', 0.0066, 'About 2–3 peppers plus any other vegetables you have'],
  ['p_stock_cube', 'p_soy_sauce', 15, 'A splash of soy sauce for savoury depth'],
];

export function substitutesFor(productId: string | null, needed: number | null, stock: Map<string, StockItem>, needs?: DietaryNeeds, baking = false): Substitute[] {
  if (!productId) return [];
  // A swap whose own note rules out baking isn't offered for cakes and pastry.
  return SUBSTITUTIONS.filter(([from, , , note]) => from === productId && !(baking && /not for baking/.test(note)))
    .map(([, to, ratio, note]) => {
      const s = stock.get(to);
      const available = s ? (s.showEstimate ? s.estimated : s.confirmed) : 0;
      return { productId: to, name: s?.product.name ?? to.replace(/^p_/, '').replace(/_/g, ' '), ratio, note, available, product: s?.product };
    })
    // Never suggest a substitute someone can't eat.
    .filter((s) => !needs || !s.product || !productConflicts(s.product, needs).length)
    .filter((s) => s.available > 0 && (needed == null || s.available >= needed * s.ratio * 0.5))
    .slice(0, 3)
    .map(({ product, ...s }) => (void product, s));
}

/** For ingredients that clash with someone's needs: a swap that fits (in stock or not). */
export function dietSwaps(db: Db, conflicts: Suitability['conflicts'], needs: DietaryNeeds, recipe: Recipe): DietSwap[] {
  const out: DietSwap[] = [];
  for (const c of conflicts) {
    const ing = recipe.ingredients.find((i) => i.position === c.position);
    if (!ing?.product_id) continue;
    for (const [from, to, ratio, note] of SUBSTITUTIONS) {
      if (from !== ing.product_id) continue;
      const p = getProduct(db, to);
      if (p && !productConflicts(p, needs).length) {
        out.push({ position: c.position, from: c.name, to: { id: p.id, name: p.name }, note, ratio });
        break;
      }
    }
  }
  return out;
}

export function stockMap(db: Db, householdId: string): Map<string, StockItem> {
  return new Map(inventorySummary(db, householdId).items.map((s) => [s.product.id, s]));
}

export function matchRecipe(recipe: Recipe, stock: Map<string, StockItem>, servings = recipe.servings, needs?: DietaryNeeds): RecipeMatch {
  const factor = servings / recipe.servings;
  const statuses: IngredientStatus[] = [];
  let have = 0, total = 0, missingCost = 0;
  const expiring: string[] = [];
  for (const ing of recipe.ingredients) {
    const needed = ing.quantity != null ? ing.quantity * factor : null;
    const s = ing.product_id ? stock.get(ing.product_id) : undefined;
    const available = s ? (s.showEstimate ? s.estimated : s.confirmed) : 0;
    const expiringSoon = !!s && s.daysToExpiry != null && s.daysToExpiry <= 3;
    let status: IngredientStatus['status'];
    if (ing.product?.staple && !s) status = 'staple';
    else if (!ing.product_id) status = 'unknown';
    else if (needed == null) status = available > 0 ? 'have' : 'missing';
    else if (available >= needed * 0.95) status = 'have';
    else if (available > 0) status = 'partial';
    else status = 'missing';
    const st: IngredientStatus = {
      position: ing.position,
      name: ing.product?.name ?? ing.name,
      product_id: ing.product_id,
      needed,
      available,
      unit: ing.product?.unit ?? ing.unit,
      status,
      expiringSoon,
      optional: ing.optional,
      substitutes: status === 'missing' || status === 'partial' ? substitutesFor(ing.product_id, needed, stock, needs, recipe.tags.some((t) => t === 'baking' || t === 'dessert')) : [],
    };
    statuses.push(st);
    if (expiringSoon && available > 0) expiring.push(st.name);
    if (ing.optional || status === 'staple') continue;
    total++;
    if (status === 'have') have++;
    else if (status === 'partial') have += needed ? Math.min(0.9, available / needed) : 0.5;
    else if (st.substitutes.length) have += 0.6;
    if ((status === 'missing' || status === 'partial') && ing.product && needed != null && !st.substitutes.length) {
      missingCost += costFor(ing.product, needed - available) ?? 0;
    }
  }
  const matchPct = total ? Math.round((have / total) * 100) : 100;
  return {
    recipe,
    servings,
    matchPct,
    ingredients: statuses,
    missing: statuses.filter((s) => !s.optional && (s.status === 'missing' || s.status === 'partial')),
    usesExpiring: expiring,
    missingCost: Math.round(missingCost * 100) / 100,
    score: 0,
    reasons: [],
  };
}

// ---------- Search and recommendations ----------

export interface RecipeQuery {
  q?: string;
  ingredient?: string;
  cuisine?: string;
  diet?: string;
  maxMinutes?: number;
  maxCostPerServing?: number;
  maxKcal?: number;
  minProtein?: number;
  difficulty?: string;
  servings?: number;
  tag?: string;
  origin?: string;
  saved?: boolean;
  sort?: 'best' | 'match' | 'time' | 'protein' | 'cost';
  limit?: number;
  /** 'full': only recipes with exact ingredients; 'available': with substitutions allowed. */
  compat?: 'full' | 'available';
  /** Also return recipes that don't fit the household's dietary needs (flagged, never hidden silently). */
  includeUnsuitable?: boolean;
}

/** Suitability for this household, plus swaps that would make it fit. */
export function suitabilityFor(db: Db, recipe: Recipe, needs: DietaryNeeds) {
  const s = recipeSuitability(recipe, needs);
  const swaps = s.ok ? [] : dietSwaps(db, s.conflicts, needs, recipe);
  // A swap can fix an allergy or something avoided (oat milk for milk), but not a diet: a "chicken curry
  // with tofu" is still offered to a vegetarian as a chicken curry, so those are left out.
  const forDiet = s.conflicts.some((c) => c.reasons.some((x) => x.startsWith('diet:')));
  const adaptable = !s.ok && !s.notes.length && !forDiet && s.conflicts.length > 0 && swaps.length === s.conflicts.length;
  return { ...s, swaps, adaptable };
}

export function recipePreferences(db: Db, householdId: string) {
  const pref = (k: string, d: any) => parseJson(db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = '' AND key = ?", householdId, k)?.value, d);
  return {
    diet: pref('diet', []) as string[],
    dislikes: pref('dislikes', []) as string[], // product ids
    cuisines: pref('cuisines', []) as string[],
    maxWeeknightMinutes: pref('maxWeeknightMinutes', 45) as number,
  };
}

export function searchRecipes(db: Db, householdId: string, query: RecipeQuery = {}): RecipeMatch[] {
  const stock = stockMap(db, householdId);
  const prefs = recipePreferences(db, householdId);
  const needs = dietaryNeeds(db, householdId);
  const interactions = new Map(db.all('SELECT * FROM recipe_interactions WHERE household_id = ?', householdId).map((r) => [r.recipe_id, r]));
  const q = query.q?.toLowerCase().trim();
  const results: RecipeMatch[] = [];
  for (const r of listRecipes(db, householdId)) {
    const minutes = r.prep_minutes + r.cook_minutes;
    const inter = interactions.get(r.id);
    if (q) {
      const hay = [r.title, r.summary, r.cuisine, ...r.tags, ...r.diet, ...r.ingredients.map((i) => `${i.name} ${i.product?.name ?? ''} ${i.product?.name_nl ?? ''}`)].join(' ').toLowerCase();
      if (!q.split(/\s+/).every((t) => hay.includes(t))) continue;
    }
    if (query.ingredient) {
      const ing = query.ingredient.toLowerCase();
      if (!r.ingredients.some((i) => [i.name, i.product?.name, i.product?.name_nl, ...(i.product?.synonyms ?? [])].some((n) => n?.toLowerCase().includes(ing)))) continue;
    }
    if (query.cuisine && r.cuisine?.toLowerCase() !== query.cuisine.toLowerCase()) continue;
    // Several diets ("vegetarian,pescatarian") widen the list: a recipe that fits any of them is shown.
    const diets = query.diet ? query.diet.split(',').map((d) => d.trim()).filter(Boolean) : [];
    if (diets.length && !diets.some((d) => r.diet.includes(d))) continue;
    if (query.tag && !r.tags.includes(query.tag)) continue;
    if (query.origin && r.origin !== query.origin) continue;
    if (query.saved && !inter?.saved) continue;
    if (query.difficulty && r.difficulty !== query.difficulty) continue;
    if (query.maxMinutes && minutes > query.maxMinutes) continue;
    if (query.maxCostPerServing && (r.costPerServing ?? 0) > query.maxCostPerServing) continue;
    if (query.maxKcal && (r.nutritionPerServing?.kcal ?? 0) > query.maxKcal) continue;
    if (query.minProtein && (r.nutritionPerServing?.protein ?? 0) < query.minProtein) continue;
    // Dietary needs of everyone in the household: unsuitable recipes are left out, unless a swap fixes them.
    const suit = suitabilityFor(db, r, needs);
    if (!suit.ok && !suit.adaptable && !query.includeUnsuitable) continue;

    const m = matchRecipe(r, stock, query.servings ?? r.servings, needs);
    m.suitability = suit;
    const reasons: string[] = [];
    let score = (m.matchPct / 100) * 0.45;
    if (suit.adaptable) {
      score -= 0.05;
      reasons.push(`Swap ${suit.swaps.map((s) => `${s.from.toLowerCase()} for ${s.to.name.toLowerCase()}`).join(', ')}`);
    }
    if (m.usesExpiring.length) {
      score += Math.min(0.25, 0.12 * m.usesExpiring.length);
      reasons.push(`Uses ${m.usesExpiring.slice(0, 2).join(' & ')} before ${m.usesExpiring.length > 1 ? 'they go' : 'it goes'} off`);
    }
    if (m.matchPct === 100) reasons.push('You have everything');
    else if (m.missing.length <= 2) reasons.push(`Only missing ${m.missing.map((x) => x.name.toLowerCase()).join(' & ')}`);
    if (inter) {
      if (inter.rating) score += (inter.rating - 3) * 0.04;
      if (inter.saved) score += 0.05;
      score += Math.min(0.08, inter.cooked_count * 0.02);
      score -= Math.min(0.15, inter.skipped_count * 0.04);
      if (inter.last_cooked_at && daysBetween(inter.last_cooked_at, clock.now()) < 5) score -= 0.15;
      if (inter.rating >= 4) reasons.push('You rated this highly');
    }
    if (prefs.cuisines.includes(r.cuisine ?? '')) score += 0.06;
    if (minutes <= prefs.maxWeeknightMinutes) score += 0.06;
    if (r.origin === 'ai') score -= 0.02;
    // Practical with Dutch supermarket ingredients first.
    if (r.compat.level === 'specialist') score -= 0.3;
    else if (r.compat.level === 'partial') score -= 0.12;
    if (query.compat === 'full' && r.compat.level !== 'full') continue;
    if (query.compat === 'available' && (r.compat.level === 'specialist' || r.compat.level === 'partial')) continue;
    m.score = Math.round(score * 1000) / 1000;
    m.reasons = reasons;
    results.push(m);
  }
  const sort = query.sort ?? 'best';
  results.sort((a, b) => {
    switch (sort) {
      case 'match': return b.matchPct - a.matchPct || b.score - a.score;
      case 'time': return a.recipe.prep_minutes + a.recipe.cook_minutes - (b.recipe.prep_minutes + b.recipe.cook_minutes);
      case 'protein': return (b.recipe.nutritionPerServing?.protein ?? 0) - (a.recipe.nutritionPerServing?.protein ?? 0);
      case 'cost': return (a.recipe.costPerServing ?? 99) - (b.recipe.costPerServing ?? 99);
      default: return b.score - a.score;
    }
  });
  return results.slice(0, query.limit ?? 50);
}

export function recordInteraction(db: Db, householdId: string, recipeId: string, patch: { saved?: boolean; rating?: number | null; priority?: number; notes?: string | null; toTry?: boolean; ease?: number | null; again?: boolean | null; swapped?: boolean; cooked?: boolean; skipped?: boolean }) {
  db.run('INSERT OR IGNORE INTO recipe_interactions (household_id, recipe_id) VALUES (?, ?)', householdId, recipeId);
  if (patch.saved !== undefined) db.run('UPDATE recipe_interactions SET saved = ? WHERE household_id = ? AND recipe_id = ?', patch.saved ? 1 : 0, householdId, recipeId);
  if (patch.rating !== undefined) db.run('UPDATE recipe_interactions SET rating = ? WHERE household_id = ? AND recipe_id = ?', patch.rating, householdId, recipeId);
  if (patch.priority !== undefined) db.run('UPDATE recipe_interactions SET priority = ? WHERE household_id = ? AND recipe_id = ?', patch.priority, householdId, recipeId);
  if (patch.notes !== undefined) db.run('UPDATE recipe_interactions SET notes = ? WHERE household_id = ? AND recipe_id = ?', patch.notes || null, householdId, recipeId);
  if (patch.toTry !== undefined) db.run('UPDATE recipe_interactions SET to_try = ? WHERE household_id = ? AND recipe_id = ?', patch.toTry ? 1 : 0, householdId, recipeId);
  if (patch.ease !== undefined) db.run('UPDATE recipe_interactions SET ease = ? WHERE household_id = ? AND recipe_id = ?', patch.ease, householdId, recipeId);
  if (patch.again !== undefined) db.run('UPDATE recipe_interactions SET again = ? WHERE household_id = ? AND recipe_id = ?', patch.again == null ? null : patch.again ? 1 : 0, householdId, recipeId);
  if (patch.swapped) db.run('UPDATE recipe_interactions SET swapped_count = swapped_count + 1 WHERE household_id = ? AND recipe_id = ?', householdId, recipeId);
  // Cooking a recipe you wanted to try ticks it off.
  if (patch.cooked) db.run('UPDATE recipe_interactions SET to_try = 0 WHERE household_id = ? AND recipe_id = ?', householdId, recipeId);
  if (patch.cooked) db.run('UPDATE recipe_interactions SET cooked_count = cooked_count + 1, last_cooked_at = ? WHERE household_id = ? AND recipe_id = ?', clock.iso(), householdId, recipeId);
  if (patch.skipped) db.run('UPDATE recipe_interactions SET skipped_count = skipped_count + 1 WHERE household_id = ? AND recipe_id = ?', householdId, recipeId);
  bus.touch(householdId, 'recipes');
}

// ---------- Cooking ----------

export interface CookInput {
  recipeId: string;
  servings: number;
  /** Override per ingredient: actual quantity used (base units), or 0 to skip. Substitutions use productId. */
  overrides?: { position: number; quantity?: number; productId?: string }[];
  leftovers?: { fridge?: number; freezer?: number };
  mealSlotId?: string | null;
  /** false: log the meal without taking ingredients out of stock. */
  deduct?: boolean;
}

export interface CookResult {
  batchId: string;
  deducted: { productId: string; name: string; quantity: number; shortfall: number; unit: string }[];
  leftoverLots: string[];
}

/** Cook a recipe: deduct ingredients via the ledger (type 'cook') and create leftover lots. */
export function cookRecipe(ctx: Ctx, input: CookInput): CookResult {
  if (!(input.servings > 0)) throw new AppError(422, 'invalid_servings', 'Servings must be positive');
  const recipe = getRecipe(ctx.db, ctx.householdId, input.recipeId);
  const factor = input.servings / recipe.servings;
  const out: CookResult = { batchId: ctx.batchId, deducted: [], leftoverLots: [] };
  ctx.db.tx(() => {
    // With automatic deductions switched off (Settings → Personalise), cooking only logs the meal.
    for (const ing of input.deduct === false ? [] : recipe.ingredients) {
      const o = input.overrides?.find((x) => x.position === ing.position);
      const productId = o?.productId ?? ing.product_id;
      if (!productId) continue;
      let qty = o?.quantity ?? (ing.quantity != null ? ing.quantity * factor : null);
      if (o?.productId && o.productId !== ing.product_id && o.quantity == null && qty != null) {
        const sub = SUBSTITUTIONS.find(([f, t]) => f === ing.product_id && t === o.productId);
        const to = sub ? null : getProduct(ctx.db, o.productId);
        if (sub) qty *= sub[2];
        else if (to && ing.product) qty = convertQty(qty, ing.product, to) ?? qty; // grams of rice stay grams, pieces become grams
      }
      if (qty == null || qty <= 0) continue;
      // Optional ingredients are only deducted if they are in stock.
      const lots = ctx.db.get<{ q: number }>("SELECT COALESCE(SUM(quantity),0) q FROM inventory_lots WHERE household_id = ? AND product_id = ? AND status = 'active'", ctx.householdId, productId)!.q;
      if (lots <= 0) {
        if (!ing.optional) out.deducted.push({ productId, name: ing.product?.name ?? ing.name, quantity: 0, shortfall: qty, unit: ing.product?.unit ?? '' });
        continue;
      }
      const r = deduct(ctx, { productId, quantity: qty, type: 'cook', meta: { recipeId: recipe.id, servings: input.servings } });
      out.deducted.push({ productId, name: ing.product?.name ?? ing.name, quantity: r.deducted, shortfall: ing.optional ? 0 : r.shortfall, unit: ing.product?.unit ?? '' });
    }
    for (const [where, n] of [['fridge', input.leftovers?.fridge ?? 0], ['freezer', input.leftovers?.freezer ?? 0]] as const) {
      if (n > 0) {
        const { lot } = addStock(ctx, {
          quantity: n,
          unit: 'portion',
          label: recipe.title,
          isLeftover: true,
          recipeId: recipe.id,
          location: where,
          expiresOn: addDays(clock.today(), where === 'freezer' ? 90 : 3),
          type: 'leftover',
        });
        out.leftoverLots.push(lot.id);
      }
    }
    recordInteraction(ctx.db, ctx.householdId, recipe.id, { cooked: true });
    ctx.db.insert('cook_log', { id: newId('ck'), household_id: ctx.householdId, recipe_id: recipe.id, servings: input.servings, batch_id: ctx.batchId, created_at: clock.iso() });
    if (input.mealSlotId) {
      ctx.db.run("UPDATE meal_slots SET status = 'cooked', cook_batch_id = ?, servings = ? WHERE id = ? AND household_id = ?", ctx.batchId, input.servings, input.mealSlotId, ctx.householdId);
      bus.touch(ctx.householdId, 'planner');
    }
  });
  return out;
}

/** Eat, freeze or discard leftover portions. */
export function useLeftover(ctx: Ctx, lotId: string, action: 'eat' | 'discard', portions: number) {
  return deduct(ctx, { lotId, quantity: portions, type: action === 'eat' ? 'consume' : 'discard', reason: action === 'discard' ? 'leftover' : null });
}
