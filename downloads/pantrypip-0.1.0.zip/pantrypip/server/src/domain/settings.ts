// Settings: one schema, one place. Every household and personal preference is declared here with
// its default and its validation. Reads validate what's stored (migrating old shapes, falling back
// to the default for anything invalid, never failing); writes are key-level patches, validated
// before anything is stored, so one setting can never overwrite another and defaults never
// replace a saved value. Storage stays in the `preferences` table under the keys the rest of the
// server already reads (user_id '' = household, a user id = personal).
import { z } from 'zod/v4';
import type { Db } from '../db/db.ts';
import { parseJson } from '../db/db.ts';
import { AppError } from '../errors.ts';

export const MEAL_TYPES = ['quick', 'one-pan', 'traybake', 'soup', 'salad', 'pasta', 'curry', 'bowl', 'comfort', 'batch-cook', 'family', 'no-cook', 'budget', 'low-carb', 'high-protein'] as const;
export const DEFAULT_NOTIFICATIONS = { expiry: true, shopping: true, prep: false, plan: true, streak: false, challenge: true, frequency: 'all' as 'all' | 'daily' | 'off', prepTime: '17:00' };
export const DEFAULT_INTERACTION = { voiceFirst: true, autoDeduct: true, shoppingAutoComplete: true, cookReadAloud: false, cookHandsFree: false, keepAwake: true, confirmDestructive: false };

const level = z.enum(['low', 'normal', 'high']);
const hhmm = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/);

/** Household settings: shared by everyone in the kitchen. Key → [schema, default]. */
export const HOUSEHOLD = {
  language: [z.enum(['en', 'nl', 'auto']), 'auto'],
  householdSize: [z.number().int().min(1).max(20), 2],
  diet: [z.array(z.string().max(40)).max(20), []],
  dislikes: [z.array(z.string().max(60)).max(100), []],
  cuisines: [z.array(z.string().max(40)).max(40), []],
  favouriteFoods: [z.array(z.string().max(60)).max(60), []],
  mealTypes: [z.array(z.enum(MEAL_TYPES)).max(MEAL_TYPES.length), []],
  maxWeeknightMinutes: [z.number().int().min(5).max(240).nullable(), 45],
  maxWeekendMinutes: [z.number().int().min(5).max(480).nullable(), null],
  maxDifficulty: [z.enum(['easy', 'medium', 'hard']), 'hard'],
  planDays: [z.array(z.number().int().min(0).max(6)).max(7), [0, 1, 2, 3, 4, 5, 6]],
  planningDay: [z.number().int().min(0).max(6), 0],
  autoPlanFifo: [z.enum(['off', 'balanced', 'strong']), 'balanced'],
  ratingWeight: [level, 'normal'],
  overlap: [level, 'normal'],
  variety: [level, 'normal'],
  budgetPerServing: [z.number().min(0.5).max(50).nullable(), null],
  newPerWeek: [z.number().int().min(0).max(7).nullable(), null],
  nutritionPriorities: [z.array(z.enum(['protein', 'fibre', 'veg', 'lessSalt', 'lessSugar', 'lessSatFat'])).max(6), []],
  scoringSensitivity: [z.enum(['gentle', 'standard', 'strict']), 'standard'],
  nutritionTargets: [z.object({ fibre: z.number().min(10).max(80), saltMax: z.number().min(1).max(15), satFatPct: z.number().min(5).max(20), sugarPct: z.number().min(5).max(30), carbMinPct: z.number().min(0).max(60), carbMaxPct: z.number().min(20).max(80) }).partial(), {}],
  xpRules: [z.record(z.string(), z.number().int().min(0).max(500)), {}],
  notifications: [z.object({
    expiry: z.boolean(), shopping: z.boolean(), prep: z.boolean(), plan: z.boolean(), streak: z.boolean(), challenge: z.boolean(),
    frequency: z.enum(['all', 'daily', 'off']), prepTime: hhmm,
  }), DEFAULT_NOTIFICATIONS],
  interaction: [z.object({
    voiceFirst: z.boolean(), autoDeduct: z.boolean(), shoppingAutoComplete: z.boolean(), cookReadAloud: z.boolean(), cookHandsFree: z.boolean(), keepAwake: z.boolean(), confirmDestructive: z.boolean(),
  }), DEFAULT_INTERACTION],
  cookCheckin: [z.object({ enabled: z.boolean(), time: hhmm }), { enabled: true, time: '20:00' }],
  quickActions: [z.array(z.object({ productId: z.string(), quantity: z.number().positive(), label: z.string().max(40) })).max(12), []],
  // Where you shop: the country (from your location until you pick one) and your supermarkets (none = all).
  country: [z.string().regex(/^[A-Z]{2}$/), 'NL'],
  countrySource: [z.enum(['auto', 'manual']), 'auto'],
  chains: [z.array(z.string().max(30)).max(30), []],
} as const satisfies Record<string, readonly [z.ZodType, unknown]>;

/** Personal settings: follow you to every device you sign in on. */
export const PERSONAL = {
  language: [z.enum(['en', 'nl', 'auto']), 'auto'],
  appearance: [z.object({
    style: z.enum(['larder', 'lavender', 'herb', 'citrus', 'night', 'ink']), theme: z.enum(['system', 'light', 'dark']),
    density: z.enum(['comfortable', 'compact']), cards: z.enum(['soft', 'outlined', 'flat']), motion: z.enum(['full', 'reduced', 'off']),
    textSize: z.enum(['normal', 'large']), showMoney: z.boolean(),
  }), { style: 'larder', theme: 'system', density: 'comfortable', cards: 'soft', motion: 'full', textSize: 'normal', showMoney: true }],
  startPage: [z.enum(['home', 'groceries', 'recipes', 'plan', 'progress']), 'home'],
} as const satisfies Record<string, readonly [z.ZodType, unknown]>;

type Spec = Record<string, readonly [z.ZodType, unknown]>;
const OBJECT_KEYS = new Set(['nutritionTargets', 'xpRules', 'notifications', 'interaction', 'cookCheckin', 'appearance']);

/** Older stored shapes, turned into today's. */
function migrate(key: string, v: unknown): unknown {
  if (key === 'autoPlanFifo' && typeof v === 'boolean') return v ? 'balanced' : 'off';
  return v;
}

/** One stored value, validated. Objects are validated field by field so one bad field doesn't lose the rest. */
function readValue(spec: Spec, key: string, raw: string | undefined): unknown {
  const [schema, def] = spec[key];
  if (raw === undefined) return structuredClone(def);
  const v = migrate(key, parseJson(raw, undefined));
  if (OBJECT_KEYS.has(key) && v && typeof v === 'object' && !Array.isArray(v) && def && typeof def === 'object') {
    const shape = (schema as any).shape ?? null;
    const out: Record<string, unknown> = { ...(def as object) };
    for (const [k, val] of Object.entries(v)) {
      if (!shape) {
        // A record (xpRules): keep valid entries.
        if ((schema as any).safeParse({ [k]: val }).success) out[k] = val;
        continue;
      }
      const field = shape[k];
      if (field && field.safeParse(val).success) out[k] = val;
    }
    return out;
  }
  const r = schema.safeParse(v);
  return r.success ? r.data : structuredClone(def);
}

const rows = (db: Db, h: string, user: string) => new Map(db.all<{ key: string; value: string }>('SELECT key, value FROM preferences WHERE household_id = ? AND user_id = ?', h, user).map((r) => [r.key, r.value]));
const revKey = 'settingsRev';

export function readSettings(db: Db, h: string, userId: string) {
  const hh = rows(db, h, '');
  const me = rows(db, h, userId);
  const household = Object.fromEntries(Object.keys(HOUSEHOLD).map((k) => [k, readValue(HOUSEHOLD, k, hh.get(k))]));
  const personal = Object.fromEntries(Object.keys(PERSONAL).map((k) => [k, readValue(PERSONAL, k, me.get(k))]));
  // Language used to be household-wide only; until you choose your own, you get the household's.
  if (!me.has('language') && hh.has('language')) personal.language = household.language;
  return { household, me: personal, rev: Number(hh.get(revKey) ?? 0) };
}

const patchSchema = (spec: Spec) =>
  z.object(Object.fromEntries(Object.entries(spec).map(([k, [schema]]) => [k, (OBJECT_KEYS.has(k) && (schema as any).shape ? (schema as any).partial() : schema).optional()]))).strict();
const PATCH = z.object({ household: patchSchema(HOUSEHOLD).optional(), me: patchSchema(PERSONAL).optional() }).strict();
export type SettingsPatch = z.infer<typeof PATCH>;

/**
 * Apply a patch: only the keys sent are written, object settings are merged field by field, and
 * everything is validated first: a rejected patch changes nothing. Returns the full, fresh settings.
 */
export function patchSettings(db: Db, h: string, userId: string, body: unknown, check?: (p: SettingsPatch) => void) {
  const parsed = PATCH.safeParse(body);
  if (!parsed.success) throw new AppError(422, 'invalid_settings', 'Some settings were not valid', parsed.error.issues.map((i) => ({ path: i.path.join('.'), message: i.message })));
  const p = parsed.data;
  check?.(p);
  const current = readSettings(db, h, userId);
  const put = (user: string, key: string, value: unknown) => db.run('INSERT INTO preferences (household_id, user_id, key, value) VALUES (?, ?, ?, ?) ON CONFLICT(household_id, user_id, key) DO UPDATE SET value = excluded.value', h, user, key, JSON.stringify(value));
  db.tx(() => {
    for (const [k, v] of Object.entries(p.household ?? {})) {
      if (v === undefined) continue;
      put('', k, OBJECT_KEYS.has(k) ? { ...(current.household[k] as object), ...(v as object) } : v);
    }
    for (const [k, v] of Object.entries(p.me ?? {})) {
      if (v === undefined) continue;
      put(userId, k, OBJECT_KEYS.has(k) ? { ...(current.me[k] as object), ...(v as object) } : v);
      // Reminders are sent per household; they follow the language you pick.
      if (k === 'language') put('', 'language', v);
    }
    put('', revKey, current.rev + 1);
  });
  return readSettings(db, h, userId);
}

/** One household setting, validated (what the planner, reminders and check-ins use). */
export function householdSetting<K extends keyof typeof HOUSEHOLD>(db: Db, h: string, key: K): any {
  const raw = db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = '' AND key = ?", h, key)?.value;
  return readValue(HOUSEHOLD, key, raw);
}
