// Shared shopping lists: one named list between friends in different households, for shopping together.
// A household's own list (shopping.ts) stays as it is; this one belongs to its members, not a household.
// Only joined members can read or change it. Everyone sees edits live (the bus, per person), who added,
// claimed ("I'll get this") and ticked each item. Finishing puts what *you* ticked into *your* household's
// stock, never anyone else's.
import type { Db } from '../db/db.ts';
import { newId } from '../db/db.ts';
import { clock } from '../clock.ts';
import { bus } from '../bus.ts';
import { AppError, notFound, badRequest } from '../errors.ts';
import { CATEGORY_LABELS } from '../db/catalogue.ts';
import { getProduct, resolveProduct, type Product } from './products.ts';
import { addStock, type Ctx } from './ledger.ts';
import { formatQty } from './units.ts';

type Me = { id: string; name: string; household_id: string };
interface ListRow { id: string; name: string; owner_id: string; created_at: string; updated_at: string }
interface MemberRow { list_id: string; user_id: string; status: 'invited' | 'joined'; invited_by: string | null; created_at: string; joined_at: string | null }
export interface SharedItemRow {
  id: string; list_id: string; product_id: string | null; name: string; category: string; packages: number | null; note: string | null;
  added_by: string | null; claimed_by: string | null; checked_by: string | null; checked_at: string | null; bought_by: string | null; bought_at: string | null;
  created_at: string; updated_at: string;
}

export const MAX_MEMBERS = 12;

/** The bus channel for one person (their stream listens to it as well as their household's). */
export const userChannel = (userId: string) => `user:${userId}`;

const areFriends = (db: Db, a: string, b: string) =>
  !!db.get("SELECT 1 FROM friendships WHERE status = 'accepted' AND ((requester_id = ? AND addressee_id = ?) OR (requester_id = ? AND addressee_id = ?))", a, b, b, a);
const listRow = (db: Db, id: string) => db.get<ListRow>('SELECT * FROM shared_lists WHERE id = ?', id);
const memberRow = (db: Db, listId: string, userId: string) => db.get<MemberRow>('SELECT * FROM shared_list_members WHERE list_id = ? AND user_id = ?', listId, userId);
const peopleOf = (db: Db, listId: string) => db.all<MemberRow & { name: string; household_id: string }>(
  // The owner first (they're added in the same millisecond as the first invites), then in the order they were added.
  'SELECT m.*, u.name, u.household_id FROM shared_list_members m JOIN users u ON u.id = m.user_id JOIN shared_lists l ON l.id = m.list_id WHERE m.list_id = ? ORDER BY m.user_id = l.owner_id DESC, m.created_at, u.name', listId,
);

/** Tell every member's screens (and invitees, so their invite card updates) that this list changed. */
export function touchList(db: Db, listId: string, extra: string[] = []) {
  for (const id of new Set([...db.all<{ user_id: string }>('SELECT user_id FROM shared_list_members WHERE list_id = ?', listId).map((r) => r.user_id), ...extra])) bus.touch(userChannel(id), 'shared');
}

/** The list, if you've joined it. Outsiders (and people only invited) get a 404, as if it didn't exist. */
function joined(db: Db, me: Me, listId: string): ListRow {
  const l = listRow(db, listId);
  if (!l || memberRow(db, listId, me.id)?.status !== 'joined') throw notFound('Shared list');
  return l;
}
const ownerOnly = (l: ListRow, me: Me) => {
  if (l.owner_id !== me.id) throw new AppError(403, 'owner_only', 'Only the person who made this list can do that');
};
const bumped = (db: Db, listId: string) => db.run('UPDATE shared_lists SET updated_at = ? WHERE id = ?', clock.iso(), listId);

/** Add friends as invitees. Only accepted friends of the inviter; people already on the list are skipped. */
function inviteInto(db: Db, me: Me, listId: string, friendIds: string[]) {
  const invited: { id: string; name: string; household_id: string }[] = [];
  const count = () => db.get<{ n: number }>('SELECT COUNT(*) n FROM shared_list_members WHERE list_id = ?', listId)!.n;
  for (const id of new Set(friendIds)) {
    if (id === me.id || memberRow(db, listId, id)) continue;
    if (!areFriends(db, me.id, id)) throw new AppError(403, 'not_friends', 'You can only invite friends');
    if (count() >= MAX_MEMBERS) throw new AppError(409, 'list_full', `A shared list has room for ${MAX_MEMBERS} people`);
    db.insert('shared_list_members', { list_id: listId, user_id: id, status: 'invited', invited_by: me.id, created_at: clock.iso(), joined_at: null });
    invited.push(db.get<{ id: string; name: string; household_id: string }>('SELECT id, name, household_id FROM users WHERE id = ?', id)!);
  }
  return invited;
}

export function createSharedList(db: Db, me: Me, name: string, friendIds: string[] = []) {
  const id = newId('sl');
  const now = clock.iso();
  db.insert('shared_lists', { id, name: name.trim(), owner_id: me.id, created_at: now, updated_at: now });
  db.insert('shared_list_members', { list_id: id, user_id: me.id, status: 'joined', invited_by: null, created_at: now, joined_at: now });
  const invited = inviteInto(db, me, id, friendIds);
  touchList(db, id);
  return { id, invited };
}

export function inviteToList(db: Db, me: Me, listId: string, friendIds: string[]) {
  const l = joined(db, me, listId);
  ownerOnly(l, me);
  const invited = inviteInto(db, me, listId, friendIds);
  touchList(db, listId);
  return { invited, name: l.name };
}

/** Join a list you were invited to, or decline (the invite goes). */
export function answerInvite(db: Db, me: Me, listId: string, join: boolean) {
  const m = memberRow(db, listId, me.id);
  if (!m || m.status !== 'invited') throw notFound('Invite');
  if (join) db.run("UPDATE shared_list_members SET status = 'joined', joined_at = ? WHERE list_id = ? AND user_id = ?", clock.iso(), listId, me.id);
  else db.run('DELETE FROM shared_list_members WHERE list_id = ? AND user_id = ?', listId, me.id);
  touchList(db, listId, [me.id]);
  return { owner: db.get<{ id: string; household_id: string }>('SELECT u.id, u.household_id FROM shared_lists l JOIN users u ON u.id = l.owner_id WHERE l.id = ?', listId)! };
}

/** Leave a list (or, for the owner, take someone off it). The owner can't leave; they delete it instead. */
export function removeMember(db: Db, me: Me, listId: string, userId: string) {
  const l = listRow(db, listId);
  const mine = l && memberRow(db, listId, me.id);
  if (!l || !mine || mine.status !== 'joined') throw notFound('Shared list');
  if (userId !== me.id) ownerOnly(l, me);
  if (userId === l.owner_id) throw new AppError(409, 'owner_stays', 'The person who made the list can delete it instead');
  if (!memberRow(db, listId, userId)) throw notFound('Member');
  db.run('DELETE FROM shared_list_members WHERE list_id = ? AND user_id = ?', listId, userId);
  // Their claims and ticks go back to the others.
  db.run('UPDATE shared_list_items SET claimed_by = NULL WHERE list_id = ? AND claimed_by = ?', listId, userId);
  db.run('UPDATE shared_list_items SET checked_by = NULL, checked_at = NULL WHERE list_id = ? AND checked_by = ? AND bought_at IS NULL', listId, userId);
  touchList(db, listId, [userId]);
}

export function renameSharedList(db: Db, me: Me, listId: string, name: string) {
  const l = joined(db, me, listId);
  ownerOnly(l, me);
  db.run('UPDATE shared_lists SET name = ?, updated_at = ? WHERE id = ?', name.trim(), clock.iso(), listId);
  touchList(db, listId);
}

export function deleteSharedList(db: Db, me: Me, listId: string) {
  const l = joined(db, me, listId);
  ownerOnly(l, me);
  const members = db.all<{ user_id: string }>('SELECT user_id FROM shared_list_members WHERE list_id = ?', listId).map((r) => r.user_id);
  db.run('DELETE FROM shared_lists WHERE id = ?', listId);
  members.forEach((id) => bus.touch(userChannel(id), 'shared'));
}

/** Your shared lists and the invites waiting for you. */
export function sharedListsFor(db: Db, me: Me) {
  const rows = db.all<ListRow & { status: 'invited' | 'joined'; invited_by: string | null }>(
    'SELECT l.*, m.status, m.invited_by FROM shared_lists l JOIN shared_list_members m ON m.list_id = l.id WHERE m.user_id = ? ORDER BY l.updated_at DESC', me.id,
  );
  const nameOf = (id: string | null) => (id ? db.get<{ name: string }>('SELECT name FROM users WHERE id = ?', id)?.name ?? null : null);
  return {
    lists: rows.filter((r) => r.status === 'joined').map((r) => {
      const counts = db.get<{ open: number; cart: number }>('SELECT COALESCE(SUM(checked_by IS NULL), 0) open, COALESCE(SUM(checked_by IS NOT NULL), 0) cart FROM shared_list_items WHERE list_id = ? AND bought_at IS NULL', r.id)!;
      return {
        id: r.id, name: r.name, mine: r.owner_id === me.id, owner: nameOf(r.owner_id), updatedAt: r.updated_at, ...counts,
        members: peopleOf(db, r.id).filter((p) => p.status === 'joined').map((p) => ({ id: p.user_id, name: p.name })),
      };
    }),
    invites: rows.filter((r) => r.status === 'invited').map((r) => ({ id: r.id, name: r.name, by: nameOf(r.invited_by) ?? nameOf(r.owner_id) })),
  };
}

const labelFor = (i: SharedItemRow, p: Product | null | undefined) => {
  if (!i.packages) return '';
  if (!p) return i.packages > 1 ? `${i.packages}×` : '';
  return i.packages > 1 || p.unit !== 'pcs' || p.package_size > 1 ? `${i.packages} × ${formatQty(p.package_size, p.unit)}` : `${i.packages}`;
};

/** One list with its items (to buy by aisle, in someone's cart, bought) and who's on it. Members only. */
export function getSharedList(db: Db, me: Me, listId: string) {
  const l = joined(db, me, listId);
  const people = peopleOf(db, listId);
  const names = new Map(people.map((p) => [p.user_id, p.name]));
  const who = (id: string | null) => (id ? { id, name: names.get(id) ?? '…', me: id === me.id } : null);
  const items = db.all<SharedItemRow>('SELECT * FROM shared_list_items WHERE list_id = ? ORDER BY created_at', listId).map((i) => {
    const p = i.product_id ? getProduct(db, i.product_id) : null;
    return {
      id: i.id, name: i.name, name_nl: p?.name_nl ?? null, productId: i.product_id, category: i.category, packages: i.packages, note: i.note, label: labelFor(i, p),
      addedBy: who(i.added_by), claimedBy: who(i.claimed_by), checkedBy: who(i.checked_by), checkedAt: i.checked_at, boughtBy: who(i.bought_by), boughtAt: i.bought_at,
    };
  });
  const open = items.filter((i) => !i.checkedBy && !i.boughtAt);
  const groups = new Map<string, typeof open>();
  for (const i of open) groups.set(i.category, [...(groups.get(i.category) ?? []), i]);
  return {
    id: l.id, name: l.name, mine: l.owner_id === me.id, ownerId: l.owner_id,
    members: people.map((p) => ({ id: p.user_id, name: p.name, status: p.status, owner: p.user_id === l.owner_id, me: p.user_id === me.id })),
    groups: [...groups.entries()]
      .sort((a, b) => (CATEGORY_LABELS[a[0]]?.order ?? 99) - (CATEGORY_LABELS[b[0]]?.order ?? 99))
      .map(([category, items]) => ({ category, label: CATEGORY_LABELS[category] ?? { en: category, nl: category }, items })),
    inCart: items.filter((i) => i.checkedBy && !i.boughtAt),
    bought: items.filter((i) => i.boughtAt).sort((a, b) => b.boughtAt!.localeCompare(a.boughtAt!)),
    count: open.length,
  };
}

export interface SharedItemInput { name?: string; productId?: string | null; packages?: number | null; note?: string | null }

/** Add an item (named the way the adder's household knows it). Merges with the same item still to buy. */
export function addSharedItem(db: Db, me: Me, listId: string, input: SharedItemInput) {
  joined(db, me, listId);
  let product = input.productId ? getProduct(db, input.productId) : undefined;
  if (input.productId && (!product || (product.household_id && product.household_id !== me.household_id))) throw notFound('Product');
  if (!product && input.name) product = resolveProduct(db, me.household_id, input.name).product ?? undefined;
  const name = product?.name ?? input.name?.trim();
  if (!name) throw badRequest('name or productId is required');
  const now = clock.iso();
  const existing = product
    ? db.get<SharedItemRow>('SELECT * FROM shared_list_items WHERE list_id = ? AND product_id = ? AND checked_by IS NULL AND bought_at IS NULL', listId, product.id)
    : db.get<SharedItemRow>('SELECT * FROM shared_list_items WHERE list_id = ? AND product_id IS NULL AND lower(name) = lower(?) AND checked_by IS NULL AND bought_at IS NULL', listId, name);
  let id: string;
  if (existing) {
    id = existing.id;
    db.update('shared_list_items', id, { packages: (existing.packages ?? 1) + (input.packages ?? 1), note: input.note ?? undefined, updated_at: now });
  } else {
    id = newId('sli');
    db.insert('shared_list_items', {
      id, list_id: listId, product_id: product?.id ?? null, name, category: product?.category ?? 'other', packages: input.packages ?? 1, note: input.note ?? null,
      added_by: me.id, claimed_by: null, checked_by: null, checked_at: null, bought_by: null, bought_at: null, created_at: now, updated_at: now,
    });
  }
  bumped(db, listId);
  touchList(db, listId);
  return { id, merged: !!existing };
}

export interface SharedItemPatch { checked?: boolean; claimed?: boolean; packages?: number; note?: string | null; name?: string }

/**
 * Change an item. Ticking puts it in *your* cart (anyone can untick, in case of a mistake); claiming says
 * you'll get it (only you can drop your claim; claiming takes it over from someone else).
 */
export function updateSharedItem(db: Db, me: Me, listId: string, itemId: string, patch: SharedItemPatch) {
  joined(db, me, listId);
  const item = db.get<SharedItemRow>('SELECT * FROM shared_list_items WHERE id = ? AND list_id = ?', itemId, listId);
  if (!item) throw notFound('Item');
  if (item.bought_at) throw new AppError(409, 'already_bought', 'This was already bought');
  const now = clock.iso();
  if (patch.claimed === false && item.claimed_by && item.claimed_by !== me.id) throw new AppError(403, 'not_your_claim', 'Someone else is getting this');
  db.update('shared_list_items', itemId, {
    checked_by: patch.checked === undefined ? undefined : patch.checked ? me.id : null,
    checked_at: patch.checked === undefined ? undefined : patch.checked ? now : null,
    claimed_by: patch.claimed === undefined ? undefined : patch.claimed ? me.id : null,
    packages: patch.packages,
    note: patch.note,
    name: patch.name?.trim() || undefined,
    updated_at: now,
  });
  bumped(db, listId);
  touchList(db, listId);
  return getSharedList(db, me, listId);
}

export function removeSharedItem(db: Db, me: Me, listId: string, itemId: string) {
  joined(db, me, listId);
  db.run('DELETE FROM shared_list_items WHERE id = ? AND list_id = ?', itemId, listId);
  bumped(db, listId);
  touchList(db, listId);
}

/** The product as the buyer's household knows it: the same one if it's built in or theirs, else by name. */
function productForBuyer(db: Db, householdId: string, item: SharedItemRow): Product | null {
  const p = item.product_id ? getProduct(db, item.product_id) : null;
  if (p && (!p.household_id || p.household_id === householdId)) return p;
  return resolveProduct(db, householdId, item.name).product;
}

/**
 * Done shopping: the items *you* ticked go into your household's stock (source 'shopping_list') and are
 * marked bought by you, so the others see who bought what. What others ticked stays in their carts.
 */
export function finishSharedList(ctx: Ctx, me: Me, listId: string, store?: string | null) {
  const { db } = ctx;
  if (ctx.householdId !== me.household_id) throw new AppError(500, 'wrong_household', 'Stock goes to the buyer’s household');
  joined(db, me, listId);
  const items = db.all<SharedItemRow>('SELECT * FROM shared_list_items WHERE list_id = ? AND checked_by = ? AND bought_at IS NULL', listId, me.id);
  const added: { itemId: string; productId: string | null; lotId: string | null }[] = [];
  const now = clock.iso();
  for (const it of items) {
    const p = productForBuyer(db, me.household_id, it);
    let lotId: string | null = null;
    if (p) lotId = addStock(ctx, { productId: p.id, quantity: (it.packages ?? 1) * p.package_size, packages: it.packages ?? 1, store: store ?? p.preferred_store, meta: { sharedListItemId: it.id } }).lot.id;
    added.push({ itemId: it.id, productId: p?.id ?? null, lotId });
    db.update('shared_list_items', it.id, { bought_by: me.id, bought_at: now, claimed_by: null, updated_at: now });
  }
  bumped(db, listId);
  touchList(db, listId);
  bus.touch(me.household_id, 'inventory');
  return { added, batchId: ctx.batchId };
}

/** Clear the "bought" section (any member). */
export function clearBought(db: Db, me: Me, listId: string) {
  joined(db, me, listId);
  const n = Number(db.run('DELETE FROM shared_list_items WHERE list_id = ? AND bought_at IS NOT NULL', listId).changes);
  touchList(db, listId);
  return n;
}
