// Shopping list: manual items, meal-plan driven items and predictive suggestions.
import type { Db } from '../db/db.ts';
import { newId } from '../db/db.ts';
import { clock, daysBetween } from '../clock.ts';
import { notFound } from '../errors.ts';
import { getProduct, normalizeText, resolveProduct, type Product } from './products.ts';
import { addStock, type Ctx } from './ledger.ts';
import { inventorySummary, type StockItem } from './inventory.ts';
import { packagesFor, formatQty } from './units.ts';
import { CATEGORY_LABELS } from '../db/catalogue.ts';
import { planRequirements } from './planner.ts';
import { bus } from '../bus.ts';

export interface ShoppingItem {
  id: string;
  product_id: string | null;
  name: string;
  quantity: number | null;
  unit: string | null;
  packages: number | null;
  category: string;
  reason: string;
  plan_driven: number;
  note: string | null;
  checked: number;
  checked_at: string | null;
  created_at: string;
  updated_at: string;
  product?: Product | null;
  label?: string;
  need_qty?: number | null;
  have_qty?: number | null;
  pack_size?: number | null;
  /** For plan-driven items: what the recipes need, what's in stock, what to buy and what will be left. */
  plan?: { need: number; have: number; toBuy: number; packs: number; packSize: number; leftover: number; unit: string } | null;
}

/**
 * The pack size and count to buy for a shortage: least left over, then fewest packs. "4 eggs" with packs
 * of 6, 10 and 12 → one 6-pack (2 left over).
 */
export function choosePacks(need: number, p: Pick<Product, 'package_size' | 'package_options'>): { size: number; count: number; leftover: number } {
  const sizes = [...new Set((p.package_options?.length ? p.package_options : [p.package_size]).filter((x) => x > 0))];
  if (!sizes.length || need <= 0) return { size: p.package_size || 1, count: need > 0 ? 1 : 0, leftover: 0 };
  // Leftover counts most; each extra pack costs a little (5 % of the need), so 700 g is 3 × 250 g rather
  // than 2 × 500 g, and 1.2 L is one 1.5 L carton rather than three 500 ml ones.
  let best: { size: number; count: number; leftover: number; score: number } | null = null;
  for (const size of sizes) {
    const count = Math.max(1, Math.ceil(need / size - 1e-9));
    const leftover = Math.round((count * size - need) * 100) / 100;
    const score = leftover + count * need * 0.05;
    if (!best || score < best.score - 1e-9) best = { size, count, leftover, score };
  }
  return { size: best!.size, count: best!.count, leftover: best!.leftover };
}

function decorate(db: Db, i: ShoppingItem): ShoppingItem {
  const product = i.product_id ? getProduct(db, i.product_id) : null;
  let label = '';
  const size = i.pack_size ?? product?.package_size ?? 0;
  if (product && i.packages) {
    label = i.packages > 1 || product.unit !== 'pcs' || size > 1 ? `${i.packages} × ${formatQty(size, product.unit)}` : '';
    if (product.unit === 'pcs' && size === 1) label = `${i.packages}`;
  } else if (i.quantity && i.unit) label = formatQty(i.quantity, i.unit);
  const plan = product && i.plan_driven && i.need_qty != null && i.packages
    ? { need: i.need_qty, have: i.have_qty ?? 0, toBuy: i.quantity ?? 0, packs: i.packages, packSize: size, leftover: Math.max(0, Math.round((i.packages * size - Math.max(0, i.need_qty - (i.have_qty ?? 0))) * 100) / 100), unit: product.unit }
    : null;
  return { ...i, product, label, plan };
}

export function listShopping(db: Db, householdId: string) {
  const items = db
    .all<ShoppingItem>('SELECT * FROM shopping_items WHERE household_id = ? ORDER BY checked, created_at', householdId)
    .map((i) => decorate(db, i));
  const groups = new Map<string, ShoppingItem[]>();
  for (const i of items.filter((x) => !x.checked)) {
    const arr = groups.get(i.category) ?? [];
    arr.push(i);
    groups.set(i.category, arr);
  }
  return {
    groups: [...groups.entries()]
      .sort((a, b) => (CATEGORY_LABELS[a[0]]?.order ?? 99) - (CATEGORY_LABELS[b[0]]?.order ?? 99))
      .map(([category, items]) => ({ category, label: CATEGORY_LABELS[category] ?? { en: category, nl: category }, items })),
    checked: items.filter((x) => x.checked),
    count: items.filter((x) => !x.checked).length,
  };
}

export interface AddItemInput {
  name?: string;
  productId?: string | null;
  quantity?: number | null; // base units
  packages?: number | null;
  /** The pack size picked (6, 12 or 24 eggs); otherwise the product's usual size. */
  packSize?: number | null;
  note?: string | null;
  reason?: string;
}

/** Add to the list, merging with an existing unchecked entry for the same product or name. */
export function addShoppingItem(db: Db, householdId: string, input: AddItemInput, userId?: string | null): ShoppingItem {
  let product = input.productId ? getProduct(db, input.productId) : undefined;
  if (!product && input.name) product = resolveProduct(db, householdId, input.name).product ?? undefined;
  const name = product?.name ?? input.name?.trim() ?? 'Item';
  const now = clock.iso();
  const existing = product
    ? db.get<ShoppingItem>('SELECT * FROM shopping_items WHERE household_id = ? AND product_id = ? AND checked = 0', householdId, product.id)
    : db.get<ShoppingItem>('SELECT * FROM shopping_items WHERE household_id = ? AND product_id IS NULL AND lower(name) = lower(?) AND checked = 0', householdId, name);
  const packSize = product && input.packSize ? input.packSize : null;
  const packages = input.packages ?? (product && input.quantity ? (packSize ? Math.max(1, Math.round(input.quantity / packSize)) : packagesFor(input.quantity, product)) : product ? 1 : null);
  if (existing) {
    const newPackages = input.packages != null || input.quantity != null ? Math.max(existing.packages ?? 0, packages ?? 0) : existing.packages;
    db.update('shopping_items', existing.id, {
      packages: newPackages,
      pack_size: packSize ?? existing.pack_size,
      quantity: packSize ? (newPackages ?? 1) * packSize : Math.max(existing.quantity ?? 0, input.quantity ?? 0) || existing.quantity,
      note: input.note ?? existing.note,
      plan_driven: 0, // the user asked for it explicitly; stop auto-removing it
      updated_at: now,
    });
    bus.touch(householdId, 'shopping');
    return decorate(db, db.get<ShoppingItem>('SELECT * FROM shopping_items WHERE id = ?', existing.id)!);
  }
  const id = newId('si');
  db.insert('shopping_items', {
    id,
    household_id: householdId,
    product_id: product?.id ?? null,
    name,
    quantity: input.quantity ?? (product ? (packages ?? 1) * (packSize ?? product.package_size) : null),
    unit: product?.unit ?? null,
    packages,
    pack_size: packSize,
    category: product?.category ?? 'other',
    reason: input.reason ?? 'manual',
    plan_driven: 0,
    note: input.note ?? null,
    checked: 0,
    added_by: userId ?? null,
    created_at: now,
    updated_at: now,
  });
  if (product && input.reason && input.reason !== 'manual') recordFeedback(db, householdId, product.id, true);
  bus.touch(householdId, 'shopping');
  return decorate(db, db.get<ShoppingItem>('SELECT * FROM shopping_items WHERE id = ?', id)!);
}

export function updateShoppingItem(db: Db, householdId: string, id: string, patch: { checked?: boolean; packages?: number; note?: string | null; name?: string }) {
  const item = db.get<ShoppingItem>('SELECT * FROM shopping_items WHERE id = ? AND household_id = ?', id, householdId);
  if (!item) throw notFound('Shopping item');
  const now = clock.iso();
  const product = item.product_id ? getProduct(db, item.product_id) : null;
  db.update('shopping_items', id, {
    checked: patch.checked === undefined ? undefined : patch.checked ? 1 : 0,
    checked_at: patch.checked === undefined ? undefined : patch.checked ? now : null,
    packages: patch.packages,
    quantity: patch.packages != null && product ? patch.packages * product.package_size : undefined,
    note: patch.note,
    name: patch.name,
    plan_driven: patch.packages != null ? 0 : undefined,
    updated_at: now,
  });
  bus.touch(householdId, 'shopping');
  return decorate(db, db.get<ShoppingItem>('SELECT * FROM shopping_items WHERE id = ?', id)!);
}

export function removeShoppingItem(db: Db, householdId: string, id: string) {
  db.run('DELETE FROM shopping_items WHERE id = ? AND household_id = ?', id, householdId);
  bus.touch(householdId, 'shopping');
}

/**
 * Finish a shopping trip: ticked items become inventory (source 'shopping_list').
 * A receipt scanned later reconciles against these instead of double counting.
 */
export function completeTrip(ctx: Ctx, opts: { itemIds?: string[]; store?: string | null } = {}) {
  const items = ctx.db.all<ShoppingItem>(
    `SELECT * FROM shopping_items WHERE household_id = ? AND checked = 1 ${opts.itemIds ? `AND id IN (${opts.itemIds.map(() => '?').join(',')})` : ''}`,
    ctx.householdId,
    ...(opts.itemIds ?? []),
  );
  const added: { itemId: string; productId: string | null; lotId: string | null }[] = [];
  ctx.db.tx(() => {
    for (const it of items) {
      let lotId: string | null = null;
      if (it.product_id) {
        const p = getProduct(ctx.db, it.product_id)!;
        // The pack size that was chosen for this item (6 eggs, not the catalogue's default 10).
        const qty = (it.packages ?? 1) * (it.pack_size ?? p.package_size);
        const { lot } = addStock(ctx, { productId: p.id, quantity: qty, packages: it.packages ?? 1, store: opts.store ?? p.preferred_store, meta: { shoppingItemId: it.id } });
        lotId = lot.id;
      }
      added.push({ itemId: it.id, productId: it.product_id, lotId });
      ctx.db.run('DELETE FROM shopping_items WHERE id = ?', it.id);
    }
  });
  bus.touch(ctx.householdId, 'shopping');
  return { added, batchId: ctx.batchId };
}

// ---------- Meal plan → list ----------

/** Recalculate plan-driven items: requirement minus what we have, rounded up to packages. */
export function syncPlanToShopping(db: Db, householdId: string, opts: { days?: number; quiet?: boolean } = {}) {
  const days = opts.days ?? 7;
  let changed = false;
  const req = planRequirements(db, householdId, clock.today(), days);
  const stock = new Map(inventorySummary(db, householdId).items.map((s) => [s.product.id, s]));
  const now = clock.iso();
  const touched = new Set<string>();
  // What's already in the cart covers the need too, or ticking an item off would bring it straight back.
  const inCart = new Map<string, number>();
  for (const c of db.all<ShoppingItem>('SELECT * FROM shopping_items WHERE household_id = ? AND checked = 1 AND product_id IS NOT NULL', householdId)) {
    const size = c.pack_size ?? getProduct(db, c.product_id!)?.package_size ?? 0;
    inCart.set(c.product_id!, (inCart.get(c.product_id!) ?? 0) + (c.packages ? c.packages * size : c.quantity ?? 0));
  }
  db.tx(() => {
    for (const r of req) {
      const p = getProduct(db, r.productId);
      if (!p || p.staple) continue;
      const s = stock.get(p.id);
      const available = (s ? (s.showEstimate ? s.estimated : s.confirmed) : 0) + (inCart.get(p.id) ?? 0);
      // Estimates drift every second; round so the list only changes when it matters.
      const step = p.unit === 'pcs' ? 0.5 : 10;
      const shortage = Math.round((r.quantity - available) / step) * step;
      const existing = db.get<ShoppingItem>('SELECT * FROM shopping_items WHERE household_id = ? AND product_id = ? AND checked = 0', householdId, p.id);
      if (shortage <= 1e-6) continue;
      touched.add(p.id);
      // The pack that wastes least, from the sizes this product is sold in.
      const pack = choosePacks(shortage, p);
      const packages = pack.count;
      const need = Math.round(r.quantity * 100) / 100;
      const have = Math.round(Math.max(0, available) * 100) / 100;
      const note = `For ${r.recipes.slice(0, 2).join(', ')}${r.recipes.length > 2 ? '…' : ''}${r.replaces?.length ? ` · replaces ${r.replaces.slice(0, 2).join(', ')}` : ''}`;
      if (existing) {
        if (existing.plan_driven && (existing.packages !== packages || existing.pack_size !== pack.size || Math.abs((existing.quantity ?? 0) - shortage) >= Math.max(step, p.package_size * 0.05))) {
          db.update('shopping_items', existing.id, { quantity: shortage, packages, pack_size: pack.size, need_qty: need, have_qty: have, note, updated_at: now });
          changed = true;
        } else if (!existing.plan_driven && (existing.packages ?? 0) < packages) {
          db.update('shopping_items', existing.id, { packages, quantity: shortage, pack_size: pack.size, need_qty: need, have_qty: have, note: existing.note ?? note, updated_at: now });
          changed = true;
        }
      } else {
        db.insert('shopping_items', {
          id: newId('si'), household_id: householdId, product_id: p.id, name: p.name, quantity: shortage, unit: p.unit, packages, pack_size: pack.size, need_qty: need, have_qty: have,
          category: p.category, reason: 'meal_plan', plan_driven: 1, note, checked: 0, created_at: now, updated_at: now,
        });
        changed = true;
      }
    }
    // Plan-driven items that are no longer needed (meal moved/removed, stock arrived) disappear.
    const stale = db.all<ShoppingItem>('SELECT * FROM shopping_items WHERE household_id = ? AND plan_driven = 1 AND checked = 0', householdId).filter((i) => !touched.has(i.product_id ?? ''));
    for (const i of stale) db.run('DELETE FROM shopping_items WHERE id = ?', i.id);
    if (stale.length) changed = true;
  });
  // Only notify other devices when something actually changed (reads call this too).
  if (changed || !opts.quiet) bus.touch(householdId, 'shopping');
}

// ---------- Predictive suggestions ----------

export interface Suggestion {
  productId: string;
  name: string;
  packages: number;
  reason: 'running_low' | 'out' | 'overdue' | 'meal_plan' | 'bought_together' | 'seasonal';
  detail: string;
  confidence: number;
}

function feedback(db: Db, householdId: string, productId: string) {
  return db.get<{ accepted: number; rejected: number; last_rejected_at: string | null }>('SELECT * FROM suggestion_feedback WHERE household_id = ? AND product_id = ?', householdId, productId);
}

export function recordFeedback(db: Db, householdId: string, productId: string, accepted: boolean) {
  db.run('INSERT OR IGNORE INTO suggestion_feedback (household_id, product_id) VALUES (?, ?)', householdId, productId);
  if (accepted) db.run('UPDATE suggestion_feedback SET accepted = accepted + 1 WHERE household_id = ? AND product_id = ?', householdId, productId);
  else db.run('UPDATE suggestion_feedback SET rejected = rejected + 1, last_rejected_at = ? WHERE household_id = ? AND product_id = ?', clock.iso(), householdId, productId);
  bus.touch(householdId, 'shopping');
}

/** Suppress products the user keeps rejecting; the suppression fades after a while. */
function suppressed(db: Db, householdId: string, productId: string): boolean {
  const f = feedback(db, householdId, productId);
  if (!f || !f.last_rejected_at) return false;
  const age = daysBetween(f.last_rejected_at, clock.now());
  const net = f.rejected - f.accepted;
  if (age < 3) return true; // just dismissed: don't nag the same week
  if (net >= 2 && age < 45) return true;
  if (net >= 4) return true;
  return false;
}

export function shoppingSuggestions(db: Db, householdId: string): Suggestion[] {
  const onList = new Set(db.all<{ product_id: string }>('SELECT product_id FROM shopping_items WHERE household_id = ? AND checked = 0 AND product_id IS NOT NULL', householdId).map((r) => r.product_id));
  const { items } = inventorySummary(db, householdId);
  const stock = new Map<string, StockItem>(items.map((s) => [s.product.id, s]));
  const out = new Map<string, Suggestion>();
  const push = (s: Suggestion) => {
    if (onList.has(s.productId) || suppressed(db, householdId, s.productId)) return;
    const prev = out.get(s.productId);
    if (!prev || prev.confidence < s.confidence) out.set(s.productId, s);
  };

  // 1. Products bought repeatedly: low, out, or overdue for a repurchase.
  const regulars = db.all<{ product_id: string; n: number; avg_qty: number }>(
    'SELECT product_id, COUNT(DISTINCT substr(purchased_at,1,10)) n, AVG(quantity) avg_qty FROM purchases WHERE household_id = ? GROUP BY product_id HAVING n >= 2',
    householdId,
  );
  for (const r of regulars) {
    const p = getProduct(db, r.product_id);
    if (!p || p.staple) continue;
    const s = stock.get(p.id);
    const packages = Math.max(1, Math.round(r.avg_qty / p.package_size));
    if (!s || s.status === 'out') {
      // Out of stock: only suggest if it's a regular, and say what we know.
      const pred = s?.prediction;
      push({ productId: p.id, name: p.name, packages, reason: 'out', detail: s ? 'Probably run out' : `You buy this regularly (${r.n}×)`, confidence: 0.75 });
      void pred;
      continue;
    }
    if (s.low && s.daysLeft != null && s.daysLeft <= 4 && s.confidence >= 0.35) {
      push({ productId: p.id, name: p.name, packages, reason: 'running_low', detail: s.daysLeft < 1 ? 'Likely runs out today' : `About ${Math.round(s.daysLeft)} day${Math.round(s.daysLeft) === 1 ? '' : 's'} left`, confidence: s.confidence });
    } else if (s.low) {
      push({ productId: p.id, name: p.name, packages, reason: 'running_low', detail: 'Running low', confidence: Math.max(0.4, s.confidence) });
    }
  }
  for (const s of items) {
    if (s.prediction.overdue && !s.product.staple && s.status !== 'ok') {
      push({ productId: s.product.id, name: s.product.name, packages: 1, reason: 'overdue', detail: `Usually bought every ${Math.round(s.prediction.avgIntervalDays ?? 0)} days`, confidence: s.prediction.confidence });
    }
  }
  // Regulars with zero stock that are overdue.
  for (const r of regulars) {
    if (stock.has(r.product_id)) continue;
    const p = getProduct(db, r.product_id);
    if (p && !p.staple && !out.has(p.id)) push({ productId: p.id, name: p.name, packages: 1, reason: 'out', detail: 'Not in stock', confidence: 0.6 });
  }

  // 2. Frequently bought together with what's already on the list.
  if (onList.size) {
    const trips = db.all<{ day: string; product_id: string }>('SELECT DISTINCT substr(purchased_at,1,10) day, product_id FROM purchases WHERE household_id = ?', householdId);
    const byDay = new Map<string, Set<string>>();
    for (const t of trips) {
      const s = byDay.get(t.day) ?? new Set();
      s.add(t.product_id);
      byDay.set(t.day, s);
    }
    const pairCount = new Map<string, { n: number; with: string }>();
    for (const set of byDay.values()) {
      for (const a of onList) {
        if (!set.has(a)) continue;
        for (const b of set) {
          if (b === a || onList.has(b)) continue;
          const c = pairCount.get(b) ?? { n: 0, with: a };
          c.n++;
          pairCount.set(b, c);
        }
      }
    }
    for (const [pid, c] of pairCount) {
      if (c.n < 3) continue;
      const s = stock.get(pid);
      if (s && s.status === 'ok') continue;
      const p = getProduct(db, pid);
      const w = getProduct(db, c.with);
      if (p && !p.staple) push({ productId: pid, name: p.name, packages: 1, reason: 'bought_together', detail: `Often bought with ${w?.name.toLowerCase() ?? 'items on your list'}`, confidence: Math.min(0.7, 0.3 + c.n * 0.08) });
    }
  }

  // 3. Seasonal: bought in this month in previous years, not yet this year.
  const month = clock.today().slice(5, 7);
  const year = clock.today().slice(0, 4);
  const seasonal = db.all<{ product_id: string; n: number }>(
    `SELECT product_id, COUNT(*) n FROM purchases WHERE household_id = ? AND substr(purchased_at,6,2) = ? AND substr(purchased_at,1,4) < ?
     AND product_id NOT IN (SELECT product_id FROM purchases WHERE household_id = ? AND substr(purchased_at,1,7) = ?) GROUP BY product_id HAVING n >= 2`,
    householdId, month, year, householdId, clock.today().slice(0, 7),
  );
  for (const r of seasonal) {
    const p = getProduct(db, r.product_id);
    if (p && !stock.has(p.id)) push({ productId: p.id, name: p.name, packages: 1, reason: 'seasonal', detail: 'You usually buy this around this time of year', confidence: 0.4 });
  }

  return [...out.values()].sort((a, b) => b.confidence - a.confidence).slice(0, 12);
}

export function findShoppingItemByName(db: Db, householdId: string, name: string): ShoppingItem | undefined {
  const n = normalizeText(name);
  const items = db.all<ShoppingItem>('SELECT * FROM shopping_items WHERE household_id = ? AND checked = 0', householdId);
  const { product } = resolveProduct(db, householdId, name);
  return items.find((i) => (product && i.product_id === product.id) || normalizeText(i.name) === n);
}
