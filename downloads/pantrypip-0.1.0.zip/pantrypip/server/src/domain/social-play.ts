// Playing together with friends: cook-along streaks, duels, cheers and nudges, passed recipes, challenges and
// team goals, leagues, seasonal events, Pip visits, the weekly recap and the shared rescued-food counter.
// Rewards are settled lazily (when someone involved looks) and stored once in social_rewards, which game()
// counts like journey XP. Everything here only ever uses progress numbers.
import type { Db } from '../db/db.ts';
import { parseJson, newId } from '../db/db.ts';
import { clock, addDays } from '../clock.ts';
import { AppError, notFound, badRequest } from '../errors.ts';
import { streakOf, weekOf, CHALLENGES } from './game.ts';
import { getRecipe, createRecipe, recordInteraction } from './recipes.ts';
import { progressNow, type FriendState, type SharedProgress } from './social.ts';
import { EVENTS, currentEvent, nextEvent, eventWindow } from './events.ts';

type Me = { id: string; name: string; household_id: string };
type Txt = [string, string];

export const REWARD_XP = { duel: 40, goal: 50, pass: 20, invite: 30 };

/** Give a reward once (the key makes it idempotent). True when it's new. */
function reward(db: Db, h: string, key: string, kind: string, xp: number, title: Txt, emoji: string, unlock: string | null = null): boolean {
  const before = db.get<{ n: number }>('SELECT COUNT(*) n FROM social_rewards WHERE household_id = ? AND key = ?', h, key)!.n;
  if (before) return false;
  db.run('INSERT INTO social_rewards (household_id, key, kind, xp, title, title_nl, emoji, unlock, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', h, key, kind, xp, title[0], title[1], emoji, unlock, clock.iso());
  return true;
}

const userRow = (db: Db, id: string) => db.get<{ id: string; name: string; household_id: string }>('SELECT id, name, household_id FROM users WHERE id = ?', id);
/** The other person, if you're friends. */
function friend(db: Db, me: Me, otherId: string) {
  const ok = db.get("SELECT 1 FROM friendships WHERE status = 'accepted' AND ((requester_id = ? AND addressee_id = ?) OR (requester_id = ? AND addressee_id = ?))", me.id, otherId, otherId, me.id);
  const u = ok && userRow(db, otherId);
  if (!u) throw notFound('Friend');
  return u;
}
const level = (db: Db, from: string, to: string) => db.get<{ level: string }>('SELECT level FROM friend_privacy WHERE user_id = ? AND friend_id = ?', from, to)?.level ?? 'all';
const userPref = <T>(db: Db, u: { id: string; household_id: string }, key: string, d: T): T => parseJson(db.get<{ value: string }>('SELECT value FROM preferences WHERE household_id = ? AND user_id = ? AND key = ?', u.household_id, u.id, key)?.value, d);

// ---------- Leagues ----------

export const LEAGUES: { emoji: string; title: Txt; up: number; down: number }[] = [
  { emoji: '🥉', title: ['Bronze Kitchen', 'Bronzen Keuken'], up: 150, down: -1 },
  { emoji: '🥈', title: ['Silver Kitchen', 'Zilveren Keuken'], up: 250, down: 60 },
  { emoji: '🥇', title: ['Gold Kitchen', 'Gouden Keuken'], up: 350, down: 120 },
  { emoji: '💠', title: ['Platinum Kitchen', 'Platina Keuken'], up: 450, down: 180 },
  { emoji: '💎', title: ['Diamond Kitchen', 'Diamanten Keuken'], up: Infinity, down: 250 },
];

/** The household's league this week. Moves once a week on last week's XP (up at `up`, down below `down`). */
export function leagueFor(db: Db, h: string, weeklyXp: Record<string, number>) {
  const thisWeek = weekOf(clock.today());
  const row = db.get<{ week: string; league: number; moved: number }>('SELECT week, league, moved FROM leagues WHERE household_id = ?', h);
  if (!row) {
    db.run('INSERT INTO leagues (household_id, week, league, moved) VALUES (?, ?, 0, 0)', h, thisWeek);
    return { league: 0, moved: 0 };
  }
  if (row.week >= thisWeek) return { league: row.league, moved: row.moved };
  let { league } = row;
  let moved = 0;
  for (let w = row.week; w < thisWeek; w = addDays(w, 7)) {
    const xp = weeklyXp[w] ?? 0;
    const L = LEAGUES[league];
    moved = xp >= L.up ? 1 : xp < L.down ? -1 : 0;
    league = Math.max(0, Math.min(LEAGUES.length - 1, league + moved));
  }
  db.run('UPDATE leagues SET week = ?, league = ?, moved = ? WHERE household_id = ?', thisWeek, league, moved, h);
  return { league, moved };
}

// ---------- Cheers and nudges ----------

export function sendCheer(db: Db, me: Me, toId: string, kind: 'cheer' | 'nudge', ref: string | null) {
  const to = friend(db, me, toId);
  const today = clock.today();
  if (kind === 'nudge') {
    if (!userPref(db, to, 'friendNudges', true)) throw new AppError(403, 'nudges_off', `${to.name} has turned nudges off`);
    if (progressNow(db, to.household_id).streak.cookedToday) throw new AppError(400, 'cooked_today', `${to.name} already cooked today`);
  }
  const dup = db.get("SELECT 1 FROM cheers WHERE from_user = ? AND to_user = ? AND kind = ? AND day = ? AND COALESCE(ref, '') = ?", me.id, to.id, kind, today, ref ?? '');
  if (dup) throw new AppError(409, kind === 'nudge' ? 'nudged_today' : 'cheered', kind === 'nudge' ? 'One nudge a day is enough' : 'Already cheered');
  db.insert('cheers', { id: newId('ch'), from_user: me.id, to_user: to.id, kind, ref, day: today, seen: 0, created_at: clock.iso() });
  return to;
}
export const setNudges = (db: Db, me: Me, on: boolean) =>
  db.run("INSERT INTO preferences (household_id, user_id, key, value) VALUES (?, ?, 'friendNudges', ?) ON CONFLICT(household_id, user_id, key) DO UPDATE SET value = excluded.value", me.household_id, me.id, JSON.stringify(on));
export const markSeen = (db: Db, me: Me) => db.run('UPDATE cheers SET seen = 1 WHERE to_user = ? AND seen = 0', me.id);

// ---------- Duels ----------

export function createDuel(db: Db, me: Me, opponentId: string) {
  const other = friend(db, me, opponentId);
  if (level(db, other.id, me.id) !== 'all' || level(db, me.id, other.id) !== 'all') throw new AppError(400, 'limited', 'Duels need you both to share more than your streak');
  const week = weekOf(clock.today());
  const open = db.get("SELECT 1 FROM duels WHERE week = ? AND status IN ('pending', 'active') AND ((challenger = ? AND opponent = ?) OR (challenger = ? AND opponent = ?))", week, me.id, other.id, other.id, me.id);
  if (open) throw new AppError(409, 'duel_exists', 'You already have a duel this week');
  db.run("DELETE FROM duels WHERE challenger = ? AND opponent = ? AND week = ? AND status = 'declined'", me.id, other.id, week);
  const id = newId('du');
  db.insert('duels', { id, challenger: me.id, opponent: other.id, week, status: 'pending', winner: null, scores: null, created_at: clock.iso() });
  return { id, other };
}
export function answerDuel(db: Db, me: Me, id: string, accept: boolean) {
  const d = db.get<{ challenger: string; week: string }>("SELECT challenger, week FROM duels WHERE id = ? AND opponent = ? AND status = 'pending'", id, me.id);
  if (!d || d.week !== weekOf(clock.today())) throw notFound('Duel');
  db.run('UPDATE duels SET status = ? WHERE id = ?', accept ? 'active' : 'declined', id);
  return userRow(db, d.challenger)!;
}

// ---------- Passing recipes ----------

export function passRecipe(db: Db, me: Me, toId: string, recipeId: string, note: string | null) {
  const to = friend(db, me, toId);
  const r = getRecipe(db, me.household_id, recipeId);
  const cooked = db.get<{ n: number }>('SELECT COUNT(*) n FROM cook_log WHERE household_id = ? AND recipe_id = ?', me.household_id, r.id)!.n;
  const id = newId('rp');
  db.insert('recipe_passes', { id, from_user: me.id, to_user: to.id, recipe_id: r.id, title: r.title, emoji: r.emoji, cooked_times: cooked, note, status: 'sent', added_recipe_id: null, created_at: clock.iso() });
  return to;
}

/** Add a passed recipe to your to-try list (a copy, when it was the sender's own), or dismiss it. */
export function answerPass(db: Db, me: Me, id: string, add: boolean) {
  const p = db.get<{ from_user: string; recipe_id: string }>("SELECT from_user, recipe_id FROM recipe_passes WHERE id = ? AND to_user = ? AND status = 'sent'", id, me.id);
  if (!p) throw notFound('Recipe');
  if (!add) {
    db.run("UPDATE recipe_passes SET status = 'dismissed' WHERE id = ?", id);
    return null;
  }
  const sender = userRow(db, p.from_user);
  if (!sender) throw notFound('Recipe');
  const r = getRecipe(db, sender.household_id, p.recipe_id);
  let mine = r.id;
  if (r.household_id) {
    // The sender's own recipe: you get your own copy (without their notes or ratings).
    mine = createRecipe(db, me.household_id, {
      title: r.title, summary: r.summary, cuisine: r.cuisine, tags: r.tags, difficulty: r.difficulty, servings: r.servings, prep_minutes: r.prep_minutes, cook_minutes: r.cook_minutes,
      steps: r.steps as any, image_url: r.image_url, emoji: r.emoji, color: r.color, origin: 'user', source_name: r.source_name ?? sender.name, source_url: r.source_url, attribution: r.attribution,
      ingredients: r.ingredients.map((i) => ({ product_id: i.product_id, name: i.name, quantity: i.quantity, unit: i.unit, display: i.display, optional: i.optional })),
    }).id;
  }
  recordInteraction(db, me.household_id, mine, { saved: true, toTry: true });
  db.run("UPDATE recipe_passes SET status = 'added', added_recipe_id = ? WHERE id = ?", mine, id);
  return mine;
}

// ---------- Challenges and team goals together ----------

export const GOAL_METRICS = ['meals'] as const;

export function createGroup(db: Db, me: Me, input: { kind: 'challenge' | 'goal'; ref: string; target?: number | null; friends: string[] }) {
  const today = clock.today();
  let ends: string;
  if (input.kind === 'challenge') {
    if (!CHALLENGES.some((c) => c.id === input.ref)) throw badRequest('Unknown challenge');
    ends = addDays(today, 6);
  } else {
    if (!GOAL_METRICS.includes(input.ref as any) || !input.target) throw badRequest('A goal needs a target');
    // To the end of this month.
    const [y, m] = today.split('-').map(Number);
    ends = new Date(Date.UTC(y, m, 0)).toISOString().slice(0, 10);
  }
  const people = [...new Set(input.friends)].map((f) => friend(db, me, f));
  const id = newId('sg');
  db.insert('social_groups', { id, kind: input.kind, ref: input.ref, target: input.target ?? null, starts: today, ends, created_by: me.id, created_at: clock.iso() });
  db.insert('social_group_members', { group_id: id, user_id: me.id, status: 'joined', joined_at: clock.iso() });
  for (const p of people) db.insert('social_group_members', { group_id: id, user_id: p.id, status: 'invited', joined_at: null });
  if (input.kind === 'challenge') startChallenge(db, me.household_id, input.ref, today);
  return { id, people };
}
const startChallenge = (db: Db, h: string, id: string, start: string) =>
  db.run("INSERT INTO preferences (household_id, user_id, key, value) VALUES (?, '', 'challenge', ?) ON CONFLICT(household_id, user_id, key) DO UPDATE SET value = excluded.value", h, JSON.stringify({ id, start }));

export function answerGroup(db: Db, me: Me, id: string, join: boolean) {
  const g = db.get<{ kind: string; ref: string; starts: string; ends: string; created_by: string }>(
    "SELECT g.* FROM social_groups g JOIN social_group_members m ON m.group_id = g.id WHERE g.id = ? AND m.user_id = ? AND m.status IN ('invited', 'joined')", id, me.id,
  );
  if (!g) throw notFound('Group');
  db.run('UPDATE social_group_members SET status = ?, joined_at = ? WHERE group_id = ? AND user_id = ?', join ? 'joined' : 'left', join ? clock.iso() : null, id, me.id);
  // Joining a challenge starts it for your household too, on the same days.
  if (join && g.kind === 'challenge' && clock.today() <= g.ends) startChallenge(db, me.household_id, g.ref, g.starts);
  return userRow(db, g.created_by);
}

// ---------- Settling rewards ----------

/** Check everything that may have earned a reward for you or your friends, and record it once. */
export function settleSocial(db: Db, me: Me) {
  const today = clock.today();
  const thisWeek = weekOf(today);
  const touched = new Set<string>();

  // Duels that ended: most XP that week wins.
  for (const d of db.all<{ id: string; challenger: string; opponent: string; week: string; status: string }>(
    "SELECT * FROM duels WHERE status IN ('pending', 'active') AND week < ? AND (challenger = ? OR opponent = ?)", thisWeek, me.id, me.id,
  )) {
    if (d.status === 'pending') {
      db.run("UPDATE duels SET status = 'declined' WHERE id = ?", d.id);
      continue;
    }
    const a = userRow(db, d.challenger);
    const b = userRow(db, d.opponent);
    if (!a || !b) continue;
    const sa = progressNow(db, a.household_id).weeklyXp[d.week] ?? 0;
    const sb = progressNow(db, b.household_id).weeklyXp[d.week] ?? 0;
    const winner = sa === sb ? null : sa > sb ? a : b;
    const loser = winner === a ? b : a;
    db.run("UPDATE duels SET status = 'done', winner = ?, scores = ? WHERE id = ?", winner?.id ?? 'tie', JSON.stringify({ [a.id]: sa, [b.id]: sb }), d.id);
    if (winner && reward(db, winner.household_id, `duel:${d.id}`, 'duel', REWARD_XP.duel, [`Won a duel against ${loser.name}`, `Duel gewonnen van ${loser.name}`], '⚔️')) touched.add(winner.household_id);
  }

  // Passed recipes you cooked after adding them.
  for (const p of db.all<{ id: string; from_user: string; added_recipe_id: string; title: string; created_at: string }>(
    "SELECT * FROM recipe_passes WHERE to_user = ? AND status = 'added'", me.id,
  )) {
    const cooked = db.get('SELECT 1 FROM cook_log WHERE household_id = ? AND recipe_id = ? AND created_at >= ?', me.household_id, p.added_recipe_id, p.created_at);
    const from = userRow(db, p.from_user)?.name ?? '';
    if (cooked && reward(db, me.household_id, `pass:${p.id}`, 'pass', REWARD_XP.pass, [`Cooked ${p.title} from ${from}`, `${p.title} van ${from} gekookt`], '📨')) touched.add(me.household_id);
  }

  // Invites: someone new joined with your code and cooked their first meal; you both get a heart for Pip.
  for (const f of db.all<{ id: string; requester_id: string; addressee_id: string; created_at: string; accepted_at: string }>(
    "SELECT * FROM friendships WHERE status = 'accepted' AND via = 'code' AND (requester_id = ? OR addressee_id = ?)", me.id, me.id,
  )) {
    const newcomer = db.get<{ household_id: string; created_at: string; name: string }>('SELECT household_id, created_at, name FROM users WHERE id = ?', f.requester_id);
    const host = userRow(db, f.addressee_id);
    if (!newcomer || !host || newcomer.created_at < addDays(f.created_at.slice(0, 10), -14)) continue;
    if (!db.get('SELECT 1 FROM cook_log WHERE household_id = ? AND created_at >= ?', newcomer.household_id, f.accepted_at)) continue;
    if (reward(db, host.household_id, `invite:${f.id}`, 'invite', REWARD_XP.invite, [`${newcomer.name} joined and cooked`, `${newcomer.name} deed mee en kookte`], '💌', 'stage:heart')) touched.add(host.household_id);
    if (reward(db, newcomer.household_id, `invite:${f.id}`, 'invite', REWARD_XP.invite, [`Joined ${host.name} on PantryPip`, `Bij ${host.name} op PantryPip`], '💌', 'stage:heart')) touched.add(newcomer.household_id);
  }

  // Team goals reached: everyone who joined gets the chest.
  for (const g of db.all<{ id: string; target: number; starts: string; ends: string }>(
    "SELECT g.* FROM social_groups g JOIN social_group_members m ON m.group_id = g.id WHERE g.kind = 'goal' AND m.user_id = ? AND m.status = 'joined'", me.id,
  )) {
    const members = groupMembers(db, g.id).filter((m) => m.status === 'joined');
    if (goalProgress(db, members, g) < g.target) continue;
    for (const h of new Set(members.map((m) => m.household_id))) {
      if (reward(db, h, `goal:${g.id}`, 'goal', REWARD_XP.goal, [`Team goal: ${g.target} meals together`, `Teamdoel: samen ${g.target} maaltijden`], '🎁')) touched.add(h);
    }
  }

  // This season's event.
  const ev = currentEvent(today);
  if (ev) {
    const mine = progressNow(db, me.household_id);
    if ((mine.event?.count ?? 0) >= ev.goal && reward(db, me.household_id, `event:${ev.id}:${today.slice(0, 4)}`, 'event', ev.xp, ev.title, ev.emoji, `skin:${ev.skin}`)) touched.add(me.household_id);
  }
  return touched;
}

const groupMembers = (db: Db, id: string) =>
  db.all<{ user_id: string; status: string; name: string; household_id: string }>('SELECT m.user_id, m.status, u.name, u.household_id FROM social_group_members m JOIN users u ON u.id = m.user_id WHERE m.group_id = ?', id);
/** Meals cooked by the members' households (each household once) between the goal's dates. */
function goalProgress(db: Db, members: { household_id: string }[], g: { starts: string; ends: string }) {
  const hs = [...new Set(members.map((m) => m.household_id))];
  if (!hs.length) return 0;
  return db.get<{ n: number }>(`SELECT COUNT(*) n FROM cook_log WHERE household_id IN (${hs.map(() => '?').join(',')}) AND substr(created_at, 1, 10) BETWEEN ? AND ?`, ...hs, g.starts, g.ends)!.n;
}

// ---------- What the Friends screen shows ----------

export function playState(db: Db, me: Me, state: { friends: FriendState[]; mine: SharedProgress }) {
  const today = clock.today();
  const thisWeek = weekOf(today);
  const visible = state.friends.filter((f) => f.progress && f.sees === 'all');

  // Leagues for everyone on the board.
  const leagues = new Map<string, { league: number; moved: number }>();
  leagues.set(me.household_id, leagueFor(db, me.household_id, state.mine.weeklyXp));
  for (const f of visible) if (!leagues.has(f.householdId)) leagues.set(f.householdId, leagueFor(db, f.householdId, f.progress!.weeklyXp));

  // Cook-along: days in a row you both cooked (streak-only friends count too: it's a streak).
  const myDays = new Set(state.mine.days);
  const together = Object.fromEntries(state.friends.filter((f) => f.progress).map((f) => [f.id, streakOf(new Set(f.progress!.days.filter((d) => myDays.has(d))), today).count]));

  const nameOf = new Map([[me.id, me.name], ...state.friends.map((f) => [f.id, f.name] as [string, string])]);
  const duels = db.all<{ id: string; challenger: string; opponent: string; week: string; status: string; winner: string | null; scores: string | null }>(
    "SELECT * FROM duels WHERE (challenger = ? OR opponent = ?) AND (week = ? OR (status = 'done' AND week >= ?)) ORDER BY created_at DESC", me.id, me.id, thisWeek, addDays(thisWeek, -7),
  ).filter((d) => d.status !== 'declined').map((d) => {
    const otherId = d.challenger === me.id ? d.opponent : d.challenger;
    const other = state.friends.find((f) => f.id === otherId);
    const scores = parseJson<Record<string, number>>(d.scores, {});
    return {
      id: d.id, week: d.week, status: d.status, mine: d.challenger === me.id, other: { id: otherId, name: nameOf.get(otherId) ?? '?' },
      me: d.status === 'done' ? scores[me.id] ?? 0 : state.mine.weekXp,
      them: d.status === 'done' ? scores[otherId] ?? 0 : other?.progress?.weekXp ?? 0,
      won: d.status === 'done' ? (d.winner === 'tie' ? null : d.winner === me.id) : null,
    };
  });

  const groups = db.all<{ id: string; kind: 'challenge' | 'goal'; ref: string; target: number | null; starts: string; ends: string; created_by: string; status: string }>(
    "SELECT g.*, m.status FROM social_groups g JOIN social_group_members m ON m.group_id = g.id WHERE m.user_id = ? AND m.status IN ('invited', 'joined') AND g.ends >= ? ORDER BY g.created_at DESC", me.id, addDays(today, -3),
  ).map((g) => {
    const members = groupMembers(db, g.id).filter((m) => m.status !== 'left');
    const def = CHALLENGES.find((c) => c.id === g.ref);
    const progressOf = (m: { user_id: string; household_id: string; status: string }) => {
      if (m.status !== 'joined' || g.kind !== 'challenge') return null;
      const p = m.user_id === me.id ? state.mine : state.friends.find((f) => f.id === m.user_id)?.progress;
      return p?.challenge && p.challenge.id === g.ref && p.challenge.start === g.starts ? p.challenge.progress : 0;
    };
    return {
      id: g.id, kind: g.kind, ref: g.ref, target: g.target ?? def?.goal ?? null, starts: g.starts, ends: g.ends, status: g.status, by: nameOf.get(g.created_by) ?? '',
      title: g.kind === 'challenge' ? [def?.title ?? g.ref, def?.title_nl ?? g.ref] : [`${g.target} meals together`, `Samen ${g.target} maaltijden`],
      emoji: g.kind === 'challenge' ? def?.emoji ?? '🎯' : '🎁',
      total: g.kind === 'goal' ? goalProgress(db, members.filter((m) => m.status === 'joined'), g) : null,
      done: g.kind === 'goal' ? !!db.get('SELECT 1 FROM social_rewards WHERE key = ? LIMIT 1', `goal:${g.id}`) : null,
      members: members.map((m) => ({ id: m.user_id, name: m.user_id === me.id ? me.name : m.name, me: m.user_id === me.id, joined: m.status === 'joined', progress: progressOf(m) })),
    };
  });

  const inbox = {
    cheers: db.all<{ id: string; from_user: string; kind: string; ref: string | null; created_at: string; seen: number }>(
      'SELECT * FROM cheers WHERE to_user = ? AND created_at >= ? ORDER BY created_at DESC LIMIT 20', me.id, addDays(today, -7),
    ).map((c) => ({ id: c.id, from: nameOf.get(c.from_user) ?? '', kind: c.kind, ref: c.ref, at: c.created_at, seen: !!c.seen })),
    passes: db.all<{ id: string; from_user: string; title: string; emoji: string | null; cooked_times: number; note: string | null; created_at: string }>(
      "SELECT * FROM recipe_passes WHERE to_user = ? AND status = 'sent' ORDER BY created_at DESC", me.id,
    ).map((p) => ({ id: p.id, from: nameOf.get(p.from_user) ?? '', title: p.title, emoji: p.emoji, cookedTimes: p.cooked_times, note: p.note, at: p.created_at })),
  };
  // Cheers and nudges I sent today (so the buttons can say "sent").
  const sentToday = db.all<{ to_user: string; kind: string; ref: string | null }>('SELECT to_user, kind, ref FROM cheers WHERE from_user = ? AND day = ?', me.id, today).map((c) => `${c.kind}:${c.to_user}:${c.ref ?? ''}`);

  // Seasonal event board.
  const ev = currentEvent(today);
  const event = ev
    ? {
        id: ev.id, emoji: ev.emoji, title: ev.title, desc: ev.desc, goal: ev.goal, xp: ev.xp, skin: ev.skin, ...eventWindow(ev, today),
        done: !!db.get('SELECT 1 FROM social_rewards WHERE household_id = ? AND key = ?', me.household_id, `event:${ev.id}:${today.slice(0, 4)}`),
        board: [{ id: me.id, name: me.name, me: true, count: state.mine.event?.count ?? 0 }, ...visible.map((f) => ({ id: f.id, name: f.name, me: false, count: f.progress!.event?.count ?? 0 }))].sort((a, b) => b.count - a.count),
      }
    : null;
  const next = nextEvent(today);

  // Pip visits: friends who finished a chapter in the last two days.
  const since = new Date(clock.now().getTime() - 48 * 3600_000).toISOString();
  const visits = visible.filter((f) => f.progress!.chapterDoneAt && f.progress!.chapterDoneAt >= since).map((f) => ({ id: f.id, name: f.name, skin: f.progress!.skin, stages: f.progress!.stages, chapter: f.progress!.chapter.done }));

  // The week together, and the food you kept out of the bin.
  const crew = [state.mine, ...visible.map((f) => f.progress!)];
  const recap = { week: thisWeek, names: [me.name, ...visible.map((f) => f.name)], meals: crew.reduce((s, p) => s + p.weekCooks, 0), rescued: crew.reduce((s, p) => s + p.rescued.week, 0), friends: visible.length };
  const rescued = { kg: Math.round(crew.reduce((s, p) => s + p.rescued.kg, 0) * 10) / 10, foods: crew.reduce((s, p) => s + p.rescued.foods, 0), mine: state.mine.rescued };

  const myLeague = leagues.get(me.household_id)!;
  return {
    leagueOf: (h: string) => leagues.get(h)?.league ?? null,
    view: {
      together, duels, groups, inbox, sentToday, event, nextEvent: { id: next.id, emoji: next.emoji, title: next.title, from: next.from }, visits, recap, rescued,
      league: { ...myLeague, ...LEAGUES[myLeague.league], up: Number.isFinite(LEAGUES[myLeague.league].up) ? LEAGUES[myLeague.league].up : null, all: LEAGUES.map((l) => ({ emoji: l.emoji, title: l.title })) },
      nudges: userPref(db, me, 'friendNudges', true),
      rewards: db.all<{ key: string; kind: string; xp: number; title: string; title_nl: string; emoji: string; at: string }>('SELECT key, kind, xp, title, title_nl, emoji, at FROM social_rewards WHERE household_id = ? ORDER BY at DESC LIMIT 10', me.household_id),
      events: EVENTS.map((e) => ({ id: e.id, emoji: e.emoji, title: e.title, from: e.from, to: e.to, skin: e.skin })),
    },
  };
}
