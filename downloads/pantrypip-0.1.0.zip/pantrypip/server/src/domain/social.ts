// Friends and the leaderboard. Friendships are between people, found by a friend code or (if they opt
// in) their phone number, never by email, and only share progress numbers: level, XP, streaks, chapters
// and what was earned. Never inventory, lists, recipes, meals or notes. Nothing is visible until both
// sides accepted. There's no limit on friends: progress is kept as a snapshot per household and only
// rebuilt when something that counts changed.
import { randomInt, randomBytes, createHmac } from 'node:crypto';
import type { Db } from '../db/db.ts';
import { parseJson, newId } from '../db/db.ts';
import { clock, addDays } from '../clock.ts';
import { bus } from '../bus.ts';
import { AppError, notFound, badRequest } from '../errors.ts';
import { game, weekOf } from './game.ts';
import { CHAPTERS, describeNode } from './journey.ts';
import { currentEvent, eventCount } from './events.ts';

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no 0/O or 1/I
const CODE_LEN = 8;

const makeCode = () => Array.from({ length: CODE_LEN }, () => ALPHABET[randomInt(ALPHABET.length)]).join('');
/** "abcd-efgh", "ABCDEFGH" and a pasted link all give the same code. */
export const normalizeCode = (s: string) => {
  const m = s.match(/friend=([A-Za-z0-9-]+)/);
  return (m ? m[1] : s).toUpperCase().replace(/[^A-Z0-9]/g, '');
};

/** Your friend code, made the first time it's asked for. */
export function friendCode(db: Db, userId: string): string {
  const row = db.get<{ code: string }>('SELECT code FROM friend_codes WHERE user_id = ?', userId);
  if (row) return row.code;
  return resetFriendCode(db, userId);
}

/** A new code; the old one (and links with it) stops working. Accepted friends stay. */
export function resetFriendCode(db: Db, userId: string): string {
  for (let i = 0; i < 10; i++) {
    const code = makeCode();
    if (db.get('SELECT 1 FROM friend_codes WHERE code = ?', code)) continue;
    db.run('INSERT INTO friend_codes (user_id, code, created_at) VALUES (?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET code = excluded.code, created_at = excluded.created_at', userId, code, clock.iso());
    return code;
  }
  throw new AppError(500, 'code_failed', 'Could not make a friend code');
}

interface Row { id: string; requester_id: string; addressee_id: string; status: 'pending' | 'accepted'; created_at: string; accepted_at: string | null }
type Me = { id: string; name: string; household_id: string };
const between = (db: Db, a: string, b: string) => db.get<Row>('SELECT * FROM friendships WHERE (requester_id = ? AND addressee_id = ?) OR (requester_id = ? AND addressee_id = ?)', a, b, b, a);
const userRow = (db: Db, id: string) => db.get<{ id: string; name: string; household_id: string }>('SELECT id, name, household_id FROM users WHERE id = ?', id);

export interface RequestResult { state: 'pending' | 'friends'; name: string; other: { id: string; householdId: string }; changed: boolean; accepted: boolean }

/** Ask someone to be friends. If they already asked you, this accepts theirs. */
function requestTo(db: Db, me: Me, otherId: string, via: 'code' | 'contact'): RequestResult {
  if (otherId === me.id) throw new AppError(400, 'own_code', 'That’s you');
  const other = userRow(db, otherId);
  if (!other) throw notFound('Person');
  if (other.household_id === me.household_id) throw new AppError(400, 'same_household', 'You already share a household');
  const base = { name: other.name, other: { id: other.id, householdId: other.household_id } };
  const existing = between(db, me.id, other.id);
  if (existing?.status === 'accepted') return { state: 'friends', ...base, changed: false, accepted: false };
  if (existing && existing.requester_id === me.id) return { state: 'pending', ...base, changed: false, accepted: false };
  if (existing) {
    // They asked you first: adding them is the same as accepting.
    acceptRequest(db, me.id, existing.id);
    return { state: 'friends', ...base, changed: true, accepted: true };
  }
  db.insert('friendships', { id: newId('fr'), requester_id: me.id, addressee_id: other.id, status: 'pending', created_at: clock.iso(), accepted_at: null, via });
  return { state: 'pending', ...base, changed: true, accepted: false };
}

/** Send a request to whoever owns this code (or link). */
export function requestFriend(db: Db, me: Me, rawCode: string): RequestResult {
  const target = db.get<{ user_id: string }>('SELECT user_id FROM friend_codes WHERE code = ?', normalizeCode(rawCode));
  if (!target) throw new AppError(404, 'invalid_code', 'No one has this friend code');
  if (target.user_id === me.id) throw new AppError(400, 'own_code', 'That’s your own code');
  return requestTo(db, me, target.user_id, 'code');
}

/** Send a request to someone found in your contacts (they must still be findable by that number). */
export function requestByContact(db: Db, me: Me, userId: string, match: string): RequestResult {
  if (!db.get('SELECT 1 FROM user_phones WHERE user_id = ? AND phone_hash = ? AND discoverable = 1', userId, match)) throw notFound('Person');
  return requestTo(db, me, userId, 'contact');
}

/** Accept a request sent to you. Returns the requester (to tell their screens). */
export function acceptRequest(db: Db, userId: string, requestId: string) {
  const row = db.get<Row>("SELECT * FROM friendships WHERE id = ? AND addressee_id = ? AND status = 'pending'", requestId, userId);
  if (!row) throw notFound('Friend request');
  db.run("UPDATE friendships SET status = 'accepted', accepted_at = ? WHERE id = ?", clock.iso(), row.id);
  const u = userRow(db, row.requester_id)!;
  return { id: u.id, householdId: u.household_id, name: u.name };
}

/** Decline a request to you, or withdraw one you sent. */
export function dropRequest(db: Db, userId: string, requestId: string): string {
  const row = db.get<Row>("SELECT * FROM friendships WHERE id = ? AND status = 'pending' AND (addressee_id = ? OR requester_id = ?)", requestId, userId, userId);
  if (!row) throw notFound('Friend request');
  db.run('DELETE FROM friendships WHERE id = ?', row.id);
  return userRow(db, row.requester_id === userId ? row.addressee_id : row.requester_id)!.household_id;
}

/** Stop being friends (either side can). */
export function removeFriend(db: Db, userId: string, friendId: string): string {
  const row = between(db, userId, friendId);
  if (!row || row.status !== 'accepted') throw notFound('Friend');
  db.run('DELETE FROM friendships WHERE id = ?', row.id);
  return userRow(db, friendId)!.household_id;
}

/** Requests waiting for you (for the badge on the tab bar). */
export const incomingCount = (db: Db, userId: string) => db.get<{ n: number }>("SELECT COUNT(*) n FROM friendships WHERE addressee_id = ? AND status = 'pending'", userId)!.n;

// ---------- Phone numbers (opt-in, hashed) ----------

/** Calling codes for the countries PantryPip knows; a local number (06…) gets the household's. */
const CALLING: Record<string, string> = { NL: '31', BE: '32', DE: '49', FR: '33', GB: '44', IE: '353', ES: '34', PT: '351', IT: '39', AT: '43', CH: '41', LU: '352', DK: '45', SE: '46', NO: '47', FI: '358', PL: '48', CZ: '420', US: '1', CA: '1', AU: '61', NZ: '64' };
const countryOf = (db: Db, h: string) => parseJson<string>(db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = '' AND key = 'country'", h)?.value, 'NL');

/** "+31 6 1234 5678", "0031612345678" and (in NL) "06-12345678" all become "+31612345678". Null if it can't be a number. */
export function normalizePhone(raw: string, country = 'NL'): string | null {
  let s = raw.trim().replace(/[\s().\-/]/g, '');
  if (s.startsWith('00')) s = '+' + s.slice(2);
  if (!s.startsWith('+')) {
    const cc = CALLING[country] ?? '31';
    // US/CA numbers have no trunk 0; most others drop their leading 0.
    s = cc === '1' ? `+1${s.replace(/^1/, '')}` : `+${cc}${s.replace(/^0/, '')}`;
  }
  s = '+' + s.slice(1).replace(/\D/g, '');
  return /^\+[1-9]\d{7,14}$/.test(s) ? s : null;
}

function pepper(db: Db): string {
  let v = db.get<{ value: string }>("SELECT value FROM app_settings WHERE key = 'phone_pepper'")?.value;
  if (!v) {
    v = randomBytes(32).toString('base64');
    db.run("INSERT OR IGNORE INTO app_settings (key, value) VALUES ('phone_pepper', ?)", v);
    v = db.get<{ value: string }>("SELECT value FROM app_settings WHERE key = 'phone_pepper'")!.value;
  }
  return v;
}
const hashPhone = (db: Db, e164: string) => createHmac('sha256', pepper(db)).update(e164).digest('base64url');
const hintOf = (e164: string) => `${e164.slice(0, e164.length > 11 ? 3 : 2)} •••• ${e164.slice(-2)}`;

export function myPhone(db: Db, userId: string) {
  const r = db.get<{ hint: string; discoverable: number }>('SELECT hint, discoverable FROM user_phones WHERE user_id = ?', userId);
  return r ? { hint: r.hint, discoverable: !!r.discoverable } : null;
}

export function setMyPhone(db: Db, me: Me, raw: string, discoverable: boolean) {
  const e164 = normalizePhone(raw, countryOf(db, me.household_id));
  if (!e164) throw badRequest('That doesn’t look like a phone number');
  db.run(
    'INSERT INTO user_phones (user_id, phone_hash, hint, discoverable, created_at) VALUES (?, ?, ?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET phone_hash = excluded.phone_hash, hint = excluded.hint, discoverable = excluded.discoverable',
    me.id, hashPhone(db, e164), hintOf(e164), discoverable ? 1 : 0, clock.iso(),
  );
  return myPhone(db, me.id)!;
}
export const setDiscoverable = (db: Db, userId: string, on: boolean) => db.run('UPDATE user_phones SET discoverable = ? WHERE user_id = ?', on ? 1 : 0, userId);
export const removeMyPhone = (db: Db, userId: string) => db.run('DELETE FROM user_phones WHERE user_id = ?', userId);

// Looking people up by number is limited per person per day, so the list can't be used to probe numbers.
export const CONTACTS_PER_DAY = 3000;
const lookups = new Map<string, { day: string; n: number }>();

/**
 * Which of these numbers belong to people who can be found by number. Returns, per matched input index,
 * who it is (name only) and where you stand with them. Numbers are only hashed, never stored.
 */
export function matchContacts(db: Db, me: Me, numbers: string[]) {
  const today = clock.today();
  const used = lookups.get(me.id);
  const n = used?.day === today ? used.n : 0;
  if (n + numbers.length > CONTACTS_PER_DAY) throw new AppError(429, 'rate_limited', 'You’ve checked a lot of numbers today. Try again tomorrow.');
  lookups.set(me.id, { day: today, n: n + numbers.length });
  const country = countryOf(db, me.household_id);
  const byHash = new Map<string, number[]>();
  numbers.forEach((raw, i) => {
    const e164 = normalizePhone(raw, country);
    if (!e164) return;
    const h = hashPhone(db, e164);
    byHash.set(h, [...(byHash.get(h) ?? []), i]);
  });
  if (!byHash.size) return [];
  const hashes = [...byHash.keys()];
  const people: { user_id: string; phone_hash: string; name: string; household_id: string }[] = [];
  for (let i = 0; i < hashes.length; i += 500) {
    const chunk = hashes.slice(i, i + 500);
    people.push(...db.all<any>(`SELECT p.user_id, p.phone_hash, u.name, u.household_id FROM user_phones p JOIN users u ON u.id = p.user_id WHERE p.discoverable = 1 AND p.phone_hash IN (${chunk.map(() => '?').join(',')})`, ...chunk));
  }
  const rel = new Map(db.all<Row>('SELECT * FROM friendships WHERE requester_id = ? OR addressee_id = ?', me.id, me.id).map((r) => [r.requester_id === me.id ? r.addressee_id : r.requester_id, r]));
  return people
    .filter((p) => p.user_id !== me.id && p.household_id !== me.household_id)
    .flatMap((p) => {
      const r = rel.get(p.user_id);
      const state = !r ? 'none' : r.status === 'accepted' ? 'friends' : r.requester_id === me.id ? 'pending' : 'incoming';
      return byHash.get(p.phone_hash)!.map((index) => ({ index, userId: p.user_id, match: p.phone_hash, name: p.name, state }));
    });
}

// ---------- Shared progress (snapshots) ----------

/** The numbers a friend may see. Built from the household's game data, nothing else. */
export function sharedProgress(db: Db, householdId: string) {
  const g = game(db, householdId);
  const rows = db.all<{ chapter: number; completed_at: string | null }>('SELECT chapter, completed_at FROM journey_chapters WHERE household_id = ? ORDER BY chapter', householdId);
  const open = rows.find((r) => !r.completed_at) ?? rows[rows.length - 1];
  const ch = open ? CHAPTERS[open.chapter] : CHAPTERS[0];
  const companion = parseJson<{ skin: string }>(db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = '' AND key = 'companion'", householdId)?.value, { skin: 'sprout' });
  // Recent progress: journey steps, chapters, skill levels and challenges (with dates), newest first.
  const recent: { id: string; emoji: string; title: string; title_nl: string; kind: string; at: string }[] = db
    .all<{ node_id: string; kind: string; completed_at: string }>("SELECT node_id, kind, completed_at FROM journey_nodes WHERE household_id = ? AND kind != 'task' ORDER BY completed_at DESC LIMIT 6", householdId)
    .map((n) => ({ id: n.node_id, ...describeNode(n.node_id), kind: n.kind, at: n.completed_at }));
  for (const c of g.challenge.completed) {
    const def = g.challenge.all.find((x) => x.id === c.id);
    if (def) recent.push({ id: `challenge:${c.id}:${c.at}`, emoji: def.emoji, title: def.title, title_nl: def.title_nl, kind: 'challenge', at: c.at });
  }
  recent.sort((a, b) => b.at.localeCompare(a.at));
  const today = clock.today();
  const week = weekOf(today);
  const count = (sql: string, ...args: unknown[]) => db.get<{ n: number }>(sql, householdId, ...args)!.n;
  // Food used just before it expired (cooking from a lot that had 2 days or less), in kg where it's weighed.
  const rescued = db.get<{ g: number; n: number; week: number }>(
    `SELECT COALESCE(SUM(CASE WHEN e.unit IN ('g', 'ml') THEN -e.delta ELSE 0 END), 0) g, COUNT(*) n, COALESCE(SUM(e.created_at >= ?2), 0) week
     FROM inventory_events e JOIN inventory_lots l ON l.id = e.lot_id
     WHERE e.household_id = ?1 AND e.type = 'cook' AND l.expires_on IS NOT NULL AND julianday(l.expires_on) - julianday(substr(e.created_at, 1, 10)) <= 2
       AND NOT EXISTS (SELECT 1 FROM inventory_events u WHERE u.reverses_event_id = e.id)`,
    householdId, week,
  )!;
  const ev = currentEvent(today);
  return {
    xp: g.xp,
    weekXp: g.weekXp,
    level: { n: g.level.n, name: g.level.name, name_nl: g.level.name_nl, emoji: g.level.emoji, progress: g.level.progress },
    streak: { current: g.streaks.cooking.current, best: g.streaks.cooking.best, cookedToday: g.streaks.cooking.cookedToday },
    chapter: { n: open ? open.chapter + 1 : 1, emoji: ch.emoji, title: ch.title[0], title_nl: ch.title[1], done: rows.filter((r) => r.completed_at).length, total: CHAPTERS.length },
    badges: { done: g.achievements.filter((a) => a.done).length, all: g.achievements.length, latest: g.achievements.filter((a) => a.done).slice(-3).map((a) => ({ id: a.id, emoji: a.emoji, title: a.title, title_nl: a.title_nl })) },
    recent: recent.slice(0, 5),
    skin: companion.skin,
    stages: db.all<{ unlock: string }>("SELECT unlock FROM social_rewards WHERE household_id = ? AND unlock LIKE 'stage:%'", householdId).map((r) => r.unlock.slice(6)),
    weekCooks: count('SELECT COUNT(*) n FROM cook_log WHERE household_id = ? AND created_at >= ?', week),
    monthCooks: count('SELECT COUNT(*) n FROM cook_log WHERE household_id = ? AND substr(created_at, 1, 7) = ?', today.slice(0, 7)),
    rescued: { kg: Math.round(rescued.g / 100) / 10, foods: rescued.n, week: rescued.week },
    challenge: g.challenge.current ? { id: g.challenge.current.id, start: g.challenge.current.start, progress: g.challenge.current.progress, goal: g.challenge.current.goal, done: g.challenge.current.done } : null,
    event: ev ? { id: ev.id, count: eventCount(db, householdId, ev, today) } : null,
    chapterDoneAt: db.get<{ at: string | null }>('SELECT MAX(completed_at) at FROM journey_chapters WHERE household_id = ?', householdId)!.at,
    // Only used on the server (cook-along streaks, duels, leagues); never sent to friends.
    days: db.all<{ d: string }>('SELECT DISTINCT substr(created_at, 1, 10) d FROM cook_log WHERE household_id = ? AND created_at >= ?', householdId, addDays(today, -120)).map((r) => r.d),
    weeklyXp: g.weeklyXp,
  };
}

/** What a friend is sent: no server-only fields, and only the streak if you chose "streak only" for them. */
export function publicProgress(p: SharedProgress, level: 'all' | 'streak') {
  const { days, weeklyXp, ...rest } = p;
  if (level === 'streak') return { limited: true as const, streak: p.streak, skin: p.skin, stages: p.stages };
  return { limited: false as const, ...rest };
}
export type SharedProgress = ReturnType<typeof sharedProgress>;

/** Everything that changes XP, in a few cheap aggregates: a snapshot is reused while this stays the same. */
export function progressFingerprint(db: Db, h: string): string {
  const r = db.get<Record<string, unknown>>(
    `SELECT
      (SELECT COUNT(*) || '/' || COALESCE(MAX(created_at), '') FROM cook_log WHERE household_id = ?1) cooks,
      (SELECT COUNT(*) || '/' || COALESCE(MAX(created_at), '') FROM inventory_events WHERE household_id = ?1) events,
      (SELECT COUNT(*) || '/' || COALESCE(MAX(completed_at), '') FROM journey_nodes WHERE household_id = ?1) nodes,
      (SELECT COUNT(*) || '/' || COUNT(completed_at) FROM journey_chapters WHERE household_id = ?1) chapters,
      (SELECT COUNT(*) || '/' || COALESCE(SUM(rating), 0) || '/' || COALESCE(SUM(priority), 0) FROM recipe_interactions WHERE household_id = ?1) ratings,
      (SELECT COUNT(*) || '/' || COALESCE(MAX(date), '') FROM meal_slots WHERE household_id = ?1 AND status != 'planned') slots,
      (SELECT COUNT(*) FROM meal_slots WHERE household_id = ?1) slotCount,
      (SELECT COUNT(*) || '/' || COALESCE(SUM(xp), 0) FROM social_rewards WHERE household_id = ?1) social,
      (SELECT COALESCE(group_concat(key || '=' || value, ';'), '') FROM preferences WHERE household_id = ?1 AND user_id = '' AND key IN ('challenge', 'challengesDone', 'xpRules', 'companion', 'nutritionTargets')) prefs`,
    h,
  )!;
  return Object.values(r).join('|');
}

/** A snapshot if it still holds (same day, same fingerprint); `stale` is the last one when it doesn't. */
function readSnapshot(db: Db, h: string) {
  const row = db.get<{ data: string; fingerprint: string; day: string }>('SELECT data, fingerprint, day FROM progress_snapshots WHERE household_id = ?', h);
  if (!row) return { fresh: null, stale: null };
  const data = parseJson<SharedProgress | null>(row.data, null);
  const ok = data && row.day === clock.today() && row.fingerprint === progressFingerprint(db, h);
  return ok ? { fresh: data, stale: null } : { fresh: null, stale: data };
}

/** Work out a household's shared progress now and keep it. */
export function refreshSnapshot(db: Db, h: string): SharedProgress {
  const data = sharedProgress(db, h);
  // The fingerprint is taken after game(), which may itself record a finished challenge.
  db.run(
    'INSERT INTO progress_snapshots (household_id, data, fingerprint, day, computed_at) VALUES (?, ?, ?, ?, ?) ON CONFLICT(household_id) DO UPDATE SET data = excluded.data, fingerprint = excluded.fingerprint, day = excluded.day, computed_at = excluded.computed_at',
    h, JSON.stringify(data), progressFingerprint(db, h), clock.today(), clock.iso(),
  );
  return data;
}

// Snapshots that didn't fit in one request are rebuilt in the background, one household per tick,
// and then the waiting screens are told to refetch.
const queue = new Set<string>();
const waiting = new Set<string>();
let running = false;
function refreshLater(db: Db, households: string[], notify: string) {
  households.forEach((h) => queue.add(h));
  waiting.add(notify);
  if (running) return;
  running = true;
  const step = () => {
    const h = queue.values().next().value;
    if (h === undefined) {
      running = false;
      waiting.forEach((w) => bus.touch(w, 'friends'));
      waiting.clear();
      return;
    }
    queue.delete(h);
    try {
      if (!readSnapshot(db, h).fresh) refreshSnapshot(db, h);
    } catch {
      /* the database may be closed (tests, shutdown): stop quietly */
      queue.clear();
    }
    setImmediate(step);
  };
  setImmediate(step);
}

/** Time spent rebuilding snapshots inside one request; the rest is done in the background. */
export const REQUEST_BUDGET_MS = 300;

/** A household's progress now: the kept snapshot, or rebuilt (for duels, goals and other checks). */
export const progressNow = (db: Db, h: string): SharedProgress => readSnapshot(db, h).fresh ?? refreshSnapshot(db, h);

/** What `friend` lets `viewer` see. */
export const privacyFor = (db: Db, friend: string, viewer: string): 'all' | 'streak' =>
  (db.get<{ level: 'all' | 'streak' }>('SELECT level FROM friend_privacy WHERE user_id = ? AND friend_id = ?', friend, viewer)?.level ?? 'all');
export function setPrivacy(db: Db, userId: string, friendId: string, level: 'all' | 'streak') {
  if (!between(db, userId, friendId)) throw notFound('Friend');
  db.run('INSERT INTO friend_privacy (user_id, friend_id, level) VALUES (?, ?, ?) ON CONFLICT(user_id, friend_id) DO UPDATE SET level = excluded.level', userId, friendId, level);
}

export interface FriendState { id: string; name: string; since: string | null; householdId: string; sees: 'all' | 'streak'; shows: 'all' | 'streak'; progress: SharedProgress | null; updating: boolean }

/** Your friends with their progress (from snapshots; rebuilt within a time budget, the rest in the background). */
export function friendsState(db: Db, me: Me) {
  const rows = db.all<Row & { other_id: string; other_name: string; other_household: string }>(
    `SELECT f.*, u.id other_id, u.name other_name, u.household_id other_household FROM friendships f
     JOIN users u ON u.id = CASE WHEN f.requester_id = ? THEN f.addressee_id ELSE f.requester_id END
     WHERE f.requester_id = ? OR f.addressee_id = ? ORDER BY f.created_at`,
    me.id, me.id, me.id,
  );
  const accepted = rows.filter((r) => r.status === 'accepted');
  // Your own first, then friends; each household once.
  const households = [...new Set([me.household_id, ...accepted.map((r) => r.other_household)])];
  const progress = new Map<string, { data: SharedProgress | null; stale: boolean }>();
  const later: string[] = [];
  const started = Date.now();
  for (const h of households) {
    const snap = readSnapshot(db, h);
    if (snap.fresh) progress.set(h, { data: snap.fresh, stale: false });
    else if (h === me.household_id || Date.now() - started < REQUEST_BUDGET_MS) progress.set(h, { data: refreshSnapshot(db, h), stale: false });
    else {
      progress.set(h, { data: snap.stale, stale: true });
      later.push(h);
    }
  }
  if (later.length) refreshLater(db, later, me.household_id);
  const levels = new Map(db.all<{ user_id: string; friend_id: string; level: 'all' | 'streak' }>('SELECT * FROM friend_privacy WHERE user_id = ? OR friend_id = ?', me.id, me.id).map((r) => [`${r.user_id}>${r.friend_id}`, r.level]));
  const friends: FriendState[] = accepted.map((r) => ({
    id: r.other_id, name: r.other_name, since: r.accepted_at, householdId: r.other_household,
    sees: levels.get(`${r.other_id}>${me.id}`) ?? 'all', // what they let you see
    shows: levels.get(`${me.id}>${r.other_id}`) ?? 'all', // what you let them see
    progress: progress.get(r.other_household)!.data, updating: progress.get(r.other_household)!.stale,
  }));
  return { rows, friends, mine: progress.get(me.household_id)!.data!, updating: later.length };
}

/** Everything the Friends screen needs: your code, requests both ways, friends with their progress, and the leaderboard. */
export function friendsOverview(db: Db, me: Me, state = friendsState(db, me), leagueOf: (householdId: string) => number | null = () => null) {
  const { rows, friends, mine } = state;
  // Friends who show "streak only" aren't on the XP boards.
  const people = [
    { id: me.id, name: me.name, me: true, householdId: me.household_id, progress: mine },
    ...friends.filter((f) => f.progress && f.sees === 'all').map((f) => ({ id: f.id, name: f.name, me: false, householdId: f.householdId, progress: f.progress! })),
  ];
  // Ties share a rank (1, 2, 2, 4).
  const board = (score: (p: SharedProgress) => number, who = people) => {
    const sorted = who
      .map((p) => ({ id: p.id, name: p.name, me: p.me, score: score(p.progress), level: p.progress.level, streak: p.progress.streak.current, skin: p.progress.skin, league: leagueOf(p.householdId), rank: 0 }))
      .sort((a, b) => b.score - a.score || b.streak - a.streak || a.name.localeCompare(b.name));
    sorted.forEach((p, i) => (p.rank = i > 0 && sorted[i - 1].score === p.score ? sorted[i - 1].rank : i + 1));
    return sorted;
  };
  const myLeague = leagueOf(me.household_id);
  return {
    code: friendCode(db, me.id),
    weekStart: weekOf(clock.today()),
    incoming: rows.filter((r) => r.status === 'pending' && r.addressee_id === me.id).map((r) => ({ id: r.id, name: r.other_name, at: r.created_at })),
    outgoing: rows.filter((r) => r.status === 'pending' && r.requester_id === me.id).map((r) => ({ id: r.id, name: r.other_name, at: r.created_at })),
    friends: friends.map((f) => ({ id: f.id, name: f.name, since: f.since, shows: f.shows, progress: f.progress ? publicProgress(f.progress, f.sees) : null, updating: f.updating })),
    updating: state.updating,
    me: publicProgress(mine, 'all'),
    phone: myPhone(db, me.id),
    leaderboard: {
      week: board((p) => p.weekXp),
      all: board((p) => p.xp),
      league: myLeague == null ? [] : board((p) => p.weekXp, people.filter((p) => leagueOf(p.householdId) === myLeague)),
    },
  };
}
