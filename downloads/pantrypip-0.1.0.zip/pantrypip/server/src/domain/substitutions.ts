// Substitutions and how each recipe line resolves for a household.
//
// A recipe line stores how it was matched (recipe_ingredients.match) and, unless it was an exact product,
// where it came from (source_key): 'f:milk' (only the family was named), 'x:habanero' (an ingredient that
// isn't a catalogue product) or 'u:<name>' (unresolved). When recipes are calculated for a household, each
// such line is resolved again: the household's choice first (substitution_prefs: keep the original, or a
// product), then the country's default substitution. Nothing is replaced without the line saying so.
import type { Db } from '../db/db.ts';
import { parseJson } from '../db/db.ts';
import { clock } from '../clock.ts';
import { bus } from '../bus.ts';
import { AppError } from '../errors.ts';
import { gramsOf } from './health.ts';
import { familyById } from './ingredient-match.ts';
import type { Product } from './products.ts';

export type MatchKind = 'exact' | 'equivalent' | 'substitute' | 'approximate' | 'unresolved';
export type Availability = 'common' | 'limited' | 'specialist' | 'unavailable';

export interface SubRow {
  id: string; from_key: string; to_product: string; extra: { product: string; perUnit: number }[];
  kind: 'equivalent' | 'substitute' | 'approximate'; ratio: number; countries: string[]; note: [string, string]; prep: [string, string] | null; identity: boolean;
}

export interface SubContext {
  country: string;
  prefs: Map<string, string>;
  subs: Map<string, SubRow[]>;
  foreign: Map<string, { names: string[]; status: Availability }>;
  availability: Map<string, Availability>;
}

export function householdCountry(db: Db, householdId: string): string {
  const v = db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = '' AND key = 'country'", householdId)?.value;
  const c = parseJson<string>(v, 'NL');
  return typeof c === 'string' && /^[A-Z]{2}$/.test(c) ? c : 'NL';
}

export function subContext(db: Db, householdId: string, country = householdCountry(db, householdId)): SubContext {
  const subs = new Map<string, SubRow[]>();
  for (const r of db.all<any>('SELECT * FROM substitutions ORDER BY sort')) {
    const row: SubRow = { ...r, extra: parseJson(r.extra, []), countries: parseJson(r.countries, []), note: parseJson(r.note, ['', '']), prep: parseJson(r.prep, null), identity: !!r.identity };
    if (row.countries.length && !row.countries.includes(country)) continue;
    (subs.get(row.from_key) ?? subs.set(row.from_key, []).get(row.from_key)!).push(row);
  }
  return {
    country,
    prefs: new Map(db.all<{ from_key: string; choice: string }>('SELECT from_key, choice FROM substitution_prefs WHERE household_id = ?', householdId).map((r) => [r.from_key, r.choice])),
    subs,
    foreign: new Map(db.all<{ key: string; names: string; status: Availability }>('SELECT key, names, status FROM foreign_ingredients WHERE country = ?', country).map((r) => [r.key, { names: parseJson(r.names, []), status: r.status }])),
    availability: new Map(db.all<{ product_id: string; status: Availability }>('SELECT product_id, status FROM ingredient_availability WHERE country = ?', country).map((r) => [r.product_id, r.status])),
  };
}

/** The default substitution for a source in a country, or undefined. */
export function defaultSub(ctx: SubContext, key: string): SubRow | undefined {
  return ctx.subs.get(key)?.[0];
}

/** Convert an amount of one product into the equivalent amount of another (by weight when units differ). */
export function convertQty(qty: number, from: Pick<Product, 'unit' | 'piece_size' | 'density'>, to: Pick<Product, 'unit' | 'piece_size' | 'density'>): number | null {
  if (from.unit === to.unit) return qty;
  const grams = gramsOf(from, qty);
  if (to.unit === 'g') return grams;
  if (to.unit === 'ml') return grams / (to.density ?? 1);
  if (to.unit === 'pcs' && to.piece_size) return grams / to.piece_size;
  return null;
}

/** Remember a household's choice for an ingredient ('keep', a product id, or null to go back to the default). */
export function setChoice(db: Db, householdId: string, key: string, choice: string | null) {
  if (!/^(p_|x:|u:|f:)/.test(key)) throw new AppError(422, 'bad_key', 'Unknown ingredient key.');
  if (choice && choice !== 'keep' && !db.get('SELECT 1 FROM products WHERE id = ? AND (household_id IS NULL OR household_id = ?)', choice, householdId)) throw new AppError(422, 'bad_choice', 'Unknown product.');
  if (key.startsWith('f:') && choice === 'keep') throw new AppError(422, 'bad_choice', 'Pick a type.');
  if (choice == null) db.run('DELETE FROM substitution_prefs WHERE household_id = ? AND from_key = ?', householdId, key);
  else db.run('INSERT INTO substitution_prefs (household_id, from_key, choice, updated_at) VALUES (?, ?, ?, ?) ON CONFLICT (household_id, from_key) DO UPDATE SET choice = excluded.choice, updated_at = excluded.updated_at', householdId, key, choice, clock.iso());
  bus.touch(householdId, 'recipes');
}

/** The household's preferred variant of a family ("milk" → semi-skimmed), if set. */
export function familyPref(db: Db, householdId: string, familyId: string): string | null {
  return db.get<{ choice: string }>('SELECT choice FROM substitution_prefs WHERE household_id = ? AND from_key = ?', householdId, `f:${familyId}`)?.choice ?? null;
}

/** What a substitution shows on a recipe line. */
export interface SubInfo {
  fromKey: string;
  /** The ingredient as the recipe wrote it. */
  original: string;
  kind: MatchKind;
  note: [string, string] | null;
  prep: [string, string] | null;
  identity: boolean;
  /** 'default' (the suggestion), 'keep' (the original, not tracked), 'user' (your own pick) */
  choice: 'default' | 'keep' | 'user';
  /** How easy the original is to get in your country. */
  status: Availability | null;
  options: { id: string; kind: MatchKind; note: [string, string] | null }[];
}

export interface LineRow { position: number; product_id: string | null; quantity: number | null; display: string | null; name: string; match: string | null; source_key: string | null }

/**
 * Resolve one stored recipe line for a household: which product it effectively uses, how much of it, and
 * what to show about the substitution. `products` must contain every product id involved.
 */
export function resolveLine(row: LineRow, ctx: SubContext, products: Map<string, Product>): { productId: string | null; quantity: number | null; match: MatchKind; sub: SubInfo | null; extra: { product: string; quantity: number }[] } {
  const stored = (row.match as MatchKind | null) ?? (row.product_id ? 'exact' : 'unresolved');
  const key = row.source_key ?? (stored !== 'exact' && row.product_id ? null : row.product_id ? null : `u:${row.name.toLowerCase()}`);
  const original = row.display ?? row.name;
  // Exact lines: only a household choice for that product changes them (e.g. "always use crème fraîche").
  if (!key) {
    const pid = row.product_id;
    const pick = pid ? ctx.prefs.get(pid) : undefined;
    if (pid && pick && pick !== 'keep' && pick !== pid && products.get(pick) && products.get(pid)) {
      const s = ctx.subs.get(pid)?.find((x) => x.to_product === pick);
      const q = row.quantity == null ? null : convertQty(row.quantity, products.get(pid)!, products.get(pick)!);
      return {
        productId: pick, quantity: q == null ? null : q * (s?.ratio ?? 1), match: s?.kind ?? 'substitute',
        sub: { fromKey: pid, original, kind: s?.kind ?? 'substitute', note: s?.note ?? null, prep: s?.prep ?? null, identity: !!s?.identity, choice: 'user', status: ctx.availability.get(pid) ?? 'common', options: optionsFor(ctx, pid) },
        extra: extrasFor(s, q),
      };
    }
    return { productId: pid, quantity: row.quantity, match: stored, sub: null, extra: [] };
  }
  // Only the family was named ("milk"): your usual type, else the default variant stored on the line.
  if (key.startsWith('f:')) {
    const pref = ctx.prefs.get(key);
    if (pref && products.get(pref) && row.product_id && products.get(row.product_id)) {
      const q = row.quantity == null ? null : convertQty(row.quantity, products.get(row.product_id)!, products.get(pref)!);
      return { productId: pref, quantity: q, match: 'exact', sub: null, extra: [] };
    }
    return { productId: row.product_id, quantity: row.quantity, match: 'equivalent', sub: null, extra: [] };
  }
  const status = key.startsWith('x:') ? ctx.foreign.get(key)?.status ?? null : null;
  const options = optionsFor(ctx, key);
  const choice = ctx.prefs.get(key);
  if (choice === 'keep') {
    return { productId: null, quantity: null, match: 'unresolved', sub: { fromKey: key, original, kind: 'unresolved', note: null, prep: null, identity: false, choice: 'keep', status, options }, extra: [] };
  }
  const base = row.product_id ? products.get(row.product_id) : undefined;
  if (choice && products.get(choice)) {
    const s = ctx.subs.get(key)?.find((x) => x.to_product === choice);
    const def = row.product_id ? ctx.subs.get(key)?.find((x) => x.to_product === row.product_id) : undefined;
    // The stored amount is in the default product's terms; carry it over by weight and ratio.
    const q = row.quantity != null && base ? convertQty(row.quantity / (def?.ratio ?? 1), base, products.get(choice)!) : null;
    const quantity = q == null ? null : q * (s?.ratio ?? 1);
    return {
      productId: choice, quantity, match: s?.kind ?? (key.startsWith('u:') ? 'equivalent' : 'substitute'),
      sub: { fromKey: key, original, kind: s?.kind ?? (key.startsWith('u:') ? 'equivalent' : 'substitute'), note: s?.note ?? null, prep: s?.prep ?? null, identity: !!s?.identity, choice: 'user', status, options },
      extra: extrasFor(s, quantity),
    };
  }
  if (row.product_id && base) {
    const s = ctx.subs.get(key)?.find((x) => x.to_product === row.product_id);
    return {
      productId: row.product_id, quantity: row.quantity, match: stored,
      sub: { fromKey: key, original, kind: stored, note: s?.note ?? null, prep: s?.prep ?? null, identity: !!s?.identity, choice: 'default', status, options },
      extra: extrasFor(s, row.quantity),
    };
  }
  return { productId: null, quantity: null, match: 'unresolved', sub: { fromKey: key, original, kind: 'unresolved', note: null, prep: null, identity: false, choice: 'default', status, options }, extra: [] };
}

function optionsFor(ctx: SubContext, key: string) {
  return (ctx.subs.get(key) ?? []).map((s) => ({ id: s.to_product, kind: s.kind as MatchKind, note: s.note }));
}

function extrasFor(s: SubRow | undefined, qty: number | null) {
  if (!s?.extra.length || qty == null) return [];
  return s.extra.map((e) => ({ product: e.product, quantity: Math.round(qty * e.perUnit * 100) / 100 }));
}

/** Recipe compatibility in a country, from its resolved lines. */
export interface Compat {
  level: 'full' | 'substitutions' | 'partial' | 'specialist';
  substitutions: number;
  unresolved: number;
  specialist: number;
}

export function compatOf(lines: { optional: boolean; match: MatchKind; productId: string | null; sub: SubInfo | null }[], ctx: SubContext): Compat {
  let substitutions = 0, unresolved = 0, specialist = 0;
  for (const l of lines) {
    if (l.optional) continue;
    if (l.match === 'substitute' || l.match === 'approximate') substitutions++;
    if (!l.productId) {
      // An ingredient you can buy but PantryPip doesn't track (hoisin) is fine; unknown or hard to get isn't.
      const st = l.sub?.status;
      if (st === 'specialist' || st === 'unavailable') specialist++;
      else if (st !== 'common') unresolved++;
    } else {
      const st = ctx.availability.get(l.productId);
      if (st === 'specialist' || st === 'unavailable') specialist++;
    }
  }
  const level = specialist ? 'specialist' : unresolved ? 'partial' : substitutions ? 'substitutions' : 'full';
  return { level, substitutions, unresolved, specialist };
}

export { familyById };
