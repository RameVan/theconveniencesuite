// The household's nutrition targets: everyone's own targets (Settings → Dietary needs) plus optional overrides.
import type { Db } from '../db/db.ts';
import { parseJson } from '../db/db.ts';
import { getPeople } from './dietary.ts';
import { householdTargets, type DailyTargets } from './health.ts';

export function nutritionOverrides(db: Db, householdId: string): Partial<DailyTargets> {
  return parseJson(db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = '' AND key = 'nutritionTargets'", householdId)?.value, {});
}

const SENSITIVITY: Record<string, number> = { gentle: 1.5, standard: 1, strict: 0.7 };

export function targetsFor(db: Db, householdId: string): DailyTargets {
  const s = parseJson<string>(db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = '' AND key = 'scoringSensitivity'", householdId)?.value, 'standard');
  const people = getPeople(db, householdId);
  // Someone eating low-carb: score carbohydrate against a low-carb range (≤ 26 % of energy) instead.
  const lowCarb = people.some((p: any) => p.diets?.includes('low-carb')) ? { carbMinPct: 0, carbMaxPct: 26 } : {};
  return { ...householdTargets(people, { ...lowCarb, ...nutritionOverrides(db, householdId) }), sensitivity: SENSITIVITY[s] ?? 1 };
}
