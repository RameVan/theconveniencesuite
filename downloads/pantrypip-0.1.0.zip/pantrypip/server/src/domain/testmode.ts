// Owner test mode, and "reset all progress" for everyone.
//
// Test mode is a sandbox: on entry the whole database is copied (VACUUM INTO, checked), and on exit every
// row of this household is put back from that copy. While it's on you can unlock everything and move the
// household's clock (clock.shifted, applied per request in server.ts); both are undone on exit with the rest.
import path from 'node:path';
import { mkdirSync, existsSync, rmSync } from 'node:fs';
import { DatabaseSync } from 'node:sqlite';
import type { Db } from '../db/db.ts';
import { clock } from '../clock.ts';
import { config } from '../config.ts';
import { AppError } from '../errors.ts';
import { log } from '../log.ts';
import { bus } from '../bus.ts';
import { CHAPTERS, SKINS } from './journey.ts';
import { levelFor, LEVELS, game } from './game.ts';

export const isOwner = (u: { email: string } | null) => !!u && !!config.ownerEmail && u.email.trim().toLowerCase() === config.ownerEmail;
const ownerOnly = (u: { email: string }) => {
  if (!isOwner(u)) throw new AppError(403, 'owner_only', 'Only the owner can use test mode');
};

interface TestRow { household_id: string; user_id: string; snapshot: string; offset_days: number; unlocked: number; started_at: string }
const rowOf = (db: Db, h: string) => db.get<TestRow>('SELECT * FROM test_mode WHERE household_id = ?', h);

export function testState(db: Db, h: string) {
  const r = rowOf(db, h);
  return r ? { on: true, since: r.started_at, offsetDays: r.offset_days, unlocked: !!r.unlocked, today: clock.today() } : { on: false };
}

const snapDir = () => path.join(config.backupDir, 'test-mode');

/**
 * Tables whose rows belong to a household and come back from the snapshot. Accounts, sign-ins and devices stay
 * as they are. Shared lists (shared_list*) have no household_id on purpose: other households edit them too, so
 * putting one household's copy back would undo their changes. Stock bought from one does come back (it's ledger).
 */
const KEEP = new Set(['users', 'api_tokens', 'push_subscriptions', 'audit_log', 'test_mode']);
function householdTables(db: Db): string[] {
  const all = (sql: string) => db.all<any>(sql);
  return all("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'")
    .map((t) => t.name as string)
    .filter((t) => !KEEP.has(t) && all(`PRAGMA table_info(${t})`).some((c) => c.name === 'household_id'));
}

export function startTest(db: Db, user: { id: string; email: string; household_id: string }) {
  ownerOnly(user);
  const h = user.household_id;
  if (rowOf(db, h)) return testState(db, h);
  mkdirSync(snapDir(), { recursive: true });
  const file = `${h}-${clock.iso().replace(/[:.]/g, '-')}.db`;
  const full = path.join(snapDir(), file);
  db.exec(`VACUUM INTO '${full.replace(/'/g, "''")}'`);
  // Never start without a copy that's known to be good: it's what your real data comes back from.
  const check = new DatabaseSync(full, { readOnly: true });
  try {
    const ok = (check.prepare('PRAGMA integrity_check').get() as any)?.integrity_check === 'ok';
    const rows = (check.prepare('SELECT COUNT(*) n FROM inventory_events WHERE household_id = ?').get(h) as any).n;
    const live = db.get<{ n: number }>('SELECT COUNT(*) n FROM inventory_events WHERE household_id = ?', h)!.n;
    if (!ok || rows !== live) throw new AppError(500, 'snapshot_failed', 'The copy of your data could not be checked, so test mode did not start');
  } finally {
    check.close();
  }
  db.insert('test_mode', { household_id: h, user_id: user.id, snapshot: file, started_at: clock.iso() });
  log.info('test mode on', { household: h, snapshot: file });
  bus.touch(h, 'all');
  return testState(db, h);
}

/** Put every row of this household back as it was when test mode started. */
export function stopTest(db: Db, user: { id: string; email: string; household_id: string }) {
  ownerOnly(user);
  const h = user.household_id;
  const row = rowOf(db, h);
  if (!row) return testState(db, h);
  const full = path.join(snapDir(), row.snapshot);
  if (!existsSync(full)) throw new AppError(500, 'snapshot_missing', 'The copy of your data is missing, so nothing was changed. Your sandbox stays on.');
  const rev = Number(db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = '' AND key = 'settingsRev'", h)?.value ?? 0);
  const tables = householdTables(db);
  db.exec('PRAGMA foreign_keys = OFF');
  try {
    db.exec(`ATTACH DATABASE '${full.replace(/'/g, "''")}' AS snap`);
    try {
      const snapTables = new Set(db.all<{ name: string }>("SELECT name FROM snap.sqlite_master WHERE type = 'table'").map((t) => t.name));
      const cols = (t: string) => {
        const mine = db.all<{ name: string }>(`PRAGMA main.table_info(${t})`).map((c) => c.name);
        const theirs = new Set(db.all<{ name: string }>(`PRAGMA snap.table_info(${t})`).map((c) => c.name));
        return mine.filter((c) => theirs.has(c)).join(', ');
      };
      db.tx(() => {
        // Recipe ingredients hang off the household's recipes, not the household itself.
        db.run('DELETE FROM main.recipe_ingredients WHERE recipe_id IN (SELECT id FROM main.recipes WHERE household_id = ?)', h);
        db.run(`INSERT INTO main.recipe_ingredients (${cols('recipe_ingredients')}) SELECT ${cols('recipe_ingredients')} FROM snap.recipe_ingredients WHERE recipe_id IN (SELECT id FROM snap.recipes WHERE household_id = ?)`, h);
        for (const t of tables) {
          db.run(`DELETE FROM main.${t} WHERE household_id = ?`, h);
          if (snapTables.has(t)) db.run(`INSERT INTO main.${t} (${cols(t)}) SELECT ${cols(t)} FROM snap.${t} WHERE household_id = ?`, h);
        }
        db.run(`UPDATE main.households SET (${cols('households')}) = (SELECT ${cols('households')} FROM snap.households WHERE id = ?) WHERE id = ?`, h, h);
        // Settings come back too; a newer revision makes open apps take them instead of their cached copy.
        db.run("INSERT INTO preferences (household_id, user_id, key, value) VALUES (?, '', 'settingsRev', ?) ON CONFLICT(household_id, user_id, key) DO UPDATE SET value = excluded.value", h, String(rev + 1));
        db.run('DELETE FROM test_mode WHERE household_id = ?', h);
      });
    } finally {
      db.exec('DETACH DATABASE snap');
    }
  } finally {
    db.exec('PRAGMA foreign_keys = ON');
  }
  const broken = db.all<any>('PRAGMA foreign_key_check');
  if (broken.length) log.warn('test mode restore left dangling references', { count: broken.length, first: broken[0] });
  try {
    rmSync(full);
  } catch {}
  log.info('test mode off, data restored', { household: h });
  bus.touch(h, 'all');
  return testState(db, h);
}

export function setTestTime(db: Db, user: { email: string; household_id: string }, days: number) {
  ownerOnly(user);
  if (!rowOf(db, user.household_id)) throw new AppError(409, 'test_off', 'Turn on test mode first, so time travel can be undone');
  const d = Math.max(-3650, Math.min(3650, Math.round(days)));
  db.run('UPDATE test_mode SET offset_days = ? WHERE household_id = ?', d, user.household_id);
  bus.touch(user.household_id, 'all');
  return clock.shifted(d, () => testState(db, user.household_id));
}

/** Every chapter done, every look and Pip extra unlocked, top level reached. Sandbox only. */
export function unlockEverything(db: Db, user: { email: string; household_id: string }) {
  ownerOnly(user);
  const h = user.household_id;
  if (!rowOf(db, h)) throw new AppError(409, 'test_off', 'Turn on test mode first, so this can be undone');
  const now = clock.iso();
  db.tx(() => {
    CHAPTERS.forEach((ch, i) => {
      const tasks = ch.pool.slice(0, 4);
      db.run('INSERT INTO journey_chapters (household_id, chapter, unlocked_at, tasks, bonus, boss_since, completed_at, celebrated) VALUES (?, ?, ?, ?, ?, ?, ?, 1) ON CONFLICT(household_id, chapter) DO UPDATE SET completed_at = excluded.completed_at, boss_since = excluded.boss_since, celebrated = 1',
        h, i, now, JSON.stringify(tasks), JSON.stringify(ch.bonus), now, now);
      const p = `c${i + 1}`;
      for (const [id, kind] of [...tasks.map((t) => [`${p}:${t}`, 'task']), ...ch.bonus.map((t) => [`${p}:${t}`, 'bonus']), [`${p}:milestone`, 'milestone'], [`${p}:boss`, 'boss']])
        db.run('INSERT OR IGNORE INTO journey_nodes (household_id, node_id, kind, xp, completed_at, celebrated) VALUES (?, ?, ?, 0, ?, 1)', h, id, kind, now);
    });
    for (const s of SKINS) if (s.id !== 'sprout') db.run("INSERT OR IGNORE INTO social_rewards (household_id, key, kind, xp, title, title_nl, emoji, unlock, at) VALUES (?, ?, 'test', 0, 'Test mode', 'Testmodus', '🧪', ?, ?)", h, `test:skin:${s.id}`, `skin:${s.id}`, now);
    db.run("INSERT OR IGNORE INTO social_rewards (household_id, key, kind, xp, title, title_nl, emoji, unlock, at) VALUES (?, 'test:stage:heart', 'test', 0, 'Test mode', 'Testmodus', '🧪', 'stage:heart', ?)", h, now);
    const top = LEVELS[LEVELS.length - 1].xp;
    const xp = game(db, h).xp;
    if (xp < top) db.run("INSERT INTO social_rewards (household_id, key, kind, xp, title, title_nl, emoji, unlock, at) VALUES (?, 'test:xp', 'test', ?, 'Test mode: top level', 'Testmodus: hoogste level', '🧪', NULL, ?) ON CONFLICT(household_id, key) DO UPDATE SET xp = xp + excluded.xp", h, top - xp, now);
    db.run('UPDATE test_mode SET unlocked = 1 WHERE household_id = ?', h);
  });
  bus.touch(h, 'all');
  return { ...testState(db, h), level: levelFor(game(db, h).xp).n };
}

/**
 * Start the game over: XP, levels, chapters, rewards, streaks and leagues. Stock, recipes, plans and
 * your cooking history stay; only what you cook from now on counts towards progress.
 */
export function resetProgress(db: Db, h: string) {
  const now = clock.iso();
  db.tx(() => {
    for (const t of ['journey_chapters', 'journey_nodes', 'social_rewards', 'leagues', 'progress_snapshots']) db.run(`DELETE FROM ${t} WHERE household_id = ?`, h);
    db.run("INSERT INTO preferences (household_id, user_id, key, value) VALUES (?, '', 'progressSince', ?) ON CONFLICT(household_id, user_id, key) DO UPDATE SET value = excluded.value", h, JSON.stringify(now));
    // Pip goes back to the starting look (keeps its name).
    const c = db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = '' AND key = 'companion'", h);
    if (c) {
      const v = { ...JSON.parse(c.value), skin: 'sprout' };
      db.run("UPDATE preferences SET value = ? WHERE household_id = ? AND user_id = '' AND key = 'companion'", JSON.stringify(v), h);
    }
  });
  bus.touch(h, 'all');
  return { ok: true, since: now };
}

/** Owner only: test accounts skip email confirmation. */
export const ownerCheck = ownerOnly;
