// Units, number words and conversions (English + Dutch).
export type BaseUnit = 'g' | 'ml' | 'pcs';

export interface ProductUnitInfo {
  unit: BaseUnit;
  package_size: number;
  piece_size?: number | null;
  piece_name?: string | null;
  /** g per ml; null = 1. */
  density?: number | null;
}

type UnitDef =
  | { kind: 'measure'; base: BaseUnit; factor: number }
  | { kind: 'package' }
  | { kind: 'piece' }
  | { kind: 'portion' };

const M = (base: BaseUnit, factor: number): UnitDef => ({ kind: 'measure', base, factor });

/** Surface forms → unit definition. Keys are lower-case. */
export const UNIT_WORDS: Record<string, UnitDef> = {
  g: M('g', 1), gr: M('g', 1), gram: M('g', 1), grams: M('g', 1), gramme: M('g', 1),
  kg: M('g', 1000), kilo: M('g', 1000), kilos: M('g', 1000), kilogram: M('g', 1000), kilograms: M('g', 1000), kilogrammes: M('g', 1000),
  ons: M('g', 100), pond: M('g', 500),
  mg: M('g', 0.001),
  ml: M('ml', 1), milliliter: M('ml', 1), milliliters: M('ml', 1), millilitre: M('ml', 1), millilitres: M('ml', 1),
  cl: M('ml', 10), centiliter: M('ml', 10), dl: M('ml', 100), deciliter: M('ml', 100),
  l: M('ml', 1000), lt: M('ml', 1000), liter: M('ml', 1000), liters: M('ml', 1000), litre: M('ml', 1000), litres: M('ml', 1000),
  tbsp: M('ml', 15), tablespoon: M('ml', 15), tablespoons: M('ml', 15), el: M('ml', 15), eetlepel: M('ml', 15), eetlepels: M('ml', 15),
  tsp: M('ml', 5), teaspoon: M('ml', 5), teaspoons: M('ml', 5), tl: M('ml', 5), theelepel: M('ml', 5), theelepels: M('ml', 5),
  cup: M('ml', 240), cups: M('ml', 240), kop: M('ml', 240), kopje: M('ml', 240), kopjes: M('ml', 240),
  // US measures, for imported recipes.
  oz: M('g', 28.35), ounce: M('g', 28.35), ounces: M('g', 28.35), lb: M('g', 453.6), lbs: M('g', 453.6), pound: M('g', 453.6), pounds: M('g', 453.6),
  pint: M('ml', 473), pints: M('ml', 473), pt: M('ml', 473), quart: M('ml', 946), quarts: M('ml', 946), qt: M('ml', 946), gallon: M('ml', 3785), gallons: M('ml', 3785),
  tbs: M('ml', 15), tbl: M('ml', 15), tbsps: M('ml', 15), tsps: M('ml', 5),
  pkg: { kind: 'package' }, pkgs: { kind: 'package' },
  cupful: M('ml', 240), cupfuls: M('ml', 240),
  // Small kitchen measures (approximate): never a whole pack.
  pinch: M('g', 0.4), pinches: M('g', 0.4), snufje: M('g', 0.4), mespuntje: M('g', 0.5), dash: M('ml', 0.6), dashes: M('ml', 0.6), scheutje: M('ml', 10),
  sprinkle: M('g', 0.5), sprig: M('g', 1), sprigs: M('g', 1), takje: M('g', 1), takjes: M('g', 1), handful: M('g', 30), handfuls: M('g', 30), handje: M('g', 30),
  knob: M('g', 15), knobs: M('g', 15), splash: M('ml', 10), drop: M('ml', 0.05), drops: M('ml', 0.05), shot: M('ml', 30), shots: M('ml', 30),
  glass: M('ml', 250), glasses: M('ml', 250), glas: M('ml', 250), glazen: M('ml', 250), glaasje: M('ml', 250),
  piece: { kind: 'piece' }, pieces: { kind: 'piece' }, pc: { kind: 'piece' }, pcs: { kind: 'piece' }, st: { kind: 'piece' }, stuk: { kind: 'piece' }, stuks: { kind: 'piece' },
  x: { kind: 'piece' },
  slice: { kind: 'piece' }, slices: { kind: 'piece' }, plak: { kind: 'piece' }, plakken: { kind: 'piece' }, plakje: { kind: 'piece' }, plakjes: { kind: 'piece' },
  sneetje: { kind: 'piece' }, sneetjes: { kind: 'piece' }, boterham: { kind: 'piece' }, boterhammen: { kind: 'piece' },
  clove: { kind: 'piece' }, cloves: { kind: 'piece' }, teen: { kind: 'piece' }, teentje: { kind: 'piece' }, teentjes: { kind: 'piece' }, tenen: { kind: 'piece' },
  pack: { kind: 'package' }, packs: { kind: 'package' }, package: { kind: 'package' }, packages: { kind: 'package' }, packet: { kind: 'package' }, packets: { kind: 'package' },
  pak: { kind: 'package' }, pakken: { kind: 'package' }, pakje: { kind: 'package' }, pakjes: { kind: 'package' },
  bottle: { kind: 'package' }, bottles: { kind: 'package' }, fles: { kind: 'package' }, flessen: { kind: 'package' }, flesje: { kind: 'package' },
  can: { kind: 'package' }, cans: { kind: 'package' }, tin: { kind: 'package' }, tins: { kind: 'package' }, blik: { kind: 'package' }, blikken: { kind: 'package' }, blikje: { kind: 'package' }, blikjes: { kind: 'package' },
  jar: { kind: 'package' }, jars: { kind: 'package' }, pot: { kind: 'package' }, potten: { kind: 'package' }, potje: { kind: 'package' },
  bag: { kind: 'package' }, bags: { kind: 'package' }, zak: { kind: 'package' }, zakken: { kind: 'package' }, zakje: { kind: 'package' }, zakjes: { kind: 'package' },
  box: { kind: 'package' }, boxes: { kind: 'package' }, doos: { kind: 'package' }, dozen: { kind: 'package' }, doosje: { kind: 'package' },
  carton: { kind: 'package' }, cartons: { kind: 'package' }, tray: { kind: 'package' }, bakje: { kind: 'package' }, bakjes: { kind: 'package' },
  bunch: { kind: 'package' }, bos: { kind: 'package' }, bosje: { kind: 'package' }, net: { kind: 'package' }, netje: { kind: 'package' },
  loaf: { kind: 'package' }, loaves: { kind: 'package' }, brood: { kind: 'package' },
  tube: { kind: 'package' }, tubes: { kind: 'package' }, tub: { kind: 'package' }, kuipje: { kind: 'package' },
  portion: { kind: 'portion' }, portions: { kind: 'portion' }, serving: { kind: 'portion' }, servings: { kind: 'portion' },
  portie: { kind: 'portion' }, porties: { kind: 'portion' }, bord: { kind: 'portion' }, borden: { kind: 'portion' },
};

export const NUMBER_WORDS: Record<string, number> = {
  a: 1, an: 1, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10,
  eleven: 11, twelve: 12, dozen: 12, fifteen: 15, twenty: 20, thirty: 30, fifty: 50, hundred: 100,
  half: 0.5, quarter: 0.25, couple: 2, 'a couple': 2, pair: 2,
  een: 1, één: 1, eén: 1, twee: 2, drie: 3, vier: 4, vijf: 5, zes: 6, zeven: 7, acht: 8, negen: 9, tien: 10,
  elf: 11, twaalf: 12, vijftien: 15, twintig: 20, dertig: 30, vijftig: 50, honderd: 100,
  halve: 0.5, kwart: 0.25, anderhalf: 1.5, anderhalve: 1.5, paar: 2,
};

export function parseNumber(token: string): number | null {
  const t = token.toLowerCase().trim();
  if (t in NUMBER_WORDS) return NUMBER_WORDS[t];
  const frac = t.match(/^(\d+)\/(\d+)$/);
  if (frac) return Number(frac[1]) / Number(frac[2]);
  const n = Number(t.replace(',', '.'));
  return Number.isFinite(n) && /^\d/.test(t) ? n : null;
}

export function unitDef(word: string | undefined | null): UnitDef | null {
  if (!word) return null;
  return UNIT_WORDS[word.toLowerCase().replace(/\.$/, '')] ?? null;
}

export class UnitError extends Error {}

/**
 * Convert an amount in a surface unit to the product's base unit.
 * g <-> ml is converted at density 1 (approximate, flagged by the caller if needed).
 * Pieces convert through piece_size; packages through package_size.
 */
export function toBase(amount: number, unitWord: string | null | undefined, p: ProductUnitInfo, portionSize?: number): { qty: number; approx: boolean } {
  const def = unitWord ? unitDef(unitWord) : null;
  if (!unitWord || !def) {
    // Bare number: pieces for countables, packages otherwise ("2 milk" = two cartons).
    if (p.unit === 'pcs') return { qty: amount, approx: false };
    if (p.piece_size) return { qty: amount * p.piece_size, approx: false };
    return { qty: amount * p.package_size, approx: false };
  }
  switch (def.kind) {
    case 'package':
      return { qty: amount * p.package_size, approx: false };
    case 'portion':
      return { qty: amount * (portionSize ?? 1), approx: portionSize == null };
    case 'piece':
      if (p.unit === 'pcs') return { qty: amount, approx: false };
      if (p.piece_size) return { qty: amount * p.piece_size, approx: false };
      throw new UnitError(`Can't count pieces of this product`);
    case 'measure': {
      const v = amount * def.factor;
      if (def.base === p.unit) return { qty: v, approx: false };
      const d = p.density ?? 1;
      if (def.base === 'ml' && p.unit === 'g') return { qty: v * d, approx: !p.density };
      if (def.base === 'g' && p.unit === 'ml') return { qty: v / d, approx: !p.density };
      if (p.unit === 'pcs' && p.piece_size) return { qty: v / p.piece_size, approx: true };
      throw new UnitError(`Can't convert ${unitWord} for this product`);
    }
  }
}

/** Convert a base quantity into a number of packages, rounded up (for shopping). */
export function packagesFor(qty: number, p: ProductUnitInfo): number {
  if (!p.package_size || p.package_size <= 0) return Math.ceil(qty);
  return Math.max(1, Math.ceil(qty / p.package_size - 1e-9));
}

export function roundQty(q: number): number {
  if (Math.abs(q) >= 100) return Math.round(q);
  if (Math.abs(q) >= 10) return Math.round(q * 10) / 10;
  return Math.round(q * 100) / 100;
}

/** Human formatting: 1500 ml → "1.5 L", 250 g → "250 g", 6 pcs → "6". */
export function formatQty(q: number, unit: string, opts: { pieceName?: string | null; lang?: 'en' | 'nl' } = {}): string {
  const r = roundQty(q);
  const nl = opts.lang === 'nl';
  const num = (n: number) => (nl ? String(n).replace('.', ',') : String(n));
  switch (unit) {
    case 'g':
      return Math.abs(r) >= 1000 ? `${num(roundQty(r / 1000))} kg` : `${num(r)} g`;
    case 'ml':
      return Math.abs(r) >= 1000 ? `${num(roundQty(r / 1000))} L` : `${num(r)} ml`;
    case 'portion':
      return nl ? `${num(r)} ${r === 1 ? 'portie' : 'porties'}` : `${num(r)} ${r === 1 ? 'portion' : 'portions'}`;
    default:
      return opts.pieceName ? `${num(r)} ${opts.pieceName}${r === 1 ? '' : /(tomat|potat)o$/.test(opts.pieceName) ? 'es' : 's'}` : num(r);
  }
}
