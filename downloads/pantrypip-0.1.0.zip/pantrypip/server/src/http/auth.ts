// Password hashing (scrypt) and cookie sessions. Session tokens are stored hashed.
import { randomBytes, scryptSync, timingSafeEqual, createHash } from 'node:crypto';
import type { Db } from '../db/db.ts';
import { newId } from '../db/db.ts';
import { clock } from '../clock.ts';
import { AppError } from '../errors.ts';
import { normalizeCode } from '../domain/social.ts';

const SESSION_DAYS = 120; // long-lived so the app opens straight into "say it and go"
export const COOKIE = 'larder_session';

export function hashPassword(pw: string): string {
  const salt = randomBytes(16);
  const hash = scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$${salt.toString('base64')}$${hash.toString('base64')}`;
}

export function verifyPassword(pw: string, stored: string): boolean {
  const [alg, saltB64, hashB64] = stored.split('$');
  if (alg !== 'scrypt') return false;
  const expected = Buffer.from(hashB64, 'base64');
  const actual = scryptSync(pw, Buffer.from(saltB64, 'base64'), expected.length, { N: 16384, r: 8, p: 1 });
  return timingSafeEqual(expected, actual);
}

const sha = (s: string) => createHash('sha256').update(s).digest('hex');

export function createSession(db: Db, userId: string): { token: string; expires: Date } {
  const token = randomBytes(32).toString('base64url');
  const expires = new Date(clock.now().getTime() + SESSION_DAYS * 86_400_000);
  db.insert('sessions', { token_hash: sha(token), user_id: userId, expires_at: expires.toISOString(), created_at: clock.iso() });
  return { token, expires };
}

export interface SessionUser {
  id: string;
  household_id: string;
  email: string;
  name: string;
}

export function userForToken(db: Db, token: string | undefined): SessionUser | null {
  if (!token) return null;
  const row = db.get<SessionUser & { expires_at: string }>(
    'SELECT u.id, u.household_id, u.email, u.name, s.expires_at FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?',
    sha(token),
  );
  if (!row || row.expires_at < clock.iso()) return null;
  return { id: row.id, household_id: row.household_id, email: row.email, name: row.name };
}

export function destroySession(db: Db, token: string | undefined) {
  if (token) db.run('DELETE FROM sessions WHERE token_hash = ?', sha(token));
}

// Simple in-memory brute-force protection for sign-in.
const attempts = new Map<string, { n: number; until: number }>();
export function checkRateLimit(key: string) {
  const a = attempts.get(key);
  if (a && a.until > Date.now() && a.n >= 8) throw new AppError(429, 'rate_limited', 'Too many attempts. Try again in a few minutes.');
}
export function recordFailure(key: string) {
  const a = attempts.get(key);
  if (!a || a.until < Date.now()) attempts.set(key, { n: 1, until: Date.now() + 10 * 60_000 });
  else a.n++;
}
export function clearFailures(key: string) {
  attempts.delete(key);
}

/**
 * What an invite code (or a pasted invite link) is: a household's code (join that household) or someone's
 * friend code (your own household, and friends with them from the start). Null when it's neither.
 */
export function resolveInvite(db: Db, raw: string): { kind: 'household'; householdId: string } | { kind: 'friend'; userId: string } | null {
  const h = db.get<{ id: string }>('SELECT id FROM households WHERE invite_code = ?', raw.trim().toUpperCase());
  if (h) return { kind: 'household', householdId: h.id };
  const f = db.get<{ user_id: string }>('SELECT user_id FROM friend_codes WHERE code = ?', normalizeCode(raw));
  return f ? { kind: 'friend', userId: f.user_id } : null;
}
const invalidInvite = () => new AppError(404, 'invalid_invite', 'Invite code not found');

export function registerUser(db: Db, input: { email: string; password?: string; passwordHash?: string; name: string; inviteCode?: string | null; householdName?: string | null }, createHousehold: (name: string) => string): SessionUser {
  if (db.get('SELECT 1 FROM users WHERE lower(email) = lower(?)', input.email)) throw new AppError(409, 'email_taken', 'An account with this email already exists');
  const invite = input.inviteCode?.trim() ? resolveInvite(db, input.inviteCode) : null;
  if (input.inviteCode?.trim() && !invite) throw invalidInvite();
  const householdId = invite?.kind === 'household' ? invite.householdId : createHousehold(input.householdName || `${input.name}'s household`);
  const id = newId('u');
  const now = clock.iso();
  db.insert('users', { id, household_id: householdId, email: input.email.trim(), name: input.name.trim(), password_hash: input.passwordHash ?? hashPassword(input.password!), created_at: now });
  // Invited by a friend's code: friends straight away (as if you'd asked and they'd accepted), which also counts for their invite reward.
  if (invite?.kind === 'friend') db.insert('friendships', { id: newId('fr'), requester_id: id, addressee_id: invite.userId, status: 'accepted', created_at: now, accepted_at: now, via: 'code' });
  return { id, household_id: householdId, email: input.email, name: input.name };
}

// ---------- Email confirmation and password reset ----------
// Links carry a random token; only its hash is stored, and each link works once.
const CONFIRM_HOURS = 48;
const RESET_MINUTES = 60;
const later = (ms: number) => new Date(clock.now().getTime() + ms).toISOString();

export interface SignupInput { email: string; password: string; name: string; inviteCode?: string | null; householdName?: string | null }

/** Hold a sign-up until its email is confirmed. Returns the token for the link (null when the email is taken). */
export function startSignup(db: Db, input: SignupInput): string | null {
  if (db.get('SELECT 1 FROM users WHERE lower(email) = lower(?)', input.email)) return null;
  if (input.inviteCode?.trim() && !resolveInvite(db, input.inviteCode)) throw invalidInvite();
  db.run('DELETE FROM pending_signups WHERE lower(email) = lower(?) OR expires_at < ?', input.email, clock.iso());
  const token = randomBytes(32).toString('base64url');
  db.insert('pending_signups', {
    token_hash: sha(token), email: input.email.trim(), name: input.name.trim(), password_hash: hashPassword(input.password),
    invite_code: input.inviteCode || null, household_name: input.householdName || null, created_at: clock.iso(), expires_at: later(CONFIRM_HOURS * 3_600_000),
  });
  return token;
}

/** Turn a confirmed sign-up into an account. */
export function confirmSignup(db: Db, token: string, createHousehold: (name: string) => string): { user: SessionUser; joined: boolean } {
  const p = db.get<{ email: string; name: string; password_hash: string; invite_code: string | null; household_name: string | null; expires_at: string }>('SELECT * FROM pending_signups WHERE token_hash = ?', sha(token));
  if (!p || p.expires_at < clock.iso()) throw new AppError(410, 'link_expired', 'This link has expired or was already used. Sign up again to get a new one.');
  db.run('DELETE FROM pending_signups WHERE lower(email) = lower(?)', p.email);
  const joined = !!p.invite_code && resolveInvite(db, p.invite_code)?.kind === 'household';
  const user = registerUser(db, { email: p.email, passwordHash: p.password_hash, name: p.name, inviteCode: p.invite_code, householdName: p.household_name }, createHousehold);
  return { user, joined };
}

/** A reset link for this email, or null when there's no such account (the caller says the same thing either way). */
export function startReset(db: Db, email: string): { token: string; user: { id: string; email: string; name: string } } | null {
  const user = db.get<{ id: string; email: string; name: string }>('SELECT id, email, name FROM users WHERE lower(email) = lower(?)', email.trim());
  if (!user) return null;
  db.run('DELETE FROM password_resets WHERE user_id = ? OR expires_at < ?', user.id, clock.iso());
  const token = randomBytes(32).toString('base64url');
  db.insert('password_resets', { token_hash: sha(token), user_id: user.id, created_at: clock.iso(), expires_at: later(RESET_MINUTES * 60_000) });
  return { token, user };
}

/** Set a new password from a reset link. Signs out every device, so a stolen session stops working too. */
export function finishReset(db: Db, token: string, password: string): string {
  const r = db.get<{ user_id: string; expires_at: string; used_at: string | null }>('SELECT * FROM password_resets WHERE token_hash = ?', sha(token));
  if (!r || r.used_at || r.expires_at < clock.iso()) throw new AppError(410, 'link_expired', 'This link has expired or was already used. Ask for a new one.');
  db.run('UPDATE users SET password_hash = ? WHERE id = ?', hashPassword(password), r.user_id);
  db.run('UPDATE password_resets SET used_at = ? WHERE token_hash = ?', clock.iso(), sha(token));
  db.run('DELETE FROM sessions WHERE user_id = ?', r.user_id);
  return r.user_id;
}

/** Whether a reset link is still good (so the page can say so before you type a password). */
export function resetValid(db: Db, token: string): boolean {
  const r = db.get<{ expires_at: string; used_at: string | null }>('SELECT expires_at, used_at FROM password_resets WHERE token_hash = ?', sha(token));
  return !!r && !r.used_at && r.expires_at >= clock.iso();
}

// ---------- Access requests (invite-only copies) ----------
// Someone without an invite leaves a name, email and note. The owner approves (a one-time sign-up link by email,
// stored hashed, good for a week) or declines (nothing is sent). The link was mailed to that address, so using
// it proves the address: the account is made straight away, without a second confirmation email.
const ACCESS_DAYS = 7;
const accessExpired = () => new AppError(410, 'link_expired', 'This link has expired or was already used. Ask for access again.');

interface AccessRow { id: string; email: string; name: string; note: string | null; lang: string | null; status: string; created_at: string; expires_at: string | null }

/** Store a request. Null when there's nothing new to tell the owner (the address has an account or an open request). */
export function requestAccess(db: Db, input: { email: string; name: string; note?: string | null; lang?: string | null }): { id: string; name: string } | null {
  const email = input.email.trim();
  if (db.get('SELECT 1 FROM users WHERE lower(email) = lower(?)', email)) return null;
  if (db.get("SELECT 1 FROM access_requests WHERE lower(email) = lower(?) AND (status = 'pending' OR (status = 'approved' AND expires_at >= ?))", email, clock.iso())) return null;
  const id = newId('ar');
  db.insert('access_requests', { id, email, name: input.name.trim(), note: input.note?.trim() || null, lang: input.lang ?? null, status: 'pending', created_at: clock.iso() });
  return { id, name: input.name.trim() };
}

/** Open requests for the owner: waiting for a decision, or approved with a link nobody has used yet. */
export function listAccessRequests(db: Db) {
  return db.all<AccessRow & { has_account: number }>(
    `SELECT a.id, a.email, a.name, a.note, a.status, a.created_at, a.expires_at,
            EXISTS (SELECT 1 FROM users u WHERE lower(u.email) = lower(a.email)) has_account
       FROM access_requests a WHERE a.status IN ('pending', 'approved') ORDER BY a.created_at DESC LIMIT 100`,
  ).map((a) => ({ id: a.id, email: a.email, name: a.name, note: a.note, status: a.status, createdAt: a.created_at, expiresAt: a.expires_at, linkExpired: a.status === 'approved' && !!a.expires_at && a.expires_at < clock.iso(), hasAccount: !!a.has_account }));
}

const openRequest = (db: Db, id: string) => {
  const a = db.get<AccessRow>("SELECT * FROM access_requests WHERE id = ? AND status IN ('pending', 'approved')", id);
  if (!a) throw new AppError(404, 'not_found', 'This request was already handled');
  return a;
};

/** Approve (or send a fresh link for an approved one): returns the token for the email. */
export function approveAccess(db: Db, id: string): { token: string; request: AccessRow } {
  const a = openRequest(db, id);
  if (db.get('SELECT 1 FROM users WHERE lower(email) = lower(?)', a.email)) throw new AppError(409, 'email_taken', 'This address already has an account');
  const token = randomBytes(32).toString('base64url');
  db.run("UPDATE access_requests SET status = 'approved', token_hash = ?, decided_at = ?, expires_at = ? WHERE id = ?", sha(token), clock.iso(), later(ACCESS_DAYS * 86_400_000), id);
  return { token, request: a };
}

export function declineAccess(db: Db, id: string) {
  openRequest(db, id);
  db.run("UPDATE access_requests SET status = 'declined', token_hash = NULL, decided_at = ? WHERE id = ?", clock.iso(), id);
}

const approvedFor = (db: Db, token: string) => {
  const a = db.get<AccessRow>("SELECT * FROM access_requests WHERE token_hash = ? AND status = 'approved'", sha(token));
  return a && a.expires_at && a.expires_at >= clock.iso() ? a : null;
};

/** What the sign-up form shows for an approval link (the email is fixed), or null when it no longer works. */
export function accessLink(db: Db, token: string): { email: string; name: string } | null {
  const a = approvedFor(db, token);
  return a ? { email: a.email, name: a.name } : null;
}

/** Make the account from an approval link: always the approved address, in a household of its own. Works once. */
export function finishAccess(db: Db, token: string, input: { password: string; name: string }, createHousehold: (name: string) => string): SessionUser {
  const a = approvedFor(db, token);
  if (!a) throw accessExpired();
  const user = registerUser(db, { email: a.email, password: input.password, name: input.name }, createHousehold);
  db.run("UPDATE access_requests SET status = 'used', used_at = ?, token_hash = NULL WHERE id = ?", clock.iso(), a.id);
  db.run("UPDATE access_requests SET status = 'used' WHERE lower(email) = lower(?) AND status IN ('pending', 'approved')", a.email);
  db.run('DELETE FROM pending_signups WHERE lower(email) = lower(?)', a.email);
  return user;
}
