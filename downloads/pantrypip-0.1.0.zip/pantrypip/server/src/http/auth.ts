// Password hashing (scrypt) and cookie sessions. Session tokens are stored hashed.
import { randomBytes, scryptSync, timingSafeEqual, createHash } from 'node:crypto';
import type { Db } from '../db/db.ts';
import { newId } from '../db/db.ts';
import { clock } from '../clock.ts';
import { AppError } from '../errors.ts';

const SESSION_DAYS = 120; // long-lived so the app opens straight into "say it and go"
export const COOKIE = 'larder_session';

export function hashPassword(pw: string): string {
  const salt = randomBytes(16);
  const hash = scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$${salt.toString('base64')}$${hash.toString('base64')}`;
}

export function verifyPassword(pw: string, stored: string): boolean {
  const [alg, saltB64, hashB64] = stored.split('$');
  if (alg !== 'scrypt') return false;
  const expected = Buffer.from(hashB64, 'base64');
  const actual = scryptSync(pw, Buffer.from(saltB64, 'base64'), expected.length, { N: 16384, r: 8, p: 1 });
  return timingSafeEqual(expected, actual);
}

const sha = (s: string) => createHash('sha256').update(s).digest('hex');

export function createSession(db: Db, userId: string): { token: string; expires: Date } {
  const token = randomBytes(32).toString('base64url');
  const expires = new Date(clock.now().getTime() + SESSION_DAYS * 86_400_000);
  db.insert('sessions', { token_hash: sha(token), user_id: userId, expires_at: expires.toISOString(), created_at: clock.iso() });
  return { token, expires };
}

export interface SessionUser {
  id: string;
  household_id: string;
  email: string;
  name: string;
}

export function userForToken(db: Db, token: string | undefined): SessionUser | null {
  if (!token) return null;
  const row = db.get<SessionUser & { expires_at: string }>(
    'SELECT u.id, u.household_id, u.email, u.name, s.expires_at FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?',
    sha(token),
  );
  if (!row || row.expires_at < clock.iso()) return null;
  return { id: row.id, household_id: row.household_id, email: row.email, name: row.name };
}

export function destroySession(db: Db, token: string | undefined) {
  if (token) db.run('DELETE FROM sessions WHERE token_hash = ?', sha(token));
}

// Simple in-memory brute-force protection for sign-in.
const attempts = new Map<string, { n: number; until: number }>();
export function checkRateLimit(key: string) {
  const a = attempts.get(key);
  if (a && a.until > Date.now() && a.n >= 8) throw new AppError(429, 'rate_limited', 'Too many attempts. Try again in a few minutes.');
}
export function recordFailure(key: string) {
  const a = attempts.get(key);
  if (!a || a.until < Date.now()) attempts.set(key, { n: 1, until: Date.now() + 10 * 60_000 });
  else a.n++;
}
export function clearFailures(key: string) {
  attempts.delete(key);
}

export function registerUser(db: Db, input: { email: string; password: string; name: string; inviteCode?: string | null; householdName?: string | null }, createHousehold: (name: string) => string): SessionUser {
  if (db.get('SELECT 1 FROM users WHERE email = ?', input.email)) throw new AppError(409, 'email_taken', 'An account with this email already exists');
  let householdId: string;
  if (input.inviteCode) {
    const h = db.get<{ id: string }>('SELECT id FROM households WHERE invite_code = ?', input.inviteCode.trim().toUpperCase());
    if (!h) throw new AppError(404, 'invalid_invite', 'Invite code not found');
    householdId = h.id;
  } else householdId = createHousehold(input.householdName || `${input.name}'s household`);
  const id = newId('u');
  db.insert('users', { id, household_id: householdId, email: input.email.trim(), name: input.name.trim(), password_hash: hashPassword(input.password), created_at: clock.iso() });
  return { id, household_id: householdId, email: input.email, name: input.name };
}
