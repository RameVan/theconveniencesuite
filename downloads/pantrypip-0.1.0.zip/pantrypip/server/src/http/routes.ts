import * as z from 'zod/v4';
import type { Db } from '../db/db.ts';
import { parseJson } from '../db/db.ts';
import { clock, addDays } from '../clock.ts';
import { config } from '../config.ts';
import { log } from '../log.ts';
import { AppError, badRequest, notFound } from '../errors.ts';
import { bus } from '../bus.ts';
import { Router, validate, reply, sessionCookie, clearCookie, isHttps, type Req } from './server.ts';
import { createSession, destroySession, verifyPassword, registerUser, checkRateLimit, recordFailure, clearFailures, COOKIE, startSignup, confirmSignup, startReset, finishReset, resetValid, resolveInvite, requestAccess, listAccessRequests, approveAccess, declineAccess, accessLink, finishAccess } from './auth.ts';
import { sendMail, linkMail } from '../mail.ts';
import { isOwner, testState, startTest, stopTest, setTestTime, unlockEverything, resetProgress, ownerCheck } from '../domain/testmode.ts';
import { createHousehold } from '../db/seed.ts';
import { listProducts, getProduct, createProduct, updateProduct, matchProducts, resolveProduct, displayName, createCustomType, suggestProducts, resolveList } from '../domain/products.ts';
import { addStock, deduct, setLotQuantity, moveLot, newCtx, undoBatch, verifyLedger, batchExists, eventsForBatch, getLot, type EventSource } from '../domain/ledger.ts';
import { inventorySummary, stockItem, correctQuantity, recentEvents } from '../domain/inventory.ts';
import { toBase, UnitError, formatQty } from '../domain/units.ts';
import { handleUtterance, undoTurnBatch, recipesForFilters, greet } from '../assistant/engine.ts';
import { checkinSettings, pendingCheckins, answerCheckin } from '../domain/checkins.ts';
import { createToken, listTokens, deleteToken, tokenUser, rememberConversation, spokenReply } from './shortcut.ts';
import { ALLERGENS, DIETS, dietaryNeeds, getPeople, savePeople, productConflicts } from '../domain/dietary.ts';
import { vapidPublicKey, saveSubscription, removeSubscription, pushToHousehold } from '../push.ts';
import { parse } from '../assistant/parser.ts';
import { readBoughtList } from '../assistant/list.ts';
import { proposeWeek, applyPlan, autoPlanPrefs, favouriteFoodOptions, swapSlot, slotOptions, chooseForSlot } from '../domain/autoplan.ts';
import { learnedProfile, dismissedInsights } from '../domain/learn.ts';
import { game, rewardFor, CHALLENGES, ACCENTS, DEFAULT_XP, levelFor, RANKS } from '../domain/game.ts';
import { notificationPrefs, interactionPrefs, MEAL_TYPES } from '../domain/personal.ts';
import { readSettings, patchSettings } from '../domain/settings.ts';
import { journey, evaluateJourney, describeNode, markCelebrated, swapTask, setCompanion, collection } from '../domain/journey.ts';
import { WIDGETS, WIDGET_TYPES, PRESETS, getDashboard, saveDashboard, dashboardData, dashboardSuggestions, dismissSuggestion, recordUsage, defaultConfig } from '../domain/dashboard.ts';
import { settleSocial, playState, sendCheer, setNudges, markSeen, createDuel, answerDuel, passRecipe, answerPass, createGroup, answerGroup } from '../domain/social-play.ts';
import { friendsState, setPrivacy, friendsOverview, resetFriendCode, requestFriend, requestByContact, acceptRequest, dropRequest, removeFriend, incomingCount, myPhone, setMyPhone, setDiscoverable, removeMyPhone, matchContacts } from '../domain/social.ts';
import { userChannel, createSharedList, inviteToList, answerInvite, removeMember, renameSharedList, deleteSharedList, sharedListsFor, getSharedList, addSharedItem, updateSharedItem, removeSharedItem, finishSharedList, clearBought, MAX_MEMBERS } from '../domain/shared-lists.ts';
import { targetsFor } from '../domain/targets.ts';
import { mealScore } from '../domain/health.ts';
import { mkdirSync, writeFileSync, readFileSync, existsSync } from 'node:fs';
import path from 'node:path';
import { draftFromUrl, draftFromText } from '../domain/recipe-import.ts';
import { draftFromPhotoText } from '../domain/photo-recipe.ts';
import { parseReceiptText, createDraft, getDraft, commitReceipt, listReceipts, discardDraft } from '../domain/receipts.ts';
import { lookupBarcode, linkBarcode, validBarcode } from '../domain/barcode.ts';
import { searchCatalogue, useCatalogueItem } from '../domain/catalogue.ts';
import { listShopping, addShoppingItem, updateShoppingItem, removeShoppingItem, completeTrip, shoppingSuggestions, recordFeedback, syncPlanToShopping } from '../domain/shopping.ts';
import { weekPlan, addSlot, updateSlot, removeSlot, getSlot, todaysMeals, clearPlan, restoreSlots, setSlotSwap, slotSwaps, planRequirements, planHorizonDays } from '../domain/planner.ts';
import { recipeFromSentence, recipeFromStock } from '../domain/quick-recipe.ts';
import { ingredientDetail, shopLinks, reviewList, familyPrefs, countryOptions, countryAt, reassignLot } from '../domain/ingredients.ts';
import { setChoice } from '../domain/substitutions.ts';
import { familyById } from '../domain/ingredient-match.ts';
import { searchRecipes, listRecipes, getRecipe, matchRecipe, stockMap, suitabilityFor, createRecipe, cookRecipe, recordInteraction, recipePreferences, useLeftover, setRetention, updateRecipe, copyRecipe } from '../domain/recipes.ts';
import { analytics } from '../domain/analytics.ts';
import { funStats, type Period } from '../domain/funstats.ts';
import { ai } from '../ai/ai.ts';
import { CATEGORY_LABELS } from '../db/catalogue.ts';

const hid = (r: Req) => r.user!.household_id;
const num = z.number().finite();
const pos = num.positive();
const clientRequestId = z.string().min(6).max(80).optional().nullable();
const location = z.string().max(60).optional().nullable();
const dateStr = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);

function ctxFor(db: Db, r: Req, source: EventSource, crid?: string | null) {
  return newCtx(db, hid(r), source, { userId: r.user!.id, clientRequestId: crid });
}

/** Run a ledger mutation once per client request id; a retry returns the original events. */
function once<T>(db: Db, r: Req, source: EventSource, crid: string | null | undefined, fn: (ctx: ReturnType<typeof ctxFor>) => T) {
  const ctx = ctxFor(db, r, source, crid);
  if (crid && batchExists(db, ctx.batchId)) return { duplicate: true, batchId: ctx.batchId, events: eventsForBatch(db, ctx.batchId) };
  const result = db.tx(() => fn(ctx));
  return { duplicate: false, batchId: ctx.batchId, result };
}

export function buildRoutes(db: Db, opts: { emailConfirm?: boolean; inviteOnly?: boolean } = {}): Router {
  const r = new Router();

  // ---------- System ----------
  r.get('/api/health', () => ({ ok: true, time: clock.iso(), ai: ai.enabled() }), { auth: false });
  r.get('/api/config', () => ({ ai: ai.enabled(), aiModel: ai.enabled() ? ai.model() : null, barcodeLookup: config.offLookup, categories: CATEGORY_LABELS, inviteOnly: !!opts.inviteOnly }), { auth: false });

  // ---------- Auth ----------
  r.post('/api/auth/login', (req) => {
    const b = validate(z.object({ email: z.string().email(), password: z.string().min(1).max(200) }), req.body);
    const key = `${req.ip}:${b.email.toLowerCase()}`;
    checkRateLimit(key);
    const u = db.get<{ id: string; password_hash: string }>('SELECT id, password_hash FROM users WHERE lower(email) = lower(?)', b.email);
    if (!u || !verifyPassword(b.password, u.password_hash)) {
      recordFailure(key);
      throw new AppError(401, 'invalid_credentials', 'Email or password is incorrect');
    }
    clearFailures(key);
    const s = createSession(db, u.id);
    db.insert('audit_log', { user_id: u.id, action: 'login', created_at: clock.iso() });
    return reply({ body: { ok: true }, cookies: [sessionCookie(s.token, s.expires, config.cookieSecure || isHttps(req.raw))] });
  }, { auth: false });
  /** Tells the owner of a public copy that someone signed up (name only; nothing else leaves the account). */
  const alertNewSignup = (name: string, joined: boolean) => {
    if (!config.signupAlertEmail) return;
    const owner = db.get<{ household_id: string }>('SELECT household_id FROM users WHERE lower(email) = ?', config.signupAlertEmail);
    if (!owner) return;
    const total = db.get<{ n: number }>('SELECT count(*) n FROM users')?.n ?? 0;
    pushToHousehold(db, owner.household_id, { title: 'New PantryPip account', body: `${name} ${joined ? 'joined a household' : 'signed up'} · ${total} accounts now`, tag: 'signup' })
      .catch((e) => log.warn('signup alert failed', { err: e?.message }));
  };
  const signupSchema = z.object({ email: z.string().email(), password: z.string().min(10).max(200), name: z.string().min(1).max(60), inviteCode: z.string().trim().max(300).optional().nullable(), householdName: z.string().max(60).optional().nullable(), lang: z.enum(['en', 'nl']).optional() });
  const signIn = (req: Req, userId: string, status = 200, body: unknown = { ok: true }) => {
    const s = createSession(db, userId);
    return reply({ status, body, cookies: [sessionCookie(s.token, s.expires, config.cookieSecure || isHttps(req.raw))] });
  };
  // Sign-up: the account is only made once the link in the email is opened. The answer is the same whether
  // or not the address already has an account (that person gets a "you already have one" email instead).
  r.post('/api/auth/register', async (req) => {
    const b = validate(signupSchema, req.body);
    const nl = b.lang === 'nl';
    // Invite only: a household's code, or a friend's code or link. Wrong codes count as failed attempts (they're guessable only by trying).
    if (opts.inviteOnly && !b.inviteCode) throw new AppError(403, 'invite_required', 'PantryPip is invite only: ask someone who uses it for their invite link or code');
    if (b.inviteCode) {
      checkRateLimit(`invite:${req.ip}`);
      if (!resolveInvite(db, b.inviteCode)) {
        recordFailure(`invite:${req.ip}`);
        throw new AppError(404, 'invalid_invite', 'Invite code not found');
      }
    }
    if (!opts.emailConfirm) {
      const joined = !!b.inviteCode && resolveInvite(db, b.inviteCode)?.kind === 'household';
      const u = db.tx(() => registerUser(db, b, (name) => createHousehold(db, name)));
      alertNewSignup(u.name, joined);
      return signIn(req, u.id, 201);
    }
    checkRateLimit(`signup:${req.ip}`);
    recordFailure(`signup:${req.ip}`);
    const token = db.tx(() => startSignup(db, b));
    if (token) {
      await sendMail(linkMail(b.email, nl ? 'Bevestig je PantryPip-account' : 'Confirm your PantryPip account',
        nl ? `Hoi ${b.name}, bevestig je e-mailadres om je PantryPip-account te maken.` : `Hi ${b.name}, confirm your email address to create your PantryPip account.`,
        nl ? 'Account bevestigen' : 'Confirm my account', `${config.publicUrl}/#/confirm/${token}`,
        nl ? 'De link werkt 48 uur. Heb je dit niet aangevraagd? Dan kun je deze mail negeren.' : "The link works for 48 hours. Didn't sign up? You can ignore this email."));
    } else {
      const reset = startReset(db, b.email);
      if (reset) await sendMail(linkMail(reset.user.email, nl ? 'Je hebt al een PantryPip-account' : 'You already have a PantryPip account',
        nl ? 'Iemand probeerde een account te maken met dit e-mailadres, maar je hebt er al een. Wachtwoord vergeten? Kies hier een nieuw.' : 'Someone tried to sign up with this email address, but you already have an account. Forgot your password? Choose a new one here.',
        nl ? 'Nieuw wachtwoord kiezen' : 'Choose a new password', `${config.publicUrl}/#/reset/${reset.token}`,
        nl ? 'De link werkt een uur. Was jij dit niet? Dan hoef je niets te doen.' : "The link works for an hour. Wasn't you? You don't need to do anything."));
    }
    return reply({ status: 202, body: { ok: true, confirm: true } });
  }, { auth: false });
  r.post('/api/auth/confirm', (req) => {
    const b = validate(z.object({ token: z.string().min(20).max(100) }), req.body);
    const { user, joined } = db.tx(() => confirmSignup(db, b.token, (name) => createHousehold(db, name)));
    alertNewSignup(user.name, joined);
    return signIn(req, user.id, 201);
  }, { auth: false });
  // Forgot password: always "check your email", so nobody can find out which addresses have an account.
  r.post('/api/auth/forgot', async (req) => {
    const b = validate(z.object({ email: z.string().email(), lang: z.enum(['en', 'nl']).optional() }), req.body);
    const nl = b.lang === 'nl';
    checkRateLimit(`forgot:${req.ip}`);
    recordFailure(`forgot:${req.ip}`);
    const reset = startReset(db, b.email);
    if (reset) await sendMail(linkMail(reset.user.email, nl ? 'Nieuw wachtwoord voor PantryPip' : 'Reset your PantryPip password',
      nl ? `Hoi ${reset.user.name}, kies hier een nieuw wachtwoord voor PantryPip.` : `Hi ${reset.user.name}, choose a new password for PantryPip here.`,
      nl ? 'Nieuw wachtwoord kiezen' : 'Choose a new password', `${config.publicUrl}/#/reset/${reset.token}`,
      nl ? 'De link werkt een uur. Heb je dit niet aangevraagd? Dan blijft je wachtwoord gewoon hetzelfde.' : "The link works for an hour. Didn't ask for this? Your password stays as it is."));
    return { ok: true };
  }, { auth: false });
  // The token goes in the body, not the path, so it never lands in request logs.
  r.post('/api/auth/reset/check', (req) => ({ valid: resetValid(db, validate(z.object({ token: z.string().min(20).max(100) }), req.body).token) }), { auth: false });
  r.post('/api/auth/reset', (req) => {
    const b = validate(z.object({ token: z.string().min(20).max(100), password: z.string().min(10).max(200) }), req.body);
    const userId = db.tx(() => finishReset(db, b.token, b.password));
    db.insert('audit_log', { user_id: userId, action: 'password_reset', created_at: clock.iso() });
    return signIn(req, userId);
  }, { auth: false });

  // ---------- Request access (invite-only copies) ----------
  // The answer is always the same, so nobody learns whether an address has an account or an open request.
  r.post('/api/auth/access-request', (req) => {
    const b = validate(z.object({ email: z.string().trim().email().max(200), name: z.string().trim().min(1).max(60), note: z.string().trim().max(300).optional().nullable(), lang: z.enum(['en', 'nl']).optional() }), req.body);
    checkRateLimit(`access:${req.ip}`);
    recordFailure(`access:${req.ip}`);
    const made = db.tx(() => requestAccess(db, b));
    const owner = made && config.ownerEmail ? db.get<{ id: string; household_id: string }>('SELECT id, household_id FROM users WHERE lower(email) = ?', config.ownerEmail) : null;
    if (made && owner) {
      pushToHousehold(db, owner.household_id, { title: 'PantryPip access request', body: `${made.name} would like an account`, tag: 'access-request', url: '/#/settings/account' }, owner.id)
        .catch((e) => log.warn('access request alert failed', { err: e?.message }));
    }
    return reply({ status: 202, body: { ok: true } });
  }, { auth: false });
  const ownerOnly = (req: Req) => {
    if (!isOwner(req.user!)) throw new AppError(403, 'owner_only', 'Only the owner can handle access requests');
  };
  r.get('/api/access-requests', (req) => (ownerOnly(req), { requests: listAccessRequests(db) }));
  r.post('/api/access-requests/:id/approve', async (req) => {
    ownerOnly(req);
    const { token, request: a } = db.tx(() => approveAccess(db, req.params.id));
    const nl = a.lang === 'nl';
    const sent = await sendMail(linkMail(a.email, nl ? 'Je kunt nu een PantryPip-account maken' : 'You can now create a PantryPip account',
      nl ? `Hoi ${a.name}, je aanvraag voor PantryPip is goedgekeurd. Maak hier je account.` : `Hi ${a.name}, your request for PantryPip was approved. Create your account here.`,
      nl ? 'Account maken' : 'Create my account', `${config.publicUrl}/#/access/${token}`,
      nl ? 'De link werkt 7 dagen en één keer.' : 'The link works once, for 7 days.'));
    db.insert('audit_log', { user_id: req.user!.id, action: 'access_approved', created_at: clock.iso() });
    return { ok: true, sent };
  });
  r.post('/api/access-requests/:id/decline', (req) => {
    ownerOnly(req);
    db.tx(() => declineAccess(db, req.params.id));
    db.insert('audit_log', { user_id: req.user!.id, action: 'access_declined', created_at: clock.iso() });
    return { ok: true };
  });
  // The approval link: the token travels in the body (never in request logs), the email comes from the request.
  const accessToken = z.object({ token: z.string().min(20).max(100) });
  r.post('/api/auth/access/check', (req) => {
    const link = accessLink(db, validate(accessToken, req.body).token);
    return link ? { valid: true, ...link } : { valid: false };
  }, { auth: false });
  r.post('/api/auth/access', (req) => {
    const b = validate(accessToken.extend({ password: z.string().min(10).max(200), name: z.string().trim().min(1).max(60) }), req.body);
    const user = db.tx(() => finishAccess(db, b.token, b, (name) => createHousehold(db, name)));
    alertNewSignup(user.name, false);
    return signIn(req, user.id, 201);
  }, { auth: false });
  r.post('/api/auth/logout', (req) => {
    destroySession(db, req.cookies[COOKIE]);
    return reply({ body: { ok: true }, cookies: [clearCookie()] });
  }, { auth: false });
  r.get('/api/me', (req) => {
    const h = db.get('SELECT id, name, invite_code, locale FROM households WHERE id = ?', hid(req));
    const members = db.all('SELECT id, name, email FROM users WHERE household_id = ?', hid(req));
    return { user: req.user, owner: isOwner(req.user!), test: testState(db, hid(req)), household: h, members, locations: db.all('SELECT * FROM storage_locations WHERE household_id = ? ORDER BY sort', hid(req)) };
  });

  // ---------- Progress reset (anyone) and test mode (owner only) ----------
  r.post('/api/progress/reset', (req) => {
    validate(z.object({ confirm: z.literal('RESET') }), req.body);
    db.insert('audit_log', { user_id: req.user!.id, action: 'progress_reset', created_at: clock.iso() });
    return resetProgress(db, hid(req));
  });
  r.get('/api/test', (req) => {
    ownerCheck(req.user!);
    return testState(db, hid(req));
  });
  r.post('/api/test/start', (req) => startTest(db, req.user!));
  r.post('/api/test/stop', (req) => stopTest(db, req.user!));
  r.post('/api/test/time', (req) => setTestTime(db, req.user!, validate(z.object({ days: z.number().int().min(-3650).max(3650) }), req.body).days));
  r.post('/api/test/unlock', (req) => unlockEverything(db, req.user!));
  // Test accounts skip email confirmation. They're real accounts, in their own household (or yours with your invite code).
  r.post('/api/test/accounts', (req) => {
    ownerCheck(req.user!);
    const b = validate(z.object({ email: z.string().email(), password: z.string().min(10).max(200), name: z.string().min(1).max(60), joinMine: z.boolean().optional() }), req.body);
    const invite = b.joinMine ? db.get<{ invite_code: string }>('SELECT invite_code FROM households WHERE id = ?', hid(req))?.invite_code : null;
    const u = db.tx(() => registerUser(db, { ...b, inviteCode: invite }, (name) => createHousehold(db, name)));
    db.insert('audit_log', { user_id: req.user!.id, action: 'test_account', created_at: clock.iso() });
    return reply({ status: 201, body: { id: u.id, email: u.email, name: u.name } });
  });

  // ---------- Live updates (Server-Sent Events) ----------
  r.get('/api/stream', (req) => {
    const res = req.res;
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
    res.write(`event: hello\ndata: {}\n\n`);
    const send = (scopes: string[]) => res.write(`event: changed\ndata: ${JSON.stringify({ scopes })}\n\n`);
    // Your household's changes, and your own (shared lists span households, so they're sent per person).
    const unsub = bus.subscribe(hid(req), send);
    const unsubMe = bus.subscribe(userChannel(req.user!.id), send);
    const ping = setInterval(() => res.write(`: ping\n\n`), 25_000);
    req.raw.on('close', () => {
      clearInterval(ping);
      unsub();
      unsubMe();
    });
  });

  // ---------- Home ----------
  r.get('/api/home', (req) => {
    const h = hid(req);
    const { items, leftovers } = inventorySummary(db, h);
    const expiring = items.filter((s) => s.daysToExpiry != null && s.daysToExpiry <= 3 && s.confirmed > 0).sort((a, b) => a.daysToExpiry! - b.daysToExpiry!);
    const low = items.filter((s) => (s.status === 'low' || s.status === 'out') && !s.product.staple);
    const suggestions = shoppingSuggestions(db, h);
    syncPlanToShopping(db, h, { quiet: true });
    const shopping = listShopping(db, h);
    const cookNow = searchRecipes(db, h, { limit: 4 });
    const today = todaysMeals(db, h);
    const recent = recentEvents(db, h, 8);
    const stats = analytics(db, h, 30);
    return {
      expiring: expiring.slice(0, 8),
      low: low.slice(0, 8),
      leftovers,
      suggestions: suggestions.slice(0, 6),
      shoppingCount: shopping.count,
      cookNow: cookNow.map(slimMatch),
      today,
      recent,
      stats: { items: items.filter((s) => s.confirmed > 0).length, spent30: stats.spent, wasted30: stats.wasted },
      plannedNext7: db.get<{ n: number }>("SELECT COUNT(DISTINCT date) n FROM meal_slots WHERE household_id = ? AND meal = 'dinner' AND status != 'skipped' AND date BETWEEN ? AND ?", h, clock.today(), addDays(clock.today(), 6))!.n,
    };
  });

  // ---------- Products ----------
  r.get('/api/products', (req) => {
    const q = req.query.get('q');
    if (q) return matchProducts(db, hid(req), q, 12).map((c) => ({ ...c.product, score: c.score }));
    return listProducts(db, hid(req));
  });
  // Type-ahead while typing a product name; and a typed list ("olives, mushrooms and coriander") at once.
  const brief = (p: { id: string; name: string; name_nl: string | null }, lang: 'en' | 'nl') => ({ id: p.id, name: displayName(p, lang) });
  const langOf = (req: any): 'en' | 'nl' => (req.query.get('lang') === 'nl' ? 'nl' : 'en');
  r.get('/api/products/suggest', (req) => suggestProducts(db, hid(req), (req.query.get('q') ?? '').slice(0, 60)).map((p) => brief(p, langOf(req))));
  r.post('/api/products/resolve-list', (req) => {
    const b = validate(z.object({ text: z.string().min(1).max(600) }), req.body);
    return resolveList(db, hid(req), b.text).map((x) => ({ term: x.term, product: x.product && brief(x.product, langOf(req)) }));
  });
  // Branded products sold in your country (Open Food Facts), to pick from when adding something.
  r.get('/api/catalogue', (req) => searchCatalogue(db, hid(req), req.query.get('q') ?? ''));
  r.post('/api/catalogue/:ean/use', (req) => db.tx(() => useCatalogueItem(db, hid(req), req.params.ean)));
  r.get('/api/products/:id', (req) => {
    const p = getProduct(db, req.params.id);
    if (!p || (p.household_id && p.household_id !== hid(req))) throw notFound('Product');
    const purchases = db.all('SELECT purchased_at, quantity, packages, total_price, store, source FROM purchases WHERE household_id = ? AND product_id = ? ORDER BY purchased_at DESC LIMIT 30', hid(req), p.id);
    return { product: p, stock: stockItem(db, hid(req), p.id), purchases, events: recentEvents(db, hid(req), 30, p.id) };
  });
  const productInput = z.object({
    name: z.string().min(1).max(120), name_nl: z.string().max(120).optional().nullable(), brand: z.string().max(80).optional().nullable(), category: z.string().max(30).optional(),
    barcode: z.string().max(20).optional().nullable(), unit: z.enum(['g', 'ml', 'pcs']).optional(), package_size: pos.optional(), piece_size: pos.optional().nullable(),
    price: num.min(0).optional().nullable(), preferred_store: z.string().max(60).optional().nullable(), default_location: z.string().max(30).optional(), shelf_life_days: z.number().int().min(0).optional().nullable(),
    synonyms: z.array(z.string().max(60)).max(30).optional(),
  });
  r.post('/api/products', (req) => createProduct(db, hid(req), validate(productInput, req.body)));
  r.patch('/api/products/:id', (req) => {
    const p = updateProduct(db, hid(req), req.params.id, validate(productInput.partial(), req.body));
    if (!p) throw notFound('Product');
    bus.touch(hid(req), 'inventory');
    return p;
  });

  // ---------- Inventory ----------
  r.get('/api/inventory', (req) => {
    const { items, leftovers } = inventorySummary(db, hid(req));
    const loc = req.query.get('location');
    return { items: loc ? items.filter((s) => s.lots.some((l) => l.location_kind === loc || l.location_id === loc)) : items, leftovers, locations: db.all('SELECT * FROM storage_locations WHERE household_id = ? ORDER BY sort', hid(req)) };
  });
  r.get('/api/inventory/events', (req) => recentEvents(db, hid(req), Math.min(200, Number(req.query.get('limit') ?? 50)), req.query.get('productId') ?? undefined));
  r.get('/api/inventory/verify', (req) => verifyLedger(db, hid(req)));

  function resolveForInput(req: Req, b: { productId?: string | null; name?: string | null }) {
    if (b.productId) {
      const p = getProduct(db, b.productId);
      if (!p || (p.household_id && p.household_id !== hid(req))) throw notFound('Product');
      return p;
    }
    if (b.name) {
      const { product } = resolveProduct(db, hid(req), b.name);
      return product ?? createProduct(db, hid(req), { name: b.name });
    }
    throw badRequest('productId or name is required');
  }
  function qtyFrom(p: { unit: 'g' | 'ml' | 'pcs'; package_size: number; piece_size?: number | null }, amount: number, unit?: string | null) {
    try {
      return toBase(amount, unit ?? null, p).qty;
    } catch (e) {
      if (e instanceof UnitError) throw badRequest(e.message);
      throw e;
    }
  }

  r.post('/api/inventory/add', (req) => {
    const b = validate(z.object({ productId: z.string().optional().nullable(), name: z.string().max(120).optional().nullable(), quantity: pos.optional(), unit: z.string().max(20).optional().nullable(), packages: pos.optional(), location, expiresOn: dateStr.optional().nullable(), price: num.min(0).optional().nullable(), source: z.enum(['manual', 'barcode', 'device', 'online_order']).optional(), clientRequestId }), req.body);
    const p = resolveForInput(req, b);
    const qty = b.quantity != null ? (b.unit ? qtyFrom(p, b.quantity, b.unit) : b.quantity) : (b.packages ?? 1) * p.package_size;
    return once(db, req, b.source ?? 'manual', b.clientRequestId, (ctx) => {
      const out = addStock(ctx, { productId: p.id, quantity: qty, location: b.location, expiresOn: b.expiresOn, totalPrice: b.price ?? null, packages: qty / p.package_size });
      const listed = db.get<{ id: string }>('SELECT id FROM shopping_items WHERE household_id = ? AND product_id = ? AND checked = 0', ctx.householdId, p.id);
      if (listed) removeShoppingItem(db, ctx.householdId, listed.id);
      return { lot: out.lot, product: p, label: `${displayName(p, 'en')} +${formatQty(qty, p.unit)}` };
    });
  });
  // A whole list of things bought at once (list mode): one batch, so one undo removes it all.
  r.post('/api/inventory/add-many', (req) => {
    const line = z.object({ productId: z.string().optional().nullable(), name: z.string().min(1).max(120).optional().nullable(), quantity: pos.optional(), location });
    const b = validate(z.object({ items: z.array(line).min(1).max(60), source: z.enum(['manual', 'voice']).default('voice'), clientRequestId }), req.body);
    const products = b.items.map((it) => resolveForInput(req, it));
    return once(db, req, b.source, b.clientRequestId, (ctx) => {
      const labels = b.items.map((it, i) => {
        const p = products[i];
        const qty = it.quantity ?? p.package_size;
        addStock(ctx, { productId: p.id, quantity: qty, location: it.location, packages: qty / p.package_size });
        const listed = db.get<{ id: string }>('SELECT id FROM shopping_items WHERE household_id = ? AND product_id = ? AND checked = 0', ctx.householdId, p.id);
        if (listed) removeShoppingItem(db, ctx.householdId, listed.id);
        return `${displayName(p, 'en')} +${formatQty(qty, p.unit)}`;
      });
      return { count: labels.length, labels };
    });
  });
  r.post('/api/inventory/consume', (req) => {
    const b = validate(z.object({ productId: z.string().optional().nullable(), lotId: z.string().optional().nullable(), name: z.string().optional().nullable(), quantity: z.union([pos, z.literal('all')]), unit: z.string().max(20).optional().nullable(), type: z.enum(['consume', 'discard']).default('consume'), reason: z.string().max(40).optional().nullable(), clientRequestId }), req.body);
    let productId = b.productId ?? null;
    let qty: number | 'all' = b.quantity;
    if (b.lotId) {
      const lot = getLot(db, b.lotId);
      if (!lot || lot.household_id !== hid(req)) throw notFound('Inventory item');
      productId = lot.product_id;
      if (qty !== 'all' && b.unit && lot.product_id) qty = qtyFrom(getProduct(db, lot.product_id)!, qty, b.unit);
    } else {
      const p = resolveForInput(req, b);
      productId = p.id;
      if (qty !== 'all' && b.unit) qty = qtyFrom(p, qty, b.unit);
    }
    return once(db, req, 'manual', b.clientRequestId, (ctx) => deduct(ctx, { productId: b.lotId ? null : productId, lotId: b.lotId ?? null, quantity: qty, type: b.type, reason: b.type === 'discard' ? b.reason ?? 'other' : null }));
  });
  // Select mode on In stock: take many products out at once. One batch, so one undo puts them all back.
  // 'remove' is a correction (it wasn't there), 'consume' is used up, 'discard' is thrown away.
  r.post('/api/inventory/remove-many', (req) => {
    const b = validate(z.object({ productIds: z.array(z.string().min(1).max(60)).min(1).max(300), type: z.enum(['remove', 'consume', 'discard']).default('remove'), reason: z.string().max(40).optional().nullable(), clientRequestId }), req.body);
    const ids = [...new Set(b.productIds)];
    return once(db, req, 'manual', b.clientRequestId, (ctx) => {
      let count = 0;
      for (const productId of ids) {
        // activeLots is scoped to the household, so another household's product id simply removes nothing.
        const res = deduct(ctx, { productId, quantity: 'all', type: b.type === 'remove' ? 'adjust' : b.type, reason: b.type === 'discard' ? b.reason ?? 'other' : b.type === 'remove' ? 'removed' : null });
        if (res.events.length) count++;
      }
      return { count };
    });
  });
  r.post('/api/inventory/set', (req) => {
    const b = validate(z.object({ productId: z.string(), quantity: num.min(0), unit: z.string().max(20).optional().nullable(), expectedTotal: num.optional().nullable(), clientRequestId }), req.body);
    const p = resolveForInput(req, b);
    const qty = b.unit ? qtyFrom(p, b.quantity, b.unit) : b.quantity;
    return once(db, req, 'manual', b.clientRequestId, (ctx) => correctQuantity(ctx, p.id, qty, { expectedTotal: b.expectedTotal }));
  });
  r.patch('/api/inventory/lots/:id', (req) => {
    const b = validate(z.object({ quantity: num.min(0).optional(), expectedVersion: z.number().int().optional().nullable(), expiresOn: dateStr.optional().nullable(), location, clientRequestId }), req.body);
    const lot = getLot(db, req.params.id);
    if (!lot || lot.household_id !== hid(req)) throw notFound('Inventory item');
    return once(db, req, 'manual', b.clientRequestId, (ctx) => {
      if (b.quantity != null) setLotQuantity(ctx, lot.id, b.quantity, b.expectedVersion);
      if (b.expiresOn !== undefined) db.run('UPDATE inventory_lots SET expires_on = ?, expiry_estimated = 0 WHERE id = ?', b.expiresOn, lot.id);
      if (b.location) moveLot(ctx, lot.id, b.location);
      bus.touch(ctx.householdId, 'inventory');
      return getLot(db, lot.id);
    });
  });
  // Correct a wrongly matched stock item: it was oat milk, not milk.
  r.post('/api/inventory/lots/:id/product', (req) => {
    const b = validate(z.object({ productId: z.string().max(60), clientRequestId }), req.body);
    return once(db, req, 'manual', b.clientRequestId, (ctx) => reassignLot(ctx, req.params.id, b.productId));
  });
  r.post('/api/inventory/lots/:id/move', (req) => {
    const b = validate(z.object({ to: z.string().max(60), quantity: pos.optional(), clientRequestId }), req.body);
    return once(db, req, 'manual', b.clientRequestId, (ctx) => moveLot(ctx, req.params.id, b.to, { quantity: b.quantity }));
  });
  r.post('/api/inventory/undo', (req) => {
    const b = validate(z.object({ batchId: z.string().min(3) }), req.body);
    // A batch can exist without stock changes (a meal cooked with nothing in stock), so check every place it leaves a trace.
    const known =
      db.get('SELECT 1 FROM inventory_events WHERE household_id = ? AND batch_id = ? LIMIT 1', hid(req), b.batchId) ||
      db.get('SELECT 1 FROM cook_log WHERE household_id = ? AND batch_id = ? LIMIT 1', hid(req), b.batchId) ||
      db.get('SELECT 1 FROM meal_slots WHERE household_id = ? AND cook_batch_id = ? LIMIT 1', hid(req), b.batchId);
    if (!known) throw notFound('Change');
    return db.tx(() => undoTurnBatch(db, hid(req), b.batchId, req.user!.id));
  });
  r.post('/api/leftovers/:id', (req) => {
    const b = validate(z.object({ action: z.enum(['eat', 'discard', 'freeze', 'thaw']), portions: pos.default(1), clientRequestId }), req.body);
    return once(db, req, 'manual', b.clientRequestId, (ctx) => (b.action === 'freeze' || b.action === 'thaw' ? moveLot(ctx, req.params.id, b.action === 'freeze' ? 'freezer' : 'fridge', { quantity: b.portions }) : useLeftover(ctx, req.params.id, b.action, b.portions)));
  });

  // Device / smart-home events (e.g. a Home Assistant automation with a load cell).
  r.post('/api/devices/events', (req) => {
    const token = String(req.raw.headers['x-larder-token'] ?? '');
    const h = db.get<{ household_id: string }>("SELECT household_id FROM preferences WHERE key = 'deviceToken' AND value = ?", JSON.stringify(token));
    if (!token || !h) throw new AppError(401, 'unauthorized', 'Invalid device token');
    const b = validate(z.object({ productId: z.string(), type: z.enum(['consume', 'set', 'add']), quantity: num.min(0), eventId: z.string().min(4).max(80) }), req.body);
    const ctx = newCtx(db, h.household_id, 'device', { clientRequestId: `device:${b.eventId}` });
    if (batchExists(db, ctx.batchId)) return { duplicate: true };
    db.tx(() => {
      if (b.type === 'consume') deduct(ctx, { productId: b.productId, quantity: b.quantity, type: 'consume' });
      else if (b.type === 'add') addStock(ctx, { productId: b.productId, quantity: b.quantity });
      else correctQuantity(ctx, b.productId, b.quantity);
    });
    return { ok: true, batchId: ctx.batchId };
  }, { auth: false });

  // ---------- Quick actions & preferences ----------
  const prefGet = (h: string, key: string, d: unknown) => parseJson(db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = '' AND key = ?", h, key)?.value, d);
  const prefSet = (h: string, key: string, v: unknown) => db.run("INSERT OR REPLACE INTO preferences (household_id, user_id, key, value) VALUES (?, '', ?, ?)", h, key, JSON.stringify(v));
  // ---------- Settings: the one source of truth (household + personal), validated both ways ----------
  r.get('/api/settings', (req) => readSettings(db, hid(req), req.user!.id));
  r.patch('/api/settings', (req) => {
    const out = patchSettings(db, hid(req), req.user!.id, req.body);
    bus.touch(hid(req), 'preferences');
    return out;
  });
  r.get('/api/preferences', (req) => {
    const rows = db.all<{ key: string; value: string }>("SELECT key, value FROM preferences WHERE household_id = ? AND user_id = '' AND key != 'deviceToken'", hid(req));
    const stored = Object.fromEntries(rows.map((x) => [x.key, parseJson(x.value, null)]));
    const cuisineOptions = db.all<{ c: string }>('SELECT DISTINCT cuisine c FROM recipes WHERE cuisine IS NOT NULL AND (household_id IS NULL OR household_id = ?) ORDER BY cuisine', hid(req)).map((r) => r.c);
    return { ...stored, notifications: notificationPrefs(db, hid(req)), interaction: interactionPrefs(db, hid(req)), planning: autoPlanPrefs(db, hid(req)), cuisineOptions, mealTypeOptions: MEAL_TYPES };
  });
  r.put('/api/preferences', (req) => {
    const b = validate(z.object({
      diet: z.array(z.string()).optional(), dislikes: z.array(z.string()).optional(), cuisines: z.array(z.string()).optional(), householdSize: z.number().int().min(1).max(20).optional(),
      maxWeeknightMinutes: z.number().int().min(5).max(240).optional(), language: z.enum(['en', 'nl', 'auto']).optional(), favouriteProducts: z.array(z.string()).optional(), preferredBrands: z.record(z.string(), z.string()).optional(),
      quickActions: z.array(z.object({ productId: z.string(), quantity: pos, label: z.string().max(40) })).max(12).optional(),
      // Personalisation: food, planning, nutrition, notifications, interaction.
      favouriteFoods: z.array(z.string().max(60)).max(60).optional(),
      mealTypes: z.array(z.enum(MEAL_TYPES)).max(MEAL_TYPES.length).optional(),
      maxWeekendMinutes: z.number().int().min(5).max(480).nullable().optional(),
      maxDifficulty: z.enum(['easy', 'medium', 'hard']).optional(),
      planDays: z.array(z.number().int().min(0).max(6)).max(7).optional(),
      planningDay: z.number().int().min(0).max(6).optional(),
      autoPlanFifo: z.enum(['off', 'balanced', 'strong']).optional(),
      ratingWeight: z.enum(['low', 'normal', 'high']).optional(),
      overlap: z.enum(['low', 'normal', 'high']).optional(),
      variety: z.enum(['low', 'normal', 'high']).optional(),
      budgetPerServing: z.number().min(0.5).max(50).nullable().optional(),
      newPerWeek: z.number().int().min(0).max(7).optional(),
      nutritionPriorities: z.array(z.enum(['protein', 'fibre', 'veg', 'lessSalt', 'lessSugar', 'lessSatFat'])).max(6).optional(),
      scoringSensitivity: z.enum(['gentle', 'standard', 'strict']).optional(),
      notifications: z.object({
        expiry: z.boolean(), shopping: z.boolean(), prep: z.boolean(), plan: z.boolean(), streak: z.boolean(), challenge: z.boolean(),
        frequency: z.enum(['all', 'daily', 'off']), prepTime: z.string().regex(/^\d{2}:\d{2}$/),
      }).partial().optional(),
      interaction: z.object({
        voiceFirst: z.boolean(), autoDeduct: z.boolean(), shoppingAutoComplete: z.boolean(), cookReadAloud: z.boolean(), cookHandsFree: z.boolean(), keepAwake: z.boolean(), confirmDestructive: z.boolean(),
      }).partial().optional(),
    }), req.body);
    if (b.notifications) b.notifications = { ...(prefGet(hid(req), 'notifications', {}) as object), ...b.notifications };
    if (b.interaction) b.interaction = { ...(prefGet(hid(req), 'interaction', {}) as object), ...b.interaction };
    for (const [k, v] of Object.entries(b)) if (v !== undefined) prefSet(hid(req), k, v);
    bus.touch(hid(req), 'preferences');
    return { ok: true };
  });
  r.post('/api/preferences/device-token', (req) => {
    const token = crypto.randomUUID().replaceAll('-', '');
    prefSet(hid(req), 'deviceToken', token);
    return { token };
  });
  r.get('/api/quick-actions', (req) => prefGet(hid(req), 'quickActions', []));

  // ---------- Dietary needs ----------
  r.get('/api/dietary', (req) => {
    const people = getPeople(db, hid(req));
    // Names for the "doesn't eat" chips (they're stored as product ids).
    const names: Record<string, [string, string]> = {};
    for (const id of new Set(people.flatMap((p) => p.avoid))) {
      const p = getProduct(db, id);
      if (p) names[id] = [p.name, p.name_nl || p.name];
    }
    return { people, names, options: { diets: DIETS, allergens: ALLERGENS } };
  });
  r.put('/api/dietary', (req) => {
    const person = z.object({
      id: z.string().min(1).max(40), name: z.string().min(1).max(40),
      diets: z.array(z.enum(DIETS)).max(DIETS.length), allergies: z.array(z.enum(ALLERGENS)).max(ALLERGENS.length),
      avoid: z.array(z.string().max(60)).max(60),
      kcal: z.number().int().min(800).max(6000).optional().nullable(), protein: z.number().int().min(0).max(400).optional().nullable(),
    });
    const b = validate(z.object({ people: z.array(person).min(1).max(12) }), req.body);
    savePeople(db, hid(req), b.people);
    bus.touch(hid(req), 'preferences');
    bus.touch(hid(req), 'recipes');
    return { people: getPeople(db, hid(req)) };
  });

  // ---------- Assistant ----------
  r.post('/api/assistant', async (req) => {
    const b = validate(z.object({ text: z.string().min(1).max(500), conversationId: z.string().max(60).optional().nullable(), lang: z.enum(['en', 'nl']).optional().nullable(), context: z.string().max(30).optional().nullable(), clientRequestId }), req.body);
    return handleUtterance(db, { householdId: hid(req), userId: req.user!.id, conversationId: b.conversationId, text: b.text, lang: b.lang, context: b.context, clientRequestId: b.clientRequestId });
  });
  r.post('/api/assistant/list', (req) => {
    const b = validate(z.object({ text: z.string().max(2000), lang: z.enum(['en', 'nl']).default('en') }), req.body);
    return b.text.trim() ? readBoughtList(db, hid(req), b.text, b.lang) : { lang: b.lang, lines: [] };
  });
  r.post('/api/assistant/undo', (req) => {
    const b = validate(z.object({ batchId: z.string().min(3) }), req.body);
    return db.tx(() => undoTurnBatch(db, hid(req), b.batchId, req.user!.id));
  });
  // ---------- Siri Shortcuts ----------
  r.get('/api/tokens', (req) => listTokens(db, hid(req)));
  r.post('/api/tokens', (req) => {
    const b = validate(z.object({ name: z.string().min(1).max(40).default('Siri') }), req.body);
    return createToken(db, hid(req), req.user!.id, b.name);
  });
  r.delete('/api/tokens/:id', (req) => {
    deleteToken(db, hid(req), req.params.id);
    return { ok: true };
  });
  // Called by the Shortcut with `Authorization: Bearer lrd_…`. Replies in plain text for Siri to speak.
  r.post('/api/shortcut/say', async (req) => {
    const t = tokenUser(db, req.raw.headers.authorization);
    const b = validate(z.object({ text: z.string().max(500).default(''), lang: z.enum(['en', 'nl']).optional() }), req.body);
    let response;
    if (!b.text.trim()) {
      // Shortcut run without words: ask the daily cooking question if one is waiting.
      response = greet(db, { householdId: t.household_id, userId: t.user_id, conversationId: t.conversation_id, lang: b.lang ?? 'en' });
      if (!response) return reply({ text: b.lang === 'nl' ? 'Wat wil je doen? Zeg bijvoorbeeld: de melk is op.' : 'What would you like to do? For example: I finished the milk.' });
    } else {
      response = await handleUtterance(db, { householdId: t.household_id, userId: t.user_id, conversationId: t.conversation_id, text: b.text, lang: b.lang ?? null, context: 'siri' });
    }
    rememberConversation(db, t.id, response.conversationId);
    return reply({ text: spokenReply(response) });
  }, { auth: false });

  // Opening the assistant: if a planned meal is waiting for its daily check-in, the assistant asks about it first.
  r.post('/api/assistant/greet', (req) => {
    const b = validate(z.object({ conversationId: z.string().max(60).optional().nullable(), lang: z.enum(['en', 'nl']).default('en') }), req.body);
    return { greeting: greet(db, { householdId: hid(req), userId: req.user!.id, conversationId: b.conversationId, lang: b.lang }) };
  });

  // ---------- Daily cooking check-in ----------
  r.get('/api/checkins', (req) => ({ settings: checkinSettings(db, hid(req)), pending: pendingCheckins(db, hid(req), { includeToday: req.query.get('all') === '1' }) }));
  r.post('/api/checkins/:slotId', (req) => {
    const b = validate(z.object({
      answer: z.enum(['cooked', 'not_cooked', 'tomorrow']),
      servings: z.number().min(0.5).max(40).optional(),
      leftovers: z.object({ fridge: z.number().int().min(0).max(40).optional(), freezer: z.number().int().min(0).max(40).optional() }).optional(),
    }), req.body);
    // Idempotent per slot: tapping "Yes" on two devices (or twice on a notification) cooks once.
    const ctx = ctxFor(db, req, 'recipe', `checkin:${req.params.slotId}`);
    return db.tx(() => answerCheckin(ctx, req.params.slotId, b.answer, { servings: b.servings, leftovers: b.leftovers }));
  });
  r.put('/api/checkins/settings', (req) => {
    const b = validate(z.object({ enabled: z.boolean(), time: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/) }), req.body);
    db.run("INSERT OR REPLACE INTO preferences (household_id, user_id, key, value) VALUES (?, '', 'cookCheckin', ?)", hid(req), JSON.stringify(b));
    bus.touch(hid(req), 'preferences');
    return b;
  });

  // ---------- Push notifications ----------
  r.get('/api/push/key', () => ({ publicKey: vapidPublicKey(db) }));
  r.post('/api/push/subscribe', (req) => {
    const b = validate(z.object({ endpoint: z.string().url().max(1000), keys: z.object({ p256dh: z.string().max(200), auth: z.string().max(100) }) }), req.body);
    saveSubscription(db, hid(req), req.user!.id, b);
    return { ok: true };
  });
  r.post('/api/push/unsubscribe', (req) => {
    const b = validate(z.object({ endpoint: z.string().max(1000) }), req.body);
    removeSubscription(db, hid(req), b.endpoint);
    return { ok: true };
  });
  r.post('/api/push/test', async (req) => {
    const nl = req.body?.lang === 'nl';
    const sent = await pushToHousehold(db, hid(req), { title: 'PantryPip', body: nl ? 'Meldingen werken. Je krijgt dagelijks de kookvraag.' : 'Notifications work. You’ll get the daily cooking question.', tag: 'test', url: '/#/' });
    return { sent };
  });

  // ---------- Receipts ----------
  r.post('/api/receipts/scan', async (req) => {
    const b = validate(z.object({
      images: z.array(z.object({ mediaType: z.enum(['image/jpeg', 'image/png', 'image/webp']), data: z.string().max(12_000_000) })).max(6).optional(),
      text: z.string().max(20_000).optional(),
      useAi: z.boolean().optional(),
    }), req.body);
    if (b.images?.length) {
      if (!ai.enabled()) throw new AppError(422, 'ai_unavailable', 'Photo reading needs AI. The app will read the photo on your device instead.');
      const parsed = await ai.parseReceiptImages(b.images);
      return createDraft(db, hid(req), parsed, { parser: 'ai' });
    }
    if (!b.text?.trim()) throw badRequest('Send receipt images or text');
    let parsed = parseReceiptText(b.text);
    let parser: 'rules' | 'ai' = 'rules';
    // OCR text from the device is noisy; let AI clean it up when the rules found little.
    if (ai.enabled() && (b.useAi || parsed.lines.length < 2 || parsed.warnings.some((w) => w.startsWith('Line items add up')))) {
      try {
        parsed = await ai.parseReceiptText(b.text);
        parser = 'ai';
      } catch {
        /* keep rule-based result */
      }
    }
    return createDraft(db, hid(req), parsed, { rawText: b.text, parser });
  }, { bodyLimit: 40_000_000 });
  r.get('/api/receipts', (req) => listReceipts(db, hid(req)));
  r.get('/api/receipts/:id', (req) => getDraft(db, hid(req), req.params.id));
  r.post('/api/receipts/:id/commit', (req) => {
    const b = validate(z.object({
      force: z.boolean().optional(),
      lines: z.array(z.object({
        index: z.number().int().min(0), action: z.enum(['add', 'skip']), productId: z.string().optional().nullable(),
        newProduct: z.object({ name: z.string().min(1).max(120), category: z.string().optional(), unit: z.enum(['g', 'ml', 'pcs']).optional(), package_size: pos.optional() }).optional().nullable(),
        quantity: pos.optional().nullable(), packages: pos.optional().nullable(), location, expiresOn: dateStr.optional().nullable(), duplicate: z.enum(['reconcile', 'add']).optional(), damaged: num.min(0).optional().nullable(),
      })).max(300).default([]),
    }), req.body);
    const ctx = ctxFor(db, req, 'receipt', `receipt:${req.params.id}`);
    return commitReceipt(ctx, req.params.id, b.lines, { force: b.force });
  });
  r.delete('/api/receipts/:id', (req) => {
    discardDraft(db, hid(req), req.params.id);
    return { ok: true };
  });

  // ---------- Barcode ----------
  r.get('/api/barcode/:code', async (req) => {
    const code = req.params.code.replace(/\D/g, '');
    if (!validBarcode(code)) throw badRequest('Not a valid EAN/UPC barcode');
    const res = await lookupBarcode(db, hid(req), code);
    // Warn when a scanned product clashes with someone's allergies or diet.
    const needs = dietaryNeeds(db, hid(req));
    const info = res.product ?? (res.external ? { id: '', allergens: res.external.allergens, diet_flags: res.external.diet_flags } : null);
    return { ...res, stock: res.product ? stockItem(db, hid(req), res.product.id) : null, conflicts: info ? productConflicts(info, needs) : [] };
  });
  r.post('/api/barcode/:code/link', (req) => {
    const b = validate(z.object({ productId: z.string().optional().nullable(), name: z.string().max(120).optional(), packageSize: pos.optional().nullable(), unit: z.enum(['g', 'ml', 'pcs']).optional().nullable(), category: z.string().optional().nullable() }), req.body);
    return db.tx(() => linkBarcode(db, hid(req), req.params.code, b));
  });

  // ---------- Shopping ----------
  // Plan-driven items depend on stock too (bought, cooked, used), so recalculate on read. ~5 ms for a household.
  r.get('/api/shopping', (req) => {
    syncPlanToShopping(db, hid(req), { quiet: true });
    return { ...listShopping(db, hid(req)), shops: shopLinks(db, hid(req)) };
  });
  r.post('/api/shopping', (req) => {
    const b = validate(z.object({ name: z.string().max(120).optional(), productId: z.string().optional().nullable(), packages: pos.optional().nullable(), packSize: pos.optional().nullable(), quantity: pos.optional().nullable(), note: z.string().max(200).optional().nullable() }), req.body);
    if (!b.name && !b.productId) throw badRequest('name or productId is required');
    return addShoppingItem(db, hid(req), b, req.user!.id);
  });
  r.patch('/api/shopping/:id', (req) => updateShoppingItem(db, hid(req), req.params.id, validate(z.object({ checked: z.boolean().optional(), packages: pos.optional(), note: z.string().max(200).optional().nullable(), name: z.string().max(120).optional() }), req.body)));
  r.delete('/api/shopping/:id', (req) => {
    removeShoppingItem(db, hid(req), req.params.id);
    return { ok: true };
  });
  // An item on the list because planned meals need it: which meals (to warn before changing it), and
  // swapping it for another product in those meals, so the recipe, the list and cooking all follow.
  const usesOf = (h: string, itemId: string) => {
    const item = db.get<{ product_id: string | null }>('SELECT product_id FROM shopping_items WHERE id = ? AND household_id = ?', itemId, h);
    if (!item) throw notFound('Item');
    if (!item.product_id) return [];
    return planRequirements(db, h, clock.today(), planHorizonDays(db, h)).find((x) => x.productId === item.product_id)?.uses ?? [];
  };
  r.get('/api/shopping/:id/uses', (req) => usesOf(hid(req), req.params.id));
  r.post('/api/shopping/:id/replace', (req) => {
    const b = validate(z.object({ productId: z.string().min(1).max(60).optional(), omit: z.boolean().optional() }).refine((x) => !!x.productId !== !!x.omit, 'Give a productId, or omit: true'), req.body);
    const uses = usesOf(hid(req), req.params.id);
    if (!uses.length) throw new AppError(409, 'not_for_a_recipe', 'No planned meal needs this item.');
    db.tx(() => {
      for (const u of uses) setSlotSwap(db, hid(req), u.slotId, u.position, b.productId ?? null, !!b.omit);
    });
    // Left out of every meal: the list item goes now (the sync removes plan items no meal needs).
    replan(hid(req));
    return { meals: [...new Set(uses.map((u) => u.slotId))].length, list: listShopping(db, hid(req)) };
  });
  r.post('/api/shopping/complete', (req) => {
    const b = validate(z.object({ itemIds: z.array(z.string()).optional(), store: z.string().max(60).optional().nullable(), clientRequestId }), req.body);
    return once(db, req, 'shopping_list', b.clientRequestId, (ctx) => completeTrip(ctx, b));
  });
  r.post('/api/shopping/sync', (req) => {
    syncPlanToShopping(db, hid(req));
    return listShopping(db, hid(req));
  });
  r.get('/api/shopping/suggestions', (req) => shoppingSuggestions(db, hid(req)));
  r.post('/api/shopping/suggestions/:productId/:verdict', (req) => {
    const { productId, verdict } = req.params;
    if (verdict === 'accept') {
      const p = getProduct(db, productId);
      if (!p) throw notFound('Product');
      const b = validate(z.object({ packages: pos.optional() }), req.body);
      return addShoppingItem(db, hid(req), { productId, packages: b.packages ?? 1, reason: 'suggestion' }, req.user!.id);
    }
    if (verdict === 'reject') {
      recordFeedback(db, hid(req), productId, false);
      return { ok: true };
    }
    throw notFound('Action');
  });

  // ---------- Meal planner ----------
  const replan = (h: string) => syncPlanToShopping(db, h);
  r.get('/api/plan', (req) => {
    const start = req.query.get('start') ?? clock.today();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(start)) throw badRequest('start must be YYYY-MM-DD');
    return weekPlan(db, hid(req), start, Math.max(1, Math.min(28, Number(req.query.get('days') ?? 7) || 7)));
  });
  r.post('/api/plan', (req) => {
    const b = validate(z.object({ date: dateStr, meal: z.string().min(1).max(30), recipeId: z.string().optional().nullable(), leftoverLotId: z.string().optional().nullable(), title: z.string().max(80).optional().nullable(), servings: z.number().int().min(1).max(40).optional(), swaps: z.array(z.object({ position: z.number().int().min(0), productId: z.string().min(1).max(60) })).max(40).optional() }), req.body);
    const slot = db.tx(() => addSlot(db, hid(req), b));
    replan(hid(req));
    return slot;
  });
  r.patch('/api/plan/:id', (req) => {
    const b = validate(z.object({ date: dateStr.optional(), meal: z.string().max(30).optional(), position: z.number().int().min(0).optional(), servings: z.number().int().min(1).max(40).optional(), status: z.enum(['planned', 'skipped']).optional(), recipeId: z.string().optional().nullable(), title: z.string().max(80).optional().nullable(), locked: z.boolean().optional() }), req.body);
    const slot = db.tx(() => updateSlot(db, hid(req), req.params.id, b));
    replan(hid(req));
    return slot;
  });
  // Use another ingredient for one line of this meal's recipe (productId null: back to the recipe's own).
  r.post('/api/plan/:id/ingredient', (req) => {
    const b = validate(z.object({ position: z.number().int().min(0), productId: z.string().min(1).max(60).nullable().optional(), omit: z.boolean().optional() }), req.body);
    const slot = db.tx(() => setSlotSwap(db, hid(req), req.params.id, b.position, b.productId ?? null, !!b.omit));
    replan(hid(req));
    return slot;
  });
  r.delete('/api/plan/:id', (req) => {
    db.tx(() => removeSlot(db, hid(req), req.params.id));
    replan(hid(req));
    return { ok: true };
  });
  // Clear the week (planned meals only; cooked ones stay), and undo it.
  r.post('/api/plan/clear', (req) => {
    const b = validate(z.object({ start: dateStr, days: z.number().int().min(1).max(28).default(7) }), req.body);
    const removed = db.tx(() => clearPlan(db, hid(req), b.start, addDays(b.start, b.days - 1)));
    replan(hid(req));
    return { removed: removed.length, slots: removed };
  });
  r.post('/api/plan/restore', (req) => {
    const slot = z.object({ id: z.string().min(1).max(60), date: dateStr, meal: z.string().max(30), position: z.number().int().min(0).optional(), recipe_id: z.string().nullable().optional(), leftover_lot_id: z.string().nullable().optional(), title: z.string().max(80).nullable().optional(), servings: z.number().int().min(1).max(40), status: z.string().optional(), locked: z.number().int().optional(), created_at: z.string().optional() });
    const b = validate(z.object({ slots: z.array(slot).max(100) }), req.body);
    const restored = db.tx(() => restoreSlots(db, hid(req), b.slots));
    replan(hid(req));
    return { restored };
  });
  // "Plan my week": a proposal first (nothing changes), then one tap to put it on the plan.
  const autoOpts = z.object({
    start: dateStr.optional(), days: z.number().int().min(1).max(14).optional(), servings: z.number().int().min(1).max(20).optional(), fifo: z.union([z.boolean(), z.enum(['off', 'balanced', 'strong'])]).optional(),
    maxWeeknightMinutes: z.number().int().min(10).max(240).nullable().optional(), replace: z.boolean().optional(), seed: z.number().int().optional(),
    avoid: z.array(z.string()).max(60).optional(), only: z.array(dateStr).max(14).optional(),
  });
  r.post('/api/plan/auto/preview', (req) => proposeWeek(db, hid(req), validate(autoOpts, req.body)));
  r.post('/api/plan/auto/apply', (req) => {
    const b = validate(z.object({ days: z.array(z.object({ date: dateStr, recipeId: z.string().min(1) })).min(1).max(14), servings: z.number().int().min(1).max(20) }), req.body);
    for (const d of b.days) getRecipe(db, hid(req), d.recipeId);
    const open = () => listShopping(db, hid(req)).count;
    const before = open();
    const res = applyPlan(db, hid(req), b.days, b.servings);
    replan(hid(req));
    return { ...res, shoppingAdded: Math.max(0, open() - before) };
  });
  r.get('/api/plan/auto/prefs', (req) => ({ ...autoPlanPrefs(db, hid(req)), options: favouriteFoodOptions(db, req.query.get('lang') === 'nl' ? 'nl' : 'en') }));
  r.put('/api/plan/auto/prefs', (req) => {
    const b = validate(z.object({ favouriteFoods: z.array(z.string()).max(40).optional(), fifo: z.enum(['off', 'balanced', 'strong']).optional(), maxWeeknightMinutes: z.number().int().min(10).max(240).nullable().optional(), householdSize: z.number().int().min(1).max(20).optional() }), req.body);
    if (b.favouriteFoods) prefSet(hid(req), 'favouriteFoods', b.favouriteFoods);
    if (b.fifo !== undefined) prefSet(hid(req), 'autoPlanFifo', b.fifo);
    if (b.maxWeeknightMinutes !== undefined) prefSet(hid(req), 'maxWeeknightMinutes', b.maxWeeknightMinutes);
    if (b.householdSize) prefSet(hid(req), 'householdSize', b.householdSize);
    bus.touch(hid(req), 'preferences');
    return autoPlanPrefs(db, hid(req));
  });
  // "Not this one": the next-best recipe for that day; the old one counts as swapped out.
  // Change a planned recipe: a ranked menu to pick from, then the pick (the shopping list follows).
  const kindFilter = (req: any) => ({ cuisine: req.query.get('cuisine')?.slice(0, 40) || null, protein: req.query.get('protein')?.slice(0, 20) || null });
  r.get('/api/plan/:id/options', (req) => slotOptions(db, hid(req), req.params.id, Math.max(1, Math.min(30, Number(req.query.get('limit') ?? 12) || 12)), kindFilter(req)));
  r.post('/api/plan/:id/choose', (req) => {
    const b = validate(z.object({ recipeId: z.string().min(1).max(60) }), req.body);
    getRecipe(db, hid(req), b.recipeId); // one of yours or a built-in recipe, or 404
    const slot = chooseForSlot(db, hid(req), req.params.id, b.recipeId);
    replan(hid(req));
    return slot;
  });
  r.post('/api/plan/:id/swap', (req) => {
    const day = db.tx(() => swapSlot(db, hid(req), req.params.id, Date.now(), kindFilter(req)));
    if (!day) throw new AppError(409, 'no_alternative', req.query.get('cuisine') || req.query.get('protein') ? 'No other recipe of that kind fits this day.' : 'No other recipe fits this day.');
    replan(hid(req));
    return day;
  });
  // What PantryPip has learned from your behaviour; each insight can be switched off.
  r.get('/api/insights/learned', (req) => {
    const recipes = new Map(listRecipes(db, hid(req)).map((x) => [x.id, x]));
    return learnedProfile(db, hid(req), recipes).insights;
  });
  r.post('/api/insights/learned/:id', (req) => {
    const b = validate(z.object({ active: z.boolean() }), req.body);
    const off = new Set(dismissedInsights(db, hid(req)));
    if (b.active) off.delete(req.params.id);
    else off.add(req.params.id);
    prefSet(hid(req), 'dismissedInsights', [...off]);
    bus.touch(hid(req), 'preferences');
    return { ok: true };
  });
  r.post('/api/plan/:id/cook', (req) => {
    const slot = getSlot(db, hid(req), req.params.id);
    if (!slot.recipe_id) throw badRequest('This meal has no recipe');
    const b = validate(cookInput, req.body);
    // Ingredients swapped for this meal are what gets taken from stock (unless the cook says otherwise).
    const swapped = slotSwaps(db.get('SELECT swaps FROM meal_slots WHERE id = ?', slot.id) ?? {}).filter((w) => !b.overrides?.some((o) => o.position === w.position)).map((w) => (w.omit ? { position: w.position, quantity: 0 } : { position: w.position, productId: w.productId }));
    const overrides = [...(b.overrides ?? []), ...swapped];
    const res = once(db, req, 'recipe', b.clientRequestId ?? `cook:${slot.id}`, (ctx) => cookRecipe(ctx, { recipeId: slot.recipe_id!, servings: b.servings ?? slot.servings, overrides: overrides.length ? overrides : undefined, leftovers: b.leftovers, mealSlotId: slot.id, deduct: b.deduct ?? interactionPrefs(db, hid(req)).autoDeduct }));
    replan(hid(req));
    return { ...res, reward: res.duplicate ? null : rewardFor(db, hid(req), res.batchId, evaluateJourney(db, hid(req))) };
  });

  // ---------- Recipes ----------
  const slimMatch = (m: ReturnType<typeof searchRecipes>[number]) => ({
    id: m.recipe.id, title: m.recipe.title, summary: m.recipe.summary, emoji: m.recipe.emoji, color: m.recipe.color, image_url: m.recipe.image_url, cuisine: m.recipe.cuisine,
    tags: m.recipe.tags, diet: m.recipe.diet, difficulty: m.recipe.difficulty, servings: m.servings, minutes: m.recipe.prep_minutes + m.recipe.cook_minutes, prep_minutes: m.recipe.prep_minutes, cook_minutes: m.recipe.cook_minutes,
    origin: m.recipe.origin, source_name: m.recipe.source_name, nutritionPerServing: m.recipe.nutritionPerServing, costPerServing: m.recipe.costPerServing,
    matchPct: m.matchPct, missing: m.missing.map((x) => ({ name: x.name, productId: x.product_id, substitutes: x.substitutes })), usesExpiring: m.usesExpiring, missingCost: m.missingCost, reasons: m.reasons, score: m.score,
    health: m.recipe.health.score, healthGrade: m.recipe.health.grade, mainProtein: m.recipe.protein, household_id: m.recipe.household_id,
    allergens: m.recipe.allergens, suitable: m.suitability?.ok ?? true, adaptable: m.suitability?.adaptable ?? false, swaps: m.suitability?.swaps ?? [],
    compat: m.recipe.compat.level, servingsEstimated: !!m.recipe.servings_estimated,
  });
  /** Recipe summaries plus your own rating and favourite, for the cards. */
  const withMine = (req: any) => {
    const inter = new Map(db.all<{ recipe_id: string; rating: number | null; priority: number; saved: number }>('SELECT recipe_id, rating, priority, saved FROM recipe_interactions WHERE household_id = ?', hid(req)).map((r) => [r.recipe_id, r]));
    return (m: ReturnType<typeof searchRecipes>[number]) => {
      const it = inter.get(m.recipe.id);
      return { ...slimMatch(m), rating: it?.rating ?? null, favourite: !!it && (it.priority >= 2 || !!it.saved || (it.rating ?? 0) >= 5) };
    };
  };
  r.get('/api/recipes', (req) => {
    const q = req.query;
    const n = (k: string) => (q.get(k) ? Number(q.get(k)) : undefined);
    return searchRecipes(db, hid(req), {
      q: q.get('q') ?? undefined, ingredient: q.get('ingredient') ?? undefined, cuisine: q.get('cuisine') ?? undefined, diet: q.get('diet') ?? undefined, tag: q.get('tag') ?? undefined,
      maxMinutes: n('maxMinutes'), maxCostPerServing: n('maxCost'), maxKcal: n('maxKcal'), minProtein: n('minProtein'), difficulty: q.get('difficulty') ?? undefined,
      servings: n('servings'), origin: q.get('origin') ?? undefined, saved: q.get('saved') === '1', sort: (q.get('sort') as any) ?? undefined, limit: n('limit'),
      compat: (q.get('compat') as any) ?? undefined,
    }).map(withMine(req));
  });
  r.get('/api/recipes/cook-now', (req) => {
    // "Cook with what I have": at least half the ingredients in stock, expiring items first.
    return searchRecipes(db, hid(req), {}).filter((m) => m.matchPct >= 50).sort((a, b) => b.usesExpiring.length - a.usesExpiring.length || b.matchPct - a.matchPct || b.score - a.score).map(withMine(req));
  });
  r.get('/api/recipes/ask', (req) => {
    // Natural-language discovery ("high-protein dinner under 20 minutes") through the same filter parser as the assistant.
    const text = req.query.get('q') ?? '';
    const intent = parse(text).intents[0];
    const filters = intent.type === 'query_cook' ? intent.filters : { query: text, ingredient: null, cuisine: null, maxMinutes: null, highProtein: false, cheap: false, diet: null, useUp: false, meal: null };
    return recipesForFilters(db, hid(req), filters).map(withMine(req));
  });
  // My recipes: ones you saved, rated, wrote or imported.
  // Links of recipes this household already imported, so a bulk import can skip them.
  r.get('/api/recipes/imported', (req) => ({
    urls: db.all<{ source_url: string }>('SELECT source_url FROM recipes WHERE household_id = ? AND source_url IS NOT NULL', hid(req)).map((r) => r.source_url),
  }));
  r.get('/api/recipes/mine', (req) => {
    const inter = new Map(db.all<any>('SELECT * FROM recipe_interactions WHERE household_id = ?', hid(req)).map((x) => [x.recipe_id, x]));
    return searchRecipes(db, hid(req), { limit: 500, includeUnsuitable: true })
      .filter((m) => { const i = inter.get(m.recipe.id); return m.recipe.household_id || i?.saved || i?.rating || i?.to_try || i?.notes || (i?.priority ?? 0) > 0; })
      .map((m) => { const i = inter.get(m.recipe.id); return { ...slimMatch(m), saved: !!i?.saved, rating: i?.rating ?? null, priority: i?.priority ?? 0, toTry: !!i?.to_try, cooked: i?.cooked_count ?? 0, lastCooked: i?.last_cooked_at ?? null, hasNotes: !!i?.notes }; });
  });
  r.get('/api/recipes/:id', (req) => {
    const recipe = getRecipe(db, hid(req), req.params.id);
    const servings = Number(req.query.get('servings') ?? recipe.servings);
    const needs = dietaryNeeds(db, hid(req));
    const m = matchRecipe(recipe, stockMap(db, hid(req)), servings, needs);
    const suitability = suitabilityFor(db, recipe, needs);
    const inter = db.get('SELECT saved, rating, priority, notes, to_try, ease, again, swapped_count, cooked_count, last_cooked_at FROM recipe_interactions WHERE household_id = ? AND recipe_id = ?', hid(req), recipe.id);
    // Balance against this household's own targets, and when it was cooked.
    recipe.health = mealScore(recipe.nutritionPerServing, recipe.health.vegGrams, recipe.health.vegKinds, targetsFor(db, hid(req)));
    const history = db.all<{ created_at: string; servings: number }>('SELECT created_at, servings FROM cook_log WHERE household_id = ? AND recipe_id = ? ORDER BY created_at DESC LIMIT 12', hid(req), recipe.id);
    return { recipe, history, servings, factor: servings / recipe.servings, match: { matchPct: m.matchPct, ingredients: m.ingredients, missing: m.missing, usesExpiring: m.usesExpiring, missingCost: m.missingCost }, suitability, people: needs.people.map((p) => p.name), interaction: inter ?? null };
  });
  const recipeInput = z.object({
    title: z.string().min(1).max(120), summary: z.string().max(400).optional().nullable(), cuisine: z.string().max(40).optional().nullable(), tags: z.array(z.string().max(30)).max(20).optional(),
    diet: z.array(z.string().max(30)).max(10).optional(), difficulty: z.enum(['easy', 'medium', 'hard']).optional(), servings: z.number().int().min(1).max(40),
    prep_minutes: z.number().int().min(0).max(1440).optional(), cook_minutes: z.number().int().min(0).max(1440).optional(),
    steps: z.array(z.object({ text: z.string().min(1).max(1000), timerSeconds: z.number().int().min(0).max(86400).optional().nullable() })).min(1).max(60),
    ingredients: z.array(z.object({ name: z.string().min(1).max(120), productId: z.string().optional().nullable(), quantity: num.min(0).optional().nullable(), unit: z.string().max(20).optional().nullable(), display: z.string().max(200).optional().nullable(), optional: z.boolean().optional(), match: z.enum(['exact', 'equivalent', 'substitute', 'approximate', 'unresolved']).optional().nullable(), sourceKey: z.string().max(140).optional().nullable() })).min(1).max(60),
    emoji: z.string().max(8).optional(), color: z.string().max(20).optional(), image_url: z.string().url().max(500).optional().nullable(), source_url: z.string().url().max(500).optional().nullable(), source_name: z.string().max(80).optional().nullable(),
  });
  function normaliseIngredients(h: string, ings: z.infer<typeof recipeInput>['ingredients']) {
    return ings.map((i) => {
      const p = i.productId ? getProduct(db, i.productId) : resolveProduct(db, h, i.name).product;
      let quantity = i.quantity ?? null;
      if (p && quantity != null && i.unit) {
        try {
          quantity = toBase(quantity, i.unit, p).qty;
        } catch {
          /* keep as given */
        }
      }
      return { product_id: p?.id ?? null, name: i.name, quantity, unit: p?.unit ?? i.unit ?? null, display: i.display ?? null, optional: i.optional, match: p ? (i.match ?? 'exact') : 'unresolved', source_key: i.sourceKey ?? null };
    });
  }
  r.post('/api/recipes', (req) => {
    const b = validate(recipeInput, req.body);
    return createRecipe(db, hid(req), { ...b, steps: b.steps.map((s) => ({ text: s.text, timerSeconds: s.timerSeconds ?? undefined })), origin: b.source_url ? 'external' : 'user', ingredients: normaliseIngredients(hid(req), b.ingredients) });
  });
  r.put('/api/recipes/:id', (req) => {
    const b = validate(recipeInput, req.body);
    return updateRecipe(db, hid(req), req.params.id, { ...b, steps: b.steps.map((s) => ({ text: s.text, timerSeconds: s.timerSeconds ?? undefined })), ingredients: normaliseIngredients(hid(req), b.ingredients) });
  });
  r.post('/api/recipes/:id/copy', (req) => copyRecipe(db, hid(req), req.params.id));
  // Your own photo for a recipe you added (resized on the phone first).
  const photoDir = path.join(path.dirname(config.dbFile), 'photos');
  r.post('/api/recipes/:id/photo', (req) => {
    const own = db.get('SELECT id FROM recipes WHERE id = ? AND household_id = ?', req.params.id, hid(req));
    if (!own) throw notFound('Recipe');
    const b = validate(z.object({ data: z.string().max(4_000_000) }), req.body);
    const m = b.data.match(/^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$/);
    if (!m) throw badRequest('Send a JPEG, PNG or WebP image');
    mkdirSync(photoDir, { recursive: true });
    const file = `${req.params.id}.${m[1] === 'jpeg' ? 'jpg' : m[1]}`;
    writeFileSync(path.join(photoDir, file), Buffer.from(m[2], 'base64'));
    const url = `/api/photos/${file}?v=${Date.now().toString(36)}`;
    db.run('UPDATE recipes SET image_url = ? WHERE id = ?', url, req.params.id);
    bus.touch(hid(req), 'recipes');
    return { image_url: url };
  }, { bodyLimit: 5_000_000 });
  r.get('/api/photos/:file', (req) => {
    const f = req.params.file;
    if (!/^r_[\w-]+\.(jpg|png|webp)$/.test(f)) throw notFound('Photo');
    const own = db.get('SELECT 1 FROM recipes WHERE id = ? AND household_id = ?', f.replace(/\.\w+$/, ''), hid(req));
    const p = path.join(photoDir, f);
    if (!own || !existsSync(p)) throw notFound('Photo');
    return reply({ bytes: readFileSync(p), headers: { 'Content-Type': f.endsWith('png') ? 'image/png' : f.endsWith('webp') ? 'image/webp' : 'image/jpeg', 'Cache-Control': 'private, max-age=31536000, immutable' } });
  });
  // Ingredients: details (types, availability, supermarket products), your own types, review, choices, country.
  r.get('/api/ingredients/review', (req) => reviewList(db, hid(req), { all: req.query.get('all') === '1' }));
  r.get('/api/ingredients/types', (req) => familyPrefs(db, hid(req)));
  r.get('/api/ingredients/country', (req) => countryOptions(db, hid(req)));
  r.post('/api/ingredients/locate', (req) => {
    const b = validate(z.object({ lat: z.number().min(-90).max(90), lon: z.number().min(-180).max(180) }), req.body);
    // Offline: the coordinates are only compared with country outlines here, never sent anywhere.
    return { country: countryAt(b.lat, b.lon) };
  });
  r.put('/api/ingredients/choice', (req) => {
    const b = validate(z.object({ key: z.string().min(3).max(140), choice: z.string().max(60).nullable() }), req.body);
    setChoice(db, hid(req), b.key, b.choice);
    return { ok: true };
  });
  r.post('/api/ingredients/custom-type', (req) => {
    const b = validate(z.object({ family: z.string().max(30), name: z.string().min(2).max(60), remember: z.boolean().optional(),
      nutrition: z.object({ kcal: z.number().min(0).max(950), protein: z.number().min(0).max(100), carbs: z.number().min(0).max(100), fat: z.number().min(0).max(100) }).optional() }), req.body);
    if (!familyById(b.family)) throw new AppError(422, 'bad_family', 'Unknown ingredient family.');
    const p = createCustomType(db, hid(req), b.family, b.name, b.nutrition ? { nutrition: b.nutrition, nutrition_source: 'user' } : {});
    if (b.remember) setChoice(db, hid(req), `f:${b.family}`, p.id);
    bus.touch(hid(req), 'recipes');
    return p;
  });
  r.get('/api/ingredients/:id', (req) => ingredientDetail(db, hid(req), req.params.id));
  // One sentence → a structured recipe in My recipes; and a use-it-up recipe from what's in stock.
  r.post('/api/recipes/quick', (req) => {
    const b = validate(z.object({ text: z.string().min(2).max(1000), servings: z.number().int().min(1).max(20).optional(), lang: z.enum(['en', 'nl']).optional() }), req.body);
    return recipeFromSentence(db, hid(req), b.text, b);
  });
  r.post('/api/recipes/from-stock', (req) => {
    const b = validate(z.object({ servings: z.number().int().min(1).max(20).optional(), lang: z.enum(['en', 'nl']).optional() }), req.body ?? {});
    return recipeFromStock(db, hid(req), b);
  });
  r.post('/api/recipes/import', async (req) => {
    const b = validate(z.object({ url: z.string().min(4).max(1000) }), req.body);
    return draftFromUrl(db, hid(req), b.url.trim());
  });
  r.post('/api/recipes/draft', (req) => {
    const b = validate(z.object({ title: z.string().max(120).default(''), servings: z.number().int().min(1).max(40).optional(), minutes: z.number().int().min(0).max(1440).optional(), ingredients: z.string().min(1).max(10000), steps: z.string().max(20000).optional() }), req.body);
    return draftFromText(db, hid(req), b);
  });
  // Errors that happen only on the phone (reading a photo), so they show up in the server log.
  r.post('/api/client-log', (req) => {
    const b = validate(z.object({ where: z.string().max(60), message: z.string().max(500), ua: z.string().max(300).optional() }), req.body);
    log.warn('client error', { where: b.where, message: b.message, ua: b.ua });
    return { ok: true };
  });
  // The text of a recipe photo or screenshot, read on the phone; this structures it into a draft.
  r.post('/api/recipes/photo', (req) => {
    const b = validate(z.object({ text: z.string().min(1).max(30000), lang: z.enum(['en', 'nl']).optional() }), req.body);
    return draftFromPhotoText(db, hid(req), b.text, b.lang);
  });
  r.delete('/api/recipes/:id', (req) => {
    const own = db.get<{ title: string }>('SELECT title FROM recipes WHERE id = ? AND household_id = ?', req.params.id, hid(req));
    if (!own) throw notFound('Recipe');
    db.tx(() => {
      db.run("DELETE FROM meal_slots WHERE household_id = ? AND recipe_id = ? AND status = 'planned'", hid(req), req.params.id);
      db.run('UPDATE meal_slots SET recipe_id = NULL, title = ? WHERE household_id = ? AND recipe_id = ?', own.title, hid(req), req.params.id);
      db.run('DELETE FROM recipe_interactions WHERE household_id = ? AND recipe_id = ?', hid(req), req.params.id);
      db.run('DELETE FROM recipes WHERE id = ?', req.params.id);
    });
    bus.touch(hid(req), 'recipes');
    replan(hid(req));
    return { ok: true };
  });
  r.post('/api/recipes/generate', async (req) => {
    if (!ai.enabled()) throw new AppError(422, 'ai_unavailable', 'AI recipe generation is switched off on this server.');
    const b = validate(z.object({ prompt: z.string().min(2).max(400), servings: z.number().int().min(1).max(20).optional(), lang: z.enum(['en', 'nl']).optional() }), req.body);
    const needs = dietaryNeeds(db, hid(req));
    const { items } = inventorySummary(db, hid(req));
    const g = await ai.generateRecipe(b.prompt, {
      lang: b.lang ?? 'en',
      servings: b.servings ?? (prefGet(hid(req), 'householdSize', 2) as number),
      diet: [...needs.diets, ...[...needs.allergies].map((a) => `no ${a} (allergy)`)],
      dislikes: [...needs.avoid].map((id) => getProduct(db, id)?.name ?? id),
      inventory: items.filter((s) => s.confirmed > 0).map((s) => ({ name: s.product.name, qty: formatQty(s.showEstimate ? s.estimated : s.confirmed, s.product.unit), expiresInDays: s.daysToExpiry })),
    });
    const recipe = createRecipe(db, hid(req), {
      title: g.title, summary: g.summary, cuisine: g.cuisine, tags: [...g.tags, 'ai'], diet: g.diet, difficulty: g.difficulty, servings: g.servings, prep_minutes: g.prep_minutes, cook_minutes: g.cook_minutes,
      emoji: g.emoji, color: '#6B5CA5', origin: 'ai', source_name: `AI-generated (${ai.model()})`, attribution: 'Generated by AI. Check quantities, cooking times and allergens.',
      steps: g.steps.map((s) => ({ text: s.text, timerSeconds: s.timerSeconds ?? undefined })),
      ingredients: normaliseIngredients(hid(req), g.ingredients.map((i) => ({ name: i.name, quantity: i.quantity, unit: i.unit, display: i.display, optional: i.optional }))),
    });
    return { recipe, aiNutritionPerServing: g.nutritionPerServing };
  });
  const cookInput = z.object({
    servings: z.number().min(0.5).max(40).optional(),
    overrides: z.array(z.object({ position: z.number().int().min(0), quantity: num.min(0).optional(), productId: z.string().optional() })).max(60).optional(),
    leftovers: z.object({ fridge: z.number().int().min(0).max(40).optional(), freezer: z.number().int().min(0).max(40).optional() }).optional(),
    deduct: z.boolean().optional(),
    clientRequestId,
  });
  r.post('/api/recipes/:id/cook', (req) => {
    const b = validate(cookInput, req.body);
    const recipe = getRecipe(db, hid(req), req.params.id);
    const slot = todaysMeals(db, hid(req)).find((s) => s.recipe_id === recipe.id && s.status === 'planned');
    const res = once(db, req, 'recipe', b.clientRequestId, (ctx) => cookRecipe(ctx, { recipeId: recipe.id, servings: b.servings ?? slot?.servings ?? recipe.servings, overrides: b.overrides, leftovers: b.leftovers, mealSlotId: slot?.id ?? null, deduct: b.deduct ?? interactionPrefs(db, hid(req)).autoDeduct }));
    replan(hid(req));
    return { ...res, reward: res.duplicate ? null : rewardFor(db, hid(req), res.batchId, evaluateJourney(db, hid(req))) };
  });
  // How much of a fat or marinade counts as eaten (default: all of it).
  r.put('/api/recipes/:id/retention', (req) => {
    const b = validate(z.object({ position: z.number().int().min(0), retention: z.number().min(0.1).max(1).nullable() }), req.body);
    return setRetention(db, hid(req), req.params.id, b.position, b.retention);
  });
  r.post('/api/recipes/:id/interaction', (req) => {
    const b = validate(z.object({ saved: z.boolean().optional(), rating: z.number().int().min(1).max(5).optional().nullable(), priority: z.number().int().min(-2).max(2).optional(), notes: z.string().max(4000).optional().nullable(), toTry: z.boolean().optional(), ease: z.number().int().min(1).max(3).optional().nullable(), again: z.boolean().optional().nullable() }), req.body);
    getRecipe(db, hid(req), req.params.id);
    recordInteraction(db, hid(req), req.params.id, b);
    return { ok: true };
  });

  // ---------- Analytics, nutrition, notifications, export ----------
  r.get('/api/analytics', (req) => analytics(db, hid(req), Math.min(365, Number(req.query.get('days') ?? 90))));
  r.get('/api/game', (req) => {
    // Pick up rewards earned with friends now and then, also for people who don't open the Friends screen.
    if (Date.now() - (settledAt.get(req.user!.id) ?? 0) > 60_000) settle(req.user!);
    return { ...game(db, hid(req)), accents: ACCENTS };
  });
  // Progress settings: XP per action, nutrition targets, accent colour (unlocked by rank).
  r.put('/api/game/settings', (req) => {
    const xpKeys = Object.keys(DEFAULT_XP) as (keyof typeof DEFAULT_XP)[];
    const b = validate(z.object({
      xpRules: z.object(Object.fromEntries(xpKeys.map((k) => [k, z.number().int().min(0).max(500).optional()]))).optional(),
      accent: z.string().max(20).optional(),
      nutritionTargets: z.object({ fibre: z.number().min(10).max(80).optional(), saltMax: z.number().min(1).max(15).optional(), satFatPct: z.number().min(5).max(20).optional(), sugarPct: z.number().min(5).max(30).optional() }).optional(),
    }), req.body);
    if (b.xpRules) prefSet(hid(req), 'xpRules', b.xpRules);
    if (b.nutritionTargets) prefSet(hid(req), 'nutritionTargets', b.nutritionTargets);
    if (b.accent) {
      if (!ACCENTS[b.accent]) throw badRequest('Unknown accent');
      const rank = levelFor(game(db, hid(req)).xp).rank;
      const needed = RANKS.findIndex((r) => r.accent === b.accent);
      if (needed > rank) throw new AppError(403, 'locked', `Unlocks at ${RANKS[needed].name}`);
      prefSet(hid(req), 'accent', b.accent);
    }
    bus.touch(hid(req), 'preferences');
    return { ok: true };
  });
  r.post('/api/game/challenge', (req) => {
    const b = validate(z.object({ id: z.enum(CHALLENGES.map((c) => c.id) as [string, ...string[]]) }), req.body);
    prefSet(hid(req), 'challenge', { id: b.id, start: clock.today() });
    bus.touch(hid(req), 'preferences');
    return game(db, hid(req)).challenge;
  });
  r.delete('/api/game/challenge', (req) => {
    db.run("DELETE FROM preferences WHERE household_id = ? AND user_id = '' AND key = 'challenge'", hid(req));
    bus.touch(hid(req), 'preferences');
    return { ok: true };
  });
  // ---------- Journey (progress path) ----------
  r.get('/api/journey', (req) => journey(db, hid(req)));
  // Cheap check for "you just moved forward" toasts anywhere in the app.
  // Everything you've earned, newest first: journey steps, chests, chapter challenges, bonus tasks,
  // skill-track levels, badges and finished challenges.
  r.get('/api/achievements', (req) => {
    const h = hid(req);
    evaluateJourney(db, h);
    const g = game(db, h);
    const kinds: Record<string, string> = { task: 'journey', milestone: 'chest', boss: 'chapter', bonus: 'bonus', track: 'track' };
    const items: { id: string; group: string; title: string; title_nl: string; desc?: string; desc_nl?: string; emoji: string; xp: number; at: string | null }[] = db
      .all<{ node_id: string; kind: string; xp: number; completed_at: string }>('SELECT node_id, kind, xp, completed_at FROM journey_nodes WHERE household_id = ?', h)
      .map((n) => ({ id: n.node_id, group: kinds[n.kind] ?? 'journey', ...describeNode(n.node_id), xp: n.xp, at: n.completed_at }));
    for (const a of g.achievements.filter((x: any) => x.done)) items.push({ id: `badge:${a.id}`, group: 'badge', title: a.title, title_nl: a.title_nl, desc: a.desc, desc_nl: a.desc_nl, emoji: a.emoji, xp: a.xp, at: null });
    for (const c of g.challenge.completed) {
      const def = CHALLENGES.find((x) => x.id === c.id);
      if (def) items.push({ id: `challenge:${c.id}:${c.at}`, group: 'challenge', title: def.title, title_nl: def.title_nl, desc: def.desc, desc_nl: def.desc_nl, emoji: def.emoji, xp: g.rules.challenge, at: c.at });
    }
    // Earned with friends: duels, team goals, passed recipes, invites, seasonal events.
    for (const s of db.all<{ key: string; xp: number; title: string; title_nl: string; emoji: string; at: string }>('SELECT key, xp, title, title_nl, emoji, at FROM social_rewards WHERE household_id = ?', h)) {
      items.push({ id: `social:${s.key}`, group: 'friends', title: s.title, title_nl: s.title_nl, emoji: s.emoji, xp: s.xp, at: s.at });
    }
    items.sort((a, b) => (b.at ?? '').localeCompare(a.at ?? ''));
    return {
      items,
      total: items.length,
      xp: items.reduce((sum, i) => sum + i.xp, 0),
      level: g.level,
      badges: { done: g.achievements.filter((x: any) => x.done).length, all: g.achievements.length },
    };
  });
  r.get('/api/journey/fresh', (req) => {
    const added = evaluateJourney(db, hid(req));
    if (added.length) bus.touch(hid(req), 'game');
    return db.all<any>('SELECT node_id id, kind, xp, completed_at FROM journey_nodes WHERE household_id = ? AND celebrated = 0 ORDER BY completed_at', hid(req)).map((n) => ({ ...n, ...describeNode(n.id) }));
  });
  r.post('/api/journey/seen', (req) => {
    markCelebrated(db, hid(req));
    return { ok: true };
  });
  r.post('/api/journey/swap', (req) => {
    const b = validate(z.object({ nodeId: z.string().regex(/^c\d:\w+$/) }), req.body);
    const out = swapTask(db, hid(req), b.nodeId);
    bus.touch(hid(req), 'game');
    return out;
  });
  r.put('/api/journey/companion', (req) => {
    const b = validate(z.object({ skin: z.string().max(20).optional(), name: z.string().trim().min(1).max(20).optional() }), req.body);
    const out = setCompanion(db, hid(req), b);
    bus.touch(hid(req), 'game');
    return out;
  });
  r.get('/api/journey/collection/:id', (req) => {
    const j = journey(db, hid(req));
    const c = j.collections.find((x) => x.id === req.params.id);
    if (!c) throw new AppError(404, 'not_found', 'Unknown collection');
    if (!c.unlocked) throw new AppError(403, 'locked', `Unlocks when you finish chapter ${c.chapter}`);
    return collection(db, hid(req), c.id);
  });

  // ---------- Friends and leaderboard (per person; only progress numbers are shared) ----------
  r.get('/api/friends', (req) => {
    const me = req.user!;
    settle(me);
    const state = friendsState(db, me);
    const play = playState(db, me, state);
    return { ...friendsOverview(db, me, state, play.leagueOf), social: play.view };
  });
  // Rewards earned with friends (duels, team goals, passed recipes, invites, events), recorded once.
  const settledAt = new Map<string, number>();
  const settle = (me: { id: string; name: string; household_id: string }) => {
    settledAt.set(me.id, Date.now());
    for (const h of db.tx(() => settleSocial(db, me))) bus.touch(h, 'game');
  };
  const pushUser = (u: { id: string; household_id: string }, title: string, body: string) =>
    pushToHousehold(db, u.household_id, { title, body, tag: 'friend', url: '/#/friends' }, u.id).catch((e) => log.warn('friend push failed', { err: e?.message }));
  const touchBoth = (req: Req, other: { household_id: string } | null | undefined) => {
    bus.touch(hid(req), 'friends');
    if (other) bus.touch(other.household_id, 'friends');
  };
  r.post('/api/friends/:id/privacy', (req) => {
    const b = validate(z.object({ level: z.enum(['all', 'streak']) }), req.body);
    setPrivacy(db, req.user!.id, req.params.id, b.level);
    const other = db.get<{ household_id: string }>('SELECT household_id FROM users WHERE id = ?', req.params.id);
    touchBoth(req, other);
    return { ok: true };
  });
  r.post('/api/social/cheer', (req) => {
    const b = validate(z.object({ to: z.string().min(3).max(60), kind: z.enum(['cheer', 'nudge']), ref: z.string().max(60).optional().nullable(), label: z.string().max(80).optional().nullable() }), req.body);
    const to = sendCheer(db, req.user!, b.to, b.kind, b.ref ?? null);
    if (b.kind === 'nudge') pushUser(to, `🔥 ${req.user!.name} says: cook today!`, 'Keep your cooking streak going.');
    else pushUser(to, `👏 ${req.user!.name} cheered you on`, b.label ? `For ${b.label}` : 'Nice cooking!');
    touchBoth(req, to);
    return { ok: true };
  });
  r.put('/api/social/nudges', (req) => {
    setNudges(db, req.user!, validate(z.object({ on: z.boolean() }), req.body).on);
    bus.touch(hid(req), 'friends');
    return { ok: true };
  });
  r.post('/api/social/seen', (req) => {
    markSeen(db, req.user!);
    return { ok: true };
  });
  r.post('/api/social/duels', (req) => {
    const b = validate(z.object({ friendId: z.string().min(3).max(60) }), req.body);
    const out = db.tx(() => createDuel(db, req.user!, b.friendId));
    pushUser(out.other, `⚔️ ${req.user!.name} challenges you to a duel`, 'Most XP by Sunday wins.');
    touchBoth(req, out.other);
    return { id: out.id };
  });
  r.post('/api/social/duels/:id', (req) => {
    const b = validate(z.object({ accept: z.boolean() }), req.body);
    const other = answerDuel(db, req.user!, req.params.id, b.accept);
    if (b.accept) pushUser(other, `⚔️ ${req.user!.name} accepted your duel`, 'Most XP by Sunday wins.');
    touchBoth(req, other);
    return { ok: true };
  });
  r.post('/api/social/pass', (req) => {
    const b = validate(z.object({ to: z.array(z.string().min(3).max(60)).min(1).max(20), recipeId: z.string().min(1).max(80), note: z.string().trim().max(200).optional().nullable() }), req.body);
    for (const id of b.to) {
      const to = db.tx(() => passRecipe(db, req.user!, id, b.recipeId, b.note || null));
      pushUser(to, `📨 ${req.user!.name} sent you a recipe`, 'Add it to your to-try list.');
      touchBoth(req, to);
    }
    return { ok: true };
  });
  r.post('/api/social/pass/:id', (req) => {
    const b = validate(z.object({ add: z.boolean() }), req.body);
    const recipeId = db.tx(() => answerPass(db, req.user!, req.params.id, b.add));
    bus.touch(hid(req), 'friends');
    if (recipeId) bus.touch(hid(req), 'recipes');
    return { recipeId };
  });
  r.post('/api/social/groups', (req) => {
    const b = validate(z.object({ kind: z.enum(['challenge', 'goal']), ref: z.string().min(1).max(40), target: z.number().int().min(2).max(1000).optional().nullable(), friends: z.array(z.string().min(3).max(60)).min(1).max(50) }), req.body);
    const out = db.tx(() => createGroup(db, req.user!, b));
    for (const p of out.people) {
      pushUser(p, b.kind === 'challenge' ? `🎯 ${req.user!.name} invites you to a challenge` : `🎁 ${req.user!.name} invites you to a team goal`, 'Join from the Friends screen.');
      bus.touch(p.household_id, 'friends');
    }
    bus.touch(hid(req), 'friends');
    bus.touch(hid(req), 'preferences');
    return { id: out.id };
  });
  r.post('/api/social/groups/:id', (req) => {
    const b = validate(z.object({ join: z.boolean() }), req.body);
    const by = db.tx(() => answerGroup(db, req.user!, req.params.id, b.join));
    touchBoth(req, by);
    bus.touch(hid(req), 'preferences');
    return { ok: true };
  });
  r.post('/api/friends/code', (req) => {
    const code = resetFriendCode(db, req.user!.id);
    bus.touch(hid(req), 'friends');
    return { code };
  });
  r.get('/api/friends/requests/count', (req) => ({ incoming: incomingCount(db, req.user!.id) }));
  // Tell the other person: a request on their phone, or that you accepted theirs.
  const notifyFriend = (me: { name: string }, other: { id: string; householdId: string }, accepted: boolean) => {
    bus.touch(other.householdId, 'friends');
    pushToHousehold(db, other.householdId, accepted
      ? { title: `${me.name} is now your friend`, body: 'You can see each other’s streaks and the leaderboard.', tag: 'friend', url: '/#/friends' }
      : { title: `${me.name} wants to be friends`, body: 'Accept to see each other’s cooking streaks and the leaderboard.', tag: 'friend', url: '/#/friends' }, other.id)
      .catch((e) => log.warn('friend push failed', { err: e?.message }));
  };
  r.post('/api/friends/request', (req) => {
    const b = validate(z.union([
      z.object({ code: z.string().trim().min(4).max(300) }),
      z.object({ userId: z.string().min(3).max(60), match: z.string().min(10).max(100) }),
    ]), req.body);
    // Codes are hard to guess; this keeps it that way.
    const key = `friend:${req.user!.id}`;
    checkRateLimit(key);
    let out;
    try {
      out = db.tx(() => ('code' in b ? requestFriend(db, req.user!, b.code) : requestByContact(db, req.user!, b.userId, b.match)));
    } catch (e) {
      if (e instanceof AppError && (e.code === 'invalid_code' || e.code === 'not_found')) recordFailure(key);
      throw e;
    }
    bus.touch(hid(req), 'friends');
    if (out.changed) notifyFriend(req.user!, out.other, out.accepted);
    return { state: out.state, name: out.name };
  });
  r.post('/api/friends/requests/:id/accept', (req) => {
    const other = acceptRequest(db, req.user!.id, req.params.id);
    bus.touch(hid(req), 'friends');
    notifyFriend(req.user!, other, true);
    return { ok: true };
  });
  // Your phone number, so people who have it in their contacts can find you (opt-in, stored hashed).
  r.put('/api/friends/phone', (req) => {
    const b = validate(z.object({ phone: z.string().trim().min(6).max(40).optional(), discoverable: z.boolean() }), req.body);
    const out = b.phone ? setMyPhone(db, req.user!, b.phone, b.discoverable) : (setDiscoverable(db, req.user!.id, b.discoverable), myPhone(db, req.user!.id));
    bus.touch(hid(req), 'friends');
    return { phone: out };
  });
  r.delete('/api/friends/phone', (req) => {
    removeMyPhone(db, req.user!.id);
    bus.touch(hid(req), 'friends');
    return { ok: true };
  });
  // Which of your contacts use PantryPip and can be found by number. Numbers are hashed, not kept.
  r.post('/api/friends/contacts', (req) => {
    const b = validate(z.object({ numbers: z.array(z.string().max(40)).max(1000) }), req.body);
    return { matches: matchContacts(db, req.user!, b.numbers) };
  });
  r.delete('/api/friends/requests/:id', (req) => {
    const other = dropRequest(db, req.user!.id, req.params.id);
    bus.touch(hid(req), 'friends');
    bus.touch(other, 'friends');
    return { ok: true };
  });
  r.delete('/api/friends/:id', (req) => {
    const other = removeFriend(db, req.user!.id, req.params.id);
    bus.touch(hid(req), 'friends');
    bus.touch(other, 'friends');
    return { ok: true };
  });

  // ---------- Shared shopping lists (between friends; members only; stock goes to whoever bought it) ----------
  const listName = z.string().trim().min(1).max(60);
  const people = z.array(z.string().min(3).max(60)).max(MAX_MEMBERS);
  const listPush = (to: { id: string; household_id: string }[], title: string, body: string, listId: string) => {
    for (const u of to) pushToHousehold(db, u.household_id, { title, body, tag: `shared-${listId}`, url: `/#/shared/${listId}` }, u.id).catch((e) => log.warn('shared list push failed', { err: e?.message }));
  };
  r.get('/api/shared-lists', (req) => sharedListsFor(db, req.user!));
  r.post('/api/shared-lists', (req) => {
    const b = validate(z.object({ name: listName, friends: people.default([]) }), req.body);
    const out = db.tx(() => createSharedList(db, req.user!, b.name, b.friends));
    listPush(out.invited, `🧺 ${req.user!.name} shares a shopping list`, `“${b.name}”: join to shop together.`, out.id);
    return reply({ status: 201, body: { id: out.id } });
  });
  r.get('/api/shared-lists/:id', (req) => getSharedList(db, req.user!, req.params.id));
  r.patch('/api/shared-lists/:id', (req) => {
    renameSharedList(db, req.user!, req.params.id, validate(z.object({ name: listName }), req.body).name);
    return { ok: true };
  });
  r.delete('/api/shared-lists/:id', (req) => {
    deleteSharedList(db, req.user!, req.params.id);
    return { ok: true };
  });
  r.post('/api/shared-lists/:id/invite', (req) => {
    const b = validate(z.object({ friends: people.min(1) }), req.body);
    const out = db.tx(() => inviteToList(db, req.user!, req.params.id, b.friends));
    listPush(out.invited, `🧺 ${req.user!.name} shares a shopping list`, `“${out.name}”: join to shop together.`, req.params.id);
    return { invited: out.invited.length };
  });
  r.post('/api/shared-lists/:id/answer', (req) => {
    const b = validate(z.object({ join: z.boolean() }), req.body);
    answerInvite(db, req.user!, req.params.id, b.join);
    return { ok: true };
  });
  r.delete('/api/shared-lists/:id/members/:userId', (req) => {
    db.tx(() => removeMember(db, req.user!, req.params.id, req.params.userId));
    return { ok: true };
  });
  const sharedItem = z.object({ name: z.string().trim().max(120).optional(), productId: z.string().max(60).optional().nullable(), packages: z.number().int().min(1).max(99).optional().nullable(), note: z.string().max(200).optional().nullable() });
  r.post('/api/shared-lists/:id/items', (req) => {
    const b = validate(sharedItem, req.body);
    if (!b.name && !b.productId) throw badRequest('name or productId is required');
    return db.tx(() => addSharedItem(db, req.user!, req.params.id, b));
  });
  r.patch('/api/shared-lists/:id/items/:itemId', (req) => {
    const b = validate(z.object({ checked: z.boolean().optional(), claimed: z.boolean().optional(), packages: z.number().int().min(1).max(99).optional(), note: z.string().max(200).optional().nullable(), name: z.string().trim().min(1).max(120).optional() }), req.body);
    return db.tx(() => updateSharedItem(db, req.user!, req.params.id, req.params.itemId, b));
  });
  r.delete('/api/shared-lists/:id/items/:itemId', (req) => {
    removeSharedItem(db, req.user!, req.params.id, req.params.itemId);
    return { ok: true };
  });
  r.post('/api/shared-lists/:id/finish', (req) => {
    const b = validate(z.object({ store: z.string().max(60).optional().nullable(), clientRequestId }), req.body);
    return once(db, req, 'shopping_list', b.clientRequestId, (ctx) => finishSharedList(ctx, req.user!, req.params.id, b.store));
  });
  r.post('/api/shared-lists/:id/clear-bought', (req) => ({ removed: clearBought(db, req.user!, req.params.id) }));

  // ---------- Dashboard (per person) ----------
  const widgetSchema = z.object({ id: z.string().min(1).max(40), type: z.enum(WIDGET_TYPES as [string, ...string[]]), size: z.enum(['s', 'm', 'l']), view: z.enum(['compact', 'expanded']), pinned: z.boolean().optional(), hidden: z.boolean().optional() });
  const layoutSchema = z.array(widgetSchema).max(60);
  const dashSchema = z.object({
    version: z.literal(1),
    active: z.string().min(1).max(40),
    profiles: z.array(z.object({ id: z.string().min(1).max(40), name: z.string().trim().min(1).max(30), preset: z.string().max(30), layouts: z.object({ phone: layoutSchema.optional(), tablet: layoutSchema.optional(), desktop: layoutSchema.optional() }) })).min(1).max(8),
  });
  const deviceOf = (req: any) => (['phone', 'tablet', 'desktop'].includes(req.query.get('device') ?? '') ? req.query.get('device') : 'phone') as 'phone' | 'tablet' | 'desktop';
  r.get('/api/dashboard', (req) => ({
    config: getDashboard(db, hid(req), req.user!.id),
    widgets: WIDGETS,
    presets: PRESETS,
    suggestions: dashboardSuggestions(db, hid(req), req.user!.id, deviceOf(req)),
  }));
  r.put('/api/dashboard', (req) => {
    const cfg = saveDashboard(db, hid(req), req.user!.id, validate(dashSchema, req.body) as any);
    bus.touch(hid(req), 'dashboard'); // your other devices pick it up
    return { config: cfg };
  });
  r.post('/api/dashboard/reset', (req) => {
    const config = saveDashboard(db, hid(req), req.user!.id, defaultConfig());
    bus.touch(hid(req), 'dashboard');
    return { config };
  });
  r.get('/api/dashboard/data', (req) => dashboardData(db, hid(req), (req.query.get('types') ?? '').split(',').filter((t) => WIDGET_TYPES.includes(t)).slice(0, 60)));
  r.post('/api/dashboard/usage', (req) => {
    const b = validate(z.object({ key: z.string().regex(/^(open|widget|recipe):[\w-]{1,40}$/) }), req.body);
    recordUsage(db, hid(req), req.user!.id, b.key);
    return { ok: true };
  });
  r.post('/api/dashboard/suggestions/:id/dismiss', (req) => {
    dismissSuggestion(db, hid(req), req.user!.id, req.params.id.slice(0, 40));
    return { ok: true };
  });

  // ---------- Personal settings (per person: appearance) ----------
  const appearanceSchema = z.object({
    style: z.enum(['larder', 'lavender', 'herb', 'citrus', 'night', 'ink', 'editorial', 'grocer', 'skog', 'dot', 'epicerie', 'monoline', 'raster', 'seventies', 'suite']).optional(), theme: z.enum(['system', 'light', 'dark']).optional(), density: z.enum(['comfortable', 'compact']).optional(), cards: z.enum(['soft', 'outlined', 'flat']).optional(),
    motion: z.enum(['full', 'reduced', 'off']).optional(), textSize: z.enum(['normal', 'large']).optional(), showMoney: z.boolean().optional(), minimal: z.boolean().optional(),
  });
  r.get('/api/preferences/me', (req) => ({ appearance: parseJson(db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = ? AND key = 'appearance'", hid(req), req.user!.id)?.value, {}) }));
  r.put('/api/preferences/me', (req) => {
    const b = validate(z.object({ appearance: appearanceSchema }), req.body);
    const cur = parseJson<Record<string, unknown>>(db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = ? AND key = 'appearance'", hid(req), req.user!.id)?.value, {});
    const next = { ...cur, ...b.appearance };
    db.run("INSERT INTO preferences (household_id, user_id, key, value) VALUES (?, ?, 'appearance', ?) ON CONFLICT(household_id, user_id, key) DO UPDATE SET value = excluded.value", hid(req), req.user!.id, JSON.stringify(next));
    return { appearance: next };
  });

  r.get('/api/stats/fun', (req) => {
    const period = req.query.get('period') ?? 'year';
    if (!['month', 'year', 'all'].includes(period)) throw badRequest('period must be month, year or all');
    return funStats(db, hid(req), period as Period);
  });
  r.get('/api/notifications', (req) => db.all('SELECT * FROM notifications WHERE household_id = ? ORDER BY created_at DESC LIMIT 30', hid(req)));
  r.post('/api/notifications/read', (req) => {
    db.run('UPDATE notifications SET read = 1 WHERE household_id = ?', hid(req));
    return { ok: true };
  });
  r.get('/api/export', (req) => {
    const h = hid(req);
    const tables = ['inventory_lots', 'inventory_events', 'purchases', 'receipts', 'receipt_aliases', 'shopping_items', 'meal_slots', 'recipe_interactions', 'preferences', 'suggestion_feedback', 'journey_chapters', 'journey_nodes'];
    const data: Record<string, unknown[]> = {};
    for (const t of tables) data[t] = db.all(`SELECT * FROM ${t} WHERE household_id = ?`, h).map((row) => (t === 'preferences' && row.key === 'deviceToken' ? { ...row, value: '"<redacted>"' } : row));
    data.products = db.all('SELECT * FROM products WHERE household_id = ?', h);
    data.recipes = db.all('SELECT * FROM recipes WHERE household_id = ?', h);
    return reply({ body: { exportedAt: clock.iso(), household: db.get('SELECT id, name, locale, created_at FROM households WHERE id = ?', h), data }, headers: { 'Content-Disposition': `attachment; filename="larder-export-${clock.today()}.json"` } });
  });

  return r;
}
