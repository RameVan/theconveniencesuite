// Minimal HTTP layer on node:http: routing, JSON bodies, validation, cookies, SSE and static files.
import http from 'node:http';
import { createReadStream, existsSync, readFileSync, statSync } from 'node:fs';
import { gzipSync } from 'node:zlib';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import * as z from 'zod/v4';
import type { Db } from '../db/db.ts';
import { AppError, unauthorized } from '../errors.ts';
import { log } from '../log.ts';
import { config } from '../config.ts';
import { COOKIE, userForToken, type SessionUser } from './auth.ts';

export interface Req {
  method: string;
  path: string;
  params: Record<string, string>;
  query: URLSearchParams;
  body: any;
  user: SessionUser | null;
  cookies: Record<string, string>;
  raw: http.IncomingMessage;
  res: http.ServerResponse;
  ip: string;
}

export interface Res {
  status?: number;
  body?: unknown;
  headers?: Record<string, string>;
  cookies?: string[];
  /** Send as plain text instead of JSON (Siri Shortcuts speak the response directly). */
  text?: string;
  /** Binary body (photos). */
  bytes?: Buffer;
}

const RES = Symbol('response');
/** Wrap a handler result that needs a status code, headers or cookies. Plain return values become 200 JSON. */
export function reply(r: Res): Res {
  return Object.assign(r, { [RES]: true });
}

type Handler = (req: Req) => Promise<Res | unknown> | Res | unknown;
interface Route {
  method: string;
  re: RegExp;
  keys: string[];
  handler: Handler;
  auth: boolean;
  bodyLimit: number;
}

export class Router {
  private routes: Route[] = [];
  add(method: string, pattern: string, handler: Handler, opts: { auth?: boolean; bodyLimit?: number } = {}) {
    const keys: string[] = [];
    const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => (keys.push(k), '([^/]+)')) + '/?$');
    this.routes.push({ method, re, keys, handler, auth: opts.auth ?? true, bodyLimit: opts.bodyLimit ?? 1_000_000 });
  }
  get = (p: string, h: Handler, o?: { auth?: boolean }) => this.add('GET', p, h, o);
  post = (p: string, h: Handler, o?: { auth?: boolean; bodyLimit?: number }) => this.add('POST', p, h, o);
  put = (p: string, h: Handler, o?: { auth?: boolean }) => this.add('PUT', p, h, o);
  patch = (p: string, h: Handler, o?: { auth?: boolean }) => this.add('PATCH', p, h, o);
  delete = (p: string, h: Handler, o?: { auth?: boolean }) => this.add('DELETE', p, h, o);
  match(method: string, p: string) {
    for (const r of this.routes) {
      if (r.method !== method) continue;
      const m = r.re.exec(p);
      if (m) return { route: r, params: Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])])) };
    }
    return null;
  }
}

/** Validate input with a zod schema; failures become 400s with field details. */
export function validate<T extends z.ZodType>(schema: T, data: unknown): z.infer<T> {
  const r = schema.safeParse(data);
  if (!r.success) throw new AppError(400, 'invalid_input', 'Invalid input', r.error.issues.map((i) => ({ path: i.path.join('.'), message: i.message })));
  return r.data;
}

function parseCookies(h: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  for (const part of (h ?? '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

async function readBody(req: http.IncomingMessage, limit: number): Promise<any> {
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const c of req) {
    size += c.length;
    if (size > limit) throw new AppError(413, 'too_large', 'Request body too large');
    chunks.push(c as Buffer);
  }
  if (!size) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw new AppError(400, 'invalid_json', 'Body must be JSON');
  }
}

const SECURITY_HEADERS: Record<string, string> = {
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'same-origin',
  'X-Frame-Options': 'DENY',
  'Permissions-Policy': 'camera=(self), microphone=(self), geolocation=()',
};
const CSP = "default-src 'self'; img-src 'self' data: blob: https:; connect-src 'self' https://cdn.jsdelivr.net https://tessdata.projectnaptha.com; script-src 'self' 'wasm-unsafe-eval' https://cdn.jsdelivr.net blob:; worker-src 'self' blob: https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; media-src 'self' blob:";

const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon', '.json': 'application/json', '.webmanifest': 'application/manifest+json',
  '.wasm': 'application/wasm', '.woff2': 'font/woff2', '.txt': 'text/plain',
};

// Compressed responses: JSON and the app's own text files shrink to a fifth, so a phone spends less time
// (and battery) on the radio. Small bodies aren't worth it.
const COMPRESSIBLE = new Set(['.html', '.js', '.css', '.svg', '.json', '.webmanifest', '.txt']);
const acceptsGzip = (req: http.IncomingMessage) => /\bgzip\b/.test(String(req.headers['accept-encoding'] ?? ''));
const gzipped = new Map<string, { mtime: number; body: Buffer }>();

function serveStatic(req: http.IncomingMessage, res: http.ServerResponse, pathname: string): boolean {
  if (!existsSync(config.webDist)) return false;
  let file = path.join(config.webDist, path.normalize(pathname).replace(/^(\.\.[/\\])+/, ''));
  if (!file.startsWith(config.webDist)) return false;
  if (!existsSync(file) || statSync(file).isDirectory()) file = path.join(config.webDist, 'index.html'); // SPA fallback
  if (!existsSync(file)) return false;
  const ext = path.extname(file);
  const immutable = pathname.startsWith('/assets/');
  const headers: Record<string, string> = {
    ...SECURITY_HEADERS,
    'Content-Security-Policy': CSP,
    'Content-Type': MIME[ext] ?? 'application/octet-stream',
    'Cache-Control': immutable ? 'public, max-age=31536000, immutable' : 'no-cache',
    Vary: 'Accept-Encoding',
  };
  if (COMPRESSIBLE.has(ext) && acceptsGzip(req)) {
    // Compressed once per file version, then served from memory.
    const mtime = statSync(file).mtimeMs;
    let z = gzipped.get(file);
    if (!z || z.mtime !== mtime) gzipped.set(file, (z = { mtime, body: gzipSync(readFileSync(file)) }));
    res.writeHead(200, { ...headers, 'Content-Encoding': 'gzip', 'Content-Length': String(z.body.length) });
    res.end(req.method === 'HEAD' ? undefined : z.body);
    return true;
  }
  res.writeHead(200, headers);
  if (req.method === 'HEAD') res.end();
  else createReadStream(file).pipe(res);
  return true;
}

/** The request handler, shared by the HTTP and HTTPS servers. */
export function createHandler(db: Db, router: Router): http.RequestListener {
  return async (rawReq, res) => {
    const started = Date.now();
    const reqId = randomUUID().slice(0, 8);
    const url = new URL(rawReq.url ?? '/', 'http://localhost');
    const method = rawReq.method ?? 'GET';
    if (!url.pathname.startsWith('/api/')) {
      if ((method === 'GET' || method === 'HEAD') && serveStatic(rawReq, res, url.pathname)) return;
      res.writeHead(404, SECURITY_HEADERS).end('Not found');
      return;
    }
    let status = 200;
    try {
      const m = router.match(method, url.pathname);
      if (!m) throw new AppError(404, 'not_found', 'No such endpoint');
      // CSRF: state-changing requests must be JSON (cross-site forms can't send that without a CORS preflight).
      if (method !== 'GET' && method !== 'HEAD' && rawReq.headers['content-length'] !== '0' && rawReq.headers['content-length'] !== undefined
        && !String(rawReq.headers['content-type'] ?? '').includes('application/json')) {
        throw new AppError(415, 'unsupported_media_type', 'Use application/json');
      }
      const cookies = parseCookies(rawReq.headers.cookie);
      const user = userForToken(db, cookies[COOKIE]);
      if (m.route.auth && !user) throw unauthorized();
      const body = method === 'GET' || method === 'HEAD' ? {} : await readBody(rawReq, m.route.bodyLimit);
      const req: Req = { method, path: url.pathname, params: m.params, query: url.searchParams, body, user, cookies, raw: rawReq, res, ip: rawReq.socket.remoteAddress ?? '' };
      const out = await m.route.handler(req);
      if (res.headersSent) return; // streaming handler (SSE)
      const r: Res = out && typeof out === 'object' && (out as any)[RES] ? (out as Res) : { body: out };
      status = r.status ?? 200;
      const headers: Record<string, string | string[]> = { ...SECURITY_HEADERS, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...(r.headers ?? {}) };
      if (r.cookies?.length) headers['Set-Cookie'] = r.cookies;
      if (r.text !== undefined) headers['Content-Type'] = 'text/plain; charset=utf-8';
      let payload: string | Buffer = r.bytes ?? (r.text !== undefined ? r.text : r.body === undefined ? '' : JSON.stringify(r.body));
      if (!r.bytes && payload.length > 1024 && acceptsGzip(rawReq)) {
        payload = gzipSync(payload, { level: 5 });
        headers['Content-Encoding'] = 'gzip';
        headers.Vary = 'Accept-Encoding';
      }
      res.writeHead(status, headers);
      res.end(payload);
    } catch (e: any) {
      const err = e instanceof AppError ? e : null;
      status = err?.status ?? 500;
      if (!err) log.error('unhandled error', { reqId, path: url.pathname, err: e?.stack ?? String(e) });
      if (!res.headersSent) {
        res.writeHead(status, { ...SECURITY_HEADERS, 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ error: { code: err?.code ?? 'internal', message: err?.message ?? 'Something went wrong', details: err?.details } }));
      }
    } finally {
      if (url.pathname !== '/api/stream') log.info('request', { reqId, method, path: url.pathname, status, ms: Date.now() - started });
    }
  };
}

export function createServer(db: Db, router: Router) {
  return http.createServer(createHandler(db, router));
}

/** True when the browser reached us over HTTPS: directly (TLS socket) or through a proxy such as Tailscale Serve. */
export function isHttps(req: http.IncomingMessage): boolean {
  return !!(req.socket as any).encrypted || req.headers['x-forwarded-proto'] === 'https';
}

export function sessionCookie(token: string, expires: Date, secure = config.cookieSecure) {
  return `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Expires=${expires.toUTCString()}${secure ? '; Secure' : ''}`;
}
export function clearCookie() {
  return `${COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`;
}
