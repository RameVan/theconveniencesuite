// The one page served over plain HTTP: how to trust the local certificate on an iPhone.
export function setupPage(httpsUrl: string, hasCa: boolean): string {
  const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]!);
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>PantryPip: set up your iPhone</title>
<style>
  :root { color-scheme: light dark; --bg: #f6f1e9; --card: #fffdf9; --ink: #1d2420; --muted: #6f776f; --herb: #2f5d50; --line: #e4dccf; }
  @media (prefers-color-scheme: dark) { :root { --bg: #121512; --card: #1c211d; --ink: #eef0ea; --muted: #8d958e; --herb: #7fc0a6; --line: #2c332e; } }
  body { margin: 0; background: var(--bg); color: var(--ink); font: 16px/1.5 -apple-system, system-ui, sans-serif; padding: max(20px, env(safe-area-inset-top)) 16px 40px; }
  main { max-width: 560px; margin: 0 auto; }
  h1 { font: 600 28px Georgia, serif; margin: 8px 0 4px; }
  ol { padding-left: 22px; } li { margin: 10px 0; }
  .card { background: var(--card); border: 1px solid var(--line); border-radius: 16px; padding: 16px; margin: 16px 0; }
  .btn { display: block; text-align: center; background: var(--herb); color: #fff; text-decoration: none; font-weight: 600; padding: 14px; border-radius: 999px; margin: 10px 0; }
  .muted { color: var(--muted); font-size: 14px; } code { font-size: 14px; }
</style></head><body><main>
<h1>PantryPip on your iPhone</h1>
<p class="muted">Camera, microphone and notifications only work over HTTPS. This home server uses its own certificate, so your iPhone needs to trust it once.</p>
${hasCa ? `<div class="card"><b>1. Install the certificate</b>
<a class="btn" href="/setup/larder-ca.crt">Download certificate</a>
<ol>
<li>Tap <b>Allow</b> when Safari asks to download a configuration profile.</li>
<li>Open <b>Settings</b>: tap <b>Profile Downloaded</b> at the top (or General → VPN &amp; Device Management) and tap <b>Install</b>.</li>
<li>Go to <b>Settings → General → About → Certificate Trust Settings</b> and switch on <b>PantryPip local CA</b>.</li>
</ol></div>` : `<div class="card"><b>No certificate yet.</b> On the computer running PantryPip, run <code>npm run cert</code> and restart with <code>npm run start:https</code>.</div>`}
<div class="card"><b>2. Open PantryPip</b>
<a class="btn" href="${esc(httpsUrl)}/">Open ${esc(httpsUrl)}</a>
<p class="muted">Then tap Share → <b>Add to Home Screen</b>. It opens full screen like an app, and can send you the daily cooking question.</p></div>
<p class="muted">Using Tailscale? You can skip the certificate: see docs/IPHONE.md for the one-command setup.</p>
</main></body></html>`;
}
