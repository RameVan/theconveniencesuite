// Siri Shortcuts: "Hey Siri, PantryPip" → dictate → POST /api/shortcut/say → Siri speaks the reply.
// Tokens are stored hashed and only unlock the assistant endpoint.
import { randomBytes, createHash } from 'node:crypto';
import type { Db } from '../db/db.ts';
import { newId } from '../db/db.ts';
import { clock } from '../clock.ts';
import { AppError } from '../errors.ts';
import type { AssistantResponse } from '../assistant/engine.ts';

const sha = (s: string) => createHash('sha256').update(s).digest('hex');

export function createToken(db: Db, householdId: string, userId: string, name: string) {
  const token = `lrd_${randomBytes(24).toString('base64url')}`;
  const id = newId('tok').slice(0, 12);
  db.insert('api_tokens', { id, token_hash: sha(token), household_id: householdId, user_id: userId, name, created_at: clock.iso() });
  return { id, token, name };
}

export function listTokens(db: Db, householdId: string) {
  return db.all('SELECT id, name, created_at, last_used_at FROM api_tokens WHERE household_id = ? ORDER BY created_at DESC', householdId);
}

export function deleteToken(db: Db, householdId: string, id: string) {
  db.run('DELETE FROM api_tokens WHERE id = ? AND household_id = ?', id, householdId);
}

export function tokenUser(db: Db, authorization: string | undefined) {
  const m = authorization?.match(/^Bearer\s+(lrd_[\w-]+)$/);
  if (!m) throw new AppError(401, 'unauthorized', 'Missing or invalid token');
  const row = db.get<{ id: string; household_id: string; user_id: string; conversation_id: string | null }>('SELECT id, household_id, user_id, conversation_id FROM api_tokens WHERE token_hash = ?', sha(m[1]));
  if (!row) throw new AppError(401, 'unauthorized', 'Unknown token');
  return row;
}

export function rememberConversation(db: Db, tokenId: string, conversationId: string) {
  db.run('UPDATE api_tokens SET conversation_id = ?, last_used_at = ? WHERE id = ?', conversationId, clock.iso(), tokenId);
}

/** What Siri should say: the reply, plus the follow-up question and its options. */
export function spokenReply(r: AssistantResponse): string {
  const parts = [r.reply];
  if (r.clarify) {
    const opts = r.clarify.options.map((o) => o.label).slice(0, 4);
    const or = r.lang === 'nl' ? 'of' : 'or';
    parts.push(r.clarify.question + (opts.length ? ` ${opts.slice(0, -1).join(', ')}${opts.length > 1 ? ` ${or} ` : ''}${opts[opts.length - 1]}.` : ''));
    parts.push(r.lang === 'nl' ? 'Start de opdracht nog een keer om te antwoorden.' : 'Run PantryPip again to answer.');
  }
  return parts.filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
}
