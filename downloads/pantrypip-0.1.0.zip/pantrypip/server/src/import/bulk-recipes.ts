// Offline import of large recipe collections into the shared library, from files you downloaded yourself:
// - Wikibooks Cookbook (CC BY-SA 4.0): recipes_parsed.json from huggingface.co/datasets/gossminn/wikibooks-cookbook
// - RecipeNLG (research/education use only, under the agreement you accept when downloading): full_dataset.csv
// Only recipes whose ingredients nearly all match the grocery catalogue get in, so stock, shopping lists,
// nutrition and diets work for them. Each keeps its source link and credit. Nothing is fetched from the internet.
import { createReadStream, readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import type { Db } from '../db/db.ts';
import { listProducts, normalizeText, stem, type Product } from '../domain/products.ts';
import { parseIngredientLine, nameIndex, type DraftIngredient } from '../domain/recipe-import.ts';
import { createRecipe, getRecipe, type RecipeInput } from '../domain/recipes.ts';
import { gramsOf } from '../domain/health.ts';
import { emojiFor } from '../domain/quick-recipe.ts';

export type SourceId = 'recipenlg' | 'wikibooks';
export interface RawRecipe {
  source: SourceId;
  title: string;
  ingredients: string[];
  steps: string[];
  url: string | null;
  servingsText?: string | null;
  timeText?: string | null;
  category?: string | null;
  difficulty?: number | null;
  /** Ingredient names only (RecipeNLG's NER column), for a fast first check. */
  names?: string[];
}

export const ID_PREFIX: Record<SourceId, string> = { recipenlg: 'rx_nlg_', wikibooks: 'rx_wb_' };

// ---------- Reading the files ----------

/** CSV rows from a file of any size (RFC 4180: quoted fields, "" escapes, newlines inside quotes). */
export async function* csvRows(file: string, chunkSize = 1 << 20): AsyncGenerator<string[]> {
  let row: string[] = [];
  let field = '';
  let quoted = false;
  let afterQuote = false;
  // A quote at the very end of a chunk: either the end of the field or the first half of "" (an escaped quote).
  let pendingQuote = false;
  for await (const chunk of createReadStream(file, { encoding: 'utf8', highWaterMark: chunkSize })) {
    const s = chunk as string;
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if (pendingQuote) {
        pendingQuote = false;
        if (c === '"') {
          field += '"';
          continue;
        }
        quoted = false;
        afterQuote = true;
      }
      if (quoted) {
        if (c === '"') {
          if (i === s.length - 1) pendingQuote = true;
          else if (s[i + 1] === '"') { field += '"'; i++; } else { quoted = false; afterQuote = true; }
        } else field += c;
        continue;
      }
      if (c === '"' && !afterQuote && field === '') quoted = true;
      else if (c === ',') { row.push(field); field = ''; afterQuote = false; }
      else if (c === '\n') { row.push(field.endsWith('\r') ? field.slice(0, -1) : field); yield row; row = []; field = ''; afterQuote = false; }
      else field += c;
    }
  }
  if (field || row.length) { row.push(field); yield row; }
}

const list = (s: string | undefined): string[] => {
  if (!s) return [];
  try {
    const v = JSON.parse(s);
    return Array.isArray(v) ? v.map(String) : [];
  } catch {
    return [];
  }
};

/** RecipeNLG full_dataset.csv: ,title,ingredients,directions,link,source,NER. Only "Gathered" rows (better quality). */
export async function* recipeNlg(file: string, onRow?: (n: number) => void): AsyncGenerator<RawRecipe> {
  let header: string[] | null = null;
  let n = 0;
  for await (const row of csvRows(file)) {
    if (!header) {
      header = row.map((h) => h.trim().toLowerCase());
      continue;
    }
    onRow?.(++n);
    const get = (k: string) => row[header!.indexOf(k)];
    const source = get('source');
    if (source && source !== 'Gathered') continue;
    const link = get('link')?.trim();
    yield {
      source: 'recipenlg',
      title: (get('title') ?? '').trim(),
      ingredients: list(get('ingredients')),
      steps: list(get('directions')),
      url: link ? (/^https?:\/\//.test(link) ? link : `https://${link}`) : null,
      names: list(get('ner')),
    };
  }
}

/** Wikibooks Cookbook recipes_parsed.json: [{ filename, recipe_data: { url, title, infobox, text_lines } }]. */
export function* wikibooks(file: string): Generator<RawRecipe> {
  const data = JSON.parse(readFileSync(file, 'utf8'));
  for (const rec of Array.isArray(data) ? data : []) {
    const d = rec?.recipe_data;
    if (!d?.title) continue;
    const lines: { text: string; line_type: string; section: string | null }[] = d.text_lines ?? [];
    const ingredients = lines.filter((l) => /ingredient/i.test(l.section ?? '') && (l.line_type === 'ul' || l.line_type === 'ol')).map((l) => l.text);
    let steps = lines.filter((l) => /procedure|method|direction|preparation|instruction|steps|cooking/i.test(l.section ?? '') && l.line_type !== 'blockquote').map((l) => l.text);
    if (!steps.length) steps = lines.filter((l) => l.line_type === 'ol' && !/ingredient/i.test(l.section ?? '')).map((l) => l.text);
    const url = typeof d.url === 'string' ? (d.url.startsWith('http') ? d.url : `https://en.wikibooks.org${d.url}`) : null;
    yield {
      source: 'wikibooks',
      title: String(d.title).trim(),
      ingredients,
      steps,
      url,
      servingsText: d.infobox?.servings ?? null,
      timeText: d.infobox?.time ?? null,
      category: d.infobox?.category ? decodeURIComponent(String(d.infobox.category)).replace(/^.*Category:/, '').replace(/[_&].*$|_/g, ' ').replace(/_/g, ' ') : null,
      difficulty: typeof d.infobox?.difficulty === 'number' ? d.infobox.difficulty : null,
    };
  }
}

// ---------- Matching and checking ----------

/** "1 c. sugar", "1 (10 oz.) can soup", "2 T butter" → units the line parser knows. */
export function normaliseLine(s: string): string {
  return s
    // Spelling, not identity: the same thing under another name.
    .replace(/\bground\s+(?:red\s+or\s+)?black\s+pepper\b|\bground\s+red\s+or\s+black\s+pepper\b/gi, 'black pepper')
    .replace(/^(\d+(?:\.\d+)?)\s*(?:tablespoons?\s+|teaspoons?\s+)?(?:[a-z]+\s+)?(?:bouillon|stock)\s+cubes?\b/i, '$1 stock cubes')
    // English "paprika" by the spoonful is the spice (in Dutch it is a bell pepper).
    .replace(/^(?=.*\b(tsp|tbsp|teaspoons?|tablespoons?|pinch(?:es)?|dash(?:es)?|sprinkle|ground|smoked|sweet|hot|mild|hungarian|spanish|to taste)\b)(.*?)\bpaprika\b(?!\s*powder)/i, '$2paprika powder')
    .replace(/\s+with\s+chicory(\s+root)?/i, '') // coffee with chicory is still coffee
    .replace(/^(\d+|a|one)\s+(?:tea\s*)?bags?\s+(?:of\s+)?(?=.*\btea\b)/i, '$1 ') // one teabag, not a box of them
    .replace(/(\d+(?:\.\d+)?(?:\s+\d+\/\d+)?|\d+\/\d+)\s*(?:ea\.?|each|whole)?\s*\(\s*(?:\d+(?:\.\d+)?\s*(?:-|–|to)\s*)?(\d+(?:\.\d+)?)\s*-?\s*(oz|ounces?|g|grams?|ml|lbs?|pounds?)\.?\s*\)\s*(?:cans?|pkgs?|packages?|jars?|boxes?|bags?|bottles?|containers?|cartons?|tins?)?\.?/i, (m: string, n: string, size: string, unit: string) => {
      // "5 ea. (15 ounces) cod fillets" gives the total; "2 (15 oz) cans" the size of each can.
      if (/\bea\b/i.test(m) && !/\)\s*[a-z]/i.test(m)) return `${size} ${unit.toLowerCase()} `;
      const count = n.includes('/') ? n.split(/\s+/).reduce((t, p) => t + (p.includes('/') ? Number(p.split('/')[0]) / Number(p.split('/')[1]) : Number(p)), 0) : Number(n);
      return `${Math.round(count * Number(size) * 100) / 100} ${unit.toLowerCase()} `;
    })
    .replace(/(\d)\s*T\.?(?=\s)/g, '$1 tbsp')
    .replace(/(\d)\s*t\.?(?=\s)/g, '$1 tsp')
    .replace(/(\d)\s*c\.?(?=\s)/gi, '$1 cup')
    .replace(/\b(tbsp|tsp|oz|lbs?|pkgs?|qt|pt|tbs|tbl|gal)\.(?=\s|$)/gi, '$1')
    .replace(/\s+/g, ' ')
    .trim();
}

// Ingredients that don't need a product to count as "matched".
const FREE = /^(water|cold water|hot water|boiling water|warm water|ice|ice cubes|ice water|salt and pepper|salt & pepper|cooking spray|nonstick cooking spray|non-stick spray)$/i;

/** Fast check on ingredient names alone: share that a catalogue product covers. */
export function nameMatcher(products: Product[]) {
  const entries: string[][] = [];
  for (const p of products) for (const n of new Set([p.name, ...p.synonyms])) {
    const w = normalizeText(n).split(' ').filter(Boolean).map(stem);
    if (w.length) entries.push(w);
  }
  const byWord = new Map<string, string[][]>();
  for (const e of entries) for (const w of e) (byWord.get(w) ?? byWord.set(w, []).get(w)!).push(e);
  const memo = new Map<string, boolean>();
  const hit = (name: string) => {
    const key = name.toLowerCase().trim();
    let v = memo.get(key);
    if (v === undefined) {
      const words = new Set(normalizeText(key).split(' ').filter(Boolean).map(stem));
      v = FREE.test(key) || [...words].some((w) => (byWord.get(w) ?? []).some((e) => e.every((x) => words.has(x))));
      if (memo.size < 300_000) memo.set(key, v);
    }
    return v;
  };
  return (names: string[]) => {
    const ns = names.filter((n) => n.trim());
    return ns.length ? ns.filter(hit).length / ns.length : 0;
  };
}

const TAGS: [string, RegExp][] = [
  ['drink', /\b(coffee|espresso|cappuccino|chai|lassi|horchata|london fog|tea|punch|smoothie|lemonade|cocktail|shake|cider|eggnog|liqueur|drink|latte|sangria|margarita|daiquiri|hot chocolate|cocoa)\b/],
  ['dessert', /\b(cake|cakes|cookie|cookies|brownies?|pudding|fudge|candy|frosting|icing|cheesecake|cobbler|crumble|ice cream|sorbet|mousse|truffles?|toffee|caramels?|meringues?|cupcakes?|dessert|doughnuts?|donuts?|macaroons?|pralines?|brittle|bonbons?|jell-?o|marshmallows?|whipped topping|cool whip|tarts?|pastry|pastries|strudel|baklava|tiramisu|parfait|trifle|sundae|cinnamon rolls?|sweet rolls?|bars|squares|blondies)\b|\b(apple|cherry|pumpkin|pecan|lemon|key lime|peach|blueberry|strawberry|chocolate|cream|custard|sweet potato|rhubarb|coconut|banana) (pie|crisp)\b/],
  ['baking', /\b(bread|breads|rolls|biscuits?|muffins?|scones?|loaf|buns|bagels?|pretzels?|crackers?|dough|focaccia|brioche|cornbread|flatbread)\b/],
  ['breakfast', /\b(pancakes?|waffles?|oatmeal|porridge|granola|french toast|breakfast|crepes?|hash browns|muesli)\b/],
  ['side', /\b(sauce|dressing|gravy|marinade|relish|jam|jelly|preserves|pickles?|pickled|chutney|seasoning|rub|syrup|glaze|stuffing|vinaigrette|aioli|mayonnaise|pesto|salsa|guacamole|hummus|dip|spread|butter|filling|topping|crust|batter|base|paste|stock|broth|spice blend|spice mix|masala|croutons)\b/],
  ['snack', /\b(chips|popcorn|snack|trail mix|appetizers?|deviled|canapes?|bruschetta|nachos|party mix|spiced nuts)\b/],
  ['sandwich', /\b(sandwich|sandwiches|panini|sloppy joes?)\b/],
  ['soup', /\b(soup|chowder|bisque|stew|broth|gumbo|chili)\b/],
  ['salad', /\bsalad\b/],
  ['pasta', /\b(pasta|spaghetti|lasagn[ae]|macaroni|penne|fettuccine|linguine|noodles?|ravioli|tortellini|gnocchi)\b/],
  ['curry', /\bcurry\b/],
];
const NOT_DINNER = new Set(['drink', 'dessert', 'baking', 'breakfast', 'side', 'snack', 'sandwich']);

const GENERIC = new Set(['easy', 'quick', 'simple', 'best', 'homemade', 'classic', 'recipe', 'style', 'roast', 'roasted', 'baked', 'fried', 'grilled', 'steamed', 'boiled', 'stuffed', 'spicy', 'sweet', 'sour', 'hot', 'cold', 'fresh', 'with', 'and', 'the', 'for', 'old', 'fashioned', 'mom', 'grandma', 'ii', 'iii', 'basic', 'perfect', 'special', 'famous', 'favorite', 'favourite', 'delicious', 'minute', 'brined', 'slow', 'cooker', 'cooked', 'instant', 'pot', 'one', 'pan', 'sheet', 'skillet', 'salad', 'soup', 'stew', 'sauce', 'dish', 'bake', 'casserole', 'cake', 'pie']);
/** Meaningful (stemmed) words of a title or ingredient name. */
function contentWords(s: string): string[] {
  return normalizeText(s).split(' ').filter((w) => w.length > 2 && !GENERIC.has(w) && !/^\d/.test(w)).map(stem);
}

export function tagsFor(title: string, category?: string | null): string[] {
  const t = `${title} ${category ?? ''}`.toLowerCase();
  const tags = TAGS.filter(([, re]) => re.test(t)).map(([tag]) => tag);
  // A main course named after its sauce ("chicken in mushroom sauce") is still a dinner.
  if (tags.includes('side') && /\b(chicken|beef|pork|fish|salmon|shrimp|meatballs?|pasta|spaghetti|steak|tofu|lamb|turkey)\b/.test(t)) tags.splice(tags.indexOf('side'), 1);
  return tags;
}

const firstNumber = (s: string | null | undefined) => {
  const m = s?.match(/\d+/);
  return m ? Number(m[0]) : null;
};

export function minutesIn(texts: string[]): number {
  let total = 0;
  for (const raw of texts) {
    let t = raw
      .replace(/([a-z])([A-Z])/g, '$1 $2') // "10 minutesCooking: 35" from the infobox
      .replace(/(\d*)\s*½/g, (_, n: string) => String(Number(n || 0) + 0.5)); // "½ hour", "1½ hours"
    // "Prep: 10 minutes Cooking: 35 minutes Total: 45 minutes": the total alone, not all three added up.
    const totalOnly = t.match(/total:\s*(.*)$/i);
    if (totalOnly) t = totalOnly[1];
    for (const m of t.matchAll(/(\d+(?:\.\d+)?)(?:\s*(?:-|–|to)\s*(\d+(?:\.\d+)?))?\s*(hours?|hrs?|h|minutes?|mins?)\b/gi)) {
      const n = Number(m[2] ?? m[1]);
      total += /^h/i.test(m[3]) ? n * 60 : n;
    }
  }
  return Math.min(360, total);
}

export interface Candidate { key: string; id: string; score: number; dinner: boolean; input: RecipeInput }

/**
 * Turn one raw recipe into a library recipe, or null when it doesn't meet the bar: nearly all ingredients
 * matched to products, most with an amount, a real method.
 */
export function buildCandidate(db: Db, raw: RawRecipe, ctx: { index: ReturnType<typeof nameIndex>; lineMemo: Map<string, DraftIngredient> }): Candidate | null {
  const title = raw.title.replace(/\s+/g, ' ').trim();
  if (title.length < 3 || title.length > 90 || raw.ingredients.length < 3 || raw.ingredients.length > 20) return null;
  const steps = raw.steps.map((s) => s.replace(/\s+/g, ' ').trim()).filter((s) => s.length > 2);
  if (!steps.length || steps.join(' ').length < 40) return null;

  const titleWords = new Set(contentWords(title));
  const products = new Map(listProductsCached(db).map((p) => [p.id, p]));
  let counted = 0, matched = 0, withAmount = 0;
  const ingredients: RecipeInput['ingredients'] = [];
  for (const original of raw.ingredients) {
    const line = normaliseLine(original);
    if (!line) continue;
    let d = ctx.lineMemo.get(line);
    if (!d) {
      d = parseIngredientLine(db, '', line, ctx.index, listProductsCached(db));
      if (ctx.lineMemo.size < 500_000) ctx.lineMemo.set(line, d);
    }
    const display = original.trim().slice(0, 200);
    // Tap water is not a product (sparkling, coconut or tonic water are), nor is "cooking spray".
    // Tap water is not a product (sparkling, coconut or tonic water are).
    const tapWater = /\bwater\b/i.test(line) && !/\b(sparkling|soda|tonic|coconut|mineral)\b/i.test(line) && !d.productId;
    if (tapWater || (FREE.test(d.name) && !d.productId)) {
      ingredients.push({ name: d.name, display, optional: d.optional, match: 'unresolved', source_key: 'u:water' });
      continue;
    }
    counted++;
    const p = d.productId ? products.get(d.productId) : undefined;
    if (!p) {
      // The dish's own main ingredient can't be missing ("Roast turkey" without the turkey).
      if (!d.optional && contentWords(d.name).some((w) => titleWords.has(w))) return null;
    } else {
      matched++;
      if (d.quantity != null) withAmount++;
      // Meat and fish without an amount would leave most of the nutrition out.
      else if (!d.optional && (p.category === 'meat_fish' || p.id === 'p_tofu' || p.id === 'p_tempeh')) return null;
    }
    // Ingredients sold in the country but not tracked (hoisin) don't count against the recipe.
    if (!d.productId && d.sourceKey?.startsWith('x:')) counted--;
    ingredients.push({ product_id: d.productId, name: d.productName ?? d.name, quantity: d.quantity, unit: d.unit, display, optional: d.optional, match: d.match, source_key: d.sourceKey });
  }
  if (matched < 3 || matched / Math.max(1, counted) < 0.85 || withAmount / matched < 0.75) return null;

  const tags = tagsFor(title, raw.category);
  const dinner = !tags.some((t) => NOT_DINNER.has(t));
  // Servings: the infobox when there is one, else estimated from the weight of the food.
  const stated = firstNumber(raw.servingsText);
  const servingsEstimated = !stated || stated > 40;
  let servings = stated ?? 4;
  if (servingsEstimated) {
    const grams = ingredients.reduce((g, i) => {
      const p = i.product_id ? products.get(i.product_id) : undefined;
      return p && i.quantity != null && p.category !== 'spices' ? g + gramsOf(p, i.quantity) : g;
    }, 0);
    servings = tags.includes('dessert') || tags.includes('baking') ? Math.min(16, Math.max(4, Math.round(grams / 110))) : Math.min(10, Math.max(2, Math.round(grams / 380)));
  }
  // Amount check: far more per serving than anyone uses means a misread line (a pack instead of a pinch).
  for (const i of ingredients) {
    const p = i.product_id ? products.get(i.product_id) : undefined;
    if (p && i.quantity != null && p.measure?.maxPerServing && i.quantity / servings > p.measure.maxPerServing * 1.5) return null;
  }
  const total = raw.timeText ? minutesIn([raw.timeText]) : minutesIn(steps);
  const prep = Math.min(30, 10 + Math.round(ingredients.length * 1.5));
  const cook = Math.max(0, total ? total - (raw.timeText ? prep : 0) : 20);
  const difficulty = raw.difficulty ? (raw.difficulty <= 2 ? 'easy' : raw.difficulty === 3 ? 'medium' : 'hard') : steps.length <= 4 && ingredients.length <= 8 ? 'easy' : 'medium';
  const hash = createHash('sha1').update(raw.url ?? title).digest('hex');
  const site = raw.url ? new URL(raw.url).hostname.replace(/^www\./, '') : null;
  const input: RecipeInput = {
    title: title.charAt(0).toUpperCase() + title.slice(1),
    summary: servingsEstimated ? 'Servings and times are estimated.' : null,
    servings_estimated: servingsEstimated,
    cuisine: null,
    tags,
    servings,
    prep_minutes: prep,
    cook_minutes: Math.min(360, cook),
    difficulty,
    emoji: emojiFor(title),
    origin: 'external',
    steps: steps.slice(0, 40).map((text) => ({ text: text.slice(0, 1000) })),
    source_url: raw.url,
    source_name: raw.source === 'wikibooks' ? 'Wikibooks Cookbook' : site,
    attribution: raw.source === 'wikibooks' ? 'Wikibooks contributors, CC BY-SA 4.0' : 'via RecipeNLG (personal use)',
    ingredients,
  };
  const score = matched / Math.max(1, counted) + (withAmount / matched) * 0.5 + (dinner ? 0.3 : 0) + (steps.length >= 3 ? 0.1 : 0) + (parseInt(hash.slice(0, 6), 16) / 0xffffff) * 0.05;
  return { key: normalizeText(title).replace(/\s+/g, ' '), id: ID_PREFIX[raw.source] + hash.slice(0, 16), score, dinner, input };
}

let productsMemo: { db: Db; list: Product[] } | null = null;
function listProductsCached(db: Db) {
  if (productsMemo?.db !== db) productsMemo = { db, list: listProducts(db, '') };
  return productsMemo.list;
}

// ---------- The import ----------

export interface ImportReport {
  read: number; checked: number; passedNames: number; passed: number; duplicates: number; imported: number; rejectedNutrition: number; byTag: Record<string, number>; examples: string[];
  /** --refresh: recipes matched again in place, and ones that no longer pass (and weren't used) taken out. */
  refreshed: number; removed: number;
  /** Recipes whose title said "dinner" but whose contents say side dish or dessert. */
  reclassified: number;
  /** Lines that use a substitution, and lines left unresolved (shown for review). */
  substituted: number; unresolvedLines: number;
}

/**
 * Pick the best `limit` recipes from the sources (most of them dinners), skip duplicates of what's already
 * in the library, and add them. Safe to run again: existing ids are skipped.
 */
export async function importRecipes(db: Db, sources: AsyncIterable<RawRecipe> | Iterable<RawRecipe>, opts: { limit: number; dinnerShare?: number; dryRun?: boolean; refresh?: SourceId; log?: (s: string) => void }): Promise<ImportReport> {
  const products = listProductsCached(db);
  const namesShare = nameMatcher(products);
  const ctx = { index: nameIndex(products), lineMemo: new Map<string, DraftIngredient>() };
  // With --refresh, this source's own recipes are matched again in place, not treated as duplicates.
  const own = opts.refresh ? ID_PREFIX[opts.refresh] : null;
  const existingTitles = new Set(db.all<{ id: string; title: string }>('SELECT id, title FROM recipes').filter((x) => !own || !x.id.startsWith(own)).map((x) => normalizeText(x.title).replace(/\s+/g, ' ')));
  const existingIds = new Set(db.all<{ id: string }>("SELECT id FROM recipes WHERE id LIKE 'rx_%'").map((x) => x.id).filter((id) => !own || !id.startsWith(own)));
  const refreshable = new Set(own ? db.all<{ id: string }>('SELECT id FROM recipes WHERE id LIKE ?', `${own}%`).map((x) => x.id) : []);
  const share = opts.dinnerShare ?? 0.7;
  const caps = { dinner: Math.round(opts.limit * share), other: opts.limit - Math.round(opts.limit * share) };
  const pools = { dinner: new Map<string, Candidate>(), other: new Map<string, Candidate>() };
  const r: ImportReport = { read: 0, checked: 0, passedNames: 0, passed: 0, duplicates: 0, imported: 0, rejectedNutrition: 0, byTag: {}, examples: [], refreshed: 0, removed: 0, reclassified: 0, substituted: 0, unresolvedLines: 0 };
  const trim = (pool: Map<string, Candidate>, cap: number) => {
    if (pool.size <= cap * 1.5) return;
    const keep = [...pool.values()].sort((a, b) => b.score - a.score).slice(0, cap);
    pool.clear();
    for (const c of keep) pool.set(c.key, c);
  };

  for await (const raw of sources as AsyncIterable<RawRecipe>) {
    r.read++;
    if (r.read % 100_000 === 0) opts.log?.(`${r.read.toLocaleString('en')} read, ${r.passed.toLocaleString('en')} good so far`);
    if (raw.names?.length && namesShare(raw.names) < 0.85) continue;
    r.passedNames++;
    r.checked++;
    const c = buildCandidate(db, raw, ctx);
    if (!c) continue;
    r.passed++;
    if (existingTitles.has(c.key) || existingIds.has(c.id)) {
      r.duplicates++;
      continue;
    }
    const pool = c.dinner ? pools.dinner : pools.other;
    const same = pool.get(c.key);
    if (same) {
      r.duplicates++;
      if (same.score >= c.score) continue;
    }
    pool.set(c.key, c);
    trim(pool, c.dinner ? caps.dinner : caps.other);
  }

  // Fill each share; if one source is short, the other fills up.
  const sorted = (p: Map<string, Candidate>) => [...p.values()].sort((a, b) => b.score - a.score);
  const d = sorted(pools.dinner), o = sorted(pools.other);
  const takeD = Math.min(d.length, Math.max(caps.dinner, opts.limit - o.length));
  const chosen = [...d.slice(0, takeD), ...o.slice(0, opts.limit - takeD)];
  if (opts.dryRun) {
    for (const c of chosen) for (const t of c.input.tags ?? []) r.byTag[t] = (r.byTag[t] ?? 0) + 1;
    r.imported = chosen.length;
    r.examples = chosen.slice(0, 12).map((c) => c.input.title);
    return r;
  }
  for (let i = 0; i < chosen.length; i += 250) {
    db.tx(() => {
      for (const c of chosen.slice(i, i + 250)) {
        const existed = refreshable.has(c.id);
        if (existed) replaceImported(db, c);
        const rec = existed ? getRecipe(db, '', c.id) : createRecipe(db, null, c.input, c.id);
        const kcal = rec.nutritionPerServing?.kcal ?? 0;
        // Implausible per-serving energy usually means a misread amount: leave it out.
        if (kcal < 60 || kcal > 1800) {
          if (!existed || !inUse(db, c.id)) {
            db.run('DELETE FROM recipe_ingredients WHERE recipe_id = ?', c.id);
            db.run('DELETE FROM recipes WHERE id = ?', c.id);
          }
          r.rejectedNutrition++;
          continue;
        }
        // What's in it decides whether it's a meal: a light or protein-free "dinner" is a side dish,
        // a sweet one without protein a dessert. Keeps the planner from proposing them for dinner.
        const kind = dishKind(rec);
        if (kind && !(c.input.tags ?? []).some((t) => NOT_DINNER.has(t))) {
          const tags = [...(c.input.tags ?? []), kind];
          db.run('UPDATE recipes SET tags = ? WHERE id = ?', JSON.stringify(tags), c.id);
          c.input.tags = tags;
          r.reclassified++;
        }
        r.substituted += c.input.ingredients.filter((i) => i.match === 'substitute' || i.match === 'approximate').length;
        r.unresolvedLines += c.input.ingredients.filter((i) => !i.product_id && i.source_key !== 'u:water').length;
        if (existed) r.refreshed++;
        else r.imported++;
        refreshable.delete(c.id);
        for (const t of c.input.tags ?? []) r.byTag[t] = (r.byTag[t] ?? 0) + 1;
        if (r.examples.length < 12) r.examples.push(c.input.title);
      }
    });
    opts.log?.(`added ${Math.min(i + 250, chosen.length).toLocaleString('en')} of ${chosen.length.toLocaleString('en')}`);
  }
  // Refresh: recipes of this source that no longer meet the bar go, unless someone cooked, planned or saved them.
  if (own) {
    db.tx(() => {
      for (const id of refreshable) {
        if (inUse(db, id)) continue;
        db.run('DELETE FROM recipe_ingredients WHERE recipe_id = ?', id);
        db.run('DELETE FROM recipe_interactions WHERE recipe_id = ?', id);
        db.run('DELETE FROM recipe_retention WHERE recipe_id = ?', id);
        db.run('DELETE FROM recipes WHERE id = ?', id);
        r.removed++;
      }
    });
  }
  return r;
}

/** Has anyone cooked, planned, saved or rated this recipe? */
function inUse(db: Db, id: string) {
  return !!(db.get('SELECT 1 FROM cook_log WHERE recipe_id = ?', id) || db.get('SELECT 1 FROM meal_slots WHERE recipe_id = ?', id)
    || db.get('SELECT 1 FROM recipe_interactions WHERE recipe_id = ? AND (saved = 1 OR rating IS NOT NULL OR priority != 0)', id));
}

/** Replace an imported recipe's content in place (same id, so plans and ratings stay attached). */
function replaceImported(db: Db, c: Candidate) {
  const x = c.input;
  db.update('recipes', c.id, {
    title: x.title, summary: x.summary ?? null, tags: x.tags ?? [], servings: x.servings, prep_minutes: x.prep_minutes ?? 0, cook_minutes: x.cook_minutes ?? 0,
    difficulty: x.difficulty ?? 'easy', steps: x.steps, emoji: x.emoji ?? '🍽️', source_url: x.source_url ?? null, source_name: x.source_name ?? null, attribution: x.attribution ?? null,
    servings_estimated: x.servings_estimated ? 1 : 0,
  });
  db.run('DELETE FROM recipe_ingredients WHERE recipe_id = ?', c.id);
  x.ingredients.forEach((ing, i) => db.insert('recipe_ingredients', {
    recipe_id: c.id, position: i, product_id: ing.product_id ?? null, name: ing.name, quantity: ing.quantity ?? null, unit: ing.unit ?? null, display: ing.display ?? null,
    optional: ing.optional ? 1 : 0, match: ing.match ?? (ing.product_id ? 'exact' : 'unresolved'), source_key: ing.source_key ?? (ing.product_id ? null : `u:${ing.name.toLowerCase()}`),
  }));
}

const PROTEIN_SUBS = new Set(['poultry', 'red_meat', 'cured_meat', 'fish', 'plant_protein', 'legume', 'eggs', 'hard_cheese', 'soft_cheese']);
/** 'side' or 'dessert' when the contents say it isn't a main meal; null when it is. */
export function dishKind(rec: { nutritionPerServing: { kcal: number; protein: number; sugars?: number } | null; ingredients: { optional: boolean; product?: { subcategory: string | null } | null }[] }): 'side' | 'dessert' | null {
  const n = rec.nutritionPerServing;
  if (!n) return null;
  const protein = rec.ingredients.some((i) => !i.optional && i.product?.subcategory && PROTEIN_SUBS.has(i.product.subcategory)) || n.protein >= 15;
  if (!protein && ((n.sugars ?? 0) * 4) / Math.max(1, n.kcal) >= 0.3) return 'dessert';
  if (n.kcal < 250 || !protein) return 'side';
  return null;
}

/** Remove an imported source again. Recipes you cooked, planned or saved stay. */
export function removeImported(db: Db, source: SourceId) {
  const prefix = ID_PREFIX[source];
  const used = new Set([
    ...db.all<{ id: string }>('SELECT DISTINCT recipe_id id FROM cook_log WHERE recipe_id LIKE ?', `${prefix}%`).map((x) => x.id),
    ...db.all<{ id: string }>('SELECT DISTINCT recipe_id id FROM meal_slots WHERE recipe_id LIKE ?', `${prefix}%`).map((x) => x.id),
    ...db.all<{ id: string }>('SELECT recipe_id id FROM recipe_interactions WHERE recipe_id LIKE ? AND (saved = 1 OR rating IS NOT NULL OR priority != 0)', `${prefix}%`).map((x) => x.id),
  ]);
  const ids = db.all<{ id: string }>('SELECT id FROM recipes WHERE id LIKE ?', `${prefix}%`).map((x) => x.id).filter((id) => !used.has(id));
  db.tx(() => {
    for (const id of ids) {
      db.run('DELETE FROM recipe_ingredients WHERE recipe_id = ?', id);
      db.run('DELETE FROM recipe_interactions WHERE recipe_id = ?', id);
      db.run('DELETE FROM recipes WHERE id = ?', id);
    }
  });
  return { removed: ids.length, kept: used.size };
}
