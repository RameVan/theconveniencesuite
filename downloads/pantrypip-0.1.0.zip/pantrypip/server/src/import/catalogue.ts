// The Dutch product catalogue: every usable product from the Open Food Facts export (scripts/fetch-off-dump.ts)
// → catalogue (searchable when adding things) and, for products that are one of our ingredients, retail_products
// (an ingredient's "Where to buy").
//
// Which ingredient a product is: its name, without brand and retail words, is that ingredient's name and nothing
// more (every word belongs to the ingredient's names), and, when Open Food Facts gives categories, at least one
// of them mostly holds that ingredient. "Twinings Groene Thee Citroen" is not lemon; "Plenny Shake Vanilla" (a
// meal replacement) is not vanilla extract. Categories alone never decide: tried, about a third came out wrong.
// Everything else stays a product of its own: searchable, and a household product once someone picks it.
// Nothing is invented: names, brands, sizes, photos and nutrition are what Open Food Facts says.
import { createReadStream } from 'node:fs';
import { createInterface } from 'node:readline';
import type { Db } from '../db/db.ts';
import { newId } from '../db/db.ts';
import { clock } from '../clock.ts';
import { identifyIngredient, onlyHarmless } from '../domain/ingredient-match.ts';
import { guessDefaults, listProducts, normalizeText, stem, type Product } from '../domain/products.ts';
import { parseSize } from '../domain/receipts.ts';
import { fromOpenFoodFacts } from '../domain/dietary.ts';
import { chainsFor, cleanName, sizeIn } from './retail.ts';
import { identityKey, identityWords, letterKey } from './identity.ts';
import { withoutOwnBrand } from '../domain/ingredients.ts';

/** One line of nl.ndjson (fetch-off-dump.ts). */
interface Row {
  code: string; name: string; generic?: string; brands?: string; quantity?: string; categories: string[]; labels: string[]; stores?: string;
  allergens: string[]; analysis: string[]; image?: string; scans?: number; modified?: number;
  n: { kcal?: number; protein?: number; carbs?: number; fat?: number; sugars?: number; satFat?: number; fibre?: number; salt?: number };
}

export interface CatalogueReport {
  read: number; kept: number; skipped: number; rejected: number; linked: number; ingredients: number;
  retail: number; byChain: Record<string, number>; withImage: number; groups: number; unlisted: number;
}

// Shelf for products that aren't one of our ingredients, from their Open Food Facts categories (first rule wins).
const SHELVES: [string, string[]][] = [
  ['frozen', ['en:frozen-foods', 'en:ice-creams-and-sorbets', 'en:ice-creams']],
  ['dairy', ['en:dairies', 'en:cheeses', 'en:eggs', 'en:yogurts', 'en:dairy-desserts', 'en:butters', 'en:creams']],
  ['meat_fish', ['en:meats', 'en:fishes', 'en:seafood', 'en:poultries', 'en:meat-analogues', 'en:prepared-meats', 'en:sausages']],
  ['bakery', ['en:breads', 'en:bread-rolls', 'en:viennoiseries', 'en:pastries']],
  ['drinks', ['en:beverages', 'en:waters', 'en:sodas', 'en:juices-and-nectars', 'en:coffees', 'en:teas', 'en:alcoholic-beverages']],
  ['snacks', ['en:snacks', 'en:sweet-snacks', 'en:salty-snacks', 'en:confectioneries', 'en:chocolates', 'en:biscuits-and-cakes', 'en:chips-and-fries', 'en:nuts']],
  ['spices', ['en:spices', 'en:herbs', 'en:dried-herbs']],
  ['produce', ['en:fresh-fruits', 'en:fresh-vegetables', 'en:fresh-plant-based-foods']],
];
function shelf(r: Row): string {
  for (const [id, tags] of SHELVES) if (r.categories.some((c) => tags.includes(c))) return id;
  return r.categories.length ? 'pantry' : guessDefaults(r.name).category;
}

const usable = (r: Row) => !!r.name?.trim() && /^\d{8,14}$/.test(r.code) && !!(r.brands || r.quantity || r.image);
const tidy = (s: string) => s.replace(/\s+/g, ' ').trim();
const brandsOf = (r: Row) => (r.brands ?? '').split(',').map((b) => normalizeText(b)).filter(Boolean);

// Some names come with HTML entities ("Jack Link&#039;s").
const ENTITIES: Record<string, string> = { '&quot;': '"', '&#34;': '"', '&#039;': "'", '&#39;': "'", '&apos;': "'", '&amp;': '&', '&lt;': '<', '&gt;': '>', '&nbsp;': ' ' };
const decode = (s?: string) => s?.replace(/&(?:quot|#34|#0?39|apos|amp|lt|gt|nbsp);/g, (m) => ENTITIES[m]);

async function readRows(file: string): Promise<Row[]> {
  const rows: Row[] = [];
  for await (const line of createInterface({ input: createReadStream(file), crlfDelay: Infinity })) {
    if (!line) continue;
    const r: Row = JSON.parse(line);
    rows.push({ ...r, name: decode(r.name)!, brands: decode(r.brands), quantity: decode(r.quantity) });
  }
  return rows;
}

/** (Re)write the catalogue and the Open Food Facts rows of retail_products from the export's Dutch rows. */
export async function importCatalogue(db: Db, file: string): Promise<CatalogueReport> {
  const rows = await readRows(file);
  const report: CatalogueReport = { read: rows.length, kept: 0, skipped: 0, rejected: 0, linked: 0, ingredients: 0, retail: 0, byChain: {}, withImage: 0, groups: 0, unlisted: 0 };
  const products = listProducts(db, '').filter((p) => !p.household_id);
  const own = new Map<string, Set<string>>();
  const ownWords = (p: Product) => own.get(p.id) ?? own.set(p.id, new Set([p.name, p.name_nl ?? '', ...p.synonyms].flatMap((x) => normalizeText(x).split(' ')).map(stem))).get(p.id)!;

  const kept = rows.filter(usable);
  report.skipped = rows.length - kept.length;
  // Only real brands come off a name: ones on at least 3 products. A one-off "brand" is usually the first word of
  // the name typed into the wrong field ("Kaas mosterd" by "Kaas", "Ovenschotel zalm" by "Ovenschotel").
  const brandCount = new Map<string, number>();
  for (const r of kept) for (const b of new Set(brandsOf(r))) brandCount.set(b, (brandCount.get(b) ?? 0) + 1);
  const named = new Map<string, Product>();
  for (const r of kept) {
    const clean = cleanName(r.name, brandsOf(r).filter((b) => brandCount.get(b)! >= 3 && b !== normalizeText(r.name)).join(','));
    const m = identifyIngredient(db, '', clean, { products });
    if (m.kind !== 'product') continue;
    const words = ownWords(m.product!);
    if (clean.split(' ').every((w) => words.has(stem(w)) || onlyHarmless([w]))) named.set(r.code, m.product!);
  }

  // Check against categories: a category's majority ingredient, among its name-linked products.
  const votes = new Map<string, Map<string, number>>();
  for (const r of kept) {
    const p = named.get(r.code);
    if (!p) continue;
    for (const c of r.categories) {
      const v = votes.get(c) ?? votes.set(c, new Map()).get(c)!;
      v.set(p.id, (v.get(p.id) ?? 0) + 1);
    }
  }
  const majority = new Map<string, string>();
  for (const [c, v] of votes) {
    const total = [...v.values()].reduce((x, y) => x + y, 0);
    const [best, n] = [...v.entries()].sort((x, y) => y[1] - x[1])[0];
    if (n / total >= 0.5) majority.set(c, best);
  }
  for (const r of kept) {
    const p = named.get(r.code);
    if (p && r.categories.length && !r.categories.some((c) => majority.get(c) === p.id)) {
      named.delete(r.code);
      report.rejected++;
    }
  }

  const now = clock.iso();
  const linked = new Set<string>();
  db.tx(() => {
    db.run("DELETE FROM catalogue WHERE source = 'Open Food Facts'");
    db.run("DELETE FROM retail_products WHERE source = 'Open Food Facts'");
    const entries: Record<string, unknown>[] = [];
    const joined = new Map<string, string>();
    for (const r of kept) {
      const product = named.get(r.code) ?? null;
      if (product) report.linked++;
      const brands = tidy(r.brands ?? '');
      const chains = chainsFor((r.stores ?? '').split(',').map((s) => s.trim()).filter(Boolean), brands);
      const size = r.quantity ? parseSize(r.quantity) : null;
      const nutrition = r.n.kcal != null ? { kcal: r.n.kcal, protein: r.n.protein ?? 0, carbs: r.n.carbs ?? 0, fat: r.n.fat ?? 0, sugars: r.n.sugars, satFat: r.n.satFat, fibre: r.n.fibre, salt: r.n.salt } : null;
      const modified = r.modified ? new Date(r.modified * 1000).toISOString().slice(0, 10) : null;
      // The same product entered more than once shares a group (identity.ts); own brands group per supermarket.
      const brand = brands.split(',')[0]?.trim() || null;
      const shown = withoutOwnBrand({ name: tidy(r.name), brand, chain_id: chains[0] ?? null, chain_name: null });
      const group = identityKey(shown.name, shown.brand, shown.chain_id, brands.split(','));
      const letters = letterKey(shown.name, brands.split(','));
      if (letters) joined.set(r.code, letters);
      entries.push({
        ean: r.code, country: 'NL', name: tidy(r.name), brand, group_key: group ?? `ean:${r.code}`, words: identityWords(shown.name, brands.split(',')), listed: group ? 1 : 0, size_text: r.quantity ? tidy(r.quantity) : null,
        size_qty: size?.qty ?? null, size_unit: size?.unit ?? null, category: product?.category ?? shelf(r), product_id: product?.id ?? null,
        chains, image_url: r.image ?? null, nutrition, ...fromOpenFoodFacts(r.allergens, r.analysis), popularity: r.scans ?? 0, modified, source: 'Open Food Facts',
      });
      report.kept++;
      if (r.image) report.withImage++;
      if (!product) continue;
      linked.add(product.id);
      // An ingredient's "Where to buy": one row per chain it's listed at, or one with the chain unknown.
      for (const chain of chains.length ? chains : [null]) {
        db.insert('retail_products', {
          id: newId('rp'), product_id: product.id, country: 'NL', chain_id: chain, name: tidy(r.name), brand: brands || null,
          size: r.quantity ? sizeIn(product, { quantity: r.quantity }) : null, size_text: r.quantity ?? null, ean: r.code,
          url: `https://world.openfoodfacts.org/product/${r.code}`, status: chain ? 'listed' : 'unverified', source: 'Open Food Facts',
          nutrition, last_verified: modified, created_at: now,
        });
        report.retail++;
        if (chain) report.byChain[chain] = (report.byChain[chain] ?? 0) + 1;
      }
    }
    // Groups that are one product after all: the same letters (words run together or in another order, "stroop
    // wafel" and "stroopwafel"; letterKey), or the
    // same words under a brand written longer ("Tony's" / "Tony's Chocolonely"; only brands of 5+ letters, so
    // "Vega" doesn't become "Vegan").
    const parent = new Map<string, string>();
    const find = (k: string): string => {
      let r = k;
      while (parent.has(r)) r = parent.get(r)!;
      if (r !== k) parent.set(k, r);
      return r;
    };
    const union = (a: string, b: string) => {
      const [x, y] = [find(a), find(b)];
      if (x !== y) parent.set(x < y ? y : x, x < y ? x : y);
    };
    const worded = (k: string) => !k.startsWith('ean:');
    const byJoined = new Map<string, string>();
    for (const e of entries) {
      const k = e.group_key as string;
      const j = joined.get(e.ean as string);
      if (!worded(k) || !j) continue;
      const jk = `${k.split('|')[0]}#${j}`;
      if (byJoined.has(jk)) union(byJoined.get(jk)!, k);
      else byJoined.set(jk, k);
    }
    const brandsByWords = new Map<string, Map<string, string>>();
    for (const e of entries) {
      const k = e.group_key as string;
      const [b, w] = k.split('|');
      if (!worded(k) || !b || b.startsWith('@')) continue;
      (brandsByWords.get(w) ?? brandsByWords.set(w, new Map()).get(w)!).set(b, k);
    }
    for (const brands of brandsByWords.values()) {
      if (brands.size < 2) continue;
      const list = [...brands.keys()].sort((x, y) => x.length - y.length);
      for (let i = 0; i < list.length; i++) for (let j = i + 1; j < list.length; j++) {
        if (list[i].length >= 5 && list[j].startsWith(list[i])) union(brands.get(list[i])!, brands.get(list[j])!);
      }
    }
    for (const e of entries) e.group_key = find(e.group_key as string);

    // An entry without brand or shop ("Zalmfilet") next to products with those words that have one adds only a
    // lookalike, and can't say whose it is (merging it would give a brand a size it may not have): not listed.
    // Barcode scans still find it.
    const known = new Map<string, Set<string>>();
    for (const e of entries) {
      const k = e.group_key as string;
      if (!k.startsWith('|') && !k.startsWith('ean:')) (known.get(e.words as string) ?? known.set(e.words as string, new Set()).get(e.words as string)!).add(k);
    }
    for (const e of entries) {
      if (!(e.group_key as string).startsWith('|')) continue;
      if (known.get(e.words as string)?.size) e.listed = 0;
    }
    for (const e of entries) db.insert('catalogue', e);
    report.groups = new Set(entries.filter((e) => e.listed).map((e) => e.group_key)).size;
    report.unlisted = entries.filter((e) => !e.listed).length;
    db.run("INSERT INTO catalogue_fts(catalogue_fts) VALUES ('rebuild')");
  });
  report.ingredients = linked.size;
  return report;
}
