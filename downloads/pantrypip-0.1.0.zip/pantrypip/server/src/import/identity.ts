// When two catalogue entries are the same product. Open Food Facts often has one product several times: other
// barcodes for other pack sizes, the same pack entered twice, and names typed differently ("Doritos Sweet Chili",
// "Sweet Chilli Pepper Flavour", "Doritos Tortilla chips sweet chilli pepper"). Same brand and the same words,
// once the words that don't tell products apart are gone, means the same product; the size is then an option.
import { normalizeText, stem } from '../domain/products.ts';

// Words that say how a product is packed or described, not which product it is.
const FILLER = new Set([
  'flavour', 'flavor', 'flavoured', 'flavored', 'smaak', 'smaakje', 'met', 'with', 'and', 'en', 'the', 'de', 'het', 'van', 'of',
  'tortilla', 'chips', 'crisps', 'party', 'pack', 'snackbox', 'box', 'multipack', 'multi', 'sharing', 'share', 'size', 'family',
  'familiepak', 'xl', 'xxl', 'big', 'bag', 'zak', 'zakje', 'pak', 'fles', 'blik', 'pot', 'stuks', 'stuk', 'st', 'pcs',
]);
// Words that make it another product even when they're in the brand ("AH Biologisch"): organic isn't regular.
const KEEP = new Set([
  'bio', 'biologisch', 'biologische', 'organic', 'eko', 'light', 'zero', 'vegan', 'vega', 'vegetarisch', 'glutenvrij', 'lactosevrij',
  'suikervrij', 'halfvol', 'halfvolle', 'mager', 'magere', 'volle', 'decaf', 'cafeinevrij', 'alcoholvrij', 'kids',
]);
// Spellings of the same word.
const SAME: [RegExp, string][] = [
  [/\bchil+i(?:e)?s?\b/g, 'chili'],
  [/\bchili peppers?\b/g, 'chili'],
  [/\bbarbecue\b/g, 'bbq'],
  [/\bflaming\b/g, 'flamin'],
  [/\bflavou?red\b/g, ''],
];
const AMOUNT = /\b\d+(?:[.,]\d+)?\s*(?:x\s*\d+(?:[.,]\d+)?\s*)?(?:kg|g|gr|gram|grams|l|lt|liter|litre|cl|ml|st|stuks|pcs|pieces|stuk)\b|\b\d+\s*x\b/g;

/** Lower case, no accents or punctuation, one spelling per word ("chilli" → "chili"): for names and searches. */
export function canonicalText(s: string): string {
  let out = normalizeText(s);
  for (const [re, to] of SAME) out = out.replace(re, to);
  return out.replace(/\s+/g, ' ').trim();
}

function ownWords(name: string, brands: string[]): string[] {
  const s = canonicalText(normalizeText(name).replace(AMOUNT, ' '));
  const brandWords = new Set(brands.flatMap((b) => normalizeText(b).split(' ')).filter((w) => w.length > 1));
  return s.split(' ').filter((w) => w && (!brandWords.has(w) || KEEP.has(w)) && !FILLER.has(w));
}

/** The words that make a product what it is, without its brand: sorted, so word order doesn't matter. */
export function identityWords(name: string, brands: string[]): string {
  return [...new Set(ownWords(name, brands).map(stem))].sort().join(' ');
}

/**
 * The letters of those words, sorted: the same for words run together or apart and in any order ("pinda kaas",
 * "pindakaas"; "noten pistache", "pistachenoten"). Only for 6+ letters, where two different names of one brand
 * having exactly the same letters doesn't happen by chance. Null when shorter.
 */
export function letterKey(name: string, brands: string[]): string | null {
  // Filler glued on counts as filler too: "vanillesmaak" is "vanille", "paprikachips" is "paprika".
  const letters = ownWords(name, brands).map((w) => w.replace(/(?<=.{3})(smaak|chips|flavour)$/, '')).join('').replace(/[^a-z0-9]/g, '');
  return letters.length >= 6 ? [...letters].sort().join('') : null;
}

/** A brand as one token: "Zuivel meester" and "Zuivelmeester" are the same brand. */
export const brandToken = (brand: string) => normalizeText(brand).replace(/[\s&']/g, '');

/**
 * Brand (or the supermarket, for own brands) plus the identity words; null when no words are left (a name that's
 * only a brand or an amount says too little to call two products the same).
 */
export function identityKey(name: string, brand: string | null, chain: string | null, brands: string[] = []): string | null {
  const words = identityWords(name, [...brands, ...(brand ? [brand] : [])]);
  if (!words) return null;
  return `${brand ? brandToken(brand) : chain ? `@${chain}` : ''}|${words}`;
}
