// Helpers for supermarket products from Open Food Facts (catalogue.ts imports them).
//
// A listing names an ingredient only when its name, without brand, chain and retail words ("AH", "Jumbo",
// "houdbare", "biologisch"), names exactly that ingredient (ingredient-match.ts). The chain comes from the
// listing's store tags, or from an own-label brand ("AH", "Jumbo", "1 de Beste").
import type { Db } from '../db/db.ts';
import { CHAINS } from '../db/ingredient-knowledge.ts';
import { normalizeText, type Product } from '../domain/products.ts';

// Words on supermarket labels that say nothing about what the product is.
const RETAIL_WORDS = /\b(flinterdun|dun gesneden|plakken|geraspte|ah|albert heijn|jumbo|lidl|aldi|plus|dirk|coop|spar|hoogvliet|vomar|deka|dekamarkt|poiesz|jan linders|picnic|1 de beste|g'woon|gwoon|huismerk|excellent|basic|terra|biologisch|biologische|bio|eko|houdbare|houdbaar|verse|vers|naturel|original|origineel|classic|klassiek|premium|select|selectie|voordeelverpakking|voordeel|multipack|family pack|xl|pak|fles|literpak|liter|stuks|zak|bakje|kuipje|netje|doos|blik|pot|tube)\b/gi;


/** A listing's pack size in the ingredient's base unit, or null. */
export function sizeIn(base: Product, q: { product_quantity?: number | string; product_quantity_unit?: string; quantity?: string }): number | null {
  let amount = Number(q.product_quantity);
  let unit = (q.product_quantity_unit ?? '').toLowerCase();
  if (!(amount > 0) && q.quantity) {
    const m = q.quantity.toLowerCase().replace(',', '.').match(/(\d+(?:\.\d+)?)\s*(kg|g|gr|l|liter|litre|cl|ml|stuks?|st|eieren|pcs)\b/);
    if (m) {
      amount = Number(m[1]);
      unit = m[2];
    }
  }
  if (!(amount > 0)) return null;
  const grams = unit === 'kg' ? amount * 1000 : unit === 'g' || unit === 'gr' ? amount : null;
  const ml = unit === 'l' || unit === 'liter' || unit === 'litre' ? amount * 1000 : unit === 'cl' ? amount * 10 : unit === 'ml' ? amount : null;
  const pcs = /^(stuks?|st|eieren|pcs)$/.test(unit) ? amount : null;
  if (base.unit === 'g') return grams ?? (ml != null ? ml * (base.density ?? 1) : pcs != null && base.piece_size ? pcs * base.piece_size : null);
  if (base.unit === 'ml') return ml ?? (grams != null && base.density ? grams / base.density : null);
  return pcs ?? (grams != null && base.piece_size ? Math.round(grams / base.piece_size) : null);
}

/** Chains a listing is sold at, from its store tags and own-label brands. */
export function chainsFor(stores: string[], brands: string): string[] {
  const out = new Set<string>();
  // Store tags, and own-label brands ("AH", "Jumbo", "Dirk / 1 de Beste").
  const hay = [...stores.map((x) => x.toLowerCase().replace(/-/g, ' ')), ...brands.toLowerCase().split(/[,/]/).map((b) => b.trim().replace(/\s+/g, ' '))];
  for (const c of CHAINS.filter((x) => x.country === 'NL')) if (hay.some((h) => c.off.some((o) => h === o))) out.add(c.id);
  return [...out];
}

/** A listing's name without its brands, retail words and amounts: what's left says what the product is. */
export function cleanName(name: string, brands: string): string {
  let clean = normalizeText(name);
  for (const b of brands.split(',').map((x) => normalizeText(x)).filter((x) => x.length > 1)) clean = clean.replace(new RegExp(`\\b${b.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'g'), ' ');
  return clean.replace(RETAIL_WORDS, ' ').replace(/\b\d+(?:[.,]\d+)?\s*(kg|g|gr|l|ml|cl|%)?\b/g, ' ').replace(/\s+/g, ' ').trim();
}

/** Pack sizes seen in at least two Dutch listings: evidence for a product's retail packaging. */
export function listedPackSizes(db: Db, productId: string): number[] {
  return db.all<{ size: number }>("SELECT size FROM retail_products WHERE product_id = ? AND country = 'NL' AND status IN ('listed', 'verified') AND size IS NOT NULL GROUP BY round(size) HAVING COUNT(DISTINCT ean) >= 2 ORDER BY COUNT(DISTINCT ean) DESC LIMIT 6", productId).map((r) => Math.round(r.size));
}
