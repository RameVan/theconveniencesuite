import http from 'node:http';
import https from 'node:https';
import { existsSync, readFileSync } from 'node:fs';
import { Db } from './db/db.ts';
import { seedCatalogue, seedDemo } from './db/seed.ts';
import { buildRoutes } from './http/routes.ts';
import { createHandler, createServer } from './http/server.ts';
import { startScheduler } from './scheduler.ts';
import { config } from './config.ts';
import { log } from './log.ts';
import { setupPage } from './http/setup-page.ts';

export function createApp(dbFile = config.dbFile, opts: { seedDemo?: boolean } = {}) {
  const db = new Db(dbFile);
  db.migrate();
  seedCatalogue(db);
  if (opts.seedDemo ?? config.seedDemo) seedDemo(db);
  const router = buildRoutes(db);
  const server = createServer(db, router);
  return { db, server, router };
}

/**
 * Plain-HTTP companion of the HTTPS server: serves the iPhone setup page and the local
 * certificate authority (a phone can't trust HTTPS before it has the certificate), and
 * redirects everything else to HTTPS.
 */
export function httpCompanion(httpsPort: number, caFile: string) {
  return http.createServer((req, res) => {
    const url = new URL(req.url ?? '/', 'http://x');
    const host = (req.headers.host ?? 'localhost').replace(/:\d+$/, '');
    const httpsUrl = `https://${host}${httpsPort === 443 ? '' : `:${httpsPort}`}`;
    if (url.pathname === '/setup/larder-ca.crt' && existsSync(caFile)) {
      // This MIME type makes iPhone Safari offer to install it as a profile.
      res.writeHead(200, { 'Content-Type': 'application/x-x509-ca-cert', 'Content-Disposition': 'attachment; filename="larder-ca.crt"' });
      res.end(readFileSync(caFile));
      return;
    }
    if (url.pathname === '/setup' || url.pathname === '/setup/') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(setupPage(httpsUrl, existsSync(caFile)));
      return;
    }
    res.writeHead(308, { Location: `${httpsUrl}${req.url ?? '/'}` });
    res.end();
  });
}

export function main() {
  const { db, server, router } = createApp();
  startScheduler(db);
  const servers: http.Server[] = [];
  if (config.https) {
    if (!existsSync(config.httpsCert) || !existsSync(config.httpsKey)) {
      log.error('HTTPS=1 but no certificate found. Run `npm run cert` first (see docs/IPHONE.md).', { cert: config.httpsCert });
      process.exit(1);
    }
    const tls = https.createServer({ cert: readFileSync(config.httpsCert), key: readFileSync(config.httpsKey) }, createHandler(db, router));
    tls.listen(config.httpsPort, config.host, () => log.info('larder listening (https)', { url: `https://${config.host}:${config.httpsPort}`, setup: `http://<this computer>:${config.port}/setup` }));
    const companion = httpCompanion(config.httpsPort, config.httpsCa);
    companion.listen(config.port, config.host);
    servers.push(tls, companion);
  } else {
    server.listen(config.port, config.host, () => {
      log.info('larder listening', { url: `http://${config.host}:${config.port}`, ai: config.aiEnabled ? config.aiModel : 'off', db: config.dbFile });
    });
    servers.push(server);
  }
  const shutdown = () => {
    log.info('shutting down');
    let open = servers.length;
    for (const s of servers) s.close(() => --open === 0 && (db.close(), process.exit(0)));
    setTimeout(() => process.exit(0), 3000).unref();
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

if (import.meta.main) main();
