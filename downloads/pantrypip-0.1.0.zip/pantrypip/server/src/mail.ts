// Sending email (account confirmation, password reset): over SMTP from your own mailbox (SMTP_HOST, e.g. Gmail
// with an app password), or through Resend's HTTP API (RESEND_API_KEY). With neither, nothing is sent: the
// message, link included, goes to the server log so a home copy still works.
import net from 'node:net';
import tls from 'node:tls';
import { randomUUID } from 'node:crypto';
import { config } from './config.ts';
import { log } from './log.ts';

export interface Mail { to: string; subject: string; text: string; html: string }

/** Test hook: every email "sent" while set, newest last. */
export const outbox: Mail[] = [];
let capture = false;
export function captureMail(on: boolean) {
  capture = on;
  outbox.length = 0;
}

export async function sendMail(m: Mail): Promise<boolean> {
  if (capture) {
    outbox.push(m);
    return true;
  }
  if (config.smtpHost) {
    try {
      await smtpSend({ host: config.smtpHost, port: config.smtpPort, secure: config.smtpPort === 465 ? 'tls' : 'starttls', user: config.smtpUser, pass: config.smtpPass }, config.mailFrom, m);
      return true;
    } catch (e: any) {
      log.warn('email failed', { to: m.to, via: 'smtp', err: e?.message });
      return false;
    }
  }
  if (!config.resendKey) {
    log.info('email not sent (no SMTP_HOST or RESEND_API_KEY)', { to: m.to, subject: m.subject, text: m.text });
    return false;
  }
  try {
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { authorization: `Bearer ${config.resendKey}`, 'content-type': 'application/json' },
      body: JSON.stringify({ from: config.mailFrom, to: [m.to], subject: m.subject, text: m.text, html: m.html }),
      signal: AbortSignal.timeout(10_000),
    });
    if (!res.ok) {
      log.warn('email failed', { to: m.to, status: res.status, body: (await res.text()).slice(0, 300) });
      return false;
    }
    return true;
  } catch (e: any) {
    log.warn('email failed', { to: m.to, err: e?.message });
    return false;
  }
}

// ---------- SMTP (no dependency: a short conversation over node:tls) ----------

export interface SmtpOptions { host: string; port: number; secure: 'tls' | 'starttls' | 'none'; user?: string; pass?: string; timeoutMs?: number }

/** "PantryPip <me@gmail.com>" → "me@gmail.com". */
const addressOf = (s: string) => (s.match(/<([^>]+)>/)?.[1] ?? s).trim();
const b64 = (s: string) => Buffer.from(s, 'utf8').toString('base64');
/** Base64 in 76-character lines, as MIME wants. */
const b64Lines = (s: string) => b64(s).replace(/.{1,76}/g, '$&\r\n');
/** A header value that may hold non-ASCII (é, ’): encoded as UTF-8 words. */
const headerWord = (s: string) => (/^[\x20-\x7e]*$/.test(s) ? s : `=?UTF-8?B?${b64(s)}?=`);
const fromHeader = (s: string) => {
  const m = s.match(/^\s*(.*?)\s*<([^>]+)>\s*$/);
  return m && m[1] ? `${headerWord(m[1].replace(/^"|"$/g, ''))} <${m[2]}>` : s;
};

/** The message as sent after DATA: headers, a text and an HTML part, lines starting with "." doubled. */
export function mimeMessage(from: string, m: Mail, now = new Date()): string {
  const boundary = `pp-${randomUUID()}`;
  const domain = addressOf(from).split('@')[1] ?? 'localhost';
  const lines = [
    `From: ${fromHeader(from)}`,
    `To: ${m.to}`,
    `Subject: ${headerWord(m.subject)}`,
    `Date: ${now.toUTCString().replace('GMT', '+0000')}`,
    `Message-ID: <${randomUUID()}@${domain}>`,
    'MIME-Version: 1.0',
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
    '',
    `--${boundary}`,
    'Content-Type: text/plain; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
    '',
    b64Lines(m.text),
    `--${boundary}`,
    'Content-Type: text/html; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
    '',
    b64Lines(m.html),
    `--${boundary}--`,
  ];
  return lines.join('\r\n').replace(/\r\n\./g, '\r\n..');
}

/** Send one email: connect, (STARTTLS), EHLO, AUTH LOGIN, MAIL FROM, RCPT TO, DATA, QUIT. Throws on any refusal. */
export async function smtpSend(o: SmtpOptions, from: string, m: Mail): Promise<void> {
  let sock: net.Socket = o.secure === 'tls' ? tls.connect({ host: o.host, port: o.port, servername: o.host }) : net.connect({ host: o.host, port: o.port });
  let buf = '';
  let waiting: ((r: { code: number; text: string }) => void) | null = null;
  let failed: Error | null = null;
  let fail: ((e: Error) => void) | null = null;
  const timer = setTimeout(() => sock.destroy(new Error('SMTP timed out')), o.timeoutMs ?? 15_000);
  const listen = (s: net.Socket) => {
    s.setEncoding('utf8');
    s.on('data', (d: string) => {
      buf += d;
      // A reply ends with a line "250 text" (a dash after the code means more lines follow).
      const done = buf.match(/(?:^|\r\n)(\d{3}) [^\r\n]*\r\n$/);
      if (done && waiting) {
        const w = waiting;
        const text = buf;
        waiting = null;
        buf = '';
        w({ code: Number(done[1]), text: text.trim() });
      }
    });
    s.on('error', (e) => (failed = e, fail?.(e)));
    s.on('close', () => fail?.(failed ?? new Error('SMTP connection closed')));
  };
  listen(sock);
  const reply = () => new Promise<{ code: number; text: string }>((resolve, reject) => {
    if (failed) return reject(failed);
    waiting = resolve;
    fail = reject;
  });
  const expect = async (code: number, send?: string, shown = send) => {
    const r = reply();
    if (send !== undefined) sock.write(send + '\r\n');
    const got = await r;
    if (got.code !== code) throw new Error(`SMTP ${shown ?? 'greeting'}: ${got.text.slice(0, 200)}`);
    return got;
  };
  try {
    await expect(220);
    const ehlo = 'EHLO pantrypip';
    await expect(250, ehlo);
    if (o.secure === 'starttls') {
      await expect(220, 'STARTTLS');
      sock.removeAllListeners('data');
      sock.removeAllListeners('close');
      sock = tls.connect({ socket: sock, servername: o.host });
      await new Promise<void>((resolve, reject) => (sock.once('secureConnect', resolve), sock.once('error', reject)));
      listen(sock);
      await expect(250, ehlo);
    }
    if (o.user) {
      await expect(334, 'AUTH LOGIN');
      await expect(334, b64(o.user), 'AUTH user');
      await expect(235, b64(o.pass ?? ''), 'AUTH password');
    }
    await expect(250, `MAIL FROM:<${addressOf(from)}>`);
    await expect(250, `RCPT TO:<${addressOf(m.to)}>`);
    await expect(354, 'DATA');
    await expect(250, mimeMessage(from, m) + '\r\n.', 'message');
    // The message is accepted; a server that hangs up instead of saying goodbye doesn't change that.
    await expect(221, 'QUIT').catch(() => {});
  } finally {
    clearTimeout(timer);
    fail = null;
    sock.end();
  }
}

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);

/** A plain email with one button. */
export function linkMail(to: string, subject: string, intro: string, button: string, url: string, outro: string): Mail {
  const text = `${intro}\n\n${button}: ${url}\n\n${outro}`;
  const html = `<div style="font-family:system-ui,-apple-system,Segoe UI,sans-serif;max-width:480px;margin:0 auto;padding:24px;color:#2b2420">
<h2 style="margin:0 0 12px">PantryPip</h2>
<p style="line-height:1.5">${esc(intro)}</p>
<p style="margin:24px 0"><a href="${esc(url)}" style="background:#3f7aa8;color:#fff;padding:12px 20px;border-radius:999px;text-decoration:none;font-weight:600">${esc(button)}</a></p>
<p style="line-height:1.5;color:#6b625b;font-size:14px">${esc(outro)}</p>
<p style="color:#9a918a;font-size:12px;word-break:break-all">${esc(url)}</p>
</div>`;
  return { to, subject, text, html };
}
