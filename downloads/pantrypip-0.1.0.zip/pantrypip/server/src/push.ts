// Web Push (VAPID). Keys are generated on first use and kept in the database.
// Phones need the app served over HTTPS (and on iOS, installed to the home screen) to receive pushes.
import webpush from 'web-push';
import type { Db } from './db/db.ts';
import { clock } from './clock.ts';
import { config } from './config.ts';
import { log } from './log.ts';

let configured = false;

export function vapidPublicKey(db: Db): string {
  let pub = db.get<{ value: string }>("SELECT value FROM app_settings WHERE key = 'vapid_public'")?.value;
  let priv = db.get<{ value: string }>("SELECT value FROM app_settings WHERE key = 'vapid_private'")?.value;
  if (!pub || !priv) {
    const keys = webpush.generateVAPIDKeys();
    pub = keys.publicKey;
    priv = keys.privateKey;
    db.run("INSERT OR REPLACE INTO app_settings (key, value) VALUES ('vapid_public', ?), ('vapid_private', ?)", pub, priv);
  }
  if (!configured) {
    webpush.setVapidDetails(config.pushContact, pub, priv);
    configured = true;
  }
  return pub;
}

export interface PushSubscriptionJson {
  endpoint: string;
  keys: { p256dh: string; auth: string };
}

export function saveSubscription(db: Db, householdId: string, userId: string, sub: PushSubscriptionJson) {
  db.run(
    'INSERT OR REPLACE INTO push_subscriptions (endpoint, household_id, user_id, keys, created_at) VALUES (?, ?, ?, ?, ?)',
    sub.endpoint,
    householdId,
    userId,
    JSON.stringify(sub.keys),
    clock.iso(),
  );
}

export function removeSubscription(db: Db, householdId: string, endpoint: string) {
  db.run('DELETE FROM push_subscriptions WHERE endpoint = ? AND household_id = ?', endpoint, householdId);
}

export interface PushPayload {
  title: string;
  body: string;
  tag?: string;
  url?: string;
  slotId?: string;
  actions?: { action: string; title: string }[];
}

type Sender = (sub: PushSubscriptionJson, payload: string) => Promise<unknown>;
let sender: Sender = (sub, payload) => webpush.sendNotification(sub, payload, { TTL: 6 * 3600 });
/** Test hook. */
export function setPushSender(s: Sender) {
  sender = s;
}

/** Send to every device of the household (or only one person's devices). Expired subscriptions are removed. */
export async function pushToHousehold(db: Db, householdId: string, payload: PushPayload, userId?: string): Promise<number> {
  vapidPublicKey(db);
  const subs = userId
    ? db.all<{ endpoint: string; keys: string }>('SELECT endpoint, keys FROM push_subscriptions WHERE household_id = ? AND user_id = ?', householdId, userId)
    : db.all<{ endpoint: string; keys: string }>('SELECT endpoint, keys FROM push_subscriptions WHERE household_id = ?', householdId);
  let sent = 0;
  for (const s of subs) {
    try {
      await sender({ endpoint: s.endpoint, keys: JSON.parse(s.keys) }, JSON.stringify(payload));
      sent++;
    } catch (e: any) {
      if (e?.statusCode === 404 || e?.statusCode === 410) db.run('DELETE FROM push_subscriptions WHERE endpoint = ?', s.endpoint);
      else log.warn('push failed', { status: e?.statusCode, err: e?.message });
    }
  }
  return sent;
}
