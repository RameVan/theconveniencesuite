// In-process background jobs (no queue infrastructure needed for a household app).
import { readdirSync, rmSync } from 'node:fs';
import path from 'node:path';
import type { Db } from './db/db.ts';
import { newId } from './db/db.ts';
import { clock, addDays } from './clock.ts';
import { config } from './config.ts';
import { log } from './log.ts';
import { bus } from './bus.ts';
import { inventorySummary } from './domain/inventory.ts';
import { completeTrip } from './domain/shopping.ts';
import { newCtx } from './domain/ledger.ts';
import { checkinSettings, pendingCheckins } from './domain/checkins.ts';
import { pushToHousehold } from './push.ts';
import { notificationPrefs, interactionPrefs } from './domain/personal.ts';
import { autoPlanPrefs } from './domain/autoplan.ts';
import { game } from './domain/game.ts';

interface Note { kind: string; title: string; body: string; ref: string | null; key: string; url?: string }

/** Minutes since local midnight. */
const minutesOf = (x: string | Date) => (typeof x === 'string' ? Number(x.slice(0, 2)) * 60 + Number(x.slice(3, 5)) : x.getHours() * 60 + x.getMinutes());

/** Store (once, by dedupe key) and push. Returns whether it was new. */
async function deliver(db: Db, householdId: string, n: Note, push: boolean) {
  const r = db.run('INSERT OR IGNORE INTO notifications (id, household_id, kind, title, body, ref, dedupe_key, read, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)', newId('n'), householdId, n.kind, n.title, n.body, n.ref, n.key, clock.iso());
  if (!r.changes) return false;
  bus.touch(householdId, 'notifications');
  if (push) await pushToHousehold(db, householdId, { title: n.title, body: n.body, tag: n.key, url: n.url ?? '/#/' }).catch((e) => log.error('push failed', { err: e.message }));
  return true;
}

/**
 * Reminders, filtered by the household's notification settings (Settings → Personalise):
 * expiry, leftovers and defrost; shopping for tomorrow; tonight's dinner; weekly planning; an
 * evening streak nudge (off by default) and a challenge ending. Deduplicated per item per day.
 * "Daily" frequency bundles the day's reminders into one summary instead.
 */
export async function generateNotifications(db: Db, opts: { push?: boolean } = {}) {
  const today = clock.today();
  const now = clock.now();
  for (const { id: h } of db.all<{ id: string }>('SELECT id FROM households')) {
    const prefs = notificationPrefs(db, h);
    if (prefs.frequency === 'off') continue;
    const notes: Note[] = [];
    if (prefs.expiry) {
      const { items, leftovers } = inventorySummary(db, h);
      for (const s of items) {
        if (s.confirmed <= 0) continue;
        if (s.daysToExpiry != null && s.daysToExpiry <= 1 && s.daysToExpiry >= -1) {
          notes.push({ kind: 'expiry', title: `${s.product.name} ${s.daysToExpiry < 0 ? 'is past its date' : s.daysToExpiry === 0 ? 'expires today' : 'expires tomorrow'}`, body: 'Use it first, or freeze it if you can.', ref: s.product.id, key: `expiry:${s.product.id}:${today}`, url: '/#/inventory' });
        }
        if (s.runOutOn && s.prediction.confidence >= 0.5 && s.daysLeft != null && s.daysLeft <= 1.5 && !s.product.staple) {
          notes.push({ kind: 'runout', title: `${s.product.name} is probably running out`, body: 'Added to suggestions on your shopping list.', ref: s.product.id, key: `runout:${s.product.id}:${today}`, url: '/#/shopping' });
        }
      }
      for (const l of leftovers) {
        if (l.location_kind !== 'freezer' && l.days_to_expiry != null && l.days_to_expiry <= 1) {
          notes.push({ kind: 'leftover', title: `Eat the ${l.title.toLowerCase()} leftovers`, body: `${l.quantity} portion(s) in the fridge.`, ref: l.id, key: `leftover:${l.id}:${today}` });
        }
      }
      // Defrost reminders: tomorrow's planned meal uses frozen leftovers.
      for (const s of db.all<{ id: string; leftover_lot_id: string; label: string; kind: string }>(
        `SELECT m.id, m.leftover_lot_id, l.label, st.kind FROM meal_slots m JOIN inventory_lots l ON l.id = m.leftover_lot_id
         LEFT JOIN storage_locations st ON st.id = l.location_id WHERE m.household_id = ? AND m.date = ? AND m.status = 'planned'`, h, addDays(today, 1))) {
        if (s.kind === 'freezer') notes.push({ kind: 'defrost', title: `Defrost the ${s.label.toLowerCase()} tonight`, body: 'It is planned for tomorrow.', ref: s.leftover_lot_id, key: `defrost:${s.id}` });
      }
    }
    if (prefs.shopping && now.getHours() >= 15) {
      const tomorrow = db.get<{ title: string }>("SELECT r.title FROM meal_slots m JOIN recipes r ON r.id = m.recipe_id WHERE m.household_id = ? AND m.date = ? AND m.meal = 'dinner' AND m.status = 'planned'", h, addDays(today, 1));
      const open = db.get<{ n: number }>("SELECT COUNT(*) n FROM shopping_items WHERE household_id = ? AND checked = 0 AND (plan_driven = 1 OR reason = 'meal_plan')", h)!.n;
      if (tomorrow && open) notes.push({ kind: 'shopping', title: `${open} item${open === 1 ? '' : 's'} to buy for your plan`, body: `Tomorrow: ${tomorrow.title}.`, ref: null, key: `shopping:${today}`, url: '/#/shopping' });
    }
    if (prefs.prep && minutesOf(now) >= minutesOf(prefs.prepTime)) {
      const tonight = db.get<{ title: string; m: number }>("SELECT r.title, r.prep_minutes + r.cook_minutes m FROM meal_slots s JOIN recipes r ON r.id = s.recipe_id WHERE s.household_id = ? AND s.date = ? AND s.meal = 'dinner' AND s.status = 'planned'", h, today);
      if (tonight) notes.push({ kind: 'prep', title: `Tonight: ${tonight.title}`, body: `About ${tonight.m} minutes. Tap to start cooking.`, ref: null, key: `prep:${today}`, url: '/#/plan' });
    }
    if (prefs.plan && new Date(today + 'T12:00:00Z').getUTCDay() === autoPlanPrefs(db, h).planningDay && now.getHours() >= 10) {
      const planned = db.get<{ n: number }>("SELECT COUNT(DISTINCT date) n FROM meal_slots WHERE household_id = ? AND meal = 'dinner' AND status != 'skipped' AND date BETWEEN ? AND ?", h, today, addDays(today, 6))!.n;
      if (planned < 4) notes.push({ kind: 'plan', title: 'Plan the week in one tap', body: `${7 - planned} evenings have no dinner planned yet.`, ref: null, key: `plan:${today}`, url: '/#/plan?auto=1' });
    }
    if ((prefs.streak || prefs.challenge) && now.getHours() >= 18) {
      const g = game(db, h);
      if (prefs.streak && g.streaks.cooking.current >= 3 && !g.streaks.cooking.cookedToday) notes.push({ kind: 'streak', title: `Your ${g.streaks.cooking.current}-day cooking streak`, body: 'Cooking tonight keeps it going. A rest day is fine too: one a week is free.', ref: null, key: `streak:${today}` });
      const c = g.challenge.current;
      if (prefs.challenge && c && !c.done && c.end === addDays(today, 1)) notes.push({ kind: 'challenge', title: 'Your challenge ends tomorrow', body: `${c.progress} of ${c.goal} done.`, ref: null, key: `challenge:${c.id}:${c.end}`, url: '/#/progress' });
    }
    if (!notes.length) continue;
    if (prefs.frequency === 'daily') {
      const fresh = notes.filter((n) => !db.get('SELECT 1 FROM notifications WHERE household_id = ? AND dedupe_key = ?', h, n.key));
      if (!fresh.length || db.get('SELECT 1 FROM notifications WHERE household_id = ? AND dedupe_key = ?', h, `digest:${today}`)) continue;
      // Mark the bundled ones as handled so they don't reappear individually.
      for (const n of fresh) db.run('INSERT OR IGNORE INTO notifications (id, household_id, kind, title, body, ref, dedupe_key, read, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)', newId('n'), h, n.kind, n.title, n.body, n.ref, n.key, clock.iso());
      await deliver(db, h, { kind: 'digest', title: 'Today in your kitchen', body: fresh.slice(0, 4).map((n) => n.title).join(' · '), ref: null, key: `digest:${today}` }, opts.push ?? true);
    } else {
      for (const n of notes) await deliver(db, h, n, (opts.push ?? true) && n.kind !== 'runout');
    }
  }
}

/** Ticked items left on the list for 6+ hours were bought: move them into inventory (unless switched off). */
export function autoCompleteTrips(db: Db) {
  const cutoff = new Date(clock.now().getTime() - 6 * 3_600_000).toISOString();
  for (const { household_id } of db.all<{ household_id: string }>('SELECT DISTINCT household_id FROM shopping_items WHERE checked = 1 AND checked_at < ?', cutoff)) {
    if (!interactionPrefs(db, household_id).shoppingAutoComplete) continue;
    const ids = db.all<{ id: string }>('SELECT id FROM shopping_items WHERE household_id = ? AND checked = 1 AND checked_at < ?', household_id, cutoff).map((r) => r.id);
    const res = completeTrip(newCtx(db, household_id, 'shopping_list'), { itemIds: ids });
    log.info('auto-completed shopping trip', { household_id, items: res.added.length });
  }
}

export function backup(db: Db) {
  const file = path.join(config.backupDir, `larder-${clock.today()}.db`);
  try {
    rmSync(file, { force: true });
    db.backupTo(file);
    const files = readdirSync(config.backupDir).filter((f) => /^larder-\d{4}-\d{2}-\d{2}\.db$/.test(f)).sort();
    for (const old of files.slice(0, Math.max(0, files.length - config.backupKeep))) rmSync(path.join(config.backupDir, old), { force: true });
    log.info('backup written', { file });
  } catch (e: any) {
    log.error('backup failed', { err: e.message });
  }
}

/**
 * Daily "Did you cook X?" question. Once the household's check-in time has passed, each planned
 * meal that's still open gets one in-app notification and one push (with Yes / No buttons).
 */
export async function sendCheckins(db: Db) {
  for (const { id: h } of db.all<{ id: string }>('SELECT id FROM households')) {
    if (!checkinSettings(db, h).enabled) continue;
    for (const c of pendingCheckins(db, h)) {
      const lang = db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = '' AND key = 'language'", h)?.value?.includes('nl') ? 'nl' : 'en';
      const title = lang === 'nl' ? `Heb je ${c.title} gekookt${c.when === 'yesterday' ? ' (gisteren)' : ''}?` : `Did you cook ${c.title}${c.when === 'yesterday' ? ' yesterday' : ''}?`;
      const body = lang === 'nl' ? 'Tik op Ja en de ingrediënten gaan uit je voorraad.' : 'Tap Yes and the ingredients come out of your inventory.';
      const r = db.run(
        'INSERT OR IGNORE INTO notifications (id, household_id, kind, title, body, ref, dedupe_key, read, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)',
        newId('n'), h, 'checkin', title, body, c.slotId, `checkin:${c.slotId}:${c.date}`, clock.iso(),
      );
      if (!r.changes) continue; // already asked about this meal
      bus.touch(h, 'notifications');
      await pushToHousehold(db, h, {
        title, body, tag: `checkin-${c.slotId}`, url: `/#/?checkin=${c.slotId}`, slotId: c.slotId,
        actions: [{ action: 'cooked', title: lang === 'nl' ? 'Ja, gekookt' : 'Yes, cooked' }, { action: 'not_cooked', title: lang === 'nl' ? 'Nee' : 'No' }],
      });
    }
  }
}

export function startScheduler(db: Db) {
  let lastBackup = '';
  const tick = () => {
    sendCheckins(db).catch((e) => log.error('check-in push failed', { err: e.message }));
    generateNotifications(db).catch((e) => log.error('notifications failed', { err: e.message }));
    try {
      autoCompleteTrips(db);
      db.run('DELETE FROM sessions WHERE expires_at < ?', clock.iso());
      if (lastBackup !== clock.today()) {
        backup(db);
        lastBackup = clock.today();
      }
    } catch (e: any) {
      log.error('scheduler tick failed', { err: e.message });
    }
  };
  setTimeout(tick, 5_000).unref();
  // Every 10 minutes, so the daily question arrives close to the chosen time.
  return setInterval(tick, 10 * 60_000).unref();
}
