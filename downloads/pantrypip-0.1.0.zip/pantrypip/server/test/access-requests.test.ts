// "Request access" on an invite-only copy: a visitor leaves a name and email, the owner approves or declines,
// and an approval mails a one-time link that makes the account (the link proves the address).
import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import type { AddressInfo } from 'node:net';
import { createApp } from '../src/index.ts';
import { clock } from '../src/clock.ts';
import { config } from '../src/config.ts';
import { captureMail, outbox } from '../src/mail.ts';
import { setPushSender, saveSubscription } from '../src/push.ts';
import { registerUser, clearFailures } from '../src/http/auth.ts';
import { createHousehold } from '../src/db/seed.ts';

const app = createApp(':memory:', { seedDemo: false, emailConfirm: true, inviteOnly: true });
let url = '';
const pushes: any[] = [];
const ownerEmailBefore = config.ownerEmail;

/** A client with its own cookie jar. Every client here comes from 127.0.0.1, so each test starts with a clean per-IP limit. */
const client = () => {
  let cookie = '';
  return async (method: string, path: string, body?: unknown) => {
    const res = await fetch(url + path, { method, headers: { 'content-type': 'application/json', cookie }, body: body === undefined ? undefined : JSON.stringify(body) });
    const set = res.headers.get('set-cookie');
    if (set) cookie = set.split(';')[0];
    const text = await res.text();
    return { status: res.status, body: text ? JSON.parse(text) : null } as { status: number; body: any };
  };
};
const owner = client();
const stranger = client();
const settle = () => new Promise((r) => setTimeout(r, 50));
const tokenIn = (text: string) => text.match(/#\/access\/([A-Za-z0-9_-]+)/)![1];
const users = () => app.db.get<{ n: number }>('SELECT COUNT(*) n FROM users')!.n;

const visitor = () => client();

before(async () => {
  clock.set(null);
  captureMail(true);
  setPushSender(async (_sub, payload) => pushes.push(JSON.parse(payload)));
  await new Promise<void>((r) => app.server.listen(0, '127.0.0.1', () => r()));
  url = `http://127.0.0.1:${(app.server.address() as AddressInfo).port}`;
  const o = app.db.tx(() => registerUser(app.db, { email: 'owner@larder.test', password: 'a-long-password', name: 'Owner' }, (n) => createHousehold(app.db, n)));
  const s = app.db.tx(() => registerUser(app.db, { email: 'someone@larder.test', password: 'a-long-password', name: 'Someone' }, (n) => createHousehold(app.db, n)));
  saveSubscription(app.db, o.household_id, o.id, { endpoint: 'https://push.example.test/owner', keys: { p256dh: 'x', auth: 'y' } });
  config.ownerEmail = 'owner@larder.test';
  assert.equal((await owner('POST', '/api/auth/login', { email: o.email, password: 'a-long-password' })).status, 200);
  assert.equal((await stranger('POST', '/api/auth/login', { email: s.email, password: 'a-long-password' })).status, 200);
});
after(async () => {
  config.ownerEmail = ownerEmailBefore;
  captureMail(false);
  clock.set(null);
  await new Promise<void>((r) => app.server.close(() => (app.db.close(), r())));
});
beforeEach(() => ['127.0.0.1', '::ffff:127.0.0.1'].forEach((ip) => clearFailures(`access:${ip}`)));

test('request → owner approves → email link → account, signed in, without a second confirmation', async () => {
  const before = users();
  const v = visitor();
  const r = await v('POST', '/api/auth/access-request', { name: 'Rosa', email: 'rosa@larder.test', note: 'Friend of Sam', lang: 'nl' });
  assert.equal(r.status, 202);
  assert.equal(users(), before, 'nothing but the request is made');
  await settle();
  assert.equal(pushes.at(-1).title, 'PantryPip access request');
  assert.equal(pushes.at(-1).body, 'Rosa would like an account');
  assert.ok(!JSON.stringify(pushes.at(-1)).includes('@'), 'the address stays out of the push');

  const list = (await owner('GET', '/api/access-requests')).body.requests;
  const req = list.find((x: any) => x.email === 'rosa@larder.test');
  assert.deepEqual([req.name, req.note, req.status, req.hasAccount], ['Rosa', 'Friend of Sam', 'pending', false]);

  const sentBefore = outbox.length;
  const ok = await owner('POST', `/api/access-requests/${req.id}/approve`);
  assert.equal(ok.status, 200);
  const mail = outbox.at(-1)!;
  assert.equal(outbox.length, sentBefore + 1);
  assert.equal(mail.to, 'rosa@larder.test');
  assert.match(mail.subject, /PantryPip-account/, 'in the language they asked in');
  const token = tokenIn(mail.text);

  // The link shows who it's for; the address can't be changed.
  const check = await v('POST', '/api/auth/access/check', { token });
  assert.deepEqual(check.body, { valid: true, email: 'rosa@larder.test', name: 'Rosa' });
  const made = await v('POST', '/api/auth/access', { token, name: 'Rosa B', password: 'rosa-long-password', email: 'other@larder.test' });
  assert.equal(made.status, 201);
  assert.equal(outbox.length, sentBefore + 1, 'no confirmation email: the link already proved the address');
  const me = (await v('GET', '/api/me')).body;
  assert.equal(me.user.email, 'rosa@larder.test');
  assert.equal(me.user.name, 'Rosa B');
  assert.equal(users(), before + 1);
  assert.ok(!(await owner('GET', '/api/access-requests')).body.requests.some((x: any) => x.id === req.id), 'used requests leave the list');
  // And the new account signs in like any other.
  assert.equal((await visitor()('POST', '/api/auth/login', { email: 'rosa@larder.test', password: 'rosa-long-password' })).status, 200);
});

test('a used link works once; an expired one stops after 7 days, and the owner can send a fresh one', async () => {
  await visitor()('POST', '/api/auth/access-request', { name: 'Tom', email: 'tom@larder.test' });
  const id = (await owner('GET', '/api/access-requests')).body.requests.find((x: any) => x.email === 'tom@larder.test').id;
  await owner('POST', `/api/access-requests/${id}/approve`);
  const old = tokenIn(outbox.at(-1)!.text);

  clock.set(new Date(Date.now() + 8 * 86_400_000));
  try {
    const v = visitor();
    assert.equal((await v('POST', '/api/auth/access/check', { token: old })).body.valid, false);
    const late = await v('POST', '/api/auth/access', { token: old, name: 'Tom', password: 'tom-long-password' });
    assert.equal(late.status, 410);
    assert.equal(late.body.error.code, 'link_expired');
    assert.equal((await owner('GET', '/api/access-requests')).body.requests.find((x: any) => x.id === id).linkExpired, true);

    await owner('POST', `/api/access-requests/${id}/approve`);
    const fresh = tokenIn(outbox.at(-1)!.text);
    assert.notEqual(fresh, old);
    assert.equal((await v('POST', '/api/auth/access', { token: old, name: 'Tom', password: 'tom-long-password' })).status, 410, 'the old link stays dead');
    assert.equal((await v('POST', '/api/auth/access', { token: fresh, name: 'Tom', password: 'tom-long-password' })).status, 201);
    const again = await visitor()('POST', '/api/auth/access', { token: fresh, name: 'Tom 2', password: 'tom-long-password' });
    assert.equal(again.status, 410, 'reusing a link fails');
    assert.equal(app.db.get<{ n: number }>("SELECT COUNT(*) n FROM users WHERE lower(email) = 'tom@larder.test'")!.n, 1);
  } finally {
    clock.set(null);
  }
});

test('declining sends nothing, closes the request, and the link-less request can’t be approved afterwards', async () => {
  await visitor()('POST', '/api/auth/access-request', { name: 'Vic', email: 'vic@larder.test' });
  const id = (await owner('GET', '/api/access-requests')).body.requests.find((x: any) => x.email === 'vic@larder.test').id;
  const sent = outbox.length;
  assert.equal((await owner('POST', `/api/access-requests/${id}/decline`)).status, 200);
  assert.equal(outbox.length, sent, 'no email on decline');
  assert.ok(!(await owner('GET', '/api/access-requests')).body.requests.some((x: any) => x.id === id));
  assert.equal((await owner('POST', `/api/access-requests/${id}/approve`)).status, 404);
  assert.equal(app.db.get<{ status: string }>('SELECT status FROM access_requests WHERE id = ?', id)!.status, 'declined');
});

test('only the owner sees, approves or declines requests', async () => {
  await visitor()('POST', '/api/auth/access-request', { name: 'Wes', email: 'wes@larder.test' });
  const id = (await owner('GET', '/api/access-requests')).body.requests.find((x: any) => x.email === 'wes@larder.test').id;
  const sent = outbox.length;
  for (const [m, p] of [['GET', '/api/access-requests'], ['POST', `/api/access-requests/${id}/approve`], ['POST', `/api/access-requests/${id}/decline`]] as const) {
    const res = await stranger(m, p);
    assert.equal(res.status, 403, `${m} ${p}`);
    assert.equal(res.body.error.code, 'owner_only');
    assert.equal((await visitor()(m, p)).status, 401, `${m} ${p} signed out`);
  }
  assert.equal(outbox.length, sent);
  assert.equal(app.db.get<{ status: string }>('SELECT status FROM access_requests WHERE id = ?', id)!.status, 'pending');
});

test('the answer is the same for a new address, an existing account and a repeat request; only new ones reach the owner', async () => {
  const before = pushes.length;
  const rows = () => app.db.get<{ n: number }>('SELECT COUNT(*) n FROM access_requests')!.n;
  const r1 = await visitor()('POST', '/api/auth/access-request', { name: 'Xan', email: 'xan@larder.test' });
  const n = rows();
  const r2 = await visitor()('POST', '/api/auth/access-request', { name: 'Xan', email: 'XAN@larder.test' });
  const r3 = await visitor()('POST', '/api/auth/access-request', { name: 'Someone', email: 'someone@larder.test' });
  assert.deepEqual([r1, r2, r3].map((r) => [r.status, r.body]), Array(3).fill([202, { ok: true }]));
  assert.equal(rows(), n, 'a repeat or an existing account stores nothing new');
  await settle();
  assert.equal(pushes.length, before + 1);
});

test('requests are rate-limited per IP, and checked by zod', async () => {
  const v = visitor();
  for (let i = 0; i < 8; i++) assert.equal((await v('POST', '/api/auth/access-request', { name: 'Spam', email: `spam${i}@larder.test` })).status, 202);
  const ninth = await v('POST', '/api/auth/access-request', { name: 'Spam', email: 'spam9@larder.test' });
  assert.equal(ninth.status, 429);
  const bad = visitor();
  assert.equal((await bad('POST', '/api/auth/access-request', { name: '', email: 'x@larder.test' })).status, 400);
  assert.equal((await bad('POST', '/api/auth/access-request', { name: 'X', email: 'not-an-email' })).status, 400);
  assert.equal((await bad('POST', '/api/auth/access-request', { name: 'X', email: 'x@larder.test', note: 'x'.repeat(301) })).status, 400);
  assert.equal((await bad('POST', '/api/auth/access', { token: 'x'.repeat(40), name: 'X', password: 'short' })).status, 400);
});
