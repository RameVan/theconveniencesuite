// Accounts are only made once the email is confirmed; "forgot password" sends a one-time link.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import type { AddressInfo } from 'node:net';
import { createApp } from '../src/index.ts';
import { clock } from '../src/clock.ts';
import { captureMail, outbox } from '../src/mail.ts';

let app: ReturnType<typeof createApp>;
let url = '';
before(async () => {
  clock.set(null);
  captureMail(true);
  app = createApp(':memory:', { seedDemo: false, emailConfirm: true });
  await new Promise<void>((r) => app.server.listen(0, '127.0.0.1', () => r()));
  url = `http://127.0.0.1:${(app.server.address() as AddressInfo).port}`;
});
after(async () => {
  captureMail(false);
  await new Promise<void>((r) => app.server.close(() => r()));
  app.db.close();
});

/** A little client with its own cookie jar. */
const client = () => {
  let cookie = '';
  return async (method: string, path: string, body?: unknown) => {
    const res = await fetch(url + path, { method, headers: { 'content-type': 'application/json', cookie }, body: body === undefined ? undefined : JSON.stringify(body) });
    const set = res.headers.get('set-cookie');
    if (set) cookie = set.split(';')[0];
    const text = await res.text();
    return { status: res.status, body: text ? JSON.parse(text) : null };
  };
};
const linkIn = (text: string, kind: 'confirm' | 'reset') => text.match(new RegExp(`#/${kind}/([A-Za-z0-9_-]+)`))?.[1];

test('signing up makes no account until the emailed link is opened', async () => {
  const api = client();
  const r = await api('POST', '/api/auth/register', { email: 'new.person@larder.test', password: 'a-long-password', name: 'New' });
  assert.equal(r.status, 202);
  assert.equal(r.body.confirm, true);
  assert.equal(app.db.get('SELECT 1 FROM users WHERE email = ?', 'new.person@larder.test'), undefined, 'no account yet');
  assert.equal((await api('GET', '/api/me')).status, 401, 'not signed in yet');
  const mail = outbox.at(-1)!;
  assert.equal(mail.to, 'new.person@larder.test');
  const token = linkIn(mail.text, 'confirm');
  assert.ok(token, 'the email has a confirmation link');
  assert.equal((await api('POST', '/api/auth/login', { email: 'new.person@larder.test', password: 'a-long-password' })).status, 401, 'cannot sign in before confirming');
  const c = await api('POST', '/api/auth/confirm', { token });
  assert.equal(c.status, 201);
  assert.equal((await api('GET', '/api/me')).body.user.email, 'new.person@larder.test', 'confirming signs you in');
  assert.equal((await client()('POST', '/api/auth/confirm', { token })).status, 410, 'the link works once');
});

test('signing up with an email that has an account looks the same, and emails a reset link instead', async () => {
  const before = outbox.length;
  const r = await client()('POST', '/api/auth/register', { email: 'New.Person@larder.test', password: 'another-password', name: 'Someone' });
  assert.equal(r.status, 202, 'no hint that the address is taken');
  const mail = outbox.at(-1)!;
  assert.equal(outbox.length, before + 1);
  assert.ok(linkIn(mail.text, 'reset'), 'the owner of the address gets a reset link');
  assert.equal(app.db.get<{ n: number }>("SELECT count(*) n FROM users WHERE lower(email) = 'new.person@larder.test'")!.n, 1);
});

test('forgot password: one-time link, new password works, old one and old sessions stop', async () => {
  const old = client();
  assert.equal((await old('POST', '/api/auth/login', { email: 'new.person@larder.test', password: 'a-long-password' })).status, 200);
  const sent = outbox.length;
  const unknown = await client()('POST', '/api/auth/forgot', { email: 'nobody@larder.test' });
  assert.equal(unknown.status, 200, 'same answer for an unknown address');
  assert.equal(outbox.length, sent, 'and nothing is sent');
  const api = client();
  assert.equal((await api('POST', '/api/auth/forgot', { email: 'NEW.person@larder.test' })).status, 200);
  const token = linkIn(outbox.at(-1)!.text, 'reset')!;
  assert.ok(token);
  assert.deepEqual((await api('POST', '/api/auth/reset/check', { token })).body, { valid: true });
  assert.equal((await api('POST', '/api/auth/reset', { token, password: 'short' })).status, 400, 'at least 10 characters');
  assert.equal((await api('POST', '/api/auth/reset', { token, password: 'brand-new-password' })).status, 200);
  assert.equal((await api('GET', '/api/me')).status, 200, 'resetting signs you in');
  assert.equal((await old('GET', '/api/me')).status, 401, 'other devices are signed out');
  assert.equal((await client()('POST', '/api/auth/login', { email: 'new.person@larder.test', password: 'a-long-password' })).status, 401);
  assert.equal((await client()('POST', '/api/auth/login', { email: 'new.person@larder.test', password: 'brand-new-password' })).status, 200);
  assert.equal((await client()('POST', '/api/auth/reset', { token, password: 'yet-another-one' })).status, 410, 'the link works once');
});

test('a reset link stops working after an hour', async () => {
  const api = client();
  await api('POST', '/api/auth/forgot', { email: 'new.person@larder.test' });
  const token = linkIn(outbox.at(-1)!.text, 'reset')!;
  clock.set(new Date(Date.now() + 61 * 60_000));
  try {
    assert.deepEqual((await api('POST', '/api/auth/reset/check', { token })).body, { valid: false });
    assert.equal((await api('POST', '/api/auth/reset', { token, password: 'brand-new-password-2' })).status, 410);
  } finally {
    clock.set(null);
  }
});
