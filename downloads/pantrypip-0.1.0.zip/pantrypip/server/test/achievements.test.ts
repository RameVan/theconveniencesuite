// The achievements overview: everything earned, newest first.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, type TestApp } from './helpers.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});

test('lists earned achievements with titles, kinds and totals', async () => {
  const empty = (await app.api('GET', '/api/achievements')).body;
  assert.ok(Array.isArray(empty.items));
  assert.equal(typeof empty.badges.all, 'number');
  assert.ok(empty.badges.all > 0);

  const ids = app.db.all<{ id: string }>("SELECT id FROM recipes WHERE household_id IS NULL ORDER BY id LIMIT 3").map((r) => r.id);
  for (const id of ids) await app.api('POST', `/api/recipes/${id}/save`, {});
  await app.api('POST', '/api/plan', { date: new Date().toISOString().slice(0, 10), meal: 'dinner', recipeId: ids[0] });

  const r = await app.api('GET', '/api/achievements');
  assert.equal(r.status, 200);
  const { items, total, xp } = r.body;
  assert.equal(total, items.length);
  assert.equal(xp, items.reduce((s: number, i: any) => s + i.xp, 0));
  for (const i of items) {
    assert.ok(i.title && i.title_nl, `${i.id} has a title in both languages`);
    assert.ok(['journey', 'bonus', 'chest', 'chapter', 'track', 'badge', 'challenge', 'friends'].includes(i.group), i.group);
  }
  const dated = items.filter((i: any) => i.at).map((i: any) => i.at);
  assert.deepEqual(dated, [...dated].sort().reverse(), 'newest first');
});
