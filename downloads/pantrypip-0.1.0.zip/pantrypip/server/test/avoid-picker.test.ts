// "Doesn't eat": suggestions while typing, and several items typed at once.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, type TestApp } from './helpers.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});
const suggest = async (q: string, lang = 'en') => (await app.api('GET', `/api/products/suggest?q=${encodeURIComponent(q)}&lang=${lang}`)).body.map((p: any) => p.name) as string[];

test('suggestions appear from the first letters, best fit first', async () => {
  assert.equal((await suggest('mush'))[0], 'Mushrooms', 'a half-typed word already finds it');
  assert.ok((await suggest('tom')).includes('Tomatoes'));
  assert.ok((await suggest('onio')).every((n) => /onion/i.test(n)), 'no unrelated guesses');
  const pork = await suggest('pork');
  assert.ok(pork.length >= 2 && pork.every((n) => /pork/i.test(n)));
  assert.deepEqual(await suggest('m'), [], 'nothing on a single letter is fine, the field waits for two');
});

test('Dutch names are suggested too', async () => {
  assert.ok((await suggest('champ', 'nl')).some((n) => /champignon/i.test(n)));
});

test('a typed list becomes one product per item, and unknown items are named', async () => {
  const r = await app.api('POST', '/api/products/resolve-list?lang=en', { text: 'mushrooms, tomatoes and pork mince; zzqx' });
  assert.equal(r.status, 200);
  assert.deepEqual(r.body.map((x: any) => [x.term, x.product?.name ?? null]), [
    ['mushrooms', 'Mushrooms'], ['tomatoes', 'Tomatoes'], ['pork mince', 'Pork mince'], ['zzqx', null],
  ]);
});

test('avoided items come back with their names, so chips never show ids', async () => {
  const d = (await app.api('GET', '/api/dietary')).body;
  const ids = (await app.api('POST', '/api/products/resolve-list', { text: 'mushrooms, tomatoes' })).body.map((x: any) => x.product.id);
  const people = d.people.map((p: any, i: number) => (i === 0 ? { ...p, avoid: ids } : p));
  assert.equal((await app.api('PUT', '/api/dietary', { people })).status, 200);
  const after = (await app.api('GET', '/api/dietary')).body;
  assert.deepEqual(ids.map((id: string) => after.names[id][0]), ['Mushrooms', 'Tomatoes']);
});
