// Bulk recipe import from RecipeNLG CSV and Wikibooks JSON (sample files in the real formats).
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { writeFileSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { startApp, type TestApp } from './helpers.ts';
import { importRecipes, recipeNlg, wikibooks, removeImported, normaliseLine, tagsFor, csvRows } from '../src/import/bulk-recipes.ts';
import { listRecipes } from '../src/domain/recipes.ts';

let app: TestApp;
const dir = mkdtempSync(path.join(tmpdir(), 'pp-import-'));
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});

const csvField = (s: string) => (/[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s);
function nlgCsv(rows: { title: string; ingredients: string[]; directions: string[]; link: string; source?: string; ner: string[] }[]) {
  const lines = [',title,ingredients,directions,link,source,NER'];
  rows.forEach((r, i) => lines.push([String(i), r.title, JSON.stringify(r.ingredients), JSON.stringify(r.directions), r.link, r.source ?? 'Gathered', JSON.stringify(r.ner)].map(csvField).join(',')));
  const file = path.join(dir, `nlg-${Math.random().toString(36).slice(2)}.csv`);
  writeFileSync(file, lines.join('\n') + '\n');
  return file;
}

const GOOD = {
  title: 'Chicken And Rice Skillet',
  ingredients: ['1 lb. chicken breasts, cubed', '1 c. rice', '1 (14 oz.) can diced tomatoes', '1 onion, chopped', '2 cloves garlic', '1 Tbsp. olive oil', '2 c. water'],
  directions: ['Brown the chicken in the oil.', 'Add onion and garlic and cook 5 minutes.', 'Add rice, tomatoes and water; simmer 20 minutes until the rice is tender.'],
  link: 'www.example-recipes.test/chicken-rice', ner: ['chicken breasts', 'rice', 'tomatoes', 'onion', 'garlic', 'olive oil', 'water'],
};

test('US measures become units the parser knows', () => {
  assert.equal(normaliseLine('1 (14 oz.) can diced tomatoes'), '14 oz diced tomatoes');
  assert.equal(normaliseLine('2 (10 oz.) pkg. frozen spinach'), '20 oz frozen spinach');
  assert.equal(normaliseLine('1 c. rice'), '1 cup rice');
  assert.equal(normaliseLine('2 T butter'), '2 tbsp butter');
  assert.equal(normaliseLine('1 t salt'), '1 tsp salt');
  assert.equal(normaliseLine('1 1/2 lb. ground beef'), '1 1/2 lb ground beef');
});

test('CSV reader handles quotes, commas and newlines inside fields', async () => {
  const file = path.join(dir, 'tricky.csv');
  writeFileSync(file, 'a,b,c\n1,"x, ""quoted""\nnext line",3\r\n4,5,6\n');
  const rows: string[][] = [];
  for await (const r of csvRows(file)) rows.push(r);
  assert.deepEqual(rows, [['a', 'b', 'c'], ['1', 'x, "quoted"\nnext line', '3'], ['4', '5', '6']]);
  // Every possible split between file chunks, including in the middle of "" and \r\n.
  for (const size of [1, 2, 3, 5, 7]) {
    const again: string[][] = [];
    for await (const r of csvRows(file, size)) again.push(r);
    assert.deepEqual(again, rows, `chunk size ${size}`);
  }
});

test('titles get the right kind, so desserts and sauces stay out of dinner planning', () => {
  assert.deepEqual(tagsFor('Grandma’s Apple Pie'), ['dessert']);
  assert.ok(tagsFor('Chocolate Chip Cookies').includes('dessert'));
  assert.ok(tagsFor('Banana Bread').includes('baking'));
  assert.ok(tagsFor('Easy Barbecue Sauce').includes('side'));
  assert.deepEqual(tagsFor('Chicken in Mushroom Sauce'), [], 'a main named after its sauce stays a dinner');
  assert.deepEqual(tagsFor('Beef Stew'), ['soup']);
});

test('RecipeNLG: only well-matched recipes get in, with amounts, credits and no duplicates', async () => {
  const file = nlgCsv([
    GOOD,
    { ...GOOD, title: 'chicken and rice skillet', link: 'www.other.test/x' }, // duplicate title
    { ...GOOD, title: 'Chicken Rice From Recipes1M', link: 'www.x.test/1m', source: 'Recipes1M' }, // not Gathered
    { title: 'Mystery Bake', ingredients: ['1 c. snozzberries', '2 c. wumpus flour', '1 jar of fizzlewhip', '1 egg'], directions: ['Mix everything and bake for 30 minutes at 180 degrees.'], link: 'www.x.test/m', ner: ['snozzberries', 'wumpus flour', 'fizzlewhip', 'egg'] },
    { title: 'Chocolate Chip Cookies', ingredients: ['1 c. butter', '1 c. sugar', '2 eggs', '2 1/4 c. flour', '1 c. dark chocolate'], directions: ['Cream butter and sugar, beat in eggs.', 'Stir in flour and chocolate, bake 10 minutes.'], link: 'www.x.test/cookies', ner: ['butter', 'sugar', 'eggs', 'flour', 'chocolate'] },
  ]);
  const before = listRecipes(app.db, app.householdId).length;
  const r = await importRecipes(app.db, recipeNlg(file), { limit: 100 });
  assert.equal(r.read, 4, 'the Recipes1M row is skipped');
  assert.equal(r.imported, 2, JSON.stringify(r));
  assert.ok(r.duplicates >= 1);
  const all = listRecipes(app.db, app.householdId);
  assert.equal(all.length, before + 2, 'the running cache sees new recipes');
  const rec = all.find((x) => x.title === 'Chicken And Rice Skillet')!;
  assert.equal(rec.origin, 'external');
  assert.equal(rec.source_name, 'example-recipes.test');
  assert.equal(rec.source_url, 'https://www.example-recipes.test/chicken-rice');
  assert.match(rec.attribution ?? '', /RecipeNLG/);
  const q = (pid: string) => rec.ingredients.find((i) => i.product_id === pid)?.quantity;
  assert.ok(Math.abs(q('p_chicken_breast')! - 453.6) < 1, '1 lb chicken');
  assert.equal(q('p_canned_tomatoes'), 396.9, '14 oz tin');
  assert.ok(rec.nutritionPerServing!.kcal > 200);
  assert.ok(rec.servings >= 2 && rec.servings <= 6, `servings ${rec.servings}`);
  const cookies = all.find((x) => x.title === 'Chocolate Chip Cookies')!;
  assert.ok(cookies.tags.includes('dessert'));
  // Running it again adds nothing.
  assert.equal((await importRecipes(app.db, recipeNlg(file), { limit: 100 })).imported, 0);
});

test('Wikibooks JSON: title, sections, infobox servings and time, CC BY-SA credit', async () => {
  const file = path.join(dir, 'wb.json');
  writeFileSync(file, JSON.stringify([
    {
      filename: 'recipes/recipe_00_000.html',
      recipe_data: {
        url: 'https://en.wikibooks.org/wiki/Cookbook:Lentil_Soup', title: 'Lentil Soup',
        infobox: { category: '/wiki/Category:Soup_recipes', servings: '4', time: 'Prep: 10 minutesCooking: 35 minutes', difficulty: 2 },
        text_lines: [
          { text: 'A simple soup.', line_type: 'p', section: null },
          { text: '200 g red lentils', line_type: 'ul', section: 'Ingredients' },
          { text: '1 onion', line_type: 'ul', section: 'Ingredients' },
          { text: '2 carrots', line_type: 'ul', section: 'Ingredients' },
          { text: '1 l water', line_type: 'ul', section: 'Ingredients' },
          { text: '1 stock cube', line_type: 'ul', section: 'Ingredients' },
          { text: 'Chop the onion and carrots.', line_type: 'ol', section: 'Procedure' },
          { text: 'Simmer everything for 30 minutes and blend.', line_type: 'ol', section: 'Procedure' },
        ],
      },
    },
    { filename: 'recipes/recipe_00_001.html', recipe_data: { url: '/wiki/Cookbook:Nothing', title: 'Nothing', infobox: null, text_lines: [] } },
  ]));
  const r = await importRecipes(app.db, wikibooks(file), { limit: 100 });
  assert.equal(r.imported, 1, JSON.stringify(r));
  const rec = listRecipes(app.db, app.householdId).find((x) => x.title === 'Lentil Soup')!;
  assert.equal(rec.servings, 4);
  assert.equal(rec.prep_minutes + rec.cook_minutes, 45);
  assert.equal(rec.difficulty, 'easy');
  assert.equal(rec.source_name, 'Wikibooks Cookbook');
  assert.match(rec.attribution ?? '', /CC BY-SA 4\.0/);
  assert.ok(rec.tags.includes('soup'));
  assert.equal(rec.steps.length, 2);
});

test('a source can be removed again; recipes you used stay', async () => {
  const id = listRecipes(app.db, app.householdId).find((x) => x.title === 'Chicken And Rice Skillet')!.id;
  await app.api('POST', `/api/recipes/${id}/interaction`, { rating: 5 });
  const r = removeImported(app.db, 'recipenlg');
  assert.equal(r.kept, 1);
  assert.ok(r.removed >= 1);
  const left = listRecipes(app.db, app.householdId).filter((x) => x.id.startsWith('rx_nlg_'));
  assert.deepEqual(left.map((x) => x.id), [id]);
});

test('cooking times in the formats Wikibooks uses', async () => {
  const { minutesIn } = await import('../src/import/bulk-recipes.ts');
  assert.equal(minutesIn(['45 minutes']), 45);
  assert.equal(minutesIn(['1 hour']), 60);
  assert.equal(minutesIn(['45–60 minutes']), 60, 'a range counts as its upper end');
  assert.equal(minutesIn(['½ hour']), 30);
  assert.equal(minutesIn(['1½ hours']), 90);
  assert.equal(minutesIn(['1 hour 15 minutes']), 75);
  assert.equal(minutesIn(['2 h, 10 minutes']), 130);
  assert.equal(minutesIn(['Prep: 10 minutesCooking: 35 minutesTotal: 45 minutes']), 45, 'not added up twice');
  assert.equal(minutesIn(['Add 5 mint leaves']), 0, '"mint" is not minutes');
});

test('context rules: paprika the spice, coffee with chicory, one teabag, small measures', async () => {
  assert.equal(normaliseLine('1 tsp paprika'), '1 tsp paprika powder');
  assert.equal(normaliseLine('½ tsp smoked paprika'), '½ tsp smoked paprika powder');
  assert.equal(normaliseLine('2 paprika, diced'), '2 paprika, diced', 'whole peppers stay peppers');
  assert.equal(normaliseLine('2 tsp instant coffee with chicory root'), '2 tsp instant coffee');
  assert.equal(normaliseLine('1 bag Earl Grey tea'), '1 Earl Grey tea');
  const { parseIngredientLine } = await import('../src/domain/recipe-import.ts');
  const salt = parseIngredientLine(app.db, '', '1 pinch of salt');
  assert.equal(salt.productId, 'p_salt');
  assert.ok(salt.quantity! < 1, `a pinch is not a pack (${salt.quantity})`);
  assert.equal(parseIngredientLine(app.db, '', normaliseLine('1 tsp paprika')).productId, 'p_paprika_powder');
});

test('recipes missing their main ingredient, or meat without an amount, are left out; tap water is no product', async () => {
  const file = nlgCsv([
    { title: 'Roast Turkey Dinner', ingredients: ['1 (12 lb.) turkey', '3 onions', '2 carrots', '1 Tbsp. butter', '1 tsp. salt'], directions: ['Roast the turkey with the vegetables for 3 hours, basting with butter.'], link: 'www.x.test/turkey', ner: ['turkey', 'onions', 'carrots', 'butter', 'salt'] },
    { title: 'Chicken Rice Pot', ingredients: ['chicken pieces', '1 c. rice', '1 onion', '2 c. water', '1 Tbsp. olive oil'], directions: ['Brown the chicken in the oil, add the rest and simmer 25 minutes.'], link: 'www.x.test/crp', ner: ['chicken', 'rice', 'onion', 'water', 'olive oil'] },
    { title: 'Lentil Pot', ingredients: ['1 c. lentils', '1 onion', '2 carrots', '4 c. water', '1 Tbsp. olive oil'], directions: ['Soften the onion and carrots in the oil, add lentils and water, simmer 25 minutes.'], link: 'www.x.test/lp', ner: ['lentils', 'onion', 'carrots', 'water', 'olive oil'] },
  ]);
  const r = await importRecipes(app.db, recipeNlg(file), { limit: 100 });
  const titles = listRecipes(app.db, app.householdId).filter((x) => x.id.startsWith('rx_nlg_')).map((x) => x.title);
  assert.ok(!titles.includes('Roast Turkey Dinner'), 'no turkey in the catalogue: left out');
  assert.ok(!titles.includes('Chicken Rice Pot'), 'chicken without an amount: left out');
  assert.ok(titles.includes('Lentil Pot'), JSON.stringify(r));
  const lp = listRecipes(app.db, app.householdId).find((x) => x.title === 'Lentil Pot')!;
  const water = lp.ingredients.find((i) => /water/.test(i.display ?? ''))!;
  assert.equal(water.product_id, null, 'tap water stays text');
});

test('broth, bouillon, spice powders, chillies and sizes in brackets', async () => {
  const { parseIngredientLine } = await import('../src/domain/recipe-import.ts');
  const pid = (s: string) => parseIngredientLine(app.db, '', normaliseLine(s)).productId;
  // Each spice is its own product; a habanero is substituted visibly; an unknown blend stays unresolved.
  assert.equal(pid('1 tsp cayenne pepper'), 'p_cayenne');
  assert.equal(pid('1 teaspoon chili powder'), 'p_chili_powder');
  assert.equal(pid('2 habanero peppers, chopped'), 'p_madame_jeanette');
  assert.equal(pid('1 tsp garam masala'), 'p_garam_masala');
  assert.equal(pid('2 tablespoons butter chicken masala powder'), null);
  assert.equal(pid('2 chicken bouillon cubes'), 'p_stock_cube');
  assert.equal(normaliseLine('1 ea. (3–4 pounds) broiler chicken'), '4 pounds broiler chicken');
  const file = nlgCsv([{ title: 'Simple Chicken Soup', ingredients: ['1 lb. chicken breasts', '1 quart chicken broth', '2 carrots', '1 onion', '1 tsp. garlic powder'], directions: ['Simmer the chicken with the vegetables in the broth for 30 minutes, then shred it.'], link: 'www.x.test/soup', ner: ['chicken breasts', 'chicken broth', 'carrots', 'onion', 'garlic powder'] }]);
  await importRecipes(app.db, recipeNlg(file), { limit: 10 });
  const soup = listRecipes(app.db, app.householdId).find((x) => x.title === 'Simple Chicken Soup')!;
  const broth = soup.ingredients.find((i) => /broth/.test(i.display ?? ''))!;
  assert.equal(broth.product_id, 'p_broth', 'broth is broth, not chicken');
  assert.ok(Math.abs(soup.ingredients.find((i) => i.product_id === 'p_chicken_breast')!.quantity! - 453.6) < 1);
});

test('components and sauces are not dinners', () => {
  assert.ok(tagsFor('Potato and Garlic Ravioli Filling').includes('side'));
  assert.ok(tagsFor('Garlic Lemon Marinade').includes('side'));
  assert.ok(tagsFor('Homemade Tomato Paste').includes('side'));
  assert.ok(tagsFor('Madras Filter Coffee').includes('drink'));
  assert.deepEqual(tagsFor('Chicken Pot Pie'), [], 'a savoury pie is a dinner');
});
