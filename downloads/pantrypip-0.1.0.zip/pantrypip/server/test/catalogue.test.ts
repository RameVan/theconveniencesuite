// The product catalogue from the Open Food Facts export: which products count as an ingredient, searching,
// picking a product, and barcodes the catalogue already knows.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { startApp, type TestApp } from './helpers.ts';
import { importCatalogue } from '../src/import/catalogue.ts';
import { setFetcher } from '../src/domain/barcode.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});

// Valid EAN-13s (check digit), so barcode lookups accept them.
let n = 0;
const ean = (body: string) => body + (10 - (body.split('').reverse().reduce((s, d, i) => s + Number(d) * (i % 2 ? 1 : 3), 0) % 10)) % 10;
const row = (name: string, extra: Record<string, unknown> = {}) => ({
  code: ean(`8710000${String(++n).padStart(5, '0')}`), name, categories: [], labels: [], allergens: [], analysis: [], n: {}, quantity: '1 l', ...extra,
});
const rows = [
  // "Campina" is on three products, so it's a brand and comes off the name.
  row('Halfvolle melk', { brands: 'Campina', categories: ['en:semi-skimmed-milks'], image: 'https://images.openfoodfacts.org/x.jpg', scans: 40 }),
  row('Volle melk', { brands: 'Campina', categories: ['en:whole-milks'] }),
  row('Campina Vla vanille', { brands: 'Campina', quantity: '1 l' }),
  row('AH Kokosmelk', { brands: 'AH', quantity: '400 ml', categories: ['en:coconut-milks'] }),
  // Extra words: tea with lemon is not lemon.
  row('Twinings Groene Thee Citroen', { brands: 'Twinings', quantity: '25 stuks' }),
  // A name that matches, but whose category is mostly something else.
  row('Thee', { brands: 'Pickwick', categories: ['en:teas'] }),
  row('Thee', { brands: 'Lipton', categories: ['en:teas'] }),
  row('Citroen', { brands: 'Pickwick', categories: ['en:teas'] }),
  row('Slimpie Limonadesiroop bosvruchten', { brands: 'Slimpie', quantity: '650 ml', categories: ['en:beverages', 'en:syrups'] }),
  // One product, entered four times: other sizes, other spellings, once twice.
  row('Doritos Sweet Chili', { brands: 'Doritos', quantity: '170g', scans: 38, image: 'https://images.openfoodfacts.org/d.jpg' }),
  row('Sweet Chilli Pepper Flavour', { brands: 'Doritos', quantity: '44 g' }),
  row('Doritos Tortilla chips sweet chilli pepper', { brands: 'Doritos', quantity: '272 g' }),
  row('Doritos Sweet Chili', { brands: 'Doritos', quantity: '170 g' }),
  row('Doritos Nacho Cheese', { brands: 'Doritos', quantity: '170 g' }),
  // Words run together or apart; a brand written longer; but organic isn't regular, and Vega isn't Vegan.
  row('Stroopwafels', { brands: 'Daelmans', quantity: '400 g' }),
  row('Stroop wafels', { brands: 'Daelmans', quantity: '250 g' }),
  row('Melkchocolade', { brands: "Tony's", quantity: '180 g' }),
  row('Melkchocolade', { brands: "Tony's Chocolonely", quantity: '240 g' }),
  row('Romaine sla', { brands: 'AH', quantity: '1 stuks' }),
  row('AH Biologisch Romaine sla', { brands: 'AH Biologisch', quantity: '1 stuks' }),
  row('Falafel', { brands: 'Vega', quantity: '200 g' }),
  row('Falafel', { brands: 'Vegan', quantity: '200 g' }),
  // A copy without brand or shop of a branded product: not shown, still scannable.
  row('Hagelslag puur', { brands: 'Venz', quantity: '380 g' }),
  row('Hagelslag puur', { quantity: '600 g', image: 'https://images.openfoodfacts.org/h.jpg' }),
  // Not usable: no barcode, or only a name.
  row('Kaas', { code: 'abc' }),
  row('Iets', { quantity: undefined }),
];

test('import: name links only, checked against categories; everything usable is searchable', async () => {
  const dir = mkdtempSync(path.join(tmpdir(), 'pp-cat-'));
  const file = path.join(dir, 'nl.ndjson');
  writeFileSync(file, rows.map((r) => JSON.stringify(r)).join('\n') + '\n');
  const r = await importCatalogue(app.db, file);
  assert.equal(r.kept, rows.length - 2);
  const linked = (name: string) => app.db.all<{ product_id: string | null }>('SELECT product_id FROM catalogue WHERE name = ?', name).map((x) => x.product_id);
  assert.deepEqual(linked('Halfvolle melk'), ['p_milk']);
  assert.deepEqual(linked('AH Kokosmelk'), ['p_coconut_milk']);
  assert.deepEqual(linked('Twinings Groene Thee Citroen'), [null], 'tea with lemon is not lemon');
  assert.deepEqual(linked('Citroen'), [null], 'a "lemon" filed under teas is not lemon');
  assert.deepEqual(linked('Slimpie Limonadesiroop bosvruchten'), [null]);
  assert.equal(r.rejected, 1);
  // Linked products are the ingredient's "Where to buy".
  const retail = app.db.all<{ chain_id: string | null }>("SELECT chain_id FROM retail_products WHERE source = 'Open Food Facts' AND product_id = 'p_coconut_milk'");
  assert.deepEqual(retail.map((x) => x.chain_id), ['ah']);
});

test('search: every word, prefixes, own brands shown as the shop', async () => {
  const s = async (q: string) => (await app.api('GET', `/api/catalogue?q=${encodeURIComponent(q)}`)).body;
  const milk = await s('halfv mel');
  assert.equal(milk[0].name, 'Halfvolle melk');
  assert.equal(milk[0].brand, 'Campina');
  assert.equal(milk[0].ingredient.id, 'p_milk');
  const coco = (await s('kokosmelk'))[0];
  assert.equal(coco.name, 'Kokosmelk');
  assert.equal(coco.brand, null);
  assert.deepEqual(coco.chains.map((c: any) => c.name), ['Albert Heijn']);
  assert.equal((await s('slimpie')).length, 1);
  assert.deepEqual(await s('x'), []);
});

test('picking: an ingredient stays that ingredient; anything else becomes your product, once', async () => {
  const ean = (name: string) => app.db.get<{ ean: string }>('SELECT ean FROM catalogue WHERE name = ?', name)!.ean;
  const milk = await app.api('POST', `/api/catalogue/${ean('Halfvolle melk')}/use`, {});
  assert.equal(milk.body.id, 'p_milk');
  const syrup = await app.api('POST', `/api/catalogue/${ean('Slimpie Limonadesiroop bosvruchten')}/use`, {});
  assert.equal(syrup.status, 200);
  assert.equal(syrup.body.name, 'Slimpie Limonadesiroop bosvruchten');
  assert.equal(syrup.body.brand, 'Slimpie');
  assert.equal(syrup.body.barcode, ean('Slimpie Limonadesiroop bosvruchten'));
  assert.equal(syrup.body.unit, 'ml');
  assert.equal(syrup.body.package_size, 650);
  assert.equal(syrup.body.category, 'drinks');
  const again = await app.api('POST', `/api/catalogue/${ean('Slimpie Limonadesiroop bosvruchten')}/use`, {});
  assert.equal(again.body.id, syrup.body.id);
  assert.equal((await app.api('POST', '/api/catalogue/0000000000000/use', {})).status, 404);
});

test('barcode: the catalogue answers without asking Open Food Facts', async () => {
  let asked = 0;
  setFetcher(async () => {
    asked++;
    return new Response('{}', { status: 500 });
  });
  const code = app.db.get<{ ean: string }>("SELECT ean FROM catalogue WHERE name = 'Volle melk'")!.ean;
  const r = await app.api('GET', `/api/barcode/${code}`);
  assert.equal(asked, 0);
  assert.equal(r.body.external.name, 'Volle melk');
  assert.equal(r.body.suggestion.id, 'p_whole_milk');
});

const search = async (q: string) => (await app.api('GET', `/api/catalogue?q=${encodeURIComponent(q)}`)).body;

test('duplicates: one product per brand and name, its sizes together', async () => {
  const chili = await search('doritos sweet chilli');
  assert.equal(chili.length, 1, 'four entries, one product');
  assert.equal(chili[0].name, 'Doritos Sweet Chili');
  assert.deepEqual(chili[0].sizes.map((x: any) => x.qty), [44, 170, 272]);
  assert.equal((await search('doritos')).length, 2, 'sweet chili and nacho cheese');
  assert.deepEqual((await search('stroopwafels')).map((x: any) => x.sizes.map((z: any) => z.qty)), [[250, 400]]);
  assert.equal((await search('melkchocolade')).length, 1, "Tony's is Tony's Chocolonely");
  assert.equal((await search('romaine sla')).length, 2, 'organic stays its own product');
  assert.equal((await search('falafel')).length, 2, 'Vega and Vegan are two brands');
  const sprinkles = await search('hagelslag');
  assert.equal(sprinkles.length, 1);
  assert.equal(sprinkles[0].brand, 'Venz');
  // Every entry is kept for barcodes.
  assert.equal(app.db.get<{ n: number }>("SELECT COUNT(*) n FROM catalogue WHERE name = 'Hagelslag puur'")!.n, 2);
});

test('sizes: a picked product keeps them as pack options; its other barcodes find it', async () => {
  const [chili] = await search('doritos sweet chili');
  const picked = (await app.api('POST', `/api/catalogue/${chili.ean}/use`, {})).body;
  assert.equal(picked.package_size, 170);
  assert.deepEqual(picked.package_options, [44, 170, 272]);
  const big = chili.sizes.find((x: any) => x.qty === 272).ean;
  const scan = (await app.api('GET', `/api/barcode/${big}`)).body;
  assert.equal(scan.source, 'local');
  assert.equal(scan.product.id, picked.id);
  assert.equal((await app.api('POST', `/api/catalogue/${big}/use`, {})).body.id, picked.id, 'picking another size is the same product');
});

test('pack size: 24 eggs on the list', async () => {
  const item = (await app.api('POST', '/api/shopping', { productId: 'p_eggs', packages: 1, packSize: 24 })).body;
  assert.equal(item.pack_size, 24);
  assert.equal(item.quantity, 24);
  assert.match(item.label, /^1 × 24/);
  const again = (await app.api('POST', '/api/shopping', { productId: 'p_eggs', packages: 2, packSize: 6 })).body;
  assert.equal(again.id, item.id, 'same list item');
  assert.equal(again.pack_size, 6);
  assert.equal(again.quantity, 12);
});
