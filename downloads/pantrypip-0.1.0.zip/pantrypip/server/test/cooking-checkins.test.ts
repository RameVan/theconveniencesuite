// "I've cooked X" by voice, the daily "Did you cook X?" question, and per-product receipt quantities.
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, stock, type TestApp } from './helpers.ts';
import { parse } from '../src/assistant/parser.ts';
import { clock, addDays } from '../src/clock.ts';
import { sendCheckins } from '../src/scheduler.ts';
import { setPushSender, saveSubscription } from '../src/push.ts';
import { verifyLedger } from '../src/domain/ledger.ts';

const BASE = Date.now();
let app: TestApp;
before(async () => {
  // Start at a fixed local midday: run just after midnight, "today" in UTC and in local time differ.
  app = await startApp();
  clock.set(at(12));
});
after(async () => {
  clock.set(null);
  await app.close();
});
const S = (pid: string) => stock(app.db, app.householdId, pid);
const add = (productId: string, quantity: number) => app.api('POST', '/api/inventory/add', { productId, quantity });
const plan = (recipeId: string, date = clock.today(), meal = 'dinner', servings = 2) => app.api('POST', '/api/plan', { date, meal, recipeId, servings }).then((r) => r.body);
const slotStatus = (id: string) => app.db.get<{ status: string; date: string }>('SELECT status, date FROM meal_slots WHERE id = ?', id)!;
/** A Date at the given local time today (check-in times are local). */
function at(h: number, m = 0) {
  const d = new Date(BASE);
  d.setHours(h, m, 0, 0);
  return d;
}

describe('voice: cooked and not cooked', () => {
  test('phrasing variants in English and Dutch', () => {
    const cooked: [string, string, string | null][] = [
      ["I've cooked spaghetti bolognese", 'spaghetti bolognese', null], ['cooked the dal', 'dal', null], ['Made the salmon traybake', 'salmon traybake', null],
      ['we had chili for dinner', 'chili', 'dinner'], ['net pannenkoeken gebakken', 'pannenkoeken', null], ['vanavond chili gemaakt voor 3', 'chili', null],
      ['I cooked dinner', '', 'dinner'], ['Dinner is done', '', 'dinner'], ['het eten is klaar', '', 'dinner'], ['I made breakfast', '', 'breakfast'], ['I cooked it', '', null],
    ];
    for (const [text, dish, meal] of cooked) {
      const i = parse(text).intents[0] as any;
      assert.equal(i.type, 'cooked', text);
      assert.equal(i.dish, dish, text);
      assert.equal(i.meal ?? null, meal, text);
    }
    for (const text of ["I didn't cook the curry", 'we skipped the bolognese', 'ik heb de curry niet gekookt', "we didn't make dinner"]) {
      assert.equal(parse(text).intents[0].type, 'not_cooked', `${text} must never deduct`);
    }
    for (const text of ['I ate 2 apples', 'I had a banana']) assert.equal(parse(text).intents[0].type, 'consume', text);
  });

  test('"I\'ve cooked the curry" cooks today\'s planned curry and deducts its ingredients', async () => {
    await add('p_chicken_breast', 500);
    await add('p_coconut_milk', 400);
    await add('p_rice', 1000);
    const slot = await plan('r_chicken_curry', clock.today(), 'dinner', 2);
    const r = await app.say("I've cooked the curry");
    assert.match(r.reply, /Creamy chicken coconut curry for 2/);
    assert.equal(slotStatus(slot.id).status, 'cooked');
    assert.equal(S('p_chicken_breast'), 250);
    assert.equal(S('p_rice'), 850);
  });

  test('"I cooked dinner" uses the planned dinner; Dutch dish names match English recipes', async () => {
    await add('p_pasta', 1000);
    await add('p_minced_beef', 500);
    const slot = await plan('r_spaghetti_bolognese', clock.today(), 'dinner', 2);
    await app.say('I cooked dinner');
    assert.equal(slotStatus(slot.id).status, 'cooked');
    assert.equal(S('p_pasta'), 800);
    await add('p_eggs', 6);
    await app.say('ik heb een omelet gemaakt');
    assert.equal(S('p_eggs'), 3, 'omelet → Cheese & vegetable omelette (3 eggs)');
  });

  test('"I didn\'t cook X" skips the meal without touching stock and offers to move it', async () => {
    await add('p_salmon', 250);
    const slot = await plan('r_salmon_traybake', clock.today(), 'dinner', 2);
    const before = S('p_salmon');
    const r = await app.say("I didn't cook the salmon");
    assert.equal(slotStatus(slot.id).status, 'skipped');
    assert.equal(S('p_salmon'), before);
    assert.ok(r.clarify, 'offers to move it to tomorrow');
    await app.say('yes');
    assert.deepEqual({ ...slotStatus(slot.id) }, { status: 'planned', date: addDays(clock.today(), 1) });
  });

  test('eating leftovers by name asks how many portions', async () => {
    await app.api('POST', '/api/recipes/r_lentil_dal/cook', { servings: 4, leftovers: { fridge: 3 }, clientRequestId: 'cook-dal-1' });
    assert.ok(app.db.get("SELECT 1 FROM inventory_lots WHERE household_id = ? AND is_leftover = 1 AND label = 'Red lentil dal'", app.householdId), 'leftovers created');
    const r = await app.say('we ate the dal');
    assert.ok(r.clarify, 'asks portions');
    await app.say('2');
    const lot = app.db.get<{ quantity: number }>("SELECT quantity FROM inventory_lots WHERE household_id = ? AND is_leftover = 1 AND label LIKE '%dal%' AND status = 'active'", app.householdId);
    assert.equal(lot?.quantity, 1);
  });

  test('a dish without a recipe asks what went into it and deducts those ingredients', async () => {
    await add('p_minced_beef', 500);
    const beef = S('p_minced_beef');
    const r = await app.say("I've cooked meatloaf");
    assert.ok(r.clarify, 'asks for the ingredients');
    await app.say('500 g minced beef and 1 onion');
    assert.equal(S('p_minced_beef'), beef - 500);
    assert.deepEqual(verifyLedger(app.db, app.householdId).mismatches, []);
  });
});

describe('daily cooking check-in', () => {
  test('nothing is asked before the check-in time, yesterday\'s open meals always are', async () => {
    clock.set(at(12));
    const today = await plan('r_shakshuka', clock.today(), 'dinner', 2);
    const yesterday = await plan('r_greek_salad', addDays(clock.today(), -1), 'dinner', 2);
    let r = await app.api('GET', '/api/checkins');
    assert.deepEqual(r.body.pending.map((c: any) => c.slotId), [yesterday.id]);
    clock.set(at(20, 30));
    r = await app.api('GET', '/api/checkins');
    assert.deepEqual(r.body.pending.map((c: any) => c.slotId).sort(), [today.id, yesterday.id].sort());
    // Not cooked yesterday: skip, nothing deducted.
    await app.api('POST', `/api/checkins/${yesterday.id}`, { answer: 'not_cooked' });
    assert.equal(slotStatus(yesterday.id).status, 'skipped');
  });

  test('the assistant asks first, and "yes" by voice cooks it', async () => {
    clock.set(at(20, 30));
    await add('p_eggs', 10);
    const eggs = S('p_eggs');
    const g = await app.api('POST', '/api/assistant/greet', { lang: 'en' });
    assert.match(g.body.greeting.clarify.question, /Did you cook Shakshuka with feta tonight\?/);
    const r = await app.api('POST', '/api/assistant', { text: 'yes', conversationId: g.body.greeting.conversationId });
    assert.match(r.body.reply, /Shakshuka with feta for 2/);
    assert.equal(S('p_eggs'), eggs - 4);
  });

  test('answering from the card or a notification is idempotent', async () => {
    clock.set(at(21));
    await add('p_oats', 500);
    const slot = await plan('r_overnight_oats', clock.today(), 'breakfast', 2);
    const a = await app.api('POST', `/api/checkins/${slot.id}`, { answer: 'cooked', leftovers: { fridge: 1 } });
    const b = await app.api('POST', `/api/checkins/${slot.id}`, { answer: 'cooked' });
    assert.equal(a.status, 200);
    assert.equal(b.body.already, 'cooked');
    assert.equal(S('p_oats'), 400);
    assert.ok(app.db.get("SELECT 1 FROM inventory_lots WHERE household_id = ? AND is_leftover = 1 AND label = 'Overnight oats with berries'", app.householdId));
  });

  test('push: one notification per open meal after the chosen time, with Yes/No buttons', async () => {
    const sent: any[] = [];
    setPushSender(async (_sub, payload) => sent.push(JSON.parse(payload)));
    const user = app.db.get<{ id: string }>('SELECT id FROM users WHERE household_id = ?', app.householdId)!;
    saveSubscription(app.db, app.householdId, user.id, { endpoint: 'https://push.example.test/abc', keys: { p256dh: 'x', auth: 'y' } });
    await app.api('PUT', '/api/checkins/settings', { enabled: true, time: '19:00' });
    clock.set(at(18, 50));
    const slot = await plan('r_tomato_soup', clock.today(), 'dinner', 2);
    await sendCheckins(app.db);
    assert.equal(sent.length, 0, 'not before 19:00');
    clock.set(at(19, 5));
    await sendCheckins(app.db);
    await sendCheckins(app.db);
    const forSlot = sent.filter((p) => p.slotId === slot.id);
    assert.equal(forSlot.length, 1, 'asked once');
    assert.match(forSlot[0].title, /Did you cook Roasted tomato & red pepper soup\?/);
    assert.deepEqual(forSlot[0].actions.map((a: any) => a.action), ['cooked', 'not_cooked']);
    await app.api('PUT', '/api/checkins/settings', { enabled: false, time: '19:00' });
    const slot2 = await plan('r_veg_soup', clock.today(), 'lunch', 2);
    await sendCheckins(app.db);
    assert.equal(sent.filter((p) => p.slotId === slot2.id).length, 0, 'switched off');
    clock.set(null);
  });
});

describe('receipt quantities per product', () => {
  test('lines without a usable size ask in the product\'s own terms; sizes, weights and single-size products don\'t', async () => {
    const r = await app.api('POST', '/api/receipts/scan', {
      text: 'ALBERT HEIJN\nEIEREN 3,29\nAH SCHARRELEIEREN 10ST 3,29\nTOMATEN 1,99\nBANANEN\n0,846 KG x 1,99 1,68\nKIPFILET 6,49\nSOJASAUS 2,29\nTOTAAL 19,04',
    });
    const by = (raw: string) => r.body.proposals.find((p: any) => p.line.raw.startsWith(raw));
    assert.equal(by('EIEREN').product.id, 'p_eggs');
    assert.equal(by('EIEREN').quantityCertain, false, 'carton size unknown → ask how many eggs');
    assert.deepEqual(by('EIEREN').product.package_options, [6, 10, 12, 15, 30]);
    assert.equal(by('AH SCHARRELEIEREN').quantityCertain, true, '"10ST" on the receipt');
    assert.equal(by('TOMATEN').quantityCertain, false);
    assert.equal(by('TOMATEN').product.unit, 'pcs', 'tomatoes are asked as a count');
    assert.equal(by('BANANEN').quantityCertain, true, 'weighed');
    assert.equal(by('KIPFILET').quantityCertain, false);
    assert.equal(by('KIPFILET').product.unit, 'g', 'chicken is asked as a weight');
    assert.equal(by('SOJASAUS').quantityCertain, true, 'one standard size');
    assert.equal(r.body.summary.quantityQuestions, 3);

    // Answer: 12 eggs in the carton, 4 tomatoes. The eggs answer is remembered for this receipt line.
    const eggsBefore = S('p_eggs');
    const tomatoesBefore = S('p_tomatoes');
    const c = await app.api('POST', `/api/receipts/${r.body.id}/commit`, {
      lines: [
        // Eggs were added by hand earlier in this test run; say these are a separate purchase.
        { index: by('EIEREN').index, action: 'add', productId: 'p_eggs', quantity: 12, packages: 1, duplicate: 'add' },
        { index: by('AH SCHARRELEIEREN').index, action: 'add', productId: 'p_eggs', duplicate: 'add' },
        { index: by('TOMATEN').index, action: 'add', productId: 'p_tomatoes', quantity: 4, packages: 1 },
      ],
    });
    assert.equal(c.status, 200, JSON.stringify(c.body));
    assert.equal(S('p_eggs'), eggsBefore + 12 + 10);
    assert.equal(S('p_tomatoes'), tomatoesBefore + 4);

    const again = await app.api('POST', '/api/receipts/scan', { text: 'ALBERT HEIJN\nEIEREN 3,35\nTOTAAL 3,35\n05-11-2026' });
    assert.equal(again.body.proposals[0].quantityCertain, true, 'learned');
    assert.equal(again.body.proposals[0].quantity, 12);
  });
});
