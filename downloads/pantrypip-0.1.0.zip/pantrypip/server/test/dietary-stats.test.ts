// Dietary needs, custom/damaged amounts, and "your year in food" stats.
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, stock, type TestApp } from './helpers.ts';
import { clock, addDays } from '../src/clock.ts';
import { setFetcher } from '../src/domain/barcode.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
});
after(async () => {
  clock.set(null);
  await app.close();
});
const S = (pid: string) => stock(app.db, app.householdId, pid);
const add = (productId: string, quantity: number) => app.api('POST', '/api/inventory/add', { productId, quantity });
const setPeople = (people: any[]) => app.api('PUT', '/api/dietary', { people });

describe('dietary needs', () => {
  test('recipes carry diets and allergens computed from their ingredients', async () => {
    const r = (await app.api('GET', '/api/recipes/r_lentil_dal')).body.recipe;
    assert.ok(r.diet.includes('vegan') && r.diet.includes('gluten-free'));
    const stamppot = (await app.api('GET', '/api/recipes/r_stamppot')).body.recipe;
    assert.ok(!stamppot.diet.includes('vegetarian'), 'smoked sausage is meat');
    assert.ok(stamppot.allergens.required.includes('milk'));
    const shakshuka = (await app.api('GET', '/api/recipes/r_shakshuka')).body.recipe;
    assert.deepEqual(shakshuka.allergens.optional.sort(), ['gluten', 'milk'], 'feta and bread are optional');
  });

  test('a vegetarian with a milk allergy only gets recipes that fit, or that a swap fixes (allergies only, never meat)', async () => {
    const res = await setPeople([
      { id: 'a', name: 'Alex', diets: ['vegetarian'], allergies: [], avoid: [] },
      { id: 'b', name: 'Bo', diets: [], allergies: ['milk'], avoid: [] },
    ]);
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const list = (await app.api('GET', '/api/recipes?limit=500')).body;
    for (const r of list) assert.ok(r.suitable || r.adaptable, `${r.title} should not be suggested`);
    assert.equal(list.find((r: any) => r.id === 'r_stamppot'), undefined, 'smoked sausage has no vegetarian swap');
    // A meat dish with tofu swapped in is still offered as a meat dish, so it isn't offered at all.
    assert.equal(list.find((r: any) => r.id === 'r_chicken_curry'), undefined, 'no chicken curry for a vegetarian');
    for (const r of list.filter((x: any) => x.adaptable)) for (const sw of r.swaps) assert.ok(!/chicken|beef|pork|bacon|sausage|mince|fish|salmon|tuna|prawn|shrimp/i.test(sw.from), `${r.title}: ${sw.from}`);
    const page = (await app.api('GET', '/api/recipes/r_stamppot')).body;
    assert.equal(page.suitability.ok, false);
    const reasons = page.suitability.conflicts.flatMap((c: any) => c.reasons);
    assert.ok(reasons.includes('diet:vegetarian') && reasons.includes('allergy:milk'));
    // "What can I cook?" goes through the same filter.
    const say = await app.say('What can I cook?');
    for (const r of say.data?.items ?? []) assert.notEqual(r.id, 'r_stamppot');
  });

  test('an egg allergy removes recipes built on eggs; substitutes never suggest something unsafe', async () => {
    await setPeople([{ id: 'c', name: 'Cas', diets: [], allergies: ['eggs', 'milk'], avoid: [] }]);
    const list = (await app.api('GET', '/api/recipes?limit=500')).body;
    assert.equal(list.find((r: any) => r.id === 'r_shakshuka'), undefined);
    assert.equal(list.find((r: any) => r.id === 'r_omelette'), undefined);
    await add('p_yoghurt', 500); // yoghurt would normally substitute cream / crème fraîche
    const page = (await app.api('GET', '/api/recipes/r_chicken_curry')).body;
    for (const ing of page.match.ingredients) for (const sub of ing.substitutes) assert.notEqual(sub.productId, 'p_yoghurt');
  });

  test('scanning a product someone is allergic to shows a warning', async () => {
    await setPeople([{ id: 'd', name: 'Dee', diets: [], allergies: ['peanuts'], avoid: [] }]);
    setFetcher(async () => new Response(JSON.stringify({ status: 1, product: { product_name: 'Satésaus', quantity: '250 g', allergens_tags: ['en:peanuts', 'en:soybeans'], ingredients_analysis_tags: ['en:vegan'] } }), { status: 200 }));
    const r = await app.api('GET', '/api/barcode/8710400000020');
    assert.equal(r.status, 200, JSON.stringify(r.body));
    assert.deepEqual(r.body.conflicts, ['allergy:peanuts']);
    const linked = (await app.api('POST', '/api/barcode/8710400000020/link', {})).body;
    assert.deepEqual(linked.allergens.sort(), ['peanuts', 'soy']);
    await setPeople([{ id: 'me', name: 'Me', diets: [], allergies: [], avoid: [] }]);
  });
});

describe('custom amounts and damage', () => {
  test('voice: "an egg broke in transit" removes one egg as damaged waste; "the eggs broke" asks how many', async () => {
    await add('p_eggs', 10);
    const before = S('p_eggs');
    await app.say('An egg broke in transit');
    assert.equal(S('p_eggs'), before - 1);
    assert.ok(app.db.get("SELECT 1 FROM inventory_events WHERE household_id = ? AND product_id = 'p_eggs' AND type = 'discard' AND reason = 'damaged'", app.householdId));
    const r = await app.say('the eggs broke');
    assert.ok(r.clarify, 'asks how many instead of throwing all eggs away');
    assert.equal(S('p_eggs'), before - 1);
    await app.say('2');
    assert.equal(S('p_eggs'), before - 3);
    await app.say('I broke 3 eggs');
    assert.equal(S('p_eggs'), before - 6);
  });

  test('receipt: any line can be corrected, and broken items are logged as waste', async () => {
    const r = await app.api('POST', '/api/receipts/scan', { text: 'ALBERT HEIJN\nAH SCHARRELEIEREN 10ST 3,29\nAH HALFVOLLE MELK 1L 1,19\nTOTAAL 4,48\n07-11-2026' });
    const eggs = r.body.proposals.find((p: any) => p.line.raw.includes('EIEREN'));
    const milk = r.body.proposals.find((p: any) => p.line.raw.includes('MELK'));
    const e0 = S('p_eggs');
    const m0 = S('p_milk');
    const c = await app.api('POST', `/api/receipts/${r.body.id}/commit`, {
      lines: [
        { index: eggs.index, action: 'add', productId: 'p_eggs', quantity: 10, packages: 1, damaged: 1, duplicate: 'add' },
        { index: milk.index, action: 'add', productId: 'p_milk', quantity: 1500, packages: 1, duplicate: 'add' }, // custom amount on a "certain" line
      ],
    });
    assert.equal(c.status, 200, JSON.stringify(c.body));
    assert.equal(S('p_eggs'), e0 + 9);
    assert.equal(S('p_milk'), m0 + 1500);
    const waste = (await app.api('GET', '/api/analytics')).body.wasteReasons;
    assert.ok(waste.find((w: any) => w.reason === 'damaged'));
  });

  test('cooking with a custom amount per ingredient', async () => {
    await add('p_pasta', 1000);
    await add('p_pesto', 190);
    const p0 = S('p_pasta');
    await app.api('POST', '/api/recipes/r_pasta_pesto/cook', { servings: 2, overrides: [{ position: 0, quantity: 275 }], clientRequestId: 'pesto-custom-1' });
    assert.equal(S('p_pasta'), p0 - 275);
  });

  test('throwing away part of a product with a reason', async () => {
    await add('p_yoghurt', 500);
    const y0 = S('p_yoghurt');
    await app.api('POST', '/api/inventory/consume', { productId: 'p_yoghurt', quantity: 150, type: 'discard', reason: 'damaged' });
    assert.equal(S('p_yoghurt'), y0 - 150);
  });
});

describe('your year in food', () => {
  test('counts meals, streaks, favourites and what was eaten (including unlogged use)', async () => {
    const start = new Date('2026-03-02T18:00:00Z');
    for (let i = 0; i < 4; i++) {
      clock.set(new Date(start.getTime() + i * 86_400_000));
      await app.api('POST', '/api/recipes/r_omelette/cook', { servings: 1, clientRequestId: `omelette-${i}` });
    }
    clock.set(new Date(start.getTime() + 10 * 86_400_000));
    await app.api('POST', '/api/recipes/r_greek_salad/cook', { servings: 2, clientRequestId: 'salad-1' });
    // Bought 2 L of juice and later said there's none left: that counts as drunk.
    await app.api('POST', '/api/inventory/add', { productId: 'p_orange_juice', quantity: 2000 });
    clock.set(new Date(start.getTime() + 14 * 86_400_000));
    await app.say("I have 0 orange juice left");
    clock.set(new Date('2026-11-02T12:00:00Z'));
    const s = (await app.api('GET', '/api/stats/fun?period=year')).body;
    assert.ok(s.cooking.meals >= 5, `meals ${s.cooking.meals}`);
    assert.ok(s.cooking.longestStreak >= 4, `streak ${s.cooking.longestStreak}`);
    assert.equal(s.cooking.topRecipes[0].id, 'r_omelette');
    assert.ok(s.eggs > 0, 'omelettes used eggs');
    const all = (await app.api('GET', '/api/stats/fun?period=all')).body;
    assert.ok(all.mostEaten.length > 0);
    const juice = all.mostEaten.find((x: any) => x.productId === 'p_orange_juice');
    assert.equal(juice?.quantity, 2000, 'bought and gone = drunk, even though nobody logged it');
    assert.equal(typeof s.waste.ratePct, 'number');
    assert.ok(s.effort.voiceCommands > 0);
    // Undoing a cooked meal takes it out of the stats again.
    const month = (await app.api('GET', '/api/stats/fun?period=month')).body;
    assert.equal(month.period, 'month');
    const bad = await app.api('GET', '/api/stats/fun?period=decade');
    assert.equal(bad.status, 400);
  });

  test('undo removes a cooked meal from the log', async () => {
    clock.set(new Date('2026-11-02T12:00:00Z'));
    const before = (await app.api('GET', '/api/stats/fun?period=all')).body.cooking.meals;
    const r = await app.api('POST', '/api/recipes/r_yoghurt_bowl/cook', { servings: 1, clientRequestId: 'bowl-undo-1' });
    assert.equal((await app.api('GET', '/api/stats/fun?period=all')).body.cooking.meals, before + 1);
    await app.api('POST', '/api/inventory/undo', { batchId: r.body.batchId });
    assert.equal((await app.api('GET', '/api/stats/fun?period=all')).body.cooking.meals, before);
    void addDays;
    clock.set(null);
  });
});
