// Playing together: cook-along streaks, cheers and nudges, privacy per friend, duels, passed recipes, team goals
// and shared challenges, invite rewards, seasonal events and leagues.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, type TestApp } from './helpers.ts';
import { clock } from '../src/clock.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
  clock.set('2026-11-10T12:00:00Z'); // a Tuesday in Soup Season
});
after(async () => {
  clock.set(null);
  await app.close();
});

type Person = Awaited<ReturnType<typeof person>>;
async function person(name: string) {
  let cookie = '';
  const api = async (method: string, path: string, body?: unknown) => {
    const res = await fetch(app.url + path, { method, headers: { 'content-type': 'application/json', cookie }, body: body === undefined ? undefined : JSON.stringify(body) });
    const set = res.headers.get('set-cookie');
    if (set) cookie = set.split(';')[0];
    const text = await res.text();
    return { status: res.status, body: text ? JSON.parse(text) : null } as { status: number; body: any };
  };
  assert.equal((await api('POST', '/api/auth/register', { email: `${name.toLowerCase()}${Math.random().toString(36).slice(2)}@larder.test`, password: 'test-password-123', name })).status, 201);
  const me = (await api('GET', '/api/me')).body;
  return { api, name, id: me.user.id as string, householdId: me.household.id as string };
}
async function befriend(a: Person, b: Person) {
  await a.api('POST', '/api/friends/request', { code: (await b.api('GET', '/api/friends')).body.code });
  const req = (await b.api('GET', '/api/friends')).body.incoming.find((r: any) => r.name === a.name);
  assert.equal((await b.api('POST', `/api/friends/requests/${req.id}/accept`)).status, 200);
}
const recipeLike = (like: string, n = 1) => app.db.all<{ id: string }>('SELECT id FROM recipes WHERE household_id IS NULL AND lower(title) LIKE ? ORDER BY id LIMIT ?', like, n).map((r) => r.id);
const cook = (p: Person, id: string) => p.api('POST', `/api/recipes/${id}/cook`, { servings: 2, deduct: false });
const view = async (p: Person) => (await p.api('GET', '/api/friends')).body;
const xp = async (p: Person) => (await p.api('GET', '/api/game')).body.xp;

test('cook-along streak, cheers, nudges and privacy per friend', async () => {
  const ann = await person('Ann');
  const ben = await person('Ben');
  await befriend(ann, ben);
  const [r] = recipeLike('%');
  // Both cook two days running.
  clock.set('2026-11-09T18:00:00Z');
  await cook(ann, r);
  await cook(ben, r);
  clock.set('2026-11-10T12:00:00Z');
  await cook(ann, r);
  assert.equal((await view(ann)).social.together[ben.id], 1, 'Ben hasn’t cooked today yet: the shared streak runs to yesterday');

  // Ann nudges Ben (he hasn't cooked today); once a day.
  assert.equal((await ann.api('POST', '/api/social/cheer', { to: ben.id, kind: 'nudge' })).status, 200);
  assert.equal((await ann.api('POST', '/api/social/cheer', { to: ben.id, kind: 'nudge' })).status, 409);
  // Ben can't nudge Ann (she cooked today), but can cheer her.
  assert.equal((await ben.api('POST', '/api/social/cheer', { to: ann.id, kind: 'nudge' })).body.error.code, 'cooked_today');
  assert.equal((await ben.api('POST', '/api/social/cheer', { to: ann.id, kind: 'cheer', ref: 'badge:first', label: 'First dish' })).status, 200);
  const inbox = (await view(ann)).social.inbox.cheers;
  assert.deepEqual(inbox.map((c: any) => [c.from, c.kind, c.ref, c.seen]), [['Ben', 'cheer', 'badge:first', false]]);
  await ann.api('POST', '/api/social/seen');
  assert.equal((await view(ann)).social.inbox.cheers[0].seen, true);

  await cook(ben, r);
  assert.equal((await view(ann)).social.together[ben.id], 2);

  // Ben turns nudges off.
  await ben.api('PUT', '/api/social/nudges', { on: false });
  clock.set('2026-11-11T09:00:00Z');
  assert.equal((await ann.api('POST', '/api/social/cheer', { to: ben.id, kind: 'nudge' })).body.error.code, 'nudges_off');

  // Ben shows Ann his streak only: she no longer sees his XP and he's off her boards.
  await ben.api('POST', `/api/friends/${ann.id}/privacy`, { level: 'streak' });
  const limited = (await view(ann));
  const b = limited.friends.find((f: any) => f.name === 'Ben');
  assert.equal(b.progress.limited, true);
  assert.equal(b.progress.xp, undefined);
  assert.ok(b.progress.streak.current >= 1);
  assert.ok(!limited.leaderboard.all.some((p: any) => p.name === 'Ben'));
  assert.equal((await ann.api('POST', '/api/social/duels', { friendId: ben.id })).body.error.code, 'limited');
  // Ann still shows Ben everything.
  assert.equal((await view(ben)).friends.find((f: any) => f.name === 'Ann').progress.limited, false);
  clock.set('2026-11-10T12:00:00Z');
});

test('a weekly duel is settled after Sunday and the winner gets XP', async () => {
  clock.set('2026-11-10T12:00:00Z');
  const cas = await person('Cas');
  const dee = await person('Dee');
  await befriend(cas, dee);
  const d = await cas.api('POST', '/api/social/duels', { friendId: dee.id });
  assert.equal(d.status, 200);
  assert.equal((await cas.api('POST', '/api/social/duels', { friendId: dee.id })).body.error.code, 'duel_exists');
  assert.equal((await cas.api('POST', `/api/social/duels/${d.body.id}`, { accept: true })).status, 404, 'only the opponent answers');
  assert.equal((await dee.api('POST', `/api/social/duels/${d.body.id}`, { accept: true })).status, 200);
  const [r] = recipeLike('%');
  await cook(dee, r);
  const live = (await view(cas)).social.duels[0];
  assert.equal(live.status, 'active');
  assert.ok(live.them > live.me);

  const before = await xp(dee);
  clock.set('2026-11-17T12:00:00Z'); // next Tuesday
  const done = (await view(dee)).social.duels[0];
  assert.equal(done.status, 'done');
  assert.equal(done.won, true);
  assert.equal(await xp(dee), before + 40);
  assert.ok((await view(dee)).social.rewards.some((x: any) => x.kind === 'duel'));
  clock.set('2026-11-10T12:00:00Z');
});

test('passing a recipe: it lands on the to-try list and cooking it earns XP', async () => {
  const eli = await person('Eli');
  const fen = await person('Fen');
  await befriend(eli, fen);
  const [r] = recipeLike('%');
  await cook(eli, r);
  assert.equal((await eli.api('POST', '/api/social/pass', { to: [fen.id], recipeId: r, note: 'So good' })).status, 200);
  const pass = (await view(fen)).social.inbox.passes[0];
  assert.deepEqual([pass.from, pass.cookedTimes, pass.note], ['Eli', 1, 'So good']);
  const added = await fen.api('POST', `/api/social/pass/${pass.id}`, { add: true });
  assert.equal(added.body.recipeId, r);
  assert.equal(app.db.get<{ t: number }>('SELECT to_try t FROM recipe_interactions WHERE household_id = ? AND recipe_id = ?', fen.householdId, r)!.t, 1);
  assert.equal((await view(fen)).social.inbox.passes.length, 0);

  // A recipe of Eli's own is copied for Fen.
  const own = (await eli.api('POST', '/api/recipes', { title: 'Eli’s secret stew', servings: 2, steps: [{ text: 'Stir.' }], ingredients: [{ name: 'onion', quantity: 1, unit: 'pcs' }] }));
  assert.ok(own.status === 200 || own.status === 201, JSON.stringify(own.body));
  await eli.api('POST', '/api/social/pass', { to: [fen.id], recipeId: own.body.id });
  const p2 = (await view(fen)).social.inbox.passes[0];
  const copy = (await fen.api('POST', `/api/social/pass/${p2.id}`, { add: true })).body.recipeId;
  assert.notEqual(copy, own.body.id);
  assert.equal((await fen.api('GET', `/api/recipes/${copy}`)).body.recipe.title, 'Eli’s secret stew');

  const before = await xp(fen);
  await cook(fen, r);
  const after = (await view(fen)).social.rewards;
  assert.ok(after.some((x: any) => x.kind === 'pass'));
  assert.ok((await xp(fen)) >= before + 20);
});

test('team goals and challenges together', async () => {
  const gil = await person('Gil');
  const hu = await person('Hu');
  await befriend(gil, hu);
  const goal = await gil.api('POST', '/api/social/groups', { kind: 'goal', ref: 'meals', target: 2, friends: [hu.id] });
  assert.equal(goal.status, 200);
  let g = (await view(hu)).social.groups[0];
  assert.equal(g.status, 'invited');
  assert.equal(g.ends, '2026-11-30');
  await hu.api('POST', `/api/social/groups/${goal.body.id}`, { join: true });
  const [r] = recipeLike('%');
  await cook(gil, r);
  await cook(hu, r);
  g = (await view(gil)).social.groups.find((x: any) => x.id === goal.body.id);
  assert.equal(g.total, 2);
  assert.equal(g.done, true);
  assert.ok((await view(hu)).social.rewards.some((x: any) => x.kind === 'goal'));

  // A challenge started together starts for whoever joins, on the same days.
  const ch = await gil.api('POST', '/api/social/groups', { kind: 'challenge', ref: 'homechef', friends: [hu.id] });
  await hu.api('POST', `/api/social/groups/${ch.body.id}`, { join: true });
  const huGame = (await hu.api('GET', '/api/game')).body;
  assert.equal(huGame.challenge.current.id, 'homechef');
  const group = (await view(gil)).social.groups.find((x: any) => x.id === ch.body.id);
  assert.deepEqual(group.members.map((m: any) => m.joined), [true, true]);
});

test('inviting someone new: when they cook, you both get a heart for Pip', async () => {
  const ida = await person('Ida');
  const jay = await person('Jay');
  await befriend(jay, ida); // Jay (new) used Ida's code
  const [r] = recipeLike('%');
  await cook(jay, r);
  await view(ida);
  const stages = (await ida.api('GET', '/api/journey')).body.companion.stages;
  assert.ok(stages.includes('heart'), stages.join(','));
  assert.ok((await jay.api('GET', '/api/journey')).body.companion.stages.includes('heart'));
});

test('Soup Season: three soups unlock the event look', async () => {
  const kai = await person('Kai');
  const soups = recipeLike('%soup%', 3);
  assert.equal(soups.length, 3);
  for (const s of soups) await cook(kai, s);
  const v = await view(kai);
  assert.equal(v.social.event.id, 'soup');
  assert.equal(v.social.event.board[0].count, 3);
  assert.equal(v.social.event.done, true);
  const skins = (await kai.api('GET', '/api/journey')).body.companion.skins;
  assert.equal(skins.find((s: any) => s.id === 'beet').unlocked, true);
  assert.equal((await kai.api('PUT', '/api/journey/companion', { skin: 'beet' })).status, 200);
});

test('leagues move up after a strong week; the recap and rescued counter add up', async () => {
  clock.set('2026-11-10T12:00:00Z');
  const lia = await person('Lia');
  const mo = await person('Mo');
  await befriend(lia, mo);
  assert.equal((await view(lia)).social.league.league, 0);
  // A strong week: plenty of cooking.
  for (const r of recipeLike('%', 8)) await cook(lia, r);
  const v = await view(lia);
  assert.equal(v.social.recap.meals, 8);
  assert.deepEqual(v.social.recap.names, ['Lia', 'Mo']);
  assert.equal(typeof v.social.rescued.kg, 'number');
  assert.ok(v.me.weekXp >= 150, `week XP ${v.me.weekXp}`);
  clock.set('2026-11-17T12:00:00Z');
  const next = (await view(lia)).social.league;
  assert.deepEqual([next.league, next.moved], [1, 1]);
  assert.ok((await view(mo)).leaderboard.all.find((p: any) => p.name === 'Lia').league === 1);
  clock.set('2026-11-10T12:00:00Z');
});
