// Friends and the leaderboard: found by code, shared only after both accept, progress numbers only.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, type TestApp } from './helpers.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});

/** Another person on the same server, with their own cookie (and household, unless an invite code is given). */
async function person(name: string, inviteCode?: string) {
  let cookie = '';
  const api = async (method: string, path: string, body?: unknown) => {
    const res = await fetch(app.url + path, { method, headers: { 'content-type': 'application/json', cookie }, body: body === undefined ? undefined : JSON.stringify(body) });
    const set = res.headers.get('set-cookie');
    if (set) cookie = set.split(';')[0];
    const text = await res.text();
    return { status: res.status, body: text ? JSON.parse(text) : null } as { status: number; body: any };
  };
  const reg = await api('POST', '/api/auth/register', { email: `${name.toLowerCase()}${Date.now()}@larder.test`, password: 'test-password-123', name, inviteCode });
  assert.equal(reg.status, 201);
  const me = (await api('GET', '/api/me')).body;
  return { api, id: me.user.id as string, householdId: me.household.id as string };
}

test('a request by code is private until accepted, then both see progress numbers only', async () => {
  const ana = await person('Ana');
  const bo = await person('Bo');

  const anaView = (await ana.api('GET', '/api/friends')).body;
  assert.match(anaView.code, /^[A-Z2-9]{8}$/);
  assert.equal(anaView.friends.length, 0);
  assert.deepEqual(anaView.leaderboard.week.map((p: any) => p.name), ['Ana']);

  // Bo cooks something so there is progress to share.
  const recipe = app.db.get<{ id: string }>('SELECT id FROM recipes WHERE household_id IS NULL ORDER BY id LIMIT 1')!.id;
  assert.equal((await bo.api('POST', `/api/recipes/${recipe}/cook`, { servings: 2 })).status, 200);

  // Bo adds Ana by her link (pasted whole, lower case, with a dash): pending, nothing shared yet.
  const link = `https://app.example/#/progress?friend=${anaView.code.slice(0, 4).toLowerCase()}-${anaView.code.slice(4)}`;
  const sent = await bo.api('POST', '/api/friends/request', { code: link });
  assert.equal(sent.status, 200);
  assert.deepEqual(sent.body, { state: 'pending', name: 'Ana' });
  const boPending = (await bo.api('GET', '/api/friends')).body;
  assert.equal(boPending.outgoing.length, 1);
  assert.equal(boPending.friends.length, 0);
  assert.equal(boPending.leaderboard.all.length, 1, 'no one on the board before accepting');
  const anaPending = (await ana.api('GET', '/api/friends')).body;
  assert.equal(anaPending.incoming.length, 1);
  assert.equal(anaPending.incoming[0].name, 'Bo');
  assert.equal(anaPending.incoming[0].progress, undefined, 'a request shows a name, not progress');
  assert.equal(anaPending.friends.length, 0);

  // Bo can't accept their own request; Ana can.
  assert.equal((await bo.api('POST', `/api/friends/requests/${anaPending.incoming[0].id}/accept`)).status, 404);
  assert.equal((await ana.api('POST', `/api/friends/requests/${anaPending.incoming[0].id}/accept`)).status, 200);

  const anaNow = (await ana.api('GET', '/api/friends')).body;
  assert.equal(anaNow.friends.length, 1);
  const boSeen = anaNow.friends[0];
  assert.equal(boSeen.name, 'Bo');
  assert.ok(boSeen.progress.xp > 0);
  // All of it was earned this week, except the undated first-dish badge.
  assert.equal(boSeen.progress.weekXp, boSeen.progress.xp - 50 * boSeen.progress.badges.done);
  assert.equal(boSeen.progress.streak.current, 1);
  assert.ok(boSeen.progress.level.name);
  assert.ok(boSeen.progress.chapter.title);
  // Only progress: no email, no household id, no recipes, meals, stock or lists.
  const json = JSON.stringify(anaNow);
  assert.ok(!json.includes('@larder.test'), 'no email addresses');
  assert.ok(!json.includes(bo.householdId), 'no household ids');
  assert.ok(!json.includes(recipe), 'no recipes or meals');
  assert.deepEqual(Object.keys(boSeen.progress).sort(), ['badges', 'challenge', 'chapter', 'chapterDoneAt', 'event', 'level', 'limited', 'monthCooks', 'recent', 'rescued', 'skin', 'stages', 'streak', 'weekCooks', 'weekXp', 'xp'].sort());
  assert.ok(!('days' in boSeen.progress) && !('weeklyXp' in boSeen.progress), 'server-only fields stay on the server');

  // Leaderboards: Bo first in both, ranked by XP.
  for (const period of ['week', 'all'] as const) {
    const board = anaNow.leaderboard[period];
    assert.deepEqual(board.map((p: any) => p.name), ['Bo', 'Ana']);
    assert.deepEqual(board.map((p: any) => p.rank), [1, 2]);
    assert.equal(board[1].me, true);
  }
  assert.equal(anaNow.leaderboard.all[0].score, boSeen.progress.xp);

  // Removing ends the sharing on both sides.
  assert.equal((await bo.api('DELETE', `/api/friends/${ana.id}`)).status, 200);
  assert.equal((await ana.api('GET', '/api/friends')).body.friends.length, 0);
  assert.equal((await bo.api('GET', '/api/friends')).body.friends.length, 0);
});

test('declining, withdrawing, crossing requests and bad codes', async () => {
  const cy = await person('Cy');
  const di = await person('Di');
  const cyCode = (await cy.api('GET', '/api/friends')).body.code;
  const diCode = (await di.api('GET', '/api/friends')).body.code;

  // Decline: the request disappears for both.
  await di.api('POST', '/api/friends/request', { code: cyCode });
  const req = (await cy.api('GET', '/api/friends')).body.incoming[0];
  assert.equal((await cy.api('DELETE', `/api/friends/requests/${req.id}`)).status, 200);
  assert.equal((await di.api('GET', '/api/friends')).body.outgoing.length, 0);

  // Withdraw your own request.
  await di.api('POST', '/api/friends/request', { code: cyCode });
  const out = (await di.api('GET', '/api/friends')).body.outgoing[0];
  assert.equal((await di.api('DELETE', `/api/friends/requests/${out.id}`)).status, 200);
  assert.equal((await cy.api('GET', '/api/friends')).body.incoming.length, 0);

  // Asking twice doesn't duplicate; adding the code of someone who asked you accepts.
  await di.api('POST', '/api/friends/request', { code: cyCode });
  await di.api('POST', '/api/friends/request', { code: cyCode });
  assert.equal((await cy.api('GET', '/api/friends')).body.incoming.length, 1);
  const crossed = await cy.api('POST', '/api/friends/request', { code: diCode });
  assert.deepEqual(crossed.body, { state: 'friends', name: 'Di' });
  assert.equal((await cy.api('GET', '/api/friends')).body.friends.length, 1);

  // A new code stops the old one working, friends stay.
  const fresh = (await cy.api('POST', '/api/friends/code')).body.code;
  assert.notEqual(fresh, cyCode);
  const eve = await person('Eve');
  assert.equal((await eve.api('POST', '/api/friends/request', { code: cyCode })).body.error.code, 'invalid_code');
  assert.equal((await cy.api('GET', '/api/friends')).body.friends.length, 1);

  // Your own code, and someone in your own household, can't be added.
  assert.equal((await cy.api('POST', '/api/friends/request', { code: fresh })).body.error.code, 'own_code');
  const inviteCode = app.db.get<{ invite_code: string }>('SELECT invite_code FROM households WHERE id = ?', cy.householdId)!.invite_code;
  const housemate = await person('Fay', inviteCode);
  assert.equal((await housemate.api('POST', '/api/friends/request', { code: fresh })).body.error.code, 'same_household');

  // Guessing codes is rate limited.
  let last = 0;
  for (let i = 0; i < 10; i++) last = (await eve.api('POST', '/api/friends/request', { code: `ZZZZZZ${i}${i}` })).status;
  assert.equal(last, 429);
});

test('ties share a rank and the weekly board only counts this week', async () => {
  const gus = await person('Gus');
  const hal = await person('Hal');
  await hal.api('POST', '/api/friends/request', { code: (await gus.api('GET', '/api/friends')).body.code });
  await gus.api('POST', `/api/friends/requests/${(await gus.api('GET', '/api/friends')).body.incoming[0].id}/accept`);
  const board = (await gus.api('GET', '/api/friends')).body.leaderboard.week;
  assert.deepEqual(board.map((p: any) => p.rank), [1, 1]);
  assert.deepEqual(board.map((p: any) => p.score), [0, 0]);

  // An old cook counts all-time but not this week.
  const recipe = app.db.get<{ id: string }>('SELECT id FROM recipes WHERE household_id IS NULL ORDER BY id LIMIT 1')!.id;
  await hal.api('POST', `/api/recipes/${recipe}/cook`, { servings: 2 });
  app.db.run("UPDATE cook_log SET created_at = '2020-01-06T18:00:00.000Z' WHERE household_id = ?", hal.householdId);
  app.db.run("UPDATE journey_nodes SET completed_at = '2020-01-06T18:00:00.000Z' WHERE household_id = ?", hal.householdId);
  const after = (await gus.api('GET', '/api/friends')).body;
  const halAll = after.leaderboard.all.find((p: any) => p.name === 'Hal');
  const halWeek = after.leaderboard.week.find((p: any) => p.name === 'Hal');
  assert.ok(halAll.score > 0);
  assert.equal(halWeek.score, 0);
  assert.equal(after.leaderboard.all[0].name, 'Hal');
});

test('progress snapshots follow what friends do, and there is no limit on friends', async () => {
  const ivy = await person('Ivy');
  const ivyCode = (await ivy.api('GET', '/api/friends')).body.code;
  const recipe = app.db.get<{ id: string }>('SELECT id FROM recipes WHERE household_id IS NULL ORDER BY id LIMIT 1')!.id;

  const jo = await person('Jo');
  await jo.api('POST', '/api/friends/request', { code: ivyCode });
  await ivy.api('POST', `/api/friends/requests/${(await ivy.api('GET', '/api/friends')).body.incoming[0].id}/accept`);
  const before = (await ivy.api('GET', '/api/friends')).body.friends[0].progress.xp;
  assert.equal(app.db.get<{ n: number }>('SELECT COUNT(*) n FROM progress_snapshots WHERE household_id = ?', jo.householdId)!.n, 1, 'kept as a snapshot');
  // Jo cooks: the next look at the friends screen shows it.
  await jo.api('POST', `/api/recipes/${recipe}/cook`, { servings: 2 });
  const after = (await ivy.api('GET', '/api/friends')).body.friends[0];
  assert.ok(after.progress.xp > before, `${after.progress.xp} > ${before}`);
  assert.equal(after.progress.streak.current, 1);

  // 60 friends (more than the old limit of 50).
  for (let i = 0; i < 59; i++) {
    const p = await person(`P${i}`);
    assert.equal((await p.api('POST', '/api/friends/request', { code: ivyCode })).status, 200);
  }
  const reqs = (await ivy.api('GET', '/api/friends')).body.incoming;
  assert.equal(reqs.length, 59);
  for (const r of reqs) assert.equal((await ivy.api('POST', `/api/friends/requests/${r.id}/accept`)).status, 200);
  const t0 = Date.now();
  const all = (await ivy.api('GET', '/api/friends')).body;
  assert.equal(all.friends.length, 60);
  assert.ok(Date.now() - t0 < 2000, 'cached snapshots keep it quick');
  assert.equal((await ivy.api('GET', '/api/friends/requests/count')).body.incoming, 0);
});

test('people who share their number can be found from contacts; others cannot', async () => {
  const kim = await person('Kim');
  const lou = await person('Lou');
  const max = await person('Max');
  // Kim is findable, Max gave a number but isn't.
  const set = await kim.api('PUT', '/api/friends/phone', { phone: '06-1234 5678', discoverable: true });
  assert.equal(set.status, 200);
  assert.equal(set.body.phone.hint, '+31 •••• 78');
  await max.api('PUT', '/api/friends/phone', { phone: '+31 6 87654321', discoverable: false });
  assert.equal((await kim.api('PUT', '/api/friends/phone', { phone: 'not a number', discoverable: true })).status, 400);
  // Only the hash is stored.
  const stored = JSON.stringify(app.db.all('SELECT * FROM user_phones'));
  assert.ok(!stored.includes('612345678') && !stored.includes('87654321'), 'no plain numbers stored');

  const found = await lou.api('POST', '/api/friends/contacts', { numbers: ['+44 20 7946 0000', '0031 6 12345678', '+31687654321', 'hello'] });
  assert.equal(found.status, 200);
  assert.equal(found.body.matches.length, 1);
  const m = found.body.matches[0];
  assert.deepEqual([m.index, m.name, m.state], [1, 'Kim', 'none']);

  // Ask Kim; a made-up match is refused.
  assert.equal((await lou.api('POST', '/api/friends/request', { userId: m.userId, match: 'x'.repeat(43) })).status, 404);
  assert.deepEqual((await lou.api('POST', '/api/friends/request', { userId: m.userId, match: m.match })).body, { state: 'pending', name: 'Kim' });
  assert.equal((await kim.api('GET', '/api/friends/requests/count')).body.incoming, 1);
  assert.equal((await lou.api('POST', '/api/friends/contacts', { numbers: ['+31612345678'] })).body.matches[0].state, 'pending');

  // Hiding yourself stops new matches.
  await kim.api('PUT', '/api/friends/phone', { discoverable: false });
  assert.equal((await lou.api('POST', '/api/friends/contacts', { numbers: ['+31612345678'] })).body.matches.length, 0);
  assert.equal((await kim.api('GET', '/api/friends')).body.phone.discoverable, false);
  await kim.api('DELETE', '/api/friends/phone');
  assert.equal((await kim.api('GET', '/api/friends')).body.phone, null);
});
