import type { AddressInfo } from 'node:net';
import { createApp } from '../src/index.ts';
import { clock } from '../src/clock.ts';

export interface TestApp {
  db: ReturnType<typeof createApp>['db'];
  api: <T = any>(method: string, path: string, body?: unknown) => Promise<{ status: number; body: T }>;
  say: (text: string, extra?: Record<string, unknown>) => Promise<any>;
  householdId: string;
  close: () => Promise<void>;
  url: string;
}

/** Start a fresh in-memory app on a random port with one registered user. */
export async function startApp(): Promise<TestApp> {
  clock.set(null);
  const { db, server } = createApp(':memory:', { seedDemo: false, emailConfirm: false });
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', () => r()));
  const port = (server.address() as AddressInfo).port;
  let cookie = '';
  const api = async (method: string, path: string, body?: unknown) => {
    const res = await fetch(`http://127.0.0.1:${port}${path}`, {
      method,
      headers: { 'content-type': 'application/json', cookie },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const set = res.headers.get('set-cookie');
    if (set) cookie = set.split(';')[0];
    const text = await res.text();
    return { status: res.status, body: text ? JSON.parse(text) : null };
  };
  const reg = await api('POST', '/api/auth/register', { email: `t${Date.now()}${Math.random().toString(36).slice(2, 6)}@larder.test`, password: 'test-password-123', name: 'Tester' });
  if (reg.status !== 201) throw new Error('register failed ' + JSON.stringify(reg.body));
  const me = await api('GET', '/api/me');
  let conversationId: string | null = null;
  const say = async (text: string, extra: Record<string, unknown> = {}) => {
    const r = await api('POST', '/api/assistant', { text, conversationId, ...extra });
    if (r.status !== 200) throw new Error(`assistant ${r.status}: ${JSON.stringify(r.body)}`);
    conversationId = r.body.conversationId;
    return r.body;
  };
  return {
    db,
    api,
    say,
    householdId: me.body.household.id,
    close: () => new Promise<void>((r) => server.close(() => (db.close(), r()))),
    url: `http://127.0.0.1:${port}`,
  };
}

export function stock(db: TestApp['db'], householdId: string, productId: string): number {
  return db.get<{ q: number }>("SELECT COALESCE(SUM(quantity),0) q FROM inventory_lots WHERE household_id = ? AND product_id = ? AND status = 'active'", householdId, productId)!.q;
}

export const AH_RECEIPT = `ALBERT HEIJN
Filiaal 1427 Utrecht
AANTAL OMSCHRIJVING        PRIJS  BEDRAG
      AH HALFVOLLE MELK 1L           1,19
2     KIPFILET            6,49      12,98
      BANANEN
      0,846 KG x 1,99                1,68
      AH SCHARRELEIEREN 10ST         3,29
      VOLKOREN BROOD                 2,19
      KNFLK BOL                      0,99
      BONUS KIPFILET                -2,00
      STATIEGELD                     0,25
SUBTOTAAL                           20,57
TOTAAL                              20,57
PINNEN                              20,57
27-10-2026 18:32  KASSA 4`;

export const JUMBO_RECEIPT = `Jumbo Supermarkten
Jumbo Halfvolle melk 1L        1,15 B
Jumbo Scharreleieren 10 st     3,19 B
2 x 0,79
Tomatenblokjes                 1,58 B
Spaghetti 500g                 1,09 B
Totaal                         7,01
Betaald met PIN
28-10-2026 12:01`;

export const LIDL_RECEIPT = `LIDL
Melk halfvol                1,09 A
Bananen                     1,49 A
  0,712 kg x 2,09 EUR/kg
Kipfilet 2 x 5,49          10,98 A
Te betalen                 13,56
29.10.2026`;

/**
 * A household that has already told PantryPip its usual types ("milk" = semi-skimmed …), so "I bought milk"
 * doesn't ask. New households get one question per family the first time instead.
 */
export function setUsualTypes(app: TestApp) {
  const usual: Record<string, string> = { milk: 'p_milk', chicken: 'p_chicken_breast', cheese: 'p_cheese', cream: 'p_cream', yoghurt: 'p_yoghurt', rice: 'p_rice', mince: 'p_minced_beef', noodles: 'p_noodles' };
  for (const [family, product] of Object.entries(usual)) {
    app.db.run("INSERT OR REPLACE INTO substitution_prefs (household_id, from_key, choice, updated_at) VALUES (?, ?, ?, datetime('now'))", app.householdId, `f:${family}`, product);
  }
}
