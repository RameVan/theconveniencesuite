// The ingredient ecosystem: canonical identity, variant questions, measurements, packaging-aware shopping,
// substitutions and recipe compatibility.
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, stock, type TestApp } from './helpers.ts';
import { identifyIngredient } from '../src/domain/ingredient-match.ts';
import { parseIngredientLine } from '../src/domain/recipe-import.ts';
import { resolveProduct } from '../src/domain/products.ts';
import { choosePacks } from '../src/domain/shopping.ts';
import { listRecipes, createRecipe } from '../src/domain/recipes.ts';
import { clock, addDays } from '../src/clock.ts';
import { dishKind, normaliseLine } from '../src/import/bulk-recipes.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});
const id = (phrase: string) => {
  const m = identifyIngredient(app.db, '', phrase);
  return m.kind === 'product' ? m.product!.id : m.kind === 'family' ? `family:${m.family!.id}` : m.kind === 'foreign' ? m.foreignKey : 'none';
};
const line = (s: string) => parseIngredientLine(app.db, '', s);
const S = (pid: string) => stock(app.db, app.householdId, pid);

describe('ingredient recognition', () => {
  test('milk versus oat milk, whole versus skimmed', () => {
    assert.equal(id('milk'), 'family:milk');
    assert.equal(id('oat milk'), 'p_oat_milk');
    assert.equal(id('whole milk'), 'p_whole_milk');
    assert.equal(id('skimmed milk'), 'p_skimmed_milk');
    assert.equal(id('semi-skimmed milk'), 'p_milk');
    assert.equal(id('halfvolle melk'), 'p_milk');
  });
  test('young versus mature cheese; "old cheese" is oude kaas; cheddar is not Gouda', () => {
    assert.equal(id('cheese'), 'family:cheese');
    assert.equal(id('young gouda'), 'p_cheese');
    assert.equal(id('mature gouda'), 'p_gouda_mature');
    assert.equal(id('old cheese'), 'p_gouda_old');
    assert.equal(id('oude kaas'), 'p_gouda_old');
    assert.equal(id('cheddar cheese'), 'p_cheddar');
    assert.notEqual(id('sharp cheddar'), 'p_cheese');
  });
  test('chicken versus chicken broth; sour cream is not cooking cream', () => {
    assert.equal(id('chicken breast'), 'p_chicken_breast');
    assert.equal(id('chicken broth'), 'p_broth');
    assert.equal(id('low-sodium chicken broth'), 'p_broth');
    assert.equal(id('sour cream'), 'p_sour_cream');
    assert.equal(id('cream'), 'family:cream');
    assert.equal(id('heavy cream'), 'p_whipping_cream');
  });
  test('paprika versus cayenne versus chilli powder; peppers stay distinct', () => {
    assert.equal(line('1 tsp cayenne pepper').productId, 'p_cayenne');
    assert.equal(line('1 tsp smoked paprika').productId, 'p_paprika_powder');
    assert.equal(line('2 tsp chili powder').productId, 'p_chili_powder');
    assert.equal(id('red bell pepper'), 'p_bell_pepper');
    assert.equal(id('habanero'), 'x:habanero');
    assert.equal(id('madame jeanette'), 'p_madame_jeanette');
  });
  test('an unknown word that changes identity is never ignored', () => {
    assert.equal(id('smoked salmon'), 'none', '"smoked" changes what salmon is');
    assert.equal(id('fresh spinach'), 'p_spinach', '"fresh" does not');
    assert.equal(resolveProduct(app.db, '', 'chicken stock cubes').product?.id, 'p_stock_cube');
    assert.equal(resolveProduct(app.db, '', 'butter chicken masala').product, null, 'not butter, not chicken');
  });
  test('bare "pepper": spooned is black pepper, counted is a bell pepper', () => {
    assert.equal(line('1/2 teaspoon ground pepper').productId, 'p_pepper');
    assert.equal(line('Pepper, to taste').productId, 'p_pepper');
    assert.equal(line('1 pepper').productId, 'p_bell_pepper');
  });
  test('two ribs of celery are a fifth of a head, not two heads', () => {
    assert.equal(line('2 ribs celery').quantity, 0.2);
    assert.equal(line('1 celery').quantity, 1);
  });
  test('"X or Y": the first choice, keeping a shared noun', () => {
    assert.equal(line('4 cups beef or chicken broth').productId, 'p_broth', 'beef broth, not beef');
    assert.equal(line('2 tbsp Worcestershire sauce or teriyaki sauce').productId, 'p_worcestershire');
    assert.equal(line('Fresh cilantro or parsley, chopped').productId, 'p_coriander');
  });
  test('"5 ea. (15 ounces)" is the total; "2 (15 oz) cans" is per can', () => {
    assert.equal(Math.round(line(normaliseLine('5 ea. (15 ounces) cod fillets')).quantity!), 425);
    assert.equal(Math.round(line(normaliseLine('2 (15 oz) cans chickpeas')).quantity!), 851);
  });
});

describe('measurements', () => {
  test('small measures never become a pack', () => {
    const salt = line('a pinch of salt');
    assert.equal(salt.productId, 'p_salt');
    assert.ok(salt.quantity! < 1);
    const milk = line('a dash of milk');
    assert.equal(milk.match, 'equivalent', 'only "milk": the everyday type');
    assert.ok(milk.quantity! < 2);
    const thyme = line('3 sprigs of thyme');
    assert.equal(thyme.productId, 'p_fresh_thyme', 'a sprig is fresh thyme');
    assert.equal(thyme.quantity, 3);
  });
  test('pieces, litres, grams and packs', async () => {
    assert.deepEqual([line('4 eggs').productId, line('4 eggs').quantity], ['p_eggs', 4]);
    assert.equal(line('half a litre of whole milk').quantity, 500);
    assert.deepEqual([line('250 grams of flour').productId, line('250 grams of flour').quantity], ['p_flour', 250]);
    const r = await app.say('I bought a pack of six chicken breasts');
    assert.ok(S('p_chicken_breast') >= 900, `6 × 150 g fillets (${S('p_chicken_breast')} g): ${r.reply}`);
  });
  test('every product has a measurement definition with sensible limits', () => {
    const rows = app.db.all<{ id: string; unit: string; measure: string }>('SELECT id, unit, measure FROM products WHERE household_id IS NULL');
    for (const r of rows) {
      const m = JSON.parse(r.measure);
      assert.ok(m.recipeUnit && m.maxPerServing > 0 && m.precision > 0, `${r.id} has a measure`);
      if (r.unit === 'pcs') assert.equal(m.recipeUnit, 'pcs', `${r.id} counts in pieces`);
    }
    const salt = JSON.parse(rows.find((r) => r.id === 'p_salt')!.measure);
    assert.ok(salt.maxPerServing <= 5);
  });
  test('volume and weight convert by density, not 1:1', () => {
    const flour = line('1 cup flour');
    assert.ok(flour.quantity! > 120 && flour.quantity! < 140, `a cup of flour ≈ 130 g (${flour.quantity})`);
    const honey = line('2 tbsp honey');
    assert.ok(honey.quantity! > 35, `honey is heavier than water (${honey.quantity})`);
  });
});

describe('stock tracking', () => {
  test('"I added milk" asks which kind once, then remembers', async () => {
    const r = await app.say('I added milk');
    assert.ok(r.clarify, 'asks');
    assert.ok(r.clarify.options.some((o: any) => o.value === 'p_whole_milk'));
    assert.ok(r.clarify.options.some((o: any) => o.value === 'other'));
    await app.say('p_whole_milk');
    assert.ok(S('p_whole_milk') > 0);
    const again = await app.say('I bought 2 litres of milk');
    assert.ok(!again.clarify, 'remembered');
    assert.equal(S('p_whole_milk'), 3000);
  });
  test('specified types need no question; plant milk asks for the kind', async () => {
    assert.ok(!(await app.say('I bought 2 litres of semi-skimmed milk')).clarify);
    assert.ok(!(await app.say('I added oat milk')).clarify);
    assert.ok(S('p_oat_milk') > 0);
    const c = await app.say('I added cheese');
    assert.ok(c.clarify.options.some((o: any) => o.value === 'p_cheddar'));
    const sub = await app.say('Cheddar');
    assert.ok(!sub.clarify);
    assert.ok(S('p_cheddar') > 0);
    assert.ok(!(await app.say('I bought 500g of old cheese')).clarify);
    assert.equal(S('p_gouda_old'), 500);
  });
  test('a custom type is the household’s own, reusable, and leaves the catalogue alone', async () => {
    await app.api('PUT', '/api/ingredients/choice', { key: 'f:yoghurt', choice: null });
    const r = await app.say('I bought yoghurt');
    assert.ok(r.clarify);
    await app.say('other');
    await app.say('Coconut yoghurt');
    const p = app.db.get<{ id: string; household_id: string; family: string; custom: number }>("SELECT * FROM products WHERE name = 'Coconut yoghurt'")!;
    assert.equal(p.household_id, app.householdId);
    assert.equal(p.family, 'yoghurt');
    assert.equal(p.custom, 1);
    assert.ok(S(p.id) > 0);
    assert.ok(!(await app.say('I bought yoghurt')).clarify, 'remembered as the usual yoghurt');
    assert.equal(app.db.get<{ n: number }>("SELECT COUNT(*) n FROM products WHERE household_id IS NULL AND name = 'Coconut yoghurt'")!.n, 0);
  });
  test('partial use, and "ran out of"', async () => {
    await app.api('POST', '/api/inventory/add', { productId: 'p_olive_oil', quantity: 500 });
    await app.say('I used half a bottle of olive oil');
    assert.equal(S('p_olive_oil'), 250);
    await app.api('POST', '/api/inventory/add', { productId: 'p_butter', quantity: 250 });
    await app.say('I ran out of butter');
    assert.equal(S('p_butter'), 0);
  });
  test('a wrongly matched stock item can be corrected, history and all', async () => {
    const lot = (await app.api('POST', '/api/inventory/add', { productId: 'p_milk', quantity: 1000 })).body;
    const lotId = lot.result.lot.id;
    const before = S('p_soy_drink');
    const r = await app.api('POST', `/api/inventory/lots/${lotId}/product`, { productId: 'p_soy_drink' });
    assert.equal(r.status, 200, JSON.stringify(r.body));
    assert.equal(S('p_soy_drink'), before + 1000);
    assert.equal((await app.api('POST', `/api/inventory/lots/${lotId}/product`, { productId: 'p_cheddar' })).status, 422, 'ml to g is refused');
  });
});

describe('shopping lists', () => {
  test('pack sizes: 4 eggs → one 6-pack; nothing wasted needlessly', () => {
    const eggs = { package_size: 10, package_options: [6, 10, 12, 15, 30] };
    assert.deepEqual(choosePacks(4, eggs), { size: 6, count: 1, leftover: 2 });
    assert.deepEqual(choosePacks(2, eggs), { size: 6, count: 1, leftover: 4 });
    assert.deepEqual(choosePacks(12, eggs), { size: 12, count: 1, leftover: 0 });
    assert.equal(choosePacks(1200, { package_size: 1000, package_options: [500, 1000, 1500, 2000] }).size, 1500);
  });
  test('plan-driven items combine recipes, subtract stock and show the leftover', async () => {
    const day = addDays(clock.today(), 1);
    // Two recipes with eggs: frittata-style needs, from the library.
    const omelette = listRecipes(app.db, app.householdId).find((r) => r.id === 'r_omelette')!;
    const eggsPer = omelette.ingredients.find((i) => i.product_id === 'p_eggs')!.quantity! / omelette.servings;
    await app.api('POST', '/api/plan', { date: day, meal: 'dinner', recipeId: 'r_omelette', servings: 2 });
    await app.api('POST', '/api/plan', { date: addDays(day, 1), meal: 'dinner', recipeId: 'r_omelette', servings: 2 });
    const have = S('p_eggs');
    const list = (await app.api('GET', '/api/shopping')).body;
    const item = list.groups.flatMap((g: any) => g.items).find((i: any) => i.product_id === 'p_eggs');
    const need = eggsPer * 4;
    if (need - have > 0) {
      assert.ok(item, 'eggs on the list');
      assert.equal(item.plan.need, need);
      assert.equal(item.plan.have, have);
      assert.equal(item.plan.leftover, item.plan.packs * item.plan.packSize - item.plan.toBuy);
      assert.ok([6, 10, 12, 15, 30].includes(item.plan.packSize));
    } else assert.equal(item, undefined, 'enough in stock');
  });
});

describe('substitutions', () => {
  const recipeWith = (lines: string[]) => {
    const ings = lines.map((l) => {
      const d = line(l);
      return { product_id: d.productId, name: d.productName ?? d.name, quantity: d.quantity, unit: d.unit, display: l, match: d.match, source_key: d.sourceKey };
    });
    return createRecipe(app.db, app.householdId, { title: `Test ${Math.random()}`, servings: 2, steps: [{ text: 'Cook.' }], origin: 'user', ingredients: ings });
  };
  test('a habanero becomes Madame Jeanette, visibly, with the reason', async () => {
    const r = recipeWith(['2 habanero peppers', '1 onion', '400 g black beans']);
    const h = (await app.api('GET', `/api/recipes/${r.id}`)).body.recipe.ingredients.find((i: any) => i.sub?.fromKey === 'x:habanero');
    assert.equal(h.product_id, 'p_madame_jeanette');
    assert.equal(h.match, 'substitute');
    assert.equal(h.sub.original, '2 habanero peppers');
    assert.match(h.sub.note[0], /habanero/);
    assert.equal(h.quantity, 2);
  });
  test('identical-looking products are never substituted automatically', () => {
    const r = recipeWith(['200 g cheddar', '100 ml sour cream', '500 ml chicken broth']);
    assert.deepEqual(r.ingredients.map((i) => [i.product_id, i.match]), [['p_cheddar', 'exact'], ['p_sour_cream', 'exact'], ['p_broth', 'exact']]);
  });
  test('your choice: another alternative, keeping the original, back to default; nutrition follows', async () => {
    const r = recipeWith(['300 g paneer', '1 onion', '400 g canned tomatoes']);
    const get = async () => (await app.api('GET', `/api/recipes/${r.id}`)).body.recipe;
    const before = await get();
    assert.equal(before.ingredients[0].product_id, 'p_halloumi');
    await app.api('PUT', '/api/ingredients/choice', { key: 'x:paneer', choice: 'p_tofu' });
    const tofu = await get();
    assert.equal(tofu.ingredients[0].product_id, 'p_tofu');
    assert.equal(tofu.ingredients[0].sub.choice, 'user');
    assert.ok(tofu.nutritionPerServing.fat < before.nutritionPerServing.fat, 'tofu is leaner than halloumi');
    await app.api('PUT', '/api/ingredients/choice', { key: 'x:paneer', choice: 'keep' });
    const kept = await get();
    assert.equal(kept.ingredients[0].product_id, null);
    assert.equal(kept.compat.level, 'specialist', 'paneer itself needs a specialist shop');
    await app.api('PUT', '/api/ingredients/choice', { key: 'x:paneer', choice: null });
    assert.equal((await get()).ingredients[0].product_id, 'p_halloumi');
  });
  test('substitutions that need something extra add it, with the preparation note', async () => {
    const r = recipeWith(['250 ml buttermilk', '200 g flour', '1 egg']);
    await app.api('PUT', '/api/ingredients/choice', { key: 'p_buttermilk', choice: 'p_milk' });
    const rec = (await app.api('GET', `/api/recipes/${r.id}`)).body.recipe;
    const milk = rec.ingredients.find((i: any) => i.sub?.fromKey === 'p_buttermilk');
    assert.equal(milk.product_id, 'p_milk');
    assert.match(milk.sub.prep[0], /lemon juice/);
    assert.ok(rec.ingredients.some((i: any) => i.extra_for === 'p_buttermilk' && i.product_id === 'p_lemon'));
    await app.api('PUT', '/api/ingredients/choice', { key: 'p_buttermilk', choice: null });
  });
  test('alternatives are country-specific', async () => {
    await app.api('PATCH', '/api/settings', { household: { country: 'BE' } });
    const be = parseIngredientLine(app.db, app.householdId, '2 habanero peppers');
    assert.equal(be.productId, null, 'no Dutch default outside the Netherlands');
    await app.api('PATCH', '/api/settings', { household: { country: 'NL' } });
    assert.equal(parseIngredientLine(app.db, app.householdId, '2 habanero peppers').productId, 'p_madame_jeanette');
  });
  test('recipe compatibility levels', async () => {
    const full = recipeWith(['1 onion', '200 g pasta', '400 g canned tomatoes']);
    const subs = recipeWith(['1 onion', '200 g pasta', '2 habanero peppers']);
    const partial = recipeWith(['1 onion', '200 g pasta', '2 tbsp unicorn sauce']);
    assert.equal(full.compat.level, 'full');
    assert.equal(subs.compat.level, 'substitutions');
    assert.equal(partial.compat.level, 'partial');
    const review = (await app.api('GET', '/api/ingredients/review')).body;
    assert.ok(review.some((x: any) => x.key === 'u:unicorn sauce'), 'unresolved lines are offered for review');
  });
});

describe('recipe imports', () => {
  test('dish type from what’s in it', () => {
    assert.equal(dishKind({ nutritionPerServing: { kcal: 180, protein: 4 }, ingredients: [] }), 'side');
    assert.equal(dishKind({ nutritionPerServing: { kcal: 420, protein: 5, sugars: 40 }, ingredients: [] }), 'dessert');
    assert.equal(dishKind({ nutritionPerServing: { kcal: 550, protein: 30 }, ingredients: [{ optional: false, product: { subcategory: 'poultry' } }] }), null);
  });
});

describe('performance', () => {
  test('identification stays fast with a large product list', () => {
    for (let i = 0; i < 2000; i++) app.db.run("INSERT INTO products (id, household_id, name, category, unit, package_size, synonyms, created_at) VALUES (?, ?, ?, 'pantry', 'g', 100, '[]', ?)", `p_perf_${i}`, app.householdId, `Testproduct ${i} special`, clock.iso());
    const t = performance.now();
    for (let i = 0; i < 2000; i++) identifyIngredient(app.db, app.householdId, i % 2 ? '2 boneless chicken breasts, cubed' : 'a pinch of smoked paprika');
    const ms = (performance.now() - t) / 2000;
    assert.ok(ms < 0.5, `${ms.toFixed(3)} ms per identification`);
    app.db.run("DELETE FROM products WHERE id LIKE 'p_perf_%'");
  });
});
