// Select mode on In stock: remove, use up or throw away many products in one batch, and undo it in one tap.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, stock, type TestApp } from './helpers.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});

async function buy(name: string, quantity: number) {
  const r = await app.api('POST', '/api/inventory/add', { name, quantity });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  return r.body.result.product.id as string;
}

test('removing many products is one batch, and one undo restores them all', async () => {
  const milk = await buy('milk', 1000);
  const eggs = await buy('eggs', 6);
  const eggs2 = await app.api('POST', '/api/inventory/add', { productId: eggs, quantity: 4 });
  assert.equal(eggs2.status, 200);
  const rice = await buy('rice', 500);

  const r = await app.api('POST', '/api/inventory/remove-many', { productIds: [milk, eggs, eggs], type: 'discard', clientRequestId: 'bulk-remove-1' });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal(r.body.duplicate, false);
  assert.equal(r.body.result.count, 2);
  assert.equal(stock(app.db, app.householdId, milk), 0);
  assert.equal(stock(app.db, app.householdId, eggs), 0);
  assert.equal(stock(app.db, app.householdId, rice), 500);

  // Both egg lots and the milk lot went in one batch, as discards.
  const events = app.db.all<{ type: string; reason: string }>('SELECT type, reason FROM inventory_events WHERE batch_id = ?', r.body.batchId);
  assert.equal(events.length, 3);
  assert.ok(events.every((e) => e.type === 'discard' && e.reason === 'other'));

  // A retry (double tap, flaky network) changes nothing.
  const again = await app.api('POST', '/api/inventory/remove-many', { productIds: [milk, eggs], type: 'discard', clientRequestId: 'bulk-remove-1' });
  assert.equal(again.body.duplicate, true);
  assert.equal(again.body.batchId, r.body.batchId);

  const undo = await app.api('POST', '/api/inventory/undo', { batchId: r.body.batchId });
  assert.equal(undo.status, 200, JSON.stringify(undo.body));
  assert.equal(undo.body.events, 3);
  assert.equal(stock(app.db, app.householdId, milk), 1000);
  assert.equal(stock(app.db, app.householdId, eggs), 10);

  const verify = await app.api('GET', '/api/inventory/verify');
  assert.deepEqual(verify.body.mismatches, []);
});

test('used up records consume events; plain remove records a correction', async () => {
  const bread = await buy('bread', 1);
  const cheese = await buy('cheese', 400);
  const used = await app.api('POST', '/api/inventory/remove-many', { productIds: [bread], type: 'consume', clientRequestId: 'bulk-used-1' });
  assert.equal(used.status, 200);
  assert.deepEqual(app.db.all('SELECT type FROM inventory_events WHERE batch_id = ?', used.body.batchId).map((e: any) => e.type), ['consume']);
  const removed = await app.api('POST', '/api/inventory/remove-many', { productIds: [cheese], clientRequestId: 'bulk-removed-1' });
  assert.equal(removed.status, 200);
  assert.deepEqual(app.db.all('SELECT type, reason FROM inventory_events WHERE batch_id = ?', removed.body.batchId).map((e: any) => [e.type, e.reason]), [['adjust', 'removed']]);
  assert.equal(stock(app.db, app.householdId, cheese), 0);
});

test('bad input is rejected', async () => {
  assert.equal((await app.api('POST', '/api/inventory/remove-many', { productIds: [] })).status, 400);
  assert.equal((await app.api('POST', '/api/inventory/remove-many', { productIds: ['x'], type: 'eat' })).status, 400);
});
