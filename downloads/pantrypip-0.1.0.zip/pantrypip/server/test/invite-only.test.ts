// Invite only (the public copy): signing up needs a household's invite code, or a friend's code or link.
// A friend's code gives you your own household and makes you friends; a household's code joins it.
import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import type { AddressInfo } from 'node:net';
import { createApp } from '../src/index.ts';
import { clock } from '../src/clock.ts';
import { captureMail, outbox } from '../src/mail.ts';

const apps: ReturnType<typeof createApp>[] = [];
after(async () => {
  captureMail(false);
  for (const a of apps) await new Promise<void>((r) => a.server.close(() => (a.db.close(), r())));
});

async function start(opts: { emailConfirm: boolean; inviteOnly: boolean }) {
  clock.set(null);
  const app = createApp(':memory:', { seedDemo: false, ...opts });
  apps.push(app);
  await new Promise<void>((r) => app.server.listen(0, '127.0.0.1', () => r()));
  const url = `http://127.0.0.1:${(app.server.address() as AddressInfo).port}`;
  /** A client with its own cookie jar. */
  const client = () => {
    let cookie = '';
    return async (method: string, path: string, body?: unknown) => {
      const res = await fetch(url + path, { method, headers: { 'content-type': 'application/json', cookie }, body: body === undefined ? undefined : JSON.stringify(body) });
      const set = res.headers.get('set-cookie');
      if (set) cookie = set.split(';')[0];
      const text = await res.text();
      return { status: res.status, body: text ? JSON.parse(text) : null } as { status: number; body: any };
    };
  };
  return { app, client };
}

let n = 0;
const signup = (name: string, inviteCode?: string | null) => ({ email: `${name.toLowerCase()}${++n}@larder.test`, password: 'a-long-password', name, inviteCode });

test('without an invite nobody can sign up; a friend’s link or a household code lets you in', async () => {
  const { app, client } = await start({ emailConfirm: false, inviteOnly: true });
  assert.equal((await client()('GET', '/api/config')).body.inviteOnly, true, 'the sign-up screen knows to ask for a code');

  const nobody = await client()('POST', '/api/auth/register', signup('Nobody'));
  assert.equal(nobody.status, 403);
  assert.equal(nobody.body.error.code, 'invite_required');
  const wrong = await client()('POST', '/api/auth/register', signup('Guesser', 'ZZZZZZZZ'));
  assert.equal(wrong.status, 404);
  assert.equal(wrong.body.error.code, 'invalid_invite');
  assert.equal(app.db.get<{ n: number }>('SELECT COUNT(*) n FROM users')!.n, 0, 'no accounts were made');

  // The first account (here, made the way the owner's test accounts are) has a friend code to share.
  const { registerUser } = await import('../src/http/auth.ts');
  const { createHousehold } = await import('../src/db/seed.ts');
  const ana = app.db.tx(() => registerUser(app.db, signup('Ana'), (name) => createHousehold(app.db, name)));
  const anaApi = client();
  assert.equal((await anaApi('POST', '/api/auth/login', { email: ana.email, password: 'a-long-password' })).status, 200);
  const code: string = (await anaApi('GET', '/api/friends')).body.code;

  // Bo signs up with Ana's friend link (pasted whole): own household, and friends with Ana already.
  const boApi = client();
  const link = `https://app.example/#/friends?friend=${code.slice(0, 4).toLowerCase()}-${code.slice(4)}`;
  assert.equal((await boApi('POST', '/api/auth/register', signup('Bo', link))).status, 201);
  const bo = (await boApi('GET', '/api/me')).body;
  assert.notEqual(bo.household.id, ana.household_id, 'a friend’s code doesn’t join their household');
  assert.deepEqual((await anaApi('GET', '/api/friends')).body.friends.map((f: any) => f.name), ['Bo']);
  assert.deepEqual((await boApi('GET', '/api/friends')).body.friends.map((f: any) => f.name), ['Ana']);
  const f = app.db.get<{ requester_id: string; via: string }>('SELECT requester_id, via FROM friendships')!;
  assert.deepEqual([f.requester_id, f.via], [bo.user.id, 'code'], 'counts as an invite by code (for the invite reward)');

  // Cy joins Ana's household with its invite code.
  const invite = app.db.get<{ invite_code: string }>('SELECT invite_code FROM households WHERE id = ?', ana.household_id)!.invite_code;
  const cyApi = client();
  assert.equal((await cyApi('POST', '/api/auth/register', signup('Cy', invite.toLowerCase()))).status, 201);
  assert.equal((await cyApi('GET', '/api/me')).body.household.id, ana.household_id);
});

test('with email confirmation, the invite is checked up front and used when the link is opened', async () => {
  captureMail(true);
  const { app, client } = await start({ emailConfirm: true, inviteOnly: true });
  const { registerUser } = await import('../src/http/auth.ts');
  const { createHousehold } = await import('../src/db/seed.ts');
  const host = app.db.tx(() => registerUser(app.db, signup('Host'), (name) => createHousehold(app.db, name)));
  const hostApi = client();
  await hostApi('POST', '/api/auth/login', { email: host.email, password: 'a-long-password' });
  const code: string = (await hostApi('GET', '/api/friends')).body.code;

  // No invite: refused before any email goes out.
  const before = outbox.length;
  assert.equal((await client()('POST', '/api/auth/register', signup('Nobody'))).status, 403);
  assert.equal((await client()('POST', '/api/auth/register', signup('Guesser', 'NOPE1234'))).status, 404);
  assert.equal(outbox.length, before, 'no email for a refused sign-up');

  const guest = client();
  const r = await guest('POST', '/api/auth/register', signup('Guest', code));
  assert.equal(r.status, 202);
  const token = outbox.at(-1)!.text.match(/#\/confirm\/([A-Za-z0-9_-]+)/)![1];
  assert.equal((await guest('POST', '/api/auth/confirm', { token })).status, 201);
  assert.deepEqual((await guest('GET', '/api/friends')).body.friends.map((f: any) => f.name), ['Host']);
});

test('without invite only, signing up stays open (the home copy)', async () => {
  const { client } = await start({ emailConfirm: false, inviteOnly: false });
  assert.equal((await client()('GET', '/api/config')).body.inviteOnly, false);
  assert.equal((await client()('POST', '/api/auth/register', signup('Open'))).status, 201);
  // A code that's wrong is still an error, never a silent new household.
  assert.equal((await client()('POST', '/api/auth/register', signup('Typo', 'WRONGCODE'))).status, 404);
});
