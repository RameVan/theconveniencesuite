// iPhone: Siri Shortcut endpoint and the HTTPS setup companion.
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import type { AddressInfo } from 'node:net';
import { mkdtempSync, writeFileSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { startApp, stock, type TestApp } from './helpers.ts';
import { clock } from '../src/clock.ts';
import { httpCompanion } from '../src/index.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
});
after(async () => {
  clock.set(null);
  await app.close();
});

/** Call the Shortcut endpoint the way the iPhone does: bearer token, no session cookie. */
async function siri(token: string, text: string) {
  const res = await fetch(`${app.url}/api/shortcut/say`, { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` }, body: JSON.stringify({ text }) });
  return { status: res.status, type: res.headers.get('content-type') ?? '', text: await res.text() };
}

describe('Siri Shortcut', () => {
  test('a token lets Siri talk to the assistant and get a plain-text answer', async () => {
    await app.api('POST', '/api/inventory/add', { productId: 'p_milk', quantity: 1000 });
    const { token } = (await app.api('POST', '/api/tokens', { name: 'Siri' })).body;
    assert.match(token, /^lrd_/);
    const r = await siri(token, 'I finished the milk');
    assert.equal(r.status, 200);
    assert.match(r.type, /text\/plain/);
    assert.match(r.text, /Finished the semi-skimmed milk/);
    assert.equal(stock(app.db, app.householdId, 'p_milk'), 0);
  });

  test('follow-up questions continue across Siri calls', async () => {
    await app.api('POST', '/api/inventory/add', { productId: 'p_yoghurt', quantity: 500 });
    const { token } = (await app.api('POST', '/api/tokens', { name: 'Siri 2' })).body;
    const q = await siri(token, 'I used some yoghurt');
    assert.match(q.text, /Approximately how much\? .*Run PantryPip again to answer\./);
    await siri(token, '100 grams');
    assert.equal(stock(app.db, app.householdId, 'p_yoghurt'), 400);
  });

  test('without words, Siri asks the daily cooking question', async () => {
    const d = new Date();
    d.setHours(21, 0, 0, 0);
    clock.set(d);
    await app.api('POST', '/api/plan', { date: clock.today(), meal: 'dinner', recipeId: 'r_omelette', servings: 1 });
    const { token } = (await app.api('POST', '/api/tokens', { name: 'Siri 3' })).body;
    const r = await siri(token, '');
    assert.match(r.text, /Did you cook Cheese & vegetable omelette tonight\?/);
    clock.set(null);
  });

  test('tokens only unlock the assistant, can be revoked, and bad tokens are refused', async () => {
    const { token, id } = (await app.api('POST', '/api/tokens', { name: 'Temp' })).body;
    const inv = await fetch(`${app.url}/api/inventory`, { headers: { authorization: `Bearer ${token}` } });
    assert.equal(inv.status, 401, 'no access to the rest of the API');
    assert.equal((await siri('lrd_nope', 'hello')).status, 401);
    await app.api('DELETE', `/api/tokens/${id}`);
    assert.equal((await siri(token, 'hello')).status, 401);
    const list = (await app.api('GET', '/api/tokens')).body;
    assert.ok(list.every((t: any) => !('token_hash' in t)), 'hashes never leave the server');
  });
});

describe('HTTPS companion (iPhone setup)', () => {
  test('serves the setup page and certificate over HTTP, redirects everything else to HTTPS', async () => {
    const dir = mkdtempSync(path.join(os.tmpdir(), 'larder-ca-'));
    const ca = path.join(dir, 'larder-ca.crt');
    writeFileSync(ca, '-----BEGIN CERTIFICATE-----\nTEST\n-----END CERTIFICATE-----\n');
    const server = httpCompanion(8443, ca);
    await new Promise<void>((r) => server.listen(0, '127.0.0.1', () => r()));
    const port = (server.address() as AddressInfo).port;
    const get = (p: string) => fetch(`http://127.0.0.1:${port}${p}`, { redirect: 'manual' });
    const page = await get('/setup');
    assert.match(await page.text(), /Install the certificate[\s\S]*https:\/\/127\.0\.0\.1:8443/);
    const crt = await get('/setup/larder-ca.crt');
    assert.equal(crt.headers.get('content-type'), 'application/x-x509-ca-cert');
    const other = await get('/api/inventory');
    assert.equal(other.status, 308);
    assert.equal(other.headers.get('location'), 'https://127.0.0.1:8443/api/inventory');
    await new Promise<void>((r) => server.close(() => r()));
  });
});
