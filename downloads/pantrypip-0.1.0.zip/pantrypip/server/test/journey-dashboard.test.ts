// The progression journey and the personal dashboard, driven over HTTP on a fresh household:
// advancing on the path, finishing a chapter, XP that can't be earned twice, layouts that persist,
// presets, live widget data, and suggestions that never change the layout by themselves.
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, type TestApp } from './helpers.ts';
import { clock, addDays } from '../src/clock.ts';
import { generateNotifications } from '../src/scheduler.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
});
after(async () => {
  clock.set(null);
  await app.close();
});

const recipeIds = () => app.db.all<{ id: string }>("SELECT id FROM recipes WHERE household_id IS NULL AND tags NOT LIKE '%breakfast%' ORDER BY id").map((r) => r.id);
const journey = async () => (await app.api('GET', '/api/journey')).body;
const nodeOf = (j: any, id: string) => j.chapters.flatMap((c: any) => [...c.path, ...c.bonus]).find((n: any) => n.id === id);
let n = 0;
const cook = async (recipeId: string) => {
  const r = await app.api('POST', `/api/recipes/${recipeId}/cook`, { clientRequestId: `cook-${++n}` });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  return r.body;
};
const journeyXp = () => app.db.get<{ xp: number }>('SELECT COALESCE(SUM(xp), 0) xp FROM journey_nodes WHERE household_id = ?', app.householdId)!.xp;

describe('Progression journey', () => {
  test('a fresh household starts at chapter 1 with a clear next step', async () => {
    const j = await journey();
    assert.equal(j.chapters.length, 7);
    assert.equal(j.chapters[0].unlocked, true);
    assert.equal(j.chapters[1].unlocked, false);
    assert.equal(j.chapters[0].path.filter((x: any) => x.kind === 'task').length, 5);
    assert.ok(j.chapters[0].path.some((x: any) => x.state === 'current'));
    assert.ok(j.chapters[1].path.every((x: any) => x.state === 'locked'), 'later chapters are visible but locked');
    assert.ok(j.current?.cta?.href, 'the next step links somewhere useful');
    assert.equal(j.companion.stage, 0);
  });

  test('completing a task advances along the path and awards XP once', async () => {
    const before = await journey();
    const add5 = nodeOf(before, 'c1:add5');
    assert.equal(add5.state === 'current' || add5.state === 'available', true);
    for (const p of ['p_milk', 'p_eggs', 'p_spinach', 'p_rice', 'p_onion']) await app.api('POST', '/api/inventory/add', { productId: p, quantity: 1, packages: 1 });
    const after = await journey();
    assert.equal(nodeOf(after, 'c1:add5').state, 'completed');
    assert.equal(nodeOf(after, 'c1:add5').fresh, true, 'shown as new until celebrated');
    assert.ok(after.fresh.includes('c1:add5'));
    const xp = journeyXp();
    assert.ok(xp >= 15);
    // Reading again, many times, never adds XP.
    await journey();
    await app.api('GET', '/api/journey/fresh');
    assert.equal(journeyXp(), xp);
    await app.api('POST', '/api/journey/seen', {});
    assert.equal(nodeOf(await journey(), 'c1:add5').fresh, false);
    const game = (await app.api('GET', '/api/game')).body;
    assert.equal(game.journeyXp, xp, 'journey XP counts towards level XP');
  });

  test('finishing every task, the chest and the final challenge completes the chapter and unlocks the next', async () => {
    const [r1, r2, r3, r4, r5, r6] = recipeIds();
    await app.api('POST', `/api/recipes/${r1}/interaction`, { saved: true, rating: 5 });
    await app.api('POST', '/api/inventory/consume', { productId: 'p_milk', quantity: 100 });
    const plan = (await app.api('POST', '/api/plan/auto/preview', { days: 3, servings: 2 })).body;
    await app.api('POST', '/api/plan/auto/apply', { days: plan.plan.map((d: any) => ({ date: d.date, recipeId: d.recipeId })), servings: 2 });
    const first = await cook(r2);
    assert.ok(first.reward.journey.some((x: any) => x.id === 'c1:cook1'), 'the cook reward reports the journey step');
    assert.ok(first.reward.parts.some((p: any) => p.key === 'journey:c1:cook1'));

    let j = await journey();
    const c1 = j.chapters[0];
    assert.equal(c1.tasksDone, c1.tasksTotal, JSON.stringify(c1.path.map((x: any) => [x.id, x.state, x.progress])));
    assert.equal(nodeOf(j, 'c1:milestone').state, 'completed', 'the reward chest opens halfway');
    assert.equal(nodeOf(j, 'c1:boss').state, 'current', 'the final challenge is next');
    assert.equal(j.chapters[1].unlocked, false);

    // The final challenge only counts what happens after it opened.
    for (const r of [r3, r4, r5]) await cook(r);
    j = await journey();
    assert.equal(nodeOf(j, 'c1:boss').state, 'completed');
    assert.equal(j.chapters[0].completed, true);
    assert.equal(j.chapters[0].fresh, true, 'a chapter completion gets its own celebration');
    assert.equal(j.chapters[1].unlocked, true);
    assert.equal(j.chapters[1].path.filter((x: any) => x.kind === 'task').length, 5);
    assert.ok(j.companion.skins.find((s: any) => s.id === 'tomato').unlocked, 'chapter reward: a new look for Pip');
    assert.equal(j.companion.stage, 1);
    assert.ok(j.decor.find((d: any) => d.id === 'herbs').unlocked);
    // Locked looks can't be chosen; unlocked ones can.
    assert.equal((await app.api('PUT', '/api/journey/companion', { skin: 'golden' })).status, 403);
    assert.equal((await app.api('PUT', '/api/journey/companion', { skin: 'tomato' })).status, 200);
    await cook(r6);
  });

  test('XP cannot be duplicated: repeats, retries and undo', async () => {
    const before = journeyXp();
    const nodes = app.db.get<{ n: number }>('SELECT COUNT(*) n FROM journey_nodes WHERE household_id = ?', app.householdId)!.n;
    // The same cook sent twice is one cook, with no second reward.
    const r = recipeIds()[7];
    const a = await app.api('POST', `/api/recipes/${r}/cook`, { clientRequestId: 'same-cook' });
    const b = await app.api('POST', `/api/recipes/${r}/cook`, { clientRequestId: 'same-cook' });
    assert.equal(b.body.duplicate, true);
    assert.equal(b.body.reward, null);
    const mid = journeyXp();
    // Undoing the cook does not un-complete finished nodes (historic achievements stay), and doing it again earns nothing new from them.
    await app.api('POST', '/api/inventory/undo', { batchId: a.body.batchId });
    await journey();
    assert.equal(journeyXp(), mid);
    assert.ok(mid >= before);
    assert.ok(app.db.get<{ n: number }>('SELECT COUNT(*) n FROM journey_nodes WHERE household_id = ?', app.householdId)!.n >= nodes);
    // Track levels are stored once too.
    const tracks = app.db.all<{ node_id: string }>("SELECT node_id FROM journey_nodes WHERE household_id = ? AND kind = 'track'", app.householdId).map((x) => x.node_id);
    assert.equal(new Set(tracks).size, tracks.length);
    assert.ok(tracks.includes('track:cooking:1'));
  });

  test('a task that does not fit right now can be swapped', async () => {
    const j = await journey();
    const open = j.chapters[1].path.find((x: any) => x.kind === 'task' && !x.done);
    const res = await app.api('POST', '/api/journey/swap', { nodeId: open.id });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const after = await journey();
    assert.ok(!after.chapters[1].path.some((x: any) => x.id === open.id));
    assert.equal(after.chapters[1].path.filter((x: any) => x.kind === 'task').length, 5);
  });

  test('parallel tracks progress from real activity', async () => {
    const j = await journey();
    const cooking = j.tracks.find((t: any) => t.id === 'cooking');
    assert.ok(cooking.level >= 2, 'five or more meals cooked');
    assert.equal(j.tracks.length, 5);
  });
});

describe('Personal dashboard', () => {
  test('starts with a good default and saves layout changes', async () => {
    const d = (await app.api('GET', '/api/dashboard')).body;
    assert.ok(d.widgets.length >= 32);
    assert.ok(d.presets.length >= 4 && d.presets.length <= 6, 'a few useful presets');
    assert.equal(d.config.active, 'home');
    assert.deepEqual(d.config.profiles[0].layouts.phone.map((x: any) => x.type), ['tonight', 'shopping', 'expiring', 'fromStock'], 'a calm default: tonight, the list, use first, ideas');
    const cfg = d.config;
    const everyday = cfg.profiles.find((p: any) => p.id === 'home');
    // Reorder, resize, compact, pin, hide, add, remove.
    const phone = [...everyday.layouts.phone];
    phone.reverse();
    phone[0] = { ...phone[0], size: 'l', view: 'compact', pinned: true };
    phone[1] = { ...phone[1], hidden: true };
    phone.push({ id: 'moneySaved', type: 'moneySaved', size: 's', view: 'expanded' });
    const removed = phone.splice(2, 1)[0];
    everyday.layouts.phone = phone;
    everyday.layouts.tablet = phone.slice(0, 3);
    const put = await app.api('PUT', '/api/dashboard', cfg);
    assert.equal(put.status, 200, JSON.stringify(put.body));
    const again = (await app.api('GET', '/api/dashboard')).body.config.profiles.find((p: any) => p.id === 'home');
    assert.deepEqual(again.layouts.phone.map((x: any) => x.id), phone.map((x) => x.id));
    assert.equal(again.layouts.phone[0].pinned, true);
    assert.equal(again.layouts.phone[1].hidden, true);
    assert.ok(again.layouts.phone.some((x: any) => x.type === 'moneySaved'));
    assert.ok(!again.layouts.phone.some((x: any) => x.id === removed.id));
    assert.equal(again.layouts.tablet.length, 3, 'tablet keeps its own layout');
  });

  test('rejects unknown widgets and fixes sizes a widget does not support', async () => {
    const cfg = (await app.api('GET', '/api/dashboard')).body.config;
    const bad = structuredClone(cfg);
    bad.profiles[0].layouts.phone.push({ id: 'x', type: 'nope', size: 'm', view: 'expanded' });
    assert.equal((await app.api('PUT', '/api/dashboard', bad)).status, 400);
    const odd = structuredClone(cfg);
    odd.profiles[0].layouts.phone = [{ id: 'shopping', type: 'shopping', size: 's', view: 'expanded' }];
    const saved = (await app.api('PUT', '/api/dashboard', odd)).body.config;
    assert.equal(saved.profiles[0].layouts.phone[0].size, 'm');
  });

  test('switching profiles and presets', async () => {
    const d = (await app.api('GET', '/api/dashboard')).body;
    const cfg = d.config;
    cfg.profiles.push({ id: 'shop', name: 'Shopping', preset: 'minimal', layouts: { phone: [{ id: 'shopping', type: 'shopping', size: 'l', view: 'expanded' }] } });
    cfg.active = 'shop';
    await app.api('PUT', '/api/dashboard', cfg);
    assert.equal((await app.api('GET', '/api/dashboard')).body.config.active, 'shop');
    const minimal = d.presets.find((p: any) => p.id === 'minimal');
    cfg.profiles.push({ id: 'p-min', name: 'Weeknights', preset: 'minimal', layouts: { phone: minimal.widgets } });
    cfg.active = 'p-min';
    await app.api('PUT', '/api/dashboard', cfg);
    const saved = (await app.api('GET', '/api/dashboard')).body.config;
    assert.equal(saved.active, 'p-min');
    assert.deepEqual(saved.profiles.find((p: any) => p.id === 'p-min').layouts.phone.map((x: any) => x.type), ['tonight', 'shopping']);
    const reset = (await app.api('POST', '/api/dashboard/reset', {})).body.config;
    assert.equal(reset.active, 'home');
    assert.equal(reset.profiles.length, 1);
  });

  test('widgets show live data', async () => {
    await app.api('POST', '/api/inventory/add', { productId: 'p_chicken_breast', quantity: 500, expiresOn: addDays(clock.today(), 1) });
    await app.api('POST', '/api/shopping', { name: 'lemons' });
    const types = ['shopping', 'expiring', 'tonight', 'cookingStreak', 'xp', 'cookingStats', 'inventory', 'journey', 'planProgress', 'weekPlan', 'dailyNutrition', 'protein', 'recentlyCooked', 'favourites', 'moneySaved', 'wasteStats', 'spending', 'topIngredients', 'fifo', 'missing', 'achievements', 'recipeOfDay', 'quickMeals', 'highProtein', 'fromStock', 'toTry', 'challenge', 'nutritionScore', 'nutritionStreak', 'weeklyNutrition', 'low', 'recent', 'leftovers', 'listSuggestions', 'autoPlan', 'activity', 'quickAdd'];
    const data = (await app.api('GET', `/api/dashboard/data?types=${types.join(',')}`)).body;
    for (const t of types) assert.ok(data[t] && !data[t].error, `${t}: ${JSON.stringify(data[t])}`);
    const shopping = (await app.api('GET', '/api/shopping')).body;
    assert.equal(data.shopping.count, shopping.count);
    assert.ok(data.shopping.items.some((i: any) => i.name.toLowerCase().includes('lemon')));
    assert.ok(data.expiring.items.some((i: any) => i.id === 'p_chicken_breast'));
    const game = (await app.api('GET', '/api/game')).body;
    assert.equal(data.cookingStreak.current, game.streaks.cooking.current);
    assert.equal(data.xp.xp, game.xp);
    const cooks = app.db.get<{ n: number }>('SELECT COUNT(*) n FROM cook_log WHERE household_id = ?', app.householdId)!.n;
    assert.equal(data.cookingStats.total, cooks);
    assert.ok(data.dailyNutrition.logged >= 1 && data.dailyNutrition.totals.kcal > 0, 'today’s meals count');
    assert.equal(data.recentlyCooked.items.length > 0, true);
    assert.equal(data.favourites.items[0].rating, 5);
  });

  test('suggestions come from use and never change the layout on their own', async () => {
    const before = JSON.stringify((await app.api('GET', '/api/dashboard')).body.config);
    for (let i = 0; i < 6; i++) await app.api('POST', '/api/dashboard/usage', { key: 'open:shopping' });
    for (let i = 0; i < 4; i++) await app.api('POST', '/api/dashboard/usage', { key: 'recipe:favourite' });
    const d = (await app.api('GET', '/api/dashboard')).body;
    assert.ok(d.suggestions.some((s: any) => s.id === 'add-favourites'), JSON.stringify(d.suggestions));
    assert.equal(JSON.stringify(d.config), before, 'reading suggestions leaves the layout alone');
    await app.api('POST', '/api/dashboard/suggestions/add-favourites/dismiss', {});
    const after = (await app.api('GET', '/api/dashboard')).body;
    assert.ok(!after.suggestions.some((s: any) => s.id === 'add-favourites'));
    assert.equal(JSON.stringify(after.config), before);
    assert.equal((await app.api('POST', '/api/dashboard/usage', { key: 'drop table' })).status, 400);
  });

  test('appearance is per person and validated', async () => {
    const r = await app.api('PUT', '/api/preferences/me', { appearance: { theme: 'dark', density: 'compact', motion: 'reduced' } });
    assert.equal(r.status, 200);
    assert.equal((await app.api('GET', '/api/preferences/me')).body.appearance.theme, 'dark');
    assert.equal((await app.api('PUT', '/api/preferences/me', { appearance: { theme: 'neon' } })).status, 400);
    // Theme styles: one of the six, kept alongside the other appearance choices.
    assert.equal((await app.api('PUT', '/api/preferences/me', { appearance: { style: 'night' } })).status, 200);
    const look = (await app.api('GET', '/api/preferences/me')).body.appearance;
    assert.equal(look.style, 'night');
    assert.equal(look.theme, 'dark', 'changing the style keeps the other choices');
    assert.equal((await app.api('PUT', '/api/preferences/me', { appearance: { style: 'neon' } })).status, 400);
    // Spending & waste is optional, per person.
    await app.api('PUT', '/api/preferences/me', { appearance: { showMoney: false } });
    assert.equal((await app.api('GET', '/api/preferences/me')).body.appearance.showMoney, false);
    assert.equal((await app.api('GET', '/api/preferences/me')).body.appearance.style, 'night', 'other choices kept');
  });
});

describe('Personalisation drives the planner and reminders', () => {
  test('dinner days, difficulty and nutrition priorities shape the plan', async () => {
    await app.api('PUT', '/api/preferences', { planDays: [1, 3, 5], maxDifficulty: 'easy', nutritionPriorities: ['protein'], newPerWeek: 1 });
    const p = (await app.api('POST', '/api/plan/auto/preview', { days: 7, servings: 2, replace: true })).body;
    const planned = p.plan.filter((d: any) => !d.existing);
    assert.ok(planned.every((d: any) => [1, 3, 5].includes(new Date(d.date + 'T12:00:00Z').getUTCDay())), JSON.stringify(planned.map((d: any) => d.date)));
    assert.ok(planned.some((d: any) => d.why.some((w: any) => w.factor === 'your nutrition priorities')));
    const prefs = (await app.api('GET', '/api/preferences')).body;
    assert.deepEqual(prefs.planning.planDays, [1, 3, 5]);
    await app.api('PUT', '/api/preferences', { planDays: [0, 1, 2, 3, 4, 5, 6], maxDifficulty: 'hard', nutritionPriorities: [], newPerWeek: null as any });
  });

  test('notification frequency: off sends nothing, daily bundles into one summary', async () => {
    await app.api('POST', '/api/inventory/add', { productId: 'p_yoghurt', quantity: 500, expiresOn: clock.today() });
    const count = () => app.db.get<{ n: number }>('SELECT COUNT(*) n FROM notifications WHERE household_id = ?', app.householdId)!.n;
    await app.api('PUT', '/api/preferences', { notifications: { frequency: 'off' } });
    const n0 = count();
    await generateNotifications(app.db, { push: false });
    assert.equal(count(), n0);
    await app.api('PUT', '/api/preferences', { notifications: { frequency: 'daily' } });
    await generateNotifications(app.db, { push: false });
    const unread = app.db.all<{ kind: string }>('SELECT kind FROM notifications WHERE household_id = ? AND read = 0', app.householdId);
    assert.equal(unread.filter((x) => x.kind === 'digest').length, 1);
    assert.ok(!unread.some((x) => x.kind === 'expiry'), 'bundled, not one by one');
    await generateNotifications(app.db, { push: false });
    assert.equal(app.db.all('SELECT 1 FROM notifications WHERE household_id = ? AND kind = ?', app.householdId, 'digest').length, 1, 'one summary a day');
  });
});
