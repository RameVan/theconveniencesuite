// Swapping an ingredient for one planned meal (basmati rice → sushi rice): the shopping list warns which
// meals need an item, swaps it in those meals, and cooking takes the new ingredient from stock.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, stock, type TestApp } from './helpers.ts';
import { addDays, clock } from '../src/clock.ts';

let app: TestApp;
let sushi: string;
before(async () => {
  app = await startApp();
  sushi = (await app.api('POST', '/api/products', { name: 'Sushi rice', category: 'pasta_rice', unit: 'g', package_size: 500 })).body.id;
});
after(async () => {
  await app.close();
});
const listed = async () => (await app.api('GET', '/api/shopping')).body.groups.flatMap((g: any) => g.items);
const named = async (name: string) => (await listed()).find((i: any) => i.name === name);
const curry = (offset: number, swaps?: any[]) => app.api('POST', '/api/plan', { date: addDays(clock.today(), offset), meal: 'dinner', recipeId: 'r_chicken_curry', servings: 2, swaps }).then((r) => r.body);

test('a list item a recipe needs says which meals need it', async () => {
  const slot = await curry(1);
  const rice = await named('Basmati rice');
  assert.ok(rice, 'basmati rice is on the list for the curry');
  const uses = (await app.api('GET', `/api/shopping/${rice.id}/uses`)).body;
  assert.deepEqual(uses.map((u: any) => [u.slotId, u.title, u.ingredient]), [[slot.id, 'Creamy chicken coconut curry', 'Basmati rice']]);
  await app.api('DELETE', `/api/plan/${slot.id}`);
});

test('swapping a list item swaps it in the meals that need it, and the list follows', async () => {
  const a = await curry(1);
  const b = await curry(3);
  const rice = await named('Basmati rice');
  const r = await app.api('POST', `/api/shopping/${rice.id}/replace`, { productId: sushi });
  assert.equal(r.status, 200);
  assert.equal(r.body.meals, 2);
  assert.equal(await named('Basmati rice'), undefined, 'basmati is off the list');
  const item = await named('Sushi rice');
  assert.ok(item, 'sushi rice is on it');
  assert.match(item.note, /replaces Basmati rice/);
  const slot = (await app.api('GET', `/api/plan?start=${addDays(clock.today(), 1)}&days=1`)).body.days[0].slots[0];
  assert.deepEqual(slot.swaps.map((s: any) => [s.from, s.to]), [['Basmati rice', 'Sushi rice']]);
  for (const s of [a, b]) await app.api('DELETE', `/api/plan/${s.id}`);
});

test('a swap chosen when planning, undone per ingredient, and cleared by changing the recipe', async () => {
  const slot = await curry(2, [{ position: 5, productId: sushi }]);
  assert.ok(await named('Sushi rice'));
  const back = await app.api('POST', `/api/plan/${slot.id}/ingredient`, { position: 5, productId: null });
  assert.deepEqual(back.body.swaps, []);
  assert.ok(await named('Basmati rice'));
  await app.api('POST', `/api/plan/${slot.id}/ingredient`, { position: 5, productId: sushi });
  const changed = await app.api('POST', `/api/plan/${slot.id}/choose`, { recipeId: 'r_mushroom_risotto' });
  assert.deepEqual(changed.body.swaps, [], 'a different recipe starts without the old swaps');
  await app.api('DELETE', `/api/plan/${slot.id}`);
});

test('cooking a meal with a swap takes the swapped ingredient from stock', async () => {
  await app.api('POST', '/api/inventory/add', { productId: sushi, quantity: 1000 });
  await app.api('POST', '/api/inventory/add', { productId: 'p_rice', quantity: 1000 });
  const slot = await curry(0, [{ position: 5, productId: sushi }]);
  const r = await app.api('POST', `/api/plan/${slot.id}/cook`, {});
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.ok(stock(app.db, app.householdId, sushi) < 1000, 'sushi rice was used');
  assert.equal(stock(app.db, app.householdId, 'p_rice'), 1000, 'basmati was not touched');
});

test('items no recipe needs have no meals, and cannot be swapped this way', async () => {
  const own = (await app.api('POST', '/api/shopping', { name: 'Coffee' })).body;
  const id = own.id ?? own.item?.id;
  assert.deepEqual((await app.api('GET', `/api/shopping/${id}/uses`)).body, []);
  assert.equal((await app.api('POST', `/api/shopping/${id}/replace`, { productId: sushi })).status, 409);
});

test('leaving an item out of the meals takes it off the list, and cooking skips it', async () => {
  await app.api('POST', '/api/inventory/add', { productId: 'p_coconut_milk', quantity: 800 });
  const slot = await curry(1);
  // Any ingredient this meal puts on the list (not in stock yet).
  let item: any;
  for (const i of await listed()) if ((await app.api('GET', `/api/shopping/${i.id}/uses`)).body.some((u: any) => u.slotId === slot.id)) item = i;
  assert.ok(item, 'the curry puts something on the list');
  const r = await app.api('POST', `/api/shopping/${item.id}/replace`, { omit: true });
  assert.equal(r.status, 200);
  assert.equal(await named(item.name), undefined, `${item.name} is off the list`);
  const s = (await app.api('GET', `/api/plan?start=${addDays(clock.today(), 1)}&days=1`)).body.days[0].slots.find((x: any) => x.id === slot.id);
  assert.deepEqual(s.swaps.map((w: any) => [w.from, !!w.omit]), [[item.name, true]]);
  assert.equal((await app.api('POST', `/api/shopping/${item.id}/replace`, {})).status, 400, 'a product or omit is required');
  await app.api('POST', '/api/inventory/add', { productId: item.product_id ?? item.product?.id, quantity: 500 });
  const left = stock(app.db, app.householdId, item.product_id ?? item.product?.id);
  const milk = stock(app.db, app.householdId, 'p_coconut_milk');
  await app.api('POST', `/api/plan/${slot.id}/cook`, {});
  assert.equal(stock(app.db, app.householdId, item.product_id ?? item.product?.id), left, `${item.name} was left out when cooking`);
  assert.ok(stock(app.db, app.householdId, 'p_coconut_milk') < milk, 'the rest of the recipe was used');
});
