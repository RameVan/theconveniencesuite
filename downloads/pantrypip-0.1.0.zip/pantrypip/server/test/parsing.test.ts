import { test } from 'node:test';
import assert from 'node:assert/strict';
import { parse } from '../src/assistant/parser.ts';
import { parseReceiptText, cleanName, parseSize } from '../src/domain/receipts.ts';
import { toBase, formatQty, packagesFor } from '../src/domain/units.ts';
import { AH_RECEIPT, JUMBO_RECEIPT, LIDL_RECEIPT } from './helpers.ts';

const first = (s: string) => parse(s).intents[0] as any;

test('every example command from the brief maps to the right intent', () => {
  const cases: [string, string, Partial<{ name: string; amount: number | null; unit: string | null; all: boolean }>?][] = [
    ['I bought two litres of milk.', 'add_inventory', { name: 'milk', amount: 2, unit: 'litres' }],
    ['Add six eggs to my groceries.', 'add_inventory', { name: 'eggs', amount: 6 }],
    ['Remove one onion.', 'consume', { name: 'onion', amount: 1 }],
    ['I used 200 grams of chicken.', 'consume', { name: 'chicken', amount: 200, unit: 'grams' }],
    ['I finished the milk.', 'consume', { name: 'milk', all: true }],
    ['Remove the remaining spinach, it has gone bad.', 'discard', { name: 'spinach', all: true }],
    ['I bought groceries, scan this receipt.', 'scan_receipt'],
    ['What groceries do I currently have?', 'query_inventory'],
    ['How much chicken do I have left?', 'query_item'],
    ['Add coffee to my shopping list.', 'shopping_add', { name: 'coffee' }],
    ["What's running low?", 'query_low'],
    ['What should I buy this week?', 'query_buy'],
    ['What can I cook with what I have?', 'query_cook'],
    ['I just cooked pasta for two people.', 'cooked'],
    ['I froze two portions of lasagna.', 'freeze', { name: 'lasagna', amount: 2 }],
  ];
  for (const [text, type, item] of cases) {
    const i = first(text);
    assert.equal(i.type, type, text);
    if (item) for (const [k, v] of Object.entries(item)) assert.equal(i.items[0][k], v, `${text} → ${k}`);
  }
});

test('Dutch commands', () => {
  assert.deepEqual([first('ik heb 2 liter melk gekocht').type, parse('ik heb 2 liter melk gekocht').lang], ['add_inventory', 'nl']);
  assert.equal(first('de melk is op').items[0].all, true);
  assert.equal(first('zet koffie op de boodschappenlijst').type, 'shopping_add');
  assert.equal(first('gooi de spinazie weg, die is bedorven').type, 'discard');
  assert.equal(first('hoeveel kip heb ik nog').name, 'kip');
  assert.equal(first('ik heb lasagne gemaakt voor 4 personen').servings, 4);
  assert.equal(first('wat raakt op').type, 'query_low');
  assert.equal(first('nog 3 eieren').type, 'set_quantity');
});

test('recipe requests become filters', () => {
  assert.equal(first('Give me a high-protein dinner').filters.highProtein, true);
  assert.equal(first('Find something cheap with chicken').filters.ingredient, 'chicken');
  assert.equal(first('Find something cheap with chicken').filters.cheap, true);
  assert.equal(first('I want something Italian').filters.cuisine, 'Italian');
  assert.equal(first('Make something with my remaining vegetables').filters.ingredient, 'vegetables');
  assert.equal(first('Find a meal that takes less than 20 minutes').filters.maxMinutes, 20);
});

test('multiple items and corrections', () => {
  const i = first('I bought milk, eggs and two onions');
  assert.deepEqual(i.items.map((x: any) => [x.name, x.amount]), [['milk', null], ['eggs', null], ['onions', 2]]);
  assert.deepEqual(first('no, 500 grams'), { type: 'correction', text: '500 grams' });
  assert.equal(first('undo').type, 'undo');
  assert.equal(first('I used some milk').items[0].vague, true);
});

test('Albert Heijn receipt', () => {
  const r = parseReceiptText(AH_RECEIPT);
  assert.equal(r.store, 'Albert Heijn');
  assert.equal(r.date, '2026-10-27');
  assert.equal(r.total, 20.57);
  assert.equal(r.deposit, 0.25);
  assert.deepEqual(r.warnings, []);
  const chicken = r.lines.find((l) => l.name.includes('KIPFILET'))!;
  assert.deepEqual([chicken.count, chicken.price, chicken.discount], [2, 12.98, 2]);
  assert.equal(r.lines.find((l) => l.name === 'BANANEN')!.weightKg, 0.846);
});

test('Jumbo receipt', () => {
  const r = parseReceiptText(JUMBO_RECEIPT);
  assert.equal(r.store, 'Jumbo');
  assert.equal(r.total, 7.01);
  assert.equal(r.lines.length, 4);
  assert.deepEqual(r.warnings, []);
});

test('Lidl receipt', () => {
  const r = parseReceiptText(LIDL_RECEIPT);
  assert.equal(r.store, 'Lidl');
  assert.equal(r.date, '2026-10-29');
  assert.equal(r.total, 13.56);
  const bananas = r.lines.find((l) => l.name === 'Bananen')!;
  assert.equal(bananas.weightKg, 0.712);
  assert.equal(r.lines.find((l) => l.name.startsWith('Kipfilet'))!.count, 2);
  assert.deepEqual(r.warnings, []);
});

test('AH receipt photographed on a table: unit price column, bag, split total', () => {
  const r = parseReceiptText(`ALBERT HEIJN 1237
AANTAL OMSCHRIJVING PRIJS BEDRAG
2 SOURCY 1,79 3,58
+STATIEGELD 0,30
1 TONIJNSALADE 1,55
: 1 ROOMK SWEETP 2,99
1 TURKS BROODJ 0,99
1 DRAAGTAS 0,89
6 SUBTOTAAL 10,30
JOUW VOORDEEL 0,00
waarvan
BONUS BOX 0,00
TOTAAL 10, 30
BETAALD MET:
PINNEN 10,30
Datum 06/11/2026 12:45`);
  assert.equal(r.store, 'Albert Heijn');
  assert.equal(r.date, '2026-11-06');
  assert.equal(r.total, 10.3);
  assert.deepEqual(r.lines.map((l) => [l.count, l.name, l.unitPrice, l.price]), [
    [2, 'SOURCY', 1.79, 3.58], [1, 'TONIJNSALADE', 1.55, 1.55], [1, 'ROOMK SWEETP', 2.99, 2.99], [1, 'TURKS BROODJ', 0.99, 0.99],
  ]);
  assert.equal(r.deposit, 0.3);
  assert.equal(r.extras, 0.89, 'the carrier bag counts towards the total but is not a product');
  assert.deepEqual(r.warnings, []);
});

test('a badly read receipt keeps its products and never turns payment details into products', () => {
  const r = parseReceiptText(`ALBERT HEIJN 1237
AANTAL OMSCHRIJVING PRIJS BEDRAG
2 SOURCY 1798
1 TONIJNSALADE 1,58
SG 1 ROOMK SWEETP DEE)
1 TURKS BROODJ 0,99
6 SUBTOTAAL 10,30
ee TOTAAL en 1 Ô . 30
# NN | 10,30
3 it | Kopie | | re 3 :`);
  assert.deepEqual(r.lines.map((l) => [l.count, l.name, l.price]), [[2, 'SOURCY', null], [1, 'TONIJNSALADE', 1.58], [1, 'ROOMK SWEETP', null], [1, 'TURKS BROODJ', 0.99]]);
  assert.equal(r.total, 10.3, 'the subtotal stands in for an unreadable total');
  assert.deepEqual(r.warnings, ['Some prices could not be read.']);
});

test('generic receipt and helpers', () => {
  const r = parseReceiptText('Corner shop\nOat drink 2,19\nApples 1,99\nTOTAL 4,18');
  assert.equal(r.lines.length, 2);
  assert.equal(cleanName('AH HALFVOLLE MELK 1L'), 'halfvolle melk');
  assert.deepEqual(parseSize('Spa rood 6x1,5L'), { qty: 9000, unit: 'ml' });
  assert.deepEqual(parseSize('Eieren 10 st'), { qty: 10, unit: 'pcs' });
});

test('unit conversion', () => {
  const milk = { unit: 'ml' as const, package_size: 1000 };
  const bread = { unit: 'g' as const, package_size: 800, piece_size: 35 };
  assert.equal(toBase(2, 'litres', milk).qty, 2000);
  assert.equal(toBase(2, 'pakken', milk).qty, 2000);
  assert.equal(toBase(2, 'slices', bread).qty, 70);
  assert.equal(toBase(1, 'eetlepel', milk).qty, 15);
  assert.equal(packagesFor(200, { unit: 'g', package_size: 500 }), 1);
  assert.equal(packagesFor(1001, { unit: 'g', package_size: 500 }), 3);
  assert.equal(formatQty(1500, 'ml'), '1.5 L');
  assert.equal(formatQty(1500, 'ml', { lang: 'nl' }), '1,5 L');
});
