// Recipes from the text of a photo or screenshot (read on the phone by Tesseract): title, servings, time,
// ingredients matched to products, and the method as separate steps.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, type TestApp } from './helpers.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});
const photo = (text: string, lang = 'nl') => app.api('POST', '/api/recipes/photo', { text, lang });

test('a recipe app screenshot: headings, screen clutter, checkboxes and steps wrapped over lines', async () => {
  const r = await photo(`9:41 ..ll 5G 87
< Terug
Pasta pesto met kip
4 personen   25 min
Ingrediënten
O 300 g penne
O 400 g kipfilet
O 2 el olijfolie
O 1 ui
O 2 tenen knoflook
200 g
cherrytomaten
O 90 g groene pesto
Bereiding
1. Kook de penne vol-
gens de verpakking.
2. Snijd de kip in blokjes en bak
8 minuten in de olie.
3. Snipper de ui en bak mee. Voeg de tomaten
en pesto toe en warm 2 minuten door.
Tip
Lekker met rucola.`);
  assert.equal(r.status, 200, JSON.stringify(r.body));
  const d = r.body;
  assert.equal(d.title, 'Pasta pesto met kip');
  assert.equal(d.servings, 4);
  assert.equal(d.prep_minutes + d.cook_minutes, 25);
  assert.deepEqual(d.ingredients.map((i: any) => i.line), ['300 g penne', '400 g kipfilet', '2 el olijfolie', '1 ui', '2 tenen knoflook', '200 g cherrytomaten', '90 g groene pesto']);
  assert.ok(d.ingredients.filter((i: any) => i.productId).length >= 5, 'most ingredients recognised');
  assert.equal(d.ingredients[4].productId, 'p_garlic', 'tenen are cloves');
  assert.deepEqual(d.steps.map((s: any) => s.text), [
    'Kook de penne volgens de verpakking.',
    'Snijd de kip in blokjes en bak 8 minuten in de olie.',
    'Snipper de ui en bak mee. Voeg de tomaten en pesto toe en warm 2 minuten door.',
  ]);
  assert.equal(d.steps[1].timerSeconds, 480);
  assert.equal(d.stepsGuessed, false);
});

test('a cookbook page without headings: amounts make ingredients, the paragraph becomes one step per sentence', async () => {
  const r = await photo(`Simple tomato soup
Serves 2

1 onion
2 tbsp olive oil
400 g chopped tomatoes
500 ml vegetable stock

Fry the onion in the oil for 5 minutes until soft. Add the tomatoes and the
stock and simmer for 15 minutes. Blend until smooth and season to taste.`, 'en');
  assert.equal(r.status, 200, JSON.stringify(r.body));
  const d = r.body;
  assert.equal(d.title, 'Simple tomato soup');
  assert.equal(d.servings, 2);
  assert.equal(d.ingredients.length, 4);
  assert.deepEqual(d.steps.map((s: any) => s.text), [
    'Fry the onion in the oil for 5 minutes until soft.',
    'Add the tomatoes and the stock and simmer for 15 minutes.',
    'Blend until smooth and season to taste.',
  ]);
  assert.deepEqual(d.steps.map((s: any) => s.timerSeconds), [300, 900, undefined]);
});

test('only an ingredient list: a plain method is written from the ingredients, and says so', async () => {
  const r = await photo(`Kip met rijst
Ingrediënten
300 g kipfilet
200 g rijst
1 paprika
1 tl currypoeder`);
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal(r.body.stepsGuessed, true);
  assert.deepEqual(r.body.ingredients.map((i: any) => i.productId).filter(Boolean).length, 4, 'currypoeder is curry powder');
  assert.ok(r.body.steps.length >= 3);
  assert.match(r.body.steps.map((s: any) => s.text).join(' '), /rijst/);
});

test('a photo without a recipe is refused with a reason', async () => {
  const r = await photo('Hallo allemaal!\nWat een mooie dag vandaag.');
  assert.equal(r.status, 422);
  assert.match(r.body.error?.message ?? r.body.message ?? JSON.stringify(r.body), /ingrediënten/i);
});
