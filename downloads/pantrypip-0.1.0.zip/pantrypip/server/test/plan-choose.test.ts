// Changing a planned recipe: a ranked menu with kinds to filter on, the shopping list following the
// change (also weeks ahead when you cook on few days), diets respected, and weeks that don't repeat.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, type TestApp } from './helpers.ts';
import { addDays, clock } from '../src/clock.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});
const planItems = async () => (await app.api('GET', '/api/shopping')).body.groups.flatMap((g: any) => g.items).filter((i: any) => i.reason === 'meal_plan').map((i: any) => i.name).sort();
const ingredientsOf = async (id: string) => (await app.api('GET', `/api/recipes/${id}`)).body.recipe;
const dinner = async (offset: number, recipeId: string) => (await app.api('POST', '/api/plan', { date: addDays(clock.today(), offset), meal: 'dinner', recipeId, servings: 2 })).body;
const options = async (slotId: string, q = '') => (await app.api('GET', `/api/plan/${slotId}/options?limit=10${q}`)).body;

test('the menu offers several recipes, best fit first, without the one already planned', async () => {
  const first = (await app.api('POST', '/api/plan/auto/preview', { days: 1 })).body.plan[0];
  const slot = await dinner(1, first.recipeId);
  const o = await options(slot.id);
  assert.ok(o.options.length >= 8, `a real choice, got ${o.options.length}`);
  assert.ok(!o.options.some((x: any) => x.recipeId === first.recipeId));
  assert.equal(new Set(o.options.map((x: any) => x.recipeId)).size, o.options.length, 'no duplicates');
  assert.ok(o.proteins.length >= 3 && o.cuisines.length >= 2, 'kinds to filter on');
  await app.api('DELETE', `/api/plan/${slot.id}`);
});

test('picking from the menu swaps the shopping list to the new recipe', async () => {
  const preview = (await app.api('POST', '/api/plan/auto/preview', { days: 1 })).body.plan[0];
  const slot = await dinner(2, preview.recipeId);
  const before = await planItems();
  const pick = (await options(slot.id, '&protein=fish')).options[0];
  assert.ok(pick, 'a fish recipe to pick');
  const r = await app.api('POST', `/api/plan/${slot.id}/choose`, { recipeId: pick.recipeId });
  assert.equal(r.status, 200);
  assert.equal(r.body.recipe_id, pick.recipeId);
  const after = await planItems();
  assert.notDeepEqual(after, before, 'the list changed');
  const recipe = await ingredientsOf(pick.recipeId);
  const fishItem = recipe.ingredients.find((i: any) => i.product?.category === 'fish' && !i.optional);
  if (fishItem) assert.ok(after.includes(fishItem.product.name), `${fishItem.product.name} is on the list`);
  await app.api('DELETE', `/api/plan/${slot.id}`);
  assert.deepEqual(await planItems(), [], 'and leaves nothing behind once removed');
});

test('cuisine and kind filters hold, for the menu and for Surprise me', async () => {
  const slot = await dinner(3, (await app.api('POST', '/api/plan/auto/preview', { days: 1 })).body.plan[0].recipeId);
  const all = await options(slot.id);
  const cuisine = all.cuisines[0];
  const only = await options(slot.id, `&cuisine=${encodeURIComponent(cuisine)}`);
  for (const o of only.options) assert.equal((await ingredientsOf(o.recipeId)).cuisine, cuisine);
  const swapped = await app.api('POST', `/api/plan/${slot.id}/swap?protein=fish`, {});
  assert.equal(swapped.status, 200);
  assert.equal((await ingredientsOf(swapped.body.recipeId)).protein, 'fish');
  await app.api('DELETE', `/api/plan/${slot.id}`);
});

test('with three cooking days the shopping list covers the weeks the planner shows', async () => {
  await app.api('PATCH', '/api/settings', { household: { planDays: [2, 4, 0] } });
  const day = addDays(clock.today(), 16);
  const preview = (await app.api('POST', '/api/plan/auto/preview', { start: day, days: 1, only: [day] })).body.plan[0];
  const slot = await dinner(16, preview.recipeId);
  assert.ok((await planItems()).length > 0, 'a meal 16 days ahead still puts its ingredients on the list');
  await app.api('DELETE', `/api/plan/${slot.id}`);
  await app.api('PATCH', '/api/settings', { household: { planDays: [0, 1, 2, 3, 4, 5, 6] } });
});

test('vegetarians are never offered meat, in the menu, Surprise me, search or the weekly plan', async () => {
  const d = (await app.api('GET', '/api/dietary')).body;
  await app.api('PUT', '/api/dietary', { people: d.people.map((p: any) => ({ ...p, diets: ['vegetarian'] })) });
  const preview = (await app.api('POST', '/api/plan/auto/preview', { days: 7 })).body;
  for (const day of preview.plan) assert.ok(['veg', 'plant', 'eggs'].includes((await ingredientsOf(day.recipeId)).protein), `${day.title} in the weekly plan`);
  const slot = await dinner(4, preview.plan[0].recipeId);
  const o = await options(slot.id);
  assert.ok(o.proteins.every((p: string) => ['veg', 'plant', 'eggs'].includes(p)), `kinds: ${o.proteins}`);
  for (const x of o.options) assert.ok(['veg', 'plant', 'eggs'].includes((await ingredientsOf(x.recipeId)).protein), x.title);
  assert.equal((await app.api('POST', `/api/plan/${slot.id}/swap?protein=chicken`, {})).status, 409, 'no chicken to surprise with');
  const found = (await app.api('GET', '/api/recipes?q=chicken&limit=50')).body;
  assert.ok(found.every((r: any) => !/chicken/i.test(r.title)), `search: ${found.map((r: any) => r.title).join(', ')}`);
  await app.api('DELETE', `/api/plan/${slot.id}`);
  await app.api('PUT', '/api/dietary', { people: d.people });
});

test('planning the next week brings mostly different dinners', async () => {
  const start = addDays(clock.today(), 30);
  const week1 = (await app.api('POST', '/api/plan/auto/preview', { start, days: 7 })).body.plan;
  await app.api('POST', '/api/plan/auto/apply', { days: week1.map((d: any) => ({ date: d.date, recipeId: d.recipeId })), servings: 2 });
  const week2 = (await app.api('POST', '/api/plan/auto/preview', { start: addDays(start, 7), days: 7 })).body.plan;
  const repeats = week2.filter((d: any) => week1.some((w: any) => w.recipeId === d.recipeId)).length;
  assert.ok(repeats <= 1, `${repeats} of 7 dinners repeat from the week before`);
});
