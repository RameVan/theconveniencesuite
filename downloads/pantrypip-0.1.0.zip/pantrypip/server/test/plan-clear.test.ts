// Clearing the week planner, and undoing it.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, type TestApp } from './helpers.ts';
import { clock, addDays } from '../src/clock.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});

const week = async (start: string) => (await app.api('GET', `/api/plan?start=${start}`)).body.days.flatMap((d: any) => d.slots);

test('clear removes planned meals in the week (locked too), keeps cooked ones and other weeks; undo restores exactly', async () => {
  const start = clock.today();
  const ids = app.db.all<{ id: string }>("SELECT id FROM recipes WHERE household_id IS NULL AND tags NOT LIKE '%breakfast%' ORDER BY id LIMIT 4").map((r) => r.id);
  const add = async (date: string, recipeId: string) => (await app.api('POST', '/api/plan', { date, meal: 'dinner', recipeId, servings: 3 })).body;
  const a = await add(start, ids[0]);
  const b = await add(addDays(start, 1), ids[1]);
  const c = await add(addDays(start, 2), ids[2]);
  const later = await add(addDays(start, 9), ids[3]);
  await app.api('PATCH', `/api/plan/${b.id}`, { locked: true });
  await app.api('POST', `/api/plan/${c.id}/cook`, {});

  const r = await app.api('POST', '/api/plan/clear', { start, days: 7 });
  assert.equal(r.status, 200);
  assert.equal(r.body.removed, 2, 'the planned and the locked meal go');
  const left = await week(start);
  assert.deepEqual(left.map((s: any) => s.id), [c.id], 'the cooked meal stays');
  assert.ok((await week(addDays(start, 7))).some((s: any) => s.id === later.id), 'next week is untouched');

  const u = await app.api('POST', '/api/plan/restore', { slots: r.body.slots });
  assert.equal(u.body.restored, 2);
  const back = await week(start);
  const restoredB = back.find((s: any) => s.id === b.id);
  assert.ok(back.some((s: any) => s.id === a.id) && restoredB, 'both meals are back with their ids');
  assert.equal(restoredB.locked, 1, 'still locked');
  assert.equal(restoredB.servings, 3, 'same number of people');
  // Undo twice does nothing extra.
  assert.equal((await app.api('POST', '/api/plan/restore', { slots: r.body.slots })).body.restored, 0);
  assert.equal((await week(start)).length, 3);
});

test('clearing an empty week is fine', async () => {
  const r = await app.api('POST', '/api/plan/clear', { start: addDays(clock.today(), 30), days: 7 });
  assert.equal(r.status, 200);
  assert.equal(r.body.removed, 0);
  assert.equal((await app.api('POST', '/api/plan/clear', { start: 'next week' })).status, 400);
});
