// Saved recipes, macros, ratings, the week auto-planner (FIFO) and the cooking path.
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, type TestApp } from './helpers.ts';
import { clock, addDays } from '../src/clock.ts';
import { draftFromHtml } from '../src/domain/recipe-import.ts';
import { streakOf } from '../src/domain/game.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
});
after(async () => {
  clock.set(null);
  await app.close();
});

describe('more recipes, several diets', () => {
  test('choosing two diets shows recipes that fit either', async () => {
    const vegan = (await app.api('GET', '/api/recipes?diet=vegan&limit=200')).body;
    const both = (await app.api('GET', '/api/recipes?diet=vegan,pescatarian&limit=200')).body;
    assert.ok(vegan.length >= 8, `enough vegan dinners (${vegan.length})`);
    assert.ok(both.length > vegan.length);
    assert.ok(both.every((r: any) => r.diet.includes('vegan') || r.diet.includes('pescatarian')));
  });
});

describe('my recipes: import, write, rate', () => {
  const page = `<html><head><script type="application/ld+json">{"@context":"https://schema.org","@graph":[{"@type":"WebPage"},{"@type":"Recipe","name":"Mum&#39;s chicken &amp; rice","recipeYield":["4","4 servings"],
    "prepTime":"PT10M","cookTime":"PT25M","recipeCuisine":"Spanish","image":{"url":"https://example.test/r.jpg"},
    "recipeIngredient":["2 tbsp olive oil","500 g chicken thighs","1 onion, finely chopped","300 g rice","1 stock cube","Salt and pepper to taste"],
    "recipeInstructions":[{"@type":"HowToSection","itemListElement":[{"@type":"HowToStep","text":"Brown the chicken in the oil for 8 minutes."},{"@type":"HowToStep","text":"Add onion, rice and stock and simmer for 20 minutes."}]}]}]}</script></head></html>`;

  test('a recipe page’s schema.org data becomes a draft with matched products', () => {
    const d = draftFromHtml(app.db, app.householdId, page, 'https://www.example.test/recipes/1');
    assert.equal(d.title, 'Mum’s chicken & rice');
    assert.equal(d.servings, 4);
    assert.equal(d.prep_minutes + d.cook_minutes, 35);
    assert.equal(d.source_name, 'example.test');
    assert.deepEqual(d.ingredients.map((i) => i.productId), ['p_olive_oil', 'p_chicken_thigh', 'p_onion', 'p_rice', 'p_stock_cube', 'p_pepper']);
    assert.equal(d.ingredients[0].quantity, 30, '2 tbsp = 30 ml');
    assert.equal(d.ingredients[5].optional, true, '"to taste" is optional');
    assert.equal(d.steps.length, 2);
    assert.equal(d.steps[1].timerSeconds, 1200);
  });

  test('a typed recipe is saved, gets macros (incl. frying fat), shows in My recipes and can be deleted', async () => {
    const draft = (await app.api('POST', '/api/recipes/draft', { title: 'Quick chicken', servings: 2, minutes: 15, ingredients: '400 g chicken breast\n200 g broccoli', steps: '1. Fry the chicken until golden.\n2. Add the broccoli.' })).body;
    assert.deepEqual(draft.ingredients.map((i: any) => i.productId), ['p_chicken_breast', 'p_broccoli']);
    const saved = (await app.api('POST', '/api/recipes', {
      title: draft.title, servings: draft.servings, cook_minutes: 15, steps: draft.steps,
      ingredients: draft.ingredients.map((i: any) => ({ name: i.name, productId: i.productId, quantity: i.quantity, unit: i.unit, display: i.line })),
    })).body;
    assert.equal(saved.assumedFat, 5, 'frying without listed fat counts ~1 tsp oil per serving');
    assert.ok(saved.nutritionPerServing.kcal > 200 && saved.nutritionPerServing.fat > 7);
    assert.ok(saved.health.score > 0);
    const mine = (await app.api('GET', '/api/recipes/mine')).body;
    assert.ok(mine.some((r: any) => r.id === saved.id));
    assert.equal((await app.api('DELETE', `/api/recipes/${saved.id}`)).status, 200);
    assert.ok(!(await app.api('GET', '/api/recipes/mine')).body.some((r: any) => r.id === saved.id));
    assert.equal((await app.api('DELETE', '/api/recipes/r_lentil_dal')).status, 404, 'built-in recipes can’t be deleted');
  });

  test('ratings and "how often" are remembered', async () => {
    await app.api('POST', '/api/recipes/r_lentil_dal/interaction', { rating: 5, priority: 2 });
    const r = (await app.api('GET', '/api/recipes/r_lentil_dal')).body;
    assert.equal(r.interaction.rating, 5);
    assert.equal(r.interaction.priority, 2);
    assert.ok((await app.api('GET', '/api/recipes/mine')).body.some((x: any) => x.id === 'r_lentil_dal' && x.rating === 5));
  });
});

describe('plan my week', () => {
  test('seven different dinners, no breakfasts, respects "never"', async () => {
    await app.api('POST', '/api/recipes/r_carbonara/interaction', { priority: -2 });
    const p = (await app.api('POST', '/api/plan/auto/preview', { start: clock.today(), days: 7, servings: 2 })).body;
    const ids = p.plan.map((d: any) => d.recipeId);
    assert.equal(ids.length, 7);
    assert.equal(new Set(ids).size, 7, 'no repeats');
    assert.ok(!ids.includes('r_carbonara'));
    assert.ok(!ids.includes('r_overnight_oats') && !ids.includes('r_pancakes'));
    const other = (await app.api('POST', '/api/plan/auto/preview', { start: clock.today(), days: 7, servings: 2, seed: 99 })).body;
    assert.notDeepEqual(other.plan.map((d: any) => d.recipeId), ids, 'shuffle gives another plan');
  });

  test('FIFO: food that expires first gets planned first', async () => {
    await app.api('POST', '/api/inventory/add', { productId: 'p_spinach', quantity: 400, expiresOn: addDays(clock.today(), 1) });
    await app.api('POST', '/api/inventory/add', { productId: 'p_chickpeas', quantity: 480 });
    const p = (await app.api('POST', '/api/plan/auto/preview', { start: clock.today(), days: 7, servings: 2, fifo: true })).body;
    const first = p.plan.slice(0, 2);
    assert.ok(first.some((d: any) => d.usesUp.includes('spinach')), JSON.stringify(first));
    assert.ok(p.summary.usesUp.includes('spinach'));
  });

  test('favourites and ratings tip the balance; applying fills the plan and the shopping list', async () => {
    await app.api('PUT', '/api/plan/auto/prefs', { favouriteFoods: ['p_salmon'] });
    const p = (await app.api('POST', '/api/plan/auto/preview', { start: clock.today(), days: 7, servings: 2 })).body;
    assert.ok(p.plan.some((d: any) => d.recipeId === 'r_lentil_dal'), 'a 5★ favourite is picked');
    assert.ok(p.plan.some((d: any) => /salmon/i.test(d.title)), 'favourite food is picked');
    const res = (await app.api('POST', '/api/plan/auto/apply', { days: p.plan.map((d: any) => ({ date: d.date, recipeId: d.recipeId })), servings: 2 })).body;
    assert.equal(res.added, 7);
    assert.ok(res.shoppingAdded > 0);
    const week = (await app.api('GET', `/api/plan?start=${clock.today()}`)).body;
    assert.equal(week.days.filter((d: any) => d.slots.some((s: any) => s.meal === 'dinner')).length, 7);
    // Re-planning keeps what's already there unless asked.
    const again = (await app.api('POST', '/api/plan/auto/preview', { start: clock.today(), days: 7 })).body;
    assert.ok(again.plan.every((d: any) => d.existing));
  });
});

describe('cooking path', () => {
  test('streaks forgive one rest day a week', () => {
    const t = '2026-11-10';
    const days = new Set(['2026-11-10', '2026-11-09', '2026-11-07', '2026-11-06']);
    assert.equal(streakOf(days, t).count, 4);
    assert.equal(streakOf(days, t).restDaysUsed, 1);
    assert.equal(streakOf(new Set(['2026-11-09', '2026-11-08']), t).count, 2, 'today still open');
    assert.equal(streakOf(new Set(['2026-11-07']), t).count, 0);
  });

  test('cooking earns XP (new recipe, balance, streak), quests and badges; undo takes it back', async () => {
    const start = new Date(clock.now());
    start.setUTCHours(18, 0, 0, 0);
    let reward: any = null;
    let batch = '';
    for (const [i, id] of ['r_lentil_dal', 'r_chicken_broccoli_stirfry', 'r_chili_sin_carne'].entries()) {
      clock.set(new Date(start.getTime() + i * 86_400_000));
      const r = (await app.api('POST', `/api/recipes/${id}/cook`, { servings: 2 })).body;
      reward = r.reward;
      batch = r.batchId;
    }
    assert.ok(reward.xp >= 30, JSON.stringify(reward));
    assert.ok(reward.parts.some((p: any) => p.key === 'new'));
    assert.ok(reward.parts.some((p: any) => p.key === 'streak'));
    assert.equal(reward.streak, 3);
    const g = (await app.api('GET', '/api/game')).body;
    assert.equal(g.streak.current, 3);
    assert.ok(g.achievements.find((a: any) => a.id === 'streak3').done);
    assert.ok(g.achievements.find((a: any) => a.id === 'first').done);
    assert.ok(g.level.n >= 2, `level ${g.level.n} with ${g.xp} XP`);
    assert.equal(g.path.length, 21);
    await app.api('POST', '/api/inventory/undo', { batchId: batch });
    const after = (await app.api('GET', '/api/game')).body;
    assert.ok(after.xp < g.xp);
    assert.equal(after.streak.current, 2);
  });
});
