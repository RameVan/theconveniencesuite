// Recipes from a sentence or from stock, after-cooking feedback, counted shares and the carb score.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, type TestApp } from './helpers.ts';
import { mealScore, DEFAULT_TARGETS } from '../src/domain/health.ts';
import { clock, addDays } from '../src/clock.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});
const recipe = async (id: string) => (await app.api('GET', `/api/recipes/${id}`)).body;

test('"Save this recipe: …" by voice structures and saves it, borrowing amounts and method from the library', async () => {
  const r = await app.say('Save this recipe: chicken fajitas with peppers, onion, rice and avocado');
  assert.match(r.reply, /Saved Chicken fajitas to My recipes/, r.reply);
  const id = r.data.items[0].id;
  const { recipe: rec, interaction } = await recipe(id);
  assert.equal(interaction.saved, 1);
  assert.deepEqual(rec.ingredients.map((i: any) => i.product_id).sort(), ['p_avocado', 'p_bell_pepper', 'p_chicken_breast', 'p_onion', 'p_rice'].sort());
  for (const i of rec.ingredients) assert.ok(i.quantity > 0, `${i.name} has an amount`);
  assert.ok(rec.steps.length >= 2, 'has a method');
  assert.ok(rec.nutritionPerServing.kcal > 200, 'and nutrition');
});

test('without ingredients the library recipe is saved; unknown ingredients are kept and reported', async () => {
  const a = await app.say('save recipe pasta puttanesca');
  assert.match(a.reply, /from the library/);
  assert.equal(a.data.items[0].id, 'r_pasta_puttanesca');
  const b = (await app.api('POST', '/api/recipes/quick', { text: 'Gran’s stew with beef strips, carrots, and grandma secret spice', servings: 4 })).body;
  assert.equal(b.existing, false);
  assert.deepEqual(b.unmatched, ['grandma secret spice']);
  assert.equal(b.recipe.servings, 4);
  assert.equal(b.recipe.ingredients.find((i: any) => i.product_id === 'p_beef_strips').quantity, 500, '125 g per serving');
  assert.equal((await app.api('POST', '/api/recipes/quick', { text: 'save recipe: zzqx' })).status, 422);
});

test('"make a recipe from what I have" uses the food at risk first and never more than is in stock', async () => {
  const empty = await app.say('make a recipe from what I have');
  assert.match(empty.reply, /enough in stock|Here's/);
  const soon = addDays(clock.today(), 1);
  await app.api('POST', '/api/inventory/add', { productId: 'p_chicken_thigh', quantity: 300, expiresOn: soon });
  await app.api('POST', '/api/inventory/add', { productId: 'p_spinach', quantity: 200, expiresOn: soon });
  await app.api('POST', '/api/inventory/add', { productId: 'p_bell_pepper', quantity: 2 });
  await app.api('POST', '/api/inventory/add', { productId: 'p_rice', quantity: 1000 });
  await app.api('POST', '/api/inventory/add', { productId: 'p_soy_sauce', quantity: 250 });
  const r = await app.say('make a recipe from what I have');
  assert.match(r.reply, /Here's Use-it-up/, r.reply);
  const { recipe: rec } = await recipe(r.data.items[0].id);
  const q = (id: string) => rec.ingredients.find((i: any) => i.product_id === id)?.quantity;
  assert.ok(q('p_chicken_thigh') > 0 && q('p_chicken_thigh') <= 300, 'chicken, within stock');
  assert.ok(q('p_spinach') > 0 && q('p_spinach') <= 200, 'spinach, within stock');
  assert.ok(rec.tags.includes('use-it-up'));
  assert.ok(rec.steps.length >= 3);
});

test('after-cooking answers are stored and steer the planner', async () => {
  await app.api('POST', '/api/recipes/r_lentil_dal/interaction', { ease: 1, again: false });
  const { interaction } = await recipe('r_lentil_dal');
  assert.equal(interaction.ease, 1);
  assert.equal(interaction.again, 0);
  const plans = await Promise.all([1, 2, 3, 4].map((seed) => app.api('POST', '/api/plan/auto/preview', { start: '2030-02-04', days: 14, seed })));
  for (const p of plans) for (const d of p.body.plan) if (d.recipeId === 'r_lentil_dal') assert.ok(d.why.some((w: any) => w.factor === 'not again'), 'held back when planned anyway');
  assert.equal((await app.api('POST', '/api/recipes/r_lentil_dal/interaction', { ease: 5 })).status, 400);
});

test('part of a frying fat or marinade can be counted; the default counts all of it', async () => {
  const id = 'r_chicken_satay';
  const before = (await recipe(id)).recipe;
  const oil = before.nutritionAudit.find((l: any) => l.productId === 'p_sunflower_oil');
  assert.equal(oil.retention, 1);
  assert.equal(oil.adjustable, true);
  const r = (await app.api('PUT', `/api/recipes/${id}/retention`, { position: oil.position, retention: 0.5 })).body;
  const after = r.nutritionAudit.find((l: any) => l.productId === 'p_sunflower_oil');
  assert.equal(after.retention, 0.5);
  assert.ok(Math.abs(after.contribution.kcal - oil.contribution.kcal / 2) < 1);
  assert.ok(r.nutritionTotal.kcal < before.nutritionTotal.kcal);
  const chicken = before.nutritionAudit.find((l: any) => l.productId === 'p_chicken_thigh');
  assert.equal((await app.api('PUT', `/api/recipes/${id}/retention`, { position: chicken.position, retention: 0.5 })).status, 422, 'only fats and marinades');
  await app.api('PUT', `/api/recipes/${id}/retention`, { position: oil.position, retention: null });
  assert.equal((await recipe(id)).recipe.nutritionTotal.kcal, before.nutritionTotal.kcal, 'reset counts all of it again');
});

test('the balance score weighs carbohydrate share, with a low-carb range when someone needs it', () => {
  const meal = (carbs: number) => mealScore({ kcal: 700, protein: 35, carbs, fat: 25, sugars: 8, satFat: 6, fibre: 10, salt: 1.5 }, 200, 3);
  const parts = meal(80).parts;
  assert.equal(parts.reduce((s, p) => s + p.max, 0), 100, 'weights add up to 100');
  const carbs = (s: ReturnType<typeof meal>) => s.parts.find((p) => p.key === 'carbs')!.points;
  assert.equal(carbs(meal(80)), 10, '46 % of energy is in range');
  assert.ok(carbs(meal(20)) < 10, 'very low carb loses points by default');
  const lowCarb = mealScore({ kcal: 700, protein: 35, carbs: 20, fat: 25, sugars: 4, satFat: 6, fibre: 10, salt: 1.5 }, 200, 3, { ...DEFAULT_TARGETS, carbMinPct: 0, carbMaxPct: 26 });
  assert.equal(lowCarb.parts.find((p) => p.key === 'carbs')!.points, 10, 'but is right for a low-carb household');
});

test('your own recipes can be edited; built-in ones are copied first', async () => {
  assert.equal((await app.api('PUT', '/api/recipes/r_hutspot', { title: 'x', servings: 2, steps: [{ text: 'a' }], ingredients: [{ name: 'onion' }] })).status, 403);
  const copy = (await app.api('POST', '/api/recipes/r_hutspot/copy', {})).body;
  assert.ok(copy.household_id, 'the copy is yours');
  assert.equal(copy.ingredients.length, (await recipe('r_hutspot')).recipe.ingredients.length);
  const r = await app.api('PUT', `/api/recipes/${copy.id}`, {
    title: 'My hutspot', servings: 3, prep_minutes: 5, cook_minutes: 25, steps: [{ text: 'Boil.' }, { text: 'Mash.' }],
    ingredients: [{ name: 'Potatoes', productId: 'p_potatoes', quantity: 900, display: '900 g potatoes' }, { name: 'carrots', quantity: 400, display: '400 g carrots' }, { name: 'mystery herb', display: 'a pinch of mystery herb' }],
  });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal(r.body.title, 'My hutspot');
  assert.equal(r.body.servings, 3);
  assert.deepEqual(r.body.ingredients.map((i: any) => [i.product_id, i.quantity]), [['p_potatoes', 900], ['p_carrots', 400], [null, null]]);
  assert.equal(r.body.steps.length, 2);
});

test('foods in the title count as ingredients, including the starch', async () => {
  const r = (await app.api('POST', '/api/recipes/quick', { text: 'Salmon pasta with spinach, cream, garlic and lemon' })).body;
  const ids = r.recipe.ingredients.map((i: any) => i.product_id);
  assert.ok(ids.includes('p_salmon') && ids.includes('p_pasta'), ids.join(','));
});
