// The built-in recipe library and bulk link import support.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, type TestApp } from './helpers.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});

test('the library has every built-in recipe, all ingredients linked to products', () => {
  const n = app.db.get<{ n: number }>("SELECT COUNT(*) n FROM recipes WHERE origin = 'builtin'")!.n;
  assert.ok(n >= 190, `expected about 199 built-ins, got ${n}`);
  const unlinked = app.db.get<{ n: number }>("SELECT COUNT(*) n FROM recipe_ingredients ri JOIN recipes r ON r.id = ri.recipe_id WHERE r.origin = 'builtin' AND ri.product_id IS NULL")!.n;
  assert.equal(unlinked, 0);
});

test('new recipes get diets from their ingredients', async () => {
  const r = (await app.api('GET', '/api/recipes/r_chana_masala')).body.recipe;
  assert.ok(r.diet.includes('vegan'), `chana masala is vegan: ${r.diet}`);
  const s = (await app.api('GET', '/api/recipes/r_boerenkool_stamppot')).body.recipe;
  assert.ok(!s.diet.includes('vegetarian'));
});

test('the week planner leaves out breakfasts, snacks, desserts, baking and sandwiches', async () => {
  const ids = new Set<string>();
  for (const seed of [1, 2, 3, 4, 5]) {
    const r = await app.api('POST', '/api/plan/auto/preview', { start: '2030-01-07', days: 14, seed });
    assert.equal(r.status, 200);
    for (const d of r.body.plan) if (d.recipeId) ids.add(d.recipeId);
  }
  assert.ok(ids.size > 10, `a varied plan (${ids.size} different dinners)`);
  for (const id of ids) {
    const rec = (await app.api('GET', `/api/recipes/${id}`)).body.recipe;
    for (const t of ['breakfast', 'snack', 'dessert', 'baking', 'sandwich']) assert.ok(!rec.tags.includes(t), `${rec.title} (${t}) was planned as a dinner`);
  }
});

test('imported links are listed so a bulk import can skip them', async () => {
  const before = (await app.api('GET', '/api/recipes/imported')).body.urls;
  assert.ok(Array.isArray(before));
  await app.api('POST', '/api/recipes', {
    title: 'Imported soup', servings: 2, prep_minutes: 5, cook_minutes: 10, source_url: 'https://example.test/soup', source_name: 'example.test',
    steps: [{ text: 'Cook.' }], ingredients: [{ name: 'Onion', quantity: 1, unit: 'pcs', display: '1 onion' }],
  });
  const after = (await app.api('GET', '/api/recipes/imported')).body.urls;
  assert.ok(after.includes('https://example.test/soup'));
});

test('imported ingredient lines keep products whose names include a prep word', async () => {
  const r = (await app.api('POST', '/api/recipes/draft', { title: 'Soup', ingredients: '800 g chopped tomatoes\n1 onion, finely chopped\n2 garlic cloves, crushed\n200 g diced tomatoes' })).body;
  const ids = r.ingredients.map((i: any) => [i.productId, i.quantity]);
  assert.deepEqual(ids[0], ['p_canned_tomatoes', 800], 'chopped tomatoes are the tin');
  assert.equal(ids[1][0], 'p_onion');
  assert.equal(ids[2][0], 'p_garlic');
  assert.ok(ids[3][0], 'diced tomatoes still match a product');
});

test('the recipe cache is reused, refreshed after any recipe or product write, and read-only', async () => {
  const { listRecipes } = await import('../src/domain/recipes.ts');
  const a = listRecipes(app.db, app.householdId);
  assert.equal(listRecipes(app.db, app.householdId), a, 'same list while nothing changed');
  assert.throws(() => { (a[0] as any).title = 'x'; }, TypeError, 'cached recipes are frozen');
  assert.throws(() => { (a as any).push({}); }, TypeError);
  // A write anywhere (here: a product price through plain SQL) refreshes it.
  const before = a.find((r) => r.id === 'r_hutspot')!.costPerServing;
  app.db.run('UPDATE products SET price = price * 2 WHERE id = ?', 'p_potatoes');
  const b = listRecipes(app.db, app.householdId);
  assert.notEqual(b, a);
  assert.ok(b.find((r) => r.id === 'r_hutspot')!.costPerServing! > before!, 'new price is used');
  app.db.run('UPDATE products SET price = price / 2 WHERE id = ?', 'p_potatoes');
  const created = (await app.api('POST', '/api/recipes', { title: 'Cache check soup', servings: 2, steps: [{ text: 'Cook.' }], ingredients: [{ name: 'onion', quantity: 1 }] })).body;
  assert.ok(listRecipes(app.db, app.householdId).some((r) => r.id === created.id), 'new recipes show up straight away');
});
