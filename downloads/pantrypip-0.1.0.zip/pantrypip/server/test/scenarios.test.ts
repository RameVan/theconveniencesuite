// The six end-to-end journeys from the brief, each driven over HTTP on a fresh household.
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, stock, setUsualTypes, type TestApp } from './helpers.ts';
import { clock, addDays } from '../src/clock.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
  setUsualTypes(app);
});
after(async () => {
  clock.set(null);
  await app.close();
});

const lot = (productId: string) => app.db.get<any>("SELECT * FROM inventory_lots WHERE household_id = ? AND product_id = ? AND status = 'active' ORDER BY created_at LIMIT 1", app.householdId, productId);

describe('Scenario 1: groceries by voice', () => {
  test('add a whole haul, use half, open, adjust, throw away, undo', async () => {
    const r = await app.say('I bought two packs of chicken, a bag of spinach, six eggs and some milk');
    assert.equal(r.actions.filter((a: any) => a.kind === 'added').length, 4);
    assert.equal(stock(app.db, app.householdId, 'p_chicken_breast'), 1000);
    assert.equal(stock(app.db, app.householdId, 'p_eggs'), 6);

    await app.say('I used half the chicken');
    assert.equal(stock(app.db, app.householdId, 'p_chicken_breast'), 500, 'half of what is there, not half a fillet');

    const before = lot('p_milk').expires_on;
    const o = await app.say('I opened the milk');
    assert.match(o.reply, /Opened/);
    assert.ok(lot('p_milk').opened_at);
    assert.ok(lot('p_milk').expires_on <= before, 'opening shortens the shelf life');
    await app.api('POST', '/api/assistant/undo', { batchId: o.batchId });
    assert.equal(lot('p_milk').opened_at, null, 'undo restores unopened');
    assert.equal(lot('p_milk').expires_on, before);

    await app.say('I only have 4 eggs left');
    assert.equal(stock(app.db, app.householdId, 'p_eggs'), 4);
    const d = await app.say('I threw away the spinach, it went off');
    assert.equal(stock(app.db, app.householdId, 'p_spinach'), 0);
    assert.doesNotMatch(d.reply, /couldn't find/i);
  });
});

describe('Scenario 2: plan the week', () => {
  test('seven dinners; strong FIFO uses what spoils first; locked meals survive regenerating; swaps are learned', async () => {
    await app.api('POST', '/api/inventory/add', { productId: 'p_spinach', quantity: 400, expiresOn: addDays(clock.today(), 1) });
    await app.api('POST', '/api/inventory/add', { productId: 'p_rice', quantity: 2000 });
    const strong = (await app.api('POST', '/api/plan/auto/preview', { days: 7, servings: 2, fifo: 'strong' })).body;
    assert.equal(strong.plan.length, 7);
    assert.ok(strong.plan[0].usesUp.includes('spinach') || strong.plan[1].usesUp.includes('spinach'), JSON.stringify(strong.plan.slice(0, 2).map((d: any) => d.title)));
    assert.ok(strong.plan[0].why.length > 0, 'every pick explains itself');
    const off = (await app.api('POST', '/api/plan/auto/preview', { days: 7, servings: 2, fifo: 'off' })).body;
    assert.ok(off.plan.every((d: any) => !d.why.some((w: any) => w.factor.startsWith('use first'))));

    await app.api('POST', '/api/plan/auto/apply', { days: strong.plan.map((d: any) => ({ date: d.date, recipeId: d.recipeId })), servings: 2 });
    const week = (await app.api('GET', `/api/plan?start=${clock.today()}`)).body;
    const tomorrow = week.days[1].slots.find((s: any) => s.meal === 'dinner');
    await app.api('PATCH', `/api/plan/${tomorrow.id}`, { locked: true });
    const redo = (await app.api('POST', '/api/plan/auto/preview', { days: 7, servings: 2, replace: true, seed: 42 })).body;
    const t2 = redo.plan.find((d: any) => d.date === tomorrow.date);
    assert.equal(t2.recipeId, tomorrow.recipe_id);
    assert.ok(t2.locked && t2.existing, 'locked meal kept');
    assert.ok(redo.plan.some((d: any) => !d.existing), 'the rest is regenerated');

    const day3 = week.days[2].slots.find((s: any) => s.meal === 'dinner');
    const swapped = (await app.api('POST', `/api/plan/${day3.id}/swap`)).body;
    assert.notEqual(swapped.recipeId, day3.recipe_id);
    const inter = app.db.get<any>('SELECT swapped_count FROM recipe_interactions WHERE household_id = ? AND recipe_id = ?', app.householdId, day3.recipe_id);
    assert.equal(inter.swapped_count, 1, 'the swap is remembered for next time');
  });
});

describe('Scenario 3: shopping', () => {
  test('the plan becomes one consolidated list of what is missing, and checking it off restocks', async () => {
    const list = (await app.api('GET', '/api/shopping')).body;
    const items = list.groups.flatMap((g: any) => g.items);
    const ids = items.filter((i: any) => i.product_id).map((i: any) => i.product_id);
    assert.equal(new Set(ids).size, ids.length, 'one line per product');
    assert.ok(!ids.includes('p_rice'), '2 kg rice in stock: not on the list');
    assert.ok(items.some((i: any) => i.reason === 'meal_plan'));
    for (const i of items) await app.api('PATCH', `/api/shopping/${i.id}`, { checked: true });
    const target = items.find((i: any) => i.product_id)!;
    const before = stock(app.db, app.householdId, target.product_id);
    await app.api('POST', '/api/shopping/complete', {});
    assert.ok(stock(app.db, app.householdId, target.product_id) > before, 'bought items are in stock');
  });
});

describe('Scenario 4: cooking', () => {
  test('cooking a planned dinner deducts the ingredients, marks it cooked and rewards it', async () => {
    const week = (await app.api('GET', `/api/plan?start=${clock.today()}`)).body;
    const slot = week.days[0].slots.find((s: any) => s.meal === 'dinner' && s.status === 'planned');
    const recipe = (await app.api('GET', `/api/recipes/${slot.recipe_id}?servings=${slot.servings}`)).body;
    const ing = recipe.recipe.ingredients.find((i: any) => !i.optional && i.product_id && i.quantity);
    const before = stock(app.db, app.householdId, ing.product_id);
    const r = (await app.api('POST', `/api/plan/${slot.id}/cook`, {})).body;
    const used = (ing.quantity * slot.servings) / recipe.recipe.servings;
    assert.ok(Math.abs(stock(app.db, app.householdId, ing.product_id) - Math.max(0, before - used)) < 0.01);
    assert.ok(r.reward.xp > 0);
    assert.ok(r.reward.parts.some((p: any) => p.key === 'planned'));
    const after = (await app.api('GET', `/api/plan?start=${clock.today()}`)).body;
    assert.equal(after.days[0].slots.find((s: any) => s.id === slot.id).status, 'cooked');
    assert.deepEqual((await app.api('GET', '/api/inventory/verify')).body.mismatches, [], 'ledger and stock agree');
  });
});

describe('Scenario 5: nutrition', () => {
  test('every ingredient counts, including oil, with density conversions and a traceable audit', async () => {
    const draft = (await app.api('POST', '/api/recipes/draft', { title: 'Oil check', servings: 2, ingredients: '2 tbsp olive oil\n1 cup flour\n1 tbsp honey\n200 g chicken breast\nparsley to serve', steps: 'Mix and bake.' })).body;
    const saved = (await app.api('POST', '/api/recipes', {
      title: draft.title, servings: 2, steps: draft.steps,
      ingredients: draft.ingredients.map((i: any) => ({ name: i.name, productId: i.productId, quantity: i.quantity, unit: i.unit, display: i.line, optional: i.optional })),
    })).body;
    const line = (pid: string) => saved.nutritionAudit.find((l: any) => l.productId === pid);
    assert.ok(Math.abs(line('p_olive_oil').contribution.kcal - 247) < 3, '2 tbsp olive oil ≈ 247 kcal (15 ml ≈ 124)');
    assert.ok(Math.abs(line('p_flour').grams - 132) < 1, '1 cup flour ≈ 132 g via density');
    assert.ok(Math.abs(line('p_honey').grams - 21.3) < 0.5, '1 tbsp honey ≈ 21 g via density');
    assert.equal(line('p_parsley').status, 'optional');
    const sum = saved.nutritionAudit.filter((l: any) => ['counted', 'assumed'].includes(l.status)).reduce((s: number, l: any) => s + l.contribution.kcal, 0);
    assert.ok(Math.abs(sum - saved.nutritionTotal.kcal) < 1, 'total = sum of counted lines');
    assert.ok(Math.abs(saved.nutritionPerServing.kcal - saved.nutritionTotal.kcal / 2) < 1);
    for (const k of ['kcal', 'protein', 'carbs', 'sugars', 'fat', 'satFat', 'fibre', 'salt']) assert.equal(typeof saved.nutritionPerServing[k], 'number', k);

    // Frying without a listed fat still counts oil.
    const fry = (await app.api('POST', '/api/recipes', { title: 'Fried eggs', servings: 1, steps: [{ text: 'Fry the eggs.' }], ingredients: [{ name: 'eggs', productId: 'p_eggs', quantity: 2 }] })).body;
    assert.ok(fry.nutritionAudit.some((l: any) => l.status === 'assumed' && l.productId === 'p_olive_oil'));
  });

  test('the balance score rewards ranges, not eating less', async () => {
    const { mealScore } = await import('../src/domain/health.ts');
    const base = { kcal: 700, protein: 30, carbs: 80, fat: 25, sugars: 10, satFat: 6, fibre: 10, salt: 1.5 };
    const good = mealScore(base, 200, 3).score;
    const tiny = mealScore({ ...base, kcal: 250, protein: 10, carbs: 30, fat: 8, fibre: 3 }, 60, 1).score;
    const huge = mealScore({ ...base, kcal: 1400, fat: 60, satFat: 25, salt: 4 }, 200, 3).score;
    assert.ok(good >= 85, `balanced ${good}`);
    assert.ok(tiny < good && huge < good, `too little ${tiny} and too much ${huge} both score lower`);
  });
});

describe('Scenario 6: progression', () => {
  test('cooking, balance and rescued food earn XP; streaks, challenges and configurable rules work', async () => {
    const g0 = (await app.api('GET', '/api/game')).body;
    assert.equal(g0.path.length, 21);
    // Earlier scenarios already cooked and moved along the journey, so this household isn't a beginner any more.
    assert.ok(g0.ranks[0].name === 'Kitchen Beginner' && g0.level.rank >= 0);
    await app.api('POST', '/api/game/challenge', { id: 'homechef' });

    await app.api('POST', '/api/inventory/add', { productId: 'p_lentils', quantity: 500, expiresOn: addDays(clock.today(), 1) });
    const start = new Date(clock.now());
    start.setUTCHours(19, 0, 0, 0);
    let last: any;
    for (const [i, id] of ['r_lentil_dal', 'r_turkish_lentil_soup', 'r_chickpea_spinach_curry'].entries()) {
      clock.set(new Date(start.getTime() + (i + 1) * 86_400_000));
      last = (await app.api('POST', `/api/recipes/${id}/cook`, { servings: 2 })).body;
      if (i === 0) assert.ok(last.reward.parts.some((p: any) => p.key === 'rescued'), 'lentils were about to expire');
    }
    const g = (await app.api('GET', '/api/game')).body;
    assert.ok(g.streaks.cooking.current >= 3);
    assert.ok(g.streaks.exploration.current >= 1);
    assert.equal(typeof g.nutrition.today, 'number');
    assert.ok(g.challenge.current.progress >= 3);
    assert.ok(g.xp > g0.xp);

    // XP per action is configurable.
    await app.api('PUT', '/api/game/settings', { xpRules: { newRecipe: 0 } });
    const g2 = (await app.api('GET', '/api/game')).body;
    assert.ok(g2.xp < g.xp);
    await app.api('PUT', '/api/game/settings', { xpRules: {} });

    // Cosmetic rewards unlock by rank.
    assert.equal((await app.api('PUT', '/api/game/settings', { accent: 'gold' })).status, 403);
    assert.equal((await app.api('PUT', '/api/game/settings', { accent: 'herb' })).status, 200);

    // Waste breaks the low-waste streak for this week; undoing it restores.
    const d = await app.say('I threw away 2 eggs, they went bad');
    await app.say('I threw away the chicken, it went off');
    const g3 = (await app.api('GET', '/api/game')).body;
    assert.ok(g3.streaks.lowWaste.current <= g.streaks.lowWaste.current);
    void d;
  });

  test('learned preferences can be switched off', async () => {
    const insights = (await app.api('GET', '/api/insights/learned')).body;
    assert.ok(Array.isArray(insights));
    if (insights.length) {
      await app.api('POST', `/api/insights/learned/${encodeURIComponent(insights[0].id)}`, { active: false });
      const again = (await app.api('GET', '/api/insights/learned')).body;
      assert.equal(again.find((i: any) => i.id === insights[0].id).active, false);
    }
  });
});
