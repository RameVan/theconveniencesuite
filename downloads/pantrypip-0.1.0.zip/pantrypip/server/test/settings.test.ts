// Settings persistence: one source of truth, key-level patches, validation both ways, migrations,
// concurrency, and the same settings after logging out, on another device and for a second person.
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, type TestApp } from './helpers.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});

const get = async () => (await app.api('GET', '/api/settings')).body;
const patch = (body: unknown) => app.api('PATCH', '/api/settings', body);
const raw = (key: string, value: string, user = '') => app.db.run('INSERT INTO preferences (household_id, user_id, key, value) VALUES (?, ?, ?, ?) ON CONFLICT(household_id, user_id, key) DO UPDATE SET value = excluded.value', app.householdId, user, key, value);

/** A second session for the same account (another phone, or after logging out and in again). */
async function newSession(email: string, password: string) {
  let cookie = '';
  const api = async (method: string, path: string, body?: unknown) => {
    const res = await fetch(app.url + path, { method, headers: { 'content-type': 'application/json', cookie }, body: body === undefined ? undefined : JSON.stringify(body) });
    const set = res.headers.get('set-cookie');
    if (set) cookie = set.split(';')[0];
    const text = await res.text();
    return { status: res.status, body: text ? JSON.parse(text) : null };
  };
  const r = await api('POST', '/api/auth/login', { email, password });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  return api;
}

describe('Settings: one source of truth', () => {
  test('defaults for everything, without writing anything', async () => {
    const s = await get();
    assert.equal(s.household.autoPlanFifo, 'balanced');
    assert.deepEqual(s.household.planDays, [0, 1, 2, 3, 4, 5, 6]);
    assert.equal(s.household.notifications.frequency, 'all');
    assert.equal(s.me.appearance.style, 'larder');
    assert.equal(s.me.startPage, 'home');
    assert.equal(app.db.get<{ n: number }>('SELECT COUNT(*) n FROM preferences WHERE household_id = ?', app.householdId)!.n, 0, 'reading never stores defaults');
  });

  test('a patch changes only what it names; objects merge field by field', async () => {
    await patch({ household: { maxWeeknightMinutes: 30, notifications: { prep: true } } });
    await patch({ household: { variety: 'high', notifications: { frequency: 'daily' } } });
    const s = await get();
    assert.equal(s.household.maxWeeknightMinutes, 30, 'earlier change kept');
    assert.equal(s.household.variety, 'high');
    assert.equal(s.household.notifications.prep, true, 'earlier field kept');
    assert.equal(s.household.notifications.frequency, 'daily');
    assert.equal(s.household.notifications.expiry, true, 'default field kept');
    assert.ok(s.rev >= 2, 'revision counts up');
  });

  test('invalid patches are rejected as a whole and change nothing', async () => {
    const before = await get();
    const r = await patch({ household: { variety: 'extreme', householdSize: 3 } });
    assert.equal(r.status, 422);
    assert.ok(r.body.error.details.some((d: any) => d.path.includes('variety')));
    assert.equal((await patch({ household: { notASetting: 1 } })).status, 422);
    assert.equal((await patch({ me: { appearance: { style: 'neon' } } })).status, 422);
    const after = await get();
    assert.deepEqual(after.household, before.household);
    assert.equal(after.rev, before.rev);
  });

  test('stored values are validated on read: old shapes migrate, broken values fall back without losing the rest', async () => {
    raw('autoPlanFifo', 'true'); // an old boolean
    raw('budgetPerServing', '"cheap"'); // not a number
    raw('notifications', JSON.stringify({ prep: true, frequency: 'hourly', prepTime: '18:30' })); // one bad field
    raw('planDays', 'not json');
    const s = await get();
    assert.equal(s.household.autoPlanFifo, 'balanced');
    assert.equal(s.household.budgetPerServing, null);
    assert.equal(s.household.notifications.prep, true);
    assert.equal(s.household.notifications.prepTime, '18:30');
    assert.equal(s.household.notifications.frequency, 'all', 'only the bad field falls back');
    assert.deepEqual(s.household.planDays, [0, 1, 2, 3, 4, 5, 6]);
    // The rest of the server reads the same keys and gets usable values.
    const plan = (await app.api('POST', '/api/plan/auto/preview', { days: 3, servings: 2 })).body;
    assert.equal(plan.fifo, 'balanced');
  });

  test('concurrent saves of different settings all land', async () => {
    const changes = [{ variety: 'low' }, { overlap: 'high' }, { ratingWeight: 'high' }, { planningDay: 3 }, { newPerWeek: 2 }, { budgetPerServing: 4 }, { maxDifficulty: 'medium' }, { scoringSensitivity: 'gentle' }];
    const results = await Promise.all(changes.map((c) => patch({ household: c })));
    assert.ok(results.every((r) => r.status === 200));
    const s = await get();
    for (const c of changes) for (const [k, v] of Object.entries(c)) assert.deepEqual(s.household[k], v, k);
  });

  test('the old endpoints and the new one agree', async () => {
    await app.api('PUT', '/api/preferences', { cuisines: ['Thai'] });
    assert.deepEqual((await get()).household.cuisines, ['Thai']);
    await patch({ household: { cuisines: ['Thai', 'Indian'] } });
    assert.deepEqual((await app.api('GET', '/api/preferences')).body.cuisines, ['Thai', 'Indian']);
    await patch({ household: { cookCheckin: { time: '19:15' } } });
    assert.equal((await app.api('GET', '/api/checkins')).body.settings.time, '19:15');
    await patch({ household: { nutritionTargets: { fibre: 35 } } });
    assert.equal((await app.api('GET', '/api/game')).body.targets.fibre, 35);
  });
});

describe('Settings follow you', () => {
  test('logging out and in, and another device, see the same settings', async () => {
    const email = `p${Date.now()}@larder.test`;
    const password = 'persist-password-1';
    // A fresh account so the password is known.
    const reg = await fetch(app.url + '/api/auth/register', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email, password, name: 'Pat' }) });
    assert.equal(reg.status, 201);
    const phone = await newSession(email, password);
    assert.equal((await phone('PATCH', '/api/settings', { me: { appearance: { style: 'herb', theme: 'dark' }, language: 'nl', startPage: 'groceries' }, household: { autoPlanFifo: 'strong' } })).status, 200);
    await phone('POST', '/api/auth/logout', {});
    assert.equal((await phone('GET', '/api/settings')).status, 401);
    const again = await newSession(email, password);
    const s = (await again('GET', '/api/settings')).body;
    assert.equal(s.me.appearance.style, 'herb');
    assert.equal(s.me.appearance.theme, 'dark');
    assert.equal(s.me.appearance.showMoney, true, 'untouched fields keep their default');
    assert.equal(s.me.language, 'nl');
    assert.equal(s.me.startPage, 'groceries');
    assert.equal(s.household.autoPlanFifo, 'strong');
    const tablet = await newSession(email, password);
    assert.equal((await tablet('GET', '/api/settings')).body.me.appearance.style, 'herb', 'a second device sees it too');
  });

  test('personal settings are personal; household settings are shared', async () => {
    const me = (await app.api('GET', '/api/me')).body;
    const email = `q${Date.now()}@larder.test`;
    const password = 'second-person-pass';
    const reg = await fetch(app.url + '/api/auth/register', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email, password, name: 'Sam', inviteCode: me.household.invite_code }) });
    assert.equal(reg.status, 201);
    const sam = await newSession(email, password);
    await patch({ me: { appearance: { style: 'night' } }, household: { householdSize: 4 } });
    const theirs = (await sam('GET', '/api/settings')).body;
    assert.equal(theirs.me.appearance.style, 'larder', 'my style is mine');
    assert.equal(theirs.household.householdSize, 4, 'household size is shared');
  });

  test('language you pick also sets the reminder language', async () => {
    await patch({ me: { language: 'nl' } });
    assert.equal(app.db.get<{ value: string }>("SELECT value FROM preferences WHERE household_id = ? AND user_id = '' AND key = 'language'", app.householdId)!.value, '"nl"');
    await patch({ me: { language: 'auto' } });
  });
});
