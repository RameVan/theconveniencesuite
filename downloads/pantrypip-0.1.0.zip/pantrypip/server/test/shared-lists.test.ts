// Shared shopping lists between friends in different households: invite, live edits, members only, and
// what you buy goes into your own stock only.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, stock, type TestApp } from './helpers.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});

/** Another person on the same server, with their own cookie and household. */
async function person(name: string) {
  let cookie = '';
  const api = async (method: string, path: string, body?: unknown) => {
    const res = await fetch(app.url + path, { method, headers: { 'content-type': 'application/json', cookie }, body: body === undefined ? undefined : JSON.stringify(body) });
    const set = res.headers.get('set-cookie');
    if (set) cookie = set.split(';')[0];
    const text = await res.text();
    return { status: res.status, body: text ? JSON.parse(text) : null } as { status: number; body: any };
  };
  const reg = await api('POST', '/api/auth/register', { email: `${name.toLowerCase()}${Date.now()}${Math.random().toString(36).slice(2, 6)}@larder.test`, password: 'test-password-123', name });
  assert.equal(reg.status, 201);
  const me = (await api('GET', '/api/me')).body;
  /** Listen on the live stream until a change with this scope arrives (or time out). */
  const nextChange = async (scope: string, ms = 2000) => {
    const ctrl = new AbortController();
    const res = await fetch(app.url + '/api/stream', { headers: { cookie }, signal: ctrl.signal });
    const reader = res.body!.getReader();
    const dec = new TextDecoder();
    let buf = '';
    const timer = setTimeout(() => ctrl.abort(), ms);
    const ready = (async () => {
      try {
        for (;;) {
          const { value, done } = await reader.read();
          if (done) return false;
          buf += dec.decode(value);
          for (const m of buf.matchAll(/event: changed\ndata: (.*)\n/g)) if (JSON.parse(m[1]).scopes.includes(scope)) return true;
        }
      } catch {
        return false;
      } finally {
        clearTimeout(timer);
        ctrl.abort();
      }
    })();
    // Wait for the hello so the subscription is in place before the caller changes something.
    for (let i = 0; i < 50 && !buf.includes('hello'); i++) await new Promise((r) => setTimeout(r, 10));
    return ready;
  };
  return { api, nextChange, id: me.user.id as string, householdId: me.household.id as string };
}

async function befriend(a: Awaited<ReturnType<typeof person>>, b: Awaited<ReturnType<typeof person>>) {
  const code = (await a.api('GET', '/api/friends')).body.code;
  assert.equal((await b.api('POST', '/api/friends/request', { code })).status, 200);
  const req = (await a.api('GET', '/api/friends')).body.incoming[0];
  assert.equal((await a.api('POST', `/api/friends/requests/${req.id}/accept`)).status, 200);
}

test('the owner invites a friend; the list is theirs to see only once they join', async () => {
  const ana = await person('Ana');
  const bo = await person('Bo');
  const stranger = await person('Cy');
  assert.notEqual(ana.householdId, bo.householdId);

  // Not friends yet: can't be invited.
  const early = await ana.api('POST', '/api/shared-lists', { name: 'Weekend', friends: [bo.id] });
  assert.equal(early.status, 403);
  assert.equal(early.body.error.code, 'not_friends');

  await befriend(ana, bo);
  const made = await ana.api('POST', '/api/shared-lists', { name: 'Weekend BBQ', friends: [bo.id] });
  assert.equal(made.status, 201);
  const id = made.body.id;

  // Bo sees an invite (name and who from), but not the items until joining.
  const boView = (await bo.api('GET', '/api/shared-lists')).body;
  assert.deepEqual(boView.invites, [{ id, name: 'Weekend BBQ', by: 'Ana' }]);
  assert.equal(boView.lists.length, 0);
  assert.equal((await bo.api('GET', `/api/shared-lists/${id}`)).status, 404);
  assert.equal((await bo.api('POST', `/api/shared-lists/${id}/items`, { name: 'Charcoal' })).status, 404);

  assert.equal((await bo.api('POST', `/api/shared-lists/${id}/answer`, { join: true })).status, 200);
  const list = (await bo.api('GET', `/api/shared-lists/${id}`)).body;
  assert.equal(list.name, 'Weekend BBQ');
  assert.deepEqual(list.members.map((m: any) => [m.name, m.status, m.owner]), [['Ana', 'joined', true], ['Bo', 'joined', false]]);
  assert.equal((await bo.api('GET', '/api/shared-lists')).body.lists[0].owner, 'Ana');

  // Only the owner invites, renames or deletes; Bo isn't friends with Cy anyway.
  assert.equal((await bo.api('POST', `/api/shared-lists/${id}/invite`, { friends: [stranger.id] })).status, 403);
  assert.equal((await bo.api('PATCH', `/api/shared-lists/${id}`, { name: 'Mine now' })).status, 403);
  assert.equal((await bo.api('DELETE', `/api/shared-lists/${id}`)).status, 403);
  // Ana can't invite Cy either: not her friend.
  assert.equal((await ana.api('POST', `/api/shared-lists/${id}/invite`, { friends: [stranger.id] })).status, 403);

  // A declined invite disappears.
  const other = (await ana.api('POST', '/api/shared-lists', { name: 'Other', friends: [bo.id] })).body.id;
  assert.equal((await bo.api('POST', `/api/shared-lists/${other}/answer`, { join: false })).status, 200);
  assert.equal((await bo.api('GET', '/api/shared-lists')).body.invites.length, 0);
  assert.equal((await bo.api('POST', `/api/shared-lists/${other}/answer`, { join: true })).status, 404);
});

test('outsiders can’t read or change a list, whatever they try', async () => {
  const ana = await person('Ana');
  const bo = await person('Bo');
  const eve = await person('Eve');
  await befriend(ana, bo);
  await befriend(ana, eve); // a friend of the owner, but not on this list
  const id = (await ana.api('POST', '/api/shared-lists', { name: 'Flat', friends: [bo.id] })).body.id;
  await bo.api('POST', `/api/shared-lists/${id}/answer`, { join: true });
  const item = (await ana.api('POST', `/api/shared-lists/${id}/items`, { name: 'Milk' })).body.id;

  for (const [m, p, body] of [
    ['GET', `/api/shared-lists/${id}`, undefined],
    ['POST', `/api/shared-lists/${id}/items`, { name: 'Crisps' }],
    ['PATCH', `/api/shared-lists/${id}/items/${item}`, { checked: true }],
    ['DELETE', `/api/shared-lists/${id}/items/${item}`, undefined],
    ['POST', `/api/shared-lists/${id}/finish`, {}],
    ['POST', `/api/shared-lists/${id}/clear-bought`, {}],
    ['POST', `/api/shared-lists/${id}/answer`, { join: true }],
    ['DELETE', `/api/shared-lists/${id}/members/${bo.id}`, undefined],
    ['PATCH', `/api/shared-lists/${id}`, { name: 'Hacked' }],
    ['DELETE', `/api/shared-lists/${id}`, undefined],
  ] as const) {
    const r = await eve.api(m, p, body);
    assert.equal(r.status, 404, `${m} ${p} → ${r.status}`);
  }
  assert.deepEqual((await eve.api('GET', '/api/shared-lists')).body, { lists: [], invites: [] });
  // Nothing changed.
  const list = (await ana.api('GET', `/api/shared-lists/${id}`)).body;
  assert.equal(list.name, 'Flat');
  assert.equal(list.count, 1);
  assert.equal(list.members.length, 2);
  // Validation: no empty names, no huge counts.
  assert.equal((await ana.api('POST', `/api/shared-lists/${id}/items`, {})).status, 400);
  assert.equal((await ana.api('POST', `/api/shared-lists/${id}/items`, { name: 'Eggs', packages: 1000 })).status, 400);
  assert.equal((await ana.api('POST', '/api/shared-lists', { name: '   ' })).status, 400);

  // Someone who leaves is an outsider again; their claim goes back to the others.
  await bo.api('PATCH', `/api/shared-lists/${id}/items/${item}`, { claimed: true });
  assert.equal((await bo.api('DELETE', `/api/shared-lists/${id}/members/${bo.id}`)).status, 200);
  assert.equal((await bo.api('GET', `/api/shared-lists/${id}`)).status, 404);
  assert.equal((await ana.api('GET', `/api/shared-lists/${id}`)).body.groups[0].items[0].claimedBy, null);
  // The owner can't leave (they delete it instead).
  assert.equal((await ana.api('DELETE', `/api/shared-lists/${id}/members/${ana.id}`)).status, 409);
});

test('edits show up live for the other member, with who claimed and ticked what', async () => {
  const ana = await person('Ana');
  const bo = await person('Bo');
  await befriend(ana, bo);
  const id = (await ana.api('POST', '/api/shared-lists', { name: 'Shop', friends: [bo.id] })).body.id;
  await bo.api('POST', `/api/shared-lists/${id}/answer`, { join: true });

  // Ana adds milk: Bo's stream (a different household) is told within a second or two.
  let heard = bo.nextChange('shared');
  const started = Date.now();
  const milk = (await ana.api('POST', `/api/shared-lists/${id}/items`, { productId: 'p_milk', packages: 2 })).body.id;
  assert.equal(await heard, true, 'Bo hears about Ana’s edit');
  assert.ok(Date.now() - started < 2000);
  // Adding the same thing again merges.
  assert.equal((await bo.api('POST', `/api/shared-lists/${id}/items`, { productId: 'p_milk' })).body.merged, true);
  await ana.api('POST', `/api/shared-lists/${id}/items`, { name: 'Birthday candles' });

  // Bo claims the milk ("I'll get it"); Ana sees it's Bo's.
  heard = ana.nextChange('shared');
  await bo.api('PATCH', `/api/shared-lists/${id}/items/${milk}`, { claimed: true });
  assert.equal(await heard, true);
  let view = (await ana.api('GET', `/api/shared-lists/${id}`)).body;
  const milkRow = view.groups.flatMap((g: any) => g.items).find((i: any) => i.id === milk);
  assert.equal(milkRow.claimedBy.name, 'Bo');
  assert.equal(milkRow.claimedBy.me, false);
  assert.equal(milkRow.packages, 3);
  assert.equal(milkRow.addedBy.name, 'Ana');
  // Ana can't drop Bo's claim, but can take it over.
  assert.equal((await ana.api('PATCH', `/api/shared-lists/${id}/items/${milk}`, { claimed: false })).status, 403);

  // Bo ticks it while shopping: Ana sees who has it in their cart.
  heard = ana.nextChange('shared');
  view = (await bo.api('PATCH', `/api/shared-lists/${id}/items/${milk}`, { checked: true })).body;
  assert.equal(await heard, true);
  assert.equal(view.inCart[0].checkedBy.name, 'Bo');
  view = (await ana.api('GET', `/api/shared-lists/${id}`)).body;
  assert.equal(view.inCart.length, 1);
  assert.equal(view.inCart[0].checkedBy.name, 'Bo');
  assert.equal(view.count, 1, 'only the candles left to buy');

  // The household lists aren't touched by any of this.
  assert.equal((await ana.api('GET', '/api/shopping')).body.count, 0);
  assert.equal((await bo.api('GET', '/api/shopping')).body.count, 0);

  // Someone outside the list hears nothing.
  const eve = await person('Eve');
  const eveHeard = eve.nextChange('shared', 400);
  await bo.api('PATCH', `/api/shared-lists/${id}/items/${milk}`, { note: 'the big ones' });
  assert.equal(await eveHeard, false);
});

test('finishing puts what you ticked into your own stock only', async () => {
  const ana = await person('Ana');
  const bo = await person('Bo');
  await befriend(ana, bo);
  const id = (await ana.api('POST', '/api/shared-lists', { name: 'Big shop', friends: [bo.id] })).body.id;
  await bo.api('POST', `/api/shared-lists/${id}/answer`, { join: true });
  const milk = (await ana.api('POST', `/api/shared-lists/${id}/items`, { productId: 'p_milk', packages: 2 })).body.id;
  const eggs = (await ana.api('POST', `/api/shared-lists/${id}/items`, { productId: 'p_eggs' })).body.id;
  const milkBefore = { ana: stock(app.db, ana.householdId, 'p_milk'), bo: stock(app.db, bo.householdId, 'p_milk') };
  const eggsBefore = { ana: stock(app.db, ana.householdId, 'p_eggs'), bo: stock(app.db, bo.householdId, 'p_eggs') };

  // Bo ticks the milk, Ana the eggs. Ticking alone adds nothing to anyone's stock.
  await bo.api('PATCH', `/api/shared-lists/${id}/items/${milk}`, { checked: true });
  await ana.api('PATCH', `/api/shared-lists/${id}/items/${eggs}`, { checked: true });
  assert.equal(stock(app.db, bo.householdId, 'p_milk'), milkBefore.bo);

  // Bo finishes: the milk goes to Bo's household, not Ana's (who added it). Ana's eggs stay in her cart.
  const fin = await bo.api('POST', `/api/shared-lists/${id}/finish`, { clientRequestId: 'shared-finish-1' });
  assert.equal(fin.status, 200);
  assert.equal(fin.body.result.added.length, 1);
  const milkPack = app.db.get<{ package_size: number }>("SELECT package_size FROM products WHERE id = 'p_milk'")!.package_size;
  assert.equal(stock(app.db, bo.householdId, 'p_milk'), milkBefore.bo + 2 * milkPack);
  assert.equal(stock(app.db, ana.householdId, 'p_milk'), milkBefore.ana, 'nothing in the adder’s household');
  assert.equal(stock(app.db, bo.householdId, 'p_eggs'), eggsBefore.bo, 'Ana’s ticks aren’t Bo’s');
  // A retry of the same request isn't counted twice.
  assert.equal((await bo.api('POST', `/api/shared-lists/${id}/finish`, { clientRequestId: 'shared-finish-1' })).body.duplicate, true);
  assert.equal(stock(app.db, bo.householdId, 'p_milk'), milkBefore.bo + 2 * milkPack);

  const view = (await ana.api('GET', `/api/shared-lists/${id}`)).body;
  assert.deepEqual(view.bought.map((i: any) => [i.id, i.boughtBy.name]), [[milk, 'Bo']]);
  assert.equal(view.inCart.length, 1);
  assert.equal(view.inCart[0].checkedBy.name, 'Ana');
  // A bought item can't be ticked again.
  assert.equal((await ana.api('PATCH', `/api/shared-lists/${id}/items/${milk}`, { checked: false })).status, 409);

  // Ana finishes her part: eggs to Ana's household only.
  await ana.api('POST', `/api/shared-lists/${id}/finish`, {});
  const eggPack = app.db.get<{ package_size: number }>("SELECT package_size FROM products WHERE id = 'p_eggs'")!.package_size;
  assert.equal(stock(app.db, ana.householdId, 'p_eggs'), eggsBefore.ana + eggPack);
  assert.equal(stock(app.db, bo.householdId, 'p_eggs'), eggsBefore.bo);

  // Clearing the bought section, and deleting the list, leaves the stock alone.
  assert.equal((await bo.api('POST', `/api/shared-lists/${id}/clear-bought`, {})).body.removed, 2);
  assert.equal((await ana.api('DELETE', `/api/shared-lists/${id}`)).status, 200);
  assert.equal((await bo.api('GET', `/api/shared-lists/${id}`)).status, 404);
  assert.equal(stock(app.db, bo.householdId, 'p_milk'), milkBefore.bo + 2 * milkPack);
});

test('a product only one household knows becomes the buyer’s own product, or a plain item', async () => {
  const ana = await person('Ana');
  const bo = await person('Bo');
  await befriend(ana, bo);
  const id = (await ana.api('POST', '/api/shared-lists', { name: 'Odd things', friends: [bo.id] })).body.id;
  await bo.api('POST', `/api/shared-lists/${id}/answer`, { join: true });
  // Ana's own custom product.
  const custom = (await ana.api('POST', '/api/products', { name: 'Grandma’s jam zz', category: 'pantry', unit: 'pcs', package_size: 1 })).body;
  assert.ok(custom.id);
  // Bo can't add Ana's product by id (it isn't Bo's), only by name.
  assert.equal((await bo.api('POST', `/api/shared-lists/${id}/items`, { productId: custom.id })).status, 404);
  const jam = (await ana.api('POST', `/api/shared-lists/${id}/items`, { productId: custom.id })).body.id;
  await bo.api('PATCH', `/api/shared-lists/${id}/items/${jam}`, { checked: true });
  const fin = (await bo.api('POST', `/api/shared-lists/${id}/finish`, {})).body;
  assert.equal(fin.result.added.length, 1);
  assert.notEqual(fin.result.added[0].productId, custom.id, 'Bo’s stock never points at Ana’s product');
  assert.equal(stock(app.db, ana.householdId, custom.id), 0);
});
