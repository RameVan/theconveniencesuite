// Shopping mode: ticking an item off moves it to the cart and keeps it there.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, type TestApp } from './helpers.ts';
import { clock } from '../src/clock.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
});
after(async () => {
  await app.close();
});

const list = async () => (await app.api('GET', '/api/shopping')).body;
const open = (l: any) => l.groups.flatMap((g: any) => g.items);

test('a ticked meal-plan item stays in the cart instead of coming back on the list', async () => {
  const ids = app.db.all<{ id: string }>("SELECT id FROM recipes WHERE household_id IS NULL AND tags NOT LIKE '%breakfast%' ORDER BY id LIMIT 3").map((r) => r.id);
  for (const recipeId of ids) await app.api('POST', '/api/plan', { date: clock.today(), meal: 'dinner', recipeId, servings: 4 });
  const before = open(await list());
  const planned = before.filter((i: any) => i.plan_driven);
  assert.ok(planned.length >= 2, 'the plan puts items on the list');

  for (const i of planned.slice(0, 2)) assert.equal((await app.api('PATCH', `/api/shopping/${i.id}`, { checked: true })).status, 200);
  // Other screens re-sync the plan; ticking must survive that.
  await app.api('GET', '/api/dashboard');
  for (let n = 0; n < 2; n++) {
    const l = await list();
    const ticked = planned.slice(0, 2).map((i: any) => i.product_id);
    assert.equal(l.checked.length, 2, 'two items in the cart');
    assert.ok(!open(l).some((i: any) => ticked.includes(i.product_id)), 'and not back on the open list');
    assert.equal(open(l).length, before.length - 2);
  }

  // Unticking puts it back once, not twice.
  await app.api('PATCH', `/api/shopping/${planned[0].id}`, { checked: false });
  const l = await list();
  assert.equal(open(l).filter((i: any) => i.product_id === planned[0].product_id).length, 1);
  assert.equal(l.checked.length, 1);
});

test('the list and the ingredient sheet carry webshop search links for the household country', async () => {
  const l = await list();
  const ids = l.shops.map((s: any) => s.id);
  assert.ok(ids.includes('ah') && ids.includes('jumbo'), 'Dutch webshops by default');
  assert.ok(l.shops.every((s: any) => s.search.startsWith('https://') && s.search.includes('{q}')));
  assert.ok(!ids.includes('picnic') && !ids.includes('rewe'), 'app-only and foreign chains have no link');

  await app.api('PATCH', '/api/settings', { household: { chains: ['jumbo'] } });
  assert.deepEqual((await list()).shops.map((s: any) => s.id), ['jumbo'], 'only the chains you shop at');
  const d = (await app.api('GET', '/api/ingredients/p_milk')).body;
  assert.deepEqual(d.shops.map((s: any) => s.id), ['jumbo']);
  assert.equal(typeof d.searchTerm, 'string');
  await app.api('PATCH', '/api/settings', { household: { chains: [] } });
});

test("supermarkets' own brands show as just the product, at that supermarket", async () => {
  const { withoutOwnBrand } = await import('../src/domain/ingredients.ts');
  const r = (name: string, brand: string | null, chain_id: string | null = null) => withoutOwnBrand({ name, brand, chain_id, chain_name: null });
  assert.deepEqual(r('AH Kokosmelk', 'Albert Heijn', 'ah'), { name: 'Kokosmelk', brand: null, chain_id: 'ah', chain_name: 'Albert Heijn' });
  assert.equal(r('Jumbo Bio groene pesto', 'Jumbo Bio', 'jumbo').name, 'Groene pesto');
  assert.equal(r('Halfvolle melk', 'Albert Heiin').chain_id, 'ah', 'misspelled own brand, chain unknown: it is sold at AH');
  assert.equal(r('Goudse kaas', 'Jumbo Wapenaer').chain_name, 'Jumbo');
  assert.equal(r('Ahornsiroop', 'Ahorn').brand, 'Ahorn', 'not an own brand');
  assert.equal(r('Kokosmelk', 'Alpro', 'ah').brand, 'Alpro', 'other brands keep their name');
});
