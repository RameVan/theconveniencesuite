// The owner of a public copy hears about new sign-ups on their own devices (SIGNUP_ALERT_EMAIL).
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, type TestApp } from './helpers.ts';
import { config } from '../src/config.ts';
import { setPushSender, saveSubscription } from '../src/push.ts';

let app: TestApp;
const sent: any[] = [];
before(async () => {
  app = await startApp();
  setPushSender(async (_sub, payload) => sent.push(JSON.parse(payload)));
  const owner = app.db.get<{ id: string; email: string }>('SELECT id, email FROM users WHERE household_id = ?', app.householdId)!;
  saveSubscription(app.db, app.householdId, owner.id, { endpoint: 'https://push.example.test/owner', keys: { p256dh: 'x', auth: 'y' } });
  config.signupAlertEmail = owner.email.toLowerCase();
});
after(async () => {
  config.signupAlertEmail = '';
  await app.close();
});
const signUp = (name: string) => app.api('POST', '/api/auth/register', { email: `${name.toLowerCase()}${Date.now()}@larder.test`, password: 'test-password-123', name });
const settle = () => new Promise((r) => setTimeout(r, 50));

test('a new account sends the owner one push with the name and the running total, and nothing else', async () => {
  assert.equal((await signUp('Sam')).status, 201);
  await settle();
  assert.equal(sent.length, 1);
  assert.equal(sent[0].title, 'New PantryPip account');
  assert.equal(sent[0].body, 'Sam signed up · 2 accounts now');
  assert.ok(!JSON.stringify(sent[0]).includes('@'), 'the email address stays private');
});

test('no alert when the setting is off', async () => {
  config.signupAlertEmail = '';
  sent.length = 0;
  assert.equal((await signUp('Kim')).status, 201);
  await settle();
  assert.equal(sent.length, 0);
});
