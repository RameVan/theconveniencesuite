// Email over SMTP from your own mailbox (Gmail with an app password): the conversation, the login and the
// message itself, against a small fake server.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import net from 'node:net';
import type { AddressInfo } from 'node:net';
import { smtpSend, mimeMessage, linkMail } from '../src/mail.ts';

/** A fake SMTP server that records the commands and the message; `refuse` makes a command fail. */
async function fakeSmtp(opts: { user: string; pass: string; refuse?: string }) {
  const seen: string[] = [];
  let message = '';
  const server = net.createServer((s) => {
    s.setEncoding('utf8');
    let buf = '';
    let state: 'cmd' | 'user' | 'pass' | 'data' = 'cmd';
    let user = '';
    const say = (l: string) => s.write(l + '\r\n');
    say('220 fake.smtp ready');
    s.on('data', (d: string) => {
      buf += d;
      for (;;) {
        if (state === 'data') {
          const end = buf.indexOf('\r\n.\r\n');
          if (end < 0) return;
          message = buf.slice(0, end);
          buf = buf.slice(end + 5);
          state = 'cmd';
          say('250 2.0.0 queued');
          continue;
        }
        const i = buf.indexOf('\r\n');
        if (i < 0) return;
        const line = buf.slice(0, i);
        buf = buf.slice(i + 2);
        if (state === 'user') {
          user = Buffer.from(line, 'base64').toString();
          state = 'pass';
          say('334 UGFzc3dvcmQ6');
          continue;
        }
        if (state === 'pass') {
          state = 'cmd';
          const ok = user === opts.user && Buffer.from(line, 'base64').toString() === opts.pass;
          say(ok ? '235 2.7.0 Accepted' : '535 5.7.8 Username and Password not accepted');
          continue;
        }
        seen.push(line);
        const verb = line.split(/[ :]/)[0].toUpperCase();
        if (opts.refuse && line.startsWith(opts.refuse)) say('550 5.1.1 refused');
        else if (verb === 'EHLO') (say('250-fake.smtp'), say('250-AUTH LOGIN PLAIN'), say('250 8BITMIME'));
        else if (verb === 'AUTH') (state = 'user', say('334 VXNlcm5hbWU6'));
        else if (verb === 'MAIL' || verb === 'RCPT') say('250 2.1.0 OK');
        else if (verb === 'DATA') (state = 'data', say('354 Go ahead'));
        else if (verb === 'QUIT') (say('221 bye'), s.end());
        else say('502 unknown');
      }
    });
  });
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', () => r()));
  return { port: (server.address() as AddressInfo).port, seen, message: () => message, close: () => new Promise<void>((r) => server.close(() => r())) };
}

/** The decoded text and HTML parts of a message. */
const parts = (msg: string) => [...msg.matchAll(/Content-Transfer-Encoding: base64\r\n\r\n([A-Za-z0-9+/=\r\n]+?)\r\n--/g)].map((m) => Buffer.from(m[1].replace(/\r\n/g, ''), 'base64').toString('utf8'));

test('sends from your own address: logs in, then MAIL FROM, RCPT TO and a text + HTML message', async () => {
  const srv = await fakeSmtp({ user: 'me@gmail.com', pass: 'abcdefghijklmnop' });
  try {
    const mail = linkMail('friend@example.com', 'Bevestig je e-mailadres ✉️', 'Welkom bij PantryPip, Zoë.', 'Bevestigen', 'https://app.example/#/confirm?token=abc', 'Niet aangevraagd? Negeer dit.');
    await smtpSend({ host: '127.0.0.1', port: srv.port, secure: 'none', user: 'me@gmail.com', pass: 'abcdefghijklmnop' }, 'PantryPip <me@gmail.com>', mail);
    assert.deepEqual(srv.seen.filter((l) => !l.startsWith('EHLO')), ['AUTH LOGIN', 'MAIL FROM:<me@gmail.com>', 'RCPT TO:<friend@example.com>', 'DATA', 'QUIT']);
    const msg = srv.message();
    assert.match(msg, /^From: PantryPip <me@gmail\.com>\r\n/);
    assert.match(msg, /\r\nTo: friend@example\.com\r\n/);
    // Non-ASCII subjects are encoded, and decode back to the same text.
    const subj = msg.match(/\r\nSubject: =\?UTF-8\?B\?([^?]+)\?=\r\n/)![1];
    assert.equal(Buffer.from(subj, 'base64').toString('utf8'), 'Bevestig je e-mailadres ✉️');
    const [text, html] = parts(msg);
    assert.match(text, /Welkom bij PantryPip, Zoë\./);
    assert.match(text, /https:\/\/app\.example\/#\/confirm\?token=abc/);
    assert.match(html, /<a href="https:\/\/app\.example\/#\/confirm\?token=abc"/);
  } finally {
    await srv.close();
  }
});

test('a wrong app password or a refused address is an error, not a silent success', async () => {
  const srv = await fakeSmtp({ user: 'me@gmail.com', pass: 'right' });
  try {
    const mail = linkMail('friend@example.com', 'Hi', 'Hello', 'Open', 'https://x.example/', 'Bye');
    await assert.rejects(smtpSend({ host: '127.0.0.1', port: srv.port, secure: 'none', user: 'me@gmail.com', pass: 'wrong' }, 'me@gmail.com', mail), /AUTH password: 535/);
  } finally {
    await srv.close();
  }
  const srv2 = await fakeSmtp({ user: 'u', pass: 'p', refuse: 'RCPT' });
  try {
    await assert.rejects(smtpSend({ host: '127.0.0.1', port: srv2.port, secure: 'none', user: 'u', pass: 'p' }, 'u@x.example', linkMail('nobody@example.com', 'Hi', 'a', 'b', 'https://x.example/', 'c')), /RCPT TO.*550/);
  } finally {
    await srv2.close();
  }
  // Nothing listening: fails fast.
  await assert.rejects(smtpSend({ host: '127.0.0.1', port: 1, secure: 'none', timeoutMs: 2000 }, 'a@b.example', linkMail('c@d.example', 'x', 'y', 'z', 'https://e.example/', 'w')));
});

test('a line starting with a dot can’t end the message early', () => {
  const msg = mimeMessage('A <a@b.example>', { to: 'c@d.example', subject: 'x', text: '.', html: '.' });
  assert.ok(!/\r\n\.\r\n/.test(msg + '\r\n'), 'no bare "." line inside the message');
});
