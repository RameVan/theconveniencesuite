// Owner test mode (sandbox, unlock everything, time travel, test accounts) and "reset all progress".
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { startApp, stock, type TestApp } from './helpers.ts';
import { config } from '../src/config.ts';
import { clock, addDays } from '../src/clock.ts';

let app: TestApp;
let tmp = '';
const saved = { owner: config.ownerEmail, backups: config.backupDir };
before(async () => {
  tmp = mkdtempSync(path.join(os.tmpdir(), 'larder-testmode-'));
  config.backupDir = tmp;
  app = await startApp();
  config.ownerEmail = (await app.api('GET', '/api/me')).body.user.email.toLowerCase();
});
after(async () => {
  config.ownerEmail = saved.owner;
  config.backupDir = saved.backups;
  await app.close();
  rmSync(tmp, { recursive: true, force: true });
});

test('only the owner sees and uses test mode', async () => {
  const me = (await app.api('GET', '/api/me')).body;
  assert.equal(me.owner, true);
  assert.deepEqual(me.test, { on: false });
  const real = config.ownerEmail;
  config.ownerEmail = 'someone-else@larder.test';
  try {
    assert.equal((await app.api('GET', '/api/me')).body.owner, false);
    assert.equal((await app.api('POST', '/api/test/start')).status, 403);
    assert.equal((await app.api('POST', '/api/test/accounts', { email: 'x@larder.test', password: 'long-enough-pw', name: 'X' })).status, 403);
  } finally {
    config.ownerEmail = real;
  }
});

test('unlocking and time travel need the sandbox on, so they can be undone', async () => {
  assert.equal((await app.api('POST', '/api/test/unlock')).status, 409);
  assert.equal((await app.api('POST', '/api/test/time', { days: 3 })).status, 409);
});

test('the sandbox puts everything back: stock, list, plan, progress, settings and the date', async () => {
  await app.api('POST', '/api/inventory/add', { productId: 'p_rice', quantity: 500 });
  await app.api('POST', '/api/shopping', { name: 'Coffee' });
  const before = {
    rice: stock(app.db, app.householdId, 'p_rice'),
    list: (await app.api('GET', '/api/shopping')).body.groups.flatMap((g: any) => g.items).map((i: any) => i.name).sort(),
    xp: (await app.api('GET', '/api/game')).body.xp,
    today: (await app.api('GET', '/api/health')).body.time.slice(0, 10),
  };
  const on = await app.api('POST', '/api/test/start');
  assert.equal(on.status, 200, JSON.stringify(on.body));
  assert.equal(on.body.on, true);

  // Play around.
  await app.api('POST', '/api/inventory/add', { productId: 'p_rice', quantity: 2000 });
  await app.api('POST', '/api/shopping', { name: 'Chocolate' });
  await app.api('POST', '/api/plan', { date: addDays(clock.today(), 1), meal: 'dinner', recipeId: 'r_chicken_curry', servings: 2 });
  assert.equal((await app.api('PATCH', '/api/settings', { household: { planDays: [1, 3, 5] } })).status, 200);
  const unlocked = await app.api('POST', '/api/test/unlock');
  assert.equal(unlocked.status, 200, JSON.stringify(unlocked.body));
  assert.equal(unlocked.body.level, 21, 'top level');
  const j = (await app.api('GET', '/api/journey')).body;
  assert.ok(j.chapters.every((c: any) => c.completed), 'every chapter done');
  assert.ok(j.companion.skins.every((s: any) => s.unlocked), 'every look unlocked');
  const moved = await app.api('POST', '/api/test/time', { days: 10 });
  assert.equal(moved.body.today, addDays(before.today, 10));
  assert.equal((await app.api('GET', '/api/health')).body.time.slice(0, 10), addDays(before.today, 10), 'the app sees the new date');
  assert.equal(clock.today(), before.today, 'other households keep the real date');

  const sandboxRev = (await app.api('GET', '/api/settings')).body.rev;
  const off = await app.api('POST', '/api/test/stop');
  assert.equal(off.status, 200, JSON.stringify(off.body));
  assert.deepEqual(off.body, { on: false });
  assert.equal(stock(app.db, app.householdId, 'p_rice'), before.rice);
  assert.deepEqual((await app.api('GET', '/api/shopping')).body.groups.flatMap((g: any) => g.items).map((i: any) => i.name).sort(), before.list);
  assert.equal((await app.api('GET', `/api/plan?start=${addDays(clock.today(), 1)}&days=1`)).body.days[0].slots.length, 0, 'the planned meal is gone');
  assert.equal((await app.api('GET', '/api/game')).body.xp, before.xp, 'XP is back');
  assert.equal((await app.api('GET', '/api/health')).body.time.slice(0, 10), before.today, 'and the date');
  const s = (await app.api('GET', '/api/settings')).body;
  assert.deepEqual(s.household.planDays, [0, 1, 2, 3, 4, 5, 6], 'settings are back');
  assert.ok(s.rev > sandboxRev, 'with a newer revision, so open apps take them');
  assert.deepEqual(app.db.all('PRAGMA foreign_key_check'), []);
});

test('test accounts skip email confirmation', async () => {
  const r = await app.api('POST', '/api/test/accounts', { email: 'tester2@larder.test', password: 'long-enough-pw', name: 'Tester 2', joinMine: true });
  assert.equal(r.status, 201, JSON.stringify(r.body));
  const u = app.db.get<{ household_id: string }>('SELECT household_id FROM users WHERE email = ?', 'tester2@larder.test');
  assert.equal(u?.household_id, app.householdId, 'joined my household');
});

test('reset all progress: back to level 1 and chapter 1, history and stock kept', async () => {
  await app.api('POST', '/api/inventory/add', { productId: 'p_coconut_milk', quantity: 800 });
  await app.api('POST', '/api/inventory/add', { productId: 'p_rice', quantity: 1000 });
  const slot = (await app.api('POST', '/api/plan', { date: clock.today(), meal: 'dinner', recipeId: 'r_chicken_curry', servings: 2 })).body;
  await app.api('POST', `/api/plan/${slot.id}/cook`, {});
  const g = (await app.api('GET', '/api/game')).body;
  assert.ok(g.xp > 0, 'cooking earned XP');
  const rice = stock(app.db, app.householdId, 'p_rice');
  assert.equal((await app.api('POST', '/api/progress/reset', {})).status, 400, 'needs the confirmation word');
  const r = await app.api('POST', '/api/progress/reset', { confirm: 'RESET' });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  const after = (await app.api('GET', '/api/game')).body;
  assert.equal(after.xp, 0);
  assert.equal(after.level.n, 1);
  const j = (await app.api('GET', '/api/journey')).body;
  assert.ok(!j.chapters[0].completed && !j.chapters[1].unlocked, 'back at the first chapter');
  assert.equal(stock(app.db, app.householdId, 'p_rice'), rice, 'stock untouched');
  assert.ok(app.db.get('SELECT 1 FROM cook_log WHERE household_id = ?', app.householdId), 'cooking history kept');
});
