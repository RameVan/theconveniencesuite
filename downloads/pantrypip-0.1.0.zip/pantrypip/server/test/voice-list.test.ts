// Spoken shopping hauls: run-on lists without commas, list mode preview and one-step add.
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, stock, setUsualTypes, type TestApp } from './helpers.ts';
import { segmentPhrase } from '../src/assistant/list.ts';
import { listProducts } from '../src/domain/products.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
  setUsualTypes(app);
});
after(() => app.close());

const names = (r: any) => r.lines.map((l: any) => `${l.productId ?? 'new'}:${l.qty}`);

describe('spoken lists', () => {
  test('the assistant splits "I bought milk eggs bread" into products, without commas', async () => {
    const r = await app.say('I bought milk eggs bread cheese and 2 kg potatoes');
    assert.equal(r.actions.filter((a: any) => a.kind === 'added').length, 5, r.reply);
    assert.equal(stock(app.db, app.householdId, 'p_potatoes'), 2000);
    assert.ok(stock(app.db, app.householdId, 'p_eggs') >= 10);
  });

  test('Dutch run-on list, with amounts in front of the right product', async () => {
    const r = (await app.api('POST', '/api/assistant/list', { text: 'ik heb melk eieren drie paprika’s een komkommer 500 gram gehakt en kombucha gekocht', lang: 'nl' })).body;
    const lines = r.lines.map((l: any) => [l.productId, l.qty, l.isNew]);
    assert.deepEqual(lines.map((l: any) => l[0]).slice(0, 2), ['p_milk', 'p_eggs']);
    const cucumber = r.lines.find((l: any) => l.productId === 'p_cucumber');
    assert.equal(cucumber.qty, 1, 'the 500 g belongs to the mince, not the cucumber');
    assert.equal(r.lines.find((l: any) => l.name.toLowerCase().includes('gehakt')).qty, 500);
    assert.ok(r.lines.some((l: any) => l.isNew && /kombucha/i.test(l.name)), 'unknown products are kept as new');
  });

  test('pauses, filler words and "done" don’t become products', async () => {
    const r = (await app.api('POST', '/api/assistant/list', { text: 'milk. Eggs. uh a bag of apples, then chicken breast and oat milk done', lang: 'en' })).body;
    assert.deepEqual(names(r).map((n: string) => n.split(':')[0]), ['p_milk', 'p_eggs', 'p_apples', 'p_chicken_breast', 'p_oat_milk']);
  });

  test('two-word products stay together and a single unknown phrase is not split', () => {
    const products = listProducts(app.db, app.householdId);
    assert.equal(segmentPhrase('chicken breast', products), null);
    assert.equal(segmentPhrase('dragon fruit', products), null);
    const parts = segmentPhrase('chicken breast greek yoghurt', products)!;
    assert.deepEqual(parts.map((p) => p.name), ['chicken breast', 'greek yoghurt']);
  });

  test('list mode adds everything in one batch, and one undo removes it all', async () => {
    const before = stock(app.db, app.householdId, 'p_bananas');
    const r = (await app.api('POST', '/api/inventory/add-many', {
      items: [{ productId: 'p_bananas', quantity: 6 }, { productId: 'p_rice', quantity: 1000 }, { name: 'Dragon fruit', quantity: 2 }],
      clientRequestId: 'list-1',
    })).body;
    assert.equal(r.result.count, 3);
    assert.equal(stock(app.db, app.householdId, 'p_bananas'), before + 6);
    const again = (await app.api('POST', '/api/inventory/add-many', { items: [{ productId: 'p_bananas', quantity: 6 }], clientRequestId: 'list-1' })).body;
    assert.equal(again.duplicate, true, 'retrying the same request adds nothing');
    await app.api('POST', '/api/inventory/undo', { batchId: r.batchId });
    assert.equal(stock(app.db, app.householdId, 'p_bananas'), before);
  });
});
