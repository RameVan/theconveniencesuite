// End-to-end workflow tests through the HTTP API (the 15 workflows from the brief).
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, stock, setUsualTypes, AH_RECEIPT, JUMBO_RECEIPT, type TestApp } from './helpers.ts';
import { ai } from '../src/ai/ai.ts';
import { setFetcher } from '../src/domain/barcode.ts';
import { verifyLedger } from '../src/domain/ledger.ts';
import { clock, addDays } from '../src/clock.ts';
import { parseReceiptText } from '../src/domain/receipts.ts';
import { bus } from '../src/bus.ts';

let app: TestApp;
before(async () => {
  app = await startApp();
  setUsualTypes(app);
});
after(async () => {
  clock.set(null);
  await app.close();
});
const S = (pid: string) => stock(app.db, app.householdId, pid);
const add = (productId: string, quantity: number, extra: Record<string, unknown> = {}) => app.api('POST', '/api/inventory/add', { productId, quantity, ...extra });

describe('1. receipt scanning', () => {
  test('photo → AI parse (mocked) → review → commit updates inventory and learns aliases', async () => {
    const realEnabled = ai.enabled;
    const realParse = ai.parseReceiptImages;
    ai.enabled = () => true;
    ai.parseReceiptImages = async () => parseReceiptText(AH_RECEIPT); // stand-in for the vision model
    try {
      const scan = await app.api('POST', '/api/receipts/scan', { images: [{ mediaType: 'image/jpeg', data: 'AAAA' }] });
      assert.equal(scan.status, 200, JSON.stringify(scan.body));
      const draft = scan.body;
      assert.equal(draft.parser, 'ai');
      assert.equal(draft.summary.store, 'Albert Heijn');
      assert.equal(draft.parsed.total, 20.57);
      assert.equal(draft.proposals.length, 6);
      const byName = (n: string) => draft.proposals.find((p: any) => p.line.name.toUpperCase().includes(n));
      assert.equal(byName('MELK').productId, 'p_milk');
      assert.equal(byName('KIPFILET').quantity, 1000); // 2 × 500 g
      assert.equal(byName('KIPFILET').pricePaid, 10.98); // bonus applied
      assert.equal(byName('BANANEN').productId, 'p_bananas');
      assert.equal(byName('BANANEN').quantity, 7); // 846 g ≈ 7 bananas of 120 g
      assert.equal(byName('SCHARRELEIEREN').quantity, 10);
      const garlic = byName('KNFLK');
      assert.equal(garlic.needsReview, true, 'abbreviation is unknown the first time');

      // Review: user maps the abbreviation to garlic (30 cloves per bulb) and commits.
      const commit = await app.api('POST', `/api/receipts/${draft.id}/commit`, {
        lines: [{ index: garlic.index, action: 'add', productId: 'p_garlic', quantity: 10, packages: 1 }],
      });
      assert.equal(commit.status, 200, JSON.stringify(commit.body));
      assert.equal(commit.body.added.length, 6);
      assert.equal(S('p_milk'), 1000);
      assert.equal(S('p_chicken_breast'), 1000);
      assert.equal(S('p_garlic'), 10);
      assert.ok(app.db.get("SELECT 1 FROM purchases WHERE household_id = ? AND product_id = 'p_chicken_breast' AND total_price = 10.98", app.householdId));
    } finally {
      ai.enabled = realEnabled;
      ai.parseReceiptImages = realParse;
    }
  });

  test('learned abbreviation is matched automatically on the next receipt', async () => {
    const r = await app.api('POST', '/api/receipts/scan', { text: AH_RECEIPT.replace('27-10-2026', '03-11-2026').replace('1,19', '1,25').replace('20,57', '20,63').replace('20,57', '20,63') });
    const garlic = r.body.proposals.find((p: any) => p.line.name.includes('KNFLK'));
    assert.equal(garlic.productId, 'p_garlic');
    assert.equal(garlic.matchedBy, 'alias');
    assert.equal(garlic.quantity, 10, 'learned package size reused');
    assert.equal(garlic.needsReview, false);
  });

  test('the same receipt cannot be added twice', async () => {
    const r = await app.api('POST', '/api/receipts/scan', { text: AH_RECEIPT });
    assert.ok(r.body.duplicateReceipt, 'flagged as duplicate in review');
    const c = await app.api('POST', `/api/receipts/${r.body.id}/commit`, { lines: [] });
    assert.equal(c.status, 409);
    assert.equal(S('p_milk'), 1000, 'no double counting');
  });

  test('Jumbo receipt with a separate quantity line', async () => {
    const r = await app.api('POST', '/api/receipts/scan', { text: JUMBO_RECEIPT });
    const tomatoes = r.body.proposals.find((p: any) => p.line.name.includes('Tomatenblokjes'));
    assert.equal(tomatoes.line.count, 2);
    assert.equal(tomatoes.productId, 'p_canned_tomatoes');
    assert.equal(tomatoes.quantity, 800);
    assert.equal(r.body.parsed.warnings.length, 0);
  });
});

describe('2–5. voice commands', () => {
  test('adding groceries by voice', async () => {
    const before = S('p_milk');
    const r = await app.say('I bought two litres of milk.');
    assert.equal(S('p_milk'), before + 2000);
    assert.match(r.reply, /Added 2 L/);
    assert.equal(r.undoable, true);
    await app.say('Add six eggs to my groceries.');
    assert.equal(S('p_eggs'), 16);
    const nl = await app.say('ik heb 3 uien gekocht');
    assert.equal(nl.lang, 'nl');
    assert.equal(S('p_onion'), 3);
  });

  test('removing groceries by voice', async () => {
    await app.say('Remove one onion.');
    assert.equal(S('p_onion'), 2);
    await app.say('I used 200 grams of chicken.');
    assert.equal(S('p_chicken_breast'), 800);
    await add('p_spinach', 300);
    const r = await app.say('Remove the remaining spinach, it has gone bad.');
    assert.equal(S('p_spinach'), 0);
    assert.ok(app.db.get("SELECT 1 FROM inventory_events WHERE household_id = ? AND product_id = 'p_spinach' AND type = 'discard' AND reason = 'spoiled'", app.householdId));
    assert.match(r.reply, /Threw away/);
    const before = S('p_milk');
    assert.ok(before > 0);
    await app.say('I finished the milk.');
    assert.equal(S('p_milk'), 0);
  });

  test('vague amounts get one follow-up question, never an invented quantity', async () => {
    await add('p_milk', 1000);
    const q = await app.say('I used some milk');
    assert.ok(q.clarify, 'asks how much');
    assert.equal(S('p_milk'), 1000, 'nothing changed yet');
    await app.say('About 250 millilitres');
    assert.equal(S('p_milk'), 750);
  });

  test('adding to the shopping list by voice', async () => {
    await app.say('Add coffee to my shopping list.');
    await app.say('zet twee pakken pasta op de boodschappenlijst');
    const list = await app.api('GET', '/api/shopping');
    const items = list.body.groups.flatMap((g: any) => g.items);
    assert.ok(items.find((i: any) => i.product_id === 'p_coffee'));
    assert.equal(items.find((i: any) => i.product_id === 'p_pasta').packages, 2);
    assert.equal(S('p_coffee'), 0, 'list additions never touch inventory');
  });

  test('ambiguous "add" asks inventory vs list, unless the screen tells us', async () => {
    const r = await app.say('add butter');
    assert.ok(r.clarify);
    await app.say('list');
    const items = (await app.api('GET', '/api/shopping')).body.groups.flatMap((g: any) => g.items);
    assert.ok(items.find((i: any) => i.product_id === 'p_butter'));
    await app.say('add yoghurt', { context: 'inventory' });
    assert.equal(S('p_yoghurt'), 500);
  });

  test('correcting a misheard voice command', async () => {
    const before = S('p_orange_juice');
    await app.say('I bought 2 litres of orange juice');
    assert.equal(S('p_orange_juice'), before + 2000);
    const r = await app.say('no, 1 litre');
    assert.equal(S('p_orange_juice'), before + 1000);
    assert.ok(r.actions.some((a: any) => a.kind === 'undone'));
    await app.say('undo');
    assert.equal(S('p_orange_juice'), before);
    const v = verifyLedger(app.db, app.householdId);
    assert.deepEqual(v.mismatches, []);
  });

  test('questions are answered from inventory', async () => {
    const r = await app.say('How much chicken do I have left?');
    assert.match(r.reply, /800 g/);
    const low = await app.say("What's running low?");
    assert.ok(low.reply.length > 0);
    const inv = await app.say('What groceries do I currently have?');
    assert.equal(inv.data.kind, 'stock');
  });
});

describe('6. barcode scanning', () => {
  test('unknown barcode → Open Food Facts → remembered product → stock', async () => {
    let calls = 0;
    setFetcher(async () => {
      calls++;
      return new Response(JSON.stringify({ status: 1, product: { product_name_nl: 'Volle yoghurt', brands: 'Zuivelhoeve', quantity: '1 l', nutriments: { 'energy-kcal_100g': 80, proteins_100g: 4, carbohydrates_100g: 5, fat_100g: 4 } } }), { status: 200 });
    });
    const code = '8710400000013';
    const look = await app.api('GET', `/api/barcode/${code}`);
    assert.equal(look.status, 200, JSON.stringify(look.body));
    assert.equal(look.body.source, 'openfoodfacts');
    assert.equal(look.body.external.name, 'Volle yoghurt');
    const linked = await app.api('POST', `/api/barcode/${code}/link`, {});
    assert.equal(linked.body.package_size, 1000);
    assert.equal(linked.body.unit, 'ml');
    await app.api('POST', '/api/inventory/add', { productId: linked.body.id, packages: 1, source: 'barcode' });
    assert.equal(S(linked.body.id), 1000);
    const again = await app.api('GET', `/api/barcode/${code}`);
    assert.equal(again.body.source, 'local');
    assert.equal(calls, 1, 'Open Food Facts is only called once');
    const bad = await app.api('GET', '/api/barcode/8710400000014');
    assert.equal(bad.status, 400, 'check digit validated');
  });
});

describe('7–9. cooking, portions and leftovers', () => {
  test('cooking a planned recipe deducts its ingredients', async () => {
    await add('p_eggs', 10);
    await add('p_canned_tomatoes', 400);
    await add('p_bell_pepper', 3);
    await add('p_onion', 3);
    const eggs = S('p_eggs');
    const slot = await app.api('POST', '/api/plan', { date: clock.today(), meal: 'dinner', recipeId: 'r_shakshuka', servings: 2 });
    assert.equal(S('p_eggs'), eggs, 'planning alone does not deduct');
    const cook = await app.api('POST', `/api/plan/${slot.body.id}/cook`, {});
    assert.equal(cook.status, 200, JSON.stringify(cook.body));
    assert.equal(S('p_eggs'), eggs - 4);
    assert.equal(S('p_canned_tomatoes'), 0);
    const plan = await app.api('GET', `/api/plan?start=${clock.today()}`);
    assert.equal(plan.body.days[0].slots.find((s: any) => s.id === slot.body.id).status, 'cooked');
    // Cooking again with the same slot id is idempotent.
    await app.api('POST', `/api/plan/${slot.body.id}/cook`, {});
    assert.equal(S('p_eggs'), eggs - 4);
  });

  test('changing portions scales the deduction', async () => {
    await add('p_pasta', 1000);
    await add('p_pesto', 190);
    await add('p_frozen_peas', 450);
    const pasta = S('p_pasta');
    await app.api('POST', '/api/recipes/r_pasta_pesto/cook', { servings: 4, clientRequestId: 'cook-pesto-4' }); // recipe is for 2
    assert.equal(S('p_pasta'), pasta - 400);
    assert.equal(S('p_frozen_peas'), 450 - 300);
  });

  test('leftovers become their own inventory and can be frozen, eaten or thrown away', async () => {
    await add('p_minced_beef', 500);
    await add('p_kidney_beans', 800);
    await add('p_canned_tomatoes', 800);
    const cook = await app.api('POST', '/api/recipes/r_chili/cook', { servings: 6, leftovers: { fridge: 4 }, clientRequestId: 'cook-chili' });
    assert.equal(cook.body.result.leftoverLots.length, 1);
    const r = await app.say('I froze two portions of chili');
    assert.match(r.reply, /Froze 2 portions/);
    const inv = (await app.api('GET', '/api/inventory')).body;
    const chili = inv.leftovers.filter((l: any) => l.title.includes('chili'));
    assert.deepEqual(chili.map((l: any) => [l.location_kind, l.quantity]).sort(), [['freezer', 2], ['fridge', 2]]);
    const fridgeLot = chili.find((l: any) => l.location_kind === 'fridge');
    await app.api('POST', `/api/leftovers/${fridgeLot.id}`, { action: 'eat', portions: 1 });
    await app.api('POST', `/api/leftovers/${fridgeLot.id}`, { action: 'discard', portions: 1 });
    const after = (await app.api('GET', '/api/inventory')).body.leftovers.filter((l: any) => l.title.includes('chili'));
    assert.deepEqual(after.map((l: any) => l.location_kind), ['freezer']);
    const waste = (await app.api('GET', '/api/analytics')).body.wasteReasons;
    assert.ok(waste.find((w: any) => w.reason === 'leftover'));
  });

  test('voice: "I just cooked pasta for two people"', async () => {
    await add('p_pasta', 500);
    const r = await app.say('I just cooked pasta for two people.');
    // Several pasta recipes exist, so it asks which one (one tap), then deducts.
    assert.ok(r.clarify);
    const pick = r.clarify.options.find((o: any) => o.label.includes('pesto'));
    const before = S('p_pasta');
    const done = await app.say(pick.value);
    assert.match(done.reply, /for 2/);
    assert.equal(S('p_pasta'), before - 200);
  });
});

describe('10. shopping list from the meal plan', () => {
  test('only the missing amount is added, rounded to packages, and recalculated when the plan changes', async () => {
    // Have 300 g chicken; curry for 4 needs 500 g → 200 g short → 1 pack of 500 g.
    const have = S('p_chicken_breast');
    await app.api('POST', '/api/inventory/set', { productId: 'p_chicken_breast', quantity: 300 });
    assert.equal(S('p_chicken_breast'), 300, `was ${have}`);
    const day = addDays(clock.today(), 2);
    const slot = await app.api('POST', '/api/plan', { date: day, meal: 'dinner', recipeId: 'r_chicken_curry', servings: 4 });
    let list = (await app.api('GET', '/api/shopping')).body;
    let chicken = list.groups.flatMap((g: any) => g.items).find((i: any) => i.product_id === 'p_chicken_breast');
    assert.ok(chicken, 'chicken added for the plan');
    assert.equal(Math.round(chicken.quantity), 200);
    assert.equal(chicken.packages, 1);
    assert.equal(chicken.reason, 'meal_plan');
    // Double the servings → 1000 g needed → 700 g short → the least waste: 3 × 250 g (50 g left over).
    await app.api('PATCH', `/api/plan/${slot.body.id}`, { servings: 8 });
    list = (await app.api('GET', '/api/shopping')).body;
    chicken = list.groups.flatMap((g: any) => g.items).find((i: any) => i.product_id === 'p_chicken_breast');
    assert.equal(chicken.plan.toBuy, 700);
    assert.equal(chicken.packages * chicken.pack_size, 750);
    assert.equal(chicken.plan.leftover, 50);
    // Remove the meal → the plan-driven item disappears.
    await app.api('DELETE', `/api/plan/${slot.body.id}`);
    list = (await app.api('GET', '/api/shopping')).body;
    assert.equal(list.groups.flatMap((g: any) => g.items).find((i: any) => i.product_id === 'p_chicken_breast'), undefined);
  });

  test('reading the list repeatedly is stable (no change notifications from drifting estimates)', async () => {
    await app.api('POST', '/api/plan', { date: addDays(clock.today(), 1), meal: 'dinner', recipeId: 'r_lentil_dal', servings: 4 });
    await app.api('GET', '/api/shopping');
    await new Promise((r) => setTimeout(r, 80));
    let notified = 0;
    const unsub = bus.subscribe(app.householdId, (scopes) => scopes.includes('shopping') && notified++);
    for (let i = 0; i < 5; i++) await app.api('GET', '/api/shopping');
    await new Promise((r) => setTimeout(r, 80));
    unsub();
    assert.equal(notified, 0);
  });

  test('finishing a trip moves ticked items into inventory; a later receipt reconciles instead of double counting', async () => {
    const item = (await app.api('POST', '/api/shopping', { productId: 'p_whole_milk', packages: 2 })).body;
    await app.api('PATCH', `/api/shopping/${item.id}`, { checked: true });
    const before = S('p_whole_milk');
    await app.api('POST', '/api/shopping/complete', { clientRequestId: 'trip-1' });
    assert.equal(S('p_whole_milk'), before + 2000);
    // Receipt says 3 cartons were bought.
    const r = await app.api('POST', '/api/receipts/scan', { text: 'Jumbo\nVolle melk 1L 3 x 1,35 4,05 B\nTotaal 4,05\n01-11-2026' });
    const line = r.body.proposals[0];
    assert.equal(line.productId, 'p_whole_milk');
    assert.ok(line.duplicateOf, 'recognised as the same purchase');
    await app.api('POST', `/api/receipts/${r.body.id}/commit`, { lines: [] });
    assert.equal(S('p_whole_milk'), before + 3000, 'adjusted to the receipt, not added again');
  });
});

describe('11–12. recipe discovery', () => {
  test('cook with what I have', async () => {
    const r = await app.api('GET', '/api/recipes/cook-now');
    assert.ok(r.body.length > 0);
    assert.ok(r.body.every((m: any) => m.matchPct >= 50));
    assert.ok(r.body[0].missing !== undefined && r.body[0].minutes > 0 && r.body[0].nutritionPerServing);
  });

  test('finding new recipes by filters and natural language', async () => {
    const italian = await app.api('GET', '/api/recipes?cuisine=Italian');
    assert.ok(italian.body.length >= 3 && italian.body.every((m: any) => m.cuisine === 'Italian'));
    const quick = await app.api('GET', `/api/recipes/ask?q=${encodeURIComponent('Find a meal that takes less than 20 minutes')}`);
    assert.ok(quick.body.length > 0 && quick.body.every((m: any) => m.minutes <= 20));
    const protein = await app.api('GET', `/api/recipes/ask?q=${encodeURIComponent('Give me a high-protein dinner')}`);
    assert.ok(protein.body.every((m: any) => m.nutritionPerServing.protein >= 20));
    const vegan = await app.api('GET', '/api/recipes?diet=vegan&maxMinutes=30');
    assert.ok(vegan.body.every((m: any) => m.diet.includes('vegan') && m.minutes <= 30));
  });
});

describe('13–14. prediction and corrections', () => {
  test('predicts when a regularly bought product runs out', async () => {
    const start = new Date('2026-08-01T10:00:00Z');
    // Buy 2 L of a fresh product every 4 days without logging consumption.
    for (let i = 0; i < 8; i++) {
      clock.set(new Date(start.getTime() + i * 4 * 86_400_000));
      if (i > 0) await app.api('POST', '/api/inventory/set', { productId: 'p_oat_milk', quantity: 0 });
      await app.api('POST', '/api/inventory/add', { productId: 'p_oat_milk', quantity: 2000 });
    }
    clock.set(new Date(start.getTime() + (7 * 4 + 2) * 86_400_000)); // two days after the last purchase
    const p = (await app.api('GET', '/api/products/p_oat_milk')).body.stock;
    assert.ok(Math.abs(p.prediction.ratePerDay - 500) < 40, `rate ${p.prediction.ratePerDay}`);
    assert.ok(Math.abs(p.estimated - 1000) < 150, `estimated ${p.estimated}`);
    assert.equal(p.confirmed, 2000, 'confirmed quantity is never overwritten by the estimate');
    assert.ok(p.daysLeft > 1 && p.daysLeft < 3, `daysLeft ${p.daysLeft}`);
    assert.ok(p.confidence >= 0.5);
    clock.set(new Date(start.getTime() + (7 * 4 + 3.5) * 86_400_000));
    const sug = (await app.api('GET', '/api/shopping/suggestions')).body;
    assert.ok(sug.find((s: any) => s.productId === 'p_oat_milk'), 'suggested before it runs out');
  });

  test('a correction updates stock and teaches the predictor', async () => {
    const before = (await app.api('GET', '/api/products/p_oat_milk')).body.stock;
    // User says there's still 1.5 L, more than the estimate: we consume slower than predicted.
    await app.say('I have 1.5 litres of oat milk left');
    const after = (await app.api('GET', '/api/products/p_oat_milk')).body.stock;
    assert.equal(after.confirmed, 1500);
    assert.ok(after.prediction.correctionFactor < 1, `factor ${after.prediction.correctionFactor} (estimate was ${before.estimated})`);
    clock.advanceDays(1);
    const later = (await app.api('GET', '/api/products/p_oat_milk')).body.stock;
    assert.ok(1500 - later.estimated < 500, 'slower decay after the correction');
    clock.set(null);
  });

  test('rejected suggestions stop being suggested', async () => {
    clock.set(new Date('2026-09-03T12:00:00Z'));
    const first = (await app.api('GET', '/api/shopping/suggestions')).body.find((s: any) => s.productId === 'p_oat_milk');
    assert.ok(first);
    await app.api('POST', '/api/shopping/suggestions/p_oat_milk/reject', {});
    await app.api('POST', '/api/shopping/suggestions/p_oat_milk/reject', {});
    clock.advanceDays(10);
    const again = (await app.api('GET', '/api/shopping/suggestions')).body.find((s: any) => s.productId === 'p_oat_milk');
    assert.equal(again, undefined);
    clock.set(null);
  });
});

describe('15. duplicates and concurrency', () => {
  test('retrying a request with the same id applies it once', async () => {
    const before = S('p_apples');
    const a = await app.api('POST', '/api/inventory/add', { productId: 'p_apples', quantity: 6, clientRequestId: 'retry-apples-1' });
    const b = await app.api('POST', '/api/inventory/add', { productId: 'p_apples', quantity: 6, clientRequestId: 'retry-apples-1' });
    assert.equal(a.body.duplicate, false);
    assert.equal(b.body.duplicate, true);
    assert.equal(S('p_apples'), before + 6);
    const v1 = await app.say('I ate 2 apples', { clientRequestId: 'voice-apples-1' });
    const v2 = await app.say('I ate 2 apples', { clientRequestId: 'voice-apples-1' });
    assert.equal(v2.duplicate, true);
    assert.equal(v1.turnId, v2.turnId);
    assert.equal(S('p_apples'), before + 4);
  });

  test('an identical voice command right after asks before doing it twice', async () => {
    const before = S('p_apples');
    await app.say('I ate 1 apple');
    const r = await app.say('I ate 1 apple');
    assert.ok(r.clarify);
    assert.equal(S('p_apples'), before - 1);
    await app.say('yes');
    assert.equal(S('p_apples'), before - 2);
  });

  test('concurrent deductions never corrupt stock', async () => {
    await app.api('POST', '/api/inventory/set', { productId: 'p_croissants', quantity: 10 });
    const results = await Promise.all(Array.from({ length: 25 }, (_, i) => app.api('POST', '/api/inventory/consume', { productId: 'p_croissants', quantity: 1, clientRequestId: `croissant-${i}` })));
    assert.ok(results.every((r) => r.status === 200));
    assert.equal(S('p_croissants'), 0);
    const used = app.db.get<{ n: number }>("SELECT -SUM(delta) n FROM inventory_events WHERE household_id = ? AND product_id = 'p_croissants' AND type = 'consume'", app.householdId)!.n;
    assert.equal(used, 10, 'exactly the available stock was consumed');
    assert.deepEqual(verifyLedger(app.db, app.householdId).mismatches, []);
  });

  test('stale absolute edits are rejected', async () => {
    await app.api('POST', '/api/inventory/set', { productId: 'p_butter', quantity: 250 });
    await app.api('POST', '/api/inventory/consume', { productId: 'p_butter', quantity: 30 });
    const stale = await app.api('POST', '/api/inventory/set', { productId: 'p_butter', quantity: 100, expectedTotal: 250 });
    assert.equal(stale.status, 409);
    assert.equal(S('p_butter'), 220);
  });

  test('the ledger reconstructs every lot', async () => {
    const v = (await app.api('GET', '/api/inventory/verify')).body;
    assert.ok(v.lots > 20);
    assert.deepEqual(v.mismatches, []);
  });
});

describe('security', () => {
  test('API requires a session and JSON bodies', async () => {
    const r = await app.api('POST', '/api/auth/logout', {});
    assert.equal(r.status, 200);
    const denied = await app.api('GET', '/api/inventory');
    assert.equal(denied.status, 401);
  });
});
