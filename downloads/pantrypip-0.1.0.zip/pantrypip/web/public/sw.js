// App-shell cache: the UI opens instantly (and offline); API calls always go to the network.
const CACHE = 'larder-shell-v11';
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(['/', '/index.html', '/icon.svg', '/icon-192.png', '/apple-touch-icon.png', '/manifest.webmanifest'])));
  self.skipWaiting();
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== location.origin || url.pathname.startsWith('/api/')) return;
  // Built files have their content hash in the name and never change: serve them from the cache without
  // touching the network.
  if (url.pathname.startsWith('/assets/')) {
    e.respondWith(
      caches.match(e.request).then((hit) => hit || fetch(e.request).then((res) => {
        if (res.ok) {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(e.request, copy));
        }
        return res;
      })),
    );
    return;
  }
  e.respondWith(
    fetch(e.request)
      .then((res) => {
        if (res.ok && (url.pathname.startsWith('/assets/') || url.pathname === '/')) {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(e.request, copy));
        }
        return res;
      })
      .catch(() => caches.match(e.request).then((r) => r || caches.match('/index.html'))),
  );
});

// ---------- Push: the daily "Did you cook X?" question ----------
self.addEventListener('push', (e) => {
  let data = {};
  try {
    data = e.data ? e.data.json() : {};
  } catch {
    data = { title: 'PantryPip', body: e.data ? e.data.text() : '' };
  }
  e.waitUntil(
    self.registration.showNotification(data.title || 'PantryPip', {
      body: data.body || '',
      tag: data.tag,
      icon: '/icon-192.png',
      badge: '/icon-192.png',
      data: { url: data.url || '/#/', slotId: data.slotId || null },
      actions: data.actions || [],
      requireInteraction: !!data.slotId,
    }),
  );
});

self.addEventListener('notificationclick', (e) => {
  const { url, slotId } = e.notification.data || {};
  e.notification.close();
  // "Yes, cooked" / "No" answer straight from the notification, without opening the app.
  if (slotId && (e.action === 'cooked' || e.action === 'not_cooked')) {
    e.waitUntil(
      fetch(`/api/checkins/${slotId}`, { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ answer: e.action }) })
        .then((r) => {
          if (!r.ok) throw new Error(String(r.status));
          const nl = (self.navigator.language || '').toLowerCase().startsWith('nl');
          return self.registration.showNotification('PantryPip', {
            body: e.action === 'cooked' ? (nl ? 'Gekookt. Ingrediënten zijn uit je voorraad gehaald.' : 'Cooked. Ingredients taken out of your inventory.') : nl ? 'Oké, niet gekookt.' : 'OK, not cooked.',
            tag: 'checkin-done',
            icon: '/icon-192.png',
          });
        })
        .catch(() => self.clients.openWindow(url || '/#/')),
    );
    return;
  }
  e.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
      for (const c of list) {
        if ('focus' in c) {
          c.navigate(url || '/#/');
          return c.focus();
        }
      }
      return self.clients.openWindow(url || '/#/');
    }),
  );
});
