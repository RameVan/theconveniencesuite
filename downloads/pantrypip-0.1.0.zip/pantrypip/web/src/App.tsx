import { useCallback, useEffect, useMemo, useState } from 'react';
import { Home as HomeIcon, Refrigerator, CalendarDays, BookOpen, Trophy, Mic, Settings as SettingsIcon } from 'lucide-react';
import { get, onUnauthorized, useLiveUpdates, useQuery, clearCache } from './api';
import { AppCtx, type AppApi, type QuickOpts } from './app-context';
import { LangContext, detectLang, type Lang } from './i18n';
import { ToastProvider } from './components/ui';
import { AssistantSheet, speechSupported } from './components/Assistant';
import { QuickSheet } from './components/QuickSheet';
import { BarcodeSheet } from './components/BarcodeSheet';
import { ReceiptSheet } from './components/ReceiptSheet';
import { RewardProvider } from './components/Reward';
import { PathPage } from './pages/Path';
import { BoughtListSheet } from './components/BoughtList';
import { HomePage, recordUse } from './pages/Home';
import { InventoryPage } from './pages/Inventory';
import { PlannerPage } from './pages/Planner';
import { DiscoverPage } from './pages/Discover';
import { RecipePage, CookMode } from './pages/Recipe';
import { ShoppingPage } from './pages/Shopping';
import { InsightsPage } from './pages/Insights';
import { AchievementsPage } from './pages/Achievements';
import { SettingsPage } from './pages/Settings';
import { JourneyToast } from './components/JourneyToast';
import { applyAppearance, uiPrefs } from './appearance';
import { SettingsProvider, SaveIndicator, useSettings } from './settings';
import { LoginPage } from './pages/Login';

function useHash() {
  const [hash, setHash] = useState(() => location.hash || '#/');
  useEffect(() => {
    const on = () => setHash(location.hash || '#/');
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  return hash;
}

const LABELS: Record<Lang, Record<string, string>> = {
  en: { home: 'Home', groceries: 'Groceries', plan: 'Planner', discover: 'Recipes', progress: 'Progress', settings: 'Settings', stock: 'In stock', list: 'Shopping list' },
  nl: { home: 'Thuis', groceries: 'Boodschappen', plan: 'Planner', discover: 'Recepten', progress: 'Voortgang', settings: 'Instellingen', stock: 'In huis', list: 'Boodschappenlijst' },
};
/** Start page setting → route. */
const START: Record<string, string> = { home: '#/', groceries: '#/inventory', recipes: '#/discover', plan: '#/plan', progress: '#/progress' };

export function App() {
  const [authed, setAuthed] = useState<boolean | null>(null);
  const [me, setMe] = useState<any>(null);
  useEffect(() => {
    get('/api/me').then((m) => (setMe(m), setAuthed(true))).catch(() => setAuthed(false));
    return onUnauthorized(() => setAuthed(false));
  }, []);
  if (authed === null) return null;
  if (!authed) return <ToastProvider><LoginPage onDone={() => get('/api/me').then((m) => (clearCache(), setMe(m), setAuthed(true)))} /></ToastProvider>;
  // Settings load before any screen that depends on them.
  return (
    <SettingsProvider userId={me.user.id} fallback={<div className="boot" aria-busy="true" />}>
      <Shell me={me} />
    </SettingsProvider>
  );
}

function Shell({ me }: { me: any }) {
  const hash = useHash();
  const { settings, set } = useSettings();
  const cfg = useQuery<any>('/api/config');
  const shopping = useQuery<any>('/api/shopping', ['shopping']);
  const lang = detectLang(settings.me.language);
  const [assistant, setAssistant] = useState<null | { listen?: boolean; text?: string }>(null);
  const [quick, setQuick] = useState<QuickOpts | null>(null);
  const [barcode, setBarcode] = useState(false);
  const [receipt, setReceipt] = useState(false);
  const [boughtList, setBoughtList] = useState<{ listen?: boolean } | null>(null);
  useLiveUpdates(true);
  const gameState = useQuery<any>('/api/game', ['game', 'preferences']);

  // Appearance, language and behaviour come from the settings store (one source of truth).
  const appearance = settings.me.appearance;
  useEffect(() => applyAppearance(appearance), [JSON.stringify(appearance)]);
  useEffect(() => {
    Object.assign(uiPrefs, settings.household.interaction);
  }, [settings.household.interaction]);
  useEffect(() => {
    document.documentElement.lang = lang;
    try {
      localStorage.setItem('larder.lang', lang); // only so the sign-in screen speaks your language
    } catch {
      /* ignore */
    }
  }, [lang]);
  useEffect(() => {
    const a = gameState.data?.accents?.[gameState.data?.accent];
    const root = document.documentElement.style;
    if (a && gameState.data.accent !== 'herb') {
      root.setProperty('--herb', a.herb);
      root.setProperty('--herb-soft', `color-mix(in srgb, ${a.herb} 16%, var(--surface))`);
    } else {
      root.removeProperty('--herb');
      root.removeProperty('--herb-soft');
    }
  }, [gameState.data?.accent]);

  // Your start page, once per visit (only when the app opens on Home).
  useEffect(() => {
    try {
      if (sessionStorage.getItem('larder.started')) return;
      sessionStorage.setItem('larder.started', '1');
    } catch {
      /* ignore */
    }
    const to = START[settings.me.startPage];
    if (to && to !== '#/' && (location.hash || '#/') === '#/') location.replace(to);
  }, []);

  // Home-screen shortcuts: /#/?do=voice | receipt | barcode | list
  useEffect(() => {
    const m = hash.match(/[?&]do=(\w+)/);
    if (!m) return;
    if (m[1] === 'voice') setAssistant({ listen: true });
    if (m[1] === 'receipt') setReceipt(true);
    if (m[1] === 'barcode') setBarcode(true);
    if (m[1] === 'list') setBoughtList({ listen: true });
    history.replaceState(null, '', hash.replace(/[?&]do=\w+/, ''));
  }, [hash]);

  const api: AppApi = useMemo(
    () => ({
      lang,
      setLang: (l) => set('me', 'language', l),
      config: cfg.data ?? null,
      me,
      openAssistant: (o) => setAssistant(o ?? {}),
      openQuick: (o) => setQuick(o ?? {}),
      openReceipt: () => setReceipt(true),
      openBoughtList: (o) => setBoughtList(o ?? {}),
      openBarcode: () => setBarcode(true),
      navigate: (h) => (location.hash = h),
    }),
    [lang, cfg.data, me, set],
  );

  const route = hash.replace(/^#/, '').split('?')[0] || '/';
  const [, section, arg] = route.split('/');
  const L = LABELS[lang];
  const context = section || 'home';
  // Five places. Shopping lives with your groceries; statistics live in Progress; settings sit behind the gear.
  const tabs = [
    { id: '', label: L.home, icon: HomeIcon },
    { id: 'inventory', label: L.groceries, icon: Refrigerator, badge: shopping.data?.count, also: ['shopping'] },
    { id: 'discover', label: L.discover, icon: BookOpen, also: ['recipe'] },
    { id: 'plan', label: L.plan, icon: CalendarDays },
    { id: 'progress', label: L.progress, icon: Trophy, also: ['path', 'insights', 'achievements'] },
  ];
  // A new screen opens at the top (Progress scrolls itself to where you are on the path).
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [section, arg]);

  let page;
  if (section === 'cook' && arg) page = <CookMode id={arg} />;
  else if (section === 'recipe' && arg) page = <RecipePage id={arg} />;
  else if (section === 'inventory') page = <InventoryPage />;
  else if (section === 'plan') page = <PlannerPage />;
  else if (section === 'discover') page = <DiscoverPage />;
  else if (section === 'shopping') page = <ShoppingPage />;
  else if (section === 'insights') page = <InsightsPage />;
  else if (section === 'achievements') page = <AchievementsPage />;
  else if (section === 'settings' || section === 'personalise') page = <SettingsPage category={section === 'settings' ? arg : undefined} />;
  else if (section === 'path' || section === 'progress') page = <PathPage />;
  else page = <HomePage />;

  const onFab = useCallback(() => setAssistant({ listen: speechSupported && uiPrefs.voiceFirst !== false }), []);
  // What people open, so Home can suggest a better layout (only ever suggested, never applied).
  useEffect(() => {
    if (section && ['shopping', 'plan', 'discover', 'inventory', 'progress', 'insights'].includes(section)) recordUse(`open:${section}`);
  }, [section]);
  const immersive = section === 'cook';

  return (
    <LangContext.Provider value={lang}>
      <AppCtx.Provider value={api}>
        <ToastProvider>
        <RewardProvider>
          <div className="shell">
            {!immersive && (
              <nav className="tabbar" aria-label="Main">
                <div className="brand"><img src="/icon.svg" alt="" /> PantryPip</div>
                {tabs.map((t) => (
                  <a key={t.id} className="tab" href={`#/${t.id}`} aria-current={(section ?? '') === t.id || (t.id === '' && !section) || (t.also ?? []).includes(section ?? '') ? 'page' : undefined}>
                    <t.icon aria-hidden />
                    <span>{t.label}</span>
                    {!!t.badge && <span className="badge">{t.badge}</span>}
                  </a>
                ))}
                <div className="spacer" />
                <a className="tab secondary" href="#/settings" aria-current={section === 'settings' ? 'page' : undefined}><SettingsIcon aria-hidden /><span>{L.settings}</span></a>
              </nav>
            )}
            <main className="main" id="main">{page}</main>
          </div>
          <SaveIndicator lang={lang} />
          {!immersive && section !== 'progress' && section !== 'path' && <JourneyToast />}
          {!immersive && !assistant && (
            <button className="fab" onClick={onFab} aria-label={lang === 'nl' ? 'Assistent: spreek of typ een opdracht' : 'Assistant: speak or type a command'} title="Speak">
              <Mic />
            </button>
          )}
          {assistant && <AssistantSheet onClose={() => setAssistant(null)} startListening={assistant.listen} initialText={assistant.text} context={context} />}
          {quick && <QuickSheet opts={quick} onClose={() => setQuick(null)} />}
          {barcode && <BarcodeSheet onClose={() => setBarcode(false)} />}
          {receipt && <ReceiptSheet onClose={() => setReceipt(false)} />}
          {boughtList && <BoughtListSheet onClose={() => setBoughtList(null)} startListening={boughtList.listen} />}
        </RewardProvider>
        </ToastProvider>
      </AppCtx.Provider>
    </LangContext.Provider>
  );
}
