// API client + a tiny query cache that refreshes when the server reports changes over SSE.
import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from 'react';

export class ApiError extends Error {
  status: number;
  code: string;
  details?: unknown;
  constructor(status: number, code: string, message: string, details?: unknown) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export async function api<T = any>(method: string, path: string, body?: unknown): Promise<T> {
  const res = await fetch(path, {
    method,
    headers: body === undefined ? {} : { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
    credentials: 'same-origin',
  });
  const text = await res.text();
  const data = text ? JSON.parse(text) : null;
  if (!res.ok) {
    if (res.status === 401) authListeners.forEach((l) => l());
    throw new ApiError(res.status, data?.error?.code ?? 'error', data?.error?.message ?? res.statusText, data?.error?.details);
  }
  return data as T;
}

export const get = <T = any>(p: string) => api<T>('GET', p);
export const post = <T = any>(p: string, b: unknown = {}) => api<T>('POST', p, b);
export const patch = <T = any>(p: string, b: unknown = {}) => api<T>('PATCH', p, b);
export const put = <T = any>(p: string, b: unknown = {}) => api<T>('PUT', p, b);
export const del = <T = any>(p: string) => api<T>('DELETE', p);

/** Unique id per user action, so retries and double taps are applied once. */
export const requestId = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;

const authListeners = new Set<() => void>();
export const onUnauthorized = (l: () => void) => {
  authListeners.add(l);
  return () => {
    authListeners.delete(l);
  };
};

// ---------- Query cache ----------
// Each query has its own listeners, so a refetch re-renders only the screens that show it. When data changes
// (or the app comes back to the foreground) only the queries on screen are refetched; the others are marked
// stale and refetched when they are shown again. A phone then doesn't download every screen it visited.

type Snap = { data?: any; error?: any; loading: boolean };
type Entry = Snap & { promise?: Promise<any>; scopes: string[]; fetcher: () => Promise<any>; at: number; stale: boolean; snap: Snap; subs: Set<() => void> };
const cache = new Map<string, Entry>();

const notify = (e: Entry) => {
  e.snap = { data: e.data, error: e.error, loading: e.loading };
  e.subs.forEach((s) => s());
};

function entry(path: string, scopes: string[]): Entry {
  let e = cache.get(path);
  if (!e) {
    e = { loading: true, scopes, fetcher: () => get(path), at: 0, stale: true, snap: { loading: true }, subs: new Set() };
    cache.set(path, e);
  }
  return e;
}

function load(key: string) {
  const e = cache.get(key)!;
  if (e.promise) return e.promise;
  e.loading = true;
  e.stale = false;
  e.promise = e
    .fetcher()
    .then((d) => {
      e.data = d;
      e.error = undefined;
    })
    .catch((err) => {
      e.error = err;
    })
    .finally(() => {
      e.loading = false;
      e.promise = undefined;
      e.at = Date.now();
      notify(e);
    });
  notify(e);
  return e.promise;
}

const NONE: Snap = { loading: false };

/** Fetch `path` (cached by key); refetches when any of `scopes` changes on the server. */
export function useQuery<T = any>(path: string | null, scopes: string[] = []) {
  const subscribe = useCallback(
    (cb: () => void) => {
      if (!path) return () => {};
      const e = entry(path, scopes);
      e.subs.add(cb);
      if (e.stale) queueMicrotask(() => load(path));
      return () => {
        e.subs.delete(cb);
      };
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [path],
  );
  const snap = useSyncExternalStore(subscribe, () => (path ? entry(path, scopes).snap : NONE));
  return { data: snap.data as T | undefined, error: snap.error as ApiError | undefined, loading: snap.loading && snap.data === undefined, refresh: () => path && load(path) };
}

export function invalidate(scopes: string[] | 'all') {
  const loads: Promise<any>[] = [];
  for (const [key, e] of cache) {
    if (scopes !== 'all' && !e.scopes.some((s) => scopes.includes(s))) continue;
    if (e.subs.size) loads.push(load(key));
    else e.stale = true;
  }
  return Promise.all(loads).then(() => {});
}

/** After signing in: nothing from a previous account stays. */
export function clearCache() {
  for (const [key, e] of cache) {
    if (!e.subs.size) cache.delete(key);
    else {
      Object.assign(e, { data: undefined, error: undefined, loading: false, stale: true });
      notify(e);
    }
  }
}

/**
 * Server-sent events: any change in the household (from any device) refreshes the affected views.
 * The connection is closed while the app is in the background (no keep-alive traffic waking the radio) and
 * reopened when it comes back; when the server can't be reached it retries less and less often.
 */
export function useLiveUpdates(enabled: boolean) {
  useEffect(() => {
    if (!enabled) return;
    let es: EventSource | null = null;
    let retry: number | undefined;
    let delay = 3000;
    let hiddenAt = 0;
    const close = () => {
      es?.close();
      es = null;
      clearTimeout(retry);
    };
    const connect = () => {
      close();
      if (document.visibilityState === 'hidden') return;
      es = new EventSource('/api/stream');
      es.addEventListener('hello', () => (delay = 3000));
      es.addEventListener('changed', (ev) => {
        const { scopes } = JSON.parse((ev as MessageEvent).data);
        const s = new Set<string>(scopes);
        // Inventory changes ripple into everything derived from it.
        if (s.has('inventory') || s.has('receipts')) ['home', 'recipes', 'shopping', 'planner'].forEach((x) => s.add(x));
        if (s.has('planner')) ['shopping', 'home'].forEach((x) => s.add(x));
        if (s.has('shopping')) s.add('home');
        invalidate([...s]);
        // Settings changed on another device (or by another screen): the settings store refreshes itself.
        if (s.has('preferences')) dispatchEvent(new Event('larder:settings-changed'));
      });
      es.onerror = () => {
        close();
        retry = window.setTimeout(connect, delay);
        delay = Math.min(delay * 2, 60_000);
      };
    };
    connect();
    const onVisibility = () => {
      if (document.visibilityState === 'hidden') {
        hiddenAt = Date.now();
        close();
        return;
      }
      delay = 3000;
      connect();
      // Changes made elsewhere while away weren't streamed to us; a quick app switch doesn't need a refresh.
      if (Date.now() - hiddenAt > 10_000) {
        invalidate('all');
        dispatchEvent(new Event('larder:settings-changed'));
      }
    };
    const onOnline = () => {
      delay = 3000;
      if (!es) connect();
    };
    document.addEventListener('visibilitychange', onVisibility);
    addEventListener('online', onOnline);
    return () => {
      close();
      document.removeEventListener('visibilitychange', onVisibility);
      removeEventListener('online', onOnline);
    };
  }, [enabled]);
}

export function useDebounced<T>(value: T, ms = 200): T {
  const [v, setV] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setV(value), ms);
    return () => clearTimeout(t);
  }, [value, ms]);
  return v;
}

export function useLatest<T>(v: T) {
  const r = useRef(v);
  r.current = v;
  return r;
}
