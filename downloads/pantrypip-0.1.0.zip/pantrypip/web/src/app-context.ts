import { createContext, useContext } from 'react';
import type { Lang } from './i18n';

export interface QuickOpts {
  mode?: 'add' | 'use' | 'discard' | 'list';
  productId?: string;
  name?: string;
}

export interface AppApi {
  lang: Lang;
  setLang: (l: Lang | 'auto') => void;
  config: { ai: boolean; aiModel: string | null; barcodeLookup: boolean; categories: Record<string, { en: string; nl: string; order: number }> } | null;
  me: any;
  openAssistant: (opts?: { listen?: boolean; text?: string }) => void;
  openQuick: (opts?: QuickOpts) => void;
  openReceipt: () => void;
  openBoughtList: (opts?: { listen?: boolean }) => void;
  openBarcode: () => void;
  navigate: (hash: string) => void;
}

export const AppCtx = createContext<AppApi>(null as any);
export const useApp = () => useContext(AppCtx);

export const SCOPES_ALL = ['inventory', 'shopping', 'planner', 'recipes', 'home', 'receipts', 'preferences', 'notifications'];
