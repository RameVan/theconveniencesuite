// Personal appearance (style, theme, spacing, cards, text size, animations) applied as data
// attributes on <html>, cached locally so the first paint already looks right. Plus the interaction
// preferences that plain functions need (outside React).
import { useSetting } from './settings';
export type Style = 'larder' | 'lavender' | 'herb' | 'citrus' | 'night' | 'ink';
export interface Appearance { showMoney?: boolean; style?: Style; theme?: 'system' | 'light' | 'dark'; density?: 'comfortable' | 'compact'; cards?: 'soft' | 'outlined' | 'flat'; motion?: 'full' | 'reduced' | 'off'; textSize?: 'normal' | 'large' }

/** The looks to choose from, with the colours the picker previews them with. */
export const STYLES: { id: Style; name: [string, string]; desc: [string, string]; band: string; bg: string; card: string; accent: string; ink: string; onBand: string; tiles: [string, string, string] }[] = [
  { id: 'larder', name: ['Classic', 'Klassiek'], desc: ['Warm kitchen neutrals, herb green, serif headings.', 'Warme keukentinten, kruidengroen, schreefkoppen.'], band: '#f6f1e9', bg: '#f6f1e9', card: '#fffdf9', accent: '#2f5d50', ink: '#1d2420', onBand: '#1d2420', tiles: ['#dfeae4', '#fbecd2', '#f8e1d8'] },
  { id: 'lavender', name: ['Lavender Glass', 'Lavendelglas'], desc: ['Blue-violet into blush, white glass cards, pastel tiles.', 'Blauwpaars naar roze, witte glazen kaarten, pastel tegels.'], band: 'linear-gradient(170deg, #4747d1, #6c5fea 45%, #c9b8f5)', bg: '#f4f1fc', card: '#ffffff', accent: '#5b5bf0', ink: '#17152e', onBand: '#ffffff', tiles: ['#ece8ff', '#ffe4ea', '#ddf7f0'] },
  { id: 'herb', name: ['Herb Glass', 'Kruidenglas'], desc: ['PantryPip’s green, as glass: deep herb into cream.', 'Het groen van PantryPip als glas: diep kruidengroen naar crème.'], band: 'linear-gradient(170deg, #143b30, #3f8166 45%, #a9d3be)', bg: '#f1f5f0', card: '#ffffff', accent: '#2f7d5b', ink: '#14231c', onBand: '#ffffff', tiles: ['#e2f1e8', '#fcf0d2', '#fbe5dc'] },
  { id: 'citrus', name: ['Citrus Morning', 'Citrusochtend'], desc: ['Peach and cream, tangerine accents, rounder shapes.', 'Perzik en crème, mandarijnaccenten, rondere vormen.'], band: 'linear-gradient(170deg, #ffcfa6, #ffe2c6 50%, #fff3e2)', bg: '#fff8ef', card: '#ffffff', accent: '#c2461a', ink: '#2e1a0e', onBand: '#2e1a0e', tiles: ['#ffe8da', '#fff2c9', '#e9f7df'] },
  { id: 'night', name: ['Night Pantry', 'Nachtvoorraad'], desc: ['Always dark, violet and teal glow, lilac accents.', 'Altijd donker, paarse en groenblauwe gloed, lila accenten.'], band: 'radial-gradient(120% 90% at 0% 0%, #4a37b8, #0d0b1a 70%)', bg: '#0d0b1a', card: '#1b1833', accent: '#a99bff', ink: '#f4f2ff', onBand: '#f4f2ff', tiles: ['#2a2550', '#3d1f27', '#173a33'] },
  { id: 'ink', name: ['Ink & Signal', 'Inkt & Signaal'], desc: ['Flat and high contrast, one strong blue, bold type.', 'Plat en veel contrast, één krachtig blauw, vette letters.'], band: '#f3f4f7', bg: '#f3f4f7', card: '#ffffff', accent: '#2b50e6', ink: '#0f1222', onBand: '#0f1222', tiles: ['#e8edff', '#ffeedd', '#e0f5ea'] },
];

const KEY = 'larder.appearance';
let current: Appearance = {};
const darkQuery = typeof matchMedia === 'function' ? matchMedia('(prefers-color-scheme: dark)') : null;

function paint() {
  const a = current;
  const root = document.documentElement;
  if (a.theme === 'light' || a.theme === 'dark') root.dataset.theme = a.theme;
  else delete root.dataset.theme;
  const style = a.style && a.style !== 'larder' ? a.style : null;
  if (style) root.dataset.style = style;
  else delete root.dataset.style;
  // Which palette a style uses: Night is always dark, others follow the theme (or the system).
  root.dataset.mode = style === 'night' || a.theme === 'dark' || (a.theme !== 'light' && darkQuery?.matches) ? 'dark' : 'light';
  root.dataset.density = a.density ?? 'comfortable';
  root.dataset.cards = a.cards ?? 'soft';
  root.dataset.motion = a.motion ?? 'full';
  root.dataset.text = a.textSize ?? 'normal';
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', getComputedStyle(root).getPropertyValue(style ? '--topbar-bg' : '--bg').trim() || getComputedStyle(root).getPropertyValue('--bg').trim() || '#f6f1e9');
}
darkQuery?.addEventListener?.('change', paint);

export function applyAppearance(a: Appearance) {
  current = a;
  paint();
  try {
    localStorage.setItem(KEY, JSON.stringify(a));
  } catch {
    /* private mode */
  }
}

export function applyCachedAppearance() {
  try {
    const a = JSON.parse(localStorage.getItem(KEY) ?? 'null');
    if (a) applyAppearance(a);
  } catch {
    /* ignore */
  }
}

/** Spending & waste figures are optional (Settings → General, or the Statistics page). */
export function useShowMoney(): [boolean, (v: boolean) => void] {
  const [look, setLook] = useSetting<any>('me', 'appearance');
  return [look?.showMoney !== false, (v: boolean) => setLook({ showMoney: v })];
}

/** Household interaction preferences, kept current by the app shell. */
export const uiPrefs = { confirmDestructive: false, voiceFirst: true };
