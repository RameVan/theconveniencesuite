// Personal appearance (style, theme, spacing, cards, text size, animations) applied as data
// attributes on <html>, cached locally so the first paint already looks right. Plus the interaction
// preferences that plain functions need (outside React).
import { useSyncExternalStore } from 'react';
import { useSetting } from './settings';
import { logoDataUrl, logoFor } from './logo';
export type Style = 'larder' | 'lavender' | 'herb' | 'citrus' | 'night' | 'ink' | Direction;
/** The eight design directions from the 2026 redesign (docs/design). Each is a full token set plus its own
    component rules in directions.css, applied as data-direction on <html> (or on a preview frame). */
export type Direction = 'editorial' | 'grocer' | 'skog' | 'dot' | 'epicerie' | 'monoline' | 'raster' | 'seventies' | 'suite';
export interface Appearance { showMoney?: boolean; style?: Style; theme?: 'system' | 'light' | 'dark'; density?: 'comfortable' | 'compact'; cards?: 'soft' | 'outlined' | 'flat'; motion?: 'full' | 'reduced' | 'off'; textSize?: 'normal' | 'large'; minimal?: boolean }

/** The looks to choose from, with the colours the picker previews them with. */
export const STYLES: { id: Style; name: [string, string]; desc: [string, string]; band: string; bg: string; card: string; accent: string; ink: string; onBand: string; tiles: [string, string, string]; fonts?: string; direction?: boolean }[] = [
  // The eight directions (docs/design/DIRECTIONS.md).
  { id: 'editorial', direction: true, name: ['Pantry Editorial', 'Voorraad-editorial'], desc: ['A food magazine: big soft serif, hairline rules, numbered sections.', 'Een eetblad: grote zachte schreefletter, haarlijnen, genummerde rubrieken.'], fonts: 'Fraunces · Figtree', band: '#f4f1ec', bg: '#f4f1ec', card: '#fbf9f5', accent: '#b4462a', ink: '#1f2a31', onBand: '#1f2a31', tiles: ['#e9e4da', '#efe0d6', '#e3e8dd'] },
  { id: 'grocer', direction: true, name: ['Corner Grocer', 'Buurtwinkel'], desc: ['Retro grocery modernism: red shopfront, ink outlines, price-tag labels.', 'Retro kruidenier: rode pui, inktlijnen, prijskaartjes.'], fonts: 'Bricolage Grotesque · DM Mono', band: '#b8352a', bg: '#f3ead7', card: '#fffaf0', accent: '#b8352a', ink: '#1d1b16', onBand: '#fff6e6', tiles: ['#f1d27a', '#e6b8a6', '#bcd3b2'] },
  { id: 'skog', direction: true, name: ['Skog', 'Skog'], desc: ['Scandinavian organic: oat and sage, light type, lots of air.', 'Scandinavisch organisch: haver en salie, lichte letters, veel lucht.'], fonts: 'Albert Sans', band: '#eeeae3', bg: '#eeeae3', card: '#f8f6f2', accent: '#3f5a4c', ink: '#26302b', onBand: '#26302b', tiles: ['#dde3da', '#e8ddd3', '#e4e0d4'] },
  { id: 'dot', direction: true, name: ['Dot', 'Stip'], desc: ['Playful minimalism: white, ink and one coral dot that marks what matters.', 'Speels minimalisme: wit, inkt en één koraalrode stip voor wat telt.'], fonts: 'Outfit', band: '#ffffff', bg: '#fbfaf8', card: '#ffffff', accent: '#24323b', ink: '#24323b', onBand: '#24323b', tiles: ['#fde3db', '#f0f0ec', '#e4eedd'] },
  { id: 'epicerie', direction: true, name: ['Épicerie', 'Épicerie'], desc: ['A boutique food brand: garamond, spaced capitals, framed labels.', 'Een boetiekmerk: garamond, gespatieerde kapitalen, omlijste etiketten.'], fonts: 'Cormorant Garamond · Jost', band: '#2b2f25', bg: '#f1ebe0', card: '#f9f5ee', accent: '#7a2f2a', ink: '#23261f', onBand: '#efe6d2', tiles: ['#e5dccb', '#e8d4cc', '#dcdccb'] },
  { id: 'monoline', direction: true, name: ['Pip Line', 'Pip-lijn'], desc: ['The logo as a system: one round-ended line draws everything.', 'Het logo als systeem: één lijn met ronde uiteinden tekent alles.'], fonts: 'Quicksand · Figtree', band: '#f4f1ec', bg: '#f4f1ec', card: '#fbfaf7', accent: '#24323b', ink: '#24323b', onBand: '#24323b', tiles: ['#e3ecd9', '#f9e0d7', '#ebe7df'] },
  { id: 'raster', direction: true, name: ['Raster', 'Raster'], desc: ['Contemporary Swiss: strict grid, tight grotesk, one red, no decoration.', 'Hedendaags Zwitsers: strak raster, compacte grotesk, één rood.'], fonts: 'Inter Tight · Inter · JetBrains Mono', band: '#ffffff', bg: '#ffffff', card: '#ffffff', accent: '#d03a1f', ink: '#111111', onBand: '#111111', tiles: ['#f1f1f1', '#fbe3dc', '#e9e9e9'] },
  { id: 'seventies', direction: true, name: ['Seventies Kitchen', 'Jaren-70-keuken'], desc: ['Organic modern retro: soft heavy serif, arches, terracotta and mustard.', 'Organisch modern retro: zware zachte schreef, bogen, terracotta en mosterd.'], fonts: 'Fraunces · Figtree', band: '#f0e3cc', bg: '#f0e3cc', card: '#fbf3e4', accent: '#a8492a', ink: '#33231a', onBand: '#33231a', tiles: ['#e8c26a', '#d98c66', '#b3b77e'] },
  { id: 'suite', direction: true, name: ['Suite', 'Suite'], desc: ['From The Convenience Suite: black masthead, sunset stripes, a light serif, orange kickers.', 'Uit The Convenience Suite: zwarte kop, zonsondergangstrepen, lichte schreef, oranje kopjes.'], fonts: 'Newsreader · Figtree', band: '#0d0d0d', bg: '#ffffff', card: '#f8f6f1', accent: '#111111', ink: '#141414', onBand: '#f7f3ea', tiles: ['#f5b335', '#f08a2b', '#e3532b'] },
  // Earlier styles.
  { id: 'larder', name: ['Classic', 'Klassiek'], desc: ['Warm kitchen neutrals, herb green, serif headings.', 'Warme keukentinten, kruidengroen, schreefkoppen.'], band: '#f6f1e9', bg: '#f6f1e9', card: '#fffdf9', accent: '#2f5d50', ink: '#1d2420', onBand: '#1d2420', tiles: ['#dfeae4', '#fbecd2', '#f8e1d8'] },
  { id: 'lavender', name: ['Lavender Glass', 'Lavendelglas'], desc: ['Blue-violet into blush, white glass cards, pastel tiles.', 'Blauwpaars naar roze, witte glazen kaarten, pastel tegels.'], band: 'linear-gradient(170deg, #4747d1, #6c5fea 45%, #c9b8f5)', bg: '#f4f1fc', card: '#ffffff', accent: '#5b5bf0', ink: '#17152e', onBand: '#ffffff', tiles: ['#ece8ff', '#ffe4ea', '#ddf7f0'] },
  { id: 'herb', name: ['Herb Glass', 'Kruidenglas'], desc: ['PantryPip’s green, as glass: deep herb into cream.', 'Het groen van PantryPip als glas: diep kruidengroen naar crème.'], band: 'linear-gradient(170deg, #143b30, #3f8166 45%, #a9d3be)', bg: '#f1f5f0', card: '#ffffff', accent: '#2f7d5b', ink: '#14231c', onBand: '#ffffff', tiles: ['#e2f1e8', '#fcf0d2', '#fbe5dc'] },
  { id: 'citrus', name: ['Citrus Morning', 'Citrusochtend'], desc: ['Peach and cream, tangerine accents, rounder shapes.', 'Perzik en crème, mandarijnaccenten, rondere vormen.'], band: 'linear-gradient(170deg, #ffcfa6, #ffe2c6 50%, #fff3e2)', bg: '#fff8ef', card: '#ffffff', accent: '#c2461a', ink: '#2e1a0e', onBand: '#2e1a0e', tiles: ['#ffe8da', '#fff2c9', '#e9f7df'] },
  { id: 'night', name: ['Night Pantry', 'Nachtvoorraad'], desc: ['Always dark, violet and teal glow, lilac accents.', 'Altijd donker, paarse en groenblauwe gloed, lila accenten.'], band: 'radial-gradient(120% 90% at 0% 0%, #4a37b8, #0d0b1a 70%)', bg: '#0d0b1a', card: '#1b1833', accent: '#a99bff', ink: '#f4f2ff', onBand: '#f4f2ff', tiles: ['#2a2550', '#3d1f27', '#173a33'] },
  { id: 'ink', name: ['Ink & Signal', 'Inkt & Signaal'], desc: ['Flat and high contrast, one strong blue, bold type.', 'Plat en veel contrast, één krachtig blauw, vette letters.'], band: '#f3f4f7', bg: '#f3f4f7', card: '#ffffff', accent: '#2b50e6', ink: '#0f1222', onBand: '#0f1222', tiles: ['#e8edff', '#ffeedd', '#e0f5ea'] },
];

const KEY = 'larder.appearance';
let current: Appearance = {};
const darkQuery = typeof matchMedia === 'function' ? matchMedia('(prefers-color-scheme: dark)') : null;

export const DIRECTIONS = STYLES.filter((s) => s.direction).map((s) => s.id as Direction);
/** The style a new account (or a device that has never signed in) starts with. */
export const DEFAULT_STYLE: Style = 'suite';
export const isDirection = (s: unknown): s is Direction => DIRECTIONS.includes(s as Direction);

/** The design studio's side-by-side frames open the app as /?dz=<direction>&dzmode=light|dark: that look
    for this frame only, nothing saved. */
const preview = (() => {
  try {
    const q = new URLSearchParams(location.search);
    const dz = q.get('dz');
    return isDirection(dz) ? { style: dz, theme: q.get('dzmode') === 'dark' ? 'dark' as const : 'light' as const } : null;
  } catch {
    return null;
  }
})();
export const inPreviewFrame = !!preview;

let painted: Style | undefined;
const listeners = new Set<() => void>();
/** The style on screen now (a preview frame's own one included), for the logo. */
export function usePaintedStyle(): Style | undefined {
  return useSyncExternalStore((f) => (listeners.add(f), () => listeners.delete(f)), () => painted);
}

function paint() {
  const a = preview ? { ...current, ...preview } : current;
  const root = document.documentElement;
  if (a.theme === 'light' || a.theme === 'dark') root.dataset.theme = a.theme;
  else delete root.dataset.theme;
  // Suite is the starting style: also on the sign-in page and before settings have loaded.
  const chosen = a.style ?? DEFAULT_STYLE;
  const direction = isDirection(chosen) ? chosen : null;
  if (chosen !== painted) {
    painted = chosen;
    // The tab icon follows the style; the home-screen icon stays the Suite one (manifest).
    document.querySelector('link[rel="icon"][type="image/svg+xml"]')?.setAttribute('href', logoDataUrl(logoFor(chosen)));
    listeners.forEach((f) => f());
  }
  const style = chosen !== 'larder' && !direction ? chosen : null;
  if (style) root.dataset.style = style;
  else delete root.dataset.style;
  if (direction) root.dataset.direction = direction;
  else delete root.dataset.direction;
  // Which palette a style uses: Night is always dark, others follow the theme (or the system).
  root.dataset.mode = style === 'night' || a.theme === 'dark' || (a.theme !== 'light' && darkQuery?.matches) ? 'dark' : 'light';
  root.dataset.density = a.density ?? 'comfortable';
  root.dataset.cards = a.cards ?? 'soft';
  root.dataset.motion = a.motion ?? 'full';
  root.dataset.text = a.textSize ?? 'normal';
  // Minimalist mode: plain surfaces, no food art, shadows or celebrations (styles.css, Reward).
  if (a.minimal) root.dataset.minimal = 'on';
  else delete root.dataset.minimal;
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', getComputedStyle(root).getPropertyValue(style || direction ? '--topbar-bg' : '--bg').trim() || getComputedStyle(root).getPropertyValue('--bg').trim() || '#f6f1e9');
}
darkQuery?.addEventListener?.('change', paint);

export function applyAppearance(a: Appearance) {
  current = a;
  paint();
  try {
    localStorage.setItem(KEY, JSON.stringify(a));
  } catch {
    /* private mode */
  }
}

export function applyCachedAppearance() {
  try {
    const a = JSON.parse(localStorage.getItem(KEY) ?? 'null');
    if (a) return applyAppearance(a);
  } catch {
    /* ignore */
  }
  paint(); // never signed in here: the starting style
}

/** Spending & waste figures are optional (Settings → General, or the Statistics page). */
export function useShowMoney(): [boolean, (v: boolean) => void] {
  const [look, setLook] = useSetting<any>('me', 'appearance');
  return [look?.showMoney !== false, (v: boolean) => setLook({ showMoney: v })];
}

/** Household interaction preferences, kept current by the app shell. */
export const uiPrefs = { confirmDestructive: false, voiceFirst: true };
