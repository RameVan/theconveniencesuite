import { useEffect, useRef, useState } from 'react';
import { Link2, PenLine, Check, AlertCircle, ClipboardPaste, Mic, Square, Layers, FileUp, ChevronDown, ChevronRight, Loader2, Camera, ImagePlus, X, Plus } from 'lucide-react';
import { useSpeech, useSpeechLang, speechSupported } from './Assistant';
import { ocr, shrink } from './ReceiptSheet';
import type { Lang } from '../i18n';
import { get, post, invalidate } from '../api';
import { useApp } from '../app-context';
import { fmtQty } from '../i18n';
import { Sheet, Stepper, useToast } from './ui';

/**
 * Save a recipe in the fewest steps: paste a link (recipe sites carry the recipe as data) or paste/type it.
 * Ingredients are matched to products, so the recipe works with stock, the shopping list and macros.
 */
export function AddRecipeSheet({ onClose }: { onClose: () => void }) {
  const app = useApp();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const [mode, setMode] = useState<'link' | 'photo' | 'many' | 'type'>('link');
  const [reading, setReading] = useState<{ previews: string[]; progress: number } | null>(null);
  const camera = useRef<HTMLInputElement>(null);
  const upload = useRef<HTMLInputElement>(null);
  const [url, setUrl] = useState('');
  const [form, setForm] = useState({ title: '', servings: 2, minutes: 30, ingredients: '', steps: '' });
  const [draft, setDraft] = useState<any | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const bulk = useBulkImport();

  const run = async (fn: () => Promise<any>) => {
    setBusy(true);
    setError('');
    try {
      setDraft(await fn());
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };
  // Photos and screenshots are read on this device; the text is then split into ingredients and steps.
  const readPhotos = async (files: FileList | null) => {
    if (!files?.length) return;
    setError('');
    let text = '';
    try {
      // Larger than receipts: a long screenshot shrunk to 1600 px makes the text too small to read.
      const images = await Promise.all([...files].slice(0, 6).map((f) => shrink(f, 2400)));
      setReading({ previews: images.map((i) => i.preview), progress: 0 });
      text = await ocr(images, (p) => setReading((r) => r && { ...r, progress: p }));
      setDraft(await post('/api/recipes/photo', { text, lang: app.lang }));
    } catch (e: any) {
      // Nothing recipe-like found: the read text goes into "Type or paste", to fix by hand.
      if (text.trim()) {
        setForm((f) => ({ ...f, ingredients: text.trim() }));
        setMode('type');
      }
      setError(e.message);
    } finally {
      setReading(null);
    }
  };
  const paste = async () => {
    try {
      const t = await navigator.clipboard.readText();
      if (t) setUrl(t.trim());
    } catch {
      /* clipboard not allowed: the user can paste by hand */
    }
  };
  const save = async () => {
    setBusy(true);
    try {
      const r = await saveDraft(draft);
      invalidate(['recipes']);
      onClose();
      toast({ text: nl ? 'Recept bewaard in Mijn recepten' : 'Saved to My recipes' });
      app.navigate(`#/recipe/${r.id}`);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };
  const saveMany = async () => {
    setBusy(true);
    setError('');
    try {
      const n = await bulk.saveChosen();
      invalidate(['recipes']);
      onClose();
      toast({ text: nl ? `${n} recepten bewaard in Mijn recepten` : `${n} recipes saved to My recipes` });
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  const matched = draft ? draft.ingredients.filter((i: any) => i.productId).length : 0;
  const footer = draft ? (
    <div className="row">
      <button className="btn" onClick={() => setDraft(null)}>{nl ? 'Terug' : 'Back'}</button>
      <button className="btn primary grow lg" onClick={save} disabled={busy || !draft.title || !draft.steps.some((s: any) => s.text.trim())}><Check size={18} /> {nl ? 'Bewaren' : 'Save recipe'}</button>
    </div>
  ) : mode === 'link' ? (
    <button className="btn primary block lg" disabled={busy || url.length < 8} onClick={() => run(() => post('/api/recipes/import', { url }))}>{busy ? '…' : nl ? 'Recept ophalen' : 'Get recipe'}</button>
  ) : mode === 'photo' ? null : mode === 'many' ? (
    bulk.items.length ? (
      <div className="row">
        <button className="btn" onClick={bulk.reset} disabled={busy || bulk.running}>{nl ? 'Terug' : 'Back'}</button>
        <button className="btn primary grow lg" onClick={saveMany} disabled={busy || bulk.running || !bulk.chosen}>
          <Check size={18} /> {busy ? (nl ? `Bewaren… ${bulk.saved}/${bulk.chosen}` : `Saving… ${bulk.saved}/${bulk.chosen}`) : nl ? `${bulk.chosen} recepten bewaren` : `Save ${bulk.chosen} recipe${bulk.chosen === 1 ? '' : 's'}`}
        </button>
      </div>
    ) : (
      <button className="btn primary block lg" disabled={!bulk.links.length} onClick={bulk.start}>
        {nl ? `${bulk.links.length} recepten ophalen` : `Get ${bulk.links.length} recipe${bulk.links.length === 1 ? '' : 's'}`}
      </button>
    )
  ) : (
    <button className="btn primary block lg" disabled={busy || !form.ingredients.trim()} onClick={() => run(() => post('/api/recipes/draft', form))}>{nl ? 'Controleren' : 'Check ingredients'}</button>
  );

  return (
    <Sheet title={nl ? 'Recept toevoegen' : 'Add a recipe'} onClose={onClose} footer={footer}>
      {error && <p className="pill tomato" style={{ padding: '8px 12px', display: 'block', marginBottom: 10 }}><AlertCircle size={14} /> {error}</p>}
      {draft ? (
        <div className="stack">
          <input className="input" value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} aria-label={nl ? 'Naam' : 'Name'} />
          <div className="row small">
            <span className="muted">{nl ? 'Porties' : 'Servings'}</span><Stepper value={draft.servings} onChange={(n) => setDraft({ ...draft, servings: n })} label={nl ? 'porties' : 'servings'} />
            <span className="grow" />
            <span className="muted">{draft.prep_minutes + draft.cook_minutes} min{draft.source_name ? ` · ${draft.source_name}` : ''}</span>
          </div>
          <div className="tiny muted">
            {nl ? `${matched} van ${draft.ingredients.length} ingrediënten herkend. Herkende ingrediënten tellen mee voor voorraad, boodschappen en voedingswaarden.` : `${matched} of ${draft.ingredients.length} ingredients recognised. Recognised ones count for stock, shopping and nutrition.`}
          </div>
          <IngredientList ingredients={draft.ingredients} onChange={(ingredients) => setDraft({ ...draft, ingredients })} />
          <StepList steps={draft.steps} guessed={draft.stepsGuessed} onChange={(steps) => setDraft({ ...draft, steps, stepsGuessed: false })} />
        </div>
      ) : reading ? (
        <div className="empty">
          <div className="thumbs" style={{ justifyContent: 'center' }}>
            {reading.previews.map((p, i) => <img key={i} src={p} alt={`${nl ? 'foto' : 'photo'} ${i + 1}`} />)}
          </div>
          <h3><Loader2 size={18} className="spin" /> {nl ? 'Recept lezen…' : 'Reading the recipe…'}</h3>
          {reading.progress > 0 && <div className="progress" style={{ maxWidth: 280, margin: '12px auto' }}><i style={{ width: `${reading.progress * 100}%` }} /></div>}
        </div>
      ) : (
        <div className="stack">
          {!(mode === 'many' && bulk.items.length) && (
            <div className="loc-tabs">
              <button aria-pressed={mode === 'link'} onClick={() => setMode('link')}><Link2 size={15} /> Link</button>
              <button aria-pressed={mode === 'photo'} onClick={() => setMode('photo')}><Camera size={15} /> {nl ? 'Foto' : 'Photo'}</button>
              <button aria-pressed={mode === 'many'} onClick={() => setMode('many')}><Layers size={15} /> {nl ? 'Meerdere' : 'Many'}</button>
              <button aria-pressed={mode === 'type'} onClick={() => setMode('type')}><PenLine size={15} /> {nl ? 'Typen' : 'Type'}</button>
            </div>
          )}
          {mode === 'link' ? (
            <>
              <div className="row">
                <input className="input grow" type="url" inputMode="url" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://…" aria-label={nl ? 'Link naar recept' : 'Recipe link'} autoFocus />
                <button className="btn" onClick={paste} aria-label={nl ? 'Plakken' : 'Paste'}><ClipboardPaste size={16} /></button>
              </div>
              <p className="tiny muted">{nl ? 'Werkt met de meeste receptensites (Allerhande, Jumbo, BBC Good Food, blogs…). Lukt het niet? Maak een screenshot en kies “Foto”, of kies “Typen”.' : 'Works with most recipe sites (BBC Good Food, Allerhande, blogs…). If it can’t read a page, take a screenshot and choose “Photo”, or choose “Type”.'}</p>
            </>
          ) : mode === 'photo' ? (
            <div className="dropzone">
              <div style={{ fontSize: 40 }} aria-hidden>📸</div>
              <div className="small muted">{nl ? 'Maak een foto van een kookboek of kies screenshots van een recept. Past het niet op één scherm? Kies alle screenshots, in volgorde.' : 'Take a photo of a cookbook page or choose screenshots of a recipe. Doesn’t fit on one screen? Choose all the screenshots, in order.'}</div>
              <div className="row wrap" style={{ justifyContent: 'center' }}>
                <button className="btn primary" onClick={() => camera.current?.click()}><Camera size={18} /> {nl ? 'Foto maken' : 'Take photo'}</button>
                <button className="btn" onClick={() => upload.current?.click()}><ImagePlus size={18} /> {nl ? 'Screenshot kiezen' : 'Choose screenshot'}</button>
              </div>
              <input ref={camera} type="file" accept="image/*" capture="environment" hidden onChange={(e) => { readPhotos(e.target.files); e.target.value = ''; }} />
              <input ref={upload} type="file" accept="image/*" multiple hidden onChange={(e) => { readPhotos(e.target.files); e.target.value = ''; }} />
              <p className="tiny muted">{nl ? 'De foto wordt op dit apparaat gelezen, zonder AI (de eerste keer laadt het taalmodel, ~10 MB). Je controleert alles voor het bewaren.' : 'The photo is read on this device, without AI (the first time downloads the text model, ~10 MB). You check everything before saving.'}</p>
            </div>
          ) : mode === 'many' ? (
            <BulkImport bulk={bulk} />
          ) : (
            <>
              <OneLine />
              <div className="tiny muted" style={{ textAlign: 'center' }}>{nl ? '— of vul het helemaal in —' : '— or write it out —'}</div>
              <input className="input" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder={nl ? 'Naam, bijv. Oma’s stoofvlees' : 'Name, e.g. Gran’s stew'} aria-label={nl ? 'Naam' : 'Name'} />
              <div className="row small">
                <span className="muted">{nl ? 'Porties' : 'Servings'}</span><Stepper value={form.servings} onChange={(n) => setForm({ ...form, servings: n })} label={nl ? 'porties' : 'servings'} />
                <span className="grow" />
                <span className="muted">min</span>
                <input className="input" style={{ width: 80 }} inputMode="numeric" value={form.minutes} onChange={(e) => setForm({ ...form, minutes: Number(e.target.value.replace(/\D/g, '')) || 0 })} aria-label={nl ? 'Minuten' : 'Minutes'} />
              </div>
              <Dictate lang={app.lang} label={nl ? 'Ingrediënten inspreken' : 'Say the ingredients'} onText={(t) => setForm((f) => ({ ...f, ingredients: t }))} base={form.ingredients} />
              <textarea className="input" rows={6} value={form.ingredients} onChange={(e) => setForm({ ...form, ingredients: e.target.value })} placeholder={nl ? 'Eén ingrediënt per regel\n500 g kipfilet\n2 el olijfolie\n1 ui' : 'One ingredient per line\n500 g chicken breast\n2 tbsp olive oil\n1 onion'} aria-label={nl ? 'Ingrediënten' : 'Ingredients'} />
              <Dictate lang={app.lang} label={nl ? 'Stappen inspreken' : 'Say the steps'} onText={(t) => setForm((f) => ({ ...f, steps: t }))} base={form.steps} />
              <textarea className="input" rows={4} value={form.steps} onChange={(e) => setForm({ ...form, steps: e.target.value })} placeholder={nl ? 'Stappen (optioneel), één per regel' : 'Steps (optional), one per line'} aria-label={nl ? 'Stappen' : 'Steps'} />
            </>
          )}
        </div>
      )}
    </Sheet>
  );
}

/** "Chicken fajitas with peppers, onion, rice and avocado" → a recipe with amounts and a method. */
function OneLine() {
  const app = useApp();
  const nl = app.lang === 'nl';
  const toast = useToast();
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const make = async () => {
    setBusy(true);
    try {
      const r = await post('/api/recipes/quick', { text, lang: app.lang });
      invalidate(['recipes']);
      toast({ text: nl ? `${r.recipe.title} bewaard${r.guessed ? ': hoeveelheden geschat' : ''}` : `Saved ${r.recipe.title}${r.guessed ? ': amounts estimated' : ''}` });
      app.navigate(`#/recipe/${r.recipe.id}`);
    } catch (e: any) {
      toast({ text: e.message, error: true });
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="stack" style={{ gap: 6 }}>
      <span className="small"><b>{nl ? 'In één zin' : 'In one line'}</b></span>
      <div className="row">
        <input className="input grow" value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && text.trim().length > 2 && make()} placeholder={nl ? 'kip fajitas met paprika, ui, rijst en avocado' : 'chicken fajitas with peppers, onion, rice and avocado'} aria-label={nl ? 'Recept in één zin' : 'Recipe in one line'} />
        <button className="btn primary" disabled={busy || text.trim().length < 3} onClick={make}>{busy ? '…' : nl ? 'Maak' : 'Make it'}</button>
      </div>
      <span className="tiny muted">{nl ? 'Hoeveelheden en werkwijze komen van een vergelijkbaar recept, of een normale portie. Je kunt het daarna aanpassen.' : 'Amounts and method come from a similar recipe, or a normal portion. You can adjust it afterwards.'}</span>
    </div>
  );
}

async function saveDraft(draft: any) {
  const r = await post('/api/recipes', {
    title: draft.title, summary: draft.summary, cuisine: draft.cuisine, servings: draft.servings, prep_minutes: draft.prep_minutes, cook_minutes: draft.cook_minutes,
    emoji: draft.emoji, image_url: draft.image_url, source_url: draft.source_url, source_name: draft.source_name, steps: draft.steps.filter((s: any) => s.text.trim()),
    ingredients: draft.ingredients.map((i: any) => ({ name: i.productName ?? i.name, productId: i.productId, quantity: i.quantity, unit: i.unit, display: i.line, optional: i.optional })),
  });
  await post(`/api/recipes/${r.id}/interaction`, { saved: true });
  return r;
}

// ---- Bulk import: many links (or a browser bookmarks file) at once ----

const MAX_LINKS = 50;
const AT_ONCE = 3; // fetched in parallel; gentle on recipe sites and on a phone connection

/** The same page however it was shared: no tracking parameters, fragment or trailing slash. */
export function linkKey(u: string) {
  try {
    const x = new URL(u);
    for (const k of [...x.searchParams.keys()]) if (/^(utm_|fbclid|gclid|mc_|ref$|source$)/i.test(k)) x.searchParams.delete(k);
    return `${x.hostname.replace(/^www\./, '').toLowerCase()}${x.pathname.replace(/\/+$/, '')}${x.search}`;
  } catch {
    return u;
  }
}

/** Every distinct http(s) link in pasted text or an exported bookmarks file. */
export function extractLinks(text: string): string[] {
  const out = new Map<string, string>();
  for (let m of text.match(/https?:\/\/[^\s"'<>]+/gi) ?? []) {
    m = m.replace(/&amp;/g, '&').replace(/[),.;:!?\]]+$/, '');
    try {
      new URL(m);
    } catch {
      continue;
    }
    const k = linkKey(m);
    if (!out.has(k)) out.set(k, m);
  }
  return [...out.values()];
}

type BulkItem = { url: string; status: 'waiting' | 'loading' | 'ok' | 'failed' | 'duplicate'; draft?: any; error?: string; pick: boolean };

function useBulkImport() {
  const [text, setText] = useState('');
  const [items, setItems] = useState<BulkItem[]>([]);
  const [running, setRunning] = useState(false);
  const [saved, setSaved] = useState(0);
  const latest = useRef(items);
  latest.current = items;
  const all = extractLinks(text);
  const links = all.slice(0, MAX_LINKS);
  const update = (url: string, patch: Partial<BulkItem>) => setItems((cur) => cur.map((i) => (i.url === url ? { ...i, ...patch } : i)));

  const start = async () => {
    setRunning(true);
    let known = new Set<string>();
    try {
      known = new Set(((await get<{ urls: string[] }>('/api/recipes/imported')).urls ?? []).map(linkKey));
    } catch {
      /* without the list, duplicates are simply not flagged */
    }
    const list: BulkItem[] = links.map((url) => ({ url, status: known.has(linkKey(url)) ? 'duplicate' : 'waiting', pick: false }));
    setItems(list);
    const queue = list.filter((i) => i.status === 'waiting').map((i) => i.url);
    const worker = async () => {
      for (let url = queue.shift(); url; url = queue.shift()) {
        update(url, { status: 'loading' });
        try {
          const draft = await post('/api/recipes/import', { url });
          update(url, { status: 'ok', draft, pick: true });
        } catch (e: any) {
          update(url, { status: 'failed', error: e.code === 'no_recipe' ? 'no_recipe' : e.code === 'fetch_failed' ? 'unreachable' : e.message });
        }
      }
    };
    await Promise.all(Array.from({ length: AT_ONCE }, worker));
    setRunning(false);
  };

  const saveChosen = async () => {
    let n = 0;
    setSaved(0);
    // The latest items: drafts can be edited between fetching and saving.
    const chosen = latest.current.filter((i) => i.pick && i.draft);
    for (const i of chosen) {
      await saveDraft(i.draft);
      n++;
      setSaved(n);
      update(i.url, { pick: false, status: 'duplicate' });
    }
    return n;
  };

  return {
    text, setText, links, tooMany: all.length > MAX_LINKS, items, running, saved, start, saveChosen, update,
    chosen: items.filter((i) => i.pick && i.draft).length,
    reset: () => setItems([]),
  };
}

const failReason = (e: string | undefined, nl: boolean) =>
  e === 'no_recipe' ? (nl ? 'Geen recept op deze pagina' : 'No recipe on this page') : e === 'unreachable' ? (nl ? 'Pagina niet te openen' : 'Couldn’t open this page') : e;

function BulkImport({ bulk }: { bulk: ReturnType<typeof useBulkImport> }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const file = useRef<HTMLInputElement>(null);
  const [open, setOpen] = useState<string | null>(null);

  if (!bulk.items.length) {
    const readFile = async (f?: File | null) => {
      if (!f) return;
      const t = await f.text();
      bulk.setText((cur) => `${cur.trim()}\n${t}`.trim());
    };
    return (
      <>
        <textarea className="input" rows={7} value={bulk.text} onChange={(e) => bulk.setText(e.target.value)} placeholder={nl ? 'Plak links, één per regel (of gewoon een hele lijst of notitie)' : 'Paste links, one per line (or a whole list or note)'} aria-label={nl ? 'Links naar recepten' : 'Recipe links'} autoFocus />
        <div className="row">
          <button className="btn" onClick={() => file.current?.click()}><FileUp size={16} /> {nl ? 'Bladwijzerbestand kiezen' : 'Choose bookmarks file'}</button>
          <input ref={file} type="file" accept=".html,.htm,.txt,.csv,.md" hidden onChange={(e) => { readFile(e.target.files?.[0]); e.target.value = ''; }} />
          <span className="grow" />
          <span className="small muted">{bulk.links.length} {nl ? 'links' : bulk.links.length === 1 ? 'link' : 'links'}</span>
        </div>
        {bulk.tooMany && <p className="tiny muted">{nl ? `De eerste ${MAX_LINKS} links worden opgehaald. Doe de rest daarna.` : `The first ${MAX_LINKS} links are fetched now. Do the rest afterwards.`}</p>}
        <p className="tiny muted">{nl ? 'Je kunt je bladwijzers exporteren vanuit je browser (Bladwijzers → Exporteren). Pagina’s zonder recept worden overgeslagen, en recepten die je al hebt ook.' : 'Export your bookmarks from your browser (Bookmarks → Export). Pages without a recipe are skipped, and so are recipes you already have.'}</p>
      </>
    );
  }

  const count = (s: BulkItem['status']) => bulk.items.filter((i) => i.status === s).length;
  const done = bulk.items.length - count('waiting') - count('loading');
  const order = { ok: 0, loading: 1, waiting: 2, failed: 3, duplicate: 4 } as const;
  const sorted = [...bulk.items].sort((a, b) => order[a.status] - order[b.status]);
  return (
    <>
      <div className="small">
        {bulk.running ? <><Loader2 size={14} className="spin" /> {nl ? `Ophalen… ${done} van ${bulk.items.length}` : `Fetching… ${done} of ${bulk.items.length}`}</> : nl ? `${count('ok')} recepten gevonden` : `${count('ok')} recipe${count('ok') === 1 ? '' : 's'} found`}
        <span className="muted">
          {count('failed') ? (nl ? ` · ${count('failed')} overgeslagen` : ` · ${count('failed')} skipped`) : ''}
          {count('duplicate') ? (nl ? ` · ${count('duplicate')} al bewaard` : ` · ${count('duplicate')} already saved`) : ''}
        </span>
      </div>
      <div className="list">
        {sorted.map((i) => {
          const host = (() => { try { return new URL(i.url).hostname.replace(/^www\./, ''); } catch { return i.url; } })();
          if (i.status !== 'ok') {
            return (
              <div key={i.url} className="item bulk-row muted" style={{ minHeight: 0, padding: '8px 12px' }}>
                {i.status === 'loading' || i.status === 'waiting' ? <Loader2 size={16} className={i.status === 'loading' ? 'spin' : ''} /> : <span className={`dot ${i.status === 'failed' ? 'missing' : 'have'}`} />}
                <div className="grow" style={{ minWidth: 0 }}>
                  <div className="small ellipsis">{host}</div>
                  <div className="tiny ellipsis">{i.status === 'failed' ? failReason(i.error, nl) : i.status === 'duplicate' ? (nl ? 'Al in Mijn recepten' : 'Already in My recipes') : i.url}</div>
                </div>
              </div>
            );
          }
          const d = i.draft;
          const m = d.ingredients.filter((x: any) => x.productId).length;
          const isOpen = open === i.url;
          return (
            <div key={i.url} className="bulk-recipe">
              <div className="item bulk-row" style={{ minHeight: 0, padding: '8px 12px' }}>
                <input type="checkbox" checked={i.pick} onChange={(e) => bulk.update(i.url, { pick: e.target.checked })} aria-label={nl ? `${d.title} bewaren` : `Save ${d.title}`} />
                <button className="grow bulk-open" onClick={() => setOpen(isOpen ? null : i.url)} aria-expanded={isOpen}>
                  <span className="small" style={{ display: 'block', fontWeight: 600 }}>{d.emoji} {d.title}</span>
                  <span className="tiny muted">{host} · {nl ? `${m}/${d.ingredients.length} herkend` : `${m}/${d.ingredients.length} recognised`}{m < d.ingredients.length ? (nl ? ' · tik om te koppelen' : ' · tap to match') : ''}</span>
                </button>
                {isOpen ? <ChevronDown size={18} /> : <ChevronRight size={18} />}
              </div>
              {isOpen && (
                <div className="bulk-detail">
                  <input className="input" value={d.title} onChange={(e) => bulk.update(i.url, { draft: { ...d, title: e.target.value } })} aria-label={nl ? 'Naam' : 'Name'} />
                  <IngredientList ingredients={d.ingredients} onChange={(ingredients) => bulk.update(i.url, { draft: { ...d, ingredients } })} />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </>
  );
}

/** Ingredients of a draft; unrecognised ones can be matched to a product by hand. */
let productsCache: Promise<any[]> | null = null;
function IngredientList({ ingredients, onChange }: { ingredients: any[]; onChange: (next: any[]) => void }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const [products, setProducts] = useState<any[] | null>(null);
  const load = () => {
    if (products) return;
    productsCache ??= get<any[]>('/api/products').catch(() => ((productsCache = null), []));
    productsCache.then((list) => setProducts([...list].sort((a, b) => (nl ? a.name_nl ?? a.name : a.name).localeCompare(nl ? b.name_nl ?? b.name : b.name))));
  };
  // Load the product list up front: on a phone the picker opens on the same tap.
  useEffect(() => {
    if (ingredients.some((i) => !i.productId)) load();
  }, []);
  const set = (k: number, patch: any) => onChange(ingredients.map((x, j) => (j === k ? { ...x, ...patch } : x)));
  return (
    <div className="list">
      {ingredients.map((i: any, k: number) => (
        <div key={k} className="item" style={{ minHeight: 0, padding: '8px 12px' }}>
          <span className={`dot ${i.productId ? 'have' : 'missing'}`} />
          <div className="grow" style={{ minWidth: 0 }}>
            <div className="small">{i.line}</div>
            {i.productId ? (
              <div className="tiny muted">
                → {i.productName}{i.quantity != null ? ` · ${fmtQty(i.quantity, i.unit, app.lang)}` : ''}{i.optional ? (nl ? ' · optioneel' : ' · optional') : ''}
                {i.manual && <> · <button className="link-btn" onClick={() => set(k, { productId: null, productName: null, unit: null, manual: false })}>{nl ? 'ongedaan maken' : 'undo'}</button></>}
              </div>
            ) : (
              <select className="input sm match-select" value="" onFocus={load} onPointerDown={load} onChange={(e) => {
                const p = products?.find((x) => x.id === e.target.value);
                if (p) set(k, { productId: p.id, productName: nl ? p.name_nl ?? p.name : p.name, unit: p.unit, quantity: null, manual: true });
              }} aria-label={nl ? `Koppel “${i.line}” aan een product` : `Match “${i.line}” to a product`}>
                <option value="">{nl ? 'Niet herkend: koppel aan…' : 'Not recognised: match to…'}</option>
                {(products ?? []).map((p) => <option key={p.id} value={p.id}>{nl ? p.name_nl ?? p.name : p.name}</option>)}
              </select>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

const timerOf = (text: string) => {
  const m = text.match(/(\d+)\s*(?:-\s*\d+\s*)?(minutes|minute|mins|min|minuten|minuut)\b/i);
  return m ? Number(m[1]) * 60 : undefined;
};

/** The method, one step at a time: fix what the photo misread, remove or add steps. */
function StepList({ steps, guessed, onChange }: { steps: { text: string; timerSeconds?: number }[]; guessed?: boolean; onChange: (next: { text: string; timerSeconds?: number }[]) => void }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const set = (k: number, text: string) => onChange(steps.map((s, j) => (j === k ? { text, timerSeconds: timerOf(text) } : s)));
  return (
    <div className="stack" style={{ gap: 6 }}>
      <span className="small"><b>{nl ? 'Bereiding' : 'Method'}</b> <span className="muted">· {steps.length} {nl ? 'stappen' : steps.length === 1 ? 'step' : 'steps'}</span></span>
      {guessed && <p className="tiny muted">{nl ? 'Geen bereiding op de foto gevonden: dit is een eenvoudige werkwijze op basis van de ingrediënten. Pas aan waar nodig.' : 'No method found in the photo: this is a plain method based on the ingredients. Adjust where needed.'}</p>}
      {steps.map((s, k) => (
        <div key={k} className="row" style={{ alignItems: 'flex-start', gap: 8 }}>
          <span className="pill grey" style={{ minWidth: 28, justifyContent: 'center', marginTop: 6 }}>{k + 1}</span>
          <textarea className="input grow" rows={Math.min(5, Math.max(2, Math.ceil(s.text.length / 38)))} value={s.text} onChange={(e) => set(k, e.target.value)} aria-label={nl ? `Stap ${k + 1}` : `Step ${k + 1}`} />
          <button className="btn ghost sm" onClick={() => onChange(steps.filter((_, j) => j !== k))} aria-label={nl ? `Stap ${k + 1} weghalen` : `Remove step ${k + 1}`}><X size={16} /></button>
        </div>
      ))}
      <button className="btn sm ghost" style={{ alignSelf: 'flex-start' }} onClick={() => onChange([...steps, { text: '' }])}><Plus size={15} /> {nl ? 'Stap toevoegen' : 'Add step'}</button>
    </div>
  );
}

/** Dictate into a field: keeps listening through pauses until you tap stop or say "done". */
function Dictate({ lang, label, base, onText }: { lang: Lang; label: string; base: string; onText: (t: string) => void }) {
  const [speechLang] = useSpeechLang(lang);
  // What was in the field when you tapped the mic; dictation is added after it.
  const before = useRef('');
  const speech = useSpeech(speechLang, (t) => onText(before.current + t), { list: true, onText: (t) => onText(before.current + t) });
  if (!speechSupported) return null;
  return (
    <button type="button" className={`btn sm ${speech.listening ? 'listening-btn' : 'ghost'}`} style={{ alignSelf: 'flex-start' }} onClick={() => { if (speech.listening) return speech.stop(); before.current = base ? `${base.trim()} ` : ''; speech.start(); }}>
      {speech.listening ? <Square size={14} fill="currentColor" /> : <Mic size={15} />} {speech.listening ? (lang === 'nl' ? 'Stop' : 'Stop') : label}
    </button>
  );
}
