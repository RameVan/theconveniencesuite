import { useEffect, useState } from 'react';
import { post, invalidate } from '../api';
import { useApp } from '../app-context';

/** How easy it was and whether you'd make it again: both steer the week planner. */
export function AfterCooking({ recipeId, ease, again, compact }: { recipeId: string; ease: number | null; again: number | boolean | null; compact?: boolean }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const [e, setE] = useState(ease);
  const [a, setA] = useState(again == null ? null : !!again);
  // Answers given elsewhere (the reward after cooking) show up here too.
  useEffect(() => setE(ease), [ease]);
  useEffect(() => setA(again == null ? null : !!again), [again]);
  const save = async (patch: { ease?: number | null; again?: boolean | null }) => {
    await post(`/api/recipes/${recipeId}/interaction`, patch);
    invalidate(['recipes']);
  };
  const EASE: [number, string, string][] = [[1, 'Easy', 'Makkelijk'], [2, 'Okay', 'Te doen'], [3, 'Hard', 'Lastig']];
  return (
    <div className={`after-cooking ${compact ? 'compact' : ''}`}>
      <div className="stack" style={{ gap: 4 }}>
        <span className="tiny muted">{nl ? 'Hoe makkelijk was het?' : 'How easy was it?'}</span>
        <div className="seg" role="radiogroup" aria-label={nl ? 'Hoe makkelijk' : 'How easy'}>
          {EASE.map(([v, en, nlL]) => (
            <button key={v} role="radio" aria-checked={e === v} className={e === v ? 'on' : ''} onClick={() => { const n = e === v ? null : v; setE(n); save({ ease: n }); }}>{nl ? nlL : en}</button>
          ))}
        </div>
      </div>
      <div className="stack" style={{ gap: 4 }}>
        <span className="tiny muted">{nl ? 'Zou je het nog eens maken?' : 'Would you make it again?'}</span>
        <div className="seg" role="radiogroup" aria-label={nl ? 'Nog eens maken' : 'Make it again'}>
          {([[true, 'Yes', 'Ja'], [false, 'No', 'Nee']] as const).map(([v, en, nlL]) => (
            <button key={en} role="radio" aria-checked={a === v} className={a === v ? 'on' : ''} onClick={() => { const n = a === v ? null : v; setA(n); save({ again: n }); }}>{nl ? nlL : en}</button>
          ))}
        </div>
      </div>
    </div>
  );
}
