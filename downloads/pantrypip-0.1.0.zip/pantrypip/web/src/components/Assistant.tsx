import { useCallback, useEffect, useRef, useState } from 'react';
import { Mic, Send, Undo2, Sparkles, Plus, ChefHat, ShoppingBasket } from 'lucide-react';
import { post, requestId, invalidate } from '../api';
import { useApp, SCOPES_ALL } from '../app-context';
import { useT, type Lang } from '../i18n';
import { Sheet, useToast } from './ui';

// ---------- Speech recognition (browser-native; works offline on some devices) ----------
type SR = any;
const SpeechRecognitionImpl: any = typeof window !== 'undefined' ? (window as any).SpeechRecognition ?? (window as any).webkitSpeechRecognition : undefined;
export const speechSupported = !!SpeechRecognitionImpl;

/** Join the results of one recognition session. Android Chrome repeats earlier text in each result, so skip repeats. */
function joinResults(results: any): string {
  let out = '';
  for (let i = 0; i < results.length; i++) {
    const t = String(results[i]?.[0]?.transcript ?? '').trim();
    if (!t) continue;
    const lo = out.toLowerCase();
    const tl = t.toLowerCase();
    if (lo && tl.startsWith(lo)) out = t;
    else if (!lo.endsWith(tl)) out = out ? `${out} ${t}` : t;
  }
  return out;
}

const DONE_WORDS = /\b(that'?s it|that'?s all|i'?m done|done|klaar|dat was het|dat is alles)\s*[.!]?$/i;

/**
 * Speech recognition that waits for you. Browsers end recognition at the first pause (iPhone: often before
 * you've started), so this keeps listening through short silences, restarts when the browser gives up early,
 * and only submits after you've stopped talking. In list mode it keeps going until you tap stop or say "done".
 */
export function useSpeech(lang: Lang, onFinal: (text: string) => void, opts: { list?: boolean; onText?: (text: string) => void } = {}) {
  const [listening, setListening] = useState(false);
  const [interim, setInterim] = useState('');
  // Some browsers expose speech recognition but refuse it (iPhone home-screen apps, no Siri, no mic permission).
  const [blocked, setBlocked] = useState(false);
  const [unheard, setUnheard] = useState(false);
  const cb = useRef({ onFinal, onText: opts.onText, list: !!opts.list });
  cb.current = { onFinal, onText: opts.onText, list: !!opts.list };
  const st = useRef({ rec: null as SR | null, active: false, committed: '', session: '', startedAt: 0, heard: false, silence: 0, giveUp: 0 });

  const text = () => [st.current.committed, st.current.session].filter(Boolean).join(' ').trim();

  const finish = useCallback((submit: boolean) => {
    const s = st.current;
    if (!s.active) return;
    s.active = false;
    clearTimeout(s.silence);
    clearTimeout(s.giveUp);
    try {
      s.rec?.abort();
    } catch {}
    const full = text();
    setListening(false);
    setInterim('');
    if (!full && !s.heard) setUnheard(true);
    if (submit && full) cb.current.onFinal(full);
  }, []);

  const begin = useCallback((): boolean => {
    const s = st.current;
    const rec = new SpeechRecognitionImpl();
    rec.lang = lang === 'nl' ? 'nl-NL' : 'en-US';
    rec.interimResults = true;
    rec.continuous = true;
    rec.maxAlternatives = 1;
    s.session = '';
    rec.onresult = (e: any) => {
      if (s.rec !== rec || !s.active) return;
      s.session = joinResults(e.results);
      const full = text();
      if (!full) return;
      s.heard = true;
      setUnheard(false);
      setInterim(full);
      cb.current.onText?.(full);
      clearTimeout(s.giveUp);
      clearTimeout(s.silence);
      if (cb.current.list) {
        if (DONE_WORDS.test(full)) finish(true);
        return;
      }
      // Submit once you've stopped talking; a little longer while the browser still thinks you're mid-sentence.
      const last = e.results[e.results.length - 1];
      s.silence = window.setTimeout(() => finish(true), last?.isFinal ? 1300 : 2000);
    };
    rec.onerror = (e: any) => {
      if (['not-allowed', 'service-not-allowed', 'audio-capture'].includes(e?.error)) {
        setBlocked(true);
        finish(false);
      }
      // "no-speech", "network", "aborted": onend decides whether to keep going.
    };
    rec.onend = () => {
      if (s.rec !== rec || !s.active) return;
      s.committed = text();
      s.session = '';
      const waited = Date.now() - s.startedAt;
      // Keep listening: always in list mode; in command mode until something was heard (up to 12 s).
      if (cb.current.list || (!s.heard && waited < 12000)) {
        window.setTimeout(() => {
          if (!s.active) return;
          try {
            begin();
          } catch {
            finish(true);
          }
        }, 120);
      } else finish(true);
    };
    s.rec = rec;
    rec.start();
    return true;
  }, [lang, finish]);

  const start = useCallback((keep = false) => {
    if (!SpeechRecognitionImpl) return false;
    const s = st.current;
    try {
      s.rec?.abort();
    } catch {}
    // Our own spoken reply would be heard as input (and iOS won't record while speaking).
    if ('speechSynthesis' in window) window.speechSynthesis.cancel();
    Object.assign(s, { active: true, committed: keep ? s.committed : '', session: '', startedAt: Date.now(), heard: keep && !!s.committed });
    setBlocked(false);
    setUnheard(false);
    try {
      begin();
    } catch {
      s.active = false;
      setListening(false);
      setBlocked(true);
      return false;
    }
    setListening(true);
    navigator.vibrate?.(15);
    if (!cb.current.list) {
      clearTimeout(s.giveUp);
      s.giveUp = window.setTimeout(() => !s.heard && finish(false), 12000);
    }
    return true;
  }, [begin, finish]);

  const stop = useCallback(() => finish(true), [finish]);
  /** Replace what has been heard so far (list mode: the text box was edited). */
  const setHeard = useCallback((t: string) => {
    st.current.committed = t;
    st.current.session = '';
  }, []);
  useEffect(() => () => {
    st.current.active = false;
    try {
      st.current.rec?.abort();
    } catch {}
  }, []);
  return { listening, interim, start, stop, blocked, unheard, setHeard };
}

/** Speech language, separate from the app language: an English app with Dutch groceries is common. */
export function useSpeechLang(appLang: Lang): [Lang, () => void] {
  const [l, setL] = useState<Lang>(() => {
    try {
      const v = localStorage.getItem('larder.speechLang');
      if (v === 'en' || v === 'nl') return v;
    } catch {}
    return appLang;
  });
  const toggle = () => {
    const next: Lang = l === 'nl' ? 'en' : 'nl';
    setL(next);
    try {
      localStorage.setItem('larder.speechLang', next);
    } catch {}
  };
  return [l, toggle];
}

function speak(text: string, lang: Lang) {
  if (!('speechSynthesis' in window) || !text) return;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text.replace(/[()]/g, ''));
  u.lang = lang === 'nl' ? 'nl-NL' : 'en-US';
  u.rate = 1.08;
  window.speechSynthesis.speak(u);
}

// ---------- Conversation ----------
interface Msg {
  id: string;
  role: 'me' | 'bot';
  text: string;
  actions?: { kind: string; label: string }[];
  clarify?: { question: string; options: { label: string; value: string }[] } | null;
  data?: { kind: string; items: any[] } | null;
  batchId?: string | null;
  via?: string;
  undone?: boolean;
}

const HINTS: Record<Lang, string[]> = {
  en: ['I finished the milk', 'I bought 6 eggs', 'Add coffee to the list', "What's running low?", 'What can I cook?', 'I used 200 g chicken'],
  nl: ['De melk is op', 'Ik heb 6 eieren gekocht', 'Zet koffie op de lijst', 'Wat raakt op?', 'Wat kan ik koken?', 'Ik heb 200 g kip gebruikt'],
};

export function AssistantSheet({ onClose, startListening, initialText, context }: { onClose: () => void; startListening?: boolean; initialText?: string; context?: string }) {
  const app = useApp();
  const t = useT();
  const toast = useToast();
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const conv = useRef<string | null>(sessionStorage.getItem('larder.conv'));
  const voiceTurn = useRef(false);
  const scroller = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const closeTimer = useRef<number>();

  const send = useCallback(
    async (value: string, label?: string) => {
      const v = value.trim();
      if (!v) return;
      clearTimeout(closeTimer.current);
      setText('');
      setMsgs((m) => [...m, { id: requestId(), role: 'me', text: label ?? v }]);
      setBusy(true);
      try {
        const r = await post('/api/assistant', { text: v, conversationId: conv.current, lang: app.lang, context, clientRequestId: requestId() });
        conv.current = r.conversationId;
        sessionStorage.setItem('larder.conv', r.conversationId);
        setMsgs((m) => [...m, { id: r.turnId, role: 'bot', text: r.reply, actions: r.actions, clarify: r.clarify, data: r.data, batchId: r.batchId, via: r.via }]);
        if (r.actions?.length) invalidate(SCOPES_ALL);
        if (voiceTurn.current) speak(r.clarify ? `${r.reply} ${r.clarify.question}` : r.reply, r.lang);
        if (r.clientAction === 'open_receipt') {
          onClose();
          app.openReceipt();
        } else if (r.clientAction === 'open_barcode') {
          onClose();
          app.openBarcode();
        }
        // "Say it and go": a voice command that was fully handled closes the panel by itself, with undo in a toast.
        if (voiceTurn.current && r.actions?.length && !r.clarify && !r.data) {
          closeTimer.current = window.setTimeout(() => {
            onClose();
            toast({
              text: r.reply,
              undo: r.batchId ? async () => {
                await post('/api/assistant/undo', { batchId: r.batchId });
                invalidate(SCOPES_ALL);
              } : undefined,
            });
          }, 2200);
        }
      } catch (e: any) {
        setMsgs((m) => [...m, { id: requestId(), role: 'bot', text: e.message ?? 'Something went wrong' }]);
      } finally {
        setBusy(false);
      }
    },
    [app, context, onClose, toast],
  );

  const [speechLang, toggleSpeechLang] = useSpeechLang(app.lang);
  const speech = useSpeech(speechLang, (finalText) => {
    voiceTurn.current = true;
    send(finalText);
  });

  useEffect(() => {
    if (initialText) {
      send(initialText);
      return () => clearTimeout(closeTimer.current);
    }
    // If a planned meal is waiting for its daily check-in, the assistant asks about it first
    // ("Did you cook X tonight?"), so "yes" or "no" is all you need to say.
    let cancelled = false;
    // Safari only grants the microphone right after a tap, so start listening now, not after the network round trip.
    const listeningNow = !!(startListening && speechSupported && speech.start());
    post('/api/assistant/greet', { conversationId: conv.current, lang: app.lang })
      .then((r) => {
        if (cancelled) return;
        const g = r.greeting;
        if (!g) return;
        conv.current = g.conversationId;
        sessionStorage.setItem('larder.conv', g.conversationId);
        setMsgs([{ id: g.turnId, role: 'bot', text: '', clarify: g.clarify }]);
        if (listeningNow) voiceTurn.current = true; // the question is on screen; "yes" / "no" answers it
        else if (startListening && speechSupported) {
          voiceTurn.current = true;
          // Ask out loud, then listen for the answer.
          if ('speechSynthesis' in window) {
            const u = new SpeechSynthesisUtterance(g.clarify.question);
            u.lang = app.lang === 'nl' ? 'nl-NL' : 'en-US';
            u.onend = () => !cancelled && speech.start();
            speechSynthesis.speak(u);
          } else speech.start();
        }
      })
      .catch(() => {});
    return () => {
      cancelled = true;
      clearTimeout(closeTimer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight, behavior: 'smooth' });
  }, [msgs, speech.interim]);

  const undo = async (m: Msg) => {
    await post('/api/assistant/undo', { batchId: m.batchId });
    setMsgs((all) => all.map((x) => (x.id === m.id ? { ...x, undone: true } : x)));
    invalidate(SCOPES_ALL);
  };

  const last = msgs[msgs.length - 1];
  return (
    <Sheet
      title={
        <span className="row">
          <Sparkles size={20} color="var(--herb)" /> {app.lang === 'nl' ? 'Assistent' : 'Assistant'}
          {speechSupported && (
            <button type="button" className="chip speech-lang" onClick={toggleSpeechLang} aria-label={app.lang === 'nl' ? `Spraaktaal: ${speechLang === 'nl' ? 'Nederlands' : 'Engels'}. Tik om te wisselen.` : `Speech language: ${speechLang === 'nl' ? 'Dutch' : 'English'}. Tap to switch.`}>
              <Mic size={12} /> {speechLang.toUpperCase()}
            </button>
          )}
        </span>
      }
      onClose={onClose}
      className="assistant"
    >
      <div ref={scroller} style={{ display: 'flex', flexDirection: 'column', gap: 10, maxHeight: '56dvh', overflowY: 'auto', paddingBottom: 6 }}>
        {!msgs.length && !speech.listening && (
          <div className="stack" style={{ padding: '4px 0 8px' }}>
            <button type="button" className="btn list-entry" onClick={() => { onClose(); app.openBoughtList({ listen: speechSupported }); }}>
              <ShoppingBasket size={18} /> {app.lang === 'nl' ? 'Alles wat je gekocht hebt in één keer inspreken' : 'Say everything you bought in one go'}
            </button>
            <p className="muted small" style={{ margin: 0 }}>{app.lang === 'nl' ? 'Zeg het gewoon zoals je het zou zeggen. Bijvoorbeeld:' : 'Just say it the way you would to a person. For example:'}</p>
            <div className="hint-chips">
              {HINTS[app.lang].map((h) => (
                <button key={h} className="chip" onClick={() => send(h)}>{h}</button>
              ))}
            </div>
          </div>
        )}
        {msgs.filter((m) => m.text || m.actions?.length || m.data).map((m) => (
          <div key={m.id} className={`bubble ${m.role}`}>
            <div>{m.text}</div>
            {!!m.actions?.length && (
              <div className="acts">
                {m.actions.map((a, i) => (
                  <span key={i} className={`act ${m.undone ? 'undone' : a.kind}`}>{a.label}</span>
                ))}
              </div>
            )}
            {m.data?.kind === 'recipes' && (
              <div className="stack" style={{ marginTop: 8 }}>
                {m.data.items.slice(0, 4).map((r: any) => (
                  <a key={r.id} href={`#/recipe/${r.id}`} onClick={onClose} className="row" style={{ textDecoration: 'none', gap: 10 }}>
                    <span className="thumb" style={{ width: 36, height: 36, borderRadius: 10, display: 'grid', placeItems: 'center', background: r.color, fontSize: 18 }}>{r.emoji}</span>
                    <span className="grow"><b>{r.title}</b><br /><span className="tiny muted">{r.matchPct != null ? `${r.matchPct}% · ` : ''}{r.minutes} min{r.missing?.length ? ` · ${t('missing')} ${r.missing.slice(0, 2).join(', ').toLowerCase()}` : ''}</span></span>
                  </a>
                ))}
              </div>
            )}
            {m.data?.kind === 'suggestions' && m.data.items.length > 0 && (
              <div className="hint-chips" style={{ marginTop: 8 }}>
                {m.data.items.slice(0, 6).map((s: any) => (
                  <button key={s.productId} className="chip" onClick={async () => {
                    await post(`/api/shopping/suggestions/${s.productId}/accept`, { packages: s.packages });
                    invalidate(['shopping', 'home']);
                    toast({ text: `${s.name} → ${t('Shopping')}` });
                  }}><Plus size={14} /> {s.name}</button>
                ))}
              </div>
            )}
            {(m.data?.kind === 'stock' || m.data?.kind === 'expiring') && m.data.items.length > 1 && (
              <div className="small" style={{ marginTop: 8, display: 'grid', gap: 3 }}>
                {m.data.items.slice(0, 10).map((s: any) => (
                  <div key={s.productId} className="row"><span className="grow ellipsis">{s.name}</span><b className="num">{s.qty}</b></div>
                ))}
              </div>
            )}
            {m.via === 'ai' && <div className="via-ai">✦ {t('AI-generated')}</div>}
            {m.batchId && !m.undone && m === msgs.filter((x) => x.batchId && !x.undone).slice(-1)[0] && (
              <button className="btn ghost sm" style={{ marginTop: 6, padding: '0 6px', minHeight: 28 }} onClick={() => undo(m)}><Undo2 size={14} /> {t('Undo')}</button>
            )}
          </div>
        ))}
        {speech.blocked && (
          <div className="bubble bot small">
            {app.lang === 'nl'
              ? 'Spraak werkt hier niet direct. Tik op het tekstveld en gebruik de 🎤 op je toetsenbord: dat werkt ook.'
              : 'Voice input isn’t available here. Tap the text field and use the 🎤 on your keyboard instead: that works too.'}
          </div>
        )}
        {speech.unheard && !speech.listening && (
          <div className="bubble bot small">
            {app.lang === 'nl'
              ? `Ik hoorde niets. Tik op de microfoon en praat meteen, of typ het. Spreek je ${speechLang === 'nl' ? 'Engels' : 'Nederlands'}? Tik bovenaan op ${speechLang.toUpperCase()} om te wisselen.`
              : `I didn't hear anything. Tap the mic and start talking right away, or type it. Speaking ${speechLang === 'nl' ? 'English' : 'Dutch'}? Tap ${speechLang.toUpperCase()} at the top to switch.`}
          </div>
        )}
        {speech.listening && !speech.interim && <div className="bubble me interim">{app.lang === 'nl' ? 'Ik luister, zeg het maar…' : 'Listening, go ahead…'}</div>}
        {speech.interim && <div className="bubble me interim">{speech.interim}</div>}
        {busy && <div className="bubble bot"><div className="wave" style={{ color: 'var(--ink-3)' }}><i /><i /><i /><i /></div></div>}
        {last?.role === 'bot' && last.clarify && (
          <div className="stack" style={{ gap: 6 }}>
            <div className="bubble bot"><b>{last.clarify.question}</b></div>
            <div className="hint-chips">
              {last.clarify.options.map((o) => (
                <button key={o.value} className="chip" onClick={() => { voiceTurn.current = false; send(o.value, o.label); }}>{o.label}</button>
              ))}
            </div>
          </div>
        )}
      </div>
      <form
        className="composer"
        style={{ margin: '8px -16px -18px' }}
        onSubmit={(e) => {
          e.preventDefault();
          voiceTurn.current = false;
          send(text);
        }}
      >
        <input ref={inputRef} className="input" value={text} onChange={(e) => setText(e.target.value)} placeholder={speech.listening ? t('Listening') : t('Say or type… e.g. “I finished the milk”')} aria-label={t('Say or type… e.g. “I finished the milk”')} enterKeyHint="send" autoFocus={!startListening} />
        {text ? (
          <button className="mic-big" type="submit" aria-label="Send"><Send /></button>
        ) : speechSupported ? (
          <button className={`mic-big ${speech.listening ? 'listening' : ''}`} type="button" onClick={() => (speech.listening ? speech.stop() : !speech.start() ? inputRef.current?.focus() : undefined)} aria-label={speech.listening ? 'Stop listening' : t('Tap to speak')} aria-pressed={speech.listening}>
            {speech.listening ? <div className="wave"><i /><i /><i /><i /></div> : <Mic />}
          </button>
        ) : (
          <button className="mic-big" type="submit" aria-label="Send" disabled><ChefHat /></button>
        )}
      </form>
    </Sheet>
  );
}
