import { useEffect, useState } from 'react';
import { Shuffle, RefreshCw, X, Sparkles } from 'lucide-react';
import { post, invalidate } from '../api';
import { useSetting } from '../settings';
import { useApp } from '../app-context';
import { Sheet, Stepper, useToast } from './ui';

/**
 * "Plan my week": one tap gives a full week of dinners, chosen with your planning settings; each day can be swapped
 * or dropped before it goes on the plan (and the shopping list fills itself).
 */
export function AutoPlanSheet({ start, onClose }: { start: string; onClose: () => void }) {
  const app = useApp();
  const toast = useToast();
  const nl = app.lang === 'nl';
  // How the planner chooses (use-first strength, cooking time, favourites…) lives in
  // Settings → Meal planning; this sheet only plans. The server applies those settings.
  const [household] = useSetting<number>('household', 'householdSize');
  // People for this plan. Changing it only scales the meals: the recipes stay the same
  // (they change only when you tap Shuffle or swap a day).
  const [servings, setServings] = useState(household);
  const [replace, setReplace] = useState(false);
  const [open, setOpen] = useState<string | null>(null);
  const [plan, setPlan] = useState<any | null>(null);
  const [dropped, setDropped] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [seed, setSeed] = useState(1);

  const body = (s = seed) => ({ start, days: 7, servings, replace, seed: s });
  useEffect(() => {
    post('/api/plan/auto/preview', body()).then(setPlan).catch((e) => toast({ text: e.message, error: true }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [replace, seed]);

  const swap = async (date: string) => {
    const avoid = plan.plan.map((d: any) => d.recipeId).filter(Boolean);
    const r = await post('/api/plan/auto/preview', { ...body(), replace: true, only: [date], avoid, seed: Math.floor(Math.random() * 1e6) });
    const day = r.plan.find((d: any) => d.date === date && !d.existing);
    if (day) setPlan({ ...plan, plan: plan.plan.map((d: any) => (d.date === date ? day : d)) });
  };

  const fresh = (plan?.plan ?? []).filter((d: any) => !d.existing && d.recipeId && !dropped.includes(d.date));
  const apply = async () => {
    setBusy(true);
    try {
      const r = await post('/api/plan/auto/apply', { days: fresh.map((d: any) => ({ date: d.date, recipeId: d.recipeId })), servings });
      invalidate(['planner', 'shopping', 'home', 'recipes']);
      onClose();
      toast({ text: nl ? `${r.added} avondmaaltijden gepland${r.shoppingAdded ? ` · ${r.shoppingAdded} op je boodschappenlijst` : ''}` : `${r.added} dinners planned${r.shoppingAdded ? ` · ${r.shoppingAdded} added to your shopping list` : ''}` });
    } catch (e: any) {
      toast({ text: e.message, error: true });
    } finally {
      setBusy(false);
    }
  };

  const fmt = (d: string) => new Date(d + 'T12:00:00Z').toLocaleDateString(nl ? 'nl-NL' : 'en-GB', { weekday: 'short', day: 'numeric' });

  return (
    <Sheet
      title={<span className="row"><Sparkles size={20} color="var(--herb)" /> {nl ? 'Plan mijn week' : 'Plan my week'}</span>}
      onClose={onClose}
      className="autoplan"
      footer={
        <div className="row">
          <button className="btn" onClick={() => setSeed((s) => s + 1)} disabled={!plan}><Shuffle size={16} /> {nl ? 'Anders' : 'Shuffle'}</button>
          <button className="btn primary grow lg" onClick={apply} disabled={!fresh.length || busy}>{nl ? `${fresh.length} op de planning` : `Plan ${fresh.length} ${fresh.length === 1 ? 'dinner' : 'dinners'}`}</button>
        </div>
      }
    >
      <div className="row small" style={{ gap: 8 }}>
        <button className="chip" aria-pressed={replace} onClick={() => setReplace(!replace)}>↻ {nl ? 'Geplande dagen ook opnieuw' : 'Redo planned days too'}</button>
        <span className="grow" />
        <Stepper value={servings} onChange={setServings} min={1} max={12} label={nl ? 'personen' : 'people'} />
      </div>
      <div className="row small" style={{ gap: 8, marginTop: 6 }}>
        <span className="muted grow">{nl ? `Voor ${servings} ${servings === 1 ? 'persoon' : 'personen'}` : `For ${servings} ${servings === 1 ? 'person' : 'people'}`}</span>
        <a className="link small" href="#/settings/planning" onClick={onClose}>{nl ? 'Planningsinstellingen' : 'Planning settings'}</a>
      </div>
      {!plan ? (
        <div className="stack" style={{ marginTop: 12 }}>{[1, 2, 3, 4].map((i) => <div key={i} className="skeleton" style={{ height: 58 }} />)}</div>
      ) : (
        <>
          {plan.summary.dinners > 0 && (
            <div className="tiny muted" style={{ margin: '10px 0 6px' }}>
              {nl ? `Gemiddelde balans ${plan.summary.avgHealth}/100` : `Average balance ${plan.summary.avgHealth}/100`}
              {plan.summary.usesUp.length ? (nl ? ` · gebruikt ${plan.summary.usesUp.slice(0, 4).join(', ')} op tijd` : ` · uses up ${plan.summary.usesUp.slice(0, 4).join(', ')} in time`) : ''}
              {nl ? ` · ≈ € ${plan.summary.extraCost.toFixed(2)} extra boodschappen` : ` · ≈ € ${plan.summary.extraCost.toFixed(2)} extra shopping`}
            </div>
          )}
          <div className="list">
            {plan.plan.map((d: any) => {
              const off = dropped.includes(d.date);
              return (
                <div key={d.date} className={`item plan-day ${d.existing ? 'existing' : ''} ${off ? 'off' : ''}`}>
                  <span className="day-label">{fmt(d.date)}</span>
                  <span className="thumb" style={{ background: d.color ?? 'var(--bg-2)' }}>{d.emoji ?? '🍽️'}</span>
                  <a className="grow" href={d.recipeId ? `#/recipe/${d.recipeId}` : undefined} onClick={onClose} style={{ minWidth: 0, textDecoration: 'none' }}>
                    <div className="title ellipsis">{d.title}</div>
                    <div className="meta ellipsis">
                      {d.existing ? (d.locked ? (nl ? '🔒 Vastgezet' : '🔒 Locked') : nl ? 'Al gepland' : 'Already planned') : [`${d.minutes} min`, `⚖️ ${d.health}`, ...d.reasons].join(' · ')}
                    </div>
                    {open === d.date && d.why?.length > 0 && (
                      <div className="why-list" onClick={(e) => e.preventDefault()}>
                        {d.why.map((w: any) => <span key={w.factor} className={w.points > 0 ? 'plus' : 'minus'}>{w.factor} {w.points > 0 ? '+' : ''}{w.points}</span>)}
                        {d.extraCost > 0 && <span>{nl ? 'extra' : 'extra'} € {d.extraCost.toFixed(2)}</span>}
                      </div>
                    )}
                  </a>
                  {!d.existing && <button className="icon-btn ghost" aria-label={nl ? 'Waarom?' : 'Why?'} onClick={() => setOpen(open === d.date ? null : d.date)}>?</button>}
                  {!d.existing && (
                    <>
                      <button className="icon-btn ghost" aria-label={nl ? 'Ander gerecht' : 'Swap this day'} onClick={() => swap(d.date)} disabled={off}><RefreshCw size={16} /></button>
                      <button className="icon-btn ghost" aria-label={off ? (nl ? 'Terugzetten' : 'Keep this day') : nl ? 'Deze dag overslaan' : 'Skip this day'} onClick={() => setDropped(off ? dropped.filter((x) => x !== d.date) : [...dropped, d.date])}><X size={16} /></button>
                    </>
                  )}
                </div>
              );
            })}
          </div>
          <p className="tiny muted" style={{ marginTop: 8 }}>
            {nl ? 'Houdt rekening met je dieetwensen, sterren, wat je net hebt gegeten, wat bederft en wat je moet kopen, en wisselt kip, vis, vlees en vega af. Vastgezette maaltijden blijven staan. Ontbrekende ingrediënten komen vanzelf op je lijst.' : 'Weighs your dietary needs, ratings, recent meals, what will spoil and what you’d need to buy, and rotates chicken, fish, meat and veg. Locked meals stay put. Missing ingredients go on your list automatically.'}
            {plan.summary.learned?.length > 0 && <><br />{nl ? 'Geleerd: ' : 'Learned: '}{plan.summary.learned.join(' ')}</>}
          </p>
        </>
      )}
    </Sheet>
  );
}
