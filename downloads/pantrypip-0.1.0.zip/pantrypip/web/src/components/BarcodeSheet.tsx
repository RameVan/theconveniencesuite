import { useEffect, useRef, useState } from 'react';
import { Keyboard, Check } from 'lucide-react';
import { get, post, requestId, invalidate } from '../api';
import { useApp, SCOPES_ALL } from '../app-context';
import { useT, fmtQty, productName } from '../i18n';
import { Sheet, Thumb, useToast } from './ui';
import { parseAmount } from './QuantityAsk';
import { reasonText } from './DietaryNeeds';

const FORMATS = ['ean_13', 'ean_8', 'upc_a', 'upc_e'];

async function getDetector(): Promise<any> {
  const Native = (window as any).BarcodeDetector;
  if (Native) {
    try {
      const supported: string[] = await Native.getSupportedFormats();
      if (FORMATS.some((f) => supported.includes(f))) return new Native({ formats: FORMATS });
    } catch {
      /* fall through to the WebAssembly ponyfill */
    }
  }
  // iOS Safari and Firefox: ZXing compiled to WebAssembly.
  const { BarcodeDetector } = await import('barcode-detector/ponyfill');
  return new BarcodeDetector({ formats: FORMATS as any });
}

export function BarcodeSheet({ onClose }: { onClose: () => void }) {
  const app = useApp();
  const t = useT();
  const toast = useToast();
  const video = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [code, setCode] = useState<string | null>(null);
  const [manual, setManual] = useState('');
  const [result, setResult] = useState<any | null>(null);
  const [busy, setBusy] = useState(false);
  const [custom, setCustom] = useState('');

  useEffect(() => {
    let stream: MediaStream | null = null;
    let stop = false;
    let timer: number;
    (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment', width: { ideal: 1280 } }, audio: false });
        if (stop) return;
        video.current!.srcObject = stream;
        await video.current!.play();
        const detector = await getDetector();
        const tick = async () => {
          if (stop || !video.current) return;
          try {
            const codes = await detector.detect(video.current);
            if (codes[0]?.rawValue) {
              navigator.vibrate?.(30);
              setCode(codes[0].rawValue);
              return;
            }
          } catch {
            /* frame not ready */
          }
          timer = window.setTimeout(tick, 220);
        };
        tick();
      } catch (e: any) {
        setError(app.lang === 'nl' ? 'Geen toegang tot de camera. Typ de code hieronder.' : 'No camera access. Type the code below instead.');
      }
    })();
    return () => {
      stop = true;
      clearTimeout(timer);
      stream?.getTracks().forEach((tr) => tr.stop());
    };
  }, [app.lang]);

  useEffect(() => {
    if (!code) return;
    setBusy(true);
    get(`/api/barcode/${code}`)
      .then(setResult)
      .catch((e) => setError(e.message))
      .finally(() => setBusy(false));
  }, [code]);

  const addProduct = async (productId: string, packages = 1) => {
    const r = await post('/api/inventory/add', { productId, packages, source: 'barcode', clientRequestId: requestId() });
    invalidate(SCOPES_ALL);
    toast({ text: `${r.result?.label ?? 'Added'}`, undo: () => post('/api/inventory/undo', { batchId: r.batchId }).then(() => invalidate(SCOPES_ALL)) });
    onClose();
  };
  const link = async (productId?: string) => {
    setBusy(true);
    try {
      const p = await post(`/api/barcode/${code}/link`, productId ? { productId } : {});
      await addProduct(p.id);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={t('Scan barcode')} onClose={onClose}>
      {!result && (
        <div className="stack">
          {!error && (
            <div className="video-box">
              <video ref={video} playsInline muted />
              <div className="frame" />
            </div>
          )}
          {error && <p className="muted">{error}</p>}
          <form className="row" onSubmit={(e) => { e.preventDefault(); if (manual.trim()) setCode(manual.replace(/\D/g, '')); }}>
            <div className="search grow">
              <Keyboard />
              <input className="input" inputMode="numeric" value={manual} onChange={(e) => setManual(e.target.value)} placeholder="EAN / UPC" aria-label="Barcode" />
            </div>
            <button className="btn" type="submit">OK</button>
          </form>
          {busy && <div className="skeleton" style={{ height: 64 }} />}
        </div>
      )}
      {result && (
        <div className="stack">
          {result.conflicts?.length > 0 && (
            <div className="diet-banner bad" role="alert">
              <b>{app.lang === 'nl' ? 'Let op' : 'Heads up'}</b>
              <div className="small">{result.conflicts.map((r: string) => reasonText(r, app.lang)).join(', ')}{app.lang === 'nl' ? '. Controleer het etiket.' : '. Check the label.'}</div>
            </div>
          )}
          {result.product ? (
            <>
              <div className="row">
                <Thumb product={result.product} />
                <div className="grow">
                  <b>{productName(result.product, app.lang)}</b>
                  <div className="muted small">{fmtQty(result.product.package_size, result.product.unit, app.lang)}{result.stock?.confirmed ? ` · ${app.lang === 'nl' ? 'in huis' : 'in stock'} ${fmtQty(result.stock.confirmed, result.product.unit, app.lang)}` : ''}</div>
                </div>
              </div>
              <div className="row wrap">
                <button className="btn primary lg grow" onClick={() => addProduct(result.product.id)}><Check size={18} /> {t('Add')} 1</button>
                <button className="btn lg" onClick={() => addProduct(result.product.id, 2)}>+2</button>
                <button className="btn lg" onClick={() => (onClose(), app.openQuick({ mode: 'use', productId: result.product.id }))}>{t('Use')}</button>
              </div>
              {/* Any other amount, e.g. a 10-pack where one egg cracked: type 9. */}
              <form className="row" onSubmit={async (e) => {
                e.preventDefault();
                const v = parseAmount(custom, result.product);
                if (!v) return;
                const r = await post('/api/inventory/add', { productId: result.product.id, quantity: v, source: 'barcode', clientRequestId: requestId() });
                invalidate(SCOPES_ALL);
                toast({ text: `${r.result?.label ?? 'Added'}`, undo: () => post('/api/inventory/undo', { batchId: r.batchId }).then(() => invalidate(SCOPES_ALL)) });
                onClose();
              }}>
                <input className="input" inputMode="decimal" value={custom} onChange={(e) => setCustom(e.target.value)}
                  placeholder={app.lang === 'nl' ? `Andere hoeveelheid (${result.product.unit === 'pcs' ? 'stuks' : result.product.unit})` : `Other amount (${result.product.unit === 'pcs' ? 'pieces' : result.product.unit})`} aria-label={app.lang === 'nl' ? 'Andere hoeveelheid' : 'Other amount'} />
                <button className="btn" type="submit" disabled={!custom.trim()}>{t('Add')}</button>
              </form>
            </>
          ) : result.external ? (
            <>
              <div className="row">
                <Thumb product={{ image_url: result.external.imageUrl, category: 'other' }} />
                <div className="grow">
                  <b>{result.external.name}</b>
                  <div className="muted small">{[result.external.brand, result.external.quantityText].filter(Boolean).join(' · ')}</div>
                  <div className="tiny muted">Open Food Facts (ODbL)</div>
                </div>
              </div>
              {result.suggestion && (
                <button className="btn block" disabled={busy} onClick={() => link(result.suggestion.id)}>
                  {app.lang === 'nl' ? `Is dit ${productName(result.suggestion, app.lang).toLowerCase()}? Koppel en voeg toe` : `Is this ${result.suggestion.name.toLowerCase()}? Link & add`}
                </button>
              )}
              <button className="btn primary lg block" disabled={busy} onClick={() => link()}>{app.lang === 'nl' ? 'Toevoegen als nieuw product' : 'Add as a new product'}</button>
            </>
          ) : (
            <>
              <p>{app.lang === 'nl' ? `Barcode ${result.barcode} is onbekend.` : `Barcode ${result.barcode} isn't known yet.`}</p>
              <button className="btn primary block" onClick={() => (onClose(), app.openQuick({ mode: 'add' }))}>{app.lang === 'nl' ? 'Kies het product' : 'Pick the product'}</button>
            </>
          )}
          <button className="btn ghost" onClick={() => { setResult(null); setCode(null); setManual(''); }}>{app.lang === 'nl' ? 'Nog een scannen' : 'Scan another'}</button>
        </div>
      )}
    </Sheet>
  );
}
