import { useEffect, useRef, useState } from 'react';
import { Mic, Square, Minus, Plus, X, ShoppingBasket } from 'lucide-react';
import { post, requestId, invalidate, useDebounced } from '../api';
import { useApp, SCOPES_ALL } from '../app-context';
import { fmtQty } from '../i18n';
import { Sheet, Thumb, useToast } from './ui';
import { useSpeech, useSpeechLang, speechSupported } from './Assistant';
import { parseAmount } from './QuantityAsk';

interface Line {
  said: string;
  productId: string | null;
  name: string;
  category: string;
  unit: 'g' | 'ml' | 'pcs';
  qty: number;
  packageSize: number;
  pieceName: string | null;
  isNew: boolean;
  location: string | null;
}

/**
 * List mode: say (or type) everything you bought in one go: "milk, eggs, bread, two kilos of potatoes…".
 * PantryPip keeps listening through pauses, shows what it recognised as you talk, and adds it all in one step.
 */
export function BoughtListSheet({ onClose, startListening }: { onClose: () => void; startListening?: boolean }) {
  const app = useApp();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const [text, setText] = useState('');
  const [lines, setLines] = useState<Line[]>([]);
  // Edits survive re-reading the text: keyed by what was said.
  const [edits, setEdits] = useState<Record<string, { qty?: number; removed?: boolean }>>({});
  const [editing, setEditing] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [speechLang, toggleSpeechLang] = useSpeechLang(app.lang);
  const speech = useSpeech(speechLang, (full) => setText(full), { list: true, onText: setText });
  const debounced = useDebounced(text, 450);
  const seq = useRef(0);

  useEffect(() => {
    if (startListening && speechSupported) speech.start();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const mine = ++seq.current;
    if (!debounced.trim()) return setLines([]);
    post('/api/assistant/list', { text: debounced, lang: speechLang })
      .then((r) => mine === seq.current && setLines(r.lines))
      .catch(() => {});
  }, [debounced, speechLang]);

  const shown = lines.map((l) => ({ ...l, qty: edits[l.said]?.qty ?? l.qty, removed: !!edits[l.said]?.removed }));
  const kept = shown.filter((l) => !l.removed && l.qty > 0);
  const step = (l: Line) => (l.unit === 'pcs' ? 1 : l.packageSize);
  const set = (said: string, e: { qty?: number; removed?: boolean }) => setEdits((all) => ({ ...all, [said]: { ...all[said], ...e } }));

  const commit = async () => {
    if (!kept.length) return;
    speech.stop();
    setBusy(true);
    try {
      const r = await post('/api/inventory/add-many', {
        items: kept.map((l) => ({ productId: l.productId, name: l.productId ? null : l.name, quantity: l.qty, location: l.location })),
        clientRequestId: requestId(),
      });
      invalidate(SCOPES_ALL);
      onClose();
      toast({
        text: nl ? `${kept.length} producten toegevoegd aan je voorraad` : `Added ${kept.length} items to your inventory`,
        undo: async () => {
          await post('/api/inventory/undo', { batchId: r.batchId });
          invalidate(SCOPES_ALL);
        },
      });
    } catch (e: any) {
      toast({ text: e.message ?? 'Something went wrong', error: true });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      title={
        <span className="row">
          <ShoppingBasket size={20} color="var(--herb)" /> {nl ? 'Wat heb je gekocht?' : 'What did you buy?'}
          {speechSupported && (
            <button type="button" className="chip speech-lang" onClick={toggleSpeechLang} aria-label={nl ? 'Spraaktaal wisselen' : 'Switch speech language'}>
              <Mic size={12} /> {speechLang.toUpperCase()}
            </button>
          )}
        </span>
      }
      onClose={onClose}
      className="bought-list"
      footer={
        <button className="btn primary block lg" disabled={!kept.length || busy} onClick={commit}>
          {nl ? `${kept.length || ''} toevoegen aan voorraad`.trim() : `Add ${kept.length || ''} to inventory`.replace('  ', ' ')}
        </button>
      }
    >
      <div className="stack">
        <div className="list-talk">
          {speechSupported && (
            <button
              type="button"
              className={`mic-big ${speech.listening ? 'listening' : ''}`}
              onClick={() => (speech.listening ? speech.stop() : speech.start(true))}
              aria-label={speech.listening ? (nl ? 'Stoppen met luisteren' : 'Stop listening') : nl ? 'Inspreken' : 'Speak'}
              aria-pressed={speech.listening}
            >
              {speech.listening ? <Square size={18} fill="currentColor" /> : <Mic />}
            </button>
          )}
          <div className="small muted grow">
            {speech.listening
              ? nl ? 'Ik luister. Noem alles op, pauzeren mag. Zeg “klaar” of tik op stop.' : 'Listening. Name everything; pauses are fine. Say “done” or tap stop.'
              : speech.unheard
                ? nl ? 'Ik hoorde niets. Tik op de microfoon en praat meteen, of typ hieronder.' : 'I didn’t hear anything. Tap the mic and start talking right away, or type below.'
                : speech.blocked
                  ? nl ? 'Spraak werkt hier niet. Tik in het tekstvak en gebruik de 🎤 van je toetsenbord.' : 'Voice isn’t available here. Tap the text box and use your keyboard’s 🎤.'
                  : nl ? 'Bijvoorbeeld: “melk, eieren, brood, twee kilo aardappelen en een komkommer”.' : 'For example: “milk, eggs, bread, two kilos of potatoes and a cucumber”.'}
          </div>
        </div>
        <textarea
          className="input"
          rows={3}
          value={text}
          onChange={(e) => {
            setText(e.target.value);
            speech.setHeard(e.target.value);
          }}
          placeholder={nl ? 'Of typ je lijst hier' : 'Or type your list here'}
          aria-label={nl ? 'Wat je gekocht hebt' : 'What you bought'}
        />
        {shown.length > 0 && (
          <div className="list">
            {shown.map((l) => (
              <div key={l.said} className={`rline ${l.removed ? 'skip' : ''}`}>
                <Thumb product={{ id: l.productId ?? undefined, category: l.category }} />
                <div style={{ minWidth: 0 }}>
                  <div className="row" style={{ gap: 6 }}>
                    <b className="ellipsis">{l.name}</b>
                    {l.isNew && <span className="pill saffron">{nl ? 'nieuw' : 'new'}</span>}
                  </div>
                  <div className="tiny muted ellipsis">“{l.said}”</div>
                </div>
                {l.removed ? (
                  <button className="btn ghost sm" onClick={() => set(l.said, { removed: false })}>{nl ? 'Terug' : 'Restore'}</button>
                ) : (
                  <div className="row" style={{ gap: 2 }}>
                    <button className="icon-btn ghost" aria-label={nl ? 'Minder' : 'Less'} onClick={() => set(l.said, { qty: Math.max(step(l), l.qty - step(l)) })}><Minus size={16} /></button>
                    {editing === l.said ? (
                      <input
                        className="input qty-input"
                        autoFocus
                        inputMode="decimal"
                        defaultValue={l.unit === 'pcs' ? String(l.qty) : fmtQty(l.qty, l.unit, app.lang)}
                        aria-label={nl ? 'Hoeveelheid' : 'Amount'}
                        onBlur={(e) => {
                          const q = parseAmount(e.target.value, { unit: l.unit, package_size: l.packageSize, piece_size: null } as any);
                          if (q && q > 0) set(l.said, { qty: q });
                          setEditing(null);
                        }}
                        onKeyDown={(e) => e.key === 'Enter' && (e.target as HTMLInputElement).blur()}
                      />
                    ) : (
                      <button className="qty-tap num small" onClick={() => setEditing(l.said)} aria-label={nl ? 'Hoeveelheid aanpassen' : 'Change amount'}>
                        <b>{fmtQty(l.qty, l.unit, app.lang, l.pieceName)}</b>
                      </button>
                    )}
                    <button className="icon-btn ghost" aria-label={nl ? 'Meer' : 'More'} onClick={() => set(l.said, { qty: l.qty + step(l) })}><Plus size={16} /></button>
                    <button className="icon-btn ghost" aria-label={nl ? 'Weghalen' : 'Remove'} onClick={() => set(l.said, { removed: true })}><X size={16} /></button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </Sheet>
  );
}
