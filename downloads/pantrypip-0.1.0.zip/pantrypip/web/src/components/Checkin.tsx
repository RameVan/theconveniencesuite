import { useState } from 'react';
import { Check, X, CalendarClock } from 'lucide-react';
import { post, useQuery, invalidate } from '../api';
import { useApp, SCOPES_ALL } from '../app-context';
import { useToast } from './ui';

/**
 * The daily question on Home: "Did you cook X?" for planned meals not yet confirmed.
 * Yes → (optional leftovers) → ingredients come out of stock. No → nothing is deducted.
 */
export function CheckinCards() {
  const app = useApp();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const { data } = useQuery<any>('/api/checkins', ['planner', 'inventory']);
  const [leftoverFor, setLeftoverFor] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const focus = location.hash.match(/checkin=([\w-]+)/)?.[1];
  const pending: any[] = data?.pending ?? [];
  if (!pending.length) return null;

  const answer = async (c: any, body: any) => {
    setBusy(true);
    try {
      const r = await post(`/api/checkins/${c.slotId}`, body);
      invalidate(SCOPES_ALL);
      setLeftoverFor(null);
      const text =
        body.answer === 'cooked' ? (nl ? `${c.title} gekookt. Ingrediënten afgeschreven.` : `${c.title} cooked. Ingredients taken out of stock.`)
          : body.answer === 'tomorrow' ? (nl ? `${c.title} staat op morgen.` : `${c.title} moved to tomorrow.`)
            : nl ? `Oké, ${c.title} niet gekookt.` : `OK, ${c.title} wasn't cooked.`;
      toast({ text, undo: r.batchId ? () => post('/api/inventory/undo', { batchId: r.batchId }).then(() => invalidate(SCOPES_ALL)) : undefined });
    } catch (e: any) {
      toast({ text: e.message, error: true });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="stack" style={{ marginTop: 18 }}>
      {pending.map((c) => {
        const q = c.when === 'yesterday'
          ? nl ? `Heb je gisteren ${c.title} gekookt?` : `Did you cook ${c.title} yesterday?`
          : nl ? `Heb je ${c.meal === 'dinner' ? 'vanavond' : 'vandaag'} ${c.title} gekookt?` : `Did you cook ${c.title} ${c.meal === 'dinner' ? 'tonight' : 'today'}?`;
        const askingLeftovers = leftoverFor === c.slotId;
        return (
          <div key={c.slotId} className={`card pad checkin ${focus === c.slotId ? 'focus' : ''}`} role="group" aria-label={q}>
            <div className="row">
              <span className="thumb" style={{ width: 46, height: 46, borderRadius: 14, display: 'grid', placeItems: 'center', fontSize: 24, background: `color-mix(in srgb, ${c.color ?? '#7A8B6F'} 25%, var(--surface))` }} aria-hidden>{c.emoji ?? '🍽️'}</span>
              <div className="grow">
                <div style={{ fontWeight: 700 }}>{askingLeftovers ? (nl ? 'Nog restjes over?' : 'Any leftovers?') : q}</div>
                <div className="tiny muted">{askingLeftovers ? (nl ? 'Restjes worden een eigen product in je voorraad.' : 'Leftovers become their own item in your inventory.') : `${c.servings} ${nl ? 'porties gepland' : 'servings planned'}`}</div>
              </div>
            </div>
            {!askingLeftovers ? (
              <div className="row wrap" style={{ marginTop: 10 }}>
                <button className="btn primary sm" disabled={busy} onClick={() => setLeftoverFor(c.slotId)}><Check size={15} /> {nl ? 'Ja, gekookt' : 'Yes, cooked'}</button>
                <button className="btn sm" disabled={busy} onClick={() => answer(c, { answer: 'not_cooked' })}><X size={15} /> {nl ? 'Nee' : 'No'}</button>
                <button className="btn sm ghost" disabled={busy} onClick={() => answer(c, { answer: 'tomorrow' })}><CalendarClock size={15} /> {nl ? 'Morgen' : 'Tomorrow'}</button>
              </div>
            ) : (
              <div className="hint-chips" style={{ marginTop: 10 }}>
                <button className="chip" disabled={busy} onClick={() => answer(c, { answer: 'cooked' })}>{nl ? 'Geen restjes' : 'No leftovers'}</button>
                <button className="chip" disabled={busy} onClick={() => answer(c, { answer: 'cooked', leftovers: { fridge: 1 } })}>{nl ? '1 portie → koelkast' : '1 portion → fridge'}</button>
                <button className="chip" disabled={busy} onClick={() => answer(c, { answer: 'cooked', leftovers: { fridge: 2 } })}>{nl ? '2 porties → koelkast' : '2 portions → fridge'}</button>
                <button className="chip" disabled={busy} onClick={() => answer(c, { answer: 'cooked', leftovers: { freezer: 2 } })}>{nl ? '2 porties → vriezer' : '2 portions → freezer'}</button>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
