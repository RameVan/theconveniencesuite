import { useEffect, useRef, useState } from 'react';
import { Plus, Trash2, UserRound } from 'lucide-react';
import { get, post, put, useQuery, invalidate } from '../api';
import { useApp } from '../app-context';
import { useSettings } from '../settings';
import { useToast } from './ui';
import type { Lang } from '../i18n';

interface Person { id: string; name: string; diets: string[]; allergies: string[]; avoid: string[]; kcal?: number | null; protein?: number | null }

export const DIET_LABEL: Record<string, [string, string]> = {
  vegetarian: ['Vegetarian', 'Vegetarisch'], vegan: ['Vegan', 'Veganistisch'], pescatarian: ['Pescatarian', 'Pescotariër'],
  'gluten-free': ['Gluten-free', 'Glutenvrij'], 'dairy-free': ['Dairy-free', 'Zuivelvrij'], halal: ['Halal', 'Halal'],
  'no-pork': ['No pork', 'Geen varkensvlees'], 'no-alcohol': ['No alcohol', 'Geen alcohol'], 'low-carb': ['Low-carb', 'Koolhydraatarm'],
};
export const ALLERGEN_LABEL: Record<string, [string, string]> = {
  gluten: ['Gluten', 'Gluten'], crustaceans: ['Shellfish', 'Schaaldieren'], eggs: ['Eggs', 'Eieren'], fish: ['Fish', 'Vis'], peanuts: ['Peanuts', "Pinda's"],
  soy: ['Soy', 'Soja'], milk: ['Milk / lactose', 'Melk / lactose'], nuts: ['Tree nuts', 'Noten'], celery: ['Celery', 'Selderij'], mustard: ['Mustard', 'Mosterd'],
  sesame: ['Sesame', 'Sesam'], sulphites: ['Sulphites', 'Sulfiet'], lupin: ['Lupin', 'Lupine'], molluscs: ['Molluscs', 'Weekdieren'],
};
export const label = (map: Record<string, [string, string]>, k: string, lang: Lang) => map[k]?.[lang === 'nl' ? 1 : 0] ?? k;

/** Human text for a conflict reason from the server ("allergy:milk", "diet:vegan", "avoid"). */
export function reasonText(r: string, lang: Lang): string {
  const [kind, key] = r.split(':');
  if (kind === 'allergy') return lang === 'nl' ? `allergie: ${label(ALLERGEN_LABEL, key, lang).toLowerCase()}` : `${label(ALLERGEN_LABEL, key, lang).toLowerCase()} allergy`;
  if (kind === 'diet') return label(DIET_LABEL, key, lang).toLowerCase();
  return lang === 'nl' ? 'liever niet' : 'avoided';
}

/**
 * People and their needs, saved as one list. Shows the server's list unless a change is on its way;
 * one save at a time (the latest wins); a rejected change rolls back and says why.
 */
function usePeople() {
  const toast = useToast();
  const { track } = useSettings();
  const { data } = useQuery<any>('/api/dietary', ['preferences']);
  const [local, setLocal] = useState<Person[] | null>(null);
  const busy = useRef(false);
  const queued = useRef<Person[] | null>(null);
  const people: Person[] | null = local ?? data?.people ?? null;
  const send = async (next: Person[]): Promise<void> => {
    if (busy.current) {
      queued.current = next;
      return;
    }
    busy.current = true;
    let failed = false;
    try {
      await track(put('/api/dietary', { people: next }));
      invalidate(['preferences', 'recipes', 'home', 'game']);
    } catch (e: any) {
      failed = true;
      toast({ text: e.message, error: true });
      queued.current = null;
    } finally {
      busy.current = false;
      const q = queued.current;
      queued.current = null;
      if (q && !failed) send(q);
      else setLocal(null); // back to what the server has (refetched above)
    }
  };
  const save = (next: Person[]) => {
    setLocal(next);
    send(next);
  };
  return { people, options: data?.options, names: (data?.names ?? {}) as Record<string, [string, string]>, save };
}

export function DietaryNeedsEditor() {
  const app = useApp();
  const nl = app.lang === 'nl';
  const { people, options, names, save } = usePeople();
  if (!people || !options) return <div className="skeleton" style={{ height: 160 }} />;
  const update = (id: string, patch: Partial<Person>) => save(people.map((p) => (p.id === id ? { ...p, ...patch } : p)));
  const toggle = (p: Person, key: 'diets' | 'allergies', v: string) => update(p.id, { [key]: p[key].includes(v) ? p[key].filter((x) => x !== v) : [...p[key], v] });

  return (
    <section className="set-group">
      <h2 className="set-title">{nl ? 'Mensen en diëten' : 'People and diets'}</h2>
      {people.map((p) => (
        <div key={p.id} className="set-card person">
          <div className="set-row">
            <UserRound size={18} aria-hidden />
            <input className="input set-name" key={`${p.id}-${p.name}`} defaultValue={p.name} aria-label={nl ? 'Naam' : 'Name'} onBlur={(e) => e.target.value.trim() && e.target.value.trim() !== p.name && update(p.id, { name: e.target.value.trim().slice(0, 40) })} />
            {people.length > 1 && <button className="icon-btn ghost" aria-label={`${nl ? 'Verwijder' : 'Remove'} ${p.name}`} onClick={() => save(people.filter((x) => x.id !== p.id))}><Trash2 size={16} /></button>}
          </div>
          <div className="set-row stacked">
            <div className="set-label"><span>{nl ? 'Dieet' : 'Diet'}</span></div>
            <div className="chips set-chips">{options.diets.map((d: string) => <button key={d} className={`chip ${p.diets.includes(d) ? 'on' : ''}`} aria-pressed={p.diets.includes(d)} onClick={() => toggle(p, 'diets', d)}>{label(DIET_LABEL, d, app.lang)}</button>)}</div>
          </div>
          <div className="set-row stacked">
            <div className="set-label"><span>{nl ? 'Allergieën' : 'Allergies'}</span><span className="set-hint">{nl ? 'Per ingrediënt gecontroleerd. Lees altijd het etiket.' : 'Checked per ingredient. Always read the label.'}</span></div>
            <div className="chips set-chips">{options.allergens.map((a: string) => <button key={a} className={`chip allergy ${p.allergies.includes(a) ? 'on' : ''}`} aria-pressed={p.allergies.includes(a)} onClick={() => toggle(p, 'allergies', a)}>{label(ALLERGEN_LABEL, a, app.lang)}</button>)}</div>
          </div>
          <div className="set-row stacked">
            <div className="set-label"><span>{nl ? 'Eet liever niet' : 'Doesn’t eat'}</span><span className="set-hint">{nl ? 'Typ of plak een lijst: olijven, champignons, koriander' : 'Type, or paste a list: olives, mushrooms, coriander'}</span></div>
            <AvoidPicker avoid={p.avoid} names={names} who={p.name} onChange={(avoid) => update(p.id, { avoid })} />
          </div>
        </div>
      ))}
      <button className="btn sm" style={{ marginTop: 10 }} onClick={() => save([...people, { id: `p${Date.now().toString(36)}`, name: nl ? 'Nieuwe persoon' : 'New person', diets: [], allergies: [], avoid: [] }])}><Plus size={15} /> {nl ? 'Persoon toevoegen' : 'Add a person'}</button>
      <p className="set-foot">{nl ? 'Recepten die niet passen verdwijnen uit voorstellen, of krijgen een vervanger.' : 'Recipes that don’t fit are left out of suggestions, or get a swap.'}</p>
    </section>
  );
}

/**
 * "Doesn't eat": chips for what's avoided, and a field that suggests products while you type. Tapping a
 * suggestion adds it and keeps the list open for the next; Enter adds everything typed ("olives, mushrooms").
 */
function AvoidPicker({ avoid, names, who, onChange }: { avoid: string[]; names: Record<string, [string, string]>; who: string; onChange: (ids: string[]) => void }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const toast = useToast();
  const [text, setText] = useState('');
  const [hits, setHits] = useState<{ id: string; name: string }[]>([]);
  const [active, setActive] = useState(0);
  const [known, setKnown] = useState<Record<string, string>>({});
  const seq = useRef(0);
  const timer = useRef<number>();
  const field = useRef<HTMLInputElement>(null);
  const nameOf = (id: string) => known[id] ?? names[id]?.[nl ? 1 : 0] ?? id.replace(/^p_/, '').replace(/_/g, ' ');
  // Only the part after the last comma is being typed; earlier parts are a list waiting for Enter.
  const current = text.split(/[,;\n]/).pop()!.trim();
  const shown = hits.filter((h) => !avoid.includes(h.id));

  useEffect(() => {
    window.clearTimeout(timer.current);
    const n = ++seq.current;
    if (current.length < 2) return setHits([]);
    timer.current = window.setTimeout(() => {
      get<{ id: string; name: string }[]>(`/api/products/suggest?q=${encodeURIComponent(current)}&lang=${app.lang}`).then((r) => {
        if (n === seq.current) { setHits(r); setActive(0); } // ignore answers to older keystrokes
      }).catch(() => {});
    }, 120);
  }, [current, app.lang]);

  const add = (items: { id: string; name: string }[]) => {
    const fresh = items.filter((x) => !avoid.includes(x.id));
    if (!fresh.length) return;
    setKnown((k) => ({ ...k, ...Object.fromEntries(fresh.map((x) => [x.id, x.name])) }));
    onChange([...avoid, ...fresh.map((x) => x.id)].slice(0, 60));
  };
  const pick = (h: { id: string; name: string }) => {
    add([h]);
    setText((t) => t.replace(/[^,;\n]*$/, '').replace(/^\s+/, '')); // drop the word being typed, keep the rest
    setHits([]);
    field.current?.focus();
  };
  const submit = async () => {
    const raw = text.trim();
    if (!raw) return;
    // One word with a suggestion showing: take the highlighted one.
    if (!/[,;\n]|\s(and|en|&)\s/i.test(raw) && shown[active]) return pick(shown[active]);
    try {
      const r = await post<{ term: string; product: { id: string; name: string } | null }[]>(`/api/products/resolve-list?lang=${app.lang}`, { text: raw });
      add(r.flatMap((x) => (x.product ? [x.product] : [])));
      const missing = r.filter((x) => !x.product).map((x) => x.term);
      setText(missing.join(', '));
      setHits([]);
      const found = r.length - missing.length;
      if (missing.length) toast({ text: nl ? `${found} toegevoegd. Niet gevonden: ${missing.join(', ')}` : `Added ${found}. Couldn’t find: ${missing.join(', ')}`, error: !found });
      else if (found > 1) toast({ text: nl ? `${found} toegevoegd` : `Added ${found}` });
    } catch (e: any) {
      toast({ text: e.message, error: true });
    }
  };
  const onKey = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') { e.preventDefault(); submit(); }
    else if (e.key === 'ArrowDown' && shown.length) { e.preventDefault(); setActive((a) => (a + 1) % shown.length); }
    else if (e.key === 'ArrowUp' && shown.length) { e.preventDefault(); setActive((a) => (a - 1 + shown.length) % shown.length); }
    else if (e.key === 'Escape') setHits([]);
  };
  const listId = `avoid-${who.replace(/\W/g, '')}`;

  return (
    <div className="avoid">
      {avoid.length > 0 && (
        <div className="chips set-chips">
          {avoid.map((id) => <button key={id} className="chip on" aria-label={`${nl ? 'Verwijder' : 'Remove'} ${nameOf(id)}`} onClick={() => onChange(avoid.filter((x) => x !== id))}>{nameOf(id)} ✕</button>)}
        </div>
      )}
      <div className="avoid-field">
        <input ref={field} className="input" value={text} placeholder={nl ? '+ ingrediënt(en)' : '+ ingredient(s)'} aria-label={nl ? `Wat ${who} niet eet` : `What ${who} doesn’t eat`}
          role="combobox" aria-expanded={shown.length > 0} aria-controls={listId} aria-autocomplete="list" autoComplete="off" enterKeyHint="done"
          onChange={(e) => setText(e.target.value)} onKeyDown={onKey} />
        <button className="btn sm soft" disabled={!text.trim()} onClick={submit}>{nl ? 'Toevoegen' : 'Add'}</button>
      </div>
      {shown.length > 0 && (
        <ul className="avoid-hits" id={listId} role="listbox">
          {shown.map((h, i) => (
            <li key={h.id} role="option" aria-selected={i === active}>
              <button className={i === active ? 'on' : ''} onMouseDown={(e) => e.preventDefault()} onClick={() => pick(h)}><Plus size={14} aria-hidden /> {h.name}</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/** Calorie and protein targets per person (Settings → Nutrition). */
export function NutritionPeople() {
  const app = useApp();
  const nl = app.lang === 'nl';
  const { people, save } = usePeople();
  if (!people) return <div className="skeleton" style={{ height: 120 }} />;
  const update = (id: string, patch: Partial<Person>) => save(people.map((p) => (p.id === id ? { ...p, ...patch } : p)));
  return (
    <section className="set-group">
      <h2 className="set-title">{nl ? 'Calorieën en eiwit per persoon' : 'Calories and protein per person'}</h2>
      <div className="set-card">
        {people.map((p) => (
          <div key={p.id} className="set-row">
            <div className="set-label"><span>{p.name}</span><span className="set-hint">{nl ? 'Leeg = standaard' : 'Empty = default'}</span></div>
            <div className="set-control">
              <TargetInput label={`${p.name} kcal`} unit="kcal" value={p.kcal ?? null} min={800} max={6000} onSave={(v) => update(p.id, { kcal: v })} />
              <TargetInput label={`${p.name} ${nl ? 'eiwit' : 'protein'}`} unit={nl ? 'g eiwit' : 'g protein'} value={p.protein ?? null} min={0} max={400} onSave={(v) => update(p.id, { protein: v })} />
            </div>
          </div>
        ))}
      </div>
      <p className="set-foot">{nl ? 'Per dag. Mensen voeg je toe onder Eetvoorkeuren.' : 'Per day. Add people under Food preferences.'}</p>
    </section>
  );
}

function TargetInput({ label: name, unit, value, min, max, onSave }: { label: string; unit: string; value: number | null; min: number; max: number; onSave: (v: number | null) => void }) {
  const [v, setV] = useState(value == null ? '' : String(value));
  useEffect(() => setV(value == null ? '' : String(value)), [value]);
  const commit = () => {
    if (v.trim() === '') {
      if (value != null) onSave(null);
      return;
    }
    const n = Math.round(Number(v));
    if (Number.isFinite(n) && n >= min && n <= max) {
      if (n !== value) onSave(n);
    } else setV(value == null ? '' : String(value)); // out of range: back to the saved value
  };
  return (
    <label className="set-target">
      <input className="input set-num" inputMode="numeric" value={v} aria-label={name} onChange={(e) => setV(e.target.value)} onBlur={commit} onKeyDown={(e) => e.key === 'Enter' && (e.target as HTMLInputElement).blur()} />
      <span className="set-hint">{unit}</span>
    </label>
  );
}
