import { useEffect, useRef, useState } from 'react';
import { Plus, Trash2, UserRound } from 'lucide-react';
import { get, put, useQuery, invalidate } from '../api';
import { useApp } from '../app-context';
import { useSettings } from '../settings';
import { useToast } from './ui';
import type { Lang } from '../i18n';

interface Person { id: string; name: string; diets: string[]; allergies: string[]; avoid: string[]; kcal?: number | null; protein?: number | null }

export const DIET_LABEL: Record<string, [string, string]> = {
  vegetarian: ['Vegetarian', 'Vegetarisch'], vegan: ['Vegan', 'Veganistisch'], pescatarian: ['Pescatarian', 'Pescotariër'],
  'gluten-free': ['Gluten-free', 'Glutenvrij'], 'dairy-free': ['Dairy-free', 'Zuivelvrij'], halal: ['Halal', 'Halal'],
  'no-pork': ['No pork', 'Geen varkensvlees'], 'no-alcohol': ['No alcohol', 'Geen alcohol'], 'low-carb': ['Low-carb', 'Koolhydraatarm'],
};
export const ALLERGEN_LABEL: Record<string, [string, string]> = {
  gluten: ['Gluten', 'Gluten'], crustaceans: ['Shellfish', 'Schaaldieren'], eggs: ['Eggs', 'Eieren'], fish: ['Fish', 'Vis'], peanuts: ['Peanuts', "Pinda's"],
  soy: ['Soy', 'Soja'], milk: ['Milk / lactose', 'Melk / lactose'], nuts: ['Tree nuts', 'Noten'], celery: ['Celery', 'Selderij'], mustard: ['Mustard', 'Mosterd'],
  sesame: ['Sesame', 'Sesam'], sulphites: ['Sulphites', 'Sulfiet'], lupin: ['Lupin', 'Lupine'], molluscs: ['Molluscs', 'Weekdieren'],
};
export const label = (map: Record<string, [string, string]>, k: string, lang: Lang) => map[k]?.[lang === 'nl' ? 1 : 0] ?? k;

/** Human text for a conflict reason from the server ("allergy:milk", "diet:vegan", "avoid"). */
export function reasonText(r: string, lang: Lang): string {
  const [kind, key] = r.split(':');
  if (kind === 'allergy') return lang === 'nl' ? `allergie: ${label(ALLERGEN_LABEL, key, lang).toLowerCase()}` : `${label(ALLERGEN_LABEL, key, lang).toLowerCase()} allergy`;
  if (kind === 'diet') return label(DIET_LABEL, key, lang).toLowerCase();
  return lang === 'nl' ? 'liever niet' : 'avoided';
}

/**
 * People and their needs, saved as one list. Shows the server's list unless a change is on its way;
 * one save at a time (the latest wins); a rejected change rolls back and says why.
 */
function usePeople() {
  const toast = useToast();
  const { track } = useSettings();
  const { data } = useQuery<any>('/api/dietary', ['preferences']);
  const [local, setLocal] = useState<Person[] | null>(null);
  const busy = useRef(false);
  const queued = useRef<Person[] | null>(null);
  const people: Person[] | null = local ?? data?.people ?? null;
  const send = async (next: Person[]): Promise<void> => {
    if (busy.current) {
      queued.current = next;
      return;
    }
    busy.current = true;
    let failed = false;
    try {
      await track(put('/api/dietary', { people: next }));
      invalidate(['preferences', 'recipes', 'home', 'game']);
    } catch (e: any) {
      failed = true;
      toast({ text: e.message, error: true });
      queued.current = null;
    } finally {
      busy.current = false;
      const q = queued.current;
      queued.current = null;
      if (q && !failed) send(q);
      else setLocal(null); // back to what the server has (refetched above)
    }
  };
  const save = (next: Person[]) => {
    setLocal(next);
    send(next);
  };
  return { people, options: data?.options, save };
}

export function DietaryNeedsEditor() {
  const app = useApp();
  const nl = app.lang === 'nl';
  const { people, options, save } = usePeople();
  const [search, setSearch] = useState<Record<string, any[]>>({});
  if (!people || !options) return <div className="skeleton" style={{ height: 160 }} />;
  const update = (id: string, patch: Partial<Person>) => save(people.map((p) => (p.id === id ? { ...p, ...patch } : p)));
  const toggle = (p: Person, key: 'diets' | 'allergies', v: string) => update(p.id, { [key]: p[key].includes(v) ? p[key].filter((x) => x !== v) : [...p[key], v] });

  return (
    <section className="set-group">
      <h2 className="set-title">{nl ? 'Mensen en diëten' : 'People and diets'}</h2>
      {people.map((p) => (
        <div key={p.id} className="set-card person">
          <div className="set-row">
            <UserRound size={18} aria-hidden />
            <input className="input set-name" key={`${p.id}-${p.name}`} defaultValue={p.name} aria-label={nl ? 'Naam' : 'Name'} onBlur={(e) => e.target.value.trim() && e.target.value.trim() !== p.name && update(p.id, { name: e.target.value.trim().slice(0, 40) })} />
            {people.length > 1 && <button className="icon-btn ghost" aria-label={`${nl ? 'Verwijder' : 'Remove'} ${p.name}`} onClick={() => save(people.filter((x) => x.id !== p.id))}><Trash2 size={16} /></button>}
          </div>
          <div className="set-row stacked">
            <div className="set-label"><span>{nl ? 'Dieet' : 'Diet'}</span></div>
            <div className="chips set-chips">{options.diets.map((d: string) => <button key={d} className={`chip ${p.diets.includes(d) ? 'on' : ''}`} aria-pressed={p.diets.includes(d)} onClick={() => toggle(p, 'diets', d)}>{label(DIET_LABEL, d, app.lang)}</button>)}</div>
          </div>
          <div className="set-row stacked">
            <div className="set-label"><span>{nl ? 'Allergieën' : 'Allergies'}</span><span className="set-hint">{nl ? 'Per ingrediënt gecontroleerd. Lees altijd het etiket.' : 'Checked per ingredient. Always read the label.'}</span></div>
            <div className="chips set-chips">{options.allergens.map((a: string) => <button key={a} className={`chip allergy ${p.allergies.includes(a) ? 'on' : ''}`} aria-pressed={p.allergies.includes(a)} onClick={() => toggle(p, 'allergies', a)}>{label(ALLERGEN_LABEL, a, app.lang)}</button>)}</div>
          </div>
          <div className="set-row stacked">
            <div className="set-label"><span>{nl ? 'Eet liever niet' : 'Doesn’t eat'}</span></div>
            <div className="chips set-chips">
              {p.avoid.map((id) => <button key={id} className="chip on" aria-label={`${nl ? 'Verwijder' : 'Remove'} ${id}`} onClick={() => update(p.id, { avoid: p.avoid.filter((x) => x !== id) })}>{id.replace(/^p_/, '').replace(/_/g, ' ')} ✕</button>)}
              <input className="input set-inline" placeholder={nl ? '+ ingrediënt' : '+ ingredient'} aria-label={nl ? 'Ingrediënt toevoegen' : 'Add ingredient'}
                onChange={(e) => { const v = e.target.value; if (v.length > 1) get(`/api/products?q=${encodeURIComponent(v)}`).then((r) => setSearch((s) => ({ ...s, [p.id]: r }))); else setSearch((s) => ({ ...s, [p.id]: [] })); }} />
            </div>
            {(search[p.id] ?? []).slice(0, 4).map((x) => (
              <button key={x.id} className="btn sm" style={{ marginTop: 6 }} onClick={() => { update(p.id, { avoid: [...new Set([...p.avoid, x.id])] }); setSearch((s) => ({ ...s, [p.id]: [] })); }}>{x.name}</button>
            ))}
          </div>
        </div>
      ))}
      <button className="btn sm" style={{ marginTop: 10 }} onClick={() => save([...people, { id: `p${Date.now().toString(36)}`, name: nl ? 'Nieuwe persoon' : 'New person', diets: [], allergies: [], avoid: [] }])}><Plus size={15} /> {nl ? 'Persoon toevoegen' : 'Add a person'}</button>
      <p className="set-foot">{nl ? 'Recepten die niet passen verdwijnen uit voorstellen, of krijgen een vervanger.' : 'Recipes that don’t fit are left out of suggestions, or get a swap.'}</p>
    </section>
  );
}

/** Calorie and protein targets per person (Settings → Nutrition). */
export function NutritionPeople() {
  const app = useApp();
  const nl = app.lang === 'nl';
  const { people, save } = usePeople();
  if (!people) return <div className="skeleton" style={{ height: 120 }} />;
  const update = (id: string, patch: Partial<Person>) => save(people.map((p) => (p.id === id ? { ...p, ...patch } : p)));
  return (
    <section className="set-group">
      <h2 className="set-title">{nl ? 'Calorieën en eiwit per persoon' : 'Calories and protein per person'}</h2>
      <div className="set-card">
        {people.map((p) => (
          <div key={p.id} className="set-row">
            <div className="set-label"><span>{p.name}</span><span className="set-hint">{nl ? 'Leeg = standaard' : 'Empty = default'}</span></div>
            <div className="set-control">
              <TargetInput label={`${p.name} kcal`} unit="kcal" value={p.kcal ?? null} min={800} max={6000} onSave={(v) => update(p.id, { kcal: v })} />
              <TargetInput label={`${p.name} ${nl ? 'eiwit' : 'protein'}`} unit={nl ? 'g eiwit' : 'g protein'} value={p.protein ?? null} min={0} max={400} onSave={(v) => update(p.id, { protein: v })} />
            </div>
          </div>
        ))}
      </div>
      <p className="set-foot">{nl ? 'Per dag. Mensen voeg je toe onder Eetvoorkeuren.' : 'Per day. Add people under Food preferences.'}</p>
    </section>
  );
}

function TargetInput({ label: name, unit, value, min, max, onSave }: { label: string; unit: string; value: number | null; min: number; max: number; onSave: (v: number | null) => void }) {
  const [v, setV] = useState(value == null ? '' : String(value));
  useEffect(() => setV(value == null ? '' : String(value)), [value]);
  const commit = () => {
    if (v.trim() === '') {
      if (value != null) onSave(null);
      return;
    }
    const n = Math.round(Number(v));
    if (Number.isFinite(n) && n >= min && n <= max) {
      if (n !== value) onSave(n);
    } else setV(value == null ? '' : String(value)); // out of range: back to the saved value
  };
  return (
    <label className="set-target">
      <input className="input set-num" inputMode="numeric" value={v} aria-label={name} onChange={(e) => setV(e.target.value)} onBlur={commit} onKeyDown={(e) => e.key === 'Enter' && (e.target as HTMLInputElement).blur()} />
      <span className="set-hint">{unit}</span>
    </label>
  );
}
