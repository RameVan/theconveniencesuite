// Edit your own recipe: name, servings, times, each ingredient's amount and product match, and the steps.
import { useEffect, useState } from 'react';
import { Plus, X, Check } from 'lucide-react';
import { api, get, invalidate } from '../api';
import { useApp } from '../app-context';
import { Sheet, Stepper, useToast } from './ui';

type Row = { display: string; productId: string | null; productName: string | null; quantity: number | null; unit: string | null; optional: boolean };

const UNIT_LABEL: Record<string, [string, string]> = { g: ['g', 'g'], ml: ['ml', 'ml'], pcs: ['pcs', 'st.'] };

export function EditRecipeSheet({ recipe, onClose }: { recipe: any; onClose: () => void }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const toast = useToast();
  const [title, setTitle] = useState(recipe.title);
  const [servings, setServings] = useState(recipe.servings);
  const [prep, setPrep] = useState(recipe.prep_minutes ?? 0);
  const [cook, setCook] = useState(recipe.cook_minutes ?? 0);
  const [rows, setRows] = useState<Row[]>(recipe.ingredients.map((i: any) => ({ display: i.display ?? i.name, productId: i.product_id, productName: i.product ? (nl ? i.product.name_nl ?? i.product.name : i.product.name) : null, quantity: i.quantity, unit: i.product?.unit ?? i.unit, optional: !!i.optional })));
  const [steps, setSteps] = useState<string>(recipe.steps.map((s: any) => s.text).join('\n'));
  const [products, setProducts] = useState<any[]>([]);
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    get<any[]>('/api/products').then((l) => setProducts([...l].sort((a, b) => (nl ? a.name_nl ?? a.name : a.name).localeCompare(nl ? b.name_nl ?? b.name : b.name)))).catch(() => {});
  }, []);
  const set = (k: number, patch: Partial<Row>) => setRows((rs) => rs.map((r, j) => (j === k ? { ...r, ...patch } : r)));
  const timers = new Map<string, number>(recipe.steps.filter((s: any) => s.timerSeconds).map((s: any) => [s.text, s.timerSeconds]));

  const save = async () => {
    setBusy(true);
    try {
      const stepList = steps.split('\n').map((s) => s.trim()).filter(Boolean);
      await api('PUT', `/api/recipes/${recipe.id}`, {
        title: title.trim(), servings, prep_minutes: prep, cook_minutes: cook, summary: recipe.summary, cuisine: recipe.cuisine, tags: recipe.tags, difficulty: recipe.difficulty,
        steps: (stepList.length ? stepList : [nl ? 'Bereiden en serveren.' : 'Prepare and serve.']).map((text) => ({ text, timerSeconds: timers.get(text) ?? null })),
        ingredients: rows.filter((r) => r.display.trim() || r.productId).map((r) => ({ name: r.productName ?? r.display, productId: r.productId, quantity: r.quantity, display: r.display || r.productName, optional: r.optional })),
      });
      invalidate(['recipes']);
      toast({ text: nl ? 'Recept bijgewerkt' : 'Recipe updated' });
      onClose();
    } catch (e: any) {
      toast({ text: e.message, error: true });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet title={nl ? 'Recept bewerken' : 'Edit recipe'} onClose={onClose} footer={<button className="btn primary block lg" disabled={busy || !title.trim() || !rows.some((r) => r.display.trim() || r.productId)} onClick={save}><Check size={18} /> {nl ? 'Opslaan' : 'Save'}</button>}>
      <div className="stack">
        <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} aria-label={nl ? 'Naam' : 'Name'} />
        <div className="row wrap small">
          <span className="muted">{nl ? 'Porties' : 'Servings'}</span><Stepper value={servings} onChange={setServings} label={nl ? 'porties' : 'servings'} />
          <span className="grow" />
          <label className="row" style={{ gap: 4 }}><span className="muted">{nl ? 'Voorb.' : 'Prep'}</span><input className="input" style={{ width: 64 }} inputMode="numeric" value={prep} onChange={(e) => setPrep(Number(e.target.value.replace(/\D/g, '')) || 0)} aria-label={nl ? 'Voorbereiding (min)' : 'Prep (min)'} /></label>
          <label className="row" style={{ gap: 4 }}><span className="muted">{nl ? 'Koken' : 'Cook'}</span><input className="input" style={{ width: 64 }} inputMode="numeric" value={cook} onChange={(e) => setCook(Number(e.target.value.replace(/\D/g, '')) || 0)} aria-label={nl ? 'Kooktijd (min)' : 'Cook (min)'} /></label>
        </div>
        <b className="small">{nl ? `Ingrediënten (voor ${servings})` : `Ingredients (for ${servings})`}</b>
        <div className="list">
          {rows.map((r, k) => (
            <div key={k} className="item edit-ing">
              <div className="grow stack" style={{ gap: 4, minWidth: 0 }}>
                <input className="input sm" value={r.display} onChange={(e) => set(k, { display: e.target.value })} aria-label={nl ? 'Omschrijving' : 'Description'} placeholder={nl ? 'bijv. 2 el olijfolie' : 'e.g. 2 tbsp olive oil'} />
                <div className="row" style={{ gap: 6 }}>
                  <input className="input sm" style={{ width: 84 }} inputMode="decimal" value={r.quantity ?? ''} onChange={(e) => { const v = e.target.value.replace(',', '.'); set(k, { quantity: v === '' ? null : Number(v) || 0 }); }} aria-label={nl ? 'Hoeveelheid' : 'Amount'} placeholder="—" />
                  <span className="tiny muted" style={{ width: 28 }}>{r.unit ? UNIT_LABEL[r.unit]?.[nl ? 1 : 0] ?? r.unit : ''}</span>
                  <select className="input sm grow" value={r.productId ?? ''} onChange={(e) => { const p = products.find((x) => x.id === e.target.value); set(k, p ? { productId: p.id, productName: nl ? p.name_nl ?? p.name : p.name, unit: p.unit } : { productId: null, productName: null, unit: null }); }} aria-label={nl ? 'Product' : 'Product'}>
                    <option value="">{nl ? 'Geen product (alleen tekst)' : 'No product (text only)'}</option>
                    {r.productId && !products.some((p) => p.id === r.productId) && <option value={r.productId}>{r.productName}</option>}
                    {products.map((p) => <option key={p.id} value={p.id}>{nl ? p.name_nl ?? p.name : p.name}</option>)}
                  </select>
                </div>
              </div>
              <button className="icon-btn ghost" onClick={() => setRows((rs) => rs.filter((_, j) => j !== k))} aria-label={nl ? `${r.display} verwijderen` : `Remove ${r.display}`}><X size={16} /></button>
            </div>
          ))}
        </div>
        <button className="btn sm ghost" style={{ alignSelf: 'flex-start' }} onClick={() => setRows((rs) => [...rs, { display: '', productId: null, productName: null, quantity: null, unit: null, optional: false }])}><Plus size={15} /> {nl ? 'Ingrediënt toevoegen' : 'Add ingredient'}</button>
        <p className="tiny muted">{nl ? 'Hoeveelheden zijn in gram, milliliter of stuks, voor het aantal porties hierboven. Zonder product telt een ingrediënt niet mee voor voorraad en voeding.' : 'Amounts are in grams, millilitres or pieces, for the servings above. Without a product, an ingredient doesn’t count for stock or nutrition.'}</p>
        <b className="small">{nl ? 'Stappen (één per regel)' : 'Steps (one per line)'}</b>
        <textarea className="input" rows={6} value={steps} onChange={(e) => setSteps(e.target.value)} aria-label={nl ? 'Stappen' : 'Steps'} />
      </div>
    </Sheet>
  );
}
