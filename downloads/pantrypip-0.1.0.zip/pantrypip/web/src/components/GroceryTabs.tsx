// Groceries has two views: what you have and what to buy. One switch, under the page title.
import { Refrigerator, ShoppingBasket } from 'lucide-react';
import { useQuery } from '../api';
import { useApp } from '../app-context';

export function GroceryTabs({ current }: { current: 'stock' | 'list' }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const count = useQuery<any>('/api/shopping', ['shopping']).data?.count ?? 0;
  return (
    <div className="loc-tabs plan-tabs grocery-tabs" role="tablist" aria-label={nl ? 'Boodschappen' : 'Groceries'}>
      <a className="seg-link" role="tab" href="#/inventory" aria-selected={current === 'stock'} aria-current={current === 'stock' ? 'page' : undefined}><Refrigerator size={16} /> {nl ? 'In huis' : 'In stock'}</a>
      <a className="seg-link" role="tab" href="#/shopping" aria-selected={current === 'list'} aria-current={current === 'list' ? 'page' : undefined}><ShoppingBasket size={16} /> {nl ? 'Boodschappenlijst' : 'Shopping list'}{count ? ` (${count})` : ''}</a>
    </div>
  );
}
