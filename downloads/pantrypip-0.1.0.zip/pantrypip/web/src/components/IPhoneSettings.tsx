import { useState } from 'react';
import { Copy, Smartphone, Trash2, ShieldCheck, ShieldAlert } from 'lucide-react';
import { post, del, useQuery, invalidate } from '../api';
import { useApp } from '../app-context';
import { useToast } from './ui';
import { isIOS, isStandalone, isSecure } from '../platform';

/** Settings → iPhone & Siri: connection status, home-screen install, and the "Hey Siri, PantryPip" shortcut. */
export function IPhoneSettings() {
  const app = useApp();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const tokens = useQuery<any[]>('/api/tokens', ['preferences']);
  const [created, setCreated] = useState<{ token: string; id: string } | null>(null);
  const endpoint = `${location.origin}/api/shortcut/say`;
  const copy = (text: string) => navigator.clipboard?.writeText(text).then(() => toast({ text: nl ? 'Gekopieerd' : 'Copied' }));
  const secure = isSecure && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1';

  return (
    <div className="card pad stack">
      <b className="row"><Smartphone size={18} /> {nl ? 'iPhone & Siri' : 'iPhone & Siri'}</b>

      <div className="row small" style={{ alignItems: 'flex-start' }}>
        {secure ? <ShieldCheck size={18} color="var(--ok)" /> : <ShieldAlert size={18} color="var(--saffron)" />}
        <div className="grow">
          {secure
            ? nl ? `Verbonden via HTTPS (${location.host}). Camera, microfoon en meldingen werken.` : `Connected over HTTPS (${location.host}). Camera, microphone and notifications work.`
            : nl
              ? 'Voor je iPhone heeft PantryPip een https-adres nodig. Makkelijkst: Tailscale (één opdracht op deze computer). Of je eigen certificaat: `npm run cert` en `npm run start:https`, open dan http://<deze computer>:8787/setup op je iPhone. Zie docs/IPHONE.md.'
              : 'Your iPhone needs an https address for PantryPip. Easiest: Tailscale (one command on this computer). Or a home certificate: `npm run cert` and `npm run start:https`, then open http://<this computer>:8787/setup on your iPhone. See docs/IPHONE.md.'}
        </div>
      </div>
      {isIOS && !isStandalone && (
        <div className="tiny muted">{nl ? 'Tip: tik op Deel → “Zet op beginscherm” om PantryPip als app te openen.' : 'Tip: tap Share → “Add to Home Screen” to open PantryPip as an app.'}</div>
      )}

      <div className="small" style={{ fontWeight: 700, marginTop: 6 }}>{nl ? '“Hé Siri, PantryPip”' : '“Hey Siri, PantryPip”'}</div>
      <div className="tiny muted">
        {nl
          ? 'Een Opdracht die je inspreekt en naar PantryPip stuurt, zonder de app te openen. Siri leest het antwoord voor. Zonder woorden stelt hij de dagelijkse kookvraag.'
          : 'A Shortcut that sends what you say to PantryPip without opening the app, and Siri reads the answer. Run it without words and it asks the daily cooking question.'}
      </div>
      {!created ? (
        <button className="btn sm primary" style={{ alignSelf: 'flex-start' }} onClick={async () => {
          const r = await post('/api/tokens', { name: 'Siri' });
          setCreated(r);
          invalidate(['preferences']);
        }}>{nl ? 'Siri-sleutel maken' : 'Create Siri key'}</button>
      ) : (
        <div className="stack shortcut-steps">
          <div className="tiny" style={{ color: 'var(--tomato)' }}>{nl ? 'Deze sleutel zie je maar één keer. Kopieer hem nu.' : 'You’ll only see this key once. Copy it now.'}</div>
          <ol className="small" style={{ margin: 0, paddingLeft: 20 }}>
            <li>{nl ? 'Open de app Opdrachten → + → noem hem “PantryPip”.' : 'Open the Shortcuts app → + → name it “PantryPip”.'}</li>
            <li>{nl ? 'Voeg “Dicteer tekst” toe (taal: Nederlands of Engels).' : 'Add “Dictate Text” (language: English or Dutch).'}</li>
            <li>{nl ? 'Voeg “Haal inhoud op van URL” toe:' : 'Add “Get Contents of URL”:'}
              <div className="copy-row"><code>{endpoint}</code><button className="icon-btn ghost" aria-label="copy URL" onClick={() => copy(endpoint)}><Copy size={15} /></button></div>
              {nl ? 'Methode POST. Koptekst ' : 'Method POST. Header '}<code>Authorization</code>{nl ? ' met waarde:' : ' with value:'}
              <div className="copy-row"><code>Bearer {created.token}</code><button className="icon-btn ghost" aria-label="copy key" onClick={() => copy(`Bearer ${created.token}`)}><Copy size={15} /></button></div>
              {nl ? 'Hoofdtekst: JSON, veld ' : 'Request Body: JSON, field '}<code>text</code>{nl ? ' = Gedicteerde tekst.' : ' = Dictated Text.'}
            </li>
            <li>{nl ? 'Voeg “Spreek tekst uit” toe met de inhoud van de URL.' : 'Add “Speak Text” with Contents of URL.'}</li>
            <li>{nl ? 'Zeg “Hé Siri, PantryPip” en dan bijvoorbeeld “de melk is op”.' : 'Say “Hey Siri, PantryPip”, then e.g. “I finished the milk”.'}</li>
          </ol>
        </div>
      )}
      {(tokens.data ?? []).length > 0 && (
        <div className="stack" style={{ gap: 4 }}>
          {tokens.data!.map((t) => (
            <div key={t.id} className="row small">
              <span className="grow">🔑 {t.name} <span className="muted">· {t.last_used_at ? `${nl ? 'laatst gebruikt' : 'last used'} ${t.last_used_at.slice(0, 10)}` : nl ? 'nog niet gebruikt' : 'not used yet'}</span></span>
              <button className="icon-btn ghost" aria-label={nl ? 'Sleutel intrekken' : 'Revoke key'} onClick={async () => { await del(`/api/tokens/${t.id}`); invalidate(['preferences']); if (created?.id === t.id) setCreated(null); }}><Trash2 size={15} /></button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
