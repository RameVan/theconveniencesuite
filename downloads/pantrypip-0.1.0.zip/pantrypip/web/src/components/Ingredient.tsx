// Ingredient details and substitution choices: the type of a product (and correcting it), your own types,
// how easy it is to get in your country, supermarket products, and what can replace it.
import { useEffect, useState } from 'react';
import { ExternalLink, Plus, Check, ArrowRight } from 'lucide-react';
import { api, get, post, invalidate } from '../api';
import { useApp } from '../app-context';
import { Sheet, useToast } from './ui';
import { ShopLinks } from './ShopLinks';

const KIND: Record<string, [string, string]> = {
  exact: ['Same ingredient', 'Zelfde ingrediënt'], equivalent: ['Same thing, local name', 'Hetzelfde, lokale naam'], substitute: ['Good substitute', 'Goede vervanger'],
  approximate: ['Close, not the same', 'Lijkt erop, niet hetzelfde'], unresolved: ['Not matched', 'Niet gekoppeld'],
};
const AVAIL: Record<string, [string, string]> = {
  common: ['In ordinary supermarkets', 'In gewone supermarkten'], limited: ['In some supermarkets', 'In sommige supermarkten'],
  specialist: ['Specialist shops (toko, market)', 'Speciaalzaak (toko, markt)'], unavailable: ['Hard to get here', 'Hier moeilijk te krijgen'],
};
const STATUS: Record<string, [string, string]> = {
  verified: ['checked with the supermarket', 'gecontroleerd bij de supermarkt'], listed: ['listed for this supermarket in open data', 'in open data bij deze supermarkt'],
  unverified: ['sold in the Netherlands, supermarket unknown', 'verkocht in Nederland, supermarkt onbekend'], discontinued: ['possibly discontinued', 'mogelijk uit het assortiment'],
};
export const kindLabel = (k: string, nl: boolean) => KIND[k]?.[nl ? 1 : 0] ?? k;
export const availLabel = (k: string, nl: boolean) => AVAIL[k]?.[nl ? 1 : 0] ?? k;

/** Type, availability and supermarket products of one ingredient. `lotIds` enables correcting the type of stock. */
export function IngredientSheet({ productId, lotIds, onClose }: { productId: string; lotIds?: string[]; onClose: () => void }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const toast = useToast();
  const [d, setD] = useState<any>(null);
  const [naming, setNaming] = useState(false);
  const [newName, setNewName] = useState('');
  const [showAll, setShowAll] = useState(false);
  const load = () => get(`/api/ingredients/${productId}`).then(setD).catch((e) => toast({ text: e.message, error: true }));
  useEffect(() => {
    load();
  }, [productId]);
  const name = (p: any) => (nl ? p.name_nl ?? p.name : p.name);

  const correct = async (to: string) => {
    try {
      for (const id of lotIds ?? []) await post(`/api/inventory/lots/${id}/product`, { productId: to });
      invalidate(['inventory', 'recipes', 'shopping']);
      toast({ text: nl ? 'Soort aangepast' : 'Type corrected' });
      onClose();
    } catch (e: any) {
      toast({ text: e.message, error: true });
    }
  };
  const addType = async () => {
    try {
      const p = await post('/api/ingredients/custom-type', { family: d.family.id, name: newName, remember: true });
      if (lotIds?.length) await correct(p.id);
      else {
        invalidate(['inventory', 'recipes']);
        toast({ text: nl ? `${p.name} toegevoegd` : `${p.name} added` });
        setNaming(false);
        setNewName('');
        load();
      }
    } catch (e: any) {
      toast({ text: e.message, error: true });
    }
  };
  const prefer = async (choice: string | null) => {
    await api('PUT', '/api/ingredients/choice', { key: productId, choice });
    invalidate(['recipes', 'shopping']);
    load();
  };

  return (
    <Sheet title={d ? name(d.product) : '…'} onClose={onClose}>
      {!d ? <div className="skeleton" style={{ height: 160 }} /> : (
        <div className="stack ing-sheet">
          {d.family && (
            <section>
              <b className="small">{nl ? `Soort ${d.family.name_nl.toLowerCase()}` : `Type of ${d.family.name.toLowerCase()}`}</b>
              <div className="chips" style={{ marginTop: 6 }}>
                {d.variants.map((v: any) => (
                  <button key={v.id} className="chip" aria-pressed={v.id === d.product.id} disabled={v.id === d.product.id || !lotIds?.length || v.unit !== d.product.unit} onClick={() => correct(v.id)}>
                    {name(v)}{v.custom ? (nl ? ' (eigen)' : ' (yours)') : ''}
                  </button>
                ))}
                <button className="chip" onClick={() => setNaming(true)}><Plus size={13} /> {nl ? 'Eigen soort' : 'Your own type'}</button>
              </div>
              {lotIds?.length ? <p className="tiny muted">{nl ? 'Klopt de soort niet? Tik de juiste: je voorraad en de geschiedenis gaan mee.' : 'Wrong type? Tap the right one: your stock and its history move with it.'}</p> : null}
              {naming && (
                <form className="row" style={{ marginTop: 6 }} onSubmit={(e) => { e.preventDefault(); if (newName.trim().length > 1) addType(); }}>
                  <input className="input grow" autoFocus value={newName} onChange={(e) => setNewName(e.target.value)} placeholder={nl ? 'bijv. geitenmelk' : 'e.g. goat milk'} aria-label={nl ? 'Naam van je soort' : 'Name of your type'} />
                  <button className="btn primary sm" disabled={newName.trim().length < 2}><Check size={14} /> {nl ? 'Toevoegen' : 'Add'}</button>
                </form>
              )}
            </section>
          )}
          <section>
            <b className="small">{nl ? 'Te koop' : 'Where to buy'}</b>
            <div className="small" style={{ marginTop: 4 }}>{availLabel(d.availability, nl)}{d.country !== 'NL' ? ` (${d.country})` : ''}</div>
            {d.chains.length > 0 && <div className="chips" style={{ marginTop: 6 }}>{d.chains.map((c: any) => <span key={c.name} className="chip static">{c.name} <span className="muted">{c.count}</span></span>)}</div>}
            {d.retail.length > 0 ? (
              <div className="list retail-list" style={{ marginTop: 6 }}>
                {(showAll ? d.retail : d.retail.slice(0, 5)).map((r: any) => (
                  <a key={r.id} className="item" href={r.url} target="_blank" rel="noopener noreferrer">
                    <span className="grow" style={{ minWidth: 0 }}>
                      <span className="small ellipsis" style={{ display: 'block' }}>{r.name}{r.size_text ? ` · ${r.size_text}` : ''}</span>
                      <span className="tiny muted">{r.chain ?? (nl ? 'Supermarkt onbekend' : 'Supermarket unknown')} · {STATUS[r.status]?.[nl ? 1 : 0]} ({r.source}{r.last_verified ? `, ${r.last_verified}` : ''})</span>
                    </span>
                    <ExternalLink size={14} />
                  </a>
                ))}
              </div>
            ) : <p className="tiny muted">{nl ? 'Nog geen supermarktproducten bekend voor dit ingrediënt.' : 'No supermarket products known for this ingredient yet.'}</p>}
            {d.retail.length > 5 && <button className="btn sm ghost" onClick={() => setShowAll((x) => !x)}>{showAll ? (nl ? 'Minder' : 'Fewer') : nl ? `Alle ${d.retail.length}` : `All ${d.retail.length}`}</button>}
            {d.shops?.length > 0 && (
              <>
                <div className="small" style={{ marginTop: 10 }}>{nl ? `Zoek "${d.searchTerm}" in de webshop` : `Search "${d.searchTerm}" in the webshop`}</div>
                <ShopLinks shops={d.shops} term={d.searchTerm} nl={nl} />
              </>
            )}
            {d.product.package_options?.length > 0 && <p className="tiny muted">{nl ? 'Gangbare verpakkingen' : 'Usual pack sizes'}: {d.product.package_options.join(', ')} {d.product.unit === 'pcs' ? (nl ? 'stuks' : 'pcs') : d.product.unit}</p>}
          </section>
          {d.alternatives.length > 0 && (
            <section>
              <b className="small">{nl ? 'Kan vervangen worden door' : 'Can be replaced by'}</b>
              <div className="list" style={{ marginTop: 6 }}>
                {d.alternatives.map((a: any) => a.to && (
                  <div key={a.to.id} className="item alt-row">
                    <span className="grow" style={{ minWidth: 0 }}>
                      <span className="small" style={{ display: 'block' }}>{name(a.to)} <span className="pill">{kindLabel(a.kind, nl)}</span></span>
                      <span className="tiny muted">{a.note[nl ? 1 : 0]}{a.with?.length ? ` (+ ${a.with.map((w: any) => w.name.toLowerCase()).join(', ')})` : ''}</span>
                    </span>
                    {d.preferred === a.to.id
                      ? <button className="btn sm" onClick={() => prefer(null)}>{nl ? 'Toch het origineel' : 'Use the original'}</button>
                      : <button className="btn sm ghost" onClick={() => prefer(a.to.id)}>{nl ? 'Altijd gebruiken' : 'Always use'}</button>}
                  </div>
                ))}
              </div>
              {d.preferred && <p className="tiny muted">{nl ? 'Geldt voor al je recepten en boodschappen.' : 'Applies to all your recipes and shopping.'}</p>}
            </section>
          )}
        </div>
      )}
    </Sheet>
  );
}

/** One substituted or unmatched recipe line: use the suggestion, keep the original, or pick something else. */
export function SubstitutionSheet({ ing, onClose }: { ing: any; onClose: () => void }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const toast = useToast();
  const sub = ing.sub;
  const [products, setProducts] = useState<any[]>([]);
  useEffect(() => {
    get<any[]>('/api/products').then((l) => setProducts([...l].sort((a, b) => (nl ? a.name_nl ?? a.name : a.name).localeCompare(nl ? b.name_nl ?? b.name : b.name)))).catch(() => {});
  }, []);
  const choose = async (choice: string | null) => {
    try {
      await api('PUT', '/api/ingredients/choice', { key: sub.fromKey, choice });
      invalidate(['recipes', 'shopping', 'planner']);
      onClose();
    } catch (e: any) {
      toast({ text: e.message, error: true });
    }
  };
  const pname = (id: string) => {
    const p = products.find((x) => x.id === id);
    return p ? (nl ? p.name_nl ?? p.name : p.name) : id;
  };
  const current = sub.choice === 'keep' ? 'keep' : ing.product_id;
  return (
    <Sheet title={sub.original} onClose={onClose}>
      <div className="stack">
        {sub.status && <p className="small">{availLabel(sub.status, nl)}.</p>}
        {sub.options.length > 0 && (
          <div className="list">
            {sub.options.map((o: any, i: number) => (
              <button key={o.id} className="item alt-row" aria-pressed={current === o.id} onClick={() => choose(i === 0 ? null : o.id)}>
                <span className="grow" style={{ minWidth: 0, textAlign: 'left' }}>
                  <span className="small" style={{ display: 'block' }}><ArrowRight size={13} /> {pname(o.id)} <span className="pill">{kindLabel(o.kind, nl)}</span>{i === 0 ? <span className="tiny muted"> · {nl ? 'voorstel' : 'suggested'}</span> : null}</span>
                  {o.note && <span className="tiny muted">{o.note[nl ? 1 : 0]}</span>}
                </span>
                {current === o.id && <Check size={16} />}
              </button>
            ))}
          </div>
        )}
        <button className="btn" aria-pressed={current === 'keep'} onClick={() => choose('keep')}>
          {nl ? `Houd “${sub.original}”` : `Keep “${sub.original}”`}
          <span className="tiny muted" style={{ display: 'block' }}>{nl ? 'Niet bijgehouden in voorraad en voeding' : 'Not tracked in stock and nutrition'}</span>
        </button>
        <label className="small">{nl ? 'Of kies zelf een product' : 'Or pick a product yourself'}
          <select className="input" value="" onChange={(e) => e.target.value && choose(e.target.value)} style={{ marginTop: 4 }}>
            <option value="">{nl ? 'Kies…' : 'Choose…'}</option>
            {products.map((p) => <option key={p.id} value={p.id}>{nl ? p.name_nl ?? p.name : p.name}</option>)}
          </select>
        </label>
        <p className="tiny muted">{nl ? `Je keuze geldt voor elk recept met ${(ing.name ?? sub.original).toLowerCase()}, ook in je boodschappen.` : `Your choice applies to every recipe with ${(ing.name ?? sub.original).toLowerCase()}, and to your shopping list.`}</p>
      </div>
    </Sheet>
  );
}
