import { useState } from 'react';
import { Share, X, ShieldAlert } from 'lucide-react';
import { useApp } from '../app-context';
import { isIOS, isStandalone, isSecure } from '../platform';

const KEY = 'larder.installHintDismissed';

/**
 * iPhone: Safari can't install apps from a button, so explain the two-tap way.
 * Also warns when the page isn't on HTTPS, because then the camera and microphone are blocked.
 */
export function InstallHint() {
  const app = useApp();
  const nl = app.lang === 'nl';
  const [hidden, setHidden] = useState(() => {
    try {
      return localStorage.getItem(KEY) === '1';
    } catch {
      return false;
    }
  });
  const insecure = !isSecure && location.hostname !== 'localhost';
  if (insecure) {
    return (
      <div className="install-hint" role="note" style={{ background: 'var(--saffron-soft)' }}>
        <ShieldAlert size={20} />
        <div className="small">
          <b>{nl ? 'Camera en microfoon geblokkeerd' : 'Camera and microphone are blocked'}</b>
          <div>{nl ? 'Deze pagina gebruikt geen HTTPS. Open PantryPip via het https-adres (zie Instellingen → iPhone).' : 'This page isn’t on HTTPS. Open PantryPip at its https address (see Settings → iPhone).'}</div>
        </div>
      </div>
    );
  }
  if (!isIOS || isStandalone || hidden) return null;
  const dismiss = () => {
    setHidden(true);
    try {
      localStorage.setItem(KEY, '1');
    } catch {
      /* private mode */
    }
  };
  return (
    <div className="install-hint" role="note">
      <Share size={20} />
      <div className="small grow">
        <b>{nl ? 'Zet PantryPip op je beginscherm' : 'Add PantryPip to your Home Screen'}</b>
        <div>{nl ? 'Tik op Deel en dan “Zet op beginscherm”. Dan opent hij als app, schermvullend, en kan hij je dagelijks vragen wat je hebt gekookt.' : 'Tap Share, then “Add to Home Screen”. It then opens like an app, full screen, and can send you the daily cooking question.'}</div>
      </div>
      <button className="icon-btn ghost" aria-label={nl ? 'Sluiten' : 'Dismiss'} onClick={dismiss}><X size={16} /></button>
    </div>
  );
}
