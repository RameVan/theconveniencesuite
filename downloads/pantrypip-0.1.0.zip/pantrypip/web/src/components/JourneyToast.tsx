// "You moved forward" anywhere in the app when a journey step completes (adding groceries, saving a
// recipe, planning). It stays until you close it or open it; the full celebration plays on Progress.
import { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import { useQuery } from '../api';
import { useApp } from '../app-context';

const KEY = 'larder.toasted';
const seen = (): Set<string> => {
  try {
    return new Set(JSON.parse(localStorage.getItem(KEY) ?? '[]'));
  } catch {
    return new Set();
  }
};
/** Remember nodes already shown (e.g. in the cooking reward), so they don't pop up twice. */
export function markToasted(ids: string[]) {
  try {
    localStorage.setItem(KEY, JSON.stringify([...new Set([...seen(), ...ids])].slice(-300)));
  } catch {
    /* ignore */
  }
}

export function JourneyToast() {
  const app = useApp();
  const nl = app.lang === 'nl';
  const { data } = useQuery<any[]>('/api/journey/fresh', ['inventory', 'shopping', 'planner', 'recipes', 'game', 'home', 'preferences']);
  const [shown, setShown] = useState<any[]>([]);
  // New achievements join the ones still on screen; nothing disappears by itself.
  useEffect(() => {
    if (!data?.length) return;
    const s = seen();
    setShown((cur) => {
      const have = new Set(cur.map((n) => n.id));
      const add = data.filter((n) => !s.has(n.id) && !have.has(n.id));
      return add.length ? [...cur, ...add] : cur;
    });
  }, [data]);
  if (!shown.length) return null;
  const close = () => {
    markToasted(shown.map((n) => n.id));
    setShown([]);
  };
  const main = shown.find((n) => n.kind === 'boss') ?? shown.find((n) => n.kind !== 'track') ?? shown[0];
  const xp = shown.reduce((s, n) => s + n.xp, 0);
  return (
    <div className="journey-toast" role="status">
      <a className="jt-main" href="#/achievements" onClick={close}>
        <span className="jt-emoji">{main.emoji}</span>
        <span className="grow" style={{ minWidth: 0 }}>
          <span className="tiny">{main.kind === 'boss' ? (nl ? 'Hoofdstuk voltooid!' : 'Chapter complete!') : main.kind === 'milestone' ? (nl ? 'Beloningskist open!' : 'Reward chest opened!') : nl ? 'Prestatie behaald' : 'Achievement unlocked'}</span>
          <b className="ellipsis" style={{ display: 'block' }}>{nl ? main.title_nl : main.title}{shown.length > 1 ? (nl ? ` en ${shown.length - 1} meer` : ` and ${shown.length - 1} more`) : ''}</b>
        </span>
        <b className="jt-xp">+{xp} XP</b>
      </a>
      <button className="jt-close" onClick={close} aria-label={nl ? 'Sluiten' : 'Close'}><X size={18} /></button>
    </div>
  );
}
