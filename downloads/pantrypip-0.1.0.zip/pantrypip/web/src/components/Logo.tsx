// The PantryPip logo in the colours of the style on screen (see logo.ts).
import { usePaintedStyle } from '../appearance';
import { logoDataUrl, logoFor } from '../logo';

export function Logo({ size, className }: { size?: number; className?: string }) {
  const style = usePaintedStyle();
  return <img className={className} src={logoDataUrl(logoFor(style))} alt="" width={size} height={size} />;
}
