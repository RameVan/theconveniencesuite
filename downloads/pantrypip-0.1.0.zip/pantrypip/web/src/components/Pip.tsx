// Pip, the little sprout who travels the journey with you. Gains an apron, a chef's hat and a scarf
// as chapters are finished; its colour is one of the looks unlocked along the way. Pure SVG.
const SKINS: Record<string, { body: string; leaf: string }> = {
  sprout: { body: '#6FAE7B', leaf: '#3E7C59' }, tomato: { body: '#E0603E', leaf: '#3E7C59' }, lemon: { body: '#EBC447', leaf: '#5E8C3A' },
  aubergine: { body: '#7C5BA6', leaf: '#4E7A3A' }, blueberry: { body: '#4D74B8', leaf: '#3E7C59' }, pea: { body: '#8CC063', leaf: '#3F7A2E' },
  copper: { body: '#C27445', leaf: '#5B4632' }, golden: { body: '#D4AA3A', leaf: '#8A6A12' },
};

export function Pip({ skin = 'sprout', stages = [], size = 56, mood = 'happy', className = '' }: { skin?: string; stages?: string[]; size?: number; mood?: 'happy' | 'cheer' | 'sleepy'; className?: string }) {
  const c = SKINS[skin] ?? SKINS.sprout;
  const has = (s: string) => stages.includes(s);
  return (
    <svg className={`pip ${className}`} width={size} height={size} viewBox="0 0 64 64" role="img" aria-label="Pip">
      <ellipse cx="32" cy="60" rx="15" ry="2.6" fill="rgb(0 0 0 / 14%)" />
      {/* leaf sprout (hidden under the hat) */}
      {!has('hat') && (
        <g>
          <path d="M32 18 C32 12 30 9 27 7" stroke={c.leaf} strokeWidth="2.4" fill="none" strokeLinecap="round" />
          <path d="M27 7 C20 5 16 10 17 14 C22 15 26 12 27 7Z" fill={c.leaf} />
          <path d="M32 14 C36 6 43 6 45 10 C41 14 36 15 32 14Z" fill={c.leaf} opacity=".85" />
        </g>
      )}
      {/* body */}
      <path d="M32 17 C45 17 52 28 52 40 C52 52 43 58 32 58 C21 58 12 52 12 40 C12 28 19 17 32 17Z" fill={c.body} />
      <path d="M22 24 C25 21 29 20 32 20" stroke="#fff" strokeOpacity=".45" strokeWidth="3" strokeLinecap="round" fill="none" />
      {/* apron */}
      {has('apron') && (
        <g>
          <path d="M21 41 H43 V52 C40 56 24 56 21 52Z" fill="#FFFDF7" />
          <path d="M21 41 L17 34 M43 41 L47 34" stroke="#FFFDF7" strokeWidth="2" strokeLinecap="round" />
          <rect x="28" y="45" width="8" height="5" rx="1.5" fill={c.body} opacity=".35" />
        </g>
      )}
      {/* scarf */}
      {has('scarf') && (
        <g>
          <path d="M18 36 C26 40 38 40 46 36 L46 40 C38 44 26 44 18 40Z" fill="#D9532C" />
          <path d="M40 40 L44 49 L39 48 L37 41Z" fill="#B8431F" />
        </g>
      )}
      {/* face */}
      {mood === 'sleepy' ? (
        <g stroke="#1D2420" strokeWidth="2" strokeLinecap="round" fill="none"><path d="M23 32 h5" /><path d="M36 32 h5" /></g>
      ) : mood === 'cheer' ? (
        <g stroke="#1D2420" strokeWidth="2.2" strokeLinecap="round" fill="none"><path d="M22 33 q3 -4 6 0" /><path d="M36 33 q3 -4 6 0" /></g>
      ) : (
        <g fill="#1D2420"><ellipse cx="25.5" cy="32" rx="2.6" ry="3.1" /><ellipse cx="38.5" cy="32" rx="2.6" ry="3.1" /><circle cx="26.4" cy="31" r=".9" fill="#fff" /><circle cx="39.4" cy="31" r=".9" fill="#fff" /></g>
      )}
      <ellipse cx="20.5" cy="37.5" rx="3" ry="1.8" fill="#FF8A80" opacity=".55" />
      <ellipse cx="43.5" cy="37.5" rx="3" ry="1.8" fill="#FF8A80" opacity=".55" />
      <path d={mood === 'cheer' ? 'M27 37 Q32 43 37 37Z' : 'M28.5 37.5 Q32 40.5 35.5 37.5'} stroke="#1D2420" strokeWidth="2" strokeLinecap="round" fill={mood === 'cheer' ? '#1D2420' : 'none'} />
      {/* chef's hat */}
      {has('hat') && (
        <g>
          <path d="M21 20 C15 18 15 9 22 9 C23 4 30 2 33 6 C36 2 44 4 44 10 C50 10 50 18 44 20Z" fill="#FFFFFF" stroke="#E7E1D6" strokeWidth="1" />
          <rect x="21" y="18" width="23" height="5" rx="2" fill="#F3EFE7" stroke="#E7E1D6" strokeWidth="1" />
        </g>
      )}
    </svg>
  );
}
