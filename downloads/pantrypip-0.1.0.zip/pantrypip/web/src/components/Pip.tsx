// Pip, the companion who travels the journey with you. Drawn like the logo: Pip is the first "p" of the
// wordmark (a round bowl on a stem, one monoline stroke with round ends) with the leaf from the "i" on top
// of the stem and the face in the bowl. The stroke follows the text colour, so Pip looks the same in every
// style; the leaf takes the colour unlocked along the way (skin). Gains an apron tie, a chef's hat and a
// scarf as chapters are finished, drawn with the same line. Pure SVG; movement lives in styles.css.
const SKINS: Record<string, string> = {
  sprout: '#6A994E', tomato: '#E0603E', lemon: '#D9AE2B', aubergine: '#7C5BA6', blueberry: '#4D74B8', pea: '#7FB24F',
  copper: '#C27445', golden: '#C99A2A',
  // Seasonal events with friends.
  mint: '#5FBF98', watermelon: '#E5677A', pumpkin: '#E8863A', beet: '#A33A5E', cocoa: '#8A5A3E',
};

export type PipMood = 'happy' | 'calm' | 'cheer' | 'sleepy' | 'thinking' | 'surprised' | 'wink' | 'sad';

export function Pip({ skin = 'sprout', stages = [], size = 56, mood = 'happy', className = '', label = 'Pip' }: { skin?: string; stages?: string[]; size?: number; mood?: PipMood; className?: string; label?: string }) {
  const leaf = SKINS[skin] ?? 'var(--pip-leaf, #6A994E)';
  const has = (s: string) => stages.includes(s);
  // Stroke weight: the logo's stroke is a fifth of the bowl's width; a little lighter when small so it stays crisp.
  const w = size < 36 ? 5.5 : 5;
  const eye = { fill: 'currentColor' } as const;
  return (
    <svg className={`pip pip-${mood} ${className}`} width={size} height={size} viewBox="0 0 64 64" role="img" aria-label={label}>
      <g fill="none" stroke="currentColor" strokeWidth={w} strokeLinecap="round" strokeLinejoin="round">
        {/* the "p": stem and bowl */}
        <path className="pip-stem" d="M18 22 V56" />
        <circle className="pip-bowl" cx="33" cy="34" r="15" />
      </g>
      {/* the leaf from the "i", sways a little (styles.css) */}
      {!has('hat') && <path className="pip-leaf" d="M18 20 C18 12 22.5 7.5 30.5 7 C30 14.5 25.5 19 18 20Z" fill={leaf} />}
      {has('hat') && (
        <g className="pip-hat" fill="var(--surface, #fff)" stroke="currentColor" strokeWidth="3" strokeLinejoin="round">
          <path d="M22 14 C17 13 17 6 22.5 6 C23.5 2 30 1 32 4.5 C34.5 1 41 2.5 41 7 C46 7 46 13.5 41 14 Z" />
          <path d="M23 14 H40 V18 H23 Z" />
        </g>
      )}
      {/* face */}
      <g className="pip-face">
        {mood === 'cheer' ? (
          <g fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round"><path d="M25.5 33 q2.5 -3.4 5 0" /><path d="M35.5 33 q2.5 -3.4 5 0" /></g>
        ) : mood === 'sleepy' ? (
          <g fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round"><path d="M25.5 32.5 h4.5" /><path d="M36 32.5 h4.5" /></g>
        ) : mood === 'wink' ? (
          <g><circle className="pip-eye" cx="28" cy="32" r="2.4" {...eye} /><path d="M35.5 32.5 q2.5 2.4 5 0" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" /></g>
        ) : mood === 'thinking' ? (
          <g className="pip-eyes"><circle className="pip-eye" cx="29.5" cy="30.5" r="2.4" {...eye} /><circle className="pip-eye" cx="39.5" cy="30.5" r="2.4" {...eye} /></g>
        ) : (
          <g className="pip-eyes"><circle className="pip-eye" cx="28" cy="32" r="2.4" {...eye} /><circle className="pip-eye" cx="38" cy="32" r="2.4" {...eye} /></g>
        )}
        {mood === 'happy' || mood === 'wink' ? <path d="M29.5 38.5 q3.5 2.8 7 0" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" />
          : mood === 'cheer' ? <path d="M28.5 37.5 q4.5 5 9 0 Z" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
          : mood === 'surprised' ? <circle cx="33" cy="39.5" r="2.2" fill="none" stroke="currentColor" strokeWidth="2.2" />
          : mood === 'sad' ? <path d="M29.5 40 q3.5 -2.6 7 0" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" />
          : mood === 'thinking' ? <path d="M31 39.5 h5" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" />
          : null}
      </g>
      {/* the coral dot from the second "p": a cheek */}
      {mood !== 'sleepy' && <circle cx="42.5" cy="38" r="2" fill="var(--pip-dot, #E76F51)" opacity=".85" />}
      {mood === 'thinking' && <g className="pip-think" fill="currentColor"><circle cx="52" cy="17" r="1.6" /><circle cx="56.5" cy="11.5" r="2.1" /></g>}
      {/* apron tie, scarf, friendship heart */}
      {has('apron') && <path d="M10.5 44 H23.5" stroke="var(--pip-dot, #E76F51)" strokeWidth="3.4" strokeLinecap="round" />}
      {has('scarf') && <path d="M21 47.5 C27 51.5 39 51.5 45 47.5 M41 49.5 L44 57" fill="none" stroke="var(--pip-dot, #E76F51)" strokeWidth="3.4" strokeLinecap="round" />}
      {has('heart') && <path d="M53 46 c-1.4 -2.4 -5 -1.4 -4.5 1.3 c.4 1.8 2.9 3.2 4.5 4.5 c1.6 -1.3 4.1 -2.7 4.5 -4.5 c.5 -2.7 -3.1 -3.7 -4.5 -1.3Z" fill="none" stroke="var(--pip-dot, #E76F51)" strokeWidth="2" strokeLinejoin="round" />}
    </svg>
  );
}
