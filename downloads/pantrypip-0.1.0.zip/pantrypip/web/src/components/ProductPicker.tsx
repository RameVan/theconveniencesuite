import { useEffect, useRef, useState } from 'react';
import { Plus } from 'lucide-react';
import { get, post } from '../api';
import { useApp } from '../app-context';

export interface Picked { id: string; name: string }

/**
 * Pick one product to use instead of another: suggestions while typing (from the second letter), and
 * when nothing fits, add what you typed as a new product (unit and category copied from the original,
 * so "Sushi rice" for "Basmati rice" is measured in grams and shelved with the rice).
 */
export function ProductPicker({ like, exclude = [], onPick, autoFocus }: { like?: { unit?: string; category?: string } | null; exclude?: string[]; onPick: (p: Picked) => void; autoFocus?: boolean }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const [text, setText] = useState('');
  const [hits, setHits] = useState<Picked[]>([]);
  const [busy, setBusy] = useState(false);
  const seq = useRef(0);
  const q = text.trim();

  useEffect(() => {
    const n = ++seq.current;
    if (q.length < 2) return setHits([]);
    const t = window.setTimeout(() => {
      get<Picked[]>(`/api/products/suggest?q=${encodeURIComponent(q)}&lang=${app.lang}`).then((r) => n === seq.current && setHits(r)).catch(() => {});
    }, 120);
    return () => window.clearTimeout(t);
  }, [q, app.lang]);

  const shown = hits.filter((h) => !exclude.includes(h.id));
  const exact = shown.some((h) => h.name.toLowerCase() === q.toLowerCase());
  const create = async () => {
    setBusy(true);
    try {
      const p = await post<{ id: string; name: string }>('/api/products', { name: (q.charAt(0).toUpperCase() + q.slice(1)).slice(0, 120), ...(like?.unit ? { unit: like.unit } : {}), ...(like?.category ? { category: like.category } : {}) });
      onPick({ id: p.id, name: p.name });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="avoid">
      <input className="input" value={text} autoFocus={autoFocus} autoComplete="off" enterKeyHint="done" placeholder={nl ? 'Typ een vervanger, bijv. sushirijst' : 'Type a replacement, e.g. sushi rice'} aria-label={nl ? 'Vervanger' : 'Replacement'}
        onChange={(e) => setText(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && shown[0]) { e.preventDefault(); onPick(shown[0]); } }} />
      {(shown.length > 0 || q.length >= 2) && (
        <ul className="avoid-hits" role="listbox">
          {shown.map((h) => (
            <li key={h.id} role="option" aria-selected={false}><button disabled={busy} onClick={() => onPick(h)}>{h.name}</button></li>
          ))}
          {q.length >= 2 && !exact && (
            <li role="option" aria-selected={false}><button disabled={busy} onClick={create}><Plus size={14} aria-hidden /> {nl ? `“${q}” toevoegen als nieuw product` : `Add “${q}” as a new product`}</button></li>
          )}
        </ul>
      )}
    </div>
  );
}
