import { useState } from 'react';
import { fmtQty, type Lang } from '../i18n';

export interface QtyProduct {
  id: string;
  name: string;
  name_nl?: string | null;
  unit: 'g' | 'ml' | 'pcs';
  package_size: number;
  piece_size?: number | null;
  piece_name?: string | null;
  package_options?: number[];
}

const plural = (w: string) => (/(o|ch|sh|s|x)$/.test(w) ? `${w}es` : /[^aeiou]y$/.test(w) ? `${w.slice(0, -1)}ies` : `${w}s`);

/** "eggs", "tomatoes", "chicken breast": how this product is counted, in the user's language. */
export function countNoun(p: QtyProduct, lang: Lang, n = 2): string {
  if (lang === 'nl') return (p.name_nl ?? p.name).toLowerCase();
  if (p.unit === 'pcs' && p.piece_name) return n === 1 ? p.piece_name : plural(p.piece_name);
  return p.name.toLowerCase();
}

/** The question for a product, in its own unit: "How many eggs?" vs "How much chicken breast?". */
export function quantityQuestion(p: QtyProduct, lang: Lang, count: number): string {
  const perPack = count > 1;
  const noun = countNoun(p, lang);
  if (lang === 'nl') {
    const stuks = p.unit === 'pcs' && !/(en|s)$/.test(noun) ? 'stuks ' : '';
    return `Hoeveel ${stuks}${noun}${perPack ? ' per verpakking' : ''}?`;
  }
  return p.unit === 'pcs' ? `How many ${noun}${perPack ? ' in each pack' : ''}?` : `How much ${noun}${perPack ? ' in each pack' : ''}?`;
}

export function optionLabel(p: QtyProduct, qty: number, lang: Lang): string {
  if (p.unit === 'pcs') return lang === 'en' && p.piece_name ? `${qty} ${countNoun(p, lang, qty)}` : `${qty}`;
  return fmtQty(qty, p.unit, lang);
}

/**
 * Parse what the user typed into base units of the product: "12", "1,5 kg", "750 g", "1 l", "600 g" of tomatoes → pieces.
 * Returns null if it can't be expressed in this product's unit.
 */
export function parseAmount(text: string, p: QtyProduct): number | null {
  const m = text.trim().toLowerCase().replace(',', '.').match(/^(\d+(?:\.\d+)?)\s*(kg|kilo|g|gr|gram|l|liter|litre|ml|cl|st|stuks|pcs)?$/);
  if (!m) return null;
  const n = Number(m[1]);
  const u = m[2];
  if (!u || u === 'st' || u === 'stuks' || u === 'pcs') return p.unit === 'pcs' ? Math.round(n) : n;
  const grams = u === 'kg' || u === 'kilo' ? n * 1000 : u === 'g' || u === 'gr' || u === 'gram' ? n : null;
  const ml = u === 'l' || u === 'liter' || u === 'litre' ? n * 1000 : u === 'ml' ? n : u === 'cl' ? n * 10 : null;
  if (p.unit === 'g') return grams ?? ml;
  if (p.unit === 'ml') return ml ?? grams;
  // Countable products: a weight converts to pieces through the typical piece weight.
  if (grams != null && p.piece_size) return Math.max(1, Math.round(grams / p.piece_size));
  return null;
}

/**
 * Inline question on a receipt line: pick one of the product's usual pack sizes or type an amount.
 * `perPack` is the amount in one package; the line's count multiplies it.
 */
export function QuantityAsk({ product, count, perPack, answered, lang, onAnswer, title, options: customOptions, note }: {
  product: QtyProduct; count: number; perPack: number | null; answered: boolean; lang: Lang; onAnswer: (perPack: number) => void;
  title?: string; options?: number[]; note?: string | null;
}) {
  const [text, setText] = useState('');
  const [bad, setBad] = useState(false);
  const options = customOptions?.length ? customOptions : product.package_options?.length ? product.package_options : [product.package_size];
  // Short examples of what can be typed: a count, or (for countables with a known piece weight) a weight.
  const unitHint = product.unit === 'pcs' ? (product.piece_size ? '7 / 600 g' : '7') : product.unit === 'g' ? '750 g' : '1,5 L';
  return (
    <div className={`qty-ask ${answered ? 'answered' : ''}`} role="group" aria-label={title ?? quantityQuestion(product, lang, count)}>
      <div className="qty-ask-q">
        {title ?? quantityQuestion(product, lang, count)}
        {!answered && note !== null && <span className="tiny muted"> · {note ?? (lang === 'nl' ? 'de bon zegt het niet' : 'the receipt doesn’t say')}</span>}
      </div>
      <div className="hint-chips">
        {options.map((o) => (
          <button key={o} type="button" className="chip" aria-pressed={answered && perPack === o} onClick={() => { setBad(false); onAnswer(o); }}>
            {optionLabel(product, o, lang)}
          </button>
        ))}
        <input
          className="input"
          style={{ minHeight: 34, width: 120, borderRadius: 999, borderColor: bad ? 'var(--tomato)' : undefined }}
          inputMode="decimal"
          placeholder={unitHint}
          aria-label={lang === 'nl' ? 'Andere hoeveelheid' : 'Other amount'}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onBlur={() => {
            if (!text.trim()) return;
            const v = parseAmount(text, product);
            setBad(v == null || v <= 0);
            if (v != null && v > 0) onAnswer(v);
          }}
          onKeyDown={(e) => e.key === 'Enter' && (e.target as HTMLInputElement).blur()}
        />
      </div>
      {count > 1 && answered && perPack != null && (
        <div className="tiny muted">{count} × {optionLabel(product, perPack, lang)} = {optionLabel(product, Math.round(count * perPack * 100) / 100, lang)}</div>
      )}
    </div>
  );
}

/** "Arrived broken or already bad": an egg cracked in transit, a yoghurt pot split. Logged as waste. */
export function DamagedAsk({ product, value, lang, onChange }: { product: QtyProduct; value: number; lang: Lang; onChange: (v: number) => void }) {
  const [text, setText] = useState('');
  const chips = product.unit === 'pcs' ? [0, 1, 2, 3] : [0];
  return (
    <div className="qty-ask damaged" role="group" aria-label={lang === 'nl' ? 'Kapot of al bedorven' : 'Broken or already bad'}>
      <div className="qty-ask-q">{lang === 'nl' ? 'Kapot of al bedorven bij thuiskomst?' : 'Broken or already bad when you got home?'}</div>
      <div className="hint-chips">
        {chips.map((n) => (
          <button key={n} type="button" className="chip" aria-pressed={value === n} onClick={() => onChange(n)}>
            {n === 0 ? (lang === 'nl' ? 'Niets' : 'None') : optionLabel(product, n, lang)}
          </button>
        ))}
        <input className="input" style={{ minHeight: 34, width: 110, borderRadius: 999 }} inputMode="decimal" placeholder={product.unit === 'pcs' ? '4' : product.unit === 'g' ? '200 g' : '250 ml'}
          aria-label={lang === 'nl' ? 'Hoeveel kapot' : 'How much was broken'} value={text} onChange={(e) => setText(e.target.value)}
          onBlur={() => { const v = parseAmount(text, product); if (v != null && v >= 0) onChange(v); }} onKeyDown={(e) => e.key === 'Enter' && (e.target as HTMLInputElement).blur()} />
      </div>
      {value > 0 && <div className="tiny muted">{lang === 'nl' ? 'Wordt toegevoegd en direct als verspilling (kapot) genoteerd.' : 'Added, then logged straight away as waste (damaged).'}</div>}
    </div>
  );
}

/** For a product that doesn't exist yet: ask how it's counted and how much there is. */
export function NewProductAsk({ name, lang, value, onChange }: { name: string; lang: Lang; value: { unit: 'g' | 'ml' | 'pcs'; amount: number | null }; onChange: (v: { unit: 'g' | 'ml' | 'pcs'; amount: number | null }) => void }) {
  const units: ['pcs' | 'g' | 'ml', string][] = [['pcs', lang === 'nl' ? 'stuks' : 'pieces'], ['g', 'gram'], ['ml', 'ml']];
  return (
    <div className="qty-ask" role="group">
      <div className="qty-ask-q">{lang === 'nl' ? `Hoeveel ${name.toLowerCase()} zat erin?` : `How much ${name.toLowerCase()} was it?`}</div>
      <div className="hint-chips">
        {units.map(([u, label]) => (
          <button key={u} type="button" className="chip" aria-pressed={value.unit === u} onClick={() => onChange({ ...value, unit: u })}>{label}</button>
        ))}
        <input className="input" style={{ minHeight: 34, width: 110, borderRadius: 999 }} inputMode="decimal" aria-label="amount"
          defaultValue={value.amount ?? ''} onChange={(e) => onChange({ ...value, amount: Number(e.target.value.replace(',', '.')) || null })} />
      </div>
    </div>
  );
}
