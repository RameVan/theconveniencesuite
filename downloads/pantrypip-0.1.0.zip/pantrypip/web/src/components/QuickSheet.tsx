import { uiPrefs } from '../appearance';
import { useEffect, useMemo, useState } from 'react';
import { Search, ScanBarcode, ReceiptText } from 'lucide-react';
import { get, post, requestId, invalidate, useDebounced, useQuery } from '../api';
import { useApp, SCOPES_ALL, type QuickOpts } from '../app-context';
import { useT, fmtQty, productName } from '../i18n';
import { Sheet, Thumb, useToast } from './ui';

type Mode = NonNullable<QuickOpts['mode']>;

const REASONS: [string, string, string][] = [
  ['spoiled', 'Went bad', 'Bedorven'], ['damaged', 'Broken / damaged', 'Kapot / beschadigd'], ['expired', 'Past its date', 'Over de datum'],
  ['mouldy', 'Mouldy', 'Beschimmeld'], ['other', 'Other', 'Anders'],
];


/** Amount presets per product unit. Values are in base units (g / ml / pcs), or packages for 'add'. */
function presets(p: any, mode: Mode, have: number, size: number = p.package_size): { label: string; qty: number | 'all'; packages?: number }[] {
  const lang = 'en';
  if (mode === 'add' || mode === 'list') {
    const pk = (n: number) => ({ label: `${n} × ${fmtQty(size, p.unit, lang)}`, qty: n * size, packages: n });
    return p.unit === 'pcs' && size === 1 ? [1, 2, 3, 4, 6].map((n) => ({ label: `${n}`, qty: n, packages: n })) : [pk(1), pk(2), pk(3)];
  }
  const out: { label: string; qty: number | 'all' }[] = [];
  if (p.unit === 'ml') [100, 250, 500].forEach((q) => out.push({ label: fmtQty(q, 'ml'), qty: q }));
  else if (p.unit === 'g') (p.piece_size ? [1, 2, 4].map((n) => n * p.piece_size) : [50, 100, 250]).forEach((q) => out.push({ label: p.piece_size && p.piece_name ? `${Math.round(q / p.piece_size)} ${p.piece_name}${q / p.piece_size > 1 ? 's' : ''}` : fmtQty(q, 'g'), qty: q }));
  else [1, 2, 3].forEach((n) => out.push({ label: `${n}`, qty: n }));
  if (have > 0) out.push({ label: mode === 'discard' ? 'All of it' : 'All / finished', qty: 'all' });
  return out.filter((o) => o.qty === 'all' || have <= 0 || o.qty <= have * 1.01 || mode === 'use');
}

export function QuickSheet({ opts, onClose }: { opts: QuickOpts; onClose: () => void }) {
  const app = useApp();
  const t = useT();
  const toast = useToast();
  const [mode, setMode] = useState<Mode>(opts.mode ?? 'use');
  const [q, setQ] = useState(opts.name ?? '');
  const [selected, setSelected] = useState<any | null>(null);
  const [custom, setCustom] = useState('');
  const [reason, setReason] = useState('spoiled');
  const dq = useDebounced(q, 120);
  const inv = useQuery<any>('/api/inventory', ['inventory']);
  const [results, setResults] = useState<any[]>([]);
  // Branded products from the shops (Open Food Facts), and the one picked: its brand and size go on the list.
  const [shop, setShop] = useState<any[]>([]);
  const [picked, setPicked] = useState<string | null>(null);
  // Pack size for adding and the list: the product's usual one, another it's sold in, or your own (24 eggs).
  const [pack, setPack] = useState<number | null>(null);
  const [otherPack, setOtherPack] = useState(false);
  useEffect(() => {
    setPack(selected?.package_size ?? null);
    setOtherPack(false);
  }, [selected?.id]);

  useEffect(() => {
    if (opts.productId) get(`/api/products/${opts.productId}`).then((r) => setSelected(r.product));
  }, [opts.productId]);
  useEffect(() => {
    if (!dq.trim()) return setResults([]);
    let alive = true;
    get(`/api/products?q=${encodeURIComponent(dq)}`).then((r) => alive && setResults(r));
    if (dq.trim().length >= 2) get(`/api/catalogue?q=${encodeURIComponent(dq)}`).then((r) => alive && setShop(r)).catch(() => alive && setShop([]));
    else setShop([]);
    return () => {
      alive = false;
    };
  }, [dq]);
  const pickShop = async (x: any) => {
    const p = await post(`/api/catalogue/${x.ean}/use`, {});
    setPicked(x.brand || null);
    setSelected(p);
  };

  const createProduct = async (name: string) => setSelected(await post('/api/products', { name }));
  // Enter: the product with exactly this name, or else a new one (adding) / the only match (using, throwing away).
  const onEnter = async () => {
    const name = q.trim();
    if (!name) return;
    const found: any[] = await get(`/api/products?q=${encodeURIComponent(name)}`);
    const same = (x?: string | null) => !!x && x.trim().toLowerCase() === name.toLowerCase();
    const exact = found.find((p) => same(p.name) || same(p.name_nl) || same(productName(p, app.lang)));
    if (exact) setSelected(exact);
    else if (mode !== 'use' && mode !== 'discard') await createProduct(name);
    else if (found.length === 1) setSelected(found[0]);
  };

  const stockById = useMemo(() => new Map<string, any>((inv.data?.items ?? []).map((s: any) => [s.product.id, s])), [inv.data]);
  const inStock = (inv.data?.items ?? []).filter((s: any) => s.confirmed > 0 && !s.product.staple);
  const list = q.trim() ? results : mode === 'use' || mode === 'discard' ? inStock.map((s: any) => s.product) : inStock.map((s: any) => s.product).slice(0, 12);
  const have = selected ? (stockById.get(selected.id)?.confirmed ?? 0) : 0;

  const size = pack && pack > 0 ? pack : selected?.package_size;
  const packed = !!selected && (mode === 'add' || mode === 'list') && !(selected.unit === 'pcs' && selected.package_size === 1);
  const sizes: number[] = selected ? [...new Set<number>([...(selected.package_options ?? []), selected.package_size].filter((x: number) => x > 0))].sort((a, b) => a - b) : [];

  const commit = async (amount: { qty: number | 'all'; packages?: number }) => {
    if (!selected) return;
    const name = productName(selected, app.lang);
    try {
      if (mode === 'list') {
        await post('/api/shopping', { productId: selected.id, packages: amount.packages ?? 1, packSize: size, note: picked });
        toast({ text: `${name} → ${t('Shopping')}` });
      } else if (mode === 'add') {
        const r = await post('/api/inventory/add', { productId: selected.id, quantity: amount.qty, clientRequestId: requestId() });
        toast({ text: `${name} +${fmtQty(amount.qty as number, selected.unit, app.lang)}`, undo: () => post('/api/inventory/undo', { batchId: r.batchId }).then(() => invalidate(SCOPES_ALL)) });
      } else {
        if (mode === 'discard' && uiPrefs.confirmDestructive && !confirm(app.lang === 'nl' ? `${name} weggooien?` : `Throw away ${name}?`)) return;
        const r = await post('/api/inventory/consume', { productId: selected.id, quantity: amount.qty, type: mode === 'discard' ? 'discard' : 'consume', reason: mode === 'discard' ? reason : null, clientRequestId: requestId() });
        const used = r.result?.deducted ?? 0;
        toast({ text: `${name} −${fmtQty(used, selected.unit, app.lang)}`, undo: () => post('/api/inventory/undo', { batchId: r.batchId }).then(() => invalidate(SCOPES_ALL)) });
      }
      invalidate(SCOPES_ALL);
      onClose();
    } catch (e: any) {
      toast({ text: e.message, error: true });
    }
  };

  const modes: { id: Mode; label: string }[] = [
    { id: 'use', label: t('Use') },
    { id: 'add', label: t('Add') },
    { id: 'discard', label: t('Throw away') },
    { id: 'list', label: t('To list') },
  ];

  return (
    <Sheet title={modes.find((m) => m.id === mode)?.label ?? t('Quick add')} onClose={onClose}>
      <div className="loc-tabs" role="tablist">
        {modes.map((m) => (
          <button key={m.id} aria-pressed={mode === m.id} onClick={() => setMode(m.id)}>{m.label}</button>
        ))}
      </div>
      {!selected ? (
        <>
          <div className="row">
            <div className="search grow">
              <Search />
              <input className="input" autoFocus value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.nativeEvent.isComposing) { e.preventDefault(); onEnter(); } }} enterKeyHint="go" placeholder={app.lang === 'nl' ? 'Product zoeken…' : 'Find a product…'} aria-label="Product" />
            </div>
            <button className="icon-btn" onClick={() => (onClose(), app.openBarcode())} aria-label={t('Scan barcode')}><ScanBarcode /></button>
            {mode === 'add' && <button className="icon-btn" onClick={() => (onClose(), app.openReceipt())} aria-label={t('Scan receipt')}><ReceiptText /></button>}
          </div>
          <div className="list" style={{ marginTop: 12 }}>
            {list.slice(0, 30).map((p: any) => {
              const s = stockById.get(p.id);
              return (
                <button key={p.id} className="item" onClick={() => setSelected(p)}>
                  <Thumb product={p} />
                  <span className="grow">
                    <span className="title">{productName(p, app.lang)}</span>
                    {s && <span className="meta">{fmtQty(s.showEstimate ? s.estimated : s.confirmed, p.unit, app.lang)}</span>}
                  </span>
                </button>
              );
            })}
            {!!shop.length && mode !== 'use' && mode !== 'discard' && (
              <>
                <div className="small muted" style={{ margin: '10px 4px 2px', fontWeight: 700 }}>{app.lang === 'nl' ? 'In de winkel' : 'In the shops'}</div>
                {shop.slice(0, 12).map((x: any) => (
                  <button key={x.ean} className="item" onClick={() => pickShop(x)}>
                    <Thumb product={{ image_url: x.image_url, category: x.category }} />
                    <span className="grow" style={{ minWidth: 0 }}>
                      <span className="title ellipsis" style={{ display: 'block' }}>{x.name}</span>
                      <span className="meta ellipsis" style={{ display: 'block' }}>{[x.brand, x.sizes?.length ? x.sizes.map((z: any) => fmtQty(z.qty, z.unit, app.lang)).join(' / ') : x.size, ...x.chains.map((c: any) => c.name)].filter(Boolean).join(' · ')}</span>
                      {x.ingredient && <span className="why-tag ellipsis" style={{ display: 'block' }}>{app.lang === 'nl' ? `telt als ${x.ingredient.name_nl || x.ingredient.name}` : `counts as ${x.ingredient.name}`}</span>}
                    </span>
                  </button>
                ))}
              </>
            )}
            {q.trim() && mode !== 'use' && mode !== 'discard' && (
              <button className="item" onClick={() => createProduct(q.trim())}>
                <Thumb emoji="＋" />
                <span className="grow title">{app.lang === 'nl' ? `Nieuw product “${q.trim()}”` : `New product “${q.trim()}”`}</span>
              </button>
            )}
            {!list.length && !q.trim() && <div className="empty small">{app.lang === 'nl' ? 'Typ om te zoeken' : 'Type to search'}</div>}
          </div>
        </>
      ) : (
        <div className="stack">
          <div className="row">
            <Thumb product={selected} />
            <div className="grow">
              <div className="title" style={{ fontWeight: 700, fontSize: 17 }}>{productName(selected, app.lang)}</div>
              {picked && <div className="small">{picked}</div>}
              <div className="muted small">{have > 0 ? `${app.lang === 'nl' ? 'In huis' : 'In stock'}: ${fmtQty(have, selected.unit, app.lang)}` : app.lang === 'nl' ? 'Niet in voorraad' : 'Not in stock'}</div>
            </div>
            <button className="btn ghost sm" onClick={() => (setSelected(null), setPicked(null))}>{t('Back')}</button>
          </div>
          {mode === 'discard' && (
            <div className="stack" style={{ gap: 6 }}>
              <div className="small muted">{app.lang === 'nl' ? 'Waarom?' : 'Why?'}</div>
              <div className="hint-chips">
                {REASONS.map(([id, en, nl]) => <button key={id} type="button" className="chip" aria-pressed={reason === id} onClick={() => setReason(id)}>{app.lang === 'nl' ? nl : en}</button>)}
              </div>
              <div className="small muted">{app.lang === 'nl' ? 'Hoeveel?' : 'How much?'}</div>
            </div>
          )}
          {packed && (
            <div className="stack" style={{ gap: 6 }}>
              <div className="small muted">{app.lang === 'nl' ? 'Verpakking' : 'Pack size'}</div>
              <div className="hint-chips">
                {sizes.map((x) => <button key={x} type="button" className="chip" aria-pressed={!otherPack && size === x} onClick={() => (setPack(x), setOtherPack(false))}>{fmtQty(x, selected.unit, app.lang)}</button>)}
                <button type="button" className="chip" aria-pressed={otherPack} onClick={() => setOtherPack(true)}>{app.lang === 'nl' ? 'Anders…' : 'Other…'}</button>
              </div>
              {otherPack && (
                <input className="input" inputMode="decimal" autoFocus aria-label={app.lang === 'nl' ? 'Verpakkingsgrootte' : 'Pack size'}
                  placeholder={`${app.lang === 'nl' ? 'Per verpakking' : 'Per pack'} (${selected.unit === 'pcs' ? (app.lang === 'nl' ? 'stuks' : 'pieces') : selected.unit})`}
                  onChange={(e) => { const n = Number(e.target.value.replace(',', '.')); setPack(n > 0 ? n : selected.package_size); }} />
              )}
            </div>
          )}
          <div className="hint-chips" style={{ gap: 8 }}>
            {presets(selected, mode, have, packed ? size : selected.package_size).map((p) => (
              <button key={p.label} className="btn lg" style={{ flex: '1 1 30%' }} onClick={() => commit(p)}>{p.label}</button>
            ))}
          </div>
          <form className="row" onSubmit={(e) => { e.preventDefault(); const n = Number(custom.replace(',', '.')); if (n > 0) commit(mode === 'add' || mode === 'list' ? { qty: n, packages: Math.max(1, Math.round(n / size)) } : { qty: n }); }}>
            <input className="input" inputMode="decimal" value={custom} onChange={(e) => setCustom(e.target.value)} placeholder={`${app.lang === 'nl' ? 'Andere hoeveelheid' : 'Other amount'} (${selected.unit === 'pcs' ? (app.lang === 'nl' ? 'stuks' : 'pieces') : selected.unit})`} />
            <button className="btn primary" type="submit">{t('Done')}</button>
          </form>
        </div>
      )}
    </Sheet>
  );
}
