import { useRef, useState } from 'react';
import { Camera, ImagePlus, ClipboardPaste, AlertTriangle, Search } from 'lucide-react';
import { get, post, invalidate } from '../api';
import { useApp, SCOPES_ALL } from '../app-context';
import { useT, fmtQty } from '../i18n';
import { Sheet, Thumb, useToast, emojiFor } from './ui';
import { QuantityAsk, NewProductAsk, DamagedAsk, type QtyProduct } from './QuantityAsk';

/** Downscale a photo so uploads stay small and fast (receipts stay readable at 1600px). */
/** Load a photo the way the user sees it: an <img> applies the EXIF rotation iPhones store. */
function loadImage(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => (URL.revokeObjectURL(url), resolve(img));
    img.onerror = () => (URL.revokeObjectURL(url), reject(new Error('This photo format can’t be read. Try a screenshot or JPEG.')));
    img.src = url;
  });
}

export async function shrink(file: File, max = 1600): Promise<{ mediaType: 'image/jpeg'; data: string; preview: string }> {
  const img = await loadImage(file);
  const w = img.naturalWidth;
  const h = img.naturalHeight;
  // 1600 px keeps receipts readable; iPhone photos are 4000+ px and would make uploads and OCR slow.
  const scale = Math.min(1, max / Math.max(w, h));
  const c = document.createElement('canvas');
  c.width = Math.round(w * scale);
  c.height = Math.round(h * scale);
  c.getContext('2d')!.drawImage(img, 0, 0, c.width, c.height);
  const url = c.toDataURL('image/jpeg', 0.82);
  return { mediaType: 'image/jpeg', data: url.split(',')[1], preview: url };
}

/**
 * Even out the light before OCR: divide each pixel by the blurred page around it, so shadows, curled paper and a
 * grey table disappear and faded thermal print turns black. Light text on a dark screen is inverted first.
 * On a photographed receipt this is the difference between "1798" and "1,79 3,58".
 */
export async function evenLight(src: string): Promise<string> {
  const img = new Image();
  img.src = src;
  await img.decode();
  const w = img.naturalWidth;
  const h = img.naturalHeight;
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d', { willReadFrequently: true })!;
  ctx.drawImage(img, 0, 0);
  // The background: a 1/16 copy, blurred, scaled back up.
  const small = document.createElement('canvas');
  small.width = Math.max(1, Math.round(w / 16));
  small.height = Math.max(1, Math.round(h / 16));
  const sx = small.getContext('2d')!;
  sx.filter = 'blur(2px)';
  sx.drawImage(c, 0, 0, small.width, small.height);
  const bgc = document.createElement('canvas');
  bgc.width = w;
  bgc.height = h;
  const bx = bgc.getContext('2d', { willReadFrequently: true })!;
  bx.drawImage(small, 0, 0, w, h);
  const bg = bx.getImageData(0, 0, w, h).data;
  const px = ctx.getImageData(0, 0, w, h);
  const d = px.data;
  const lum = (a: Uint8ClampedArray, i: number) => 0.299 * a[i] + 0.587 * a[i + 1] + 0.114 * a[i + 2];
  let sum = 0;
  for (let i = 0; i < d.length; i += 64) sum += lum(bg, i);
  const dark = sum / (d.length / 64) < 110;
  for (let i = 0; i < d.length; i += 4) {
    let v = lum(d, i);
    let b = lum(bg, i);
    if (dark) {
      v = 255 - v;
      b = 255 - b;
    }
    const r = Math.min(1, Math.max(0, (v / Math.max(1, b) - 0.55) / 0.4));
    d[i] = d[i + 1] = d[i + 2] = Math.round(r * 255);
  }
  ctx.putImageData(px, 0, 0);
  return c.toDataURL('image/png');
}

/** On-device OCR (no AI configured): Tesseract with Dutch + English models, loaded on demand. */
export async function ocr(images: { preview: string }[], onProgress: (p: number) => void): Promise<string> {
  const { createWorker } = await import('tesseract.js');
  const worker = await createWorker(['nld', 'eng'], 1, { logger: (m: any) => m.status === 'recognizing text' && onProgress(m.progress) });
  let text = '';
  for (const img of images) {
    const r = await worker.recognize(await evenLight(img.preview).catch(() => img.preview));
    text += r.data.text + '\n';
  }
  await worker.terminate();
  return text;
}

type Decision = {
  action: 'add' | 'skip'; productId?: string | null; productName?: string | null; packages?: number; quantity?: number | null; unit?: string | null;
  newProduct?: { name: string } | null; newQty?: { unit: 'g' | 'ml' | 'pcs'; amount: number | null }; duplicate?: 'reconcile' | 'add';
  product?: QtyProduct | null; certain?: boolean; answered?: boolean; perPack?: number | null; damaged?: number;
};

/** Same rule as the server: a weight, a printed size or a single-size product makes the amount certain. */
function certainFor(line: any, p: QtyProduct): boolean {
  if (line.weightKg) return true;
  if (line.size && (line.size.unit === p.unit || (line.size.unit === 'g' && p.unit === 'pcs' && p.piece_size))) return true;
  return !(p.package_options ?? []).length;
}

export function ReceiptSheet({ onClose }: { onClose: () => void }) {
  const app = useApp();
  const t = useT();
  const toast = useToast();
  const [images, setImages] = useState<{ mediaType: 'image/jpeg'; data: string; preview: string }[]>([]);
  const [text, setText] = useState('');
  const [pasting, setPasting] = useState(false);
  const [stage, setStage] = useState<'capture' | 'reading' | 'review'>('capture');
  const [progress, setProgress] = useState(0);
  const [draft, setDraft] = useState<any>(null);
  const [decisions, setDecisions] = useState<Record<number, Decision>>({});
  const [editing, setEditing] = useState<number | null>(null);
  const [qtyEdit, setQtyEdit] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const camera = useRef<HTMLInputElement>(null);
  const upload = useRef<HTMLInputElement>(null);

  const addFiles = async (files: FileList | null) => {
    if (!files) return;
    const shrunk = await Promise.all([...files].slice(0, 6).map(shrink));
    setImages((s) => [...s, ...shrunk].slice(0, 6));
  };

  const read = async () => {
    setError(null);
    setStage('reading');
    try {
      let d;
      if (text.trim()) d = await post('/api/receipts/scan', { text });
      else if (app.config?.ai) d = await post('/api/receipts/scan', { images: images.map(({ mediaType, data }) => ({ mediaType, data })) });
      else {
        const ocrText = await ocr(images, setProgress);
        d = await post('/api/receipts/scan', { text: ocrText });
      }
      setDraft(d);
      const init: Record<number, Decision> = {};
      for (const p of d.proposals) {
        const count = p.line.count || 1;
        init[p.index] = {
          action: p.productId ? 'add' : 'skip', productId: p.productId, productName: p.productName, packages: p.packages, quantity: p.quantity, unit: p.unit,
          product: p.product, certain: p.quantityCertain, answered: false, perPack: p.quantity != null && !p.line.weightKg ? p.quantity / count : null,
        };
      }
      setDecisions(init);
      setStage('review');
    } catch (e: any) {
      setError(e.message);
      setStage('capture');
    }
  };

  const commit = async (force = false) => {
    const lines = draft.proposals.map((p: any) => {
      const d = decisions[p.index];
      const changed = d.productId !== p.productId;
      const count = p.line.count || 1;
      const nq = d.newQty?.amount ? d.newQty : null;
      return {
        index: p.index,
        action: d.action,
        productId: d.productId ?? null,
        newProduct: d.newProduct ? { name: d.newProduct.name, ...(nq ? { unit: nq.unit, package_size: nq.amount } : {}) } : null,
        // An answered quantity question always wins; otherwise the server works it out from the line.
        quantity: d.answered && d.perPack ? d.perPack * count : nq ? nq.amount! * count : changed ? null : d.quantity ?? null,
        packages: d.answered || nq ? count : d.packages ?? null,
        duplicate: d.duplicate,
        damaged: d.damaged || null,
      };
    });
    try {
      const r = await post(`/api/receipts/${draft.id}/commit`, { lines, force });
      invalidate(SCOPES_ALL);
      const n = r.added.length + r.reconciled.length;
      toast({ text: app.lang === 'nl' ? `${n} producten toegevoegd` : `${n} products added`, undo: r.batchId ? () => post('/api/inventory/undo', { batchId: r.batchId }).then(() => invalidate(SCOPES_ALL)) : undefined });
      onClose();
    } catch (e: any) {
      if (e.status === 409 && confirm(app.lang === 'nl' ? 'Deze bon is al toegevoegd. Toch nog een keer toevoegen?' : 'This receipt was already added. Add it again anyway?')) return commit(true);
      setError(e.message);
    }
  };

  const set = (i: number, patch: Partial<Decision>) => setDecisions((d) => ({ ...d, [i]: { ...d[i], ...patch } }));
  const count = Object.values(decisions).filter((d) => d.action === 'add').length;
  const openQuestions = Object.values(decisions).filter((d) => d.action === 'add' && d.product && !d.certain && !d.answered).length;

  return (
    <Sheet title={stage === 'review' ? t('Review receipt') : t('Scan receipt')} onClose={onClose} wide
      footer={stage === 'review' ? (
        <>
          <button className="btn ghost" onClick={() => setStage('capture')}>{t('Back')}</button>
          <button className="btn primary grow lg" onClick={() => commit()} disabled={!count}>{app.lang === 'nl' ? `${count} toevoegen aan voorraad` : `Add ${count} to inventory`}</button>
        </>
      ) : stage === 'capture' && (images.length || text.trim()) ? (
        <button className="btn primary block lg" onClick={read}>{app.lang === 'nl' ? 'Bon lezen' : 'Read receipt'}</button>
      ) : undefined}
    >
      {error && <p className="pill tomato" style={{ padding: '8px 12px', display: 'block', marginBottom: 10 }}>{error}</p>}
      {stage === 'capture' && (
        <div className="stack">
          <div className="dropzone">
            <div style={{ fontSize: 40 }} aria-hidden>🧾</div>
            <div className="small muted">{app.lang === 'nl' ? 'Maak een foto van je kassabon. Lange bon? Maak meerdere foto’s.' : 'Take a photo of your receipt. Long receipt? Take several photos.'}</div>
            <div className="row wrap" style={{ justifyContent: 'center' }}>
              <button className="btn primary" onClick={() => camera.current?.click()}><Camera size={18} /> {app.lang === 'nl' ? 'Foto maken' : 'Take photo'}</button>
              <button className="btn" onClick={() => upload.current?.click()}><ImagePlus size={18} /> {app.lang === 'nl' ? 'Uploaden' : 'Upload'}</button>
              <button className="btn" onClick={() => setPasting((p) => !p)}><ClipboardPaste size={18} /> {app.lang === 'nl' ? 'Tekst plakken' : 'Paste text'}</button>
            </div>
            <input ref={camera} type="file" accept="image/*" capture="environment" hidden onChange={(e) => addFiles(e.target.files)} />
            <input ref={upload} type="file" accept="image/*" multiple hidden onChange={(e) => addFiles(e.target.files)} />
          </div>
          {!!images.length && (
            <div className="thumbs">
              {images.map((im, i) => <img key={i} src={im.preview} alt={`page ${i + 1}`} />)}
            </div>
          )}
          {pasting && (
            <textarea className="input" style={{ minHeight: 160, padding: 12, fontFamily: 'ui-monospace, monospace', fontSize: 13 }} value={text} onChange={(e) => setText(e.target.value)}
              placeholder={app.lang === 'nl' ? 'Plak hier een digitale bon of e-mailbon…' : 'Paste a digital or email receipt here…'} />
          )}
          <p className="tiny muted">
            {app.config?.ai
              ? app.lang === 'nl' ? 'Foto’s worden gelezen door AI op de server en daarna niet bewaard.' : 'Photos are read by AI on the server and are not stored afterwards.'
              : app.lang === 'nl' ? 'Foto’s worden op dit apparaat gelezen (eerste keer laadt het taalmodel, ~10 MB).' : 'Photos are read on this device (the first time downloads the text model, ~10 MB).'}
          </p>
        </div>
      )}
      {stage === 'reading' && (
        <div className="empty">
          <div className="art">🧾</div>
          <h3>{app.lang === 'nl' ? 'Bon lezen…' : 'Reading your receipt…'}</h3>
          {progress > 0 && <div className="progress" style={{ maxWidth: 280, margin: '12px auto' }}><i style={{ width: `${progress * 100}%` }} /></div>}
        </div>
      )}
      {stage === 'review' && draft && (
        <div className="stack">
          <div className="row wrap small">
            <span className="pill herb">{draft.summary.store ?? (app.lang === 'nl' ? 'Onbekende winkel' : 'Unknown store')}</span>
            {draft.summary.date && <span className="pill grey">{draft.summary.date}</span>}
            {draft.summary.total != null && <span className="pill grey">€ {draft.summary.total.toFixed(2)}</span>}
            {draft.parser === 'ai' && <span className="pill plum">✦ AI</span>}
            {draft.summary.needsReview > 0 && <span className="pill saffron">{draft.summary.needsReview} × {t('Needs a check')}</span>}
            {openQuestions > 0 && <span className="pill saffron">{openQuestions} × {app.lang === 'nl' ? 'hoeveelheid?' : 'how much?'}</span>}
          </div>
          {draft.duplicateReceipt && <div className="pill tomato" style={{ padding: '8px 12px' }}><AlertTriangle size={14} /> {app.lang === 'nl' ? 'Deze bon lijkt al eerder toegevoegd.' : 'This receipt looks like one you already added.'}</div>}
          {draft.parsed.warnings.filter((w: string) => !w.startsWith('No products')).map((w: string) => <div key={w} className="tiny muted">⚠ {w}</div>)}
          <div className="list">
            {draft.proposals.map((p: any) => {
              const d = decisions[p.index];
              return (
                <div key={p.index}>
                  <div className={`rline ${p.needsReview && d.action === 'add' && !d.productId ? 'review' : ''} ${d.action === 'skip' ? 'skip' : ''}`}>
                    <button className={`check ${d.action === 'add' ? 'on' : ''}`} onClick={() => set(p.index, { action: d.action === 'add' ? 'skip' : 'add' })} aria-label={d.action === 'add' ? t('Skip') : t('Add')} aria-pressed={d.action === 'add'}>
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M5 12l5 5L20 7" /></svg>
                    </button>
                    <button className="grow" style={{ background: 'none', border: 0, textAlign: 'left', padding: 0 }} onClick={() => setEditing(editing === p.index ? null : p.index)}>
                      <div className="row" style={{ gap: 8 }}>
                        <span aria-hidden>{d.productId ? emojiFor({ id: d.productId }) : '❓'}</span>
                        <b className="ellipsis">{d.newProduct?.name ?? d.productName ?? (app.lang === 'nl' ? 'Kies product' : 'Choose product')}</b>
                        {p.needsReview && p.productId && d.productId === p.productId && <span className="pill saffron">?</span>}
                      </div>
                      <div className="raw ellipsis">{p.line.raw}</div>
                      {p.duplicateOf && d.action === 'add' && (
                        <div className="tiny" style={{ color: 'var(--herb)' }}>
                          {app.lang === 'nl' ? 'Al toegevoegd via je boodschappenlijst: wordt bijgewerkt, niet dubbel geteld.' : 'Already added from your shopping list: it will be updated, not counted twice.'}
                        </div>
                      )}
                    </button>
                    {/* Every amount can be changed: tap it (custom amount, and anything that arrived broken or bad). */}
                    <button className="qty num small qty-tap" style={{ textAlign: 'right' }} disabled={d.action !== 'add' || !d.product}
                      onClick={() => setQtyEdit(qtyEdit === p.index ? null : p.index)} aria-expanded={qtyEdit === p.index} aria-label={app.lang === 'nl' ? 'Hoeveelheid aanpassen' : 'Change amount'}>
                      {d.answered && d.perPack && d.product ? <b>{fmtQty(d.perPack * (p.line.count || 1), d.product.unit, app.lang)}</b>
                        : d.quantity && d.unit ? <b className={d.product && !d.certain ? 'estimate' : ''}>{d.product && !d.certain ? '≈ ' : ''}{fmtQty(d.quantity, d.unit, app.lang)}</b>
                        : <b>{p.line.count}×</b>}
                      {!!d.damaged && d.product && <div style={{ color: 'var(--tomato)' }}>−{fmtQty(d.damaged, d.product.unit, app.lang)} {app.lang === 'nl' ? 'kapot' : 'broken'}</div>}
                      {p.pricePaid != null && <div className="muted">€ {p.pricePaid.toFixed(2)}</div>}
                    </button>
                  </div>
                  {d.action === 'add' && d.product && (!d.certain || qtyEdit === p.index) && editing !== p.index && (
                    <QuantityAsk product={d.product} count={p.line.count || 1} perPack={d.perPack ?? null} answered={!!d.answered} lang={app.lang}
                      title={d.certain ? (app.lang === 'nl' ? 'Hoeveel heb je gekocht?' : 'How much did you buy?') : undefined} note={d.certain ? null : undefined}
                      onAnswer={(perPack) => set(p.index, { answered: true, perPack, quantity: perPack * (p.line.count || 1), unit: d.product!.unit })} />
                  )}
                  {d.action === 'add' && d.product && qtyEdit === p.index && editing !== p.index && (
                    <DamagedAsk product={d.product} value={d.damaged ?? 0} lang={app.lang} onChange={(v) => set(p.index, { damaged: v })} />
                  )}
                  {d.action === 'add' && d.newProduct && editing !== p.index && (
                    <NewProductAsk name={d.newProduct.name} lang={app.lang} value={d.newQty ?? { unit: 'pcs', amount: null }} onChange={(v) => set(p.index, { newQty: v })} />
                  )}
                  {editing === p.index && (
                    <ProductPicker initial={p.line.name} candidates={p.candidates}
                      onPick={(prod) => {
                        const count = p.line.count || 1;
                        const per = p.line.size && p.line.size.unit === prod.unit ? p.line.size.qty : prod.package_size;
                        set(p.index, {
                          action: 'add', productId: prod.id, productName: prod.name, newProduct: null, product: prod, certain: certainFor(p.line, prod), answered: false,
                          perPack: p.line.weightKg ? null : per, quantity: p.line.weightKg ? null : per * count, unit: prod.unit,
                        });
                        setEditing(null);
                      }}
                      onNew={(name) => { set(p.index, { action: 'add', productId: null, productName: null, newProduct: { name }, product: null, newQty: { unit: 'pcs', amount: null } }); setEditing(null); }} />
                  )}
                </div>
              );
            })}
          </div>
          <p className="tiny muted">{app.lang === 'nl' ? 'Correcties worden onthouden: volgende keer herkent PantryPip deze regels zelf.' : 'Corrections are remembered: next time PantryPip recognises these lines by itself.'}</p>
        </div>
      )}
    </Sheet>
  );
}

function ProductPicker({ initial, candidates, onPick, onNew }: { initial: string; candidates: { productId: string; name: string }[]; onPick: (p: any) => void; onNew: (name: string) => void }) {
  const [q, setQ] = useState('');
  const [res, setRes] = useState<any[]>([]);
  return (
    <div style={{ padding: '4px 14px 14px', background: 'var(--surface-2)' }} className="stack">
      {!!candidates.length && (
        <div className="hint-chips">
          {candidates.map((c) => <button key={c.productId} className="chip" onClick={() => get(`/api/products/${c.productId}`).then((r) => onPick(r.product))}>{c.name}</button>)}
        </div>
      )}
      <div className="search">
        <Search />
        <input className="input" autoFocus value={q} placeholder="Search products" onChange={(e) => {
          setQ(e.target.value);
          if (e.target.value.trim().length > 1) get(`/api/products?q=${encodeURIComponent(e.target.value)}`).then(setRes);
        }} />
      </div>
      {res.slice(0, 6).map((p) => (
        <button key={p.id} className="item" style={{ borderRadius: 12 }} onClick={() => onPick(p)}><Thumb product={p} /><span className="title">{p.name}</span></button>
      ))}
      <button className="btn sm" onClick={() => onNew(q.trim() || initial)}>+ {q.trim() || initial}</button>
    </div>
  );
}
