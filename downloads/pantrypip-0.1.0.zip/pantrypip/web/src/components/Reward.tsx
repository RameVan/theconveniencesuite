import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { Star, X } from 'lucide-react';
import { post, invalidate } from '../api';
import { useApp } from '../app-context';
import { markToasted } from './JourneyToast';
import { AfterCooking } from './AfterCooking';

interface Reward {
  xp: number;
  parts: { key: string; label: string; label_nl: string; xp: number }[];
  score: number;
  streak: number;
  levelUp: boolean;
  level: { n: number; name: string; name_nl: string; emoji: string; progress: number; to: number | null };
  totalXp: number;
}
interface Shown { reward: Reward; recipe?: { id: string; title: string } | null }

const Ctx = createContext<(r: Reward | null | undefined, recipe?: { id: string; title: string } | null) => void>(() => {});
/** Show what cooking earned: XP, streak, level, and a one-tap "how was it?" rating. */
export const useReward = () => useContext(Ctx);

export function RewardProvider({ children }: { children: ReactNode }) {
  const [shown, setShown] = useState<Shown | null>(null);
  const show = useCallback((reward: Reward | null | undefined, recipe?: { id: string; title: string } | null) => {
    // Minimalist mode skips the celebration; the XP still counts.
    if (reward && document.documentElement.dataset.minimal !== 'on') setShown({ reward, recipe });
    if ((reward as any)?.journey?.length) markToasted((reward as any).journey.map((n: any) => n.id));
    invalidate(['game']);
  }, []);
  return (
    <Ctx.Provider value={show}>
      {children}
      {shown && <RewardPop {...shown} onClose={() => setShown(null)} />}
    </Ctx.Provider>
  );
}

function RewardPop({ reward, recipe, onClose }: Shown & { onClose: () => void }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const [rated, setRated] = useState<number | null>(null);
  const touched = useRef(false);
  // Stays until you close it (or tap outside): an achievement is yours to look at.
  const rate = async (n: number) => {
    touched.current = true;
    setRated(n);
    if (recipe) await post(`/api/recipes/${recipe.id}/interaction`, { rating: n });
    invalidate(['recipes']);
  };
  const l = reward.level;
  return (
    <div className="reward-wrap" onClick={onClose}>
      <div className="reward-pop" role="dialog" aria-label={nl ? 'Beloning' : 'Reward'} onClick={(e) => { e.stopPropagation(); touched.current = true; }}>
        <button className="icon-btn ghost reward-close" onClick={onClose} aria-label={nl ? 'Sluiten' : 'Close'}><X size={18} /></button>
        {reward.levelUp ? (
          <div className="reward-level-up">
            <div className="big-emoji">{l.emoji}</div>
            <b>{nl ? 'Nieuw level!' : 'Level up!'}</b>
            <div>{nl ? `Level ${l.n}: ${l.name_nl}` : `Level ${l.n}: ${l.name}`}</div>
          </div>
        ) : (
          <div className="reward-xp">+{reward.xp} XP</div>
        )}
        <div className="reward-parts">
          {reward.parts.map((p) => <span key={p.key} className="chip">{nl ? p.label_nl : p.label} <b>+{p.xp}</b></span>)}
        </div>
        <div className="row" style={{ justifyContent: 'center', gap: 14 }}>
          <span className="reward-streak">🔥 {reward.streak} {nl ? (reward.streak === 1 ? 'dag' : 'dagen') : reward.streak === 1 ? 'day' : 'days'}</span>
          {reward.score > 0 && <span className="pill herb">⚖️ {reward.score}/100</span>}
        </div>
        {reward.parts.some((p) => p.key.startsWith('journey:')) && <a className="small link" href="#/progress" onClick={onClose}>🧭 {nl ? 'Je bent verder op je reis →' : 'You moved forward on your journey →'}</a>}
        <div className="xp-bar" aria-label={`${Math.round(l.progress * 100)}%`}><i style={{ width: `${Math.round(l.progress * 100)}%` }} /></div>
        <div className="tiny muted">{l.emoji} {nl ? l.name_nl : l.name}{l.to ? ` · ${l.to - reward.totalXp} XP ${nl ? 'tot het volgende level' : 'to next level'}` : ''}</div>
        {recipe && (
          <div className="stack" style={{ gap: 4, alignItems: 'center', marginTop: 6 }}>
            <div className="small">{nl ? `Hoe was ${recipe.title}?` : `How was ${recipe.title}?`}</div>
            <div className="row" style={{ gap: 2 }}>
              {[1, 2, 3, 4, 5].map((s) => (
                <button key={s} className="icon-btn ghost" aria-label={`${s} ${nl ? 'sterren' : 'stars'}`} onClick={() => rate(s)}>
                  <Star size={26} fill={(rated ?? 0) >= s ? 'var(--saffron)' : 'none'} color={(rated ?? 0) >= s ? 'var(--saffron)' : 'var(--ink-3)'} />
                </button>
              ))}
            </div>
            {rated != null && <AfterCooking recipeId={recipe.id} ease={null} again={null} compact />}
          </div>
        )}
      </div>
    </div>
  );
}
