import { ExternalLink } from 'lucide-react';

export interface Shop { id: string; name: string; search: string }

/** Links that open each supermarket's own webshop search for a term. PantryPip never fetches these sites. */
export function ShopLinks({ shops, term, nl }: { shops?: Shop[]; term: string; nl: boolean }) {
  if (!shops?.length || !term.trim()) return null;
  return (
    <div className="chips shop-links" aria-label={nl ? `Zoek ${term} in een webshop` : `Search ${term} in a webshop`}>
      {shops.map((s) => (
        <a key={s.id} className="chip" href={s.search.replace('{q}', encodeURIComponent(term.trim()))} target="_blank" rel="noopener noreferrer">
          {s.name} <ExternalLink size={12} />
        </a>
      ))}
    </div>
  );
}
