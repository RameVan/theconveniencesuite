// "Reset all progress" (anyone) and the owner's test mode: a sandbox of your own data, with unlock-everything,
// time travel and test accounts. Leaving test mode puts every bit of your data back as it was.
import { useState } from 'react';
import { FlaskConical, RotateCcw, Unlock, UserPlus, Undo2 } from 'lucide-react';
import { post } from '../api';
import { useApp } from '../app-context';
import { useToast } from './ui';

const reload = () => location.reload();

export function ResetProgress() {
  const app = useApp();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const [open, setOpen] = useState(false);
  const [word, setWord] = useState('');
  const [busy, setBusy] = useState(false);
  const go = async () => {
    setBusy(true);
    try {
      await post('/api/progress/reset', { confirm: 'RESET' });
      toast({ text: nl ? 'Je voortgang begint opnieuw' : 'Your progress starts over' });
      setTimeout(reload, 600);
    } catch (e: any) {
      toast({ text: e.message });
      setBusy(false);
    }
  };
  return (
    <section className="set-group">
      <h2 className="set-title">{nl ? 'Voortgang' : 'Progress'}</h2>
      <div className="set-card">
        <div className="set-row stacked">
          <span className="set-label">
            <span>{nl ? 'Alle voortgang wissen' : 'Reset all progress'}</span>
            <span className="set-hint">{nl ? 'XP, levels, hoofdstukken, beloningen, reeksen en competities beginnen opnieuw, voor het hele huishouden. Je voorraad, recepten, planning en kookgeschiedenis blijven.' : 'XP, levels, chapters, rewards, streaks and leagues start over, for the whole household. Your stock, recipes, plans and cooking history stay.'}</span>
          </span>
          {!open ? (
            <button className="btn sm tomato" onClick={() => setOpen(true)}><RotateCcw size={15} /> {nl ? 'Wissen…' : 'Reset…'}</button>
          ) : (
            <div className="row wrap" style={{ gap: 8, marginTop: 8 }}>
              <input className="input" style={{ maxWidth: 180 }} value={word} onChange={(e) => setWord(e.target.value)} placeholder={nl ? 'Typ RESET' : 'Type RESET'} aria-label={nl ? 'Typ RESET om te bevestigen' : 'Type RESET to confirm'} autoCapitalize="characters" autoComplete="off" />
              <button className="btn sm tomato" disabled={busy || word.trim().toUpperCase() !== 'RESET'} onClick={go}>{nl ? 'Alles wissen' : 'Reset everything'}</button>
              <button className="btn sm ghost" onClick={() => (setOpen(false), setWord(''))}>{nl ? 'Annuleren' : 'Cancel'}</button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

export function TestModeSettings() {
  const app = useApp();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const t = app.me?.test ?? { on: false };
  const [busy, setBusy] = useState(false);
  const [days, setDays] = useState<number>(t.offsetDays ?? 0);
  const [acct, setAcct] = useState({ name: '', email: '', password: '', joinMine: false });
  if (!app.me?.owner) return null;
  const run = async (path: string, body: unknown = {}, done?: string) => {
    setBusy(true);
    try {
      await post(path, body);
      if (done) toast({ text: done });
      setTimeout(reload, done ? 500 : 0);
    } catch (e: any) {
      toast({ text: e.message });
      setBusy(false);
    }
  };
  const addAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      await post('/api/test/accounts', acct);
      toast({ text: nl ? `Testaccount ${acct.email} gemaakt` : `Test account ${acct.email} created` });
      setAcct({ name: '', email: '', password: '', joinMine: false });
    } catch (err: any) {
      toast({ text: err.message });
    } finally {
      setBusy(false);
    }
  };
  return (
    <section className="set-group">
      <h2 className="set-title">{nl ? 'Testmodus (alleen jij)' : 'Test mode (only you)'}</h2>
      <div className="set-card">
        <div className="set-row stacked">
          <span className="set-label">
            <span><FlaskConical size={15} aria-hidden /> {nl ? 'Zandbak' : 'Sandbox'}</span>
            <span className="set-hint">{t.on
              ? (nl ? 'Aan. Alles wat je nu doet wordt teruggezet als je stopt.' : 'On. Everything you do now is put back when you leave.')
              : (nl ? 'Er wordt een gecontroleerde kopie van je gegevens gemaakt. Probeer alles; bij stoppen komt alles terug zoals het was.' : 'Makes a checked copy of your data first. Try anything; leaving puts it all back as it was.')}</span>
          </span>
          {t.on
            ? <button className="btn sm primary" disabled={busy} onClick={() => run('/api/test/stop', {}, nl ? 'Je echte gegevens zijn terug' : 'Your real data is back')}><Undo2 size={15} /> {nl ? 'Stoppen en terugzetten' : 'Leave and restore'}</button>
            : <button className="btn sm primary" disabled={busy} onClick={() => run('/api/test/start', {}, nl ? 'Testmodus aan' : 'Test mode on')}><FlaskConical size={15} /> {nl ? 'Testmodus starten' : 'Start test mode'}</button>}
        </div>
        {t.on && (
          <>
            <div className="set-row stacked">
              <span className="set-label"><span><Unlock size={15} aria-hidden /> {nl ? 'Alles ontgrendelen' : 'Unlock everything'}</span><span className="set-hint">{nl ? 'Alle hoofdstukken, looks, Pip-extra’s en het hoogste level.' : 'Every chapter, look, Pip extra and the top level.'}</span></span>
              <button className="btn sm" disabled={busy || t.unlocked} onClick={() => run('/api/test/unlock', {}, nl ? 'Alles ontgrendeld' : 'Everything unlocked')}>{t.unlocked ? (nl ? 'Ontgrendeld' : 'Unlocked') : nl ? 'Ontgrendelen' : 'Unlock'}</button>
            </div>
            <div className="set-row stacked">
              <span className="set-label"><span>{nl ? 'Tijdreizen' : 'Time travel'}</span><span className="set-hint">{nl ? `De app denkt dat het ${t.today} is. Alleen voor jouw huishouden.` : `The app thinks it's ${t.today}. Your household only.`}</span></span>
              <div className="row wrap" style={{ gap: 8, marginTop: 8 }}>
                {[-7, -1, 1, 7].map((d) => (
                  <button key={d} className="btn sm" disabled={busy} onClick={() => run('/api/test/time', { days: (t.offsetDays ?? 0) + d })}>{d > 0 ? `+${d}` : d} {nl ? 'd' : 'd'}</button>
                ))}
                <input className="input" type="number" style={{ width: 90 }} value={days} onChange={(e) => setDays(Number(e.target.value))} aria-label={nl ? 'Dagen vooruit of terug' : 'Days ahead or back'} />
                <button className="btn sm" disabled={busy} onClick={() => run('/api/test/time', { days: Math.round(days) || 0 })}>{nl ? 'Instellen' : 'Set'}</button>
                {!!t.offsetDays && <button className="btn sm ghost" disabled={busy} onClick={() => run('/api/test/time', { days: 0 })}>{nl ? 'Vandaag' : 'Today'}</button>}
              </div>
            </div>
          </>
        )}
        <form className="set-row stacked" onSubmit={addAccount}>
          <span className="set-label"><span><UserPlus size={15} aria-hidden /> {nl ? 'Testaccount maken' : 'Create a test account'}</span><span className="set-hint">{nl ? 'Zonder e-mailbevestiging. Een echt account; gebruik een adres dat je herkent, zoals naam+test@…' : 'No email confirmation. It is a real account; use an address you recognise, like name+test@…'}</span></span>
          <div className="row wrap" style={{ gap: 8, marginTop: 8 }}>
            <input className="input" required placeholder={nl ? 'Naam' : 'Name'} value={acct.name} onChange={(e) => setAcct({ ...acct, name: e.target.value })} autoComplete="off" />
            <input className="input" required type="email" placeholder="Email" value={acct.email} onChange={(e) => setAcct({ ...acct, email: e.target.value })} autoComplete="off" />
            <input className="input" required type="password" minLength={10} placeholder={nl ? 'Wachtwoord (10+ tekens)' : 'Password (10+ characters)'} value={acct.password} onChange={(e) => setAcct({ ...acct, password: e.target.value })} autoComplete="new-password" />
            <label className="row" style={{ gap: 6 }}><input type="checkbox" checked={acct.joinMine} onChange={(e) => setAcct({ ...acct, joinMine: e.target.checked })} /> {nl ? 'In mijn huishouden' : 'Join my household'}</label>
            <button className="btn sm" disabled={busy}>{nl ? 'Maken' : 'Create'}</button>
          </div>
        </form>
      </div>
    </section>
  );
}

/** A strip across the top while test mode is on, so it's never forgotten. */
export function TestModeBanner() {
  const app = useApp();
  const nl = app.lang === 'nl';
  const t = app.me?.test;
  if (!t?.on) return null;
  return (
    <a className="test-banner" href="#/settings/account">
      <FlaskConical size={14} aria-hidden /> {nl ? 'Testmodus' : 'Test mode'}{t.offsetDays ? ` · ${t.today}` : ''} · {nl ? 'wordt teruggezet' : 'will be undone'}
    </a>
  );
}
