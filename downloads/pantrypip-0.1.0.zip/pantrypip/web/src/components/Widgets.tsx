// Dashboard widgets: each renders live data from /api/dashboard/data in a compact or expanded view,
// with the most useful action right inside (tick off, cook, eat leftovers, plan the week).
import { useState, type ReactNode } from 'react';
import { Check, Plus, X, Utensils, ReceiptText, ScanBarcode, Minus, ShoppingBasket, Sparkles, ChefHat, Lock } from 'lucide-react';
import { post, patch, requestId, invalidate } from '../api';
import { useApp, SCOPES_ALL } from '../app-context';
import { fmtQty, relDays, timeAgo, type Lang } from '../i18n';
import { useToast, emojiFor } from './ui';
import { useReward } from './Reward';
import { Pip } from './Pip';
import { speechSupported } from './Assistant';

export const WIDGET_LINK: Record<string, string> = {
  shopping: '#/shopping', listSuggestions: '#/shopping', missing: '#/shopping', inventory: '#/inventory', expiring: '#/inventory', low: '#/inventory', recent: '#/inventory', leftovers: '#/inventory', fifo: '#/inventory',
  favourites: '#/discover', recipeOfDay: '#/discover', recentlyCooked: '#/progress', toTry: '#/discover', quickMeals: '#/discover', highProtein: '#/discover', fromStock: '#/discover',
  weekPlan: '#/plan', tonight: '#/plan', planProgress: '#/plan', autoPlan: '#/plan?auto=1', dailyNutrition: '#/progress', protein: '#/progress', weeklyNutrition: '#/progress', nutritionScore: '#/progress', nutritionStreak: '#/progress',
  cookingStreak: '#/progress', xp: '#/progress', challenge: '#/progress', journey: '#/progress', achievements: '#/progress', wasteStats: '#/insights', moneySaved: '#/insights', cookingStats: '#/insights', spending: '#/insights', topIngredients: '#/insights', activity: '#/inventory',
};

const name = (x: any, lang: Lang) => (lang === 'nl' && x.name_nl ? x.name_nl : x.name);
const DAY = { en: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], nl: ['zo', 'ma', 'di', 'wo', 'do', 'vr', 'za'] };

function Meter({ value, max, label, unit = '' }: { value: number; max: number; label: string; unit?: string }) {
  const pct = max ? Math.min(100, (value / max) * 100) : 0;
  return (
    <div className="meter">
      <div className="row" style={{ justifyContent: 'space-between' }}><span className="tiny muted">{label}</span><span className="tiny num"><b>{value}</b>{unit} / {max}{unit}</span></div>
      <div className="xp-bar thin"><i style={{ width: `${pct}%` }} /></div>
    </div>
  );
}

function Big({ v, sub, tone }: { v: ReactNode; sub: ReactNode; tone?: string }) {
  return <div className="w-big"><b className={`num ${tone ?? ''}`}>{v}</b><span className="tiny muted">{sub}</span></div>;
}

function Recipes({ items, empty, onOpen }: { items: any[]; empty: string; onOpen?: (r: any) => void }) {
  if (!items?.length) return <p className="tiny muted w-empty">{empty}</p>;
  return (
    <div className="w-recipes">
      {items.map((r) => (
        <a key={r.id} className="w-recipe" href={`#/recipe/${r.id}`} onClick={() => onOpen?.(r)}>
          <span className="w-plate" style={{ background: r.color ?? 'var(--bg-2)' }}>{r.image_url ? <img src={r.image_url} alt="" loading="lazy" /> : r.emoji ?? '🍽️'}</span>
          <b className="small ellipsis2">{r.title}</b>
          <span className="tiny muted">{r.minutes} min{r.matchPct != null ? ` · ${Math.round(r.matchPct)}%` : ''}{r.rating ? ` · ${'★'.repeat(r.rating)}` : ''}</span>
        </a>
      ))}
    </div>
  );
}

function Rows({ children }: { children: ReactNode }) {
  return <div className="w-rows">{children}</div>;
}

/** One-line summaries for compact widgets. */
export function compactLine(type: string, d: any, lang: Lang): string {
  const nl = lang === 'nl';
  if (!d) return '…';
  switch (type) {
    case 'shopping': return d.count ? `${d.count} ${nl ? 'te kopen' : 'to buy'}` : nl ? 'Lijst is leeg' : 'List is empty';
    case 'inventory': return `${d.total} ${nl ? 'producten' : 'products'}`;
    case 'expiring': return d.items.length ? `${d.items.length} ${nl ? 'snel op' : 'to use soon'}: ${d.items.slice(0, 2).map((i: any) => name(i, lang)).join(', ')}` : nl ? 'Niets dringends' : 'Nothing urgent';
    case 'low': return d.items.length ? `${d.items.length} ${nl ? 'bijna op' : 'running low'}` : nl ? 'Alles op peil' : 'All stocked';
    case 'recent': return d.items[0] ? `${nl ? 'Laatst' : 'Last'}: ${name(d.items[0], lang)}` : '–';
    case 'leftovers': return d.items.length ? `${d.items.length} ${nl ? 'restje(s)' : 'leftover(s)'}` : nl ? 'Geen restjes' : 'No leftovers';
    case 'listSuggestions': return `${d.items.length} ${nl ? 'voorstellen' : 'suggestions'}`;
    case 'fifo': return d.items[0] ? `${nl ? 'Eerst' : 'First'}: ${name(d.items[0], lang)}` : nl ? 'Niets dringends' : 'Nothing urgent';
    case 'tonight': return d.slot?.title ?? (nl ? 'Nog niets gepland' : 'Nothing planned');
    case 'weekPlan': return `${d.days.filter((x: any) => x.title).length}/7 ${nl ? 'gepland' : 'planned'}`;
    case 'missing': return d.count ? `${d.count} ${nl ? 'nodig' : 'needed'}` : nl ? 'Alles in huis' : 'Got everything';
    case 'planProgress': return `${d.cooked}/${d.planned} ${nl ? 'gekookt' : 'cooked'}`;
    case 'autoPlan': return `${7 - d.plannedNext7} ${nl ? 'avonden open' : 'evenings open'}`;
    case 'dailyNutrition': return `${d.totals.kcal} kcal · ${d.totals.protein} g ${nl ? 'eiwit' : 'protein'}`;
    case 'protein': return `${d.today} / ${d.target} g`;
    case 'weeklyNutrition': return d.average != null ? `${nl ? 'Gemiddeld' : 'Average'} ${d.average}` : '–';
    case 'nutritionScore': return d.today != null ? `${d.today}/100` : '–';
    case 'nutritionStreak': return `${d.current} ${nl ? 'dagen' : 'days'}`;
    case 'cookingStreak': return `🔥 ${d.current} ${nl ? 'dagen' : 'days'}`;
    case 'xp': return `${d.xp} XP · ${nl ? d.level.name_nl : d.level.name}`;
    case 'challenge': return d.current ? `${d.current.progress}/${d.current.goal}` : nl ? 'Geen actieve uitdaging' : 'No active challenge';
    case 'journey': return d.next ? (nl ? d.next.title_nl : d.next.title) : '👑';
    case 'achievements': return d.items[0] ? (nl ? d.items[0].title_nl : d.items[0].title) : '–';
    case 'wasteStats': return d.usedPct != null ? `${d.usedPct}% ${nl ? 'gebruikt' : 'used'}` : '–';
    case 'moneySaved': return `€${d.total.toFixed(2)}`;
    case 'cookingStats': return `${d.total} ${nl ? 'maaltijden' : 'meals'} · ${d.distinct} ${nl ? 'recepten' : 'recipes'}`;
    case 'spending': return `€${d.thisWeek.toFixed(2)} ${nl ? 'deze week' : 'this week'}`;
    case 'topIngredients': return d.items[0] ? name(d.items[0], lang) : '–';
    case 'activity': return d.items[0] ? `${d.items[0].product_name ?? d.items[0].lot_label ?? ''}` : '–';
    case 'recipeOfDay': return d.recipe?.title ?? '–';
    default: return d.items ? `${d.items.length}` : '';
  }
}

export function WidgetBody({ type, d, compact, size }: { type: string; d: any; compact: boolean; size: 's' | 'm' | 'l' }) {
  const app = useApp();
  const toast = useToast();
  const reward = useReward();
  const nl = app.lang === 'nl';
  const lang = app.lang;
  const [text, setText] = useState('');
  if (!d) return <div className="skeleton" style={{ height: size === 's' ? 40 : 90 }} />;
  if (d.error) return <p className="tiny muted">{d.error}</p>;
  if (compact) return <p className="w-compact small ellipsis">{compactLine(type, d, lang)}</p>;
  const act = async (fn: () => Promise<any>, msg: string, recipe?: any) => {
    try {
      const r = await fn();
      invalidate([...SCOPES_ALL, 'game']);
      if (r?.reward) reward(r.reward, recipe);
      toast({ text: msg, undo: r?.batchId ? () => post('/api/inventory/undo', { batchId: r.batchId }).then(() => invalidate([...SCOPES_ALL, 'game'])) : undefined });
    } catch (e: any) {
      toast({ text: e.message, error: true });
    }
  };
  const few = size === 's' ? 3 : size === 'm' ? 5 : 8;
  const stockRow = (i: any, right?: ReactNode) => (
    <div key={i.id} className="w-row">
      <span className="w-ic">{i.emoji ?? emojiFor({ id: i.id, category: i.category })}</span>
      <span className="grow ellipsis small">{name(i, lang)}</span>
      {right ?? <span className="tiny muted">{i.daysToExpiry != null ? relDays(i.daysToExpiry, lang) : fmtQty(i.qty, i.unit, lang)}</span>}
    </div>
  );

  switch (type) {
    case 'quickAdd':
      return (
        <div className="w-quick">
          <button onClick={app.openReceipt}><span className="ic" style={{ background: 'var(--saffron-soft)', color: 'var(--saffron)' }}><ReceiptText /></span>{nl ? 'Bon' : 'Receipt'}</button>
          <button onClick={() => app.openBoughtList({ listen: speechSupported })}><span className="ic" style={{ background: 'var(--herb-soft)', color: 'var(--herb)' }}><ShoppingBasket /></span>{nl ? 'Gekocht' : 'Bought'}</button>
          <button onClick={app.openBarcode}><span className="ic" style={{ background: 'var(--plum-soft)', color: 'var(--plum)' }}><ScanBarcode /></span>Barcode</button>
          <button onClick={() => app.openQuick({ mode: 'use' })}><span className="ic" style={{ background: 'var(--tomato-soft)', color: 'var(--tomato)' }}><Minus /></span>{nl ? 'Gebruik' : 'Use'}</button>
          <button onClick={() => app.openQuick({ mode: 'add' })}><span className="ic" style={{ background: 'var(--herb-soft)', color: 'var(--herb)' }}><Plus /></span>{nl ? 'Toevoegen' : 'Add'}</button>
          {(d.quick ?? []).map((q: any) => (
            <button key={q.label} className="chip" onClick={() => act(() => post('/api/inventory/consume', { productId: q.productId, quantity: q.quantity, clientRequestId: requestId() }), `−${q.label}`)}><Minus size={14} /> {q.label}</button>
          ))}
        </div>
      );
    case 'shopping':
      return (
        <>
          <form className="w-add" onSubmit={(e) => { e.preventDefault(); if (!text.trim()) return; const n = text.trim(); setText(''); act(() => post('/api/shopping', { name: n }), `${n} → ${nl ? 'lijst' : 'list'}`); }}>
            <input className="input" value={text} onChange={(e) => setText(e.target.value)} placeholder={nl ? 'Iets toevoegen…' : 'Add something…'} aria-label={nl ? 'Toevoegen aan lijst' : 'Add to list'} />
            <button className="icon-btn" aria-label={nl ? 'Toevoegen' : 'Add'}><Plus size={18} /></button>
          </form>
          {d.items.length ? (
            <Rows>
              {d.items.slice(0, few + 2).map((i: any) => (
                <button key={i.id} className="w-row w-tick" onClick={() => act(() => patch(`/api/shopping/${i.id}`, { checked: true }), `✓ ${i.name}`)} aria-label={`${nl ? 'Afvinken' : 'Tick off'} ${i.name}`}>
                  <span className="tickbox" />
                  <span className="grow ellipsis small" style={{ textAlign: 'left' }}>{i.name}</span>
                  {i.detail && <span className="tiny muted">{i.detail}</span>}
                </button>
              ))}
            </Rows>
          ) : <p className="tiny muted w-empty">{nl ? 'Je lijst is leeg.' : 'Your list is empty.'}</p>}
          {d.count > few + 2 && <a className="tiny link" href="#/shopping">+{d.count - few - 2} {nl ? 'meer' : 'more'}</a>}
        </>
      );
    case 'inventory':
      return (
        <>
          <Big v={d.total} sub={nl ? 'producten in huis' : 'products in stock'} />
          <div className="w-cats">{d.categories.slice(0, size === 'l' ? 10 : 6).map((c: any) => <span key={c.category} className="pill">{emojiFor({ category: c.category })} {c.n}</span>)}</div>
        </>
      );
    case 'expiring':
      return d.items.length ? <Rows>{d.items.slice(0, few).map((i: any) => stockRow(i, <span className={`tiny ${i.daysToExpiry <= 0 ? 'bad' : 'warn'}`}>{relDays(i.daysToExpiry, lang)}</span>))}</Rows> : <p className="tiny muted w-empty">{nl ? 'Niets dat snel op moet. 🌿' : 'Nothing to rush. 🌿'}</p>;
    case 'low':
      return d.items.length ? <Rows>{d.items.slice(0, few).map((i: any) => stockRow(i, <button className="btn soft sm" onClick={() => act(() => post('/api/shopping', { productId: i.id }), `${name(i, lang)} → ${nl ? 'lijst' : 'list'}`)}><Plus size={13} /></button>))}</Rows> : <p className="tiny muted w-empty">{nl ? 'Alles op peil.' : 'All stocked up.'}</p>;
    case 'recent':
      return d.items.length ? <Rows>{d.items.slice(0, few).map((i: any) => stockRow(i, <span className="tiny muted">{timeAgo(i.at, lang)}</span>))}</Rows> : <p className="tiny muted w-empty">{nl ? 'Nog niets toegevoegd.' : 'Nothing added yet.'}</p>;
    case 'leftovers':
      return d.items.length ? (
        <Rows>
          {d.items.slice(0, few).map((l: any) => (
            <div key={l.id} className="w-row">
              <span className="w-ic">{l.freezer ? '🧊' : '🥡'}</span>
              <span className="grow ellipsis small">{l.title}<span className="tiny muted"> · {fmtQty(l.quantity, 'portion', lang)}{l.daysToExpiry != null && !l.freezer ? ` · ${relDays(l.daysToExpiry, lang)}` : ''}</span></span>
              <button className="btn sm" onClick={() => act(() => post(`/api/leftovers/${l.id}`, { action: 'eat', portions: 1, clientRequestId: requestId() }), nl ? 'Smakelijk!' : 'Enjoy!')}><Utensils size={13} /> 1</button>
            </div>
          ))}
        </Rows>
      ) : <p className="tiny muted w-empty">{nl ? 'Geen restjes.' : 'No leftovers.'}</p>;
    case 'listSuggestions':
      return d.items.length ? (
        <Rows>
          {d.items.slice(0, few).map((s: any) => (
            <div key={s.productId} className="w-row">
              <span className="grow ellipsis small">{s.name}<span className="tiny muted"> · {s.detail}</span></span>
              <button className="icon-btn ghost" aria-label={nl ? 'Niet nu' : 'Not now'} onClick={() => act(() => post(`/api/shopping/suggestions/${s.productId}/reject`, {}), nl ? 'Oké, niet nu' : 'OK, not now')}><X size={15} /></button>
              <button className="btn soft sm" onClick={() => act(() => post(`/api/shopping/suggestions/${s.productId}/accept`, { packages: s.packages }), `${s.name} → ${nl ? 'lijst' : 'list'}`)}><Plus size={13} /></button>
            </div>
          ))}
        </Rows>
      ) : <p className="tiny muted w-empty">{nl ? 'Geen voorstellen.' : 'No suggestions.'}</p>;
    case 'fifo':
      return d.items.length ? (
        <Rows>
          {d.items.slice(0, few).map((i: any) => (
            <div key={i.id} className="w-row">
              <span className="w-ic">{i.emoji ?? emojiFor({ id: i.id, category: i.category })}</span>
              <span className="grow ellipsis small">{name(i, lang)}{i.daysToExpiry != null && <span className="tiny muted"> · {relDays(i.daysToExpiry, lang)}</span>}</span>
              {i.recipe && <a className="tiny link ellipsis" style={{ maxWidth: '45%' }} href={`#/recipe/${i.recipe.id}`}>{i.recipe.emoji} {i.recipe.title}</a>}
            </div>
          ))}
        </Rows>
      ) : <p className="tiny muted w-empty">{nl ? 'Niets dat dringend op moet.' : 'Nothing urgent to use up.'}</p>;
    case 'favourites':
      return <Recipes items={d.items.slice(0, few)} empty={nl ? 'Geef recepten 4★ of meer en ze verschijnen hier.' : 'Rate recipes 4★ or more and they show up here.'} onOpen={() => post('/api/dashboard/usage', { key: 'recipe:favourite' }).catch(() => {})} />;
    case 'recipeOfDay': {
      const r = d.recipe;
      if (!r) return <p className="tiny muted w-empty">–</p>;
      return (
        <a className="w-rotd" href={`#/recipe/${r.id}`}>
          <span className="w-plate big" style={{ background: r.color ?? 'var(--bg-2)' }}>{r.image_url ? <img src={r.image_url} alt="" loading="lazy" /> : r.emoji}</span>
          <span className="grow" style={{ minWidth: 0 }}>
            <b className="ellipsis2">{r.title}</b>
            <span className="tiny muted" style={{ display: 'block' }}>{r.minutes} min · {Math.round(r.matchPct * 100)}% {nl ? 'in huis' : 'in stock'}</span>
            {r.reasons?.[0] && <span className="tiny" style={{ display: 'block' }}>{r.reasons[0]}</span>}
          </span>
        </a>
      );
    }
    case 'recentlyCooked':
      return d.items.length ? <Rows>{d.items.slice(0, few).map((c: any, i: number) => <a key={i} className="w-row" href={`#/recipe/${c.id}`}><span className="w-ic">{c.emoji}</span><span className="grow ellipsis small">{c.title}</span><span className="tiny muted">{c.date.slice(5)}</span></a>)}</Rows> : <p className="tiny muted w-empty">{nl ? 'Nog niets gekookt.' : 'Nothing cooked yet.'}</p>;
    case 'toTry':
      return <Recipes items={d.items.slice(0, few)} empty={nl ? 'Tik op het bladwijzer-icoon bij een recept om het hier te bewaren.' : 'Tap the bookmark on a recipe to keep it here.'} />;
    case 'quickMeals':
    case 'highProtein':
    case 'fromStock':
      return <Recipes items={d.items.slice(0, few)} empty={type === 'fromStock' ? (nl ? 'Voeg wat boodschappen toe voor ideeën.' : 'Add some groceries for ideas.') : '–'} />;
    case 'weekPlan':
      return (
        <div className="w-week">
          {d.days.map((x: any) => {
            const dow = new Date(x.date + 'T12:00:00Z').getUTCDay();
            return (
              <a key={x.date} className={`w-day ${x.status ?? 'empty'}`} href={x.recipeId ? `#/recipe/${x.recipeId}?servings=${x.servings}` : '#/plan'}>
                <span className="tiny muted">{DAY[lang][dow]}</span>
                <span className="w-day-e">{x.status === 'cooked' ? '✅' : x.emoji ?? '·'}</span>
                {size !== 's' && <span className="tiny ellipsis2">{x.title ?? ''}</span>}
              </a>
            );
          })}
        </div>
      );
    case 'tonight': {
      const s = d.slot;
      if (!s) return (
        <div className="w-tonight">
          <p className="small muted" style={{ margin: 0 }}>{nl ? 'Nog niets gepland voor vanavond.' : 'Nothing planned for tonight.'}</p>
          <a className="btn soft sm" href="#/plan?auto=1"><Sparkles size={14} /> {nl ? 'Plan mijn week' : 'Plan my week'}</a>
        </div>
      );
      return (
        <div className="w-tonight">
          <a className="row" style={{ gap: 10, textDecoration: 'none', color: 'inherit', minWidth: 0 }} href={s.recipeId ? `#/recipe/${s.recipeId}?servings=${s.servings}` : '#/plan'}>
            <span className="w-plate" style={{ background: s.color ?? 'var(--bg-2)' }}>{s.emoji ?? '🍽️'}</span>
            <span style={{ minWidth: 0 }}><b className="ellipsis2">{s.title}</b><span className="tiny muted" style={{ display: 'block' }}>{s.servings} {nl ? 'porties' : 'servings'}{s.minutes ? ` · ${s.minutes} min` : ''}</span></span>
          </a>
          {s.status === 'planned' && s.recipeId ? (
            <div className="row" style={{ gap: 6 }}>
              <a className="btn soft sm" href={`#/cook/${s.recipeId}?servings=${s.servings}`}><ChefHat size={14} /> {nl ? 'Koken' : 'Cook'}</a>
              <button className="btn primary sm" onClick={() => act(() => post(`/api/plan/${s.id}/cook`, {}), nl ? `${s.title} gekookt` : `Cooked ${s.title}`, { id: s.recipeId, title: s.title })}><Check size={14} /> {nl ? 'Gekookt' : 'Cooked it'}</button>
            </div>
          ) : <span className="pill herb">{s.status === 'cooked' ? (nl ? 'Gekookt ✓' : 'Cooked ✓') : s.status}</span>}
        </div>
      );
    }
    case 'missing':
      return d.items.length ? <Rows>{d.items.slice(0, few).map((i: any) => <div key={i.id} className="w-row"><span className="w-ic">🧩</span><span className="grow ellipsis small">{i.name}</span>{i.packages ? <span className="tiny muted">×{i.packages}</span> : null}</div>)}</Rows> : <p className="tiny muted w-empty">{nl ? 'Je hebt alles voor de komende maaltijden.' : 'You have everything for upcoming meals.'}</p>;
    case 'planProgress':
      return (
        <>
          <Big v={`${d.cooked}/${d.planned}`} sub={nl ? 'geplande maaltijden gekookt (deze week)' : 'planned dinners cooked (this week)'} />
          <div className="xp-bar"><i style={{ width: `${d.planned ? (d.cooked / d.planned) * 100 : 0}%` }} /></div>
        </>
      );
    case 'autoPlan':
      return (
        <a className="w-autoplan" href="#/plan?auto=1">
          <Sparkles size={22} />
          <span className="grow"><b className="small">{d.plannedNext7 >= 7 ? (nl ? 'Je week staat' : 'Your week is planned') : nl ? 'Plan mijn week' : 'Plan my week'}</b><span className="tiny muted" style={{ display: 'block' }}>{d.plannedNext7 >= 7 ? (nl ? 'Tik om aan te passen' : 'Tap to adjust') : nl ? `${7 - d.plannedNext7} avonden open` : `${7 - d.plannedNext7} evenings open`}</span></span>
        </a>
      );
    case 'dailyNutrition':
      return (
        <>
          <Meter value={d.totals.kcal} max={d.targets.kcal} label={nl ? 'Energie' : 'Energy'} unit=" kcal" />
          <Meter value={d.totals.protein} max={d.targets.protein} label={nl ? 'Eiwit' : 'Protein'} unit=" g" />
          {size !== 's' && <Meter value={d.totals.carbs} max={d.targets.carbs} label={nl ? 'Koolhydraten' : 'Carbs'} unit=" g" />}
          {size !== 's' && <Meter value={d.totals.fat} max={d.targets.fat} label={nl ? 'Vet' : 'Fat'} unit=" g" />}
          <p className="tiny muted" style={{ margin: '4px 0 0' }}>{d.logged ? (nl ? `Uit ${d.logged} maaltijd(en) die je vandaag kookte. Ontbijt en lunch staan er niet in.` : `From ${d.logged} meal(s) you cooked today. Breakfast and lunch aren’t included.`) : nl ? 'Kook iets en het telt hier mee.' : 'Cook something and it shows up here.'}</p>
        </>
      );
    case 'protein':
      return (
        <>
          <Big v={`${d.today} g`} sub={nl ? `van ≈${d.target} g per dag` : `of ≈${d.target} g a day`} />
          <div className="xp-bar"><i style={{ width: `${Math.min(100, (d.today / d.target) * 100)}%` }} /></div>
          <span className="tiny muted">{nl ? `Avondeten: ≈${d.dinnerTarget} g is je deel` : `Dinner share: ≈${d.dinnerTarget} g`}</span>
        </>
      );
    case 'weeklyNutrition':
      return (
        <div className="w-bars">
          {d.days.map((x: any) => (
            <div key={x.date} className="w-bar" title={`${x.date}: ${x.score ?? '–'}`}>
              <i style={{ height: `${x.score ?? 0}%` }} className={x.score >= 70 ? 'good' : ''} />
              <span className="tiny muted">{DAY[lang][new Date(x.date + 'T12:00:00Z').getUTCDay()].slice(0, 2)}</span>
            </div>
          ))}
        </div>
      );
    case 'nutritionScore':
      return <Big v={d.today ?? '–'} sub={d.weekAverage != null ? (nl ? `week gemiddeld ${d.weekAverage} · 70+ is top` : `week avg ${d.weekAverage} · 70+ is great`) : nl ? 'nog niets gekookt' : 'nothing cooked yet'} tone={d.today >= 70 ? 'good' : ''} />;
    case 'nutritionStreak':
      return <Big v={`🥗 ${d.current}`} sub={nl ? 'gebalanceerde kookdagen op rij' : 'balanced cooking days in a row'} />;
    case 'cookingStreak':
      return <Big v={`🔥 ${d.current}`} sub={d.cookedToday ? (nl ? 'vandaag gekookt' : 'cooked today') : d.current ? (nl ? 'kook vandaag om door te gaan' : 'cook today to keep it going') : nl ? 'begin vandaag' : 'start today'} />;
    case 'xp':
      return (
        <>
          <Big v={d.xp} sub={`XP · ${d.level.emoji} ${nl ? d.level.name_nl : d.level.name}`} />
          <div className="xp-bar"><i style={{ width: `${Math.round(d.level.progress * 100)}%` }} /></div>
          {d.level.to && <span className="tiny muted">{d.level.to - d.xp} XP {nl ? 'tot volgend niveau' : 'to next level'}</span>}
        </>
      );
    case 'challenge': {
      const c = d.current;
      const def = c ? d.all.find((x: any) => x.id === c.id) : null;
      if (c && def) return (
        <>
          <div className="small"><b>{def.emoji} {nl ? def.title_nl : def.title}</b></div>
          <div className="xp-bar"><i style={{ width: `${(c.progress / c.goal) * 100}%` }} /></div>
          <span className="tiny muted">{c.progress}/{c.goal} · {nl ? 'tot' : 'until'} {c.end}</span>
        </>
      );
      const s = d.suggestion;
      return s ? (
        <div className="w-row">
          <span className="w-ic">{s.emoji}</span>
          <span className="grow small">{nl ? s.title_nl : s.title}<span className="tiny muted" style={{ display: 'block' }}>{nl ? s.reason_nl : s.reason}</span></span>
          <button className="btn soft sm" onClick={() => act(() => post('/api/game/challenge', { id: s.id }), nl ? 'Uitdaging gestart!' : 'Challenge started!')}>{nl ? 'Doe mee' : 'Join'}</button>
        </div>
      ) : <p className="tiny muted w-empty">–</p>;
    }
    case 'journey':
      return (
        <div className="w-journey">
          <Pip skin={d.companion.skin} stages={d.companion.stage >= 1 ? ['apron', ...(d.companion.stage >= 2 ? ['hat'] : []), ...(d.companion.stage >= 3 ? ['scarf'] : [])] : []} size={size === 's' ? 40 : 52} />
          <div className="grow" style={{ minWidth: 0 }}>
            <span className="tiny muted">{d.chapter.emoji} {nl ? `Hoofdstuk ${d.chapter.n}` : `Chapter ${d.chapter.n}`} · {d.chapter.done}/{d.chapter.total}</span>
            <b className="small ellipsis" style={{ display: 'block' }}>{d.next ? `${d.next.emoji} ${nl ? d.next.title_nl : d.next.title}` : nl ? 'Reis voltooid 👑' : 'Journey complete 👑'}</b>
            <div className="w-mini-path">{d.nodes.map((n: any) => <i key={n.id} className={`${n.state} k-${n.kind}`} />)}</div>
          </div>
        </div>
      );
    case 'achievements':
      return d.items.length ? <Rows>{d.items.slice(0, few).map((a: any) => <div key={a.id} className="w-row"><span className="w-ic">{a.emoji}</span><span className="grow ellipsis small">{nl ? a.title_nl : a.title}</span><span className="tiny" style={{ color: 'var(--herb)' }}>+{a.xp}</span></div>)}</Rows> : <p className="tiny muted w-empty">{nl ? 'Je eerste prestatie komt eraan.' : 'Your first achievement is on its way.'}</p>;
    case 'wasteStats':
      return (
        <>
          <Big v={d.usedPct != null ? `${d.usedPct}%` : '–'} sub={nl ? 'van je eten gebruikt, niet weggegooid (30 d)' : 'of food used, not thrown away (30 d)'} tone={d.usedPct >= 90 ? 'good' : ''} />
          <span className="tiny muted">🛟 {d.rescued} {nl ? 'gered' : 'rescued'} · 🗑️ {d.thrown} {nl ? 'weggegooid' : 'thrown away'} (€{d.wastedValue.toFixed(2)})</span>
        </>
      );
    case 'moneySaved':
      return <Big v={`€${d.total.toFixed(2)}`} sub={nl ? `geschat, 30 d: gered eten €${d.rescued.toFixed(2)} + restjes €${d.leftovers.toFixed(2)}` : `estimated, 30 d: rescued food €${d.rescued.toFixed(2)} + leftovers €${d.leftovers.toFixed(2)}`} />;
    case 'cookingStats':
      return (
        <div className="w-trio">
          <div><b className="num">{d.total}</b><span className="tiny muted">{nl ? 'gekookt' : 'cooked'}</span></div>
          <div><b className="num">{d.distinct}</b><span className="tiny muted">{nl ? 'recepten' : 'recipes'}</span></div>
          <div><b className="num">{d.avgMinutes ?? '–'}</b><span className="tiny muted">{nl ? 'min gem.' : 'avg min'}</span></div>
        </div>
      );
    case 'spending': {
      const max = Math.max(1, ...d.weeks.map((w: any) => w.total));
      return (
        <>
          <div className="w-bars short">{d.weeks.map((w: any) => <div key={w.week} className="w-bar" title={`${w.week}: €${w.total}`}><i style={{ height: `${(w.total / max) * 100}%` }} /></div>)}</div>
          <span className="tiny muted">€{d.thisWeek.toFixed(2)} {nl ? 'deze week' : 'this week'}{d.pricedShare != null && d.pricedShare < 100 ? ` · ${nl ? 'prijs bekend bij' : 'prices known for'} ${d.pricedShare}%` : ''}</span>
        </>
      );
    }
    case 'topIngredients':
      return d.items.length ? <Rows>{d.items.slice(0, few).map((i: any) => <div key={i.id} className="w-row"><span className="w-ic">{emojiFor({ id: i.id })}</span><span className="grow ellipsis small">{name(i, lang)}</span><span className="tiny muted">{i.n}×</span></div>)}</Rows> : <p className="tiny muted w-empty">–</p>;
    case 'activity':
      return d.items.length ? <Rows>{d.items.slice(0, few).map((e: any) => <div key={e.id} className="w-row"><span className="grow ellipsis small"><b>{(nl ? e.product_name_nl : null) ?? e.product_name ?? e.lot_label}</b> <span className="muted">{e.type}{e.delta ? ` ${e.delta > 0 ? '+' : '−'}${fmtQty(Math.abs(e.delta), e.unit, lang)}` : ''}</span></span><span className="tiny muted">{timeAgo(e.created_at, lang)}</span></div>)}</Rows> : <p className="tiny muted w-empty">–</p>;
    default:
      return <p className="tiny muted"><Lock size={12} /> {type}</p>;
  }
}

