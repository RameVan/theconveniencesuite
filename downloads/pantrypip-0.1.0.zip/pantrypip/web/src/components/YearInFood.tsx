import { useShowMoney } from '../appearance';
import { useState } from 'react';
import { useQuery } from '../api';
import { useApp } from '../app-context';
import { fmtQty, productName, type Lang } from '../i18n';
import { emojiFor } from './ui';

type Period = 'month' | 'year' | 'all';
const WEEKDAYS: Record<Lang, string[]> = {
  en: ['Sundays', 'Mondays', 'Tuesdays', 'Wednesdays', 'Thursdays', 'Fridays', 'Saturdays'],
  nl: ['zondag', 'maandag', 'dinsdag', 'woensdag', 'donderdag', 'vrijdag', 'zaterdag'],
};
const n = (x: number, lang: Lang) => x.toLocaleString(lang === 'nl' ? 'nl-NL' : 'en-GB', { maximumFractionDigits: 1 });

/** A playful comparison for the top food: glasses of milk, slices of bread, omelettes. */
function comparison(item: any, lang: Lang): string | null {
  const nl = lang === 'nl';
  if (item.unit === 'ml') return nl ? `≈ ${n(Math.round(item.quantity / 250), lang)} glazen` : `≈ ${n(Math.round(item.quantity / 250), lang)} glasses`;
  if (item.productId === 'p_bread') return nl ? `≈ ${n(Math.round(item.quantity / 35), lang)} boterhammen` : `≈ ${n(Math.round(item.quantity / 35), lang)} slices`;
  if (item.productId === 'p_eggs') return nl ? `≈ ${n(Math.round(item.quantity / 3), lang)} omeletten` : `≈ ${n(Math.round(item.quantity / 3), lang)} omelettes`;
  if (item.unit === 'g' && item.quantity >= 1000) return nl ? `zo zwaar als ${n(Math.round(item.quantity / 4000), lang)} katten` : `as heavy as ${n(Math.max(1, Math.round(item.quantity / 4000)), lang)} cat${Math.round(item.quantity / 4000) === 1 ? '' : 's'}`;
  return null;
}

export function YearInFood() {
  const app = useApp();
  const lang = app.lang;
  const nl = lang === 'nl';
  const [period, setPeriod] = useState<Period>('year');
  const { data: s } = useQuery<any>(`/api/stats/fun?period=${period}`, ['inventory', 'planner', 'receipts']);
  const title = period === 'year' ? (nl ? `Jouw ${new Date().getFullYear()} in eten` : `Your ${new Date().getFullYear()} in food`) : period === 'month' ? (nl ? 'Deze maand in eten' : 'This month in food') : nl ? 'Alles bij elkaar' : 'All time in food';
  const top = s?.mostEaten?.[0];
  const [showMoney] = useShowMoney();

  const tiles: { emoji: string; value: string; label: string; sub?: string; tone?: string }[] = s
    ? [
        { emoji: '🍳', value: n(s.cooking.meals, lang), label: nl ? 'maaltijden gekookt' : 'meals cooked', sub: nl ? `${n(s.cooking.servings, lang)} porties` : `${n(s.cooking.servings, lang)} servings`, tone: 'herb' },
        { emoji: '🔥', value: n(s.cooking.longestStreak, lang), label: nl ? 'dagen op rij gekookt' : 'day cooking streak', sub: s.cooking.currentStreak ? (nl ? `nu ${s.cooking.currentStreak} dagen` : `${s.cooking.currentStreak} days and counting`) : undefined, tone: 'tomato' },
        { emoji: '🥚', value: n(s.eggs, lang), label: nl ? 'eieren' : 'eggs', sub: s.eggs ? (nl ? `≈ ${n(Math.round(s.eggs / 3), lang)} omeletten` : `≈ ${n(Math.round(s.eggs / 3), lang)} omelettes`) : undefined, tone: 'saffron' },
        { emoji: '🥛', value: `${n(s.milkLitres, lang)} L`, label: nl ? 'melk' : 'of milk', sub: s.milkLitres ? (nl ? `≈ ${n(Math.round(s.milkLitres * 4), lang)} glazen` : `≈ ${n(Math.round(s.milkLitres * 4), lang)} glasses`) : undefined, tone: 'sky' },
        { emoji: '🥦', value: `${n(s.fruitVegKg, lang)} kg`, label: nl ? 'groente & fruit' : 'fruit & veg', sub: nl ? `${s.plantVariety} verschillende soorten` : `${s.plantVariety} different kinds`, tone: 'herb' },
        { emoji: '☕', value: n(s.coffeeCups, lang), label: nl ? 'koppen koffie' : 'cups of coffee', tone: 'saffron' },
        { emoji: '🍞', value: n(s.breadSlices, lang), label: nl ? 'boterhammen' : 'slices of bread', tone: 'saffron' },
        { emoji: '🛟', value: n(s.foodRescued, lang), label: nl ? 'producten gered' : 'items rescued', sub: nl ? 'opgemaakt vlak voor de datum' : 'used just before their date', tone: 'herb' },
        ...(showMoney ? [{ emoji: '🗑️', value: `${n(s.waste.ratePct, lang)}%`, label: nl ? 'weggegooid' : 'wasted', sub: `€ ${s.waste.value.toFixed(2)}`, tone: s.waste.ratePct > 5 ? 'tomato' : 'herb' }] : []),
        { emoji: '🆕', value: n(s.cooking.newRecipes, lang), label: nl ? 'nieuwe recepten geprobeerd' : 'new recipes tried', sub: nl ? `${s.cooking.differentRecipes} verschillende in totaal` : `${s.cooking.differentRecipes} different in total`, tone: 'plum' },
        { emoji: '💪', value: `${n(Math.round(s.cooking.protein / 100) / 10, lang)} kg`, label: nl ? 'eiwit gekookt' : 'of protein cooked', sub: `${n(Math.round(s.cooking.kcal / 1000), lang)}k kcal`, tone: 'plum' },
        { emoji: '🛒', value: n(s.shopping.trips, lang), label: nl ? 'boodschappendagen' : 'shopping days', sub: showMoney ? `€ ${Math.round(s.shopping.spent)}` : undefined, tone: 'sky' },
      ]
    : [];

  return (
    <section>
      <div className="section-head" style={{ marginTop: 6 }}>
        <h2>{title}</h2>
        <div className="loc-tabs" style={{ margin: 0, width: 'auto' }}>
          {(['month', 'year', 'all'] as Period[]).map((p) => (
            <button key={p} aria-pressed={period === p} onClick={() => setPeriod(p)} style={{ padding: '0 10px' }}>{p === 'month' ? (nl ? 'Maand' : 'Month') : p === 'year' ? (nl ? 'Jaar' : 'Year') : nl ? 'Alles' : 'All'}</button>
          ))}
        </div>
      </div>
      {!s ? (
        <div className="skeleton" style={{ height: 220 }} />
      ) : (
        <div className="stack" style={{ gap: 12 }}>
          {top ? (
            <div className="fun-hero">
              <div className="fun-hero-emoji" aria-hidden>{emojiFor({ id: top.productId, category: top.category })}</div>
              <div className="grow">
                <div className="tiny" style={{ textTransform: 'uppercase', letterSpacing: '.08em', fontWeight: 800, opacity: 0.8 }}>{nl ? 'Meest gegeten' : 'Most eaten'}</div>
                <div className="fun-hero-title">{productName(top, lang)}</div>
                <div>{fmtQty(top.quantity, top.unit, lang)}{comparison(top, lang) ? ` · ${comparison(top, lang)}` : ''}</div>
              </div>
            </div>
          ) : (
            <div className="card pad muted small">{nl ? 'Nog niet genoeg gegevens voor deze periode.' : 'Not enough data for this period yet.'}</div>
          )}

          <div className="fun-grid">
            {tiles.map((t) => (
              <div key={t.label} className={`fun-tile ${t.tone ?? ''}`}>
                <div className="fun-emoji" aria-hidden>{t.emoji}</div>
                <div className="fun-value num">{t.value}</div>
                <div className="fun-label">{t.label}</div>
                {t.sub && <div className="fun-sub">{t.sub}</div>}
              </div>
            ))}
          </div>

          <div className="grid-2">
            <div className="card pad stack" style={{ gap: 8 }}>
              <b>{nl ? 'Top 5 gegeten' : 'Top 5 eaten'}</b>
              {s.mostEaten.map((x: any, i: number) => (
                <div key={x.productId} className="row small">
                  <span className="fun-rank">{i + 1}</span>
                  <span aria-hidden>{emojiFor({ id: x.productId, category: x.category })}</span>
                  <span className="grow">{productName(x, lang)}</span>
                  <b className="num">{fmtQty(x.quantity, x.unit, lang)}</b>
                </div>
              ))}
            </div>
            <div className="card pad stack" style={{ gap: 8 }}>
              <b>{nl ? 'In de keuken' : 'In the kitchen'}</b>
              {s.cooking.topRecipes.map((r: any, i: number) => (
                <a key={r.id} href={`#/recipe/${r.id}`} className="row small" style={{ textDecoration: 'none' }}>
                  <span className="fun-rank">{i + 1}</span><span aria-hidden>{r.emoji}</span><span className="grow">{r.title}</span><b className="num">{r.times}×</b>
                </a>
              ))}
              {s.cooking.favouriteCuisine && <div className="small">🌍 {nl ? 'Favoriete keuken' : 'Favourite cuisine'}: <b>{s.cooking.favouriteCuisine.name}</b></div>}
              {s.cooking.busiestWeekday && <div className="small">📅 {nl ? `Je kookt het vaakst op ${WEEKDAYS.nl[s.cooking.busiestWeekday.day]}` : `You cook most on ${WEEKDAYS.en[s.cooking.busiestWeekday.day]}`}</div>}
              {s.shopping.topStores[0] && <div className="small">🏪 {nl ? 'Vaste winkel' : 'Go-to store'}: <b>{s.shopping.topStores[0].store}</b> ({s.shopping.topStores[0].trips}×)</div>}
              <div className="small">⚡ {nl ? `${s.effort.receipts} bonnen gescand, ${s.effort.voiceCommands} spraakopdrachten` : `${s.effort.receipts} receipts scanned, ${s.effort.voiceCommands} voice commands`}</div>
            </div>
          </div>
          {s.plants.length > 0 && (
            <div className="small muted">🌱 {nl ? 'Jouw groente & fruit' : 'Your fruit & veg'}: {s.plants.join(', ').toLowerCase()}</div>
          )}
        </div>
      )}
    </section>
  );
}
