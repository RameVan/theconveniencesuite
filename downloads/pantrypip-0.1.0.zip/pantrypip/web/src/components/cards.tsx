import { uiPrefs } from '../appearance';
import { useState } from 'react';
import { Clock, Heart, Snowflake, Check, PencilLine, Minus, Trash2, ShoppingCart, MoreHorizontal, Info } from 'lucide-react';
import { IngredientSheet } from './Ingredient';
import { post, requestId, invalidate } from '../api';
import { useApp, SCOPES_ALL } from '../app-context';
import { useT, fmtQty, productName, relDays, type Lang } from '../i18n';
import { Plate, Thumb, Stepper, useToast } from './ui';

export function RecipeCard({ r, mini }: { r: any; mini?: boolean }) {
  const t = useT();
  const app = useApp();
  const nl = app.lang === 'nl';
  const have = r.matchPct != null ? Math.round(r.matchPct) : null;
  return (
    <a className={`recipe-card ${mini ? 'mini' : ''}`} href={`#/recipe/${r.id}`}>
      <Plate color={r.color} emoji={r.emoji} image={r.image_url}>
        {r.origin === 'ai' && <span className="tag pill plum">✦ {t('AI-generated')}</span>}
        {r.favourite && <span className="fav" aria-label={nl ? 'Favoriet' : 'Favourite'}><Heart size={15} fill="currentColor" /></span>}
      </Plate>
      <div className="body">
        <h3>{r.title}</h3>
        <div className="facts">
          <span><Clock /> {r.minutes} {t('min')}</span>
          {r.rating ? <span className="stars" aria-label={`${r.rating} ${nl ? 'sterren' : 'stars'}`}>{'★'.repeat(r.rating)}</span> : null}
          {have != null && <span className={`have ${have >= 80 ? 'good' : ''}`}>{have >= 100 ? (nl ? 'Alles in huis' : 'All in stock') : nl ? `${have}% in huis` : `${have}% in stock`}</span>}
          {r.compat === 'specialist' && <span className="pill compat specialist compact">{nl ? 'Speciaalzaak' : 'Specialist shop'}</span>}
          {r.compat === 'partial' && <span className="pill compat partial compact">{nl ? 'Na te kijken' : 'To check'}</span>}
        </div>
        {!mini && r.reasons?.[0] && <div className="why">{r.reasons[0]}</div>}
      </div>
    </a>
  );
}

export function stockQty(s: any, lang: Lang) {
  const q = s.showEstimate ? s.estimated : s.confirmed;
  const approx = s.showEstimate && s.estimated < s.confirmed - 1e-6;
  return { q, text: `${approx ? '≈ ' : ''}${fmtQty(q, s.product.unit, lang, s.product.unit === 'pcs' ? s.product.piece_name : null)}`, approx };
}

/** A leftover lot: eat, throw away, freeze or thaw any number of portions. */
export function LeftoverRow({ l }: { l: any }) {
  const app = useApp();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const [open, setOpen] = useState(false);
  const [n, setN] = useState(Math.min(1, l.quantity));
  const frozen = l.location_kind === 'freezer';
  const act = async (action: 'eat' | 'discard' | 'freeze' | 'thaw', text: string) => {
    if (action === 'discard' && uiPrefs.confirmDestructive && !confirm(nl ? `${l.title} weggooien?` : `Throw away ${l.title}?`)) return;
    try {
      const r = await post(`/api/leftovers/${l.id}`, { action, portions: n, clientRequestId: requestId() });
      invalidate(SCOPES_ALL);
      setOpen(false);
      toast({ text, undo: r?.batchId ? () => post('/api/inventory/undo', { batchId: r.batchId }).then(() => invalidate(SCOPES_ALL)) : undefined });
    } catch (e: any) {
      toast({ text: e.message, error: true });
    }
  };
  return (
    <div>
      <button className="item" onClick={() => setOpen((o) => !o)} aria-expanded={open}>
        <span className="thumb">{frozen ? '🧊' : '🥡'}</span>
        <span className="grow">
          <span className="title" style={{ display: 'block' }}>{l.title}</span>
          <span className="meta">{l.location_name} · {frozen ? `${nl ? 'ingevroren' : 'frozen'} ${l.frozen_at?.slice(0, 10) ?? ''}` : relDays(l.days_to_expiry, app.lang)}</span>
        </span>
        <span className="qty">{fmtQty(l.quantity, 'portion', app.lang)}</span>
      </button>
      {open && (
        <div className="swipe-actions" style={{ alignItems: 'center' }}>
          <span className="small muted">{nl ? 'Porties' : 'Portions'}</span>
          <Stepper value={n} onChange={setN} min={0.5} max={l.quantity} step={0.5} label="portions" />
          <button className="btn sm soft" onClick={() => act('eat', nl ? 'Eet smakelijk!' : 'Enjoy!')}>{nl ? 'Opgegeten' : 'Eaten'}</button>
          <button className="btn sm" onClick={() => act('discard', nl ? 'Weggegooid' : 'Thrown away')}><Trash2 size={14} /></button>
          <button className="btn sm" onClick={() => act(frozen ? 'thaw' : 'freeze', frozen ? (nl ? 'Ontdooit in de koelkast' : 'Thawing in the fridge') : nl ? 'Ingevroren' : 'Frozen')}><Snowflake size={14} /> {frozen ? (nl ? 'Ontdooien' : 'Thaw') : nl ? 'Invriezen' : 'Freeze'}</button>
        </div>
      )}
    </div>
  );
}

/** One inventory product with confirmed vs estimated quantity, expiry and one-tap actions. */
export function StockRow({ s, defaultOpen = false }: { s: any; defaultOpen?: boolean }) {
  const app = useApp();
  const t = useT();
  const toast = useToast();
  const [open, setOpen] = useState(defaultOpen);
  const [editing, setEditing] = useState(false);
  const [extra, setExtra] = useState(false);
  const [about, setAbout] = useState(false);
  const [val, setVal] = useState('');
  const { q, text, approx } = stockQty(s, app.lang);
  const p = s.product;
  const name = productName(p, app.lang);

  const run = async (fn: () => Promise<any>, label: string) => {
    try {
      const r = await fn();
      invalidate(SCOPES_ALL);
      toast({ text: label, undo: r?.batchId ? () => post('/api/inventory/undo', { batchId: r.batchId }).then(() => invalidate(SCOPES_ALL)) : undefined });
    } catch (e: any) {
      toast({ text: e.message, error: true });
    }
  };
  const use = (qty: number | 'all') => run(() => post('/api/inventory/consume', { productId: p.id, quantity: qty, clientRequestId: requestId() }), `${name} −${qty === 'all' ? text : fmtQty(qty, p.unit, app.lang)}`);
  const confirm = () => run(() => post('/api/inventory/set', { productId: p.id, quantity: Math.round(q * 100) / 100, clientRequestId: requestId() }), app.lang === 'nl' ? `${name} bevestigd` : `${name} confirmed`);
  const correct = (v: number) => run(() => post('/api/inventory/set', { productId: p.id, quantity: v, clientRequestId: requestId() }), `${name} = ${fmtQty(v, p.unit, app.lang)}`);
  const step = p.unit === 'pcs' ? 1 : p.piece_size ?? (p.unit === 'ml' ? 250 : Math.min(100, p.package_size / 4));

  const expiry = s.daysToExpiry;
  return (
    <div>
      <button className="item" onClick={() => setOpen((o) => !o)} aria-expanded={open}>
        <Thumb product={p} />
        <span className="grow" style={{ minWidth: 0 }}>
          <span className="title ellipsis" style={{ display: 'block' }}>{name}</span>
          {(expiry != null && expiry <= 3) || s.status === 'out' || s.status === 'low' || s.locations.includes('Freezer') ? (
            <span className="meta">
              {expiry != null && expiry <= 3 ? <span className={`pill ${expiry < 0 ? 'tomato' : 'saffron'}`}>{relDays(expiry, app.lang)}</span>
                : s.status === 'out' ? <span className="pill tomato">{t('Out')}</span>
                  : s.status === 'low' ? <span className="pill saffron">{t('Low')}</span> : null}
              {s.locations.includes('Freezer') && <Snowflake size={13} aria-label={app.lang === 'nl' ? 'ingevroren' : 'frozen'} />}
            </span>
          ) : null}
        </span>
        <span className="qty"><span className={approx ? 'estimate' : ''}>{text}</span></span>
      </button>
      {open && (
        <div className="swipe-actions">
          <button className="btn sm" onClick={() => use(step)}><Minus size={14} /> {fmtQty(step, p.unit, app.lang, p.piece_name)}</button>
          <button className="btn sm" onClick={() => use('all')}>{app.lang === 'nl' ? 'Op' : 'Finished'}</button>
          {approx && <button className="btn sm soft" onClick={confirm}><Check size={14} /> {app.lang === 'nl' ? 'Klopt' : 'Looks right'}</button>}
          <button className="btn sm ghost" onClick={() => setExtra((x) => !x)} aria-expanded={extra}><MoreHorizontal size={14} /> {app.lang === 'nl' ? 'Meer' : 'More'}</button>
          {extra && (
            <>
              <button className="btn sm" onClick={() => app.openQuick({ mode: 'use', productId: p.id })}>{t('Use')}…</button>
              <button className="btn sm" onClick={() => (setEditing(true), setVal(String(Math.round(q))))}><PencilLine size={14} /> {t('Correct')}</button>
              <button className="btn sm" onClick={() => app.openQuick({ mode: 'discard', productId: p.id })}><Trash2 size={14} /> {app.lang === 'nl' ? 'Weggooien' : 'Throw away'}</button>
              <button className="btn sm" onClick={() => run(() => post('/api/shopping', { productId: p.id, packages: 1 }), `${name} → ${t('Shopping')}`)}><ShoppingCart size={14} /> {t('To list')}</button>
              <button className="btn sm" onClick={() => setAbout(true)}><Info size={14} /> {app.lang === 'nl' ? 'Soort & winkels' : 'Type & shops'}</button>
              {s.lots[0] && !s.locations.includes('Freezer') && p.freezer_life_days && (
                <button className="btn sm" onClick={() => run(() => post(`/api/inventory/lots/${s.lots[0].id}/move`, { to: 'freezer', clientRequestId: requestId() }), app.lang === 'nl' ? `${name} ingevroren` : `${name} frozen`)}><Snowflake size={14} /> {app.lang === 'nl' ? 'Invriezen' : 'Freeze'}</button>
              )}
            </>
          )}
          {editing && (
            <form className="row" style={{ width: '100%' }} onSubmit={(e) => { e.preventDefault(); const v = Number(val.replace(',', '.')); if (v >= 0) correct(v); setEditing(false); }}>
              <input className="input" autoFocus inputMode="decimal" value={val} onChange={(e) => setVal(e.target.value)} aria-label="Quantity" style={{ maxWidth: 140 }} />
              <span className="muted small">{p.unit === 'pcs' ? (app.lang === 'nl' ? 'stuks' : 'pcs') : p.unit}</span>
              <button className="btn primary sm">{t('Save')}</button>
            </form>
          )}
          {about && <IngredientSheet productId={p.id} lotIds={s.lots.map((l: any) => l.id)} onClose={() => setAbout(false)} />}
          <div className="tiny muted" style={{ width: '100%' }}>
            {app.lang === 'nl' ? 'Bevestigd' : 'Confirmed'}: {fmtQty(s.confirmed, p.unit, app.lang)}
            {s.prediction.ratePerDay ? ` · ${app.lang === 'nl' ? 'verbruik' : 'use'} ≈ ${fmtQty(s.prediction.ratePerDay * 7, p.unit, app.lang)}/${app.lang === 'nl' ? 'week' : 'week'}` : ''}
            {s.soonestExpiry ? ` · ${app.lang === 'nl' ? 'THT' : 'best before'} ${s.soonestExpiry}${s.expiryEstimated ? ' (≈)' : ''}` : ''}
          </div>
        </div>
      )}
    </div>
  );
}
