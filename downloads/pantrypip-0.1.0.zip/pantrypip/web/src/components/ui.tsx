import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { X, Minus, Plus } from 'lucide-react';
import { useT } from '../i18n';
import { Pip } from './Pip';

// ---------- Sheet ----------
export function Sheet({ title, onClose, children, footer, wide, className = '', labelledBy }: { title?: ReactNode; onClose: () => void; children: ReactNode; footer?: ReactNode; wide?: boolean; className?: string; labelledBy?: string }) {
  const t = useT();
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    const prev = document.activeElement as HTMLElement | null;
    ref.current?.querySelector<HTMLElement>('[autofocus], input, button')?.focus();
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
      prev?.focus?.();
    };
  }, [onClose]);
  return (
    <>
      <div className="scrim" onClick={onClose} />
      <div className={`sheet ${wide ? 'wide' : ''} ${className}`} role="dialog" aria-modal="true" aria-label={typeof title === 'string' ? title : undefined} aria-labelledby={labelledBy} ref={ref}>
        <div className="grab" />
        {title !== undefined && (
          <header>
            <h2>{title}</h2>
            <button className="icon-btn ghost" onClick={onClose} aria-label={t('Close')}>
              <X />
            </button>
          </header>
        )}
        <div className="content">{children}</div>
        {footer && <footer>{footer}</footer>}
      </div>
    </>
  );
}

// ---------- Toasts with undo ----------
interface Toast { id: number; text: string; undo?: () => void | Promise<void>; error?: boolean; ms?: number }
const ToastCtx = createContext<{ push: (t: Omit<Toast, 'id'>) => void }>({ push: () => {} });
export const useToast = () => useContext(ToastCtx).push;

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Toast[]>([]);
  const t = useT();
  const push = useCallback((x: Omit<Toast, 'id'>) => {
    const id = Date.now() + Math.random();
    setItems((s) => [...s.slice(-2), { ...x, id }]);
    setTimeout(() => setItems((s) => s.filter((i) => i.id !== id)), x.ms ?? (x.undo ? 6500 : 3500));
  }, []);
  return (
    <ToastCtx.Provider value={{ push }}>
      {children}
      <div className="toasts" role="status" aria-live="polite">
        {items.map((i) => (
          <div key={i.id} className={`toast ${i.error ? 'error' : ''}`}>
            <span className="grow">{i.text}</span>
            {i.undo && (
              <button
                onClick={async () => {
                  setItems((s) => s.filter((x) => x.id !== i.id));
                  await i.undo!();
                }}
              >
                {t('Undo')}
              </button>
            )}
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

// ---------- Small visual pieces ----------
export function Plate({ color, emoji, image, children, className = '' }: { color?: string | null; emoji?: string | null; image?: string | null; children?: ReactNode; className?: string }) {
  return (
    <div className={`plate ${className}`} style={{ ['--c' as any]: color ?? '#7A8B6F' }}>
      {image ? <img src={image} alt="" loading="lazy" /> : <span className="food" aria-hidden>{emoji ?? '🍽️'}</span>}
      {children}
    </div>
  );
}

export function Conf({ value }: { value: number }) {
  const bars = value >= 0.75 ? 3 : value >= 0.45 ? 2 : 1;
  return (
    <span className="conf" title={`Confidence ${Math.round(value * 100)}%`} aria-label={`confidence ${Math.round(value * 100)} percent`}>
      {[0, 1, 2].map((i) => <i key={i} className={i < bars ? 'on' : ''} />)}
    </span>
  );
}

export function Level({ ratio, status }: { ratio: number; status: string }) {
  return (
    <div className={`level ${status === 'out' ? 'out' : status === 'low' ? 'low' : ''}`} aria-hidden>
      <i style={{ width: `${Math.max(4, Math.min(100, ratio * 100))}%` }} />
    </div>
  );
}

export function Empty({ art, title, children }: { art: string; title: string; children?: ReactNode }) {
  return (
    <div className="empty">
      <div className="art" aria-hidden><span className="art-emoji">{art}</span><Pip className="art-pip" size={64} mood="calm" label="" /></div>
      <h3>{title}</h3>
      {children}
    </div>
  );
}

export function Stepper({ value, onChange, min = 1, max = 40, step = 1, label }: { value: number; onChange: (n: number) => void; min?: number; max?: number; step?: number; label?: string }) {
  return (
    <div className="stepper" role="group" aria-label={label}>
      <button onClick={() => onChange(Math.max(min, +(value - step).toFixed(2)))} aria-label="less"><Minus size={16} /></button>
      <span aria-live="polite">{value}</span>
      <button onClick={() => onChange(Math.min(max, +(value + step).toFixed(2)))} aria-label="more"><Plus size={16} /></button>
    </div>
  );
}

const EMOJI: Record<string, string> = {
  milk: '🥛', whole_milk: '🥛', oat_milk: '🥛', eggs: '🥚', butter: '🧈', yoghurt: '🥣', skyr: '🥣', quark: '🥣', cheese: '🧀', parmesan: '🧀', mozzarella: '🧀', feta: '🧀',
  cream: '🥛', creme_fraiche: '🥛', onion: '🧅', red_onion: '🧅', garlic: '🧄', potatoes: '🥔', sweet_potato: '🍠', carrots: '🥕', tomatoes: '🍅', cherry_tomatoes: '🍅',
  cucumber: '🥒', bell_pepper: '🫑', zucchini: '🥒', broccoli: '🥦', cauliflower: '🥦', spinach: '🥬', lettuce: '🥬', mushrooms: '🍄', leek: '🥬', green_beans: '🫛',
  avocado: '🥑', lemon: '🍋', lime: '🍋', apples: '🍎', bananas: '🍌', berries: '🫐', ginger: '🫚', chili: '🌶️', parsley: '🌿', coriander: '🌿', basil: '🌿',
  spring_onion: '🌱', wok_vegetables: '🥗', chicken_breast: '🍗', chicken_thigh: '🍗', minced_beef: '🥩', bacon: '🥓', ham: '🍖', salmon: '🐟', shrimp: '🦐',
  tuna: '🐟', smoked_sausage: '🌭', tofu: '🧊', bread: '🍞', wraps: '🫓', croissants: '🥐', pasta: '🍝', rice: '🍚', noodles: '🍜', oats: '🌾', flour: '🌾',
  sugar: '🍬', olive_oil: '🫒', sunflower_oil: '🌻', canned_tomatoes: '🥫', tomato_paste: '🥫', coconut_milk: '🥥', chickpeas: '🫘', kidney_beans: '🫘', lentils: '🫘',
  stock_cube: '🧂', soy_sauce: '🍶', peanut_butter: '🥜', honey: '🍯', curry_paste: '🍛', pesto: '🌿', mustard: '🌭', mayonnaise: '🥚', vinegar: '🍶',
  breakfast_cereal: '🥣', nuts: '🥜', chocolate: '🍫', crisps: '🥔', hummus: '🫘', coffee: '☕', tea: '🍵', orange_juice: '🍊', sparkling_water: '💧', beer: '🍺',
  salt: '🧂', pepper: '🧂', paprika_powder: '🌶️', cumin: '🌰', curry_powder: '🍛', oregano: '🌿', cinnamon: '🌰', frozen_peas: '🫛', frozen_spinach: '🥬',
  frozen_berries: '🍓', frozen_pizza: '🍕', ice_cream: '🍨',
};
const CAT: Record<string, string> = { produce: '🥬', dairy: '🥛', meat_fish: '🍗', bakery: '🍞', pantry: '🥫', spices: '🧂', snacks: '🍪', drinks: '🧃', frozen: '🧊', other: '🛒' };

export function emojiFor(p: { id?: string; category?: string } | null | undefined): string {
  if (!p) return '🛒';
  return EMOJI[(p.id ?? '').replace(/^p_/, '')] ?? CAT[p.category ?? 'other'] ?? '🛒';
}

export function Thumb({ product, emoji }: { product?: { id?: string; category?: string; image_url?: string | null } | null; emoji?: string }) {
  return <span className="thumb" aria-hidden>{product?.image_url ? <img src={product.image_url} alt="" loading="lazy" /> : emoji ?? emojiFor(product)}</span>;
}
