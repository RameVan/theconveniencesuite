import { createContext, useContext } from 'react';

export type Lang = 'en' | 'nl';

const NL: Record<string, string> = {
  Home: 'Thuis', Inventory: 'Voorraad', Plan: 'Planner', Discover: 'Ontdekken', Shopping: 'Boodschappen',
  'Good morning': 'Goedemorgen', 'Good afternoon': 'Goedemiddag', 'Good evening': 'Goedenavond',
  'Use soon': 'Snel gebruiken', 'Running low': 'Bijna op', 'Cook tonight': 'Vanavond koken', 'Today': 'Vandaag', 'Leftovers': 'Restjes',
  'Recent activity': 'Recente activiteit', 'Suggested for your list': 'Voorstellen voor je lijst', 'Nothing urgent. Enjoy your day.': 'Niets dringends. Fijne dag.',
  'Say or type… e.g. “I finished the milk”': 'Zeg of typ… bijv. “de melk is op”', Listening: 'Luisteren…', 'Tap to speak': 'Tik om te spreken',
  Add: 'Toevoegen', Use: 'Gebruiken', 'Throw away': 'Weggooien', 'To list': 'Op lijst', Undo: 'Ongedaan maken', Done: 'Klaar', Cancel: 'Annuleren', Save: 'Opslaan', Close: 'Sluiten',
  'Scan receipt': 'Bon scannen', 'Scan barcode': 'Barcode scannen', Speak: 'Spreek', 'Quick add': 'Snel toevoegen',
  'All': 'Alles', Fridge: 'Koelkast', Freezer: 'Vriezer', Pantry: 'Voorraadkast', 'Search inventory': 'Zoek in voorraad',
  'estimate': 'schatting', 'confirmed': 'bevestigd', 'Still right?': 'Klopt dit nog?', 'Yes': 'Ja', 'No': 'Nee', 'Correct': 'Corrigeren',
  'expires today': 'vervalt vandaag', 'expired': 'over de datum', 'days left': 'dagen over', 'day left': 'dag over', 'Out': 'Op', 'Low': 'Bijna op',
  'Breakfast': 'Ontbijt', 'Lunch': 'Lunch', 'Dinner': 'Avondeten', 'Snack': 'Snack', 'Add meal': 'Maaltijd toevoegen', 'Cooked': 'Gekookt', 'Skipped': 'Overgeslagen',
  'Cook with what I have': 'Koken met wat ik heb', 'Find recipes': 'Recepten zoeken', 'Generate with AI': 'Maak met AI', 'AI-generated': 'Door AI gemaakt',
  'have': 'in huis', 'missing': 'mist', 'servings': 'porties', 'min': 'min', 'Start cooking': 'Begin met koken', 'Add missing to list': 'Ontbrekende op de lijst',
  'Plan it': 'Inplannen', 'Ingredients': 'Ingrediënten', 'Steps': 'Bereiding', 'Nutrition per serving': 'Voedingswaarde per portie', 'Saved': 'Bewaard', 'Save recipe': 'Bewaar recept',
  'Shopping mode': 'Winkelmodus', 'Finish shopping': 'Klaar met winkelen', 'In cart': 'In het mandje', 'Suggestions': 'Voorstellen', 'Your list is empty': 'Je lijst is leeg',
  'Add item': 'Item toevoegen', 'Insights': 'Inzichten', 'Settings': 'Instellingen', 'Sign out': 'Uitloggen', 'Language': 'Taal',
  'Spent (30 days)': 'Uitgegeven (30 dagen)', 'Wasted (30 days)': 'Weggegooid (30 dagen)', 'Products in stock': 'Producten in huis',
  'Review receipt': 'Bon controleren', 'Add to inventory': 'Aan voorraad toevoegen', 'Needs a check': 'Even checken', 'Skip': 'Overslaan',
  'Next': 'Volgende', 'Back': 'Terug', 'Finish': 'Afronden', 'Timer': 'Timer', 'I cooked this': 'Ik heb dit gekookt', 'Leftovers?': 'Restjes?',
};

export const LangContext = createContext<Lang>('en');
export function useT() {
  const lang = useContext(LangContext);
  return (s: string) => (lang === 'nl' ? NL[s] ?? s : s);
}
export function useLang() {
  return useContext(LangContext);
}

export function detectLang(pref?: string | null): Lang {
  if (pref === 'en' || pref === 'nl') return pref;
  return navigator.language.toLowerCase().startsWith('nl') ? 'nl' : 'en';
}

export function fmtQty(q: number, unit: string, lang: Lang = 'en', pieceName?: string | null): string {
  const r = Math.abs(q) >= 100 ? Math.round(q) : Math.abs(q) >= 10 ? Math.round(q * 10) / 10 : Math.round(q * 100) / 100;
  const n = (x: number) => (lang === 'nl' ? String(x).replace('.', ',') : String(x));
  if (unit === 'g') return Math.abs(r) >= 1000 ? `${n(Math.round(r / 100) / 10)} kg` : `${n(r)} g`;
  if (unit === 'ml') return Math.abs(r) >= 1000 ? `${n(Math.round(r / 100) / 10)} L` : `${n(r)} ml`;
  if (unit === 'portion') return `${n(r)} ${lang === 'nl' ? (r === 1 ? 'portie' : 'porties') : r === 1 ? 'portion' : 'portions'}`;
  // Countable items: whole numbers read better than "0.46 tomatoes".
  const whole = r > 0 && r < 1 ? '<1' : n(Math.round(r * 2) / 2);
  if (!pieceName) return whole;
  const plural = r === 1 ? pieceName : /(o|ch|sh|s)$/.test(pieceName) ? `${pieceName}es` : `${pieceName}s`;
  return lang === 'en' ? `${whole} ${plural}` : whole;
}

export function productName(p: { name: string; name_nl?: string | null }, lang: Lang) {
  return lang === 'nl' && p.name_nl ? p.name_nl : p.name;
}

export function relDays(days: number | null | undefined, lang: Lang): string {
  if (days == null) return '';
  if (days < 0) return lang === 'nl' ? 'over de datum' : 'past date';
  if (days === 0) return lang === 'nl' ? 'vandaag' : 'today';
  if (days === 1) return lang === 'nl' ? 'morgen' : 'tomorrow';
  return lang === 'nl' ? `over ${days} dagen` : `in ${days} days`;
}

export function timeAgo(iso: string, lang: Lang): string {
  const s = (Date.now() - new Date(iso).getTime()) / 1000;
  if (s < 60) return lang === 'nl' ? 'zojuist' : 'just now';
  if (s < 3600) return `${Math.round(s / 60)} min`;
  if (s < 86400) return `${Math.round(s / 3600)} ${lang === 'nl' ? 'uur' : 'h'}`;
  return `${Math.round(s / 86400)} ${lang === 'nl' ? 'd' : 'd'}`;
}
