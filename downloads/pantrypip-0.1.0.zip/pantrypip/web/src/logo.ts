// The PantryPip logo, coloured for each style. The mark is always the same "pip" (stem–bowl with Pip's
// face, the i with a leaf, stem–bowl with a dot); each style picks the tile, ink, leaf and dot colours and
// may add its own ground underneath (Suite's sunset stripes, Corner Grocer's awning, ...). The app icon
// on the home screen is the Suite version (web/public/icon.svg, docs/design/logos/logo-01.svg).
import type { Style } from './appearance';

export type Ground = 'sun' | 'awning' | 'rule' | 'brass' | 'bar' | 'bands';
export interface LogoLook { bg: string; ink: string; leaf: string; dot: string; ground?: Ground }

const ORIGINAL: LogoLook = { bg: '#F4F1EC', ink: '#24323B', leaf: '#6A994E', dot: '#E76F51' };
export const LOGO: Partial<Record<Style, LogoLook>> = {
  suite: { bg: '#0D0D0D', ink: '#F7F3EA', leaf: '#6A994E', dot: '#E3532B', ground: 'sun' },
  editorial: { bg: '#F4F1EC', ink: '#1F2A31', leaf: '#3C6531', dot: '#B4462A', ground: 'rule' },
  grocer: { bg: '#B8352A', ink: '#FFF6E6', leaf: '#F1D27A', dot: '#1D1B16', ground: 'awning' },
  skog: { bg: '#EEEAE3', ink: '#3F5A4C', leaf: '#6F8F68', dot: '#A14E37' },
  dot: { bg: '#FFFFFF', ink: '#24323B', leaf: '#6A994E', dot: '#E76F51' },
  epicerie: { bg: '#2B2F25', ink: '#EFE6D2', leaf: '#A3B26E', dot: '#A07A3A', ground: 'brass' },
  monoline: ORIGINAL,
  raster: { bg: '#FFFFFF', ink: '#111111', leaf: '#C4341A', dot: '#C4341A', ground: 'bar' },
  seventies: { bg: '#F0E3CC', ink: '#33231A', leaf: '#6E7C33', dot: '#A3442A', ground: 'bands' },
};
export const logoFor = (style: Style | undefined): LogoLook => (style && LOGO[style]) || ORIGINAL;

function ground(g: Ground | undefined, l: LogoLook): string {
  const band = (y: number, h: number, c: string, x = 0, w = 512) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${c}"/>`;
  switch (g) {
    case 'sun': return ['#F5B335', '#F08A2B', '#E3532B', '#B8261E'].map((c, i) => band(408 + i * 26, 26, c)).join('');
    case 'awning': return band(404, 6, l.ink) + Array.from({ length: 6 }, (_, i) => band(410, 102, l.ink, i * 88 + 44, 44)).join('');
    case 'rule': return band(424, 8, l.dot, 112, 288);
    case 'brass': return band(420, 4, l.dot, 132, 248) + band(434, 4, l.dot, 132, 248);
    case 'bar': return band(436, 28, l.dot);
    case 'bands': return band(414, 32, '#DBA73F') + band(446, 32, l.dot) + band(478, 34, l.leaf);
    default: return '';
  }
}

/** The logo as SVG markup. `bleed`: a square, full-bleed tile (for icons that the system rounds itself). */
export function logoSvg(l: LogoLook, { bleed = false } = {}): string {
  // With a ground the mark sits higher (logo 1); without one it is centred.
  const place = l.ground ? 'translate(8 -46) scale(0.96)' : 'translate(3.94 -7.1) scale(0.92)';
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><defs><clipPath id="pp-t"><rect width="512" height="512" rx="${bleed ? 0 : 112}"/></clipPath></defs>`
    + `<g clip-path="url(#pp-t)"><rect width="512" height="512" fill="${l.bg}"/>${ground(l.ground, l)}`
    + `<g transform="${place}"><path d="M112 206V430M262 214V314M320 206V430" fill="none" stroke="${l.ink}" stroke-width="22" stroke-linecap="round"/>`
    + `<circle cx="170" cy="258" r="58" fill="none" stroke="${l.ink}" stroke-width="22"/><circle cx="378" cy="258" r="58" fill="none" stroke="${l.ink}" stroke-width="22"/>`
    + `<path d="M262 176C262 150 278 134 304 132C302 156 286 172 262 176Z" fill="${l.leaf}"/>`
    + `<circle cx="156" cy="252" r="9" fill="${l.ink}"/><circle cx="186" cy="252" r="9" fill="${l.ink}"/><circle cx="378" cy="258" r="20" fill="${l.dot}"/></g></g></svg>`;
}

export const logoDataUrl = (l: LogoLook) => `data:image/svg+xml,${encodeURIComponent(logoSvg(l))}`;
