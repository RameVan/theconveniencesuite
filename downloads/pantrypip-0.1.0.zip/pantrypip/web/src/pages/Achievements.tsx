// Everything you've earned, in one place: newest first, grouped by month, filterable by kind.
import { useMemo, useState } from 'react';
import { ChevronLeft } from 'lucide-react';
import { useQuery } from '../api';
import { useApp } from '../app-context';
import { Empty } from '../components/ui';

type Filter = 'all' | 'journey' | 'chapter' | 'track' | 'badge' | 'challenge';
const FILTERS: [Filter, string, string][] = [
  ['all', 'All', 'Alles'], ['journey', 'Journey', 'Reis'], ['chapter', 'Chapters', 'Hoofdstukken'], ['track', 'Skills', 'Vaardigheden'], ['badge', 'Badges', 'Badges'], ['challenge', 'Challenges', 'Uitdagingen'],
];
const GROUP_LABEL: Record<string, [string, string]> = {
  journey: ['Journey step', 'Reisstap'], bonus: ['Bonus task', 'Bonustaak'], chest: ['Reward chest', 'Beloningskist'], chapter: ['Chapter challenge', 'Hoofdstukuitdaging'],
  track: ['Skill level', 'Vaardigheidsniveau'], badge: ['Badge', 'Badge'], challenge: ['Challenge', 'Uitdaging'],
};
const inFilter = (group: string, f: Filter) => f === 'all' || (f === 'journey' ? group === 'journey' || group === 'bonus' : f === 'chapter' ? group === 'chapter' || group === 'chest' : group === f);

export function AchievementsPage() {
  const app = useApp();
  const nl = app.lang === 'nl';
  const { data } = useQuery<any>('/api/achievements', ['game', 'inventory', 'recipes', 'planner', 'shopping']);
  const [filter, setFilter] = useState<Filter>('all');
  const sections = useMemo(() => {
    const out = new Map<string, any[]>();
    for (const i of (data?.items ?? []).filter((x: any) => inFilter(x.group, filter))) {
      const key = i.at ? new Date(i.at).toLocaleDateString(nl ? 'nl-NL' : 'en-GB', { month: 'long', year: 'numeric' }) : nl ? 'Badges' : 'Badges';
      out.set(key, [...(out.get(key) ?? []), i]);
    }
    return [...out.entries()];
  }, [data, filter, nl]);
  const count = (f: Filter) => (data?.items ?? []).filter((x: any) => inFilter(x.group, f)).length;

  return (
    <>
      <div className="topbar">
        <a className="icon-btn ghost" href="#/progress" aria-label={nl ? 'Terug naar voortgang' : 'Back to progress'}><ChevronLeft /></a>
        <div className="grow"><h1>{nl ? 'Prestaties' : 'Achievements'}</h1></div>
      </div>
      {!data ? (
        <div className="stack">{[1, 2, 3].map((i) => <div key={i} className="skeleton" style={{ height: 64 }} />)}</div>
      ) : (
        <>
          <div className="ach-summary">
            <div><b className="num">{data.total}</b><span>{nl ? 'behaald' : 'earned'}</span></div>
            <div><b className="num">{data.xp}</b><span>{nl ? 'XP daaruit' : 'XP from them'}</span></div>
            <div><b className="num">{data.badges.done}/{data.badges.all}</b><span>badges</span></div>
          </div>
          <div className="chips ach-filters" role="tablist" aria-label={nl ? 'Soort' : 'Kind'}>
            {FILTERS.map(([id, en, nlL]) => (
              <button key={id} role="tab" aria-selected={filter === id} className={`chip ${filter === id ? 'on' : ''}`} onClick={() => setFilter(id)}>{nl ? nlL : en} <span className="muted">{count(id)}</span></button>
            ))}
          </div>
          {!sections.length && (
            <Empty art="🏅" title={nl ? 'Nog niets hier' : 'Nothing here yet'}>
              <p className="small">{nl ? 'Kook, plan en gebruik je voorraad: elke stap op je reis komt hier te staan.' : 'Cook, plan and use what you have: every step on your journey shows up here.'}</p>
              <a className="btn primary" href="#/progress">{nl ? 'Naar je reis' : 'Go to your journey'}</a>
            </Empty>
          )}
          {sections.map(([label, items]) => (
            <section key={label}>
              <div className="section-head"><h2>{label}</h2><span className="tiny muted">{items.length}</span></div>
              <div className="list">
                {items.map((i: any) => (
                  <div key={i.id} className="item ach-row">
                    <span className="thumb">{i.emoji}</span>
                    <span className="grow" style={{ minWidth: 0 }}>
                      <span className="title" style={{ display: 'block' }}>{nl ? i.title_nl : i.title}</span>
                      <span className="meta">{nl ? GROUP_LABEL[i.group]?.[1] : GROUP_LABEL[i.group]?.[0]}{i.at ? ` · ${new Date(i.at).toLocaleDateString(nl ? 'nl-NL' : 'en-GB', { day: 'numeric', month: 'short' })}` : ''}{(nl ? i.desc_nl : i.desc) ? ` · ${nl ? i.desc_nl : i.desc}` : ''}</span>
                    </span>
                    <b className="ach-xp">+{i.xp}</b>
                  </div>
                ))}
              </div>
            </section>
          ))}
        </>
      )}
    </>
  );
}
