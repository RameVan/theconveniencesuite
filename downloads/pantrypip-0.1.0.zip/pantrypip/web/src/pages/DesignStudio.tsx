// Design studio (#/design): the eight design directions side by side, on your own data. Compare opens the
// real app in frames (/?dz=<direction>, applied to that frame only, nothing saved); Specimen shows each
// direction's type and components; Pip shows the companion. "Use" saves the style like Settings does.
import { useEffect, useMemo, useRef, useState } from 'react';
import { ChevronLeft, Check, Plus, Search, Clock, Users } from 'lucide-react';
import { STYLES, DIRECTIONS, DEFAULT_STYLE, type Direction } from '../appearance';
import { useSetting } from '../settings';
import { useApp } from '../app-context';
import { useQuery } from '../api';
import { Pip, type PipMood } from '../components/Pip';
import { logoDataUrl, logoFor } from '../logo';
import { Empty, Plate } from '../components/ui';

/** Type roles per direction (docs/design/TYPOGRAPHY.md). */
const TYPE: Record<Direction, { display: string; heading: string; body: string; ui: string; data: string; label: string }> = {
  editorial: { display: 'Fraunces 420 italic', heading: 'Fraunces 500', body: 'Figtree 400', ui: 'Figtree 600', data: 'Figtree tabular', label: 'Figtree 650 caps' },
  grocer: { display: 'Bricolage Grotesque 800 condensed', heading: 'Bricolage Grotesque 800', body: 'Bricolage Grotesque 400', ui: 'Bricolage Grotesque 700', data: 'DM Mono 500', label: 'DM Mono caps' },
  skog: { display: 'Albert Sans 300', heading: 'Albert Sans 450', body: 'Albert Sans 400', ui: 'Albert Sans 550', data: 'Albert Sans tabular', label: 'Albert Sans 500' },
  dot: { display: 'Outfit 600', heading: 'Outfit 600', body: 'Outfit 400', ui: 'Outfit 600', data: 'Outfit tabular', label: 'Outfit 600' },
  epicerie: { display: 'Cormorant Garamond 500 italic', heading: 'Cormorant Garamond 600', body: 'Jost 400', ui: 'Jost 500 spaced caps', data: 'Jost tabular', label: 'Jost 500 spaced caps' },
  monoline: { display: 'Quicksand 700 lowercase', heading: 'Quicksand 700', body: 'Figtree 400', ui: 'Figtree 600', data: 'Figtree tabular', label: 'Figtree 600' },
  raster: { display: 'Inter Tight 700', heading: 'Inter Tight 650', body: 'Inter 400', ui: 'Inter 600', data: 'JetBrains Mono 500', label: 'JetBrains Mono caps' },
  seventies: { display: 'Fraunces 760 soft, wonky', heading: 'Fraunces 700 soft', body: 'Figtree 400', ui: 'Figtree 700', data: 'Figtree tabular', label: 'Figtree 800' },
  suite: { display: 'Newsreader 380', heading: 'Newsreader 420', body: 'Figtree 400', ui: 'Figtree 650 caps', data: 'Figtree tabular', label: 'Figtree 650 spaced caps' },
};

const SCREENS: { route: string; en: string; nl: string }[] = [
  { route: '#/', en: 'Home', nl: 'Thuis' },
  { route: '#/shopping', en: 'Shopping list', nl: 'Boodschappenlijst' },
  { route: '#/discover', en: 'Recipes', nl: 'Recepten' },
  { route: 'recipe', en: 'Recipe', nl: 'Recept' },
  { route: '#/plan', en: 'Planner', nl: 'Planner' },
  { route: '#/inventory', en: 'In stock', nl: 'In huis' },
  { route: '#/settings', en: 'Settings', nl: 'Instellingen' },
  { route: '#/progress', en: 'Progress & Pip', nl: 'Voortgang & Pip' },
];

const MOODS: PipMood[] = ['happy', 'calm', 'cheer', 'thinking', 'surprised', 'wink', 'sleepy', 'sad'];

export function DesignStudioPage() {
  const app = useApp();
  const nl = app.lang === 'nl';
  const [look, setLook] = useSetting<any>('me', 'appearance');
  const [tab, setTab] = useState<'directions' | 'compare' | 'specimen' | 'pip'>('directions');
  const [mode, setMode] = useState<'light' | 'dark'>(() => (document.documentElement.dataset.mode === 'dark' ? 'dark' : 'light'));
  const name = (id: string) => { const s = STYLES.find((x) => x.id === id)!; return nl ? s.name[1] : s.name[0]; };
  const tabs: [typeof tab, string][] = [['directions', nl ? 'Richtingen' : 'Directions'], ['compare', nl ? 'Vergelijken' : 'Compare'], ['specimen', nl ? 'Proefblad' : 'Specimen'], ['pip', 'Pip']];
  return (
    <>
      <div className="topbar">
        <a className="icon-btn ghost" href="#/settings/general" aria-label={nl ? 'Terug' : 'Back'}><ChevronLeft /></a>
        <div className="grow">
          <h1>{nl ? 'Ontwerpstudio' : 'Design studio'}</h1>
          <div className="sub">{nl ? 'Negen richtingen voor PantryPip, op je eigen gegevens' : 'Nine directions for PantryPip, on your own data'}</div>
        </div>
      </div>
      <div className="dz-bar">
        <div className="seg dz-tabs" role="tablist">
          {tabs.map(([id, label]) => <button key={id} role="tab" aria-selected={tab === id} className={tab === id ? 'on' : ''} onClick={() => setTab(id)}>{label}</button>)}
        </div>
        <div className="seg dz-mode" role="radiogroup" aria-label={nl ? 'Licht of donker' : 'Light or dark'}>
          {(['light', 'dark'] as const).map((m) => <button key={m} role="radio" aria-checked={mode === m} className={mode === m ? 'on' : ''} onClick={() => setMode(m)}>{m === 'light' ? (nl ? 'Licht' : 'Light') : (nl ? 'Donker' : 'Dark')}</button>)}
        </div>
      </div>
      <p className="muted small dz-now">
        {nl ? 'Nu in gebruik: ' : 'In use now: '}<b>{name(look.style ?? DEFAULT_STYLE)}</b>
        {look.style !== 'larder' && <> · <button className="link-btn" onClick={() => setLook({ style: 'larder' })}>{nl ? 'terug naar Klassiek' : 'back to Classic'}</button></>}
      </p>
      {tab === 'directions' && <Directions mode={mode} nl={nl} current={look.style} use={(id) => setLook({ style: id })} name={name} onCompare={() => setTab('compare')} />}
      {tab === 'compare' && <Compare mode={mode} nl={nl} name={name} />}
      {tab === 'specimen' && <Specimens mode={mode} nl={nl} name={name} />}
      {tab === 'pip' && <PipSheet mode={mode} nl={nl} />}
    </>
  );
}

function Directions({ mode, nl, current, use, name, onCompare }: { mode: string; nl: boolean; current?: string; use: (id: Direction) => void; name: (id: string) => string; onCompare: () => void }) {
  return (
    <div className="dz-dirs">
      {DIRECTIONS.map((id, i) => {
        const s = STYLES.find((x) => x.id === id)!;
        return (
          <section key={id} className="dz-frame dz-dir" data-direction={id} data-mode={mode}>
            <div className="dz-dir-head">
              <span className="dz-no">{String(i + 1).padStart(2, '0')}</span>
              <span className="row" style={{ gap: 10 }}><Pip size={44} mood={i % 3 === 0 ? 'happy' : i % 3 === 1 ? 'calm' : 'wink'} /><img src={logoDataUrl(logoFor(id))} alt="" width={52} height={52} /></span>
            </div>
            <h2 className="dz-dir-name">{name(id)}</h2>
            <p className="dz-dir-desc">{nl ? s.desc[1] : s.desc[0]}</p>
            <p className="dz-dir-fonts">{s.fonts}</p>
            <div className="dz-swatches" aria-hidden><i style={{ background: 'var(--bg)' }} /><i style={{ background: 'var(--surface)' }} /><i style={{ background: 'var(--ink)' }} /><i style={{ background: 'var(--herb)' }} /><i style={{ background: 'var(--tomato)' }} /><i style={{ background: 'var(--saffron)' }} /></div>
            <div className="row wrap" style={{ gap: 8 }}>
              <button className="btn primary sm" onClick={() => use(id)} aria-pressed={current === id}>{current === id ? <><Check size={16} /> {nl ? 'In gebruik' : 'In use'}</> : nl ? 'Gebruiken' : 'Use'}</button>
              <button className="btn sm" onClick={onCompare}>{nl ? 'Vergelijken' : 'Compare'}</button>
            </div>
          </section>
        );
      })}
    </div>
  );
}

function Compare({ mode, nl, name }: { mode: string; nl: boolean; name: (id: string) => string }) {
  const [screen, setScreen] = useState(SCREENS[0].route);
  const [device, setDevice] = useState<'phone' | 'desktop'>('phone');
  const [picked, setPicked] = useState<Direction[]>(DIRECTIONS);
  const recipes = useQuery<any[]>(screen === 'recipe' ? '/api/recipes/cook-now' : null, ['recipes']);
  const route = screen === 'recipe' ? (recipes.data?.[0] ? `#/recipe/${recipes.data[0].id}` : null) : screen;
  const toggle = (id: Direction) => setPicked((p) => (p.includes(id) ? p.filter((x) => x !== id) : DIRECTIONS.filter((x) => x === id || p.includes(x))));
  return (
    <>
      <div className="dz-controls">
        <div className="chips" role="radiogroup" aria-label={nl ? 'Scherm' : 'Screen'}>
          {SCREENS.map((s) => <button key={s.route} className={`chip ${screen === s.route ? 'on' : ''}`} aria-pressed={screen === s.route} onClick={() => setScreen(s.route)}>{nl ? s.nl : s.en}</button>)}
        </div>
        <div className="row wrap" style={{ gap: 10 }}>
          <div className="seg" role="radiogroup" aria-label={nl ? 'Apparaat' : 'Device'} style={{ minWidth: 200 }}>
            <button className={device === 'phone' ? 'on' : ''} aria-checked={device === 'phone'} role="radio" onClick={() => setDevice('phone')}>{nl ? 'Telefoon 375' : 'Phone 375'}</button>
            <button className={device === 'desktop' ? 'on' : ''} aria-checked={device === 'desktop'} role="radio" onClick={() => setDevice('desktop')}>{nl ? 'Computer 1280' : 'Desktop 1280'}</button>
          </div>
        </div>
        <div className="chips" aria-label={nl ? 'Richtingen' : 'Directions'}>
          {DIRECTIONS.map((id) => <button key={id} className={`chip ${picked.includes(id) ? 'on' : ''}`} aria-pressed={picked.includes(id)} onClick={() => toggle(id)}>{name(id)}</button>)}
        </div>
        <p className="muted tiny">{nl ? 'Elk venster is de echte app met jouw gegevens. Wat je daarin doet, gebeurt echt; de stijl geldt alleen voor dat venster.' : 'Each frame is the real app with your data. What you do in it really happens; the style applies to that frame only.'}</p>
      </div>
      {!route ? <div className="skeleton" style={{ height: 300 }} /> : (
        <div className={`dz-compare ${device}`}>
          {picked.map((id) => (
            <figure key={`${id}-${mode}`} className="dz-shot">
              <Viewport width={device === 'phone' ? 375 : 1280} height={device === 'phone' ? 760 : 800} title={name(id)} src={`/?dz=${id}&dzmode=${mode}${route}`} />
              <figcaption>{name(id)}</figcaption>
            </figure>
          ))}
        </div>
      )}
    </>
  );
}

/** The app at its real size (375 or 1280 wide), scaled down to fit the column. */
function Viewport({ width, height, title, src }: { width: number; height: number; title: string; src: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(0.5);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setScale(el.clientWidth / width));
    ro.observe(el);
    return () => ro.disconnect();
  }, [width]);
  return (
    <div className="dz-viewport" ref={ref} style={{ aspectRatio: `${width} / ${height}` }}>
      <iframe title={title} src={src} loading="lazy" style={{ width, height, transform: `scale(${scale})` }} />
    </div>
  );
}

function Specimens({ mode, nl, name }: { mode: string; nl: boolean; name: (id: string) => string }) {
  const [one, setOne] = useState<Direction | 'all'>('all');
  const list = one === 'all' ? DIRECTIONS : [one];
  return (
    <>
      <div className="chips" style={{ marginBottom: 12 }}>
        <button className={`chip ${one === 'all' ? 'on' : ''}`} aria-pressed={one === 'all'} onClick={() => setOne('all')}>{nl ? 'Alle' : 'All'}</button>
        {DIRECTIONS.map((id) => <button key={id} className={`chip ${one === id ? 'on' : ''}`} aria-pressed={one === id} onClick={() => setOne(id)}>{name(id)}</button>)}
      </div>
      <div className={`dz-specimens ${one === 'all' ? '' : 'single'}`}>
        {list.map((id) => <Specimen key={id} id={id} mode={mode} nl={nl} name={name(id)} />)}
      </div>
    </>
  );
}

function Specimen({ id, mode, nl, name }: { id: Direction; mode: string; nl: boolean; name: string }) {
  const t = TYPE[id];
  const [checked, setChecked] = useState<number[]>([1]);
  const [chip, setChip] = useState(0);
  const [on, setOn] = useState(true);
  const items = useMemo(() => [
    { e: '🥛', title: nl ? 'Havermelk' : 'Oat milk', meta: nl ? 'Voor de pannenkoeken van zaterdag' : 'For Saturday’s pancakes', q: '2 l' },
    { e: '🍅', title: nl ? 'Trostomaten' : 'Vine tomatoes', meta: nl ? 'Bijna op' : 'Running low', q: '500 g' },
    { e: '🧀', title: 'Parmigiano', meta: nl ? 'Risotto · do' : 'Risotto · Thu', q: '€4.20' },
  ], [nl]);
  return (
    <article className="dz-frame dz-specimen" data-direction={id} data-mode={mode} aria-label={name}>
      <div className="dz-sheet-in">
        <header className="dz-spec-head">
          <span className="dz-brand">pantrypip</span>
          <span className="pill grey">{name}</span>
        </header>

        <div className="dz-ramp">
          <div className="dz-role"><span>Display · {t.display}</span><div className="dz-display">{nl ? 'Wat eten we vanavond?' : 'What’s for dinner tonight?'}</div></div>
          <div className="dz-role"><span>Heading · {t.heading}</span><div className="section-head" style={{ margin: 0 }}><h2>{nl ? 'Deze week' : 'This week'}</h2><a className="link">{nl ? 'Alles' : 'See all'}</a></div></div>
          <div className="dz-role"><span>Body · {t.body}</span><p style={{ margin: 0 }}>{nl ? 'Pip houdt bij wat er in huis is en schrijft de boodschappenlijst voor je, zodat je minder weggooit.' : 'Pip keeps track of what you have and writes the shopping list for you, so less food goes to waste.'}</p></div>
          <div className="dz-role"><span>Data · {t.data}</span><div className="dz-data num">250 g · 4 {nl ? 'pers' : 'servings'} · 35 min · €3.40</div></div>
          <div className="dz-role"><span>Label · {t.label}</span><div className="set-title" style={{ margin: 0 }}>{nl ? 'Voorraadkast' : 'Pantry shelf'}</div></div>
        </div>

        <div className="section-head"><h2>{nl ? 'Boodschappen' : 'Shopping list'}</h2><span className="pill herb">3</span></div>
        <div className="list">
          {items.map((x, i) => (
            <div key={i} className={`shop-item ${checked.includes(i) ? 'done' : ''}`}>
              <button className={`check ${checked.includes(i) ? 'on' : ''}`} aria-label={x.title} aria-pressed={checked.includes(i)} onClick={() => setChecked((c) => (c.includes(i) ? c.filter((y) => y !== i) : [...c, i]))}><Check /></button>
              <span className="thumb" aria-hidden style={{ width: 36, height: 36, display: 'grid', placeItems: 'center', flex: 'none' }}>{x.e}</span>
              <div className="grow"><div className="title">{x.title}</div><div className="why-tag">{x.meta}</div></div>
              <span className="num" style={{ fontWeight: 700 }}>{x.q}</span>
            </div>
          ))}
        </div>

        <div className="section-head"><h2>{nl ? 'Recepten' : 'Recipes'}</h2></div>
        <div className="dz-two">
          <div className="recipe-card">
            <Plate color="#D9A441" emoji="🍝"><span className="match">92%</span></Plate>
            <div className="body">
              <h3>{nl ? 'Pasta met geroosterde tomaat' : 'Pasta with roast tomatoes'}</h3>
              <div className="facts"><span><Clock /> 25 min</span><span><Users /> 4</span></div>
              <div className="why">{nl ? 'Je hebt 7 van de 8' : 'You have 7 of 8'}</div>
            </div>
          </div>
          <div className="day today">
            <div className="day-head"><b>{nl ? 'Donderdag' : 'Thursday'}</b><span>{nl ? 'vandaag' : 'today'}</span></div>
            <div className="meal"><span className="em" style={{ background: 'var(--saffron-soft)' }}>🍲</span><div className="grow"><div className="mt">{nl ? 'Linzensoep' : 'Lentil soup'}</div><div className="ms">30 min</div></div></div>
            <button className="add-meal"><Plus size={14} /> {nl ? 'Maaltijd' : 'Meal'}</button>
          </div>
        </div>

        <div className="section-head"><h2>{nl ? 'Knoppen en keuzes' : 'Controls'}</h2></div>
        <div className="row wrap" style={{ gap: 8 }}>
          <button className="btn primary">{nl ? 'Op de lijst' : 'Add to list'}</button>
          <button className="btn">{nl ? 'Plannen' : 'Plan'}</button>
          <button className="btn soft">{nl ? 'Koken' : 'Cook'}</button>
          <button className="btn ghost">{nl ? 'Niet nu' : 'Not now'}</button>
        </div>
        <div className="row wrap" style={{ gap: 8, marginTop: 10 }}>
          {[nl ? 'Alles' : 'All', nl ? 'Vega' : 'Veggie', nl ? 'Snel' : 'Quick'].map((c, i) => <button key={c} className={`chip ${chip === i ? 'on' : ''}`} aria-pressed={chip === i} onClick={() => setChip(i)}>{c}</button>)}
          <span className="pill tomato">{nl ? 'Op' : 'Out'}</span><span className="pill saffron">{nl ? 'Bijna op' : 'Low'}</span><span className="pill herb">{nl ? 'Vers' : 'Fresh'}</span>
        </div>
        <div className="row" style={{ gap: 10, marginTop: 10 }}>
          <div className="search grow"><Search /><input className="input" placeholder={nl ? 'Zoek een product' : 'Find a product'} aria-label={nl ? 'Zoek' : 'Search'} /></div>
          <button className="switch" role="switch" aria-checked={on} aria-label={nl ? 'Schakelaar' : 'Switch'} onClick={() => setOn(!on)} />
        </div>

        <div className="section-head"><h2>{nl ? 'Venster, leeg en laden' : 'Dialog, empty, loading'}</h2></div>
        <div className="dz-two">
          <div className="sheet dz-static" role="group" aria-label={nl ? 'Voorbeeldvenster' : 'Sample dialog'}>
            <header><h2>{nl ? 'Hoeveel is er nog?' : 'How much is left?'}</h2></header>
            <div className="content"><p className="small muted" style={{ marginTop: 0 }}>{nl ? 'Havermelk, geopend op maandag' : 'Oat milk, opened on Monday'}</p>
              <div className="seg"><button>{nl ? 'Op' : 'None'}</button><button className="on">{nl ? 'Half' : 'Half'}</button><button>{nl ? 'Vol' : 'Full'}</button></div>
            </div>
            <footer><button className="btn ghost grow">{nl ? 'Annuleren' : 'Cancel'}</button><button className="btn primary grow">{nl ? 'Bewaren' : 'Save'}</button></footer>
          </div>
          <div className="card">
            <Empty art="🧺" title={nl ? 'Alles is binnen' : 'Nothing left to buy'}><p className="small" style={{ margin: 0 }}>{nl ? 'Pip zet er vanzelf iets op als het opraakt.' : 'Pip adds things here when they run low.'}</p></Empty>
          </div>
        </div>
        <div className="row" style={{ gap: 10, marginTop: 12, alignItems: 'center' }}>
          <Pip size={34} mood="thinking" className="wait" label={nl ? 'Laden' : 'Loading'} />
          <div className="grow stack" style={{ gap: 6 }}><div className="skeleton" style={{ height: 14, width: '70%' }} /><div className="skeleton" style={{ height: 14, width: '45%' }} /></div>
        </div>
        <div className="toast dz-static-toast"><span className="grow">{nl ? 'Melk van de lijst gehaald' : 'Milk taken off the list'}</span><button>{nl ? 'Ongedaan maken' : 'Undo'}</button></div>
      </div>
    </article>
  );
}

function PipSheet({ mode, nl }: { mode: string; nl: boolean }) {
  return (
    <div className="dz-pip">
      <div className="card pad">
        <h2 className="dz-h">{nl ? 'Eén Pip voor elke stijl' : 'One Pip for every style'}</h2>
        <p className="small muted" style={{ marginTop: 0 }}>{nl ? 'Pip is de eerste p van het woordmerk: een ronde kom op een steel, getekend met één lijn met ronde uiteinden, het blaadje van de i bovenop en het koraalrode stipje van de tweede p als wang. De lijn volgt de tekstkleur; alleen het blaadje kleurt mee met wat je vrijspeelt.' : 'Pip is the first p of the wordmark: a round bowl on a stem, drawn with one round-ended line, the leaf from the i on top and the coral dot from the second p as a cheek. The line follows the text colour; only the leaf takes the colour you unlock.'}</p>
        <div className="dz-moods">
          {MOODS.map((m) => <figure key={m}><Pip size={72} mood={m} /><figcaption>{m}</figcaption></figure>)}
        </div>
      </div>
      <div className="card pad">
        <h2 className="dz-h">{nl ? 'Wat Pip verdient' : 'What Pip earns'}</h2>
        <div className="dz-moods">
          <figure><Pip size={64} /><figcaption>{nl ? 'start' : 'start'}</figcaption></figure>
          <figure><Pip size={64} stages={['apron']} skin="tomato" /><figcaption>{nl ? 'schort' : 'apron'}</figcaption></figure>
          <figure><Pip size={64} stages={['apron', 'hat']} /><figcaption>{nl ? 'koksmuts' : 'chef’s hat'}</figcaption></figure>
          <figure><Pip size={64} stages={['apron', 'hat', 'scarf']} mood="cheer" /><figcaption>{nl ? 'sjaal' : 'scarf'}</figcaption></figure>
          <figure><Pip size={64} stages={['heart']} skin="blueberry" mood="wink" /><figcaption>{nl ? 'vriendschap' : 'friendship'}</figcaption></figure>
        </div>
      </div>
      <div className="dz-pip-dirs">
        {DIRECTIONS.map((id) => (
          <div key={id} className="dz-frame dz-pip-dir" data-direction={id} data-mode={mode}>
            <Pip size={56} mood="happy" />
            <Pip size={32} mood="calm" />
            <Pip size={20} mood="happy" />
          </div>
        ))}
      </div>
      <div className="card pad small">
        <h2 className="dz-h">{nl ? 'Regels' : 'Rules'}</h2>
        <ul className="dz-rules">
          <li>{nl ? 'Pip verschijnt bij lege lijsten, laden, voortgang en beloningen; nooit naast foutmeldingen of als versiering op elke kaart.' : 'Pip appears in empty states, loading, progress and rewards; never next to errors, and never as decoration on every card.'}</li>
          <li>{nl ? 'Eén Pip per scherm. Minimaal 20 px; de lijn wordt dan iets dikker zodat hij scherp blijft.' : 'One Pip per screen. At least 20 px; the line gets slightly heavier when small so it stays crisp.'}</li>
          <li>{nl ? 'Bewegingen zijn klein en zeldzaam (knipperen, blaadje, nadenken) en stoppen bij Animaties: rustig of uit.' : 'Movements are small and rare (blink, leaf, thinking) and stop with Animations: reduced or off.'}</li>
          <li>{nl ? 'Geen armen, geen tekstballonnen, geen kindergezichtjes: Pip is een letter met een gezicht.' : 'No arms, no speech bubbles, no baby faces: Pip is a letter with a face.'}</li>
        </ul>
      </div>
    </div>
  );
}
