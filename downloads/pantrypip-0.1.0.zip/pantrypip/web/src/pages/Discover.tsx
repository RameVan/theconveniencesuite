import { useState } from 'react';
import { Search, Sparkles, SlidersHorizontal, Plus } from 'lucide-react';
import { post, useQuery, useDebounced, invalidate } from '../api';
import { useApp } from '../app-context';
import { useT } from '../i18n';
import { AddRecipeSheet } from '../components/AddRecipe';
import { Empty, useToast } from '../components/ui';
import { RecipeCard } from '../components/cards';

const CUISINES = ['Italian', 'Dutch', 'Thai', 'Indian', 'Mexican', 'Chinese', 'Greek', 'Middle Eastern', 'Nordic', 'Mediterranean'];
const DIETS = ['vegetarian', 'vegan', 'pescatarian', 'gluten-free', 'dairy-free', 'low-carb', 'halal', 'no-pork'];

const PAGE = 40;

export function DiscoverPage() {
  const app = useApp();
  const t = useT();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const [tab, setTab] = useState<'cook' | 'explore' | 'mine'>('cook');
  const [adding, setAdding] = useState(false);
  const [mineFilter, setMineFilter] = useState<'all' | 'fav' | 'try' | 'own'>('all');
  const [ask, setAsk] = useState('');
  const [asked, setAsked] = useState('');
  const [cuisine, setCuisine] = useState<string | null>(null);
  // Pick several diets to see more recipes: anything that fits one of them.
  const [diets, setDiets] = useState<string[]>([]);
  const [maxMinutes, setMaxMinutes] = useState<number | null>(null);
  const [protein, setProtein] = useState(false);
  const [budget, setBudget] = useState(false);
  const [saved, setSaved] = useState(false);
  const [sort, setSort] = useState('best');
  const [generating, setGenerating] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const active = (cuisine ? 1 : 0) + diets.length + (maxMinutes ? 1 : 0) + (protein ? 1 : 0) + (budget ? 1 : 0) + (saved ? 1 : 0) + (sort !== 'best' ? 1 : 0);
  const dq = useDebounced(ask, 250);

  const params = new URLSearchParams();
  if (dq && !asked) params.set('q', dq);
  if (cuisine) params.set('cuisine', cuisine);
  if (diets.length) params.set('diet', diets.join(','));
  if (maxMinutes) params.set('maxMinutes', String(maxMinutes));
  if (protein) params.set('minProtein', '25');
  if (budget) params.set('maxCost', '2.5');
  if (saved) params.set('saved', '1');
  params.set('sort', sort);
  // The library is large: show a page at a time, starting again whenever the filters change.
  const filterKey = params.toString();
  const [shown, setShown] = useState({ key: filterKey, n: PAGE });
  const limit = shown.key === filterKey ? shown.n : PAGE;
  params.set('limit', String(limit + 1));
  const cookNow = useQuery<any[]>(tab === 'cook' && !asked ? '/api/recipes/cook-now' : null, ['recipes', 'inventory']);
  const explore = useQuery<any[]>(tab === 'explore' && !asked ? `/api/recipes?${params}` : null, ['recipes', 'inventory']);
  const askRes = useQuery<any[]>(asked ? `/api/recipes/ask?q=${encodeURIComponent(asked)}` : null, ['recipes']);
  const mine = useQuery<any[]>(tab === 'mine' && !asked ? '/api/recipes/mine' : null, ['recipes', 'inventory']);
  const mineList = mine.data?.filter((r: any) => mineFilter === 'all' || (mineFilter === 'fav' ? r.saved || r.priority === 2 || r.rating >= 4 : mineFilter === 'try' ? r.toTry : !!r.household_id));
  const more = !asked && tab === 'explore' && (explore.data?.length ?? 0) > limit;
  const list = asked ? askRes.data : tab === 'cook' ? cookNow.data : tab === 'mine' ? mineList : explore.data?.slice(0, limit);

  // A use-it-up recipe built from the food at most risk (rule-based, no AI).
  const [making, setMaking] = useState(false);
  const fromStock = async () => {
    setMaking(true);
    try {
      const r = await post('/api/recipes/from-stock', { lang: app.lang });
      invalidate(['recipes']);
      app.navigate(`#/recipe/${r.recipe.id}`);
    } catch (e: any) {
      toast({ text: e.message, error: true });
    } finally {
      setMaking(false);
    }
  };
  const generate = async () => {
    setGenerating(true);
    try {
      const r = await post('/api/recipes/generate', { prompt: ask || (nl ? 'Iets lekkers met wat ik in huis heb' : 'Something tasty with what I have'), lang: app.lang });
      invalidate(['recipes']);
      app.navigate(`#/recipe/${r.recipe.id}`);
    } catch (e: any) {
      toast({ text: e.message, error: true });
    } finally {
      setGenerating(false);
    }
  };

  const toggle = <T,>(v: T, cur: T | null, set: (x: T | null) => void) => set(cur === v ? null : v);

  return (
    <>
      <div className="topbar">
        <div className="grow"><h1>{nl ? 'Recepten' : 'Recipes'}</h1></div>
        <button className="icon-btn" onClick={() => setAdding(true)} aria-label={nl ? 'Recept toevoegen' : 'Add a recipe'}><Plus /></button>
      </div>
      <form className="row" onSubmit={(e) => { e.preventDefault(); setAsked(ask.trim()); }}>
        <div className="search grow">
          <Search />
          <input className="input" value={ask} onChange={(e) => { setAsk(e.target.value); if (!e.target.value) setAsked(''); }} placeholder={nl ? '“Iets eiwitrijks onder 20 minuten”' : '“High-protein dinner under 20 minutes”'} aria-label={t('Find recipes')} enterKeyHint="search" />
        </div>
        {app.config?.ai && (
          <button type="button" className="btn" style={{ color: 'var(--plum)' }} onClick={generate} disabled={generating}>
            <Sparkles size={17} /> <span className="hide-sm">{generating ? '…' : t('Generate with AI')}</span>
          </button>
        )}
      </form>
      {asked && <div className="row small" style={{ margin: '10px 0' }}><span className="grow muted">{nl ? 'Resultaten voor' : 'Results for'} “{asked}”</span><button className="btn ghost sm" onClick={() => { setAsked(''); setAsk(''); }}>{nl ? 'Wissen' : 'Clear'}</button></div>}
      {!asked && (
        <>
          <div className="loc-tabs" style={{ marginTop: 12 }}>
            <button aria-pressed={tab === 'cook'} onClick={() => setTab('cook')}>{nl ? 'Voor jou' : 'For you'}</button>
            <button aria-pressed={tab === 'explore'} onClick={() => setTab('explore')}>{nl ? 'Alle' : 'All'}</button>
            <button aria-pressed={tab === 'mine'} onClick={() => setTab('mine')}>{nl ? 'Bewaard' : 'Saved'}</button>
          </div>
          {tab === 'mine' && (
            <div className="chips" style={{ marginBottom: 6 }}>
              {([['all', 'All', 'Alles'], ['fav', '♥ Favourites', '♥ Favorieten'], ['try', '🔖 To try', '🔖 Proberen'], ['own', 'Added by me', 'Zelf toegevoegd']] as const).map(([k, en, nlL]) => (
                <button key={k} className="chip" aria-pressed={mineFilter === k} onClick={() => setMineFilter(k)}>{nl ? nlL : en}</button>
              ))}
            </div>
          )}
          {tab === 'explore' && (
            <button className={`btn sm ${active ? 'soft' : 'ghost'}`} onClick={() => setShowFilters((f) => !f)} aria-expanded={showFilters} style={{ marginBottom: 6 }}><SlidersHorizontal size={15} /> {nl ? 'Filters' : 'Filters'}{active ? ` (${active})` : ''}</button>
          )}
          {tab === 'explore' && showFilters && (
            <div className="stack" style={{ gap: 8 }}>
              <div className="chips">
                {[20, 30, 45].map((m) => <button key={m} className="chip" aria-pressed={maxMinutes === m} onClick={() => toggle(m, maxMinutes, setMaxMinutes)}>≤ {m} min</button>)}
                <button className="chip" aria-pressed={protein} onClick={() => setProtein(!protein)}>💪 {nl ? 'Eiwitrijk' : 'High protein'}</button>
                <button className="chip" aria-pressed={budget} onClick={() => setBudget(!budget)}>€ {nl ? 'Budget' : 'Budget'}</button>
                <button className="chip" aria-pressed={saved} onClick={() => setSaved(!saved)}>♥ {t('Saved')}</button>
                {DIETS.map((d) => <button key={d} className="chip" aria-pressed={diets.includes(d)} onClick={() => setDiets((all) => (all.includes(d) ? all.filter((x) => x !== d) : [...all, d]))}>{d}</button>)}
              </div>
              <div className="chips">
                {CUISINES.map((c) => <button key={c} className="chip" aria-pressed={cuisine === c} onClick={() => toggle(c, cuisine, setCuisine)}>{c}</button>)}
              </div>
              <div className="row small"><span className="muted">{nl ? 'Sorteer' : 'Sort'}</span>
                <select className="select" style={{ width: 'auto', minHeight: 36 }} value={sort} onChange={(e) => setSort(e.target.value)}>
                  <option value="best">{nl ? 'Beste match voor jou' : 'Best for you'}</option>
                  <option value="match">{nl ? 'Meeste in huis' : 'Most in stock'}</option>
                  <option value="time">{nl ? 'Snelst' : 'Quickest'}</option>
                  <option value="protein">{nl ? 'Meeste eiwit' : 'Most protein'}</option>
                  <option value="cost">{nl ? 'Goedkoopst' : 'Cheapest'}</option>
                </select>
              </div>
            </div>
          )}
          {tab === 'cook' && <p className="small muted" style={{ margin: '0 0 6px' }}>{nl ? 'Met wat je in huis hebt; wat eerst op moet gaat voor.' : 'From what you have; what needs using comes first.'}</p>}
          {tab === 'cook' && !asked && (
            <button className="btn sm soft" style={{ marginBottom: 8 }} disabled={making} onClick={fromStock}>
              🥘 {making ? '…' : nl ? 'Maak een recept van wat ik heb' : 'Make a recipe from what I have'}
            </button>
          )}
        </>
      )}
      {!list && <div className="grid-cards" style={{ marginTop: 12 }}>{[1, 2, 3].map((i) => <div key={i} className="skeleton" style={{ height: 250 }} />)}</div>}
      {adding && <AddRecipeSheet onClose={() => setAdding(false)} />}
      {list && !list.length && tab === 'mine' && !asked ? (
        <Empty art="📖" title={nl ? 'Nog geen eigen recepten' : 'No recipes of your own yet'}>
          <p className="small">{nl ? 'Plak een link van een receptensite, of tik op ♥ bij een recept.' : 'Paste a link from any recipe site, or tap ♥ on a recipe.'}</p>
          <button className="btn primary" onClick={() => setAdding(true)}><Plus size={16} /> {nl ? 'Recept toevoegen' : 'Add recipe'}</button>
        </Empty>
      ) : list && !list.length && (
        <Empty art="🍳" title={nl ? 'Geen recepten gevonden' : 'No recipes found'}>
          <p className="small">{nl ? 'Probeer minder filters' : 'Try fewer filters'}{app.config?.ai ? (nl ? ', of laat AI er een bedenken.' : ', or let AI create one.') : '.'}</p>
          {app.config?.ai && <button className="btn" onClick={generate}><Sparkles size={16} /> {t('Generate with AI')}</button>}
        </Empty>
      )}
      <div className="grid-cards" style={{ marginTop: 12 }}>{list?.map((r) => <RecipeCard key={r.id} r={r} />)}</div>
      {more && <button className="btn block" style={{ marginTop: 12 }} onClick={() => setShown({ key: filterKey, n: limit + PAGE })}>{nl ? 'Meer recepten' : 'Show more recipes'}</button>}
    </>
  );
}
