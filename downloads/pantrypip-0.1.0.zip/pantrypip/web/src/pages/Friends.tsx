// Friends and the leaderboard. In Progress it's a tab (leaderboard, friends' progress); in Settings → Friends
// (the only place in minimalist mode) you can still invite, accept and remove. Friends are added by code,
// link or phone contacts, never by email, and only see progress numbers.
import { useEffect, useState } from 'react';
import { Copy, Share2, RefreshCw, UserPlus, Check, X, ChevronDown, Lock, BookUser, MessageSquare, Phone } from 'lucide-react';
import { useQuery, post, put, del, invalidate } from '../api';
import { useApp } from '../app-context';
import { useToast, Sheet } from '../components/ui';
import { Pip } from '../components/Pip';
import { useSetting } from '../settings';
import { Inbox, Duels, LeagueHead, EventCard, Together, RecapCard, FriendActions, NudgeToggle } from './FriendsPlay';

type Period = 'week' | 'league' | 'all';
const SCOPES = ['friends', 'game', 'recipes', 'planner'];
export const friendLink = (code: string) => `${location.origin}/#/friends?friend=${code}`;
/** A code from a link opened in the app (#/friends?friend=CODE). */
export const codeFromHash = () => location.hash.match(/[?&]friend=([A-Za-z0-9-]+)/)?.[1] ?? null;
const pretty = (code: string) => `${code.slice(0, 4)}-${code.slice(4)}`;
/** Typed into the add box: a phone number rather than a code? */
const looksLikePhone = (s: string) => /^[+0(]/.test(s.trim()) && s.replace(/\D/g, '').length >= 8;
const inviteText = (nl: boolean, code: string) => `${nl ? 'Kook je mee? Word mijn vriend op PantryPip en zie wie de langste kookreeks heeft:' : 'Cook along? Be my friend on PantryPip and see who keeps the longest cooking streak:'} ${friendLink(code)}`;
/** An SMS with your invite link (works on iOS and Android). */
const smsHref = (tel: string, body: string) => `sms:${tel.replace(/[^\d+]/g, '')}?&body=${encodeURIComponent(body)}`;
const contactsSupported = () => typeof navigator !== 'undefined' && 'contacts' in navigator && 'ContactsManager' in window;

/** Shared actions plus the minimalist-mode note on every success. */
function useFriendActions() {
  const app = useApp();
  const nl = app.lang === 'nl';
  const toast = useToast();
  const [look] = useSetting<any>('me', 'appearance');
  const minimal = !!look?.minimal;
  const [busy, setBusy] = useState(false);
  const hidden = nl ? ' Minimalistische modus verbergt Voortgang, dus je ziet hun reeks en de ranglijst pas als je die uitzet.' : ' Minimalist mode hides Progress, so you won’t see their streak or the leaderboard until you switch it off.';
  const done = (text: string, friendsNow: boolean) => toast({ text: minimal && friendsNow ? text + hidden : text, ms: minimal && friendsNow ? 7000 : undefined });
  const act = async <T,>(fn: () => Promise<T>, ok?: (r: T) => [string, boolean] | void) => {
    setBusy(true);
    try {
      const r = await fn();
      invalidate(['friends']);
      const m = ok?.(r);
      if (m) done(m[0], m[1]);
      return r;
    } catch (e: any) {
      toast({ text: errorText(e, nl), error: true });
    } finally {
      setBusy(false);
    }
  };
  const requested = (r: { state: string; name: string }): [string, boolean] =>
    r.state === 'friends' ? [nl ? `Je bent nu vrienden met ${r.name}.` : `You and ${r.name} are now friends.`, true] : [nl ? `Verzoek gestuurd naar ${r.name}. Zodra die accepteert, zijn jullie vrienden.` : `Request sent to ${r.name}. You’ll be friends once they accept.`, true];
  return { nl, minimal, busy, act, requested, toast };
}

/** Progress → Friends: requests, leaderboard, friends' progress, and adding friends. */
export function FriendsTab() {
  const { data } = useQuery<any>('/api/friends', SCOPES);
  const app = useApp();
  const nl = app.lang === 'nl';
  const [period, setPeriod] = useState<Period>('week');
  const [open, setOpen] = useState<string | null>(null);
  const { busy, act } = useFriendActions();
  if (!data) return <div className="stack" style={{ marginTop: 12 }}><div className="skeleton" style={{ height: 220 }} /><div className="skeleton" style={{ height: 120 }} /></div>;
  const board = data.leaderboard[period];
  const leagueEmoji = (n: number | null) => (n == null ? '' : data.social.league.all[n]?.emoji ?? '');

  return (
    <div className="friends">
      <Inbox data={data} />
      <Requests data={data} />
      <Duels data={data} />
      <div className="section-head"><h2>{nl ? 'Ranglijst' : 'Leaderboard'}</h2><span className="tiny muted">{nl ? 'op XP' : 'by XP'}</span></div>
      <div className="seg mini lb-seg" role="tablist" aria-label={nl ? 'Periode' : 'Period'}>
        <button role="tab" aria-selected={period === 'week'} className={period === 'week' ? 'on' : ''} onClick={() => setPeriod('week')}>{nl ? 'Deze week' : 'This week'}</button>
        <button role="tab" aria-selected={period === 'league'} className={period === 'league' ? 'on' : ''} onClick={() => setPeriod('league')}>{data.social.league.emoji} League</button>
        <button role="tab" aria-selected={period === 'all'} className={period === 'all' ? 'on' : ''} onClick={() => setPeriod('all')}>{nl ? 'Altijd' : 'All time'}</button>
      </div>
      {period === 'league' && <LeagueHead data={data} />}
      <ol className="list lb">
        {board.map((p: any) => (
          <li key={p.id} className={`item lb-row ${p.me ? 'me' : ''}`}>
            <span className={`lb-rank r${p.rank}`}>{p.rank}</span>
            <Pip skin={p.skin} size={34} />
            <div className="grow" style={{ minWidth: 0 }}>
              <div className="title ellipsis">{p.name}{p.me && <span className="muted"> · {nl ? 'jij' : 'you'}</span>}</div>
              <div className="meta ellipsis">{leagueEmoji(p.league)} {p.level.emoji} {nl ? p.level.name_nl : p.level.name} · 🔥 {p.streak}</div>
            </div>
            <b className="lb-score num">{p.score}<small>XP</small></b>
          </li>
        ))}
      </ol>
      <p className="tiny muted">
        {period === 'all' ? (nl ? 'Alle XP ooit verdiend.' : 'All XP ever earned.') : period === 'league' ? (nl ? 'Vrienden in jouw league, op XP van deze week. Elke maandag ga je omhoog of omlaag.' : 'Friends in your league, by this week’s XP. Leagues move every Monday.') : nl ? 'XP verdiend sinds maandag: koken, uitdagingen en stappen op je reis.' : 'XP earned since Monday: cooking, quests, challenges and journey steps.'}
        {data.updating > 0 && (nl ? ` Voortgang van ${data.updating} ${data.updating === 1 ? 'vriend' : 'vrienden'} wordt bijgewerkt…` : ` Updating ${data.updating} ${data.updating === 1 ? 'friend' : 'friends'}…`)}
      </p>

      <EventCard data={data} />
      <Together data={data} />
      {data.friends.length > 0 && <RecapCard data={data} />}
      {data.friends.length > 0 && (
        <>
          <div className="section-head"><h2>{nl ? 'Vrienden' : 'Friends'}</h2><span className="tiny muted">{data.friends.length}</span></div>
          <div className="list">
            {data.friends.map((f: any) => <FriendRow key={f.id} f={f} data={data} open={open === f.id} onToggle={() => setOpen(open === f.id ? null : f.id)} onRemove={() => act(() => del(`/api/friends/${f.id}`), () => [nl ? `${f.name} is geen vriend meer` : `Removed ${f.name}`, false])} busy={busy} />)}
          </div>
        </>
      )}
      <div className="section-head"><h2>{nl ? 'Vrienden toevoegen' : 'Add friends'}</h2></div>
      <AddFriends data={data} />
      <div style={{ marginTop: 12 }}><NudgeToggle data={data} /></div>
    </div>
  );
}

/** Settings → Friends: everything except the progress views (so it works in minimalist mode too). */
export function FriendsSettings() {
  const { data } = useQuery<any>('/api/friends', SCOPES);
  const { nl, minimal, busy, act } = useFriendActions();
  const [look, setLook] = useSetting<any>('me', 'appearance');
  if (!data) return <div className="skeleton" style={{ height: 260 }} />;
  return (
    <div className="friends">
      {minimal && (
        <div className="card pad friend-minimal">
          <b>{nl ? 'Je zit in minimalistische modus' : 'You’re in minimalist mode'}</b>
          <p className="small muted" style={{ margin: '4px 0 10px' }}>{nl ? 'Je kunt hier vrienden uitnodigen en accepteren, maar hun kookreeks, prestaties en de ranglijst staan in Voortgang, en die is verborgen.' : 'You can invite and accept friends here, but their cooking streaks, achievements and the leaderboard live in Progress, which is hidden.'}</p>
          <button className="btn soft sm" onClick={() => setLook({ ...look, minimal: false })}>{nl ? 'Minimalistische modus uitzetten' : 'Switch off minimalist mode'}</button>
        </div>
      )}
      <Inbox data={data} />
      <Requests data={data} />
      {!minimal && <a className="stats-link" href="#/friends">🏆 <span className="grow">{nl ? 'Ranglijst en voortgang van vrienden' : 'Leaderboard and friends’ progress'}</span></a>}
      <div className="section-head"><h2>{nl ? 'Vrienden toevoegen' : 'Add friends'}</h2></div>
      <AddFriends data={data} />
      <div style={{ marginTop: 12 }}><NudgeToggle data={data} /></div>
      {data.friends.length > 0 && (
        <>
          <div className="section-head"><h2>{nl ? 'Je vrienden' : 'Your friends'}</h2><span className="tiny muted">{data.friends.length}</span></div>
          <div className="list">
            {data.friends.map((f: any) => (
              <div key={f.id} className="item">
                <Pip skin={f.progress?.skin} size={36} />
                <div className="grow title ellipsis" style={{ minWidth: 0 }}>{f.name}</div>
                <button className="btn ghost sm friend-remove" disabled={busy} onClick={() => confirm(nl ? `${f.name} verwijderen als vriend?` : `Remove ${f.name} as a friend?`) && act(() => del(`/api/friends/${f.id}`), () => [nl ? `${f.name} is geen vriend meer` : `Removed ${f.name}`, false])}>{nl ? 'Verwijder' : 'Remove'}</button>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function Requests({ data }: { data: any }) {
  const { nl, busy, act } = useFriendActions();
  if (!data.incoming.length) return null;
  return (
    <>
      <div className="section-head"><h2>{nl ? 'Vriendschapsverzoeken' : 'Friend requests'}</h2><span className="tiny muted">{data.incoming.length}</span></div>
      <div className="list">
        {data.incoming.map((r: any) => (
          <div key={r.id} className="item">
            <span className="thumb">👋</span>
            <div className="grow" style={{ minWidth: 0 }}>
              <div className="title ellipsis">{r.name}</div>
              <div className="meta">{nl ? 'wil voortgang met je delen' : 'wants to share progress with you'}</div>
            </div>
            <div className="actions">
              <button className="icon-btn sm" disabled={busy} aria-label={nl ? `Weiger ${r.name}` : `Decline ${r.name}`} onClick={() => act(() => del(`/api/friends/requests/${r.id}`))}><X size={16} /></button>
              <button className="btn primary sm" disabled={busy} onClick={() => act(() => post(`/api/friends/requests/${r.id}/accept`), () => [nl ? `Je bent nu vrienden met ${r.name}.` : `You and ${r.name} are now friends.`, true])}><Check size={16} /> {nl ? 'Accepteer' : 'Accept'}</button>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

/** Your code and link, a box for a friend's code, link or phone number, your contacts, and your own number. */
function AddFriends({ data }: { data: any }) {
  const { nl, busy, act, requested, toast } = useFriendActions();
  const [code, setCode] = useState('');
  const [invite, setInvite] = useState<string | null>(null); // a typed number nobody has: offer a text
  const [contacts, setContacts] = useState<null | { name: string; tel: string; match?: any }[]>(null);

  // Opened from a friend's link: fill in their code and clean the address.
  useEffect(() => {
    const c = codeFromHash();
    if (!c) return;
    setCode(c);
    history.replaceState(null, '', location.hash.replace(/[?&]friend=[A-Za-z0-9-]+/, ''));
  }, []);

  const add = async () => {
    setInvite(null);
    if (looksLikePhone(code)) {
      const r = await act(() => post('/api/friends/contacts', { numbers: [code] }));
      if (!r) return;
      const m = (r as any).matches[0];
      if (!m) return setInvite(code);
      if (m.state === 'friends') return toast({ text: nl ? `${m.name} is al je vriend` : `${m.name} is already your friend` });
      await act(() => post('/api/friends/request', { userId: m.userId, match: m.match }), requested);
      setCode('');
      return;
    }
    const r = await act(() => post('/api/friends/request', { code }), requested);
    if (r) setCode('');
  };
  const share = async () => {
    const text = inviteText(nl, data.code);
    if (navigator.share) {
      try {
        await navigator.share({ title: 'PantryPip', text });
        return;
      } catch {
        /* cancelled: fall through to copy */
      }
    }
    navigator.clipboard?.writeText(friendLink(data.code)).then(() => toast({ text: nl ? 'Link gekopieerd' : 'Link copied' }));
  };
  const pickContacts = async () => {
    try {
      const picked: { name?: string[]; tel?: string[] }[] = await (navigator as any).contacts.select(['name', 'tel'], { multiple: true });
      const list = picked.flatMap((c) => (c.tel ?? []).slice(0, 3).map((tel) => ({ name: c.name?.[0] ?? tel, tel })));
      if (!list.length) return;
      const r = await act(() => post('/api/friends/contacts', { numbers: list.map((c) => c.tel).slice(0, 1000) }));
      if (!r) return;
      const byIndex = new Map<number, any>((r as any).matches.map((m: any) => [m.index, m]));
      // One row per person: found ones first.
      const seen = new Set<string>();
      setContacts(list.map((c, i) => ({ ...c, match: byIndex.get(i) })).sort((a, b) => Number(!!b.match) - Number(!!a.match)).filter((c) => {
        const k = c.match?.userId ?? c.name;
        return seen.has(k) ? false : (seen.add(k), true);
      }));
    } catch {
      /* picker closed */
    }
  };

  return (
    <div className="card pad stack friend-add">
      {data.friends.length === 0 && <p className="small" style={{ margin: 0 }}>{nl ? 'Kook samen op afstand: nodig een vriend uit en houd elkaars reeks bij.' : 'Cook together from afar: invite a friend and keep each other’s streaks going.'}</p>}
      <div className="friend-code">
        <div className="grow" style={{ minWidth: 0 }}>
          <div className="tiny muted">{nl ? 'Jouw vriendcode' : 'Your friend code'}</div>
          <b className="num code">{pretty(data.code)}</b>
        </div>
        <button className="icon-btn" aria-label={nl ? 'Kopieer code' : 'Copy code'} onClick={() => navigator.clipboard?.writeText(data.code).then(() => toast({ text: nl ? 'Gekopieerd' : 'Copied' }))}><Copy size={16} /></button>
        <button className="btn soft sm" onClick={share}><Share2 size={16} /> {nl ? 'Deel link' : 'Share link'}</button>
      </div>
      {contactsSupported() && (
        <button className="btn soft" disabled={busy} onClick={pickContacts}><BookUser size={17} /> {nl ? 'Kies uit je contacten' : 'Choose from your contacts'}</button>
      )}
      <form className="friend-form" onSubmit={(e) => (e.preventDefault(), code.trim() && add())}>
        <input className="input" value={code} onChange={(e) => (setCode(e.target.value), setInvite(null))} placeholder={nl ? 'Code, link of telefoonnummer' : 'Code, link or phone number'} aria-label={nl ? 'Code, link of telefoonnummer van je vriend' : 'Your friend’s code, link or phone number'} autoComplete="off" spellCheck={false} />
        <button className="btn primary" disabled={busy || !code.trim()}><UserPlus size={16} /> {nl ? 'Voeg toe' : 'Add'}</button>
      </form>
      {invite && (
        <div className="friend-invite">
          <span className="small grow">{nl ? 'Niemand is op dit nummer te vinden. Stuur een uitnodiging:' : 'No one can be found by this number yet. Send them an invite:'}</span>
          <a className="btn soft sm" href={smsHref(invite, inviteText(nl, data.code))}><MessageSquare size={15} /> {nl ? 'Sms' : 'Text'}</a>
        </div>
      )}
      {data.outgoing.length > 0 && (
        <div className="stack" style={{ gap: 6 }}>
          {data.outgoing.map((r: any) => (
            <div key={r.id} className="row friend-pending">
              <span className="grow small ellipsis">⏳ {nl ? `Wacht op ${r.name}` : `Waiting for ${r.name}`}</span>
              <button className="btn ghost sm" disabled={busy} onClick={() => act(() => del(`/api/friends/requests/${r.id}`))}>{nl ? 'Intrekken' : 'Withdraw'}</button>
            </div>
          ))}
        </div>
      )}
      <MyNumber phone={data.phone} />
      <p className="tiny muted friend-privacy"><Lock size={13} aria-hidden /> <span>{nl ? 'Vrienden zien alleen je niveau, XP, reeks en prestaties, pas als jullie allebei akkoord zijn. Nooit je voorraad, lijsten, recepten, maaltijden, telefoonnummer of e-mailadres.' : 'Friends only see your level, XP, streak and achievements, and only once you have both accepted. Never your stock, lists, recipes, meals, phone number or email.'}</span></p>
      <button className="btn ghost sm" style={{ alignSelf: 'center' }} disabled={busy} onClick={() => confirm(nl ? 'Nieuwe code maken? De oude code en link werken dan niet meer. Je vrienden blijven.' : 'Make a new code? The old code and link stop working. Your friends stay.') && act(() => post('/api/friends/code'), () => [nl ? 'Nieuwe code gemaakt' : 'New code made', false])}>
        <RefreshCw size={14} /> {nl ? 'Nieuwe code' : 'New code'}
      </button>
      {contacts && <ContactsSheet contacts={contacts} code={data.code} onClose={() => setContacts(null)} />}
    </div>
  );
}

/** Your own number, so friends who have it can find you. Off until you add it. */
function MyNumber({ phone }: { phone: { hint: string; discoverable: boolean } | null }) {
  const { nl, busy, act } = useFriendActions();
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState('');
  if (!phone && !editing) {
    return <button className="btn ghost sm" style={{ alignSelf: 'flex-start' }} onClick={() => setEditing(true)}><Phone size={15} /> {nl ? 'Laat vrienden je vinden via je nummer' : 'Let friends find you by your number'}</button>;
  }
  if (editing) {
    return (
      <form className="stack friend-phone" style={{ gap: 6 }} onSubmit={async (e) => {
        e.preventDefault();
        const r = await act(() => put('/api/friends/phone', { phone: value, discoverable: true }), () => [nl ? 'Mensen met je nummer kunnen je nu vinden' : 'People with your number can now find you', false]);
        if (r) (setEditing(false), setValue(''));
      }}>
        <div className="friend-form">
          <input className="input" type="tel" inputMode="tel" autoComplete="tel" value={value} onChange={(e) => setValue(e.target.value)} placeholder={nl ? 'Je telefoonnummer' : 'Your phone number'} aria-label={nl ? 'Je telefoonnummer' : 'Your phone number'} />
          <button className="btn primary" disabled={busy || value.replace(/\D/g, '').length < 6}>{nl ? 'Bewaar' : 'Save'}</button>
        </div>
        <span className="tiny muted">{nl ? 'Alleen versleuteld bewaard (een hash), nooit getoond. Wie je nummer in zijn contacten heeft, kan je een verzoek sturen; jij beslist.' : 'Kept only as a hash, never shown. Anyone with your number in their contacts can send you a request; you decide.'}</span>
        <button type="button" className="btn ghost sm" style={{ alignSelf: 'flex-start' }} onClick={() => setEditing(false)}>{nl ? 'Annuleer' : 'Cancel'}</button>
      </form>
    );
  }
  return (
    <div className="friend-phone-row">
      <div className="grow" style={{ minWidth: 0 }}>
        <div className="small">{nl ? 'Vindbaar via' : 'Findable by'} <b className="num">{phone!.hint}</b></div>
        <div className="tiny muted">{phone!.discoverable ? (nl ? 'Mensen met je nummer kunnen je vinden' : 'People with your number can find you') : nl ? 'Uit: niemand vindt je via je nummer' : 'Off: no one finds you by number'}</div>
      </div>
      <button className="switch" role="switch" aria-checked={phone!.discoverable} aria-label={nl ? 'Vindbaar via nummer' : 'Findable by number'} disabled={busy} onClick={() => act(() => put('/api/friends/phone', { discoverable: !phone!.discoverable }))} />
      <button className="icon-btn sm" aria-label={nl ? 'Nummer verwijderen' : 'Remove number'} disabled={busy} onClick={() => act(() => del('/api/friends/phone'), () => [nl ? 'Nummer verwijderd' : 'Number removed', false])}><X size={15} /></button>
    </div>
  );
}

/** Picked contacts: who's on PantryPip (add them), and who isn't yet (invite them by text). */
function ContactsSheet({ contacts, code, onClose }: { contacts: { name: string; tel: string; match?: any }[]; code: string; onClose: () => void }) {
  const { nl, busy, act, requested } = useFriendActions();
  const [states, setStates] = useState<Record<string, string>>({});
  const found = contacts.filter((c) => c.match);
  const others = contacts.filter((c) => !c.match);
  const STATE: Record<string, [string, string]> = { friends: ['Friends', 'Vrienden'], pending: ['Requested', 'Gevraagd'] };
  return (
    <Sheet title={nl ? 'Je contacten' : 'Your contacts'} onClose={onClose}>
      {found.length > 0 && (
        <>
          <div className="section-head" style={{ marginTop: 0 }}><h2>{nl ? 'Op PantryPip' : 'On PantryPip'}</h2></div>
          <div className="list">
            {found.map((c) => {
              const state = states[c.match.userId] ?? c.match.state;
              return (
                <div key={c.match.userId} className="item">
                  <span className="thumb">🧑‍🍳</span>
                  <div className="grow" style={{ minWidth: 0 }}><div className="title ellipsis">{c.name}</div><div className="meta ellipsis">{nl ? 'op PantryPip als' : 'on PantryPip as'} {c.match.name}</div></div>
                  {STATE[state] ? <span className="small muted">{nl ? STATE[state][1] : STATE[state][0]}</span> : (
                    <button className="btn primary sm" disabled={busy} onClick={async () => {
                      const r: any = await act(() => post('/api/friends/request', { userId: c.match.userId, match: c.match.match }), requested);
                      if (r) setStates((s) => ({ ...s, [c.match.userId]: r.state }));
                    }}>{state === 'incoming' ? (nl ? 'Accepteer' : 'Accept') : nl ? 'Voeg toe' : 'Add'}</button>
                  )}
                </div>
              );
            })}
          </div>
        </>
      )}
      {others.length > 0 && (
        <>
          <div className="section-head"><h2>{nl ? 'Uitnodigen' : 'Invite'}</h2><span className="tiny muted">{nl ? 'nog niet te vinden' : 'not findable yet'}</span></div>
          <div className="list">
            {others.map((c) => (
              <div key={c.tel} className="item">
                <span className="thumb">✉️</span>
                <div className="grow" style={{ minWidth: 0 }}><div className="title ellipsis">{c.name}</div><div className="meta ellipsis">{c.tel}</div></div>
                <a className="btn soft sm" href={smsHref(c.tel, inviteText(nl, code))}><MessageSquare size={15} /> {nl ? 'Sms' : 'Text'}</a>
              </div>
            ))}
          </div>
        </>
      )}
      <p className="tiny muted">{nl ? 'Nummers worden alleen vergeleken, niet bewaard. Alleen wie zich vindbaar heeft gemaakt, verschijnt hier.' : 'Numbers are only compared, never stored. Only people who chose to be findable show up here.'}</p>
    </Sheet>
  );
}

function FriendRow({ f, data, open, onToggle, onRemove, busy }: { f: any; data: any; open: boolean; onToggle: () => void; onRemove: () => void; busy: boolean }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const p = f.progress;
  const together = data.social.together[f.id] ?? 0;
  const when = (iso: string) => new Date(iso).toLocaleDateString(nl ? 'nl-NL' : 'en-GB', { day: 'numeric', month: 'short' });
  if (!p) {
    return <div className="item"><Pip size={42} /><div className="grow"><div className="title ellipsis">{f.name}</div><div className="meta">{nl ? 'Voortgang wordt bijgewerkt…' : 'Updating progress…'}</div></div></div>;
  }
  return (
    <div className={`friend ${open ? 'open' : ''}`}>
      <button className="item" onClick={onToggle} aria-expanded={open}>
        <Pip skin={p.skin} stages={p.stages} size={42} />
        <div className="grow" style={{ minWidth: 0 }}>
          <div className="title ellipsis">{f.name}</div>
          <div className="meta ellipsis">
            {p.limited ? (nl ? 'deelt alleen de reeks' : 'shares their streak only') : <>{p.level.emoji} {nl ? p.level.name_nl : p.level.name} · {p.xp} XP</>}
            {together > 1 && <> · 🤝 {nl ? `${together} dagen samen` : `${together} days together`}</>}
          </div>
        </div>
        <span className={`friend-flame ${p.streak.cookedToday ? 'lit' : ''}`} title={nl ? 'Dagen op rij gekookt' : 'Days in a row cooked'}>🔥 <b className="num">{p.streak.current}</b></span>
        <ChevronDown size={18} className="muted friend-chev" />
      </button>
      {open && (
        <div className="friend-detail">
          {!p.limited && (
            <>
              <div className="xp-bar"><i style={{ width: `${Math.round(p.level.progress * 100)}%` }} /></div>
              <div className="ach-summary friend-stats">
                <div><b className="num">{p.streak.current}</b><span>{nl ? `reeks · record ${p.streak.best}` : `streak · best ${p.streak.best}`}</span></div>
                <div><b className="num">{p.weekXp}</b><span>{nl ? 'XP deze week' : 'XP this week'}</span></div>
                <div><b className="num">{p.badges.done}/{p.badges.all}</b><span>badges</span></div>
              </div>
              <div className="small">{p.chapter.emoji} {nl ? `Hoofdstuk ${p.chapter.n}: ${p.chapter.title_nl}` : `Chapter ${p.chapter.n}: ${p.chapter.title}`} <span className="muted">· {p.chapter.done}/{p.chapter.total} {nl ? 'voltooid' : 'done'}</span></div>
              {(p.recent.length > 0 || p.badges.latest.length > 0) && (
                <div className="friend-recent">
                  {p.recent.map((r: any) => <span key={r.id} className="chip static">{r.emoji} {nl ? r.title_nl : r.title} <span className="muted">{when(r.at)}</span></span>)}
                  {p.badges.latest.map((b: any) => <span key={b.id} className="chip static">{b.emoji} {nl ? b.title_nl : b.title}</span>)}
                </div>
              )}
            </>
          )}
          <div className="small">🤝 {together > 0 ? (nl ? `Samen-kookreeks: ${together} ${together === 1 ? 'dag' : 'dagen'} dat jullie allebei kookten` : `Cook-along streak: ${together} ${together === 1 ? 'day' : 'days'} you both cooked`) : nl ? 'Kook op dezelfde dag voor een samen-kookreeks' : 'Cook on the same day to start a cook-along streak'}</div>
          <FriendActions f={f} data={data} />
          <button className="btn ghost sm friend-remove" disabled={busy} onClick={() => confirm(nl ? `${f.name} verwijderen als vriend? Jullie zien elkaars voortgang dan niet meer.` : `Remove ${f.name} as a friend? You’ll both stop seeing each other’s progress.`) && onRemove()}>
            {nl ? 'Verwijder vriend' : 'Remove friend'}
          </button>
        </div>
      )}
    </div>
  );
}

function errorText(e: any, nl: boolean): string {
  const t: Record<string, [string, string]> = {
    invalid_code: ['No one has this code. Check it with your friend.', 'Niemand heeft deze code. Controleer hem met je vriend.'],
    own_code: ['That’s you.', 'Dat ben jij.'],
    same_household: ['You already share a household, so you see the same progress.', 'Jullie delen al een huishouden en zien dezelfde voortgang.'],
    rate_limited: ['Too many tries. Try again later.', 'Te veel pogingen. Probeer het later opnieuw.'],
  };
  return t[e?.code]?.[nl ? 1 : 0] ?? e?.message ?? 'Error';
}
