// Playing together (Progress → Friends): inbox, Pip visits, duels, leagues, the seasonal event, challenges and
// team goals together, the weekly recap card, the rescued-food counter, and sending a recipe to a friend.
import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { Send, Swords, Users, Share2, X } from 'lucide-react';
import { useQuery, post, put, invalidate } from '../api';
import { useApp } from '../app-context';
import { useToast, Sheet } from '../components/ui';
import { Pip } from '../components/Pip';

const tx = (nl: boolean, t: [string, string] | string[]) => (nl ? t[1] : t[0]);
const fmtDay = (nl: boolean, d: string) => new Date(d + (d.length === 10 ? 'T12:00:00Z' : '')).toLocaleDateString(nl ? 'nl-NL' : 'en-GB', { day: 'numeric', month: 'short' });
const refresh = () => invalidate(['friends', 'game', 'preferences']);

/** Run a call, show its error as a toast, refresh friends. */
function useCall() {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const run = async <T,>(fn: () => Promise<T>, ok?: string) => {
    setBusy(true);
    try {
      const r = await fn();
      refresh();
      if (ok) toast({ text: ok });
      return r;
    } catch (e: any) {
      toast({ text: e?.message ?? 'Error', error: true });
    } finally {
      setBusy(false);
    }
  };
  return { busy, run };
}

/** Cheers, nudges, recipes from friends, and invitations to duels, challenges and team goals. */
export function Inbox({ data }: { data: any }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const { busy, run } = useCall();
  const s = data.social;
  const duels = s.duels.filter((d: any) => d.status === 'pending' && !d.mine);
  const groups = s.groups.filter((g: any) => g.status === 'invited');
  const fresh = s.inbox.cheers.filter((c: any) => !c.seen);
  // Seen once shown.
  useEffect(() => {
    if (!fresh.length) return;
    const t = setTimeout(() => post('/api/social/seen').catch(() => {}), 2500);
    return () => clearTimeout(t);
  }, [fresh.map((c: any) => c.id).join()]);
  if (!fresh.length && !s.inbox.passes.length && !duels.length && !groups.length) return null;
  return (
    <>
      <div className="section-head"><h2>{nl ? 'Voor jou' : 'For you'}</h2></div>
      <div className="list inbox">
        {fresh.map((c: any) => (
          <div key={c.id} className="item">
            <span className="thumb">{c.kind === 'nudge' ? '🔥' : '👏'}</span>
            <div className="grow" style={{ minWidth: 0 }}>
              <div className="title ellipsis">{c.kind === 'nudge' ? (nl ? `${c.from}: kook vandaag!` : `${c.from}: cook today!`) : nl ? `${c.from} juicht je toe` : `${c.from} cheered you on`}</div>
              <div className="meta">{c.kind === 'nudge' ? (nl ? 'Houd je reeks vast' : 'Keep your streak going') : nl ? 'Voor wat je behaalde' : 'For what you earned'}</div>
            </div>
          </div>
        ))}
        {s.inbox.passes.map((p: any) => (
          <div key={p.id} className="item">
            <span className="thumb">{p.emoji ?? '📨'}</span>
            <div className="grow" style={{ minWidth: 0 }}>
              <div className="title ellipsis">{p.title}</div>
              <div className="meta">{nl ? `van ${p.from}` : `from ${p.from}`}{p.cookedTimes > 1 ? (nl ? ` · ${p.cookedTimes}× gekookt` : ` · cooked it ${p.cookedTimes}×`) : ''}{p.note ? ` · “${p.note}”` : ''}</div>
            </div>
            <div className="actions">
              <button className="icon-btn sm" disabled={busy} aria-label={nl ? 'Niet nu' : 'Not now'} onClick={() => run(() => post(`/api/social/pass/${p.id}`, { add: false }))}><X size={16} /></button>
              <button className="btn primary sm" disabled={busy} onClick={() => run(() => post(`/api/social/pass/${p.id}`, { add: true }), nl ? 'Op je wil-ik-proberen-lijst. Kook het voor +20 XP!' : 'On your to-try list. Cook it for +20 XP!')}>{nl ? 'Wil ik proberen' : 'Want to try'}</button>
            </div>
          </div>
        ))}
        {duels.map((d: any) => (
          <div key={d.id} className="item">
            <span className="thumb">⚔️</span>
            <div className="grow" style={{ minWidth: 0 }}><div className="title ellipsis">{nl ? `${d.other.name} daagt je uit` : `${d.other.name} challenges you`}</div><div className="meta">{nl ? 'Meeste XP tot zondag wint +40 XP' : 'Most XP by Sunday wins +40 XP'}</div></div>
            <div className="actions">
              <button className="icon-btn sm" disabled={busy} aria-label={nl ? 'Weiger' : 'Decline'} onClick={() => run(() => post(`/api/social/duels/${d.id}`, { accept: false }))}><X size={16} /></button>
              <button className="btn primary sm" disabled={busy} onClick={() => run(() => post(`/api/social/duels/${d.id}`, { accept: true }), nl ? 'Duel begonnen!' : 'Duel on!')}>{nl ? 'Doe mee' : 'Accept'}</button>
            </div>
          </div>
        ))}
        {groups.map((g: any) => (
          <div key={g.id} className="item">
            <span className="thumb">{g.emoji}</span>
            <div className="grow" style={{ minWidth: 0 }}>
              <div className="title ellipsis">{tx(nl, g.title)}</div>
              <div className="meta">{nl ? `${g.by} nodigt je uit · tot ${fmtDay(nl, g.ends)}` : `${g.by} invites you · until ${fmtDay(nl, g.ends)}`}{g.kind === 'challenge' ? (nl ? ' · vervangt je huidige uitdaging' : ' · replaces your current challenge') : ''}</div>
            </div>
            <div className="actions">
              <button className="icon-btn sm" disabled={busy} aria-label={nl ? 'Nee, dank je' : 'No thanks'} onClick={() => run(() => post(`/api/social/groups/${g.id}`, { join: false }))}><X size={16} /></button>
              <button className="btn primary sm" disabled={busy} onClick={() => run(() => post(`/api/social/groups/${g.id}`, { join: true }), nl ? 'Je doet mee!' : 'You’re in!')}>{nl ? 'Doe mee' : 'Join'}</button>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

/** Friends' Pips visiting after they finished a chapter. */
export function PipVisits({ data }: { data: any }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const v = data?.social?.visits ?? [];
  if (!v.length) return null;
  return (
    <div className="pip-visits" role="status">
      {v.map((x: any) => (
        <div key={x.id} className="pip-visit">
          <Pip skin={x.skin} stages={x.stages} size={40} mood="cheer" className="visiting" />
          <span className="small"><b>{nl ? `De Pip van ${x.name} komt langs!` : `${x.name}’s Pip drops by!`}</b> <span className="muted">{nl ? `Hoofdstuk ${x.chapter} voltooid 🎉` : `Finished chapter ${x.chapter} 🎉`}</span></span>
        </div>
      ))}
    </div>
  );
}

/** This week's duels: you vs them, live. */
export function Duels({ data }: { data: any }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const ds = data.social.duels.filter((d: any) => d.status === 'active' || d.status === 'done' || (d.status === 'pending' && d.mine));
  if (!ds.length) return null;
  return (
    <>
      <div className="section-head"><h2>{nl ? 'Duels' : 'Duels'}</h2><span className="tiny muted">{nl ? 'meeste XP tot zondag' : 'most XP by Sunday'}</span></div>
      <div className="stack" style={{ gap: 8 }}>
        {ds.map((d: any) => {
          const max = Math.max(1, d.me, d.them);
          return (
            <div key={d.id} className="card pad duel">
              <div className="row" style={{ gap: 8 }}>
                <b className="grow">⚔️ {nl ? `Jij vs ${d.other.name}` : `You vs ${d.other.name}`}</b>
                <span className="tiny muted">{d.status === 'pending' ? (nl ? 'wacht op antwoord' : 'waiting for an answer') : d.status === 'done' ? (d.won == null ? (nl ? 'gelijkspel' : 'a tie') : d.won ? (nl ? 'gewonnen! +40 XP' : 'you won! +40 XP') : nl ? 'verloren, volgende keer!' : 'lost, next time!') : nl ? 'bezig' : 'on'}</span>
              </div>
              <div className="duel-bar"><span>{nl ? 'Jij' : 'You'}</span><div className="xp-bar"><i style={{ width: `${(d.me / max) * 100}%` }} /></div><b className="num">{d.me}</b></div>
              <div className="duel-bar them"><span className="ellipsis">{d.other.name}</span><div className="xp-bar"><i style={{ width: `${(d.them / max) * 100}%` }} /></div><b className="num">{d.them}</b></div>
            </div>
          );
        })}
      </div>
    </>
  );
}

/** Your league, how to move up, and where you stand. */
export function LeagueHead({ data }: { data: any }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const L = data.social.league;
  return (
    <div className="league-head">
      <span className="league-emoji" aria-hidden>{L.emoji}</span>
      <div className="grow" style={{ minWidth: 0 }}>
        <b>{tx(nl, L.title)}</b>
        <div className="tiny muted">
          {L.moved > 0 ? (nl ? 'Gepromoveerd! ' : 'Promoted! ') : L.moved < 0 ? (nl ? 'Een league gezakt. ' : 'Moved down a league. ') : ''}
          {L.up ? (nl ? `${L.up} XP deze week = promotie op maandag.` : `${L.up} XP this week moves you up on Monday.`) : nl ? 'De hoogste league!' : 'The top league!'}
        </div>
      </div>
      <span className="league-ladder" aria-hidden>{L.all.map((x: any, i: number) => <i key={i} className={i === L.league ? 'on' : ''}>{x.emoji}</i>)}</span>
    </div>
  );
}

/** This season's event with friends' counts, or the next one. */
export function EventCard({ data }: { data: any }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const e = data.social.event;
  if (!e) {
    const n = data.social.nextEvent;
    return <p className="tiny muted event-next">{n.emoji} {nl ? `Volgend seizoensevent: ${tx(nl, n.title)}, vanaf ${n.from.split('-').reverse().join('-')}` : `Next seasonal event: ${tx(nl, n.title)}, from ${n.from.split('-').reverse().join('/')}`}</p>;
  }
  const mine = e.board.find((p: any) => p.me)?.count ?? 0;
  return (
    <>
      <div className="section-head"><h2>{e.emoji} {tx(nl, e.title)}</h2><span className="tiny muted">{nl ? `tot ${fmtDay(nl, e.end)}` : `until ${fmtDay(nl, e.end)}`}</span></div>
      <div className="card pad event-card">
        <div className="row" style={{ gap: 12 }}>
          <Pip skin={e.skin} size={52} mood={e.done ? 'cheer' : 'happy'} />
          <div className="grow" style={{ minWidth: 0 }}>
            <b>{tx(nl, e.desc)}</b>
            <div className="tiny muted">{e.done ? (nl ? `Gehaald! Je hebt de nieuwe Pip-look en +${e.xp} XP.` : `Done! You earned this Pip look and +${e.xp} XP.`) : nl ? `+${e.xp} XP en deze Pip-look, alleen deze maand` : `+${e.xp} XP and this Pip look, only this month`}</div>
            <div className="xp-bar"><i style={{ width: `${Math.min(1, mine / e.goal) * 100}%` }} /></div>
          </div>
          <b className="num">{Math.min(mine, e.goal)}/{e.goal}</b>
        </div>
        {e.board.length > 1 && (
          <div className="event-board">
            {e.board.map((p: any) => <span key={p.id} className={`chip static ${p.me ? 'on' : ''}`}>{p.me ? (nl ? 'Jij' : 'You') : p.name} <b className="num">{p.count}</b></span>)}
          </div>
        )}
      </div>
    </>
  );
}

/** Challenges and team goals with friends, and starting a new one. */
export function Together({ data }: { data: any }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const [open, setOpen] = useState(false);
  const groups = data.social.groups.filter((g: any) => g.status === 'joined');
  const canStart = data.friends.length > 0;
  return (
    <>
      <div className="section-head"><h2>{nl ? 'Samen' : 'Together'}</h2>{canStart && <button className="link" onClick={() => setOpen(true)}>{nl ? '+ Samen starten' : '+ Start together'}</button>}</div>
      {!groups.length && <p className="tiny muted" style={{ marginTop: -4 }}>{canStart ? (nl ? 'Start een uitdaging met vrienden, of een teamdoel zoals “samen 50 maaltijden deze maand”.' : 'Start a challenge with friends, or a team goal like “50 meals together this month”.') : nl ? 'Voeg eerst een vriend toe.' : 'Add a friend first.'}</p>}
      <div className="stack" style={{ gap: 8 }}>
        {groups.map((g: any) => (
          <div key={g.id} className="card pad group-card">
            <div className="row" style={{ gap: 10 }}>
              <span className="thumb">{g.emoji}</span>
              <div className="grow" style={{ minWidth: 0 }}><b className="ellipsis" style={{ display: 'block' }}>{tx(nl, g.title)}</b><span className="tiny muted">{nl ? `tot ${fmtDay(nl, g.ends)}` : `until ${fmtDay(nl, g.ends)}`}</span></div>
              {g.kind === 'goal' && <b className="num">{g.done ? '🎁' : `${g.total}/${g.target}`}</b>}
            </div>
            {g.kind === 'goal' ? (
              <>
                <div className="xp-bar"><i style={{ width: `${Math.min(1, g.total / g.target) * 100}%` }} /></div>
                <div className="tiny muted">{g.done ? (nl ? 'Gehaald! Iedereen kreeg +50 XP.' : 'Reached! Everyone got +50 XP.') : g.members.filter((m: any) => m.joined).map((m: any) => (m.me ? (nl ? 'jij' : 'you') : m.name)).join(', ')}</div>
              </>
            ) : (
              g.members.map((m: any) => (
                <div key={m.id} className="duel-bar">
                  <span className="ellipsis">{m.me ? (nl ? 'Jij' : 'You') : m.name}</span>
                  {m.joined ? <div className="xp-bar"><i style={{ width: `${Math.min(1, (m.progress ?? 0) / g.target) * 100}%` }} /></div> : <span className="tiny muted grow">{nl ? 'uitgenodigd' : 'invited'}</span>}
                  <b className="num">{m.joined ? `${m.progress ?? 0}/${g.target}` : ''}</b>
                </div>
              ))
            )}
          </div>
        ))}
      </div>
      {open && <StartTogether data={data} onClose={() => setOpen(false)} />}
    </>
  );
}

function StartTogether({ data, onClose }: { data: any; onClose: () => void }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const { data: g } = useQuery<any>('/api/game', ['game', 'preferences']);
  const { busy, run } = useCall();
  const [kind, setKind] = useState<'challenge' | 'goal'>('challenge');
  const [ref, setRef] = useState('homechef');
  const [target, setTarget] = useState(30);
  const friends = data.friends.filter((f: any) => f.progress);
  const [who, setWho] = useState<string[]>(friends.map((f: any) => f.id));
  const start = async () => {
    const r = await run(() => post('/api/social/groups', { kind, ref: kind === 'goal' ? 'meals' : ref, target: kind === 'goal' ? target : null, friends: who }), nl ? 'Uitnodigingen verstuurd' : 'Invites sent');
    if (r) onClose();
  };
  return (
    <Sheet title={nl ? 'Samen starten' : 'Start together'} onClose={onClose} footer={<button className="btn primary block" disabled={busy || !who.length} onClick={start}><Users size={16} /> {nl ? 'Nodig uit' : 'Invite'}</button>}>
      <div className="seg mini" role="tablist">
        <button role="tab" aria-selected={kind === 'challenge'} className={kind === 'challenge' ? 'on' : ''} onClick={() => setKind('challenge')}>{nl ? 'Uitdaging (7 dagen)' : 'Challenge (7 days)'}</button>
        <button role="tab" aria-selected={kind === 'goal'} className={kind === 'goal' ? 'on' : ''} onClick={() => setKind('goal')}>{nl ? 'Teamdoel (deze maand)' : 'Team goal (this month)'}</button>
      </div>
      {kind === 'challenge' ? (
        <div className="list" style={{ marginTop: 12 }}>
          {(g?.challenge.all ?? []).map((c: any) => (
            <label key={c.id} className="item" style={{ cursor: 'pointer' }}>
              <span className="thumb">{c.emoji}</span>
              <div className="grow"><div className="title">{nl ? c.title_nl : c.title}</div><div className="meta">{nl ? c.desc_nl : c.desc}</div></div>
              <input type="radio" name="ch" checked={ref === c.id} onChange={() => setRef(c.id)} />
            </label>
          ))}
        </div>
      ) : (
        <div className="card pad" style={{ marginTop: 12 }}>
          <label className="small">{nl ? 'Samen zoveel maaltijden koken deze maand' : 'Meals to cook together this month'}</label>
          <input className="input" type="number" min={2} max={1000} value={target} onChange={(e) => setTarget(Math.max(2, Math.min(1000, Number(e.target.value) || 2)))} style={{ marginTop: 6 }} />
          <p className="tiny muted" style={{ marginBottom: 0 }}>{nl ? 'Haal je het samen, dan krijgt iedereen een beloningskist: +50 XP.' : 'Reach it together and everyone gets a reward chest: +50 XP.'}</p>
        </div>
      )}
      <div className="section-head"><h2>{nl ? 'Met wie?' : 'With whom?'}</h2></div>
      <div className="list">
        {friends.map((f: any) => (
          <label key={f.id} className="item" style={{ cursor: 'pointer' }}>
            <Pip skin={f.progress.skin} size={34} />
            <span className="grow title">{f.name}</span>
            <input type="checkbox" checked={who.includes(f.id)} onChange={(e) => setWho(e.target.checked ? [...who, f.id] : who.filter((x) => x !== f.id))} />
          </label>
        ))}
      </div>
    </Sheet>
  );
}

/** "This week: you, Bo and Ana cooked 14 meals and rescued 9 foods", as a card you can share as an image. */
export function RecapCard({ data }: { data: any }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const toast = useToast();
  const r = data.social.recap;
  const k = data.social.rescued;
  const join = (xs: string[]) => (xs.length > 1 ? `${xs.slice(0, -1).join(', ')} ${nl ? 'en' : 'and'} ${xs[xs.length - 1]}` : xs[0]);
  // The image is for others, so it uses your name; on screen it says "you".
  const names = join(r.names);
  const line = nl
    ? `Deze week kookten ${join([...(r.names.length > 1 ? ['jij'] : ['Jij']), ...r.names.slice(1)])} samen ${r.meals} ${r.meals === 1 ? 'maaltijd' : 'maaltijden'} en ${r.rescued === 1 ? 'werd 1 product' : `werden ${r.rescued} producten`} gered van de vuilnisbak.`
    : `This week ${join(['you', ...r.names.slice(1)])} cooked ${r.meals} ${r.meals === 1 ? 'meal' : 'meals'} together and rescued ${r.rescued} ${r.rescued === 1 ? 'food' : 'foods'} from the bin.`;
  const share = async () => {
    const blob = await recapImage(nl, r, k, names);
    const file = new File([blob], 'pantrypip-week.png', { type: 'image/png' });
    try {
      if (navigator.canShare?.({ files: [file] })) return await navigator.share({ files: [file], text: line });
    } catch {
      return; // cancelled
    }
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'pantrypip-week.png';
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    toast({ text: nl ? 'Afbeelding opgeslagen' : 'Image saved' });
  };
  return (
    <>
      <div className="section-head"><h2>{nl ? 'Jullie week' : 'Your week together'}</h2></div>
      <div className="card pad recap-card">
        <div className="recap-nums">
          <div><b className="num">{r.meals}</b><span>{nl ? 'maaltijden' : 'meals'}</span></div>
          <div><b className="num">{r.rescued}</b><span>{nl ? 'gered deze week' : 'rescued this week'}</span></div>
          <div><b className="num">{k.kg}</b><span>{nl ? 'kg gered, ooit' : 'kg rescued, ever'}</span></div>
        </div>
        <p className="small" style={{ margin: '10px 0' }}>{line}</p>
        <p className="tiny muted" style={{ margin: '0 0 10px' }}>♻️ {nl ? `Samen hielden jullie al ${k.kg} kg (${k.foods} ${k.foods === 1 ? 'product' : 'producten'}) uit de vuilnisbak. Jij: ${k.mine.kg} kg.` : `Together you’ve kept ${k.kg} kg (${k.foods} ${k.foods === 1 ? 'food' : 'foods'}) out of the bin. You: ${k.mine.kg} kg.`}</p>
        <button className="btn soft sm" onClick={share}><Share2 size={15} /> {nl ? 'Deel als afbeelding' : 'Share as image'}</button>
      </div>
    </>
  );
}

/** Draws the recap as a square PNG (no libraries). */
async function recapImage(nl: boolean, r: any, k: any, names: string): Promise<Blob> {
  const c = document.createElement('canvas');
  c.width = c.height = 1080;
  const g = c.getContext('2d')!;
  // Always the deep green, so white text reads well whatever theme the app is in.
  g.fillStyle = '#2F5D50';
  g.fillRect(0, 0, 1080, 1080);
  g.fillStyle = 'rgba(255,255,255,.08)';
  g.beginPath();
  g.arc(900, 160, 260, 0, Math.PI * 2);
  g.fill();
  g.fillStyle = '#fff';
  g.font = '600 44px Georgia, serif';
  g.fillText(nl ? 'Onze week in de keuken' : 'Our week in the kitchen', 80, 150);
  g.font = '400 30px system-ui, sans-serif';
  wrap(g, names, 80, 210, 920, 40);
  const stat = (x: number, n: string, label: string) => {
    g.font = '800 150px system-ui, sans-serif';
    g.fillText(n, x, 560);
    g.font = '500 34px system-ui, sans-serif';
    g.fillText(label, x, 620);
  };
  stat(80, String(r.meals), nl ? 'maaltijden gekookt' : 'meals cooked');
  stat(580, String(r.rescued), nl ? 'producten gered' : 'foods rescued');
  g.font = '500 36px system-ui, sans-serif';
  g.fillText(`♻️ ${k.kg} kg ${nl ? 'uit de vuilnisbak gehouden, samen' : 'kept out of the bin, together'}`, 80, 760);
  g.font = '700 40px system-ui, sans-serif';
  g.fillText('🌱 PantryPip', 80, 980);
  return new Promise((res) => c.toBlob((b) => res(b!), 'image/png'));
}
function wrap(g: CanvasRenderingContext2D, text: string, x: number, y: number, w: number, lh: number) {
  let line = '';
  for (const word of text.split(' ')) {
    if (g.measureText(line + word).width > w && line) {
      g.fillText(line, x, y);
      y += lh;
      line = '';
    }
    line += word + ' ';
  }
  g.fillText(line, x, y);
}

/** Buttons on a friend: cheer, nudge, duel, and what they may see of you. */
export function FriendActions({ f, data }: { f: any; data: any }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const { busy, run } = useCall();
  const s = data.social;
  const p = f.progress;
  const sent = (kind: string, ref = '') => s.sentToday.includes(`${kind}:${f.id}:${ref}`);
  const latest = p?.limited ? null : p?.recent?.[0] ?? (p?.badges?.latest?.[0] ? { id: `badge:${p.badges.latest[0].id}`, title: p.badges.latest[0].title, title_nl: p.badges.latest[0].title_nl, emoji: p.badges.latest[0].emoji } : null);
  const dueling = s.duels.some((d: any) => d.other.id === f.id && d.status !== 'done');
  return (
    <div className="friend-actions">
      {latest && (
        <button className="btn soft sm" disabled={busy || sent('cheer', latest.id)} onClick={() => run(() => post('/api/social/cheer', { to: f.id, kind: 'cheer', ref: latest.id, label: nl ? latest.title_nl : latest.title }), nl ? `Je juichte ${f.name} toe 👏` : `You cheered ${f.name} on 👏`)}>
          👏 {sent('cheer', latest.id) ? (nl ? 'Toegejuicht' : 'Cheered') : nl ? `Juich voor ${latest.emoji}` : `Cheer ${latest.emoji}`}
        </button>
      )}
      {!p?.streak?.cookedToday && (
        <button className="btn soft sm" disabled={busy || sent('nudge')} onClick={() => run(() => post('/api/social/cheer', { to: f.id, kind: 'nudge' }), nl ? `${f.name} kreeg een duwtje 🔥` : `Nudged ${f.name} 🔥`)}>
          🔥 {sent('nudge') ? (nl ? 'Duwtje gegeven' : 'Nudged') : nl ? 'Duwtje' : 'Nudge'}
        </button>
      )}
      {!p?.limited && f.shows === 'all' && !dueling && (
        <button className="btn soft sm" disabled={busy} onClick={() => run(() => post('/api/social/duels', { friendId: f.id }), nl ? `${f.name} is uitgedaagd ⚔️` : `Challenged ${f.name} ⚔️`)}><Swords size={15} /> {nl ? 'Duel' : 'Duel'}</button>
      )}
      <label className="friend-privacy-pick small">
        <span className="muted">{nl ? `${f.name} ziet:` : `${f.name} sees:`}</span>
        <select className="select" value={f.shows} disabled={busy} onChange={(e) => run(() => post(`/api/friends/${f.id}/privacy`, { level: e.target.value }))}>
          <option value="all">{nl ? 'Alles (niveau, XP, prestaties)' : 'Everything (level, XP, achievements)'}</option>
          <option value="streak">{nl ? 'Alleen mijn reeks' : 'Only my streak'}</option>
        </select>
      </label>
    </div>
  );
}

/** Nudges on or off (for you). */
export function NudgeToggle({ data }: { data: any }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const { busy, run } = useCall();
  const on = data.social.nudges;
  return (
    <div className="friend-phone-row">
      <div className="grow"><div className="small">{nl ? 'Duwtjes van vrienden' : 'Nudges from friends'}</div><div className="tiny muted">{nl ? '“Kook vandaag!” als je nog niet kookte, hooguit één per vriend per dag' : '“Cook today!” when you haven’t yet, at most one per friend a day'}</div></div>
      <button className="switch" role="switch" aria-checked={on} aria-label={nl ? 'Duwtjes van vrienden' : 'Nudges from friends'} disabled={busy} onClick={() => run(() => put('/api/social/nudges', { on: !on }))} />
    </div>
  );
}

/** Recipe page: send this recipe to one or more friends. */
export function SendRecipeButton({ recipeId, title }: { recipeId: string; title: string }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const [open, setOpen] = useState(false);
  return (
    <>
      <button className="icon-btn" aria-label={nl ? 'Stuur naar een vriend' : 'Send to a friend'} title={nl ? 'Stuur naar een vriend' : 'Send to a friend'} onClick={() => setOpen(true)}><Send /></button>
      {/* Outside the top bar, which would otherwise clip the sheet. */}
      {open && createPortal(<SendRecipeSheet recipeId={recipeId} title={title} onClose={() => setOpen(false)} />, document.body)}
    </>
  );
}

function SendRecipeSheet({ recipeId, title, onClose }: { recipeId: string; title: string; onClose: () => void }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const { data } = useQuery<any>('/api/friends', ['friends']);
  const { busy, run } = useCall();
  const [who, setWho] = useState<string[]>([]);
  const [note, setNote] = useState('');
  const friends = data?.friends ?? [];
  const send = async () => {
    const r = await run(() => post('/api/social/pass', { to: who, recipeId, note: note.trim() || null }), nl ? 'Recept verstuurd 📨' : 'Recipe sent 📨');
    if (r) onClose();
  };
  return (
    <Sheet title={nl ? `“${title}” sturen` : `Send “${title}”`} onClose={onClose} footer={friends.length ? <button className="btn primary block" disabled={busy || !who.length} onClick={send}><Send size={16} /> {nl ? 'Stuur' : 'Send'}</button> : undefined}>
      {!data ? <div className="skeleton" style={{ height: 120 }} /> : !friends.length ? (
        <p className="small">{nl ? 'Voeg eerst vrienden toe in Instellingen → Vrienden.' : 'Add friends first, in Settings → Friends.'} <a href="#/settings/friends" onClick={onClose}>{nl ? 'Ga erheen' : 'Go there'}</a></p>
      ) : (
        <>
          <div className="list">
            {friends.map((f: any) => (
              <label key={f.id} className="item" style={{ cursor: 'pointer' }}>
                <Pip skin={f.progress?.skin} size={34} />
                <span className="grow title">{f.name}</span>
                <input type="checkbox" checked={who.includes(f.id)} onChange={(e) => setWho(e.target.checked ? [...who, f.id] : who.filter((x) => x !== f.id))} />
              </label>
            ))}
          </div>
          <input className="input" style={{ marginTop: 12 }} maxLength={200} value={note} onChange={(e) => setNote(e.target.value)} placeholder={nl ? 'Een berichtje (mag leeg)' : 'A short note (optional)'} aria-label={nl ? 'Berichtje' : 'Note'} />
          <p className="tiny muted">{nl ? 'Ze krijgen het op hun wil-ik-proberen-lijst, en +20 XP als ze het koken. Je notities en beoordeling gaan niet mee.' : 'It goes on their to-try list, and they get +20 XP when they cook it. Your notes and rating stay private.'}</p>
        </>
      )}
    </Sheet>
  );
}

