import { useEffect, useMemo, useRef, useState } from 'react';
import { Mic, Settings as SettingsIcon, Pencil, Plus, Undo2, RotateCcw, LayoutGrid, GripVertical, ChevronUp, ChevronDown, Pin, EyeOff, Eye, X, Minimize2, Maximize2, Check, Trash2, Lightbulb, ChevronRight } from 'lucide-react';
import { post, useQuery, invalidate } from '../api';
import { useApp } from '../app-context';
import { Sheet, useToast } from '../components/ui';
import { speechSupported } from '../components/Assistant';
import { CheckinCards } from '../components/Checkin';
import { InstallHint } from '../components/InstallHint';
import { WidgetBody, WIDGET_LINK } from '../components/Widgets';
import { useSettings } from '../settings';

type Size = 's' | 'm' | 'l';
type Device = 'phone' | 'tablet' | 'desktop';
interface Widget { id: string; type: string; size: Size; view: 'compact' | 'expanded'; pinned?: boolean; hidden?: boolean }
interface Profile { id: string; name: string; preset: string; layouts: Partial<Record<Device, Widget[]>> }
interface Config { version: 1; active: string; profiles: Profile[] }

const DATA_SCOPES = ['inventory', 'shopping', 'planner', 'recipes', 'home', 'game', 'preferences', 'notifications'];
const PROFILE_NAMES: Record<string, string> = { Everyday: 'Dagelijks', Shopping: 'Boodschappen', Cooking: 'Koken', Nutrition: 'Voeding' };

/** Which layout to use: phones, tablets and computers each keep their own. */
export function useDevice(): Device {
  const pick = () => (innerWidth < 600 ? 'phone' : innerWidth < 1100 ? 'tablet' : 'desktop');
  const [d, setD] = useState<Device>(pick);
  useEffect(() => {
    const on = () => setD(pick());
    addEventListener('resize', on);
    return () => removeEventListener('resize', on);
  }, []);
  return d;
}

const MAX_PROFILES = 8;
/** What the server accepts: trimmed names (never empty), at most 8 layouts, 60 widgets each. */
function sanitize(c: Config): Config {
  const profiles = c.profiles.slice(0, MAX_PROFILES).map((p, i) => ({
    ...p,
    name: p.name.trim().slice(0, 30) || `Layout ${i + 1}`,
    layouts: Object.fromEntries(Object.entries(p.layouts).filter(([, l]) => Array.isArray(l)).map(([d, l]) => [d, l!.slice(0, 60)])),
  }));
  return { ...c, profiles, active: profiles.some((p) => p.id === c.active) ? c.active : profiles[0].id };
}

let lastUse: Record<string, number> = {};
export const recordUse = (key: string) => {
  // At most once a minute per thing: it's a signal, not a click counter.
  if (Date.now() - (lastUse[key] ?? 0) < 60_000) return;
  lastUse[key] = Date.now();
  post('/api/dashboard/usage', { key }).catch(() => {});
};

export function HomePage() {
  const app = useApp();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const device = useDevice();
  const { track } = useSettings();
  const dash = useQuery<any>(`/api/dashboard?device=${device}`, ['preferences', 'dashboard']);
  const [cfg, setCfg] = useState<Config | null>(null);
  const history = useRef<Config[]>([]);
  const [editing, setEditing] = useState(false);
  const [sheet, setSheet] = useState<null | 'add' | 'presets'>(null);
  const [drag, setDrag] = useState<string | null>(null);
  const [tools, setTools] = useState<string | null>(null);
  useEffect(() => {
    if (/[?&]edit=1/.test(location.hash)) {
      setEditing(true);
      window.history.replaceState(null, '', location.hash.replace(/[?&]edit=1/, ''));
    }
  }, []);
  const saveTimer = useRef<any>(null);
  // Saving: one request at a time, always the latest layout, flushed when you leave Home or the app.
  // While a change is unsaved (`dirty`), fresh server data never overwrites it; once saved, Home
  // follows the server again (so another device's change shows up, and a stale cache never wins).
  const dirty = useRef(false);
  const pending = useRef<Config | null>(null);
  const inflight = useRef(false);
  const flush = () => {
    clearTimeout(saveTimer.current);
    if (inflight.current || !pending.current) return;
    const next = pending.current;
    pending.current = null;
    inflight.current = true;
    track(
      fetch('/api/dashboard', { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify(next), keepalive: true, credentials: 'same-origin' }).then(async (r) => {
        if (!r.ok) throw new Error((await r.json().catch(() => null))?.error?.message ?? `Couldn’t save your layout (${r.status})`);
      }),
    )
      .catch((e) => toast({ text: e.message, error: true }))
      .finally(() => {
        inflight.current = false;
        if (pending.current) flush();
        else {
          dirty.current = false;
          invalidate(['dashboard']);
        }
      });
  };
  useEffect(() => {
    if (dash.data && !dirty.current) setCfg(dash.data.config);
  }, [dash.data]);
  useEffect(() => {
    recordUse('open:home');
    invalidate(['dashboard']); // never start from a cached copy
    const onHide = () => flush();
    addEventListener('pagehide', onHide);
    document.addEventListener('visibilitychange', onHide);
    return () => {
      removeEventListener('pagehide', onHide);
      document.removeEventListener('visibilitychange', onHide);
      flush();
    };
  }, []);

  const profile = cfg?.profiles.find((p) => p.id === cfg.active) ?? cfg?.profiles[0];
  const own = !!profile?.layouts[device];
  const layout: Widget[] = profile ? profile.layouts[device] ?? profile.layouts.phone ?? [] : [];
  const visible = useMemo(() => [...layout.filter((w) => !w.hidden && w.pinned), ...layout.filter((w) => !w.hidden && !w.pinned)], [layout]);
  const types = [...new Set(visible.map((w) => w.type))].sort().join(',');
  const data = useQuery<any>(types ? `/api/dashboard/data?types=${types}` : null, DATA_SCOPES);
  const catalogue: any[] = dash.data?.widgets ?? [];
  const def = (t: string) => catalogue.find((w) => w.type === t);

  const persist = (next: Config) => {
    dirty.current = true;
    pending.current = sanitize(next);
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(flush, 300);
  };
  /** Every change goes through here: remembered for Undo, saved to the server. */
  const commit = (fn: (c: Config) => Config, msg?: string) => {
    if (!cfg) return;
    history.current = [...history.current.slice(-19), cfg];
    const next = fn(structuredClone(cfg));
    setCfg(next);
    persist(next);
    if (msg) toast({ text: msg, undo: undo });
  };
  const undo = () => {
    const prev = history.current.pop();
    if (!prev) return;
    setCfg(prev);
    persist(prev);
  };
  /** Change this device's layout (copying the shared one the first time). */
  const editLayout = (fn: (l: Widget[]) => Widget[], msg?: string) =>
    commit((c) => {
      const p = c.profiles.find((x) => x.id === c.active)!;
      p.layouts[device] = fn([...(p.layouts[device] ?? p.layouts.phone ?? [])]);
      // The phone layout is the shared base: editing it on the phone keeps other devices following it.
      return c;
    }, msg);
  const move = (id: string, to: number) => editLayout((l) => {
    const i = l.findIndex((w) => w.id === id);
    const [w] = l.splice(i, 1);
    l.splice(Math.max(0, Math.min(l.length, to)), 0, w);
    return l;
  });
  const patchW = (id: string, p: Partial<Widget>) => editLayout((l) => l.map((w) => (w.id === id ? { ...w, ...p } : w)));
  const addWidget = (type: string, at = 0, size?: Size) => {
    const id = layout.some((w) => w.id === type) ? `${type}-${Date.now().toString(36)}` : type;
    editLayout((l) => {
      l.splice(at, 0, { id, type, size: size ?? def(type)?.size ?? 'm', view: 'expanded' });
      return l;
    }, nl ? `${def(type)?.title[1]} toegevoegd` : `Added ${def(type)?.title[0]}`);
  };
  const applySuggestion = (s: any) => {
    const a = s.action;
    editLayout((l) => {
      if (a.kind === 'add' && !l.some((w) => w.type === a.type)) l.splice(a.index ?? 0, 0, { id: a.type, type: a.type, size: a.size ?? def(a.type)?.size ?? 'm', view: 'expanded' });
      if (a.kind === 'move') {
        const i = l.findIndex((w) => w.type === a.type);
        if (i >= 0) {
          const [w] = l.splice(i, 1);
          l.splice(a.index ?? 0, 0, { ...w, size: a.size ?? w.size, hidden: false });
        }
      }
      if (a.kind === 'compact') return l.map((w) => ((a.types ?? [a.type]).includes(w.type) ? { ...w, view: 'compact' as const } : w));
      return l;
    }, nl ? 'Startscherm aangepast' : 'Home screen updated');
    post(`/api/dashboard/suggestions/${s.id}/dismiss`, {}).then(() => invalidate(['dashboard']));
  };
  const dismiss = (s: any) => post(`/api/dashboard/suggestions/${s.id}/dismiss`, {}).then(() => invalidate(['dashboard']));
  const usePreset = (presetId: string, asNew: boolean) => {
    const preset = dash.data.presets.find((p: any) => p.id === presetId);
    commit((c) => {
      if (asNew) {
        if (c.profiles.length >= MAX_PROFILES) {
          toast({ text: nl ? `Maximaal ${MAX_PROFILES} indelingen` : `At most ${MAX_PROFILES} layouts`, error: true });
          return c;
        }
        const id = `p-${Date.now().toString(36)}`;
        c.profiles.push({ id, name: nl ? preset.title[1] : preset.title[0], preset: preset.id, layouts: { phone: structuredClone(preset.widgets) } });
        c.active = id;
      } else {
        const p = c.profiles.find((x) => x.id === c.active)!;
        p.preset = preset.id;
        p.layouts = { phone: structuredClone(preset.widgets) };
      }
      return c;
    }, nl ? `Indeling “${preset.title[1]}”` : `Layout “${preset.title[0]}”`);
    setSheet(null);
  };
  const resetProfile = () => {
    const p = profile!;
    const preset = dash.data.presets.find((x: any) => x.id === p.preset) ?? dash.data.presets[0];
    commit((c) => {
      c.profiles.find((x) => x.id === c.active)!.layouts = { phone: structuredClone(preset.widgets) };
      return c;
    }, nl ? 'Teruggezet naar standaard' : 'Reset to default');
  };

  // Drag to reorder. Follows the pointer on the window (finger or mouse), so it doesn't depend on
  // pointer capture, which iOS can refuse; the handle has touch-action: none so the page doesn't scroll.
  const cfgRef = useRef(cfg);
  cfgRef.current = cfg;
  const dragOver = (id: string, x: number, y: number) => {
    const el = document.elementFromPoint(x, y)?.closest('[data-wid]') as HTMLElement | null;
    const over = el?.dataset.wid;
    if (!over || over === id) return;
    setCfg((c) => {
      if (!c) return c;
      const n = structuredClone(c);
      const p = n.profiles.find((x) => x.id === n.active)!;
      const l = [...(p.layouts[device] ?? p.layouts.phone ?? [])];
      const from = l.findIndex((w) => w.id === id);
      const to = l.findIndex((w) => w.id === over);
      if (from < 0 || to < 0) return c;
      const [w] = l.splice(from, 1);
      l.splice(to, 0, w);
      p.layouts[device] = l;
      return n;
    });
  };
  const startDrag = (e: React.PointerEvent, id: string) => {
    e.preventDefault();
    try {
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    } catch {
      /* not needed: we listen on the window */
    }
    if (cfgRef.current) history.current = [...history.current.slice(-19), cfgRef.current];
    dirty.current = true;
    setDrag(id);
    const move = (ev: PointerEvent) => {
      ev.preventDefault();
      dragOver(id, ev.clientX, ev.clientY);
    };
    const end = () => {
      removeEventListener('pointermove', move);
      removeEventListener('pointerup', end);
      removeEventListener('pointercancel', end);
      setDrag(null);
      // The last reorder may still be pending in React state; save after it lands.
      setTimeout(() => cfgRef.current && persist(cfgRef.current), 0);
    };
    addEventListener('pointermove', move, { passive: false });
    addEventListener('pointerup', end);
    addEventListener('pointercancel', end);
  };

  const hour = new Date().getHours();
  const greeting = nl ? (hour < 12 ? 'Goedemorgen' : hour < 18 ? 'Goedemiddag' : 'Goedenavond') : hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
  const pname = (p: Profile) => (nl ? PROFILE_NAMES[p.name] ?? p.name : p.name);

  return (
    <>
      <div className="hero">
        <a className="icon-btn ghost hero-gear" href="#/settings" aria-label={nl ? 'Instellingen' : 'Settings'}><SettingsIcon size={20} /></a>
        <div className="muted small" style={{ paddingTop: 18 }}>{new Date().toLocaleDateString(nl ? 'nl-NL' : 'en-GB', { weekday: 'long', day: 'numeric', month: 'long' })}</div>
        <h1>{greeting}{app.me?.user?.name ? `, ${app.me.user.name}` : ''}</h1>
        <button className="ask" onClick={() => app.openAssistant({ listen: speechSupported })}>
          <span className="grow">{nl ? '“De melk is op”, “wat kan ik koken?”…' : '“I finished the milk”, “what can I cook?”…'}</span>
          <span className="mic" aria-hidden><Mic /></span>
        </button>
      </div>

      <InstallHint />
      <CheckinCards />

      {!editing && (dash.data?.suggestions ?? []).slice(0, 1).map((s: any) => (
        <div key={s.id} className="card pad row dash-suggest">
          <Lightbulb size={18} color="var(--saffron)" />
          <span className="grow small">{nl ? s.text_nl : s.text}</span>
          <button className="btn ghost sm" onClick={() => dismiss(s)}>{nl ? 'Niet nu' : 'Not now'}</button>
          <button className="btn soft sm" onClick={() => applySuggestion(s)}>{nl ? 'Doen' : 'Apply'}</button>
        </div>
      ))}

      {!editing && cfg && cfg.profiles.length > 1 && (
        <div className="chips profiles" role="tablist" aria-label={nl ? 'Indelingen' : 'Layouts'}>
          {cfg.profiles.map((p) => (
            <button key={p.id} role="tab" aria-selected={p.id === cfg.active} className={`chip ${p.id === cfg.active ? 'on' : ''}`} onClick={() => p.id !== cfg.active && commit((c) => ({ ...c, active: p.id }))}>{pname(p)}</button>
          ))}
        </div>
      )}

      {editing && cfg && profile && (
        <div className="dash-edit">
          <div className="row" style={{ gap: 8 }}>
            <b className="grow">{nl ? 'Startscherm aanpassen' : 'Customise Home'}</b>
            <button className="btn primary sm" onClick={() => setEditing(false)}><Check size={15} /> {nl ? 'Klaar' : 'Done'}</button>
          </div>
          <div className="row wrap" style={{ gap: 6 }}>
            <button className="btn soft sm" onClick={() => setSheet('add')}><Plus size={15} /> {nl ? 'Widget' : 'Add widget'}</button>
            <button className="btn soft sm" onClick={() => setSheet('presets')}><LayoutGrid size={15} /> {nl ? 'Indelingen' : 'Layouts'}</button>
            <button className="btn ghost sm" onClick={undo} disabled={!history.current.length}><Undo2 size={15} /> {nl ? 'Ongedaan' : 'Undo'}</button>
            <button className="btn ghost sm" onClick={resetProfile}><RotateCcw size={15} /> {nl ? 'Standaard' : 'Reset'}</button>
          </div>
          {cfg.profiles.length > 1 && (
            <div className="row wrap" style={{ gap: 6 }}>
              <input className="input" style={{ maxWidth: 200 }} value={pname(profile)} maxLength={30} aria-label={nl ? 'Naam van deze indeling' : 'Name of this layout'}
                onChange={(e) => { const v = e.target.value.slice(0, 30); dirty.current = true; setCfg((c) => c && { ...c, profiles: c.profiles.map((p) => (p.id === c.active ? { ...p, name: v } : p)) }); }}
                onBlur={() => cfg && persist(cfg)} />
              <button className="btn ghost sm" onClick={() => commit((c) => { c.profiles = c.profiles.filter((p) => p.id !== c.active); c.active = c.profiles[0].id; return c; }, nl ? 'Indeling verwijderd' : 'Layout removed')}><Trash2 size={15} /> {nl ? 'Verwijder' : 'Delete'}</button>
            </div>
          )}
          {device !== 'phone' && (
            <p className="tiny muted" style={{ margin: 0 }}>
              {own ? (nl ? `Deze ${device === 'tablet' ? 'tablet' : 'computer'} heeft een eigen indeling.` : `This ${device === 'tablet' ? 'tablet' : 'computer'} has its own layout.`) : nl ? 'Wijzigingen hier gelden alleen voor dit soort scherm.' : 'Changes here only apply to this screen size.'}
              {own && <button className="link tiny" style={{ marginLeft: 6 }} onClick={() => commit((c) => { delete c.profiles.find((p) => p.id === c.active)!.layouts[device]; return c; })}>{nl ? 'Volg weer de telefoon' : 'Follow the phone layout again'}</button>}
            </p>
          )}
        </div>
      )}

      {!cfg ? (
        <div className="stack" style={{ marginTop: 20 }}>{[1, 2, 3].map((i) => <div key={i} className="skeleton" style={{ height: 96 }} />)}</div>
      ) : (
        <div className={`dash dev-${device} ${editing ? 'editing' : ''}`}>
          {(editing ? layout.filter((w) => !w.hidden) : visible).map((w) => {
            const d = def(w.type);
            if (!d) return null;
            const idx = layout.findIndex((x) => x.id === w.id);
            return (
              <section key={w.id} data-wid={w.id} className={`widget card s-${w.size} ${w.view} ${drag === w.id ? 'dragging' : ''} ${w.pinned ? 'pinned' : ''}`}
                onClickCapture={() => !editing && recordUse(`widget:${w.type}`)} aria-label={nl ? d.title[1] : d.title[0]}>
                <header className="w-head">
                  {editing && <span className="w-grip" onPointerDown={(e) => startDrag(e, w.id)} aria-hidden><GripVertical size={18} /></span>}
                  <span className="w-emoji" aria-hidden>{d.emoji}</span>
                  {editing ? <b className="grow ellipsis small">{nl ? d.title[1] : d.title[0]}</b> : <a className="grow ellipsis small w-title" href={WIDGET_LINK[w.type] ?? '#/'}><b>{nl ? d.title[1] : d.title[0]}</b></a>}
                  {w.pinned && !editing && <Pin size={13} className="muted" aria-label={nl ? 'Vastgezet' : 'Pinned'} />}
                  {!editing && WIDGET_LINK[w.type] && <a className="w-more" href={WIDGET_LINK[w.type]} aria-label={nl ? 'Openen' : 'Open'}><ChevronRight size={16} /></a>}
                  {editing && <button className="icon-btn ghost w-remove" onClick={() => editLayout((l) => l.filter((x) => x.id !== w.id), nl ? 'Widget verwijderd' : 'Widget removed')} aria-label={`${nl ? 'Verwijder' : 'Remove'} ${nl ? d.title[1] : d.title[0]}`} title={nl ? 'Verwijderen' : 'Remove'}><X size={16} /></button>}
                </header>
                {editing ? (
                  <div className="w-tools">
                    <button className="icon-btn" onClick={() => move(w.id, idx - 1)} disabled={idx === 0} aria-label={nl ? 'Omhoog' : 'Move up'}><ChevronUp size={16} /></button>
                    <button className="icon-btn" onClick={() => move(w.id, idx + 1)} disabled={idx === layout.length - 1} aria-label={nl ? 'Omlaag' : 'Move down'}><ChevronDown size={16} /></button>
                    <button className={`btn ghost sm ${tools === w.id ? 'on' : ''}`} onClick={() => setTools(tools === w.id ? null : w.id)} aria-expanded={tools === w.id}>{nl ? 'Opties' : 'Options'}</button>
                    {tools === w.id && (
                      <div className="w-tools-more">
                        <div className="seg mini" role="group" aria-label={nl ? 'Grootte' : 'Size'}>
                          {d.sizes.map((s: Size) => <button key={s} className={w.size === s ? 'on' : ''} onClick={() => patchW(w.id, { size: s })} aria-pressed={w.size === s}>{({ s: nl ? 'Klein' : 'Small', m: nl ? 'Middel' : 'Medium', l: nl ? 'Groot' : 'Large' } as const)[s]}</button>)}
                        </div>
                        <button className="icon-btn" onClick={() => patchW(w.id, { view: w.view === 'compact' ? 'expanded' : 'compact' })} aria-label={w.view === 'compact' ? (nl ? 'Uitgebreid' : 'Expanded') : 'Compact'} title={w.view === 'compact' ? (nl ? 'Uitgebreid' : 'Expanded') : 'Compact'}>{w.view === 'compact' ? <Maximize2 size={15} /> : <Minimize2 size={15} />}</button>
                        <button className={`icon-btn ${w.pinned ? 'on' : ''}`} onClick={() => patchW(w.id, { pinned: !w.pinned })} aria-pressed={!!w.pinned} aria-label={nl ? 'Vastzetten bovenaan' : 'Pin to top'} title={nl ? 'Vastzetten' : 'Pin'}><Pin size={15} /></button>
                        <button className="icon-btn" onClick={() => patchW(w.id, { hidden: true })} aria-label={nl ? 'Verbergen' : 'Hide'} title={nl ? 'Verbergen' : 'Hide'}><EyeOff size={15} /></button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="w-body"><WidgetBody type={w.type} d={data.data?.[w.type]} compact={w.view === 'compact'} size={w.size} /></div>
                )}
              </section>
            );
          })}
          {editing && layout.some((w) => w.hidden) && (
            <div className="card pad s-l hidden-tray">
              <b className="small">{nl ? 'Verborgen' : 'Hidden'}</b>
              <div className="row wrap" style={{ gap: 6, marginTop: 6 }}>
                {layout.filter((w) => w.hidden).map((w) => <button key={w.id} className="chip" onClick={() => patchW(w.id, { hidden: false })}><Eye size={14} /> {def(w.type)?.emoji} {nl ? def(w.type)?.title[1] : def(w.type)?.title[0]}</button>)}
              </div>
            </div>
          )}
          {!editing && visible.length > 0 && (
            <button className="link dash-customise" onClick={() => setEditing(true)}><Pencil size={14} /> {nl ? 'Startscherm aanpassen' : 'Customise Home'}</button>
          )}
          {!visible.length && !editing && (
            <div className="card pad s-l" style={{ textAlign: 'center' }}>
              <p className="small">{nl ? 'Je startscherm is leeg.' : 'Your home screen is empty.'}</p>
              <button className="btn soft sm" onClick={() => { setEditing(true); setSheet('add'); }}><Plus size={15} /> {nl ? 'Widget toevoegen' : 'Add a widget'}</button>
            </div>
          )}
        </div>
      )}

      {sheet === 'add' && <AddWidgetSheet catalogue={catalogue} have={layout.map((w) => w.type)} onAdd={(t) => addWidget(t)} onClose={() => setSheet(null)} />}
      {sheet === 'presets' && dash.data && <PresetSheet presets={dash.data.presets} catalogue={catalogue} current={profile?.preset} onPick={usePreset} onClose={() => setSheet(null)} />}
    </>
  );
}

const GROUPS: [string, string, string][] = [['groceries', 'Groceries', 'Boodschappen'], ['recipes', 'Recipes & cooking', 'Recepten & koken'], ['planning', 'Meal planning', 'Planning'], ['nutrition', 'Nutrition', 'Voeding'], ['game', 'Progress', 'Voortgang'], ['stats', 'Statistics', 'Statistieken']];

function AddWidgetSheet({ catalogue, have, onAdd, onClose }: { catalogue: any[]; have: string[]; onAdd: (t: string) => void; onClose: () => void }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const [preview, setPreview] = useState<string | null>(null);
  const pd = useQuery<any>(preview ? `/api/dashboard/data?types=${preview}` : null, DATA_SCOPES);
  return (
    <Sheet title={nl ? 'Widget toevoegen' : 'Add a widget'} onClose={onClose}>
      {GROUPS.map(([g, en, nlL]) => (
        <div key={g}>
          <div className="section-head"><h2>{nl ? nlL : en}</h2></div>
          <div className="list">
            {catalogue.filter((w) => w.group === g).map((w) => (
              <div key={w.type} className="item lib-item">
                <span className="thumb">{w.emoji}</span>
                <button className="grow lib-text" onClick={() => setPreview(preview === w.type ? null : w.type)} aria-expanded={preview === w.type}>
                  <div className="title">{nl ? w.title[1] : w.title[0]}{have.includes(w.type) && <span className="pill" style={{ marginLeft: 6 }}>{nl ? 'staat erop' : 'on Home'}</span>}</div>
                  <div className="meta">{nl ? w.desc[1] : w.desc[0]} · <u>{preview === w.type ? (nl ? 'verberg voorbeeld' : 'hide preview') : nl ? 'voorbeeld' : 'preview'}</u></div>
                </button>
                <button className="btn soft sm" onClick={() => onAdd(w.type)} aria-label={`${nl ? 'Toevoegen' : 'Add'} ${w.title[0]}`}><Plus size={15} /></button>
                {preview === w.type && (
                  <div className="lib-preview widget card s-m expanded"><WidgetBody type={w.type} d={pd.data?.[w.type]} compact={false} size={w.size} /></div>
                )}
              </div>
            ))}
          </div>
        </div>
      ))}
    </Sheet>
  );
}

function PresetSheet({ presets, catalogue, current, onPick, onClose }: { presets: any[]; catalogue: any[]; current?: string; onPick: (id: string, asNew: boolean) => void; onClose: () => void }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const emoji = (t: string) => catalogue.find((w) => w.type === t)?.emoji ?? '·';
  return (
    <Sheet title={nl ? 'Kant-en-klare indelingen' : 'Ready-made layouts'} onClose={onClose}>
      <p className="small muted">{nl ? 'Kies er een en pas hem daarna aan. Je kunt altijd terug met Ongedaan maken.' : 'Pick one and adjust it after. Undo always takes you back.'}</p>
      <div className="presets">
        {presets.map((p) => (
          <div key={p.id} className={`card pad preset ${current === p.id ? 'on' : ''}`}>
            <div className="row" style={{ gap: 8 }}><span style={{ fontSize: 22 }}>{p.emoji}</span><b className="grow">{nl ? p.title[1] : p.title[0]}</b></div>
            <p className="tiny muted" style={{ margin: '4px 0 8px' }}>{nl ? p.desc[1] : p.desc[0]}</p>
            <div className="preset-mini">{p.widgets.map((w: any, i: number) => <span key={i} className={`s-${w.size}`}>{emoji(w.type)}</span>)}</div>
            <div className="row" style={{ gap: 6, marginTop: 8 }}>
              <button className="btn primary sm" onClick={() => onPick(p.id, false)}>{nl ? 'Gebruik hier' : 'Use here'}</button>
              <button className="btn ghost sm" onClick={() => onPick(p.id, true)}>{nl ? 'Als nieuwe' : 'As new layout'}</button>
            </div>
          </div>
        ))}
      </div>
    </Sheet>
  );
}
