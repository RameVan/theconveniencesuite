import { useState } from 'react';
import { useQuery } from '../api';
import { useApp } from '../app-context';
import { useT, fmtQty } from '../i18n';
import { YearInFood } from '../components/YearInFood';
import { useShowMoney } from '../appearance';

const SOURCE: Record<string, [string, string]> = {
  receipt: ['Receipt', 'Bon'], voice: ['Voice', 'Spraak'], shopping_list: ['Shopping list', 'Boodschappenlijst'], recipe: ['Cooking', 'Koken'], manual: ['Manual', 'Handmatig'],
  barcode: ['Barcode', 'Barcode'], assistant_ai: ['AI assistant', 'AI-assistent'], device: ['Device', 'Apparaat'], system: ['System', 'Systeem'],
};

export function InsightsPage() {
  const app = useApp();
  const t = useT();
  const nl = app.lang === 'nl';
  const [days, setDays] = useState(90);
  const { data } = useQuery<any>(`/api/analytics?days=${days}`, ['inventory', 'receipts']);
  const max = Math.max(1, ...(data?.weekly ?? []).map((w: any) => w.total));
  const inputTotal = (data?.inputs ?? []).reduce((s: number, x: any) => s + x.events, 0);
  const [showMoney, setShowMoney] = useShowMoney();
  return (
    <>
      <div className="topbar"><div className="grow"><h1>{t('Insights')}</h1></div>
        <select className="select" style={{ width: 'auto', minHeight: 38 }} value={days} onChange={(e) => setDays(Number(e.target.value))}>
          {[30, 90, 365].map((d) => <option key={d} value={d}>{d} {nl ? 'dagen' : 'days'}</option>)}
        </select>
      </div>
      <YearInFood />
      <div className="section-head">
        <h2>{nl ? 'Uitgaven en verspilling' : 'Spending & waste'}</h2>
        <label className="row small" style={{ gap: 8 }}>
          <span className="muted">{showMoney ? (nl ? 'Tonen' : 'Show') : nl ? 'Verborgen' : 'Hidden'}</span>
          <button className="switch" role="switch" aria-checked={showMoney} aria-label={nl ? 'Uitgaven en verspilling tonen' : 'Show spending & waste'} onClick={() => setShowMoney(!showMoney)} />
        </label>
      </div>
      {!showMoney && <p className="small muted" style={{ marginTop: 0 }}>{nl ? 'Uitgaven en verspilling staan uit. Zet ze hier of in Persoonlijk maken weer aan.' : 'Spending and waste are switched off. Turn them back on here or in Personalise.'}</p>}
      {!data ? <div className="skeleton" style={{ height: 200 }} /> : (
        <>
          {showMoney && <>
          <div className="stats">
            <div className="card stat"><div className="v num">€{Math.round(data.spent)}</div><div className="l">{nl ? 'Uitgegeven' : 'Spent'}</div></div>
            <div className="card stat"><div className="v num">€{(data.spent / Math.max(1, days / 7)).toFixed(0)}</div><div className="l">{nl ? 'Per week' : 'Per week'}</div></div>
            <div className="card stat"><div className="v num" style={{ color: data.wasted > 0 ? 'var(--tomato)' : undefined }}>€{data.wasted.toFixed(2)}</div><div className="l">{nl ? 'Weggegooid' : 'Wasted'}</div></div>
          </div>
          <div className="section-head"><h2>{nl ? 'Uitgaven per week' : 'Weekly spending'}</h2></div>
          <div className="card pad">
            <div className="bars" role="img" aria-label="weekly spending chart">
              {data.weekly.map((w: any) => (
                <div key={w.week} className="b" title={`${w.week}: €${w.total}`}>
                  <span className="num">{Math.round(w.total)}</span>
                  <i style={{ height: `${(w.total / max) * 100}%` }} />
                  <span>{w.week.slice(-3)}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="grid-2" style={{ marginTop: 6 }}>
            <div>
              <div className="section-head"><h2>{nl ? 'Meest gekocht' : 'Bought most often'}</h2></div>
              <div className="list">
                {data.topProducts.map((p: any) => (
                  <div key={p.product_id} className="item" style={{ minHeight: 48 }}><span className="grow">{p.name}</span><span className="muted small">{p.times}×</span><b className="num">€{p.spent.toFixed(2)}</b></div>
                ))}
              </div>
            </div>
            <div>
              <div className="section-head"><h2>{nl ? 'Verspilling' : 'Food waste'}</h2></div>
              {data.waste.length ? (
                <div className="list">
                  {data.waste.map((w: any) => (
                    <div key={w.name} className="item" style={{ minHeight: 48 }}><span className="grow">{w.name}</span><span className="muted small">{w.events}× · {fmtQty(w.quantity, w.unit, app.lang)}</span><b className="num">€{w.value.toFixed(2)}</b></div>
                  ))}
                </div>
              ) : <div className="card pad muted small">{nl ? 'Niets weggegooid. Top!' : 'Nothing thrown away. Great!'}</div>}
              {data.wasteReasons.length > 0 && <div className="row wrap small" style={{ marginTop: 8 }}>{data.wasteReasons.map((r: any) => <span key={r.reason} className="pill grey">{r.reason}: {r.events}</span>)}</div>}
            </div>
          </div>
          </>}
          <div className="section-head"><h2>{nl ? 'Hoe je voorraad wordt bijgehouden' : 'How your inventory gets updated'}</h2></div>
          <div className="card pad stack">
            {data.inputs.map((x: any) => (
              <div key={x.source} className="row small">
                <span style={{ width: 130 }}>{SOURCE[x.source]?.[nl ? 1 : 0] ?? x.source}</span>
                <div className="progress grow"><i style={{ width: `${(x.events / inputTotal) * 100}%` }} /></div>
                <span className="num muted" style={{ width: 40, textAlign: 'right' }}>{Math.round((x.events / inputTotal) * 100)}%</span>
              </div>
            ))}
            <div className="tiny muted">{nl ? 'Hoe meer via bonnen, koken en spraak, hoe minder je zelf hoeft te tikken.' : 'The more that comes from receipts, cooking and voice, the less you have to tap.'}</div>
          </div>
        </>
      )}
    </>
  );
}
