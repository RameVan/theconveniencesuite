import { useMemo, useState } from 'react';
import { Search, Plus, ReceiptText, ScanBarcode, History, Mic, MoreHorizontal, SlidersHorizontal, Minus } from 'lucide-react';
import { useQuery } from '../api';
import { useApp } from '../app-context';
import { useT, fmtQty, timeAgo } from '../i18n';
import { Empty, Sheet } from '../components/ui';
import { StockRow, LeftoverRow } from '../components/cards';
import { speechSupported } from '../components/Assistant';
import { GroceryTabs } from '../components/GroceryTabs';

type Sort = 'category' | 'expiry' | 'low' | 'recent';

/** Groceries → In stock. One job: keep what you have right, with as little effort as possible. */
export function InventoryPage() {
  const app = useApp();
  const t = useT();
  const nl = app.lang === 'nl';
  const { data } = useQuery<any>('/api/inventory', ['inventory']);
  const [loc, setLoc] = useState<string>('all');
  const [q, setQ] = useState('');
  const [sort, setSort] = useState<Sort>('category');
  const [filters, setFilters] = useState(false);
  const [more, setMore] = useState(false);
  const [history, setHistory] = useState(false);

  const all = useMemo(() => (data?.items ?? []).filter((s: any) => s.confirmed > 0), [data]);
  const soon = useMemo(() => all.filter((s: any) => s.daysToExpiry != null && s.daysToExpiry <= 3).sort((a: any, b: any) => a.daysToExpiry - b.daysToExpiry), [all]);
  const items = useMemo(() => {
    let xs: any[] = all;
    if (loc !== 'all') xs = xs.filter((s) => s.lots.some((l: any) => l.location_kind === loc));
    if (q.trim()) {
      const n = q.toLowerCase();
      xs = xs.filter((s) => [s.product.name, s.product.name_nl, ...s.product.synonyms].some((x: string) => x?.toLowerCase().includes(n)));
    }
    if (sort === 'expiry') xs = [...xs].sort((a, b) => (a.daysToExpiry ?? 999) - (b.daysToExpiry ?? 999));
    if (sort === 'low') xs = [...xs].sort((a, b) => (a.daysLeft ?? 999) - (b.daysLeft ?? 999));
    if (sort === 'recent') xs = [...xs].sort((a, b) => (b.lastPurchaseAt ?? '').localeCompare(a.lastPurchaseAt ?? ''));
    return xs;
  }, [all, loc, q, sort]);

  const groups = useMemo(() => {
    if (sort !== 'category') return [{ key: sort, label: '', items }];
    const m = new Map<string, any[]>();
    for (const s of items) m.set(s.product.category, [...(m.get(s.product.category) ?? []), s]);
    const cats = app.config?.categories ?? {};
    return [...m.entries()].sort((a, b) => (cats[a[0]]?.order ?? 99) - (cats[b[0]]?.order ?? 99)).map(([key, items]) => ({ key, label: cats[key]?.[app.lang] ?? key, items }));
  }, [items, sort, app.config, app.lang]);

  const leftovers = (data?.leftovers ?? []).filter((l: any) => loc === 'all' || l.location_kind === loc);
  const filtering = loc !== 'all' || sort !== 'category';
  const browsing = !q.trim() && !filtering;

  return (
    <>
      <div className="topbar">
        <div className="grow"><h1>{nl ? 'Boodschappen' : 'Groceries'}</h1></div>
        <button className="icon-btn" onClick={() => setMore(true)} aria-label={nl ? 'Meer' : 'More'}><MoreHorizontal /></button>
      </div>
      <GroceryTabs current="stock" />

      {/* The one main action: add (or use) something, by voice or by typing. */}
      <div className="g-add">
        <button className="btn primary g-add-main" onClick={() => app.openQuick({ mode: 'add' })}><Plus size={18} /> {nl ? 'Toevoegen' : 'Add groceries'}</button>
        {speechSupported && <button className="btn g-add-icon" onClick={() => app.openBoughtList({ listen: true })} aria-label={nl ? 'Inspreken wat je kocht' : 'Say what you bought'}><Mic size={18} /></button>}
        <button className="btn g-add-icon" onClick={() => app.openQuick({ mode: 'use' })} aria-label={nl ? 'Iets gebruiken' : 'Use something'}><Minus size={18} /></button>
      </div>

      {browsing && soon.length > 0 && (
        <>
          <div className="section-head"><h2>{nl ? 'Eerst opmaken' : 'Use soon'}</h2></div>
          <div className="list">{soon.slice(0, 5).map((s: any) => <StockRow key={s.product.id} s={s} />)}</div>
        </>
      )}

      <div className="row" style={{ gap: 8, marginTop: 18 }}>
        <div className="search grow"><Search /><input className="input" value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('Search inventory')} aria-label={t('Search inventory')} /></div>
        <button className={`icon-btn ${filtering ? 'on' : ''}`} onClick={() => setFilters((f) => !f)} aria-expanded={filters} aria-label={nl ? 'Filteren en sorteren' : 'Filter and sort'}><SlidersHorizontal size={18} /></button>
      </div>
      {filters && (
        <div className="g-filters">
          <div className="loc-tabs" role="tablist" aria-label={nl ? 'Bewaarplek' : 'Storage location'}>
            {[['all', t('All')], ['fridge', t('Fridge')], ['freezer', t('Freezer')], ['pantry', t('Pantry')]].map(([id, label]) => (
              <button key={id} aria-pressed={loc === id} onClick={() => setLoc(id)}>{label}</button>
            ))}
          </div>
          <div className="chips">
            {([['category', nl ? 'Per categorie' : 'By aisle'], ['expiry', nl ? 'Eerst op' : 'Use first'], ['low', nl ? 'Raakt op' : 'Running out'], ['recent', nl ? 'Net gekocht' : 'Recently bought']] as [Sort, string][]).map(([id, label]) => (
              <button key={id} className="chip" aria-pressed={sort === id} onClick={() => setSort(id)}>{label}</button>
            ))}
          </div>
        </div>
      )}

      {!data && <div className="stack" style={{ marginTop: 16 }}>{[1, 2, 3, 4].map((i) => <div key={i} className="skeleton" style={{ height: 62 }} />)}</div>}
      {data && !items.length && !leftovers.length && (
        <Empty art="🧺" title={q ? (nl ? 'Niets gevonden' : 'Nothing found') : nl ? 'Hier is nog niets' : 'Nothing here yet'}>
          <p className="small">{nl ? 'Tik op Toevoegen, scan een bon, of zeg “ik heb melk en eieren gekocht”.' : 'Tap Add, scan a receipt, or say “I bought milk and eggs”.'}</p>
        </Empty>
      )}

      {leftovers.length > 0 && (
        <>
          <div className="section-head"><h2>{t('Leftovers')}</h2></div>
          <div className="list">{leftovers.map((l: any) => <LeftoverRow key={l.id} l={l} />)}</div>
        </>
      )}

      {groups.map((g) => g.items.length > 0 && (
        <section key={g.key}>
          {g.label && <div className="section-head"><h2>{g.label}</h2><span className="tiny muted">{g.items.length}</span></div>}
          <div className="list" style={{ marginTop: g.label ? 0 : 14 }}>{g.items.map((s: any) => <StockRow key={s.product.id} s={s} />)}</div>
        </section>
      ))}

      {more && (
        <Sheet title={nl ? 'Meer' : 'More'} onClose={() => setMore(false)}>
          <div className="list">
            <button className="item" onClick={() => { setMore(false); app.openReceipt(); }}><span className="thumb"><ReceiptText size={20} /></span><span className="grow title">{t('Scan receipt')}</span></button>
            <button className="item" onClick={() => { setMore(false); app.openBarcode(); }}><span className="thumb"><ScanBarcode size={20} /></span><span className="grow title">{t('Scan barcode')}</span></button>
            <button className="item" onClick={() => { setMore(false); setHistory(true); }}><span className="thumb"><History size={20} /></span><span className="grow title">{nl ? 'Alle wijzigingen' : 'Every change'}</span></button>
          </div>
        </Sheet>
      )}
      {history && <HistorySheet onClose={() => setHistory(false)} />}
    </>
  );
}

/** The ledger, only fetched when you open it. */
function HistorySheet({ onClose }: { onClose: () => void }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const events = useQuery<any[]>('/api/inventory/events?limit=60', ['inventory']);
  return (
    <Sheet title={nl ? 'Alle wijzigingen' : 'Every change'} onClose={onClose}>
      <div className="list">
        {(events.data ?? []).map((e: any) => (
          <div key={e.id} className="item small" style={{ minHeight: 44 }}>
            <span className="grow ellipsis"><b>{(nl ? e.product_name_nl : null) ?? e.product_name ?? e.lot_label}</b> <span className="muted">{e.type}{e.reason ? ` · ${e.reason}` : ''}</span></span>
            <span className="num">{e.delta > 0 ? '+' : e.delta < 0 ? '−' : ''}{e.delta ? fmtQty(Math.abs(e.delta), e.unit, app.lang) : '·'}</span>
            <span className="tiny muted" style={{ width: 52, textAlign: 'right' }}>{timeAgo(e.created_at, app.lang)}</span>
          </div>
        ))}
      </div>
    </Sheet>
  );
}
