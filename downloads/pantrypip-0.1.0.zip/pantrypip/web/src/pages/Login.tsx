import { useState } from 'react';
import { post } from '../api';

export function LoginPage({ onDone }: { onDone: () => void }) {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [invite, setInvite] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const nl = navigator.language.toLowerCase().startsWith('nl');

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      if (mode === 'login') await post('/api/auth/login', { email, password });
      else await post('/api/auth/register', { email, password, name, inviteCode: invite || null });
      onDone();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="login">
      <form className="card" onSubmit={submit}>
        <div className="row"><img src="/icon.svg" alt="" width={44} height={44} /><h1>PantryPip</h1></div>
        <p className="muted" style={{ margin: 0 }}>{nl ? 'Je boodschappen, maaltijden en lijstje. Bijgehouden voor je.' : 'Your groceries, meals and shopping list. Kept up to date for you.'}</p>
        {mode === 'register' && (
          <label className="field">{nl ? 'Naam' : 'Name'}<input className="input" value={name} onChange={(e) => setName(e.target.value)} required autoComplete="name" /></label>
        )}
        <label className="field">Email<input className="input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="email" /></label>
        <label className="field">{nl ? 'Wachtwoord' : 'Password'}<input className="input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={mode === 'register' ? 10 : 1} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} /></label>
        {mode === 'register' && (
          <label className="field">{nl ? 'Uitnodigingscode (optioneel, om een huishouden te delen)' : 'Invite code (optional, to share a household)'}<input className="input" value={invite} onChange={(e) => setInvite(e.target.value)} /></label>
        )}
        {error && <div className="pill tomato" style={{ padding: '8px 12px' }}>{error}</div>}
        <button className="btn primary lg" disabled={busy}>{mode === 'login' ? (nl ? 'Inloggen' : 'Sign in') : nl ? 'Account maken' : 'Create account'}</button>
        <button type="button" className="btn ghost" onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>
          {mode === 'login' ? (nl ? 'Nieuw hier? Maak een account' : 'New here? Create an account') : nl ? 'Ik heb al een account' : 'I already have an account'}
        </button>
      </form>
    </div>
  );
}
