import { useEffect, useRef, useState } from 'react';
import { MailCheck, Hourglass } from 'lucide-react';
import { Logo } from '../components/Logo';
import { get, post } from '../api';

/** An invite in the link that opened the app: a friend's link (#/friends?friend=CODE) or #/?invite=CODE. */
const inviteFromHash = () => location.hash.match(/[?&](?:friend|invite)=([A-Za-z0-9-]+)/)?.[1] ?? '';

type Mode = 'login' | 'register' | 'forgot' | 'sent' | 'confirm' | 'reset' | 'request' | 'requested' | 'access';
type LinkKind = 'confirm' | 'reset' | 'access';

/** Links from emails open #/confirm/<token> (new account), #/reset/<token> (new password) or #/access/<token> (an approved access request). */
export const linkFromHash = (hash = location.hash): { kind: LinkKind; token: string } | null => {
  const m = hash.match(/^#\/(confirm|reset|access)\/([A-Za-z0-9_-]{20,100})$/);
  return m ? { kind: m[1] as LinkKind, token: m[2] } : null;
};
const leaveLink = () => history.replaceState(null, '', location.pathname + location.search);

export function LoginPage({ onDone }: { onDone: () => void }) {
  const link = useRef(linkFromHash()).current;
  // Someone opening an invite link is new here: start on "create account" with the code filled in.
  const invited = useRef(inviteFromHash()).current;
  const [mode, setMode] = useState<Mode>(link?.kind ?? (invited ? 'register' : 'login'));
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [note, setNote] = useState('');
  const [invite, setInvite] = useState(invited);
  const [inviteOnly, setInviteOnly] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sentFor, setSentFor] = useState<'register' | 'forgot'>('register');
  const [busy, setBusy] = useState(false);
  const [linkOk, setLinkOk] = useState<boolean | null>(null);
  const nl = navigator.language.toLowerCase().startsWith('nl');
  const lang = nl ? 'nl' : 'en';

  useEffect(() => {
    get<{ inviteOnly?: boolean }>('/api/config').then((c) => setInviteOnly(!!c.inviteOnly)).catch(() => {});
  }, []);

  // Opening a confirmation link makes the account and signs you in. A reset link is checked first.
  useEffect(() => {
    if (link?.kind === 'confirm') {
      post('/api/auth/confirm', { token: link.token })
        .then(() => (leaveLink(), onDone()))
        .catch((e) => (setLinkOk(false), setError(e.message)));
    } else if (link?.kind === 'reset') {
      post<{ valid: boolean }>('/api/auth/reset/check', { token: link.token }).then((r) => setLinkOk(r.valid)).catch(() => setLinkOk(false));
    } else if (link?.kind === 'access') {
      // An approved request: the address is the one it was approved for, so it's filled in and can't be changed.
      post<{ valid: boolean; email?: string; name?: string }>('/api/auth/access/check', { token: link.token })
        .then((r) => {
          setLinkOk(r.valid);
          if (r.valid) (setEmail(r.email!), setName(r.name!));
        })
        .catch(() => setLinkOk(false));
    }
  }, []);

  const go = (m: Mode) => {
    if (link) leaveLink();
    setError(null);
    setMode(m);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      if (mode === 'login') {
        await post('/api/auth/login', { email, password });
        onDone();
      } else if (mode === 'register') {
        const r = await post<{ confirm?: boolean }>('/api/auth/register', { email, password, name, inviteCode: invite || null, lang });
        if (r?.confirm) (setSentFor('register'), setMode('sent'));
        else onDone();
      } else if (mode === 'forgot') {
        await post('/api/auth/forgot', { email, lang });
        setSentFor('forgot');
        setMode('sent');
      } else if (mode === 'request') {
        await post('/api/auth/access-request', { name, email, note: note || null, lang });
        setMode('requested');
      } else if (mode === 'access' && link) {
        await post('/api/auth/access', { token: link.token, name, password });
        leaveLink();
        onDone();
      } else if (mode === 'reset' && link) {
        await post('/api/auth/reset', { token: link.token, password });
        leaveLink();
        onDone();
      }
    } catch (err: any) {
      const known: Record<string, [string, string]> = {
        invite_required: ['PantryPip is invite only. Ask someone who uses it for their invite link or code.', 'PantryPip werkt alleen op uitnodiging. Vraag iemand die het gebruikt om een uitnodigingslink of -code.'],
        rate_limited: ['Too many tries. Wait a few minutes and try again.', 'Te vaak geprobeerd. Wacht een paar minuten en probeer het opnieuw.'],
        link_expired: ['This link has expired or was already used. Ask for access again.', 'Deze link is verlopen of al gebruikt. Vraag opnieuw toegang aan.'],
        email_taken: ['This address already has an account. Sign in instead.', 'Dit adres heeft al een account. Log in.'],
        invalid_invite: ['That invite code doesn’t work. Check it, or ask for a new link.', 'Die uitnodigingscode werkt niet. Controleer hem, of vraag om een nieuwe link.'],
      };
      setError(known[err.code]?.[nl ? 1 : 0] ?? err.message);
    } finally {
      setBusy(false);
    }
  };

  const head = (
    <>
      <div className="row"><Logo size={44} /><h1>PantryPip</h1></div>
    </>
  );

  if (mode === 'sent')
    return (
      <div className="login">
        <div className="card">
          {head}
          <div className="row" style={{ gap: 10 }}><MailCheck size={22} aria-hidden /><b>{nl ? 'Kijk in je mail' : 'Check your email'}</b></div>
          <p className="muted" style={{ margin: 0 }}>
            {sentFor === 'register'
              ? nl ? `We stuurden een link naar ${email}. Open die om je account te maken. De link werkt 48 uur.` : `We sent a link to ${email}. Open it to create your account. The link works for 48 hours.`
              : nl ? `Als ${email} een account heeft, staat er een link in je mail om een nieuw wachtwoord te kiezen. De link werkt een uur.` : `If ${email} has an account, there's a link in your email to choose a new password. The link works for an hour.`}
          </p>
          <p className="muted" style={{ margin: 0, fontSize: 13 }}>{nl ? 'Niets gekregen? Kijk ook bij spam, of probeer het opnieuw.' : "Nothing arrived? Check your spam folder, or try again."}</p>
          <button type="button" className="btn ghost" onClick={() => go(sentFor === 'register' ? 'register' : 'forgot')}>{nl ? 'Opnieuw versturen' : 'Send again'}</button>
          <button type="button" className="btn ghost" onClick={() => go('login')}>{nl ? 'Terug naar inloggen' : 'Back to sign in'}</button>
        </div>
      </div>
    );

  if (mode === 'confirm')
    return (
      <div className="login">
        <div className="card" aria-busy={!error}>
          {head}
          <p className="muted" style={{ margin: 0 }}>{error ?? (nl ? 'Je account wordt gemaakt…' : 'Creating your account…')}</p>
          {error && <button type="button" className="btn primary lg" onClick={() => go('register')}>{nl ? 'Opnieuw aanmelden' : 'Sign up again'}</button>}
          {error && <button type="button" className="btn ghost" onClick={() => go('login')}>{nl ? 'Ik heb al een account' : 'I already have an account'}</button>}
        </div>
      </div>
    );

  if (mode === 'requested')
    return (
      <div className="login">
        <div className="card">
          {head}
          <div className="row" style={{ gap: 10 }}><Hourglass size={22} aria-hidden /><b>{nl ? 'Aanvraag verstuurd' : 'Request sent'}</b></div>
          <p className="muted" style={{ margin: 0 }}>{nl ? `Bedankt, ${name}. Wordt je aanvraag goedgekeurd, dan krijg je op ${email} een link om je account te maken. De link werkt 7 dagen.` : `Thanks, ${name}. If your request is approved, you'll get a link at ${email} to create your account. The link works for 7 days.`}</p>
          <button type="button" className="btn ghost" onClick={() => go('login')}>{nl ? 'Terug naar inloggen' : 'Back to sign in'}</button>
        </div>
      </div>
    );

  if (mode === 'access' && linkOk === false)
    return (
      <div className="login">
        <div className="card">
          {head}
          <p className="muted" style={{ margin: 0 }}>{nl ? 'Deze link is verlopen of al gebruikt. Vraag opnieuw toegang aan, of log in als je je account al hebt gemaakt.' : 'This link has expired or was already used. Ask for access again, or sign in if you already made your account.'}</p>
          <button type="button" className="btn primary lg" onClick={() => go('request')}>{nl ? 'Opnieuw toegang vragen' : 'Request access again'}</button>
          <button type="button" className="btn ghost" onClick={() => go('login')}>{nl ? 'Terug naar inloggen' : 'Back to sign in'}</button>
        </div>
      </div>
    );

  if (mode === 'reset' && linkOk === false)
    return (
      <div className="login">
        <div className="card">
          {head}
          <p className="muted" style={{ margin: 0 }}>{nl ? 'Deze link is verlopen of al gebruikt. Vraag een nieuwe aan.' : 'This link has expired or was already used. Ask for a new one.'}</p>
          <button type="button" className="btn primary lg" onClick={() => go('forgot')}>{nl ? 'Nieuwe link' : 'Send a new link'}</button>
          <button type="button" className="btn ghost" onClick={() => go('login')}>{nl ? 'Terug naar inloggen' : 'Back to sign in'}</button>
        </div>
      </div>
    );

  const title = { login: null, register: null, forgot: nl ? 'Wachtwoord vergeten' : 'Forgot your password?', reset: nl ? 'Kies een nieuw wachtwoord' : 'Choose a new password', request: nl ? 'Toegang vragen' : 'Request access', access: nl ? 'Maak je account' : 'Create your account' }[mode as 'login'];
  return (
    <div className="login">
      <form className="card" onSubmit={submit}>
        {head}
        {title ? <b>{title}</b> : <p className="muted" style={{ margin: 0 }}>{nl ? 'Je boodschappen, maaltijden en lijstje. Bijgehouden voor je.' : 'Your groceries, meals and shopping list. Kept up to date for you.'}</p>}
        {mode === 'forgot' && <p className="muted" style={{ margin: 0 }}>{nl ? 'Vul je e-mailadres in. We sturen je een link om een nieuw wachtwoord te kiezen.' : "Enter your email address. We'll send you a link to choose a new password."}</p>}
        {mode === 'request' && <p className="muted" style={{ margin: 0 }}>{nl ? 'PantryPip werkt op uitnodiging. Laat je naam en e-mailadres achter; wordt je aanvraag goedgekeurd, dan krijg je een link om een account te maken.' : 'PantryPip is invite only. Leave your name and email; if your request is approved, you’ll get a link to create an account.'}</p>}
        {mode === 'access' && <p className="muted" style={{ margin: 0 }}>{nl ? 'Je aanvraag is goedgekeurd. Kies een wachtwoord om je account te maken.' : 'Your request was approved. Choose a password to create your account.'}</p>}
        {(mode === 'register' || mode === 'request' || mode === 'access') && (
          <label className="field">{nl ? 'Naam' : 'Name'}<input className="input" value={name} onChange={(e) => setName(e.target.value)} required maxLength={60} autoComplete="name" /></label>
        )}
        {mode !== 'reset' && <label className="field">Email<input className="input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete={mode === 'access' ? 'username' : 'email'} readOnly={mode === 'access'} style={mode === 'access' ? { color: 'var(--ink-3)' } : undefined} /></label>}
        {mode === 'request' && (
          <label className="field">{nl ? 'Opmerking (optioneel)' : 'Note (optional)'}
            <textarea className="input" rows={2} value={note} onChange={(e) => setNote(e.target.value)} maxLength={300} placeholder={nl ? 'Bijv. hoe je PantryPip kent' : 'E.g. how you heard of PantryPip'} />
          </label>
        )}
        {mode !== 'forgot' && mode !== 'request' && (
          <label className="field">{mode === 'reset' ? (nl ? 'Nieuw wachtwoord (minstens 10 tekens)' : 'New password (at least 10 characters)') : mode === 'access' ? (nl ? 'Wachtwoord (minstens 10 tekens)' : 'Password (at least 10 characters)') : nl ? 'Wachtwoord' : 'Password'}
            <input className="input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={mode === 'login' ? 1 : 10} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} />
          </label>
        )}
        {mode === 'login' && <button type="button" className="btn ghost sm" style={{ alignSelf: 'flex-end', marginTop: -6 }} onClick={() => go('forgot')}>{nl ? 'Wachtwoord vergeten?' : 'Forgot password?'}</button>}
        {mode === 'register' && (
          <label className="field">
            {inviteOnly ? (nl ? 'Uitnodigingscode of -link' : 'Invite code or link') : nl ? 'Uitnodigingscode (optioneel, om een huishouden te delen)' : 'Invite code (optional, to share a household)'}
            <input className="input" value={invite} onChange={(e) => setInvite(e.target.value)} required={inviteOnly} autoCapitalize="characters" spellCheck={false} />
            {inviteOnly && <span className="tiny muted" style={{ fontWeight: 400 }}>{nl ? 'PantryPip werkt op uitnodiging. Met de vriendencode van iemand krijg je je eigen huishouden en zijn jullie meteen vrienden; met de code van een huishouden doe je mee in dat huishouden.' : 'PantryPip is invite only. A friend’s code gives you your own household and makes you friends straight away; a household’s code lets you join that household.'}</span>}
          </label>
        )}
        {mode === 'register' && inviteOnly && <button type="button" className="btn ghost sm" style={{ alignSelf: 'flex-start', marginTop: -6 }} onClick={() => go('request')}>{nl ? 'Geen uitnodiging? Vraag toegang' : 'No invite? Request access'}</button>}
        {error && <div className="pill tomato" style={{ padding: '8px 12px' }}>{error}</div>}
        <button className="btn primary lg" disabled={busy || ((mode === 'reset' || mode === 'access') && linkOk !== true)}>
          {{ login: nl ? 'Inloggen' : 'Sign in', register: nl ? 'Account maken' : 'Create account', forgot: nl ? 'Stuur link' : 'Send link', reset: nl ? 'Wachtwoord opslaan' : 'Save password', request: nl ? 'Toegang vragen' : 'Request access', access: nl ? 'Account maken' : 'Create account' }[mode as 'login']}
        </button>
        {mode === 'login' || mode === 'register' ? (
          <button type="button" className="btn ghost" onClick={() => go(mode === 'login' ? 'register' : 'login')}>
            {mode === 'login' ? (nl ? 'Nieuw hier? Maak een account' : 'New here? Create an account') : nl ? 'Ik heb al een account' : 'I already have an account'}
          </button>
        ) : (
          <button type="button" className="btn ghost" onClick={() => go('login')}>{nl ? 'Terug naar inloggen' : 'Back to sign in'}</button>
        )}
        {mode === 'login' && inviteOnly && <button type="button" className="btn ghost" onClick={() => go('request')}>{nl ? 'Geen uitnodiging? Vraag toegang' : 'No invite? Request access'}</button>}
      </form>
    </div>
  );
}
