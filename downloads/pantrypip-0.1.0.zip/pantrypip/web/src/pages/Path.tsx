import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { Lock, BarChart3, Lightbulb, Check, Star, Gift, Flag, ChevronRight, RefreshCw, Pencil } from 'lucide-react';
import { useQuery, post, put, del, invalidate } from '../api';
import { useApp } from '../app-context';
import { Empty, Sheet, useToast } from '../components/ui';
import { Pip } from '../components/Pip';
import { FriendsTab, codeFromHash } from './Friends';
import { PipVisits } from './FriendsPlay';

const DAY = { en: ['M', 'T', 'W', 'T', 'F', 'S', 'S'], nl: ['M', 'D', 'W', 'D', 'V', 'Z', 'Z'] };
const STREAKS: [string, string, string, string][] = [
  ['cooking', '🔥', 'Cooking', 'Koken'], ['nutrition', '⚖️', 'Balanced', 'Gebalanceerd'], ['exploration', '🧭', 'New recipes', 'Nieuwe recepten'], ['lowWaste', '♻️', 'Low waste', 'Weinig verspilling'], ['planning', '🗓️', 'Planning', 'Plannen'],
];
const UNIT: Record<string, [string, string]> = { days: ['days', 'dagen'], weeks: ['weeks', 'weken'] };
// Scenery for each chapter's world (decorative only).
const SCENERY: Record<string, string[]> = {
  tiles: ['🫖', '🧂', '🪴', '🍞', '🥄', '🧈'], market: ['🧺', '🍋', '🥬', '🍅', '🧅', '⛱️'], home: ['🕯️', '🍳', '🪟', '🥖', '🫕', '🧦'],
  world: ['🗺️', '🌶️', '🍜', '🌮', '🍣', '🧭'], garden: ['🌿', '🥦', '🍎', '🌻', '🫛', '🐝'], studio: ['🔪', '🥘', '📋', '🧄', '🍷', '⏱️'], hall: ['👑', '✨', '🏆', '🥂', '🎻', '🌟'],
};
const WAVE = [0, 0.6, 0.95, 0.6, 0, -0.6, -0.95, -0.6];
const ROW = 96;

/** Respect the device setting and the in-app animation preference. */
export const reducedMotion = () => document.documentElement.dataset.motion === 'off' || document.documentElement.dataset.motion === 'reduced' || matchMedia('(prefers-reduced-motion: reduce)').matches;

/** Counts a number up smoothly (instantly with reduced motion). */
export function useCountUp(target: number, from = target, ms = 900) {
  const [v, setV] = useState(from);
  useEffect(() => {
    if (reducedMotion() || from === target) return setV(target);
    let raf = 0;
    const t0 = performance.now();
    const step = (t: number) => {
      const p = Math.min(1, (t - t0) / ms);
      setV(Math.round(from + (target - from) * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target, from, ms]);
  return v;
}

/** Small home card: streak, level and the next journey step. */
export function PathCard() {
  const app = useApp();
  const nl = app.lang === 'nl';
  const { data: g } = useQuery<any>('/api/game', ['game', 'recipes', 'planner', 'preferences']);
  const { data: j } = useQuery<any>('/api/journey', ['game', 'recipes', 'planner', 'inventory', 'shopping']);
  if (!g || !j) return null;
  const s = g.streaks.cooking;
  return (
    <a className="card pad path-card" href="#/progress">
      <div className="row" style={{ gap: 12 }}>
        <Pip skin={j.companion.skin} stages={j.companion.stages} size={48} />
        <div className="grow" style={{ minWidth: 0 }}>
          <b className="ellipsis" style={{ display: 'block' }}>{j.current ? `${j.current.emoji} ${nl ? j.current.title_nl : j.current.title}` : nl ? 'Reis voltooid!' : 'Journey complete!'}</b>
          <div className="xp-bar"><i style={{ width: `${Math.round(g.level.progress * 100)}%` }} /></div>
          <div className="tiny muted ellipsis">{g.level.emoji} {nl ? g.level.name_nl : g.level.name} · 🔥 {s.current}</div>
        </div>
        <ChevronRight size={18} className="muted" />
      </div>
    </a>
  );
}

export function PathPage() {
  const app = useApp();
  const nl = app.lang === 'nl';
  const [tab, setTab] = useState<'journey' | 'rewards' | 'stats' | 'friends'>(() => {
    if (codeFromHash() || location.hash.startsWith('#/friends')) return 'friends'; // a friend's link, or a friend notification
    const v = sessionStorage.getItem('larder.progressTab');
    return v === 'rewards' || v === 'stats' || v === 'friends' ? v : 'journey';
  });
  useEffect(() => sessionStorage.setItem('larder.progressTab', tab), [tab]);
  const { data: g } = useQuery<any>('/api/game', ['game', 'recipes', 'planner', 'preferences']);
  const { data: j } = useQuery<any>('/api/journey', ['game', 'recipes', 'planner', 'inventory', 'shopping', 'preferences']);
  const friends = useQuery<any>('/api/friends', ['friends', 'game', 'recipes', 'planner']);
  if (!g || !j) return <div className="stack" style={{ marginTop: 20 }}><div className="skeleton" style={{ height: 160 }} /><div className="skeleton" style={{ height: 420 }} /></div>;
  const TABS: [typeof tab, string, string][] = [['journey', 'Path', 'Pad'], ['rewards', 'Rewards', 'Beloningen'], ['stats', 'Stats', 'Cijfers'], ['friends', 'Friends', 'Vrienden']];
  return (
    <>
      <div className="topbar">
        <div className="grow"><h1>{nl ? 'Voortgang' : 'Progress'}</h1></div>
      </div>
      <ProgressHero g={g} j={j} />
      <PipVisits data={friends.data} />
      <div className="seg progress-tabs" role="tablist">
        {TABS.map(([id, en, nlL]) => <button key={id} role="tab" aria-selected={tab === id} className={tab === id ? 'on' : ''} onClick={() => setTab(id)}>{nl ? nlL : en}</button>)}
      </div>
      {tab === 'journey' && <JourneyPath j={j} />}
      {tab === 'rewards' && (
        <>
          <a className="stats-link" href="#/achievements">🏅 <span className="grow">{nl ? 'Al je prestaties' : 'All your achievements'}</span> <ChevronRight size={18} /></a>
          <Rewards g={g} j={j} />
        </>
      )}
      {tab === 'friends' && <FriendsTab />}
      {tab === 'stats' && (
        <>
          <a className="stats-link" href="#/insights"><BarChart3 size={18} /> <span className="grow">{nl ? 'Statistieken: uitgaven, verspilling, je jaar in eten' : 'Statistics: spending, waste, your year in food'}</span> <ChevronRight size={18} /></a>
          <Habits g={g} />
          <div className="section-head"><h2>{nl ? 'Vaardigheden' : 'Skill tracks'}</h2></div>
          <Tracks j={j} />
        </>
      )}
    </>
  );
}

/** Answers "what can I do next?": XP, streak, this week, today's balance and the next step. */
function ProgressHero({ g, j }: { g: any; j: any }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const xp = useCountUp(g.xp, g.xp - (j.freshXp ?? 0), 1100);
  const s = g.streaks.cooking;
  const next = j.current;
  return (
    <div className="card j-hero">
      <div className="row" style={{ gap: 14, alignItems: 'center' }}>
        <div className="j-hero-pip"><Pip skin={j.companion.skin} stages={j.companion.stages} size={56} mood={j.fresh.length ? 'cheer' : 'happy'} /></div>
        <div className="grow" style={{ minWidth: 0 }}>
          <div className="tiny muted">{nl ? `${j.companion.name} en jij` : `${j.companion.name} & you`}</div>
          <b className="ellipsis" style={{ display: 'block', fontSize: 17 }}>{g.level.emoji} {nl ? g.level.name_nl : g.level.name}</b>
          <div className="xp-bar"><i style={{ width: `${Math.round(g.level.progress * 100)}%` }} /></div>
          <div className="tiny muted"><b className="num xp-count">{xp}</b> XP{g.level.to ? ` · ${g.level.to - g.xp} ${nl ? 'tot volgend niveau' : 'to next level'}` : ''}</div>
        </div>
        <div className={`j-streak ${s.cookedToday ? 'lit' : s.atRisk ? 'risk' : ''}`} title={nl ? 'Dagen op rij gekookt' : 'Days in a row cooked'}><span aria-hidden>🔥</span><b>{s.current}</b><i>{nl ? 'dagen' : 'days'}</i></div>
      </div>
      {next ? (
        <a className="j-next" href={next.cta?.href ?? '#/progress'}>
          <span className="j-next-emoji">{next.emoji}</span>
          <span className="grow" style={{ minWidth: 0 }}>
            <span className="tiny muted">{nl ? 'Volgende stap' : 'Next step'} · +{next.xp} XP</span>
            <b className="ellipsis" style={{ display: 'block' }}>{nl ? next.title_nl : next.title}</b>
            {next.goal > 1 && <span className="xp-bar thin"><i style={{ width: `${(next.progress / next.goal) * 100}%` }} /></span>}
          </span>
          <span className="btn primary sm">{nl ? next.cta?.label_nl : next.cta?.label}</span>
        </a>
      ) : (
        <div className="j-next"><span className="j-next-emoji">👑</span><b className="grow">{nl ? 'Je hebt de hele reis voltooid. De paden gaan door!' : 'You finished the whole journey. The tracks keep going!'}</b></div>
      )}
    </div>
  );
}

function JourneyPath({ j }: { j: any }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const [open, setOpen] = useState<any>(null);
  const [celebrate, setCelebrate] = useState<any>(() => j.chapters.find((c: any) => c.fresh) ?? null);
  const active = j.chapters.find((c: any) => c.unlocked && !c.completed) ?? null;
  const firstFresh = useRef<HTMLElement | null>(null);

  // Show what's new, then mark it seen so it only celebrates once.
  useEffect(() => {
    if (!j.fresh.length) return;
    const el = document.querySelector('.jnode.just-done');
    if (el && !reducedMotion()) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
    const t = setTimeout(() => post('/api/journey/seen', {}).catch(() => {}), 2200);
    return () => clearTimeout(t);
  }, [j.fresh.join(',')]);
  useEffect(() => {
    // Without fresh news, start at the current position.
    if (j.fresh.length) return;
    const el = document.querySelector('.jnode.current');
    if (el) el.scrollIntoView({ block: 'center' });
  }, []);

  return (
    <div className="journey">
      {j.chapters.map((ch: any) => (
        <Chapter key={ch.id} ch={ch} j={j} active={active?.n === ch.n} onOpen={setOpen} firstFresh={firstFresh} />
      ))}
      <div className="j-end">
        <Pip skin={j.companion.skin} stages={j.companion.stages} size={44} mood="sleepy" />
        <span className="small muted">{nl ? 'Meer hoofdstukken volgen. Je paden en uitdagingen gaan altijd door.' : 'More chapters to come. Your tracks and challenges keep going.'}</span>
      </div>
      {open && <NodeSheet node={open} onClose={() => setOpen(null)} />}
      {celebrate && <ChapterDone ch={celebrate} j={j} onClose={() => { setCelebrate(null); post('/api/journey/seen', {}).then(() => invalidate(['game'])); }} />}
    </div>
  );
}

function Chapter({ ch, j, active, onOpen, firstFresh }: { ch: any; j: any; active: boolean; onOpen: (n: any) => void; firstFresh: React.MutableRefObject<HTMLElement | null> }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const box = useRef<HTMLDivElement>(null);
  const [w, setW] = useState(360);
  useLayoutEffect(() => {
    if (!box.current) return;
    const ro = new ResizeObserver(([e]) => setW(e.contentRect.width));
    ro.observe(box.current);
    return () => ro.disconnect();
  }, []);
  const amp = Math.max(56, Math.min(130, w / 2 - 64));
  const pts = ch.path.map((_: any, i: number) => ({ x: w / 2 + WAVE[i % WAVE.length] * amp, y: 84 + i * ROW }));
  const height = 84 + (ch.path.length - 1) * ROW + 70;
  // Pip walks from where you were to where you are.
  const curIdx = ch.path.findIndex((n: any) => n.state === 'current');
  const freshIdx = ch.path.findIndex((n: any) => n.fresh);
  const [pipAt, setPipAt] = useState(freshIdx >= 0 && freshIdx < curIdx ? freshIdx : curIdx);
  useEffect(() => {
    if (pipAt === curIdx) return;
    const t = setTimeout(() => setPipAt(curIdx), reducedMotion() ? 0 : 900);
    return () => clearTimeout(t);
  }, [curIdx]);
  const bonusAt = Math.min(3, ch.path.length - 1);
  const bonusSide = WAVE[bonusAt % WAVE.length] > 0 ? -1 : 1;
  const pipPt = pipAt >= 0 ? pts[pipAt] : null;
  const pipSide = pipPt && pipPt.x > w / 2 ? -1 : 1;

  return (
    <section className={`chapter env-${ch.env} ${ch.unlocked ? '' : 'locked'} ${ch.completed ? 'done' : ''}`} aria-label={nl ? ch.title_nl : ch.title}>
      <div className="scenery" aria-hidden>{(SCENERY[ch.env] ?? []).map((e, i) => <span key={i} style={{ ['--i' as any]: i }}>{e}</span>)}</div>
      <header className="chapter-head">
        <div className="chapter-badge">{ch.unlocked ? ch.emoji : <Lock size={18} />}</div>
        <div className="grow" style={{ minWidth: 0 }}>
          <div className="tiny chapter-kicker">{nl ? `Hoofdstuk ${ch.n}` : `Chapter ${ch.n}`}{ch.completed ? (nl ? ' · voltooid' : ' · complete') : ch.unlocked ? ` · ${ch.tasksDone}/${ch.tasksTotal}` : ''}</div>
          <h2>{nl ? ch.title_nl : ch.title}</h2>
          {(active || !ch.unlocked) && <p className="small">{ch.unlocked ? (nl ? ch.intro_nl : ch.intro) : nl ? `Gaat open na hoofdstuk ${ch.n - 1}.` : `Opens after chapter ${ch.n - 1}.`}</p>}
          {ch.unlocked && !ch.completed && <div className="xp-bar thin"><i style={{ width: `${(ch.tasksDone / ch.tasksTotal) * 100}%` }} /></div>}
        </div>
        <div className="chapter-rewards" title={nl ? 'Beloningen' : 'Rewards'}>{ch.rewards.map((r: any) => <span key={r.id}>{r.emoji}</span>)}</div>
      </header>
      <div className="trail" ref={box} style={{ height }}>
        <svg className="trail-line" width={w} height={height} aria-hidden>
          {pts.slice(1).map((p: any, i: number) => {
            const a = pts[i];
            const done = ch.path[i + 1].state === 'completed' || (ch.path[i].state === 'completed' && ch.path[i + 1].state === 'current');
            return <path key={i} className={done ? 'tseg done' : 'tseg'} d={`M ${a.x} ${a.y} C ${a.x} ${a.y + ROW / 2}, ${p.x} ${p.y - ROW / 2}, ${p.x} ${p.y}`} />;
          })}
          {ch.bonus.length > 0 && <path className="tseg bonus" d={`M ${pts[bonusAt].x} ${pts[bonusAt].y} Q ${(pts[bonusAt].x + w / 2 + bonusSide * amp * 1.2) / 2} ${pts[bonusAt].y - 40}, ${w / 2 + bonusSide * amp * 1.2} ${pts[bonusAt].y - 6}`} />}
        </svg>
        {ch.path.map((n: any, i: number) => (
          <JNode key={n.id} n={n} at={pts[i]} onOpen={onOpen} refFresh={n.fresh && !firstFresh.current ? firstFresh : null} />
        ))}
        {ch.bonus.map((b: any) => <JNode key={b.id} n={b} at={{ x: w / 2 + bonusSide * amp * 1.2, y: pts[bonusAt].y - 6 }} onOpen={onOpen} />)}
        {active && pipPt && (
          <div className="trail-pip" style={{ transform: `translate(${pipPt.x + pipSide * 58 - 24}px, ${pipPt.y - 40}px)` }} aria-hidden>
            <Pip skin={j.companion.skin} stages={j.companion.stages} size={48} mood={pipAt !== curIdx ? 'cheer' : 'happy'} />
          </div>
        )}
      </div>
    </section>
  );
}

function JNode({ n, at, onOpen, refFresh }: { n: any; at: { x: number; y: number }; onOpen: (n: any) => void; refFresh?: React.MutableRefObject<HTMLElement | null> | null }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const size = n.kind === 'boss' ? 78 : n.kind === 'bonus' ? 56 : 66;
  const pct = n.goal ? Math.min(1, n.progress / n.goal) : 0;
  const r = size / 2 + 5;
  const label = `${nl ? n.title_nl : n.title}: ${n.state === 'completed' ? (nl ? 'voltooid' : 'done') : n.state === 'locked' ? (nl ? 'op slot' : 'locked') : `${n.progress}/${n.goal}`}`;
  return (
    <button
      ref={refFresh ? (el) => { refFresh.current = el; } : undefined}
      className={`jnode k-${n.kind} ${n.state} ${n.fresh ? 'just-done' : ''} ${n.feasible === false && n.state !== 'completed' ? 'waiting' : ''}`}
      style={{ left: at.x - size / 2, top: at.y - size / 2, width: size, height: size }}
      onClick={() => onOpen(n)}
      aria-label={label}
    >
      {(n.state === 'available' || n.state === 'current' || n.state === 'bonus') && pct > 0 && (
        <svg className="jring" width={r * 2} height={r * 2} style={{ left: size / 2 - r, top: size / 2 - r }} aria-hidden>
          <circle cx={r} cy={r} r={r - 3} pathLength={100} strokeDasharray={`${pct * 100} 100`} />
        </svg>
      )}
      <span className="jface">
        {n.state === 'locked' ? <Lock size={20} /> : n.kind === 'milestone' ? (n.done ? <span className="jemoji">{n.emoji}</span> : <Gift size={26} />) : <span className="jemoji">{n.emoji}</span>}
      </span>
      {n.state === 'completed' && <span className="jcheck"><Check size={13} strokeWidth={3} /></span>}
      {n.kind === 'bonus' && n.state !== 'completed' && <span className="jstar"><Star size={11} fill="currentColor" /></span>}
      {n.kind === 'boss' && <span className="jflag"><Flag size={12} /></span>}
      {n.state === 'current' && <span className="jbubble">{n.progress > 0 ? (nl ? 'Verder' : 'Continue') : nl ? 'Start' : 'Start'}</span>}
      {n.fresh && !reducedMotion() && <span className="confetti" aria-hidden>{Array.from({ length: 10 }, (_, i) => <i key={i} style={{ ['--a' as any]: `${i * 36}deg`, ['--d' as any]: `${(i % 3) * 60}ms` }} />)}</span>}
    </button>
  );
}

function NodeSheet({ node: n, onClose }: { node: any; onClose: () => void }) {
  const app = useApp();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const state = { completed: nl ? 'Voltooid' : 'Completed', current: nl ? 'Nu aan de beurt' : 'Up next', available: nl ? 'Beschikbaar' : 'Available', locked: nl ? 'Op slot' : 'Locked', bonus: nl ? 'Bonus (optioneel)' : 'Bonus (optional)' }[n.state as string] ?? '';
  const swap = async () => {
    try {
      await post('/api/journey/swap', { nodeId: n.id });
      invalidate(['game']);
      toast({ text: nl ? 'Andere taak gekozen' : 'Swapped for another task' });
      onClose();
    } catch (e: any) {
      toast({ text: e.message, error: true });
    }
  };
  return (
    <Sheet title={<span>{n.emoji} {nl ? n.title_nl : n.title}</span>} onClose={onClose}>
      <div className="stack">
        <div className="row" style={{ gap: 8 }}><span className={`pill ${n.state === 'completed' ? 'herb' : ''}`}>{state}</span><span className="pill">+{n.xp} XP</span>{n.kind === 'boss' && <span className="pill">{nl ? 'Hoofdstukuitdaging' : 'Chapter challenge'}</span>}</div>
        <p style={{ margin: 0 }}>{nl ? n.desc_nl : n.desc}</p>
        {n.kind === 'milestone' && n.reward && <p className="small muted" style={{ margin: 0 }}>{nl ? 'Beloning' : 'Reward'}: {n.reward.emoji} {nl ? n.reward.title[1] : n.reward.title[0]}</p>}
        {n.goal > 0 && n.state !== 'locked' && (
          <div>
            <div className="xp-bar"><i style={{ width: `${(n.progress / n.goal) * 100}%` }} /></div>
            <div className="tiny muted">{n.progress} / {n.goal}{n.completedAt ? ` · ${new Date(n.completedAt).toLocaleDateString(nl ? 'nl-NL' : 'en-GB')}` : ''}</div>
          </div>
        )}
        {n.state === 'locked' && <p className="small muted" style={{ margin: 0 }}>{n.kind === 'boss' ? (nl ? 'Gaat open als alle taken van dit hoofdstuk klaar zijn.' : 'Opens when this chapter’s tasks are done.') : nl ? 'Gaat open als je zover bent.' : 'Opens when you get here.'}</p>}
        {n.hint && n.state !== 'completed' && <p className="small" style={{ margin: 0 }}>💡 {nl ? n.hint.nl : n.hint.en}</p>}
        <p className="tiny muted" style={{ margin: 0 }}>{nl ? 'Telt alleen echte dingen: wat je kookt, koopt, gebruikt en plant.' : 'Only real things count: what you cook, buy, use and plan.'}</p>
        <div className="row wrap" style={{ gap: 8 }}>
          {n.cta && n.state !== 'completed' && n.state !== 'locked' && <a className="btn primary" href={n.cta.href} onClick={onClose}>{nl ? n.cta.label_nl : n.cta.label}</a>}
          {n.kind === 'task' && (n.state === 'available' || n.state === 'current') && <button className="btn ghost" onClick={swap}><RefreshCw size={15} /> {nl ? 'Andere taak' : 'Different task'}</button>}
        </div>
      </div>
    </Sheet>
  );
}

function ChapterDone({ ch, j, onClose }: { ch: any; j: any; onClose: () => void }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const next = j.chapters.find((c: any) => c.n === ch.n + 1);
  return (
    <div className="celebrate" role="dialog" aria-modal="true" aria-label={nl ? 'Hoofdstuk voltooid' : 'Chapter complete'}>
      <div className="celebrate-card">
        {!reducedMotion() && <div className="confetti big" aria-hidden>{Array.from({ length: 24 }, (_, i) => <i key={i} style={{ ['--a' as any]: `${i * 15}deg`, ['--d' as any]: `${(i % 4) * 70}ms` }} />)}</div>}
        <Pip skin={j.companion.skin} stages={j.companion.stages} size={110} mood="cheer" className="bounce" />
        <div className="tiny muted">{nl ? `Hoofdstuk ${ch.n} voltooid` : `Chapter ${ch.n} complete`}</div>
        <h2 style={{ margin: '2px 0 8px' }}>{nl ? ch.title_nl : ch.title}</h2>
        <div className="stack" style={{ gap: 6 }}>
          {ch.rewards.map((r: any) => <div key={r.id} className="reward-row"><span>{r.emoji}</span><b>{nl ? r.title[1] : r.title[0]}</b></div>)}
        </div>
        <button className="btn primary" style={{ marginTop: 16, width: '100%' }} onClick={onClose}>{next ? (nl ? `Op naar ${next.title_nl}` : `On to ${next.title}`) : nl ? 'Geweldig!' : 'Amazing!'}</button>
      </div>
    </div>
  );
}

function Tracks({ j }: { j: any }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  return (
    <div className="stack" style={{ marginTop: 12 }}>
      <p className="small muted" style={{ margin: 0 }}>{nl ? 'Naast je reis groeien deze vaardigheden vanzelf mee met wat je doet.' : 'Alongside your journey, these skills grow by themselves with what you do.'}</p>
      {j.tracks.map((t: any) => (
        <div key={t.id} className="card pad track">
          <div className="row" style={{ gap: 10 }}>
            <span className="thumb">{t.emoji}</span>
            <div className="grow" style={{ minWidth: 0 }}>
              <b>{nl ? t.title_nl : t.title}</b>
              <div className="tiny muted">{nl ? t.levelName_nl : t.levelName} · {t.value} {nl ? t.unit_nl : t.unit}{t.next ? ` · ${nl ? 'volgende bij' : 'next at'} ${t.next}` : ''}</div>
            </div>
            <a className="btn soft sm" href={t.cta.href}>{nl ? t.cta.label_nl : t.cta.label}</a>
          </div>
          <div className="track-nodes">
            {t.nodes.map((n: any, i: number) => (
              <div key={n.id} className={`tnode ${n.done ? 'done' : i === t.level ? 'next' : ''} ${n.fresh ? 'just-done' : ''}`} title={`${nl ? n.name_nl : n.name}: ${n.need} · +${n.xp} XP`}>
                {n.done ? <Check size={14} strokeWidth={3} /> : i + 1}
              </div>
            ))}
          </div>
          {t.next && <div className="xp-bar thin"><i style={{ width: `${Math.min(100, ((t.value - t.prev) / (t.next - t.prev)) * 100)}%` }} /></div>}
        </div>
      ))}
    </div>
  );
}

function Rewards({ g, j }: { g: any; j: any }) {
  const app = useApp();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const [name, setName] = useState(j.companion.name);
  const [coll, setColl] = useState<string | null>(null);
  const items = useQuery<any[]>(coll ? `/api/journey/collection/${coll}` : null, ['recipes', 'inventory']);
  const setSkin = async (skin: string) => {
    try {
      await put('/api/journey/companion', { skin });
      invalidate(['game']);
    } catch (e: any) {
      toast({ text: e.message, error: true });
    }
  };
  return (
    <div className="stack" style={{ marginTop: 12 }}>
      <div className="card pad pip-card">
        <Pip skin={j.companion.skin} stages={j.companion.stages} size={96} />
        <div className="grow stack" style={{ gap: 6 }}>
          <label className="row" style={{ gap: 6 }}>
            <Pencil size={14} className="muted" />
            <input className="input" style={{ maxWidth: 180 }} value={name} maxLength={20} onChange={(e) => setName(e.target.value)} onBlur={() => name.trim() && name !== j.companion.name && put('/api/journey/companion', { name: name.trim() }).then(() => invalidate(['game']))} aria-label={nl ? 'Naam van je kokmaatje' : 'Your companion’s name'} />
          </label>
          <span className="tiny muted">{nl ? 'Krijgt een schort, koksmuts en das als je hoofdstukken afrondt.' : 'Earns an apron, a chef’s hat and a scarf as you finish chapters.'}</span>
        </div>
      </div>
      <div className="section-head"><h2>{nl ? 'Uiterlijk' : 'Looks'}</h2><span className="tiny muted">{j.companion.skins.filter((s: any) => s.unlocked).length}/{j.companion.skins.length}</span></div>
      <div className="skins">
        {j.companion.skins.map((s: any) => (
          <button key={s.id} className={`skin ${j.companion.skin === s.id ? 'on' : ''}`} disabled={!s.unlocked} onClick={() => setSkin(s.id)} aria-pressed={j.companion.skin === s.id} title={s.unlocked ? (nl ? s.title[1] : s.title[0]) : nl ? 'Ontgrendel met een hoofdstuk' : 'Unlock with a chapter'}>
            <Pip skin={s.id} stages={j.companion.stages} size={46} />
            <span className="tiny">{s.unlocked ? (nl ? s.title[1] : s.title[0]) : <Lock size={12} />}</span>
          </button>
        ))}
      </div>
      <div className="section-head"><h2>{nl ? 'Je keukenplank' : 'Your kitchen shelf'}</h2><span className="tiny muted">{nl ? 'uit beloningskisten' : 'from reward chests'}</span></div>
      <div className="shelf">
        {j.decor.map((d: any) => <span key={d.id} className={`decor ${d.unlocked ? 'on' : ''}`} title={nl ? d.title[1] : d.title[0]}>{d.unlocked ? d.emoji : '·'}</span>)}
      </div>
      <div className="section-head"><h2>{nl ? 'Receptcollecties' : 'Recipe collections'}</h2></div>
      <div className="list">
        {j.collections.map((c: any) => (
          <button key={c.id} className="item" disabled={!c.unlocked} onClick={() => setColl(coll === c.id ? null : c.id)} style={{ textAlign: 'left', width: '100%' }}>
            <span className="thumb">{c.unlocked ? c.emoji : <Lock size={16} />}</span>
            <div className="grow"><div className="title">{nl ? c.title[1] : c.title[0]}</div><div className="meta">{c.unlocked ? (nl ? 'Tik om te bekijken' : 'Tap to browse') : nl ? `Na hoofdstuk ${c.chapter}` : `After chapter ${c.chapter}`}</div></div>
          </button>
        ))}
      </div>
      {coll && items.data && (
        <div className="hscroll">
          {items.data.map((r: any) => (
            <a key={r.id} className="card mini-recipe" href={`#/recipe/${r.id}`}><span className="thumb" style={{ background: r.color ?? 'var(--bg-2)' }}>{r.emoji ?? '🍽️'}</span><b className="small">{r.title}</b><span className="tiny muted">{r.minutes} min</span></a>
          ))}
        </div>
      )}
      <div className="section-head"><h2>{nl ? 'Accentkleur' : 'Accent colour'}</h2><span className="tiny muted">{nl ? 'ontgrendel met elke rang' : 'unlocks with each rank'}</span></div>
      <div className="row wrap" style={{ gap: 10 }}>
        {g.ranks.map((r: any) => (
          <button key={r.accent} className={`swatch ${g.accent === r.accent ? 'on' : ''}`} style={{ background: g.accents[r.accent]?.herb }} disabled={!r.unlocked} title={r.unlocked ? r.accent : `${nl ? 'Ontgrendelt bij' : 'Unlocks at'} ${nl ? r.name_nl : r.name}`}
            onClick={async () => { await put('/api/game/settings', { accent: r.accent }); invalidate(['game']); }} aria-label={r.accent}>
            {!r.unlocked && <Lock size={14} color="#fff" />}
          </button>
        ))}
      </div>
      <div className="section-head"><h2>Badges</h2><span className="tiny muted">{g.achievements.filter((a: any) => a.done).length}/{g.achievements.length} · +{g.rules.badge} XP</span></div>
      <div className="achs">
        {g.achievements.map((a: any) => (
          <div key={a.id} className={`ach ${a.done ? 'done' : ''}`} title={nl ? a.desc_nl : a.desc}>
            <div className="b-emoji">{a.emoji}</div>
            <b>{nl ? a.title_nl : a.title}</b>
            <span className="tiny muted">{nl ? a.desc_nl : a.desc}</span>
            {!a.done && <div className="xp-bar thin"><i style={{ width: `${(a.progress / a.goal) * 100}%` }} /></div>}
          </div>
        ))}
      </div>
      <div className="section-head"><h2>{nl ? 'Rangen' : 'Ranks'}</h2><span className="tiny muted">{g.level.to ? `${g.level.to - g.xp} XP ${nl ? 'tot volgende' : 'to next'}` : nl ? 'Hoogste niveau!' : 'Top level!'}</span></div>
      <div className="ranks">
        {g.ranks.map((r: any, ri: number) => (
          <div key={r.name} className={`rank ${r.unlocked ? 'unlocked' : ''}`}>
            <div className="rank-head"><span className="rank-emoji">{r.unlocked ? r.emoji : <Lock size={16} />}</span><b>{nl ? r.name_nl : r.name}</b><span className="tiny muted">{r.from} XP</span></div>
            <div className="tiers">
              {g.path.filter((n: any) => n.rank === ri).map((n: any) => (
                <div key={n.n} className={`tier ${n.state}`} title={`${n.xp} XP`}>{n.state === 'done' ? <Check size={16} /> : ['I', 'II', 'III'][n.tier]}</div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Habits({ g }: { g: any }) {
  const app = useApp();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const learned = useQuery<any[]>('/api/insights/learned', ['preferences', 'recipes']);
  const weekday = (d: string) => DAY[app.lang][(new Date(d + 'T12:00:00Z').getUTCDay() + 6) % 7];
  const ch = g.challenge;
  const chDef = (id: string) => ch.all.find((c: any) => c.id === id);
  const s = g.streaks.cooking;
  return (
    <>
      <div className="card pad stack path-hero" style={{ marginTop: 12 }}>
        <div className="row" style={{ gap: 14 }}>
          <div className={`flame big ${s.cookedToday ? 'lit' : s.current ? 'risk' : ''}`}>🔥<b>{s.current}</b></div>
          <div className="grow">
            <b>{nl ? `${s.current} ${s.current === 1 ? 'dag' : 'dagen'} op rij gekookt` : `${s.current}-day cooking streak`}</b>
            <div className="small muted">{s.cookedToday ? (nl ? 'Vandaag gedaan. Lekker bezig!' : 'Done for today. Nice!') : s.current ? (nl ? 'Kook vandaag om je reeks te houden.' : 'Cook today to keep it going.') : nl ? 'Kook vandaag om een reeks te starten.' : 'Cook today to start a streak.'}</div>
            <div className="tiny muted">{nl ? `Record ${s.best}` : `Best ${s.best}`} · {nl ? 'één rustdag per week telt niet' : 'one rest day a week doesn’t count against you'}{s.repaired ? (nl ? ' · reeks hersteld 💪' : ' · streak repaired 💪') : ''}</div>
          </div>
        </div>
        <div className="week-dots">
          {g.week.map((d: any) => (
            <div key={d.date} className={`wd ${d.cooked ? 'on' : ''} ${d.best >= 70 ? 'good' : ''}`} title={d.score != null ? `${d.date}: ${d.score}/100` : d.date}>
              <span>{d.cooked ? (d.best >= 70 ? '🥗' : '✓') : ''}</span>
              <i>{weekday(d.date)}</i>
            </div>
          ))}
        </div>
      </div>
      <div className="streak-grid">
        {STREAKS.map(([k, emoji, en, nlL]) => {
          const st = g.streaks[k];
          return (
            <div key={k} className={`streak-tile ${st.current ? 'on' : ''}`}>
              <span className="e">{emoji}</span><b>{st.current}</b>
              <span className="tiny muted">{nl ? nlL : en} · {UNIT[st.unit]?.[nl ? 1 : 0] ?? st.unit}</span>
            </div>
          );
        })}
      </div>
      <div className="card pad nutrition-card">
        <div className="row" style={{ gap: 12 }}>
          <span className={`score-ring ${scoreGrade(g.nutrition.today ?? g.nutrition.weekAverage)}`}>{g.nutrition.today ?? g.nutrition.weekAverage ?? '–'}</span>
          <div className="grow">
            <b>{nl ? 'Voedingsscore' : 'Nutrition score'}</b>
            <div className="small muted">
              {g.nutrition.today != null ? (nl ? `Vandaag ${g.nutrition.today}/100` : `Today ${g.nutrition.today}/100`) : nl ? 'Vandaag nog niets gekookt' : 'Nothing cooked today yet'}
              {g.nutrition.weekAverage != null ? (nl ? ` · gemiddeld ${g.nutrition.weekAverage} deze week` : ` · ${g.nutrition.weekAverage} average this week`) : ''}
            </div>
            <div className="tiny muted">{nl ? `70+ is top: hoger levert geen extra punten op. Minder eten scoort niet beter. Doel ≈ ${g.dinnerTarget} kcal per avondmaal.` : `70+ is great: higher doesn’t earn more. Eating less never scores better. Target ≈ ${g.dinnerTarget} kcal per dinner.`}</div>
          </div>
        </div>
      </div>
      <div className="section-head"><h2>{nl ? 'Uitdaging' : 'Challenge'}</h2><span className="tiny muted">{nl ? 'optioneel · 7 dagen' : 'optional · 7 days'}</span></div>
      {ch.current ? (
        <div className="card pad">
          <div className="row" style={{ gap: 10 }}>
            <span className="thumb">{chDef(ch.current.id)?.emoji}</span>
            <div className="grow">
              <b>{nl ? chDef(ch.current.id)?.title_nl : chDef(ch.current.id)?.title}</b>
              <div className="tiny muted">{nl ? chDef(ch.current.id)?.desc_nl : chDef(ch.current.id)?.desc} · {nl ? 'tot' : 'until'} {ch.current.end}</div>
              <div className="xp-bar"><i style={{ width: `${(ch.current.progress / ch.current.goal) * 100}%` }} /></div>
            </div>
            <b className="small num">{ch.current.done ? '✅' : `${ch.current.progress}/${ch.current.goal}`}</b>
          </div>
          <button className="btn ghost sm" style={{ marginTop: 6 }} onClick={async () => { await del('/api/game/challenge'); invalidate(['game']); }}>{nl ? 'Stoppen' : 'Leave'}</button>
        </div>
      ) : (
        <div className="list">
          {ch.suggestions.map((c: any) => (
            <div key={c.id} className="item">
              <span className="thumb">{c.emoji}</span>
              <div className="grow" style={{ minWidth: 0 }}>
                <div className="title">{nl ? c.title_nl : c.title}</div>
                <div className="meta">{nl ? c.desc_nl : c.desc} · <i>{nl ? c.reason_nl : c.reason}</i></div>
              </div>
              <button className="btn soft sm" onClick={async () => { await post('/api/game/challenge', { id: c.id }); invalidate(['game']); toast({ text: nl ? 'Uitdaging gestart!' : 'Challenge started!' }); }}>{nl ? 'Doe mee' : 'Join'}</button>
            </div>
          ))}
        </div>
      )}
      <div className="section-head"><h2>{nl ? 'Deze week' : 'This week'}</h2><span className="tiny muted">{nl ? 'bonus-XP' : 'bonus XP'}</span></div>
      <div className="list">
        {g.quests.map((q: any) => (
          <div key={q.id} className={`item quest ${q.done ? 'done' : ''}`}>
            <span className="thumb">{q.done ? '✅' : q.emoji}</span>
            <div className="grow"><div className="title">{nl ? q.title_nl : q.title}</div><div className="xp-bar thin"><i style={{ width: `${(q.progress / q.goal) * 100}%` }} /></div></div>
            <span className="small num"><b>{q.progress}/{q.goal}</b><br /><span className="muted">+{q.xp}</span></span>
          </div>
        ))}
      </div>
      {(learned.data?.length ?? 0) > 0 && (
        <>
          <div className="section-head"><h2><Lightbulb size={18} style={{ verticalAlign: -3 }} /> {nl ? 'Wat PantryPip heeft geleerd' : 'What PantryPip has learned'}</h2></div>
          <div className="list">
            {learned.data!.map((i: any) => (
              <label key={i.id} className={`item learned ${i.active ? '' : 'off'}`}>
                <div className="grow"><div className="small">{nl ? i.text_nl : i.text}</div><div className="tiny muted">{nl ? i.effect_nl : i.effect}</div></div>
                <input type="checkbox" className="switch" checked={i.active} onChange={async (e) => { await post(`/api/insights/learned/${encodeURIComponent(i.id)}`, { active: e.target.checked }); invalidate(['preferences']); }} aria-label={nl ? 'Gebruiken' : 'Use this'} />
              </label>
            ))}
          </div>
          <p className="tiny muted">{nl ? 'Gebaseerd op de laatste 3 maanden en past zich aan als je gewoontes veranderen. Zet uit wat niet klopt.' : 'Based on the last 3 months and adapts as your habits change. Switch off anything that’s wrong.'}</p>
        </>
      )}
      <div className="section-head"><h2>{nl ? 'Recent gekookt' : 'Recently cooked'}</h2></div>
      {g.recent.length ? (
        <div className="list">
          {g.recent.map((e: any) => (
            <a key={e.id} className="item" href={`#/recipe/${e.recipeId}`} style={{ textDecoration: 'none' }}>
              <span className="thumb">{e.emoji}</span>
              <div className="grow" style={{ minWidth: 0 }}><div className="title ellipsis">{e.title}</div><div className="meta">{e.date} · ⚖️ {e.score}/100</div></div>
              <b className="small" style={{ color: 'var(--herb)' }}>+{e.xp} XP</b>
            </a>
          ))}
        </div>
      ) : (
        <Empty art="🍳" title={nl ? 'Nog niets gekookt' : 'Nothing cooked yet'}><p className="small">{nl ? 'Tik op “Gekookt” bij een maaltijd en je eerste XP komt binnen.' : 'Tap “Cooked it” on a meal and your first XP rolls in.'}</p></Empty>
      )}
      <a className="stats-link" href="#/settings/personal"><span className="grow">{nl ? 'Punten en voedingsdoelen aanpassen' : 'Change points and nutrition targets'}</span> <ChevronRight size={18} /></a>
    </>
  );
}

function scoreGrade(s: number | null) {
  if (s == null) return '';
  return s >= 85 ? 'excellent' : s >= 70 ? 'balanced' : s >= 50 ? 'ok' : 'treat';
}
