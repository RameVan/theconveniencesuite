import { useState } from 'react';
import { ChevronLeft, ChevronRight, Plus, Search, Trash2, Check, SkipForward, ShoppingBasket } from 'lucide-react';
import { del, patch, post, useQuery, invalidate, useDebounced } from '../api';
import { ProductPicker } from '../components/ProductPicker';
import { useApp, SCOPES_ALL } from '../app-context';
import { useT } from '../i18n';
import { Sheet, Stepper, useToast } from '../components/ui';
import { AutoPlanSheet } from '../components/AutoPlan';
import { useReward } from '../components/Reward';
import { Sparkles, Lock, Unlock, Shuffle, Eraser } from 'lucide-react';
import { uiPrefs } from '../appearance';
import { useSetting } from '../settings';

const MEALS = ['breakfast', 'lunch', 'dinner', 'snack'];
const iso = (d: Date) => d.toISOString().slice(0, 10);
const addDays = (s: string, n: number) => {
  const d = new Date(s + 'T12:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return iso(d);
};
function monday(s: string) {
  const d = new Date(s + 'T12:00:00Z');
  const wd = (d.getUTCDay() + 6) % 7;
  return addDays(s, -wd);
}

export function PlannerPage() {
  const app = useApp();
  const t = useT();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const today = iso(new Date());
  const [start, setStart] = useState(monday(today));
  // Cooking on only some days: show just those days, over enough weeks to see about a week's worth of meals.
  const [planDays] = useSetting<number[]>('household', 'planDays');
  const cookDays = planDays?.length ? planDays : [0, 1, 2, 3, 4, 5, 6];
  const weeks = cookDays.length >= 7 ? 1 : cookDays.length >= 4 ? 2 : cookDays.length >= 2 ? 3 : 4;
  const span = weeks * 7;
  const { data } = useQuery<any>(`/api/plan?start=${start}&days=${span}`, ['planner']);
  const shopping = useQuery<any>('/api/shopping', ['shopping']);
  const [adding, setAdding] = useState<{ date: string; meal: string } | null>(null);
  const [editing, setEditing] = useState<any | null>(null);
  const [choosing, setChoosing] = useState<any | null>(null);
  const [dragId, setDragId] = useState<string | null>(null);
  const [dropDay, setDropDay] = useState<string | null>(null);
  // Home's "plan your week" prompt opens the planner sheet straight away.
  const [auto, setAuto] = useState(() => /[?&]auto=1/.test(location.hash));
  const reward = useReward();
  const planItems = (shopping.data?.groups ?? []).flatMap((g: any) => g.items).filter((i: any) => i.reason === 'meal_plan').length;

  // Clear the shown week: planned meals go (locked ones too), cooked meals stay. Undo puts them back.
  const clearable = (data?.days ?? []).reduce((n: number, d: any) => n + d.slots.filter((s: any) => s.status !== 'cooked').length, 0);
  const clearWeek = async () => {
    if (uiPrefs.confirmDestructive && !confirm(nl ? `${clearable} geplande maaltijden van deze week verwijderen?` : `Remove ${clearable} planned meals from this week?`)) return;
    try {
      const r = await post('/api/plan/clear', { start, days: span });
      invalidate(['planner', 'shopping', 'home']);
      toast({
        text: nl ? `${r.removed} maaltijden verwijderd` : `Cleared ${r.removed} meals`,
        undo: () => post('/api/plan/restore', { slots: r.slots }).then(() => invalidate(['planner', 'shopping', 'home'])),
      });
    } catch (e: any) {
      toast({ text: e.message, error: true });
    }
  };
  const move = async (id: string, date: string) => {
    await patch(`/api/plan/${id}`, { date });
    invalidate(['planner', 'shopping', 'home']);
  };
  const fmt = (d: string, o: Intl.DateTimeFormatOptions) => new Date(d + 'T12:00:00Z').toLocaleDateString(nl ? 'nl-NL' : 'en-GB', { timeZone: 'UTC', ...o });
  const fmtDay = (d: string) => fmt(d, { weekday: 'short' });
  const dayNum = (d: string) => new Date(d + 'T12:00:00Z').getUTCDate();
  const weekNo = (d: string) => {
    // ISO week of the Monday d: its Thursday decides the year, and counting from 1 January gives the week.
    const t = new Date(addDays(d, 3) + 'T12:00:00Z');
    return Math.ceil(((t.getTime() - Date.UTC(t.getUTCFullYear(), 0, 1, 12)) / 864e5 + 1) / 7);
  };
  const allDays: any[] = data?.days ?? Array.from({ length: span }, (_, i) => ({ date: addDays(start, i), slots: [], nutrition: null }));
  // A planned meal on a day you don't usually cook still shows, so nothing is ever hidden.
  const isCookDay = (d: any) => cookDays.includes(new Date(d.date + 'T12:00:00Z').getUTCDay()) || d.slots.length > 0;
  const groups = Array.from({ length: weeks }, (_, w) => {
    const from = addDays(start, w * 7);
    return { from, days: allDays.filter((d) => d.date >= from && d.date <= addDays(from, 6) && (weeks === 1 || isCookDay(d))) };
  });

  return (
    <>
      <div className="topbar">
        <div className="grow">
          <h1>Planner</h1>
          <div className="sub">{fmt(start, { day: 'numeric', month: 'short' })} – {fmt(addDays(start, span - 1), { day: 'numeric', month: 'short' })}{weeks > 1 ? ` · ${nl ? `${weeks} weken` : `${weeks} weeks`}` : ''}</div>
        </div>
        <div className="week-nav">
          <button className="icon-btn" onClick={() => setStart(addDays(start, -span))} aria-label={weeks > 1 ? (nl ? 'Vorige weken' : 'Previous weeks') : nl ? 'Vorige week' : 'Previous week'}><ChevronLeft /></button>
          <button className="btn sm" onClick={() => setStart(monday(today))}>{t('Today')}</button>
          <button className="icon-btn" onClick={() => setStart(addDays(start, span))} aria-label={weeks > 1 ? (nl ? 'Volgende weken' : 'Next weeks') : nl ? 'Volgende week' : 'Next week'}><ChevronRight /></button>
        </div>
      </div>
      <div className="plan-actions">
        <button className="btn primary lg plan-week-btn" onClick={() => setAuto(true)}><Sparkles size={18} /> {nl ? 'Plan mijn week' : 'Plan my week'}</button>
        {clearable > 0 && <button className="btn lg plan-clear-btn" onClick={clearWeek}><Eraser size={17} /> {weeks > 1 ? (nl ? 'Leegmaken' : 'Clear') : nl ? 'Week leegmaken' : 'Clear week'}</button>}
      </div>
      {auto && <AutoPlanSheet start={start < today ? today : start} onClose={() => setAuto(false)} />}
      {planItems > 0 && (
        <a href="#/shopping" className="plan-missing">
          <ShoppingBasket size={17} />
          <span className="grow">{nl ? `${planItems} ontbrekende ingrediënten` : `${planItems} missing ingredients`}</span>
          <ChevronRight size={17} />
        </a>
      )}
      {groups.map((g) => (
        <section key={g.from} className="plan-week" aria-label={`${nl ? 'Week' : 'Week'} ${weekNo(g.from)}`}>
          {weeks > 1 && <h2 className="plan-week-head">{nl ? 'Week' : 'Week'} {weekNo(g.from)} <span>{fmt(g.from, { day: 'numeric', month: 'short' })} – {fmt(addDays(g.from, 6), { day: 'numeric', month: 'short' })}</span></h2>}
          <div className="week" style={weeks > 1 ? ({ ['--cols' as any]: Math.max(1, cookDays.length) }) : undefined}>
            {g.days.map((d: any) => (
              <div
                key={d.date}
                className={`day ${d.date === today ? 'today' : ''} ${dropDay === d.date ? 'drop' : ''}`}
                onDragOver={(e) => { e.preventDefault(); setDropDay(d.date); }}
                onDragLeave={() => setDropDay(null)}
                onDrop={(e) => { e.preventDefault(); setDropDay(null); if (dragId) move(dragId, d.date); setDragId(null); }}
              >
                <div className="day-head"><b>{fmtDay(d.date)} {dayNum(d.date)}{weeks > 1 ? ` ${fmt(d.date, { month: 'short' })}` : ''}</b>{d.date === today && <span>{t('Today')}</span>}</div>
                {MEALS.flatMap((m) => d.slots.filter((s: any) => s.meal === m)).map((s: any) => (
                  <div key={s.id} className={`meal ${s.status} ${dragId === s.id ? 'dragging' : ''}`} draggable onDragStart={() => setDragId(s.id)} onDragEnd={() => setDragId(null)} onClick={() => setEditing(s)} role="button" tabIndex={0} onKeyDown={(e) => e.key === 'Enter' && setEditing(s)}>
                    <span className="em" style={{ background: s.recipe?.color ? `color-mix(in srgb, ${s.recipe.color} 22%, var(--surface))` : 'var(--bg-2)' }}>{s.recipe?.emoji ?? (s.leftover_lot_id ? '🥡' : '🍽️')}</span>
                    <span className="grow" style={{ minWidth: 0 }}>
                      <div className="mt ellipsis">{s.locked ? <Lock size={11} style={{ marginRight: 3, verticalAlign: -1 }} /> : null}{s.recipe?.title ?? s.title}</div>
                      <div className="ms">{t(s.meal.charAt(0).toUpperCase() + s.meal.slice(1))} · {s.servings}p{s.status === 'cooked' ? ' · ✓' : s.status === 'skipped' ? ` · ${t('Skipped').toLowerCase()}` : ''}</div>
                    </span>
                  </div>
                ))}
                <button className="add-meal" onClick={() => setAdding({ date: d.date, meal: d.slots.some((s: any) => s.meal === 'dinner') ? 'lunch' : 'dinner' })}><Plus size={13} /> {t('Add meal')}</button>
              </div>
            ))}
            {!g.days.length && <p className="muted small">{nl ? 'Geen kookdagen deze week.' : 'No cooking days this week.'}</p>}
          </div>
        </section>
      ))}

      {adding && <AddMealSheet target={adding} onClose={() => setAdding(null)} />}
      {choosing && <ChooseRecipeSheet slot={choosing} onClose={() => setChoosing(null)} />}
      {editing && (
        <Sheet title={editing.recipe?.title ?? editing.title} onClose={() => setEditing(null)}>
          <div className="stack">
            <div className="row wrap">
              {editing.recipe && <a className="btn" href={`#/recipe/${editing.recipe.id}?servings=${editing.servings}`}>{nl ? 'Recept' : 'Recipe'}</a>}
              {editing.recipe && editing.status === 'planned' && (
                <button className="btn primary" onClick={async () => {
                  const r = await post(`/api/plan/${editing.id}/cook`, {});
                  invalidate(SCOPES_ALL);
                  reward(r.reward, editing.recipe);
                  setEditing(null);
                  toast({ text: nl ? 'Gekookt, ingrediënten afgeschreven' : 'Cooked, ingredients deducted', undo: () => post('/api/inventory/undo', { batchId: r.batchId }).then(() => invalidate(SCOPES_ALL)) });
                }}><Check size={16} /> {nl ? 'Gekookt' : 'Cooked it'}</button>
              )}
              {editing.status === 'planned' && (
                <button className="btn" onClick={() => { setChoosing(editing); setEditing(null); }}><Shuffle size={16} /> {nl ? 'Ander recept' : 'Change recipe'}</button>
              )}
              {editing.status === 'planned' && (
                <button className="btn" aria-pressed={!!editing.locked} onClick={async () => {
                  await patch(`/api/plan/${editing.id}`, { locked: !editing.locked });
                  setEditing({ ...editing, locked: !editing.locked });
                  invalidate(['planner']);
                }}>{editing.locked ? <><Unlock size={16} /> {nl ? 'Ontgrendelen' : 'Unlock'}</> : <><Lock size={16} /> {nl ? 'Vastzetten' : 'Lock'}</>}</button>
              )}
              {editing.status === 'planned' && <button className="btn" onClick={async () => { await patch(`/api/plan/${editing.id}`, { status: 'skipped' }); invalidate(['planner', 'shopping']); setEditing(null); }}><SkipForward size={16} /> {nl ? 'Overslaan' : 'Skip'}</button>}
              <button className="btn" style={{ color: 'var(--tomato)' }} onClick={async () => { await del(`/api/plan/${editing.id}`); invalidate(['planner', 'shopping', 'home']); setEditing(null); }}><Trash2 size={16} /> {nl ? 'Verwijderen' : 'Remove'}</button>
            </div>
            {editing.recipe && editing.status === 'planned' && <MealIngredients slot={editing} onChange={setEditing} />}
            <details className="set-more">
              <summary>{nl ? 'Dag, maaltijd of porties wijzigen' : 'Change day, meal or servings'}</summary>
              <div className="stack" style={{ paddingTop: 8 }}>
            <label className="field">{nl ? 'Dag' : 'Day'}
              <select className="select" value={editing.date} onChange={async (e) => { await move(editing.id, e.target.value); setEditing({ ...editing, date: e.target.value }); }}>
                {Array.from({ length: Math.max(14, span) }, (_, i) => addDays(start, i)).map((d) => <option key={d} value={d}>{new Date(d + 'T12:00:00Z').toLocaleDateString(nl ? 'nl-NL' : 'en-GB', { weekday: 'long', day: 'numeric', month: 'short' })}</option>)}
              </select>
            </label>
            <label className="field">{nl ? 'Maaltijd' : 'Meal'}
              <select className="select" value={editing.meal} onChange={async (e) => { await patch(`/api/plan/${editing.id}`, { meal: e.target.value }); setEditing({ ...editing, meal: e.target.value }); invalidate(['planner']); }}>
                {MEALS.map((m) => <option key={m} value={m}>{t(m.charAt(0).toUpperCase() + m.slice(1))}</option>)}
              </select>
            </label>
            <div className="row"><span className="grow field">{t('servings')}</span>
              <Stepper value={editing.servings} onChange={async (n) => { setEditing({ ...editing, servings: n }); await patch(`/api/plan/${editing.id}`, { servings: n }); invalidate(['planner', 'shopping', 'home']); }} />
            </div>
              </div>
            </details>
          </div>
        </Sheet>
      )}
    </>
  );
}

/**
 * Change a planned meal: the recipes that fit best (stock, taste, variety with the rest of the plan) to
 * pick from, or search for any recipe. The shopping list follows the new recipe straight away.
 */
/**
 * The ingredients of one planned meal, each replaceable for this meal only (basmati → sushi rice) or left
 * out. The recipe itself stays as it is; the shopping list and cooking use the adjusted version.
 */
function MealIngredients({ slot, onChange }: { slot: any; onChange: (s: any) => void }) {
  const app = useApp();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const recipe = useQuery<any>(`/api/recipes/${slot.recipe.id}`, ['recipes']).data?.recipe;
  const [open, setOpen] = useState<number | null>(null);
  const swaps: any[] = slot.swaps ?? [];
  const set = async (position: number, body: { productId?: string | null; omit?: boolean }, msg?: string) => {
    try {
      const next = await post(`/api/plan/${slot.id}/ingredient`, { position, ...body });
      onChange({ ...slot, swaps: next.swaps });
      invalidate(['planner', 'shopping', 'home']);
      setOpen(null);
      if (msg) toast({ text: msg });
    } catch (e: any) {
      toast({ text: e.message, error: true });
    }
  };
  if (!recipe) return null;
  const lines = recipe.ingredients.filter((i: any) => i.product_id);
  return (
    <details className="set-more" open={swaps.length > 0}>
      <summary>{nl ? 'Ingrediënten aanpassen' : 'Adjust ingredients'}{swaps.length ? ` · ${swaps.length} ${nl ? 'aangepast' : 'changed'}` : ''}</summary>
      <div className="meal-swaps" style={{ paddingTop: 8 }}>
        {lines.map((i: any) => {
          const sw = swaps.find((w) => w.position === i.position);
          const own = (nl && i.product?.name_nl) || i.product?.name || i.name;
          return (
            <div key={i.position}>
              <div className="row">
                <span className="grow small">
                  {sw ? <><s className="muted">{own}</s> → <b>{sw.omit ? (nl ? 'weggelaten' : 'left out') : (nl ? sw.to_nl : sw.to)}</b></> : own}
                  {i.optional && <span className="muted"> · {nl ? 'optioneel' : 'optional'}</span>}
                </span>
                {sw ? <button className="btn sm ghost" onClick={() => set(i.position, { productId: null })}>{nl ? 'Terugzetten' : 'Undo'}</button>
                  : <button className="btn sm ghost" aria-expanded={open === i.position} onClick={() => setOpen(open === i.position ? null : i.position)}>{nl ? 'Vervangen' : 'Replace'}</button>}
              </div>
              {open === i.position && (
                <div className="stack" style={{ margin: '6px 0 10px' }}>
                  <ProductPicker autoFocus like={i.product} exclude={[i.product_id]} onPick={(p) => set(i.position, { productId: p.id }, nl ? `${own} → ${p.name}. Boodschappenlijst bijgewerkt.` : `${own} → ${p.name}. Shopping list updated.`)} />
                  <button className="btn sm ghost" style={{ justifySelf: 'start' }} onClick={() => set(i.position, { omit: true }, nl ? `${own} weggelaten` : `Left out ${own}`)}>{nl ? 'Weglaten' : 'Leave it out'}</button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </details>
  );
}

const PROTEINS: [string, string, string][] = [
  ['veg', 'Vegetables', 'Groente'], ['plant', 'Beans & tofu', 'Bonen & tofu'], ['eggs', 'Eggs', 'Ei'], ['fish', 'Fish', 'Vis'],
  ['chicken', 'Chicken', 'Kip'], ['beef', 'Beef', 'Rund'], ['pork', 'Pork', 'Varken'],
];

function ChooseRecipeSheet({ slot, onClose }: { slot: any; onClose: () => void }) {
  const app = useApp();
  const t = useT();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(false);
  const [cuisine, setCuisine] = useState<string | null>(null);
  const [protein, setProtein] = useState<string | null>(null);
  const dq = useDebounced(q, 150);
  const kind = `${cuisine ? `&cuisine=${encodeURIComponent(cuisine)}` : ''}${protein ? `&protein=${protein}` : ''}`;
  const options = useQuery<{ options: any[]; cuisines: string[]; proteins: string[] }>(`/api/plan/${slot.id}/options?limit=15${kind}`, ['planner']);
  // Kinds come from recipes that fit everyone's diet, so a vegetarian household never sees Chicken or Beef.
  const [facets, setFacets] = useState<{ cuisines: string[]; proteins: string[] } | null>(null);
  if (options.data && !facets) setFacets({ cuisines: options.data.cuisines, proteins: options.data.proteins });
  const found = useQuery<any[]>(dq ? `/api/recipes?q=${encodeURIComponent(dq)}&limit=20` : null, ['recipes']);
  const done = (title: string) => {
    invalidate(['planner', 'shopping', 'home']);
    toast({ text: nl ? `${title} ingepland. Boodschappenlijst bijgewerkt.` : `Changed to ${title}. Shopping list updated.` });
    onClose();
  };
  const choose = async (recipeId: string, title: string) => {
    if (busy) return;
    setBusy(true);
    try {
      await post(`/api/plan/${slot.id}/choose`, { recipeId });
      done(title);
    } catch (e: any) {
      toast({ text: e.message, error: true });
      setBusy(false);
    }
  };
  const surprise = async () => {
    setBusy(true);
    try {
      const d = await post(`/api/plan/${slot.id}/swap?${kind.slice(1)}`, {});
      done(d.title);
    } catch (e: any) {
      toast({ text: e.message, error: true });
      setBusy(false);
    }
  };
  const when = new Date(slot.date + 'T12:00:00Z').toLocaleDateString(nl ? 'nl-NL' : 'en-GB', { timeZone: 'UTC', weekday: 'long', day: 'numeric', month: 'short' });
  const list: any[] = dq ? (found.data ?? []).filter((r: any) => r.id !== slot.recipe?.id).map((r: any) => ({ recipeId: r.id, title: r.title, emoji: r.emoji, color: r.color, minutes: r.minutes, reasons: r.matchPct != null ? [nl ? `${Math.round(r.matchPct)}% in huis` : `${Math.round(r.matchPct)}% in stock`] : [] })) : options.data?.options ?? [];
  return (
    <Sheet title={nl ? 'Kies een ander recept' : 'Pick another recipe'} onClose={onClose}>
      <div className="stack">
        <p className="small muted" style={{ margin: 0 }}>{nl ? `Voor ${when}${slot.recipe ? `, in plaats van ${slot.recipe.title}` : ''}.` : `For ${when}${slot.recipe ? `, instead of ${slot.recipe.title}` : ''}.`}</p>
        <div className="search"><Search /><input className="input" value={q} onChange={(e) => setQ(e.target.value)} placeholder={nl ? 'Zoek een recept…' : 'Search a recipe…'} /></div>
        {!dq && facets && (
          <div className="choose-kinds">
            <div className="chips" role="group" aria-label={nl ? 'Soort' : 'Kind of food'}>
              {PROTEINS.filter(([k]) => facets.proteins.includes(k)).map(([k, en, nlName]) => (
                <button key={k} className={`chip ${protein === k ? 'on' : ''}`} aria-pressed={protein === k} onClick={() => setProtein(protein === k ? null : k)}>{nl ? nlName : en}</button>
              ))}
            </div>
            {facets.cuisines.length > 1 && (
              <div className="chips" role="group" aria-label={nl ? 'Keuken' : 'Cuisine'}>
                {facets.cuisines.map((c) => <button key={c} className={`chip ${cuisine === c ? 'on' : ''}`} aria-pressed={cuisine === c} onClick={() => setCuisine(cuisine === c ? null : c)}>{c}</button>)}
              </div>
            )}
          </div>
        )}
        {!dq && <div className="row"><span className="tiny muted grow">{cuisine || protein ? (nl ? 'Alleen deze soort, best passend eerst' : 'Only this kind, best fit first') : nl ? 'Past het best bij je voorraad en je week' : 'Best fit for your stock and your week'}</span><button className="btn sm ghost" disabled={busy} onClick={surprise}><Shuffle size={14} /> {nl ? 'Verras me' : 'Surprise me'}</button></div>}
        <div className="list">
          {list.map((r) => (
            <button key={r.recipeId} className="item" disabled={busy} onClick={() => choose(r.recipeId, r.title)}>
              <span className="thumb" style={{ background: r.color ? `color-mix(in srgb, ${r.color} 25%, var(--surface))` : 'var(--bg-2)' }}>{r.emoji ?? '🍽️'}</span>
              <span className="grow"><span className="title">{r.title}</span><span className="meta">{[`${r.minutes} min`, ...(r.reasons ?? []), r.extraCost ? (nl ? `± €${r.extraCost.toFixed(2)} erbij kopen` : `± €${r.extraCost.toFixed(2)} to buy`) : null].filter(Boolean).join(' · ')}</span></span>
            </button>
          ))}
          {!list.length && (options.loading || found.loading ? <div className="skeleton" style={{ height: 120 }} /> : <p className="small muted">{dq ? (nl ? 'Geen recepten gevonden.' : 'No recipes found.') : nl ? 'Geen andere recepten passen deze dag.' : 'No other recipes fit this day.'}</p>)}
        </div>
      </div>
    </Sheet>
  );
}

export function AddMealSheet({ target, onClose, recipeId }: { target: { date: string; meal: string }; onClose: () => void; recipeId?: string }) {
  const app = useApp();
  const t = useT();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const [q, setQ] = useState('');
  const [meal, setMeal] = useState(target.meal);
  const [date, setDate] = useState(target.date);
  const [servings, setServings] = useState(2);
  const dq = useDebounced(q, 150);
  const recipes = useQuery<any[]>(dq ? `/api/recipes?q=${encodeURIComponent(dq)}&limit=20` : '/api/recipes/cook-now', ['recipes']);
  const inv = useQuery<any>('/api/inventory', ['inventory']);
  const add = async (body: any) => {
    await post('/api/plan', { date, meal, servings, ...body });
    invalidate(['planner', 'shopping', 'home']);
    toast({ text: nl ? 'Ingepland. Ontbrekende ingrediënten staan op je lijst.' : 'Planned. Missing ingredients are on your list.' });
    onClose();
  };
  if (recipeId) {
    return (
      <Sheet title={t('Plan it')} onClose={onClose} footer={<button className="btn primary block lg" onClick={() => add({ recipeId })}>{t('Plan it')}</button>}>
        <PlanFields {...{ date, setDate, meal, setMeal, servings, setServings, nl, t }} />
      </Sheet>
    );
  }
  return (
    <Sheet title={t('Add meal')} onClose={onClose}>
      <div className="stack">
        <PlanFields {...{ date, setDate, meal, setMeal, servings, setServings, nl, t }} />
        <div className="search"><Search /><input className="input" value={q} onChange={(e) => setQ(e.target.value)} placeholder={nl ? 'Zoek een recept…' : 'Search a recipe…'} autoFocus /></div>
        {!q && <div className="tiny muted">{t('Cook with what I have')}</div>}
        <div className="list">
          {(recipes.data ?? []).slice(0, 12).map((r: any) => (
            <button key={r.id} className="item" onClick={() => add({ recipeId: r.id })}>
              <span className="thumb" style={{ background: `color-mix(in srgb, ${r.color} 25%, var(--surface))` }}>{r.emoji}</span>
              <span className="grow"><span className="title">{r.title}</span><span className="meta">{r.minutes} min · {r.matchPct}% {t('have')}</span></span>
            </button>
          ))}
          {(inv.data?.leftovers ?? []).map((l: any) => (
            <button key={l.id} className="item" onClick={() => add({ leftoverLotId: l.id, title: `${l.title} (${nl ? 'restjes' : 'leftovers'})` })}>
              <span className="thumb">🥡</span><span className="grow"><span className="title">{l.title}</span><span className="meta">{t('Leftovers')} · {l.quantity}p · {l.location_name}</span></span>
            </button>
          ))}
          {q.trim() && <button className="item" onClick={() => add({ title: q.trim() })}><span className="thumb">✏️</span><span className="grow title">{nl ? `Alleen “${q.trim()}” noteren` : `Just note “${q.trim()}”`}</span></button>}
        </div>
      </div>
    </Sheet>
  );
}

function PlanFields({ date, setDate, meal, setMeal, servings, setServings, nl, t }: any) {
  return (
    <div className="row wrap">
      <input className="input" type="date" value={date} onChange={(e) => setDate(e.target.value)} style={{ flex: '1 1 150px' }} aria-label={nl ? 'Dag' : 'Day'} />
      <select className="select" value={meal} onChange={(e) => setMeal(e.target.value)} style={{ flex: '1 1 120px' }} aria-label={nl ? 'Maaltijd' : 'Meal'}>
        {MEALS.map((m) => <option key={m} value={m}>{t(m.charAt(0).toUpperCase() + m.slice(1))}</option>)}
      </select>
      <Stepper value={servings} onChange={setServings} label="servings" />
    </div>
  );
}
