import { useState } from 'react';
import { ChevronLeft, ChevronRight, Plus, Search, Trash2, Check, SkipForward, ShoppingBasket } from 'lucide-react';
import { del, patch, post, useQuery, invalidate, useDebounced } from '../api';
import { useApp, SCOPES_ALL } from '../app-context';
import { useT } from '../i18n';
import { Sheet, Stepper, useToast } from '../components/ui';
import { AutoPlanSheet } from '../components/AutoPlan';
import { useReward } from '../components/Reward';
import { Sparkles, Lock, Unlock, Shuffle, Eraser } from 'lucide-react';
import { uiPrefs } from '../appearance';

const MEALS = ['breakfast', 'lunch', 'dinner', 'snack'];
const iso = (d: Date) => d.toISOString().slice(0, 10);
const addDays = (s: string, n: number) => {
  const d = new Date(s + 'T12:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return iso(d);
};
function monday(s: string) {
  const d = new Date(s + 'T12:00:00Z');
  const wd = (d.getUTCDay() + 6) % 7;
  return addDays(s, -wd);
}

export function PlannerPage() {
  const app = useApp();
  const t = useT();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const today = iso(new Date());
  const [start, setStart] = useState(monday(today));
  const { data } = useQuery<any>(`/api/plan?start=${start}`, ['planner']);
  const shopping = useQuery<any>('/api/shopping', ['shopping']);
  const [adding, setAdding] = useState<{ date: string; meal: string } | null>(null);
  const [editing, setEditing] = useState<any | null>(null);
  const [dragId, setDragId] = useState<string | null>(null);
  const [dropDay, setDropDay] = useState<string | null>(null);
  // Home's "plan your week" prompt opens the planner sheet straight away.
  const [auto, setAuto] = useState(() => /[?&]auto=1/.test(location.hash));
  const reward = useReward();
  const planItems = (shopping.data?.groups ?? []).flatMap((g: any) => g.items).filter((i: any) => i.reason === 'meal_plan').length;

  // Clear the shown week: planned meals go (locked ones too), cooked meals stay. Undo puts them back.
  const clearable = (data?.days ?? []).reduce((n: number, d: any) => n + d.slots.filter((s: any) => s.status !== 'cooked').length, 0);
  const clearWeek = async () => {
    if (uiPrefs.confirmDestructive && !confirm(nl ? `${clearable} geplande maaltijden van deze week verwijderen?` : `Remove ${clearable} planned meals from this week?`)) return;
    try {
      const r = await post('/api/plan/clear', { start, days: 7 });
      invalidate(['planner', 'shopping', 'home']);
      toast({
        text: nl ? `${r.removed} maaltijden verwijderd` : `Cleared ${r.removed} meals`,
        undo: () => post('/api/plan/restore', { slots: r.slots }).then(() => invalidate(['planner', 'shopping', 'home'])),
      });
    } catch (e: any) {
      toast({ text: e.message, error: true });
    }
  };
  const move = async (id: string, date: string) => {
    await patch(`/api/plan/${id}`, { date });
    invalidate(['planner', 'shopping', 'home']);
  };
  const fmtDay = (d: string) => new Date(d + 'T12:00:00Z').toLocaleDateString(nl ? 'nl-NL' : 'en-GB', { weekday: 'short' });
  const dayNum = (d: string) => new Date(d + 'T12:00:00Z').getUTCDate();

  return (
    <>
      <div className="topbar">
        <div className="grow">
          <h1>Planner</h1>
          <div className="sub">{new Date(start + 'T12:00:00Z').toLocaleDateString(nl ? 'nl-NL' : 'en-GB', { day: 'numeric', month: 'short' })} – {new Date(addDays(start, 6) + 'T12:00:00Z').toLocaleDateString(nl ? 'nl-NL' : 'en-GB', { day: 'numeric', month: 'short' })}</div>
        </div>
        <div className="week-nav">
          <button className="icon-btn" onClick={() => setStart(addDays(start, -7))} aria-label="Previous week"><ChevronLeft /></button>
          <button className="btn sm" onClick={() => setStart(monday(today))}>{t('Today')}</button>
          <button className="icon-btn" onClick={() => setStart(addDays(start, 7))} aria-label="Next week"><ChevronRight /></button>
        </div>
      </div>
      <div className="plan-actions">
        <button className="btn primary lg plan-week-btn" onClick={() => setAuto(true)}><Sparkles size={18} /> {nl ? 'Plan mijn week' : 'Plan my week'}</button>
        {clearable > 0 && <button className="btn lg plan-clear-btn" onClick={clearWeek}><Eraser size={17} /> {nl ? 'Week leegmaken' : 'Clear week'}</button>}
      </div>
      {auto && <AutoPlanSheet start={start < today ? today : start} onClose={() => setAuto(false)} />}
      {planItems > 0 && (
        <a href="#/shopping" className="plan-missing">
          <ShoppingBasket size={17} />
          <span className="grow">{nl ? `${planItems} ontbrekende ingrediënten` : `${planItems} missing ingredients`}</span>
          <ChevronRight size={17} />
        </a>
      )}
      <div className="week">
        {(data?.days ?? Array.from({ length: 7 }, (_, i) => ({ date: addDays(start, i), slots: [], nutrition: null }))).map((d: any) => (
          <div
            key={d.date}
            className={`day ${d.date === today ? 'today' : ''} ${dropDay === d.date ? 'drop' : ''}`}
            onDragOver={(e) => { e.preventDefault(); setDropDay(d.date); }}
            onDragLeave={() => setDropDay(null)}
            onDrop={(e) => { e.preventDefault(); setDropDay(null); if (dragId) move(dragId, d.date); setDragId(null); }}
          >
            <div className="day-head"><b>{fmtDay(d.date)} {dayNum(d.date)}</b></div>
            {MEALS.flatMap((m) => d.slots.filter((s: any) => s.meal === m)).map((s: any) => (
              <div key={s.id} className={`meal ${s.status} ${dragId === s.id ? 'dragging' : ''}`} draggable onDragStart={() => setDragId(s.id)} onDragEnd={() => setDragId(null)} onClick={() => setEditing(s)} role="button" tabIndex={0} onKeyDown={(e) => e.key === 'Enter' && setEditing(s)}>
                <span className="em" style={{ background: s.recipe?.color ? `color-mix(in srgb, ${s.recipe.color} 22%, var(--surface))` : 'var(--bg-2)' }}>{s.recipe?.emoji ?? (s.leftover_lot_id ? '🥡' : '🍽️')}</span>
                <span className="grow" style={{ minWidth: 0 }}>
                  <div className="mt ellipsis">{s.locked ? <Lock size={11} style={{ marginRight: 3, verticalAlign: -1 }} /> : null}{s.recipe?.title ?? s.title}</div>
                  <div className="ms">{t(s.meal.charAt(0).toUpperCase() + s.meal.slice(1))} · {s.servings}p{s.status === 'cooked' ? ' · ✓' : s.status === 'skipped' ? ` · ${t('Skipped').toLowerCase()}` : ''}</div>
                </span>
              </div>
            ))}
            <button className="add-meal" onClick={() => setAdding({ date: d.date, meal: d.slots.some((s: any) => s.meal === 'dinner') ? 'lunch' : 'dinner' })}><Plus size={13} /> {t('Add meal')}</button>
          </div>
        ))}
      </div>

      {adding && <AddMealSheet target={adding} onClose={() => setAdding(null)} />}
      {editing && (
        <Sheet title={editing.recipe?.title ?? editing.title} onClose={() => setEditing(null)}>
          <div className="stack">
            <div className="row wrap">
              {editing.recipe && <a className="btn" href={`#/recipe/${editing.recipe.id}?servings=${editing.servings}`}>{nl ? 'Recept' : 'Recipe'}</a>}
              {editing.recipe && editing.status === 'planned' && (
                <button className="btn primary" onClick={async () => {
                  const r = await post(`/api/plan/${editing.id}/cook`, {});
                  invalidate(SCOPES_ALL);
                  reward(r.reward, editing.recipe);
                  setEditing(null);
                  toast({ text: nl ? 'Gekookt, ingrediënten afgeschreven' : 'Cooked, ingredients deducted', undo: () => post('/api/inventory/undo', { batchId: r.batchId }).then(() => invalidate(SCOPES_ALL)) });
                }}><Check size={16} /> {nl ? 'Gekookt' : 'Cooked it'}</button>
              )}
              {editing.status === 'planned' && editing.recipe && (
                <button className="btn" onClick={async () => {
                  try {
                    const d = await post(`/api/plan/${editing.id}/swap`, {});
                    invalidate(['planner', 'shopping', 'home']);
                    setEditing(null);
                    toast({ text: nl ? `Gewisseld: ${d.title}` : `Swapped for ${d.title}` });
                  } catch (e: any) {
                    toast({ text: e.message, error: true });
                  }
                }}><Shuffle size={16} /> {nl ? 'Iets anders' : 'Something else'}</button>
              )}
              {editing.status === 'planned' && (
                <button className="btn" aria-pressed={!!editing.locked} onClick={async () => {
                  await patch(`/api/plan/${editing.id}`, { locked: !editing.locked });
                  setEditing({ ...editing, locked: !editing.locked });
                  invalidate(['planner']);
                }}>{editing.locked ? <><Unlock size={16} /> {nl ? 'Ontgrendelen' : 'Unlock'}</> : <><Lock size={16} /> {nl ? 'Vastzetten' : 'Lock'}</>}</button>
              )}
              {editing.status === 'planned' && <button className="btn" onClick={async () => { await patch(`/api/plan/${editing.id}`, { status: 'skipped' }); invalidate(['planner', 'shopping']); setEditing(null); }}><SkipForward size={16} /> {nl ? 'Overslaan' : 'Skip'}</button>}
              <button className="btn" style={{ color: 'var(--tomato)' }} onClick={async () => { await del(`/api/plan/${editing.id}`); invalidate(['planner', 'shopping', 'home']); setEditing(null); }}><Trash2 size={16} /> {nl ? 'Verwijderen' : 'Remove'}</button>
            </div>
            <details className="set-more">
              <summary>{nl ? 'Dag, maaltijd of porties wijzigen' : 'Change day, meal or servings'}</summary>
              <div className="stack" style={{ paddingTop: 8 }}>
            <label className="field">{nl ? 'Dag' : 'Day'}
              <select className="select" value={editing.date} onChange={async (e) => { await move(editing.id, e.target.value); setEditing({ ...editing, date: e.target.value }); }}>
                {Array.from({ length: 14 }, (_, i) => addDays(start, i)).map((d) => <option key={d} value={d}>{new Date(d + 'T12:00:00Z').toLocaleDateString(nl ? 'nl-NL' : 'en-GB', { weekday: 'long', day: 'numeric', month: 'short' })}</option>)}
              </select>
            </label>
            <label className="field">{nl ? 'Maaltijd' : 'Meal'}
              <select className="select" value={editing.meal} onChange={async (e) => { await patch(`/api/plan/${editing.id}`, { meal: e.target.value }); setEditing({ ...editing, meal: e.target.value }); invalidate(['planner']); }}>
                {MEALS.map((m) => <option key={m} value={m}>{t(m.charAt(0).toUpperCase() + m.slice(1))}</option>)}
              </select>
            </label>
            <div className="row"><span className="grow field">{t('servings')}</span>
              <Stepper value={editing.servings} onChange={async (n) => { setEditing({ ...editing, servings: n }); await patch(`/api/plan/${editing.id}`, { servings: n }); invalidate(['planner', 'shopping', 'home']); }} />
            </div>
              </div>
            </details>
          </div>
        </Sheet>
      )}
    </>
  );
}

export function AddMealSheet({ target, onClose, recipeId }: { target: { date: string; meal: string }; onClose: () => void; recipeId?: string }) {
  const app = useApp();
  const t = useT();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const [q, setQ] = useState('');
  const [meal, setMeal] = useState(target.meal);
  const [date, setDate] = useState(target.date);
  const [servings, setServings] = useState(2);
  const dq = useDebounced(q, 150);
  const recipes = useQuery<any[]>(dq ? `/api/recipes?q=${encodeURIComponent(dq)}&limit=20` : '/api/recipes/cook-now', ['recipes']);
  const inv = useQuery<any>('/api/inventory', ['inventory']);
  const add = async (body: any) => {
    await post('/api/plan', { date, meal, servings, ...body });
    invalidate(['planner', 'shopping', 'home']);
    toast({ text: nl ? 'Ingepland. Ontbrekende ingrediënten staan op je lijst.' : 'Planned. Missing ingredients are on your list.' });
    onClose();
  };
  if (recipeId) {
    return (
      <Sheet title={t('Plan it')} onClose={onClose} footer={<button className="btn primary block lg" onClick={() => add({ recipeId })}>{t('Plan it')}</button>}>
        <PlanFields {...{ date, setDate, meal, setMeal, servings, setServings, nl, t }} />
      </Sheet>
    );
  }
  return (
    <Sheet title={t('Add meal')} onClose={onClose}>
      <div className="stack">
        <PlanFields {...{ date, setDate, meal, setMeal, servings, setServings, nl, t }} />
        <div className="search"><Search /><input className="input" value={q} onChange={(e) => setQ(e.target.value)} placeholder={nl ? 'Zoek een recept…' : 'Search a recipe…'} autoFocus /></div>
        {!q && <div className="tiny muted">{t('Cook with what I have')}</div>}
        <div className="list">
          {(recipes.data ?? []).slice(0, 12).map((r: any) => (
            <button key={r.id} className="item" onClick={() => add({ recipeId: r.id })}>
              <span className="thumb" style={{ background: `color-mix(in srgb, ${r.color} 25%, var(--surface))` }}>{r.emoji}</span>
              <span className="grow"><span className="title">{r.title}</span><span className="meta">{r.minutes} min · {r.matchPct}% {t('have')}</span></span>
            </button>
          ))}
          {(inv.data?.leftovers ?? []).map((l: any) => (
            <button key={l.id} className="item" onClick={() => add({ leftoverLotId: l.id, title: `${l.title} (${nl ? 'restjes' : 'leftovers'})` })}>
              <span className="thumb">🥡</span><span className="grow"><span className="title">{l.title}</span><span className="meta">{t('Leftovers')} · {l.quantity}p · {l.location_name}</span></span>
            </button>
          ))}
          {q.trim() && <button className="item" onClick={() => add({ title: q.trim() })}><span className="thumb">✏️</span><span className="grow title">{nl ? `Alleen “${q.trim()}” noteren` : `Just note “${q.trim()}”`}</span></button>}
        </div>
      </div>
    </Sheet>
  );
}

function PlanFields({ date, setDate, meal, setMeal, servings, setServings, nl, t }: any) {
  return (
    <div className="row wrap">
      <input className="input" type="date" value={date} onChange={(e) => setDate(e.target.value)} style={{ flex: '1 1 150px' }} aria-label={nl ? 'Dag' : 'Day'} />
      <select className="select" value={meal} onChange={(e) => setMeal(e.target.value)} style={{ flex: '1 1 120px' }} aria-label={nl ? 'Maaltijd' : 'Meal'}>
        {MEALS.map((m) => <option key={m} value={m}>{t(m.charAt(0).toUpperCase() + m.slice(1))}</option>)}
      </select>
      <Stepper value={servings} onChange={setServings} label="servings" />
    </div>
  );
}
