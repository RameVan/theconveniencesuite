import { useEffect, useRef, useState } from 'react';
import { AfterCooking } from '../components/AfterCooking';
import { ArrowLeft, Clock, Flame, Heart, Play, CalendarPlus, ShoppingBasket, Check, X, Mic, Pause, RotateCcw, ChefHat, Star, Bookmark, Camera, History, Pencil } from 'lucide-react';
import { EditRecipeSheet } from '../components/EditRecipe';
import { IngredientSheet, SubstitutionSheet, kindLabel } from '../components/Ingredient';
import { Info } from 'lucide-react';
import { shrink } from '../components/ReceiptSheet';
import { api, post, useQuery, invalidate } from '../api';
import { useSetting } from '../settings';
import { useApp, SCOPES_ALL } from '../app-context';
import { useT, fmtQty } from '../i18n';
import { Plate, Sheet, Stepper, useToast, Empty } from '../components/ui';
import { AddMealSheet } from './Planner';
import { useSpeech, useSpeechLang } from '../components/Assistant';
import { ALLERGEN_LABEL, DIET_LABEL, label, reasonText } from '../components/DietaryNeeds';
import { QuantityAsk } from '../components/QuantityAsk';
import { useReward } from '../components/Reward';
import { del } from '../api';

function useServingsParam(defaultServings?: number) {
  const m = location.hash.match(/servings=(\d+(?:\.\d+)?)/);
  return m ? Number(m[1]) : defaultServings;
}

export function RecipePage({ id }: { id: string }) {
  const app = useApp();
  const t = useT();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const initial = useServingsParam();
  const [servings, setServings] = useState<number | undefined>(initial);
  const { data, error } = useQuery<any>(`/api/recipes/${id}${servings ? `?servings=${servings}` : ''}`, ['recipes', 'inventory']);
  const [planning, setPlanning] = useState(false);
  const [cooking, setCooking] = useState(false);
  const [editing, setEditing] = useState(false);
  const [subFor, setSubFor] = useState<any>(null);
  const [aboutId, setAboutId] = useState<string | null>(null);
  // A fresh copy of a built-in recipe opens straight in the editor.
  useEffect(() => {
    if (/[?&]edit=1/.test(location.hash)) setEditing(true);
  }, [id]);
  useEffect(() => {
    if (data && servings == null) setServings(data.recipe.servings);
  }, [data, servings]);
  if (error) return <Empty art="🤔" title={nl ? 'Recept niet gevonden' : 'Recipe not found'} />;
  if (!data) return <div className="stack" style={{ marginTop: 20 }}><div className="skeleton" style={{ height: 240 }} /><div className="skeleton" style={{ height: 120 }} /></div>;
  const r = data.recipe;
  const f = data.factor;
  const n = r.nutritionPerServing;
  const missing = data.match.missing.filter((m: any) => !m.substitutes.length || m.status === 'partial');

  const addMissing = async () => {
    for (const m of data.match.missing) {
      if (!m.product_id) continue;
      await post('/api/shopping', { productId: m.product_id, quantity: Math.max(0, (m.needed ?? 0) - m.available) || null, note: r.title });
    }
    invalidate(['shopping', 'home']);
    toast({ text: nl ? `${data.match.missing.length} op je lijst gezet` : `${data.match.missing.length} added to your list` });
  };

  return (
    <>
      <div className="topbar">
        <button className="icon-btn" onClick={() => history.back()} aria-label={t('Back')}><ArrowLeft /></button>
        <div className="grow" />
        <button className="icon-btn" aria-label={nl ? 'Wil ik proberen' : 'Want to try'} aria-pressed={!!data.interaction?.to_try} title={nl ? 'Wil ik proberen' : 'Want to try'} onClick={async () => { await post(`/api/recipes/${r.id}/interaction`, { toTry: !data.interaction?.to_try }); invalidate(['recipes']); }}>
          <Bookmark fill={data.interaction?.to_try ? 'var(--saffron)' : 'none'} color={data.interaction?.to_try ? 'var(--saffron)' : 'currentColor'} />
        </button>
        <button className="icon-btn" aria-label={t('Save recipe')} aria-pressed={!!data.interaction?.saved} onClick={async () => { await post(`/api/recipes/${r.id}/interaction`, { saved: !data.interaction?.saved }); invalidate(['recipes']); }}>
          <Heart fill={data.interaction?.saved ? 'var(--tomato)' : 'none'} color={data.interaction?.saved ? 'var(--tomato)' : 'currentColor'} />
        </button>
      </div>
      <div className="two-col">
        <div>
          <div className="recipe-hero"><Plate color={r.color} emoji={r.emoji} image={r.image_url}>{r.origin === 'ai' && <span className="tag pill plum">✦ {t('AI-generated')}</span>}</Plate></div>
          <h1 className="recipe-title">{r.title}</h1>
          {r.compat && r.compat.level !== 'full' && <CompatBadge c={r.compat} />}
          {r.summary && <p className="muted" style={{ margin: '0 0 6px' }}>{r.summary}</p>}
          <div className="tiny muted">
            {r.cuisine}
            {r.source_name ? ' · ' : ''}
            {r.source_name && (r.source_url ? <a href={r.source_url} target="_blank" rel="noopener noreferrer">{r.source_name}</a> : r.source_name)}
            {/* Credit as the source asks for it; CC BY-SA links its licence. */}
            {r.attribution ? ' · ' : ''}
            {r.attribution && (/CC BY-SA 4\.0/.test(r.attribution) ? <>{r.attribution.replace('CC BY-SA 4.0', '')}<a href="https://creativecommons.org/licenses/by-sa/4.0/" target="_blank" rel="noopener noreferrer">CC BY-SA 4.0</a></> : r.attribution)}
          </div>
          <DietBanner data={data} />
          <div className="facts-row">
            <div className="fact"><Clock size={14} /> <b>{r.prep_minutes + r.cook_minutes} min</b>{r.prep_minutes} {nl ? 'voorb.' : 'prep'} + {r.cook_minutes} {nl ? 'koken' : 'cook'}</div>
            {n && <div className="fact"><Flame size={14} /> <b>{n.kcal} kcal</b>{Math.round(n.protein)} g {nl ? 'eiwit' : 'protein'} · {Math.round(n.carbs)} g {nl ? 'koolh.' : 'carbs'} · {Math.round(n.fat)} g {nl ? 'vet' : 'fat'}</div>}
            {r.costPerServing != null && <div className="fact"><b>€ {r.costPerServing.toFixed(2)}</b>{nl ? 'per portie (≈)' : 'per serving (≈)'}</div>}
            <div className="fact"><b>{data.match.matchPct}%</b>{nl ? 'in huis' : 'in stock'}</div>
          </div>
          <div className="row wrap" style={{ margin: '12px 0' }}>
            <span className="muted small">{t('servings')}{r.servings_estimated ? <span title={nl ? 'Het recept noemde geen aantal: geschat' : 'The recipe gave no number: estimated'}> (≈)</span> : null}</span>
            <Stepper value={servings ?? r.servings} onChange={setServings} label={t('servings')} />
            <span className="grow" />
            <span className="row" aria-label="rating">
              {[1, 2, 3, 4, 5].map((s) => (
                <button key={s} className="icon-btn ghost" style={{ width: 30, height: 30 }} aria-label={`${s} stars`} onClick={async () => { await post(`/api/recipes/${r.id}/interaction`, { rating: s }); invalidate(['recipes']); }}>
                  <Star size={17} fill={(data.interaction?.rating ?? 0) >= s ? 'var(--saffron)' : 'none'} color={(data.interaction?.rating ?? 0) >= s ? 'var(--saffron)' : 'var(--ink-3)'} />
                </button>
              ))}
            </span>
          </div>
          <div className="row wrap">
            <a className="btn primary lg grow" href={`#/cook/${r.id}?servings=${servings ?? r.servings}`}><Play size={18} /> {t('Start cooking')}</a>
            <button className="btn lg" onClick={() => setPlanning(true)}><CalendarPlus size={18} /> {t('Plan it')}</button>
          </div>
          <BalancePanel r={r} />
          <HowOften recipeId={r.id} value={data.interaction?.priority ?? 0} />
          {(data.interaction?.cooked_count > 0 || data.interaction?.ease || data.interaction?.again != null) && <AfterCooking recipeId={r.id} ease={data.interaction?.ease ?? null} again={data.interaction?.again ?? null} />}
          <RecipeHistory history={data.history ?? []} />
          <RecipeNotes recipeId={r.id} notes={data.interaction?.notes ?? ''} />
          {r.household_id && <PhotoButton recipeId={r.id} />}
          <button className="btn sm ghost" onClick={async () => {
            if (r.household_id) return setEditing(true);
            // Built-in recipes are shared: edit your own copy.
            const c = await post(`/api/recipes/${r.id}/copy`, {});
            invalidate(['recipes']);
            toast({ text: nl ? 'Kopie gemaakt in Mijn recepten' : 'Copy made in My recipes' });
            app.navigate(`#/recipe/${c.id}?edit=1`);
          }}><Pencil size={15} /> {r.household_id ? (nl ? 'Bewerken' : 'Edit') : nl ? 'Kopie bewerken' : 'Edit a copy'}</button>
          {editing && <EditRecipeSheet recipe={r} onClose={() => setEditing(false)} />}
          <div className="row wrap" style={{ marginTop: 8 }}>
            {data.match.missing.length > 0 && <button className="btn sm" onClick={addMissing}><ShoppingBasket size={15} /> {t('Add missing to list')} ({data.match.missing.length})</button>}
            <button className="btn sm ghost" onClick={() => setCooking(true)}><ChefHat size={15} /> {t('I cooked this')}</button>
            {r.household_id && (
              <button className="btn sm ghost" style={{ color: 'var(--tomato)' }} onClick={async () => {
                if (!confirm(nl ? 'Dit recept verwijderen?' : 'Delete this recipe?')) return;
                await del(`/api/recipes/${r.id}`);
                invalidate(['recipes', 'planner']);
                history.back();
              }}>{nl ? 'Verwijderen' : 'Delete'}</button>
            )}
          </div>
        </div>
        <div>
          <div className="section-head" style={{ marginTop: 6 }}><h2>{t('Ingredients')}</h2><span className="tiny muted">{missing.length ? `${missing.length} ${t('missing')}` : nl ? 'Alles in huis' : 'All in stock'}</span></div>
          <div className="list">
            {r.ingredients.map((ing: any) => {
              const st = data.match.ingredients.find((x: any) => x.position === ing.position);
              const qty = ing.quantity != null ? ing.quantity * f : null;
              return (
                <div key={ing.position} className="ing">
                  <span className={`dot ${st?.status}`} title={st?.status} />
                  <div className="grow">
                    <div>
                      {f !== 1 && qty != null && ing.product ? <b>{fmtQty(qty, ing.product.unit, app.lang, ing.product.piece_name)} </b> : null}
                      {ing.extra_for ? <>{ing.product ? (nl ? ing.product.name_nl ?? ing.product.name : ing.product.name) : ing.name}<span className="muted small"> ({nl ? 'voor de vervanging' : 'for the substitution'})</span></> : ing.display ?? ing.name}
                      {ing.optional && <span className="muted small"> ({nl ? 'optioneel' : 'optional'})</span>}
                    </div>
                    {/* What the line uses instead of what the recipe wrote, and why: tap to change. */}
                    {ing.sub && (
                      <button className={`sub-line ${ing.sub.identity ? 'identity' : ''} ${ing.product_id ? '' : 'unmatched'}`} onClick={() => setSubFor(ing)}>
                        {ing.product_id
                          ? <>→ {nl ? ing.product.name_nl ?? ing.product.name : ing.product.name} <span className="pill">{kindLabel(ing.sub.kind, nl)}</span></>
                          : ing.sub.choice === 'keep' ? <>{nl ? 'Zoals geschreven (niet bijgehouden)' : 'As written (not tracked)'}</>
                          : <>{nl ? 'Niet gekoppeld: kies een product' : 'Not matched: pick a product'}</>}
                        {ing.sub.identity && <span className="tiny"> · {nl ? 'verandert het gerecht' : 'changes the dish'}</span>}
                      </button>
                    )}
                    {ing.sub?.note && ing.product_id && <div className="tiny muted">{ing.sub.note[nl ? 1 : 0]}</div>}
                    {st && (st.status === 'partial' || st.status === 'missing') && (
                      <div className="tiny muted">{nl ? 'In huis' : 'You have'}: {fmtQty(st.available, st.unit ?? 'pcs', app.lang)}</div>
                    )}
                    {st?.substitutes?.map((s: any) => <div key={s.productId} className="sub">↔ {nl ? 'Of gebruik' : 'Or use'} {s.name.toLowerCase()}: {s.note}</div>)}
                    {st?.expiringSoon && <span className="pill saffron" style={{ marginTop: 4 }}>{nl ? 'Snel gebruiken' : 'Use soon'}</span>}
                  </div>
                  {ing.product_id && <button className="icon-btn ghost sm" onClick={() => setAboutId(ing.product_id)} aria-label={nl ? `Over ${ing.name}` : `About ${ing.name}`}><Info size={15} /></button>}
                </div>
              );
            })}
          </div>
          <div className="section-head"><h2>{t('Steps')}</h2></div>
          <ol className="steps">
            {r.steps.map((s: any, i: number) => <li key={i} className="card"><span>{s.text}{s.timerSeconds ? <span className="muted small"> ⏱ {Math.round(s.timerSeconds / 60)} min</span> : null}</span></li>)}
          </ol>
        </div>
      </div>
      {subFor && <SubstitutionSheet ing={subFor} onClose={() => setSubFor(null)} />}
      {aboutId && <IngredientSheet productId={aboutId} onClose={() => setAboutId(null)} />}
      {planning && <AddMealSheet target={{ date: new Date().toISOString().slice(0, 10), meal: 'dinner' }} recipeId={r.id} onClose={() => setPlanning(false)} />}
      {cooking && <CookedSheet recipe={r} servings={servings ?? r.servings} ingredients={data.match.ingredients} onClose={() => setCooking(false)} />}
    </>
  );
}

/** Dietary fit for this household: conflicts per ingredient, swaps that fix them, allergens. */
function DietBanner({ data }: { data: any }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const s = data.suitability;
  const al = data.recipe.allergens;
  const diets: string[] = data.recipe.diet ?? [];
  return (
    <div className="stack" style={{ gap: 6, margin: '10px 0 0' }}>
      {s && !s.ok && (
        <div className={`diet-banner ${s.adaptable ? 'adapt' : 'bad'}`} role="note">
          <b>{s.adaptable ? (nl ? 'Past met een kleine aanpassing' : 'Fits with a small swap') : nl ? 'Past niet bij jullie dieetwensen' : 'Doesn’t fit your dietary needs'}</b>
          {s.conflicts.map((c: any) => {
            const swap = s.swaps.find((w: any) => w.position === c.position);
            return (
              <div key={c.position} className="small">
                {c.name}: {c.reasons.map((r: string) => reasonText(r, app.lang)).join(', ')}
                {swap && <> → <b>{nl ? 'gebruik' : 'use'} {swap.to.name.toLowerCase()}</b> <span className="muted">({swap.note})</span></>}
              </div>
            );
          })}
          {s.notes.includes('diet:low-carb') && <div className="small">{nl ? 'Te veel koolhydraten voor koolhydraatarm' : 'Too many carbs for low-carb'}</div>}
        </div>
      )}
      {s?.optionalConflicts?.length > 0 && (
        <div className="small muted">{nl ? 'Laat weg' : 'Leave out'}: {s.optionalConflicts.map((c: any) => `${c.name.toLowerCase()} (${c.reasons.map((r: string) => reasonText(r, app.lang)).join(', ')})`).join(', ')}</div>
      )}
      <div className="row wrap" style={{ gap: 6 }}>
        {diets.filter((d) => d !== 'no-alcohol' && d !== 'halal' && d !== 'no-pork').slice(0, 5).map((d) => <span key={d} className="pill herb">{label(DIET_LABEL, d, app.lang)}</span>)}
        {al.required.length > 0 && <span className="pill saffron">{nl ? 'Bevat' : 'Contains'}: {al.required.map((a: string) => label(ALLERGEN_LABEL, a, app.lang).toLowerCase()).join(', ')}</span>}
        {al.optional.length > 0 && <span className="pill grey">{nl ? 'Optioneel' : 'Optional'}: {al.optional.map((a: string) => label(ALLERGEN_LABEL, a, app.lang).toLowerCase()).join(', ')}</span>}
      </div>
    </div>
  );
}

/** Confirm what was used (adjust or skip any ingredient), then log leftovers. Deducts through the ledger. */
function CookedSheet({ recipe, servings: initialServings, ingredients, onClose, after }: { recipe: any; servings: number; ingredients: any[]; onClose: () => void; after?: () => void }) {
  const app = useApp();
  const t = useT();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const [servings, setServings] = useState(initialServings);
  const reward = useReward();
  const [fridge, setFridge] = useState(0);
  const [freezer, setFreezer] = useState(0);
  const [skip, setSkip] = useState<Set<number>>(new Set());
  const [custom, setCustom] = useState<Record<number, number>>({}); // position → amount actually used (base units)
  const [editing, setEditing] = useState<number | null>(null);
  const f = servings / recipe.servings;
  const rows = recipe.ingredients.filter((i: any) => i.product_id && i.quantity != null);
  const submit = async () => {
    const overrides = [
      ...[...skip].map((position) => ({ position, quantity: 0 })),
      ...Object.entries(custom).filter(([pos]) => !skip.has(Number(pos))).map(([pos, quantity]) => ({ position: Number(pos), quantity })),
    ];
    try {
      const r = await post(`/api/recipes/${recipe.id}/cook`, { servings, overrides, leftovers: { fridge, freezer } });
      invalidate(SCOPES_ALL);
      reward(r.reward, { id: recipe.id, title: recipe.title });
      toast({ text: nl ? 'Gekookt! Voorraad bijgewerkt.' : 'Cooked! Inventory updated.', undo: () => post('/api/inventory/undo', { batchId: r.batchId }).then(() => invalidate(SCOPES_ALL)) });
      onClose();
      after?.();
    } catch (e: any) {
      toast({ text: e.message, error: true });
    }
  };
  return (
    <Sheet title={t('I cooked this')} onClose={onClose} footer={<button className="btn primary block lg" onClick={submit}><Check size={18} /> {nl ? 'Bevestigen' : 'Confirm'}</button>}>
      <div className="stack">
        <div className="row"><span className="grow">{t('servings')}</span><Stepper value={servings} onChange={setServings} /></div>
        <div className="small muted">{nl ? 'Dit gaat uit je voorraad. Tik op het vinkje om iets over te slaan, of op de hoeveelheid om die aan te passen.' : 'This comes out of your inventory. Tap the tick to skip something, or the amount to change it.'}</div>
        <div className="list">
          {rows.map((i: any) => {
            const st = ingredients.find((x) => x.position === i.position);
            const off = skip.has(i.position);
            const unit = i.product?.unit ?? 'pcs';
            const amount = custom[i.position] ?? i.quantity * f;
            return (
              <div key={i.position}>
                <div className="item" style={{ minHeight: 50, opacity: off ? 0.45 : 1 }}>
                  <button className={`check ${off ? '' : 'on'}`} aria-label={off ? (nl ? 'Wel gebruikt' : 'Used') : nl ? 'Overslaan' : 'Skip'} aria-pressed={!off}
                    onClick={() => setSkip((s) => { const n = new Set(s); n.has(i.position) ? n.delete(i.position) : n.add(i.position); return n; })}>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M5 12l5 5L20 7" /></svg>
                  </button>
                  <span className="grow">{i.product?.name ?? i.name}{i.optional && <span className="muted small"> ({nl ? 'optioneel' : 'optional'})</span>}</span>
                  <button className="btn sm ghost num" disabled={off} onClick={() => setEditing(editing === i.position ? null : i.position)} aria-label={nl ? 'Hoeveelheid aanpassen' : 'Change amount'}>
                    <span className={custom[i.position] != null ? '' : 'muted'}>{fmtQty(amount, unit, app.lang)}</span>
                    {st && st.available < amount && <span className="muted"> / {fmtQty(st.available, st.unit ?? 'pcs', app.lang)}</span>}
                  </button>
                </div>
                {editing === i.position && i.product && (
                  <QuantityAsk product={i.product} count={1} perPack={amount} answered={custom[i.position] != null} lang={app.lang} note={null} title={nl ? `Hoeveel ${i.product.name_nl?.toLowerCase() ?? i.product.name.toLowerCase()} heb je gebruikt?` : `How much ${i.product.name.toLowerCase()} did you use?`}
                    options={[...new Set([i.quantity * f * 0.5, i.quantity * f, i.quantity * f * 1.5].map((x) => (unit === 'pcs' ? Math.max(1, Math.round(x)) : Math.round(x))))]}
                    onAnswer={(v) => { setCustom((c) => ({ ...c, [i.position]: v })); setEditing(null); }} />
                )}
              </div>
            );
          })}
        </div>
        <div className="section-head" style={{ margin: '8px 0 0' }}><h2>{t('Leftovers?')}</h2></div>
        <div className="row"><span className="grow">🥡 {nl ? 'Porties in de koelkast' : 'Portions in the fridge'}</span><Stepper value={fridge} onChange={setFridge} min={0} /></div>
        <div className="row"><span className="grow">🧊 {nl ? 'Porties in de vriezer' : 'Portions in the freezer'}</span><Stepper value={freezer} onChange={setFreezer} min={0} /></div>
      </div>
    </Sheet>
  );
}

// ---------- Cooking mode ----------

function fmtTime(s: number) {
  const m = Math.floor(s / 60);
  return `${m}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
}

export function CookMode({ id }: { id: string }) {
  const app = useApp();
  const t = useT();
  const nl = app.lang === 'nl';
  const servings = useServingsParam();
  const { data } = useQuery<any>(`/api/recipes/${id}${servings ? `?servings=${servings}` : ''}`, ['recipes']);
  const [step, setStep] = useState(-1); // -1 = ingredients overview
  const [timers, setTimers] = useState<Record<number, { left: number; running: boolean }>>({});
  const [finishing, setFinishing] = useState(false);
  const steps = data?.recipe.steps ?? [];
  const stepRef = useRef(step);
  stepRef.current = step;

  const [ix] = useSetting<any>('household', 'interaction');
  // Keep the screen awake while cooking (unless switched off in Personalise).
  useEffect(() => {
    if (!ix || ix.keepAwake === false) return;
    let lock: any;
    const take = () => (navigator as any).wakeLock?.request('screen').then((l: any) => (lock = l)).catch(() => {});
    // The system lets go of the lock when the app goes to the background; take it again on return.
    const back = () => document.visibilityState === 'visible' && take();
    take();
    document.addEventListener('visibilitychange', back);
    return () => {
      document.removeEventListener('visibilitychange', back);
      lock?.release?.();
    };
  }, [ix?.keepAwake]);
  // Tick only while a timer runs: an idle cooking screen does no work.
  const ticking = Object.values(timers).some((x) => x.running && x.left > 0);
  useEffect(() => {
    if (!ticking) return;
    // Count by the clock, not by ticks: a phone slows or pauses timers while the screen is off or the app is
    // in the background, and the countdown must still be right when you look again.
    let last = Date.now();
    const iv = setInterval(() => {
      const passed = Math.floor((Date.now() - last) / 1000);
      if (passed < 1) return;
      last += passed * 1000;
      setTimers((ts) => {
        const out = { ...ts };
        for (const k of Object.keys(out)) {
          const x = out[+k];
          if (x.running && x.left > 0) {
            const left = Math.max(0, x.left - passed);
            out[+k] = { ...x, left };
            if (left === 0) {
              navigator.vibrate?.([300, 150, 300, 150, 300]);
              beep();
              say(nl ? `Timer van stap ${+k + 1} is klaar` : `Step ${+k + 1} timer is done`);
            }
          }
        }
        return out;
      });
    }, 1000);
    return () => clearInterval(iv);
  }, [ticking]);

  /** Speak without the mic hearing it: hands-free listening pauses while talking. */
  const say = (text: string) => {
    if (!('speechSynthesis' in window) || !text) return;
    const resume = handsFree.current;
    if (resume) speechRef.current?.stop();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = nl ? 'nl-NL' : 'en-US';
    u.onend = () => resume && handsFree.current && speechRef.current?.start();
    speechSynthesis.cancel();
    speechSynthesis.speak(u);
  };
  const startTimer = (i: number, secs: number) => setTimers((ts) => ({ ...ts, [i]: ts[i] ? { ...ts[i], running: !ts[i].running } : { left: secs, running: true } }));
  const go = (d: number) => setStep((s) => Math.max(-1, Math.min(steps.length - 1, s + d)));

  // Hands-free: the mic stays open and each phrase is a command (English or Dutch):
  // next · back · repeat · start/stop timer · ingredients · "how much butter?" · done.
  const [speechLang] = useSpeechLang(app.lang);
  const [readAloud, setReadAloud] = useState(false);
  const handsFree = useRef(false);
  const speechRef = useRef<ReturnType<typeof useSpeech> | null>(null);
  const command = (txt: string): boolean => {
    const x = txt.toLowerCase();
    const s = stepRef.current;
    const how = x.match(/(?:how much|how many|hoeveel)\s+(.+)/);
    if (how && data) {
      const q = how[1].replace(/\b(do i need|is it|heb ik nodig|nodig|the|de|het)\b/g, '').trim();
      const ing = data.recipe.ingredients.find((i: any) => [i.name, i.display, i.product?.name, i.product?.name_nl, ...(i.product?.synonyms ?? [])].some((n: string | undefined) => n && (n.toLowerCase().includes(q) || q.includes(n.toLowerCase()))));
      say(ing ? (ing.quantity != null && ing.product ? `${fmtQty(ing.quantity * data.factor, ing.product.unit, app.lang, ing.product.piece_name)} ${ing.product.name.toLowerCase()}` : ing.display ?? ing.name) : nl ? 'Dat staat niet in dit recept.' : 'That’s not in this recipe.');
      return true;
    }
    if (/\b(next|volgende|verder|door)\b/.test(x)) go(1);
    else if (/\b(back|previous|vorige|terug)\b/.test(x)) go(-1);
    else if (/\b(stop|pause|pauze)\b.*\b(timer|wekker)\b|\b(timer|wekker)\b.*\b(stop|uit|pauze)\b/.test(x)) setTimers((ts) => (ts[s] ? { ...ts, [s]: { ...ts[s], running: false } } : ts));
    else if (/\b(timer|wekker)\b/.test(x)) {
      if (steps[s]?.timerSeconds) startTimer(s, steps[s].timerSeconds);
    } else if (/\b(repeat|again|herhaal|nog een keer|read|lees)\b/.test(x)) say(steps[s]?.text ?? '');
    else if (/\b(ingredients|ingrediënten|ingredienten)\b/.test(x)) setStep(-1);
    else if (/\b(done|finished|finish|klaar|afgerond)\b/.test(x)) setFinishing(true);
    else return false;
    return true;
  };
  const speech = useSpeech(speechLang, () => {}, {
    list: true,
    onText: (txt) => {
      if (command(txt)) speechRef.current?.setHeard('');
    },
  });
  speechRef.current = speech;
  // Hands-free stays on through pauses; if the browser stops listening, start again.
  useEffect(() => {
    if (handsFree.current && !speech.listening && !speechSynthesis.speaking) {
      const t = setTimeout(() => handsFree.current && !speechSynthesis.speaking && speech.start(), 600);
      return () => clearTimeout(t);
    }
  }, [speech.listening]);
  // Personal defaults: read aloud, and hands-free from the first step (started by your tap on it).
  const autoStarted = useRef(false);
  useEffect(() => {
    if (ix?.cookReadAloud) setReadAloud(true);
  }, [ix?.cookReadAloud]);
  useEffect(() => {
    if (step === 0 && ix?.cookHandsFree && !autoStarted.current) {
      autoStarted.current = true;
      handsFree.current = true;
      speech.start();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step]);
  useEffect(() => {
    if (readAloud && step >= 0 && steps[step]) say(steps[step].text);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step, readAloud]);

  if (!data) return <div className="cook"><div className="stepview"><div className="skeleton" style={{ width: 300, height: 120 }} /></div></div>;
  const r = data.recipe;
  const f = data.factor;
  const cur = steps[step];
  const tm = timers[step];
  const activeTimers = Object.entries(timers).filter(([k, v]) => v.running && +k !== step);
  return (
    <div className="cook">
      <header>
        <button className="icon-btn" onClick={() => history.back()} aria-label={t('Close')}><X /></button>
        <div className="grow"><b>{r.title}</b><div className="tiny muted">{data.servings} {t('servings')}</div></div>
        <button className="icon-btn" aria-pressed={readAloud} style={readAloud ? { background: 'var(--herb)', color: '#fff' } : undefined} onClick={() => setReadAloud(!readAloud)} aria-label={nl ? 'Stappen voorlezen' : 'Read steps aloud'} title={nl ? 'Voorlezen' : 'Read aloud'}>🔊</button>
        <button className={`icon-btn ${speech.listening ? 'listening' : ''}`} style={handsFree.current ? { background: 'var(--tomato)', color: '#fff' } : undefined} onClick={() => {
          handsFree.current = !handsFree.current;
          if (handsFree.current) speech.start();
          else speech.stop();
        }} aria-label={nl ? 'Handsfree bediening' : 'Hands-free control'} aria-pressed={handsFree.current}><Mic /></button>
      </header>
      <div className="dots" aria-hidden>{[-1, ...steps.map((_: any, i: number) => i)].map((i) => <i key={i} className={i === step ? 'on' : ''} />)}</div>
      <div className="stepview">
        {step === -1 ? (
          <div style={{ width: 'min(620px, 100%)', textAlign: 'left' }}>
            <div className="stepnum" style={{ textAlign: 'center' }}>{t('Ingredients')}</div>
            {r.ingredients.filter((i: any) => i.sub?.prep && i.product_id).map((i: any) => (
              <div key={`prep-${i.position}`} className="card prep-note"><b>{i.sub.original} → {nl ? i.product.name_nl ?? i.product.name : i.product.name}</b><div className="small">{i.sub.prep[nl ? 1 : 0]}</div></div>
            ))}
            <div className="list" style={{ marginTop: 14 }}>
              {r.ingredients.map((i: any) => {
                const st = data.match.ingredients.find((x: any) => x.position === i.position);
                return (
                  <div key={i.position} className="ing" style={{ fontSize: 17 }}>
                    <span className={`dot ${st?.status}`} />
                    <span className="grow">{f !== 1 && i.quantity != null && i.product ? <b>{fmtQty(i.quantity * f, i.product.unit, app.lang, i.product.piece_name)} </b> : null}{i.extra_for ? (nl ? i.product?.name_nl ?? i.name : i.product?.name ?? i.name) : i.display ?? i.name}{i.sub && i.product_id ? <span className="muted small"> → {nl ? i.product.name_nl ?? i.product.name : i.product.name}</span> : null}</span>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          <div>
            <div className="stepnum">{nl ? 'Stap' : 'Step'} {step + 1} / {steps.length}</div>
            <div className="steptext">{cur.text}</div>
            <StepIngredients text={cur.text} ingredients={r.ingredients} factor={f} />
            {cur.timerSeconds && (
              <button className={`timer ${tm?.left === 0 ? 'done' : tm?.running ? 'running' : ''}`} onClick={() => (tm?.left === 0 ? setTimers((ts) => { const o = { ...ts }; delete o[step]; return o; }) : startTimer(step, cur.timerSeconds))}>
                {tm?.running ? <Pause size={20} /> : tm?.left === 0 ? <RotateCcw size={20} /> : <Play size={20} />} {fmtTime(tm?.left ?? cur.timerSeconds)}
              </button>
            )}
          </div>
        )}
      </div>
      {handsFree.current && (
        <div className="tiny muted" style={{ textAlign: 'center' }}>
          {nl ? '🎙 Zeg: “volgende”, “terug”, “herhaal”, “timer”, “hoeveel boter?”, “klaar”' : '🎙 Say: “next”, “back”, “repeat”, “timer”, “how much butter?”, “done”'}
        </div>
      )}
      {activeTimers.length > 0 && (
        <div className="row" style={{ justifyContent: 'center', gap: 8, flexWrap: 'wrap' }}>
          {activeTimers.map(([k, v]) => <span key={k} className="pill saffron">⏱ {nl ? 'Stap' : 'Step'} {+k + 1}: {fmtTime(v.left)}</span>)}
        </div>
      )}
      <footer>
        <button className="btn lg" onClick={() => go(-1)} disabled={step === -1}>{t('Back')}</button>
        {step < steps.length - 1 ? (
          <button className="btn primary lg grow" onClick={() => go(1)}>{step === -1 ? (nl ? 'Begin' : 'Start') : t('Next')}</button>
        ) : (
          <button className="btn primary lg grow" onClick={() => setFinishing(true)}><Check size={18} /> {t('Finish')}</button>
        )}
      </footer>
      {finishing && <CookedSheet recipe={r} servings={data.servings} ingredients={data.match.ingredients} onClose={() => setFinishing(false)} after={() => app.navigate('#/')} />}
    </div>
  );
}


const PART_LABEL: Record<string, [string, string]> = {
  energy: ['Portion energy', 'Energie portie'], protein: ['Protein', 'Eiwit'], fibre: ['Fibre', 'Vezels'], veg: ['Vegetables', 'Groente'], carbs: ['Carb share', 'Koolhydraataandeel'],
  fat: ['Fat share', 'Vetaandeel'], satFat: ['Saturated fat', 'Verzadigd vet'], sugar: ['Sugars', 'Suikers'], salt: ['Salt', 'Zout'],
};
const GRADE: Record<string, [string, string]> = {
  excellent: ['Excellent balance', 'Uitstekend gebalanceerd'], balanced: ['Well balanced', 'Goed gebalanceerd'], ok: ['OK', 'Redelijk'], light: ['Light meal', 'Lichte maaltijd'], treat: ['More of a treat', 'Meer een traktatie'],
};
const NUTRIENT_ROWS: [string, string, string, string][] = [
  ['kcal', 'Energy', 'Energie', 'kcal'], ['protein', 'Protein', 'Eiwit', 'g'], ['carbs', 'Carbohydrates', 'Koolhydraten', 'g'], ['sugars', '  of which sugars', '  waarvan suikers', 'g'],
  ['fat', 'Fat', 'Vet', 'g'], ['satFat', '  of which saturated', '  waarvan verzadigd', 'g'], ['fibre', 'Fibre', 'Vezels', 'g'], ['salt', 'Salt', 'Zout', 'g'],
];
const STATUS: Record<string, [string, string]> = {
  counted: ['', ''], assumed: ['assumed amount', 'aangenomen hoeveelheid'], optional: ['optional, not counted', 'optioneel, niet meegeteld'],
  no_product: ['not recognised, not counted', 'niet herkend, niet meegeteld'], no_amount: ['no amount, not counted', 'geen hoeveelheid, niet meegeteld'], no_data: ['no nutrition data', 'geen voedingsdata'],
};

/** Nutrition per serving and in total from the ingredients (incl. cooking fat), the balance score, and the per-ingredient audit. */
function BalancePanel({ r }: { r: any }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const [total, setTotal] = useState(false);
  const n = r.nutritionPerServing;
  const h = r.health;
  if (!n || !h) return null;
  const shown = total ? r.nutritionTotal : n;
  const kcalFrom = (g: number, k: number) => (n.kcal ? Math.round(((g * k) / n.kcal) * 100) : 0);
  const fmt = (k: string, v: number) => (k === 'kcal' ? Math.round(v) : k === 'salt' ? v.toFixed(2) : v >= 10 ? Math.round(v) : v.toFixed(1));
  const uncounted = (r.nutritionAudit ?? []).filter((l: any) => ['no_product', 'no_amount', 'no_data'].includes(l.status));
  return (
    <details className="card pad balance" style={{ margin: '12px 0' }}>
      <summary className="row" style={{ gap: 10 }}>
        <span className={`score-ring ${h.grade}`}>{h.score}</span>
        <span className="grow">
          <b>{(GRADE[h.grade] ?? GRADE.ok)[nl ? 1 : 0]}</b>
          <span className="tiny muted" style={{ display: 'block' }}>{n.kcal} kcal · P {Math.round(n.protein)} g · {nl ? 'K' : 'C'} {Math.round(n.carbs)} g · {nl ? 'V' : 'F'} {Math.round(n.fat)} g · {nl ? 'vezels' : 'fibre'} {Math.round(n.fibre)} g {nl ? 'per portie' : 'per serving'}</span>
          {uncounted.length > 0 && <span className="tiny" style={{ display: 'block', color: 'var(--saffron)' }}>{nl ? `${uncounted.length} ingrediënt(en) niet meegeteld` : `${uncounted.length} ingredient(s) not counted`}</span>}
        </span>
      </summary>
      <div className="macro-bar" aria-hidden>
        <i className="p" style={{ width: `${kcalFrom(n.protein, 4)}%` }} /><i className="c" style={{ width: `${kcalFrom(n.carbs, 4)}%` }} /><i className="f" style={{ width: `${kcalFrom(n.fat, 9)}%` }} />
      </div>
      <div className="tiny muted">{nl ? 'Energie uit eiwit' : 'Energy from protein'} {kcalFrom(n.protein, 4)}% · {nl ? 'koolhydraten' : 'carbs'} {kcalFrom(n.carbs, 4)}% · {nl ? 'vet' : 'fat'} {kcalFrom(n.fat, 9)}%</div>

      <div className="row" style={{ margin: '10px 0 4px' }}>
        <b className="small grow">{nl ? 'Voedingswaarden' : 'Nutrition'}</b>
        <div className="seg" style={{ width: 190 }}>
          <button className={!total ? 'on' : ''} onClick={() => setTotal(false)}>{nl ? 'Per portie' : 'Per serving'}</button>
          <button className={total ? 'on' : ''} onClick={() => setTotal(true)}>{nl ? 'Totaal' : 'Total'}</button>
        </div>
      </div>
      <table className="nutri-table">
        <tbody>
          {NUTRIENT_ROWS.map(([k, en, nlLabel, unit]) => (
            <tr key={k} className={en.startsWith(' ') ? 'sub' : ''}><td>{(nl ? nlLabel : en).trim()}</td><td className="num">{fmt(k, shown[k] ?? 0)} {unit}</td></tr>
          ))}
        </tbody>
      </table>

      <b className="small" style={{ display: 'block', margin: '12px 0 4px' }}>{nl ? 'Balansscore' : 'Balance score'}</b>
      <div className="stack" style={{ gap: 4 }}>
        {h.parts.map((p: any) => (
          <div key={p.key} className="row small">
            <span style={{ width: 104 }}>{PART_LABEL[p.key]?.[nl ? 1 : 0] ?? p.key}</span>
            <div className="xp-bar thin grow"><i style={{ width: `${(p.points / p.max) * 100}%` }} /></div>
            <span className="num tiny" style={{ width: 92, textAlign: 'right' }} title={p.target}>{p.value}{p.key === 'energy' ? '' : ['fat', 'satFat', 'sugar', 'carbs'].includes(p.key) ? '%' : ' g'} · {p.target}</span>
          </div>
        ))}
      </div>

      <details style={{ marginTop: 10 }}>
        <summary className="small" style={{ cursor: 'pointer' }}><b>{nl ? 'Hoe is dit berekend?' : 'How this was calculated'}</b></summary>
        <div className="stack" style={{ gap: 4, marginTop: 6 }}>
          {(r.nutritionAudit ?? []).map((l: any, i: number) => (
            <div key={i} className={`audit-line ${l.status}`}>
              <span className="grow">
                {l.name}
                <span className="tiny muted" style={{ display: 'block' }}>
                  {l.productName ? `→ ${l.productName}` : ''}{l.grams != null ? ` · ${l.grams} g` : ''}{STATUS[l.status]?.[nl ? 1 : 0] ? ` · ${STATUS[l.status][nl ? 1 : 0]}` : ''}{l.missing?.length ? ` · ${nl ? 'onbekend' : 'unknown'}: ${l.missing.join(', ')}` : ''}
                </span>
                {l.adjustable && l.position != null && l.status !== 'optional' && (
                  <select className="input sm retention-select" value={String(l.retention ?? 1)} aria-label={nl ? `Hoeveel van ${l.name} eet je op?` : `How much of ${l.name} is eaten?`} onChange={async (e) => {
                    await api('PUT', `/api/recipes/${r.id}/retention`, { position: l.position, retention: Number(e.target.value) >= 1 ? null : Number(e.target.value) });
                    invalidate(['recipes']);
                  }}>
                    {RETENTION.map(([v, en, nlL]) => <option key={v} value={String(v)}>{nl ? nlL : en}</option>)}
                  </select>
                )}
              </span>
              <span className="num tiny">{l.contribution ? `${Math.round(l.contribution.kcal)} kcal` : '—'}</span>
            </div>
          ))}
        </div>
        <p className="tiny muted">{nl ? 'Waarden per 100 g uit PantryPips tabel (algemene waarden in lijn met CIQUAL/USDA) of Open Food Facts voor gescande producten. Lepels en kopjes worden met de dichtheid van het product omgerekend. Een schatting, geen medisch advies.' : 'Per-100 g values from PantryPip’s table (generic values in line with CIQUAL/USDA) or Open Food Facts for scanned products. Spoons and cups are converted with each product’s density. An estimate, not medical advice.'}</p>
      </details>
    </details>
  );
}

// Part of a frying fat or marinade stays in the pan or bowl. Counting all of it is the default, so
// calories are never quietly underestimated.
const RETENTION: [number, string, string][] = [[1, 'All of it counted', 'Alles meegeteld'], [0.75, 'About ¾ eaten', 'Ongeveer ¾ opgegeten'], [0.5, 'About half eaten', 'Ongeveer de helft opgegeten'], [0.25, 'About ¼ eaten', 'Ongeveer ¼ opgegeten']];

/** "Cooked 4× · last 2 Nov" with the dates. */
function RecipeHistory({ history }: { history: { created_at: string; servings: number }[] }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  if (!history.length) return <div className="tiny muted row" style={{ gap: 6, margin: '0 0 8px' }}><History size={14} /> {nl ? 'Nog niet gekookt: nieuw voor je!' : 'Not cooked yet: new to you!'}</div>;
  const d = (iso: string) => new Date(iso).toLocaleDateString(nl ? 'nl-NL' : 'en-GB', { day: 'numeric', month: 'short' });
  return (
    <details className="tiny muted" style={{ margin: '0 0 8px' }}>
      <summary className="row" style={{ gap: 6, cursor: 'pointer' }}><History size={14} /> {nl ? `${history.length}× gekookt · laatst ${d(history[0].created_at)}` : `Cooked ${history.length}× · last ${d(history[0].created_at)}`}</summary>
      <div style={{ paddingLeft: 20 }}>{history.map((h) => `${d(h.created_at)} (${h.servings})`).join(' · ')}</div>
    </details>
  );
}

/** Personal notes, saved when you leave the field. */
function RecipeNotes({ recipeId, notes }: { recipeId: string; notes: string }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const [v, setV] = useState(notes);
  const [open, setOpen] = useState(!!notes);
  useEffect(() => setV(notes), [notes]);
  if (!open) return <button className="btn ghost sm" style={{ marginBottom: 8 }} onClick={() => setOpen(true)}>✎ {nl ? 'Notitie toevoegen' : 'Add a note'}</button>;
  return (
    <textarea
      className="input"
      rows={2}
      style={{ marginBottom: 8 }}
      value={v}
      placeholder={nl ? 'Bijv. “minder chili, kinderen vonden het top”' : 'E.g. “less chilli, kids loved it”'}
      aria-label={nl ? 'Mijn notities' : 'My notes'}
      onChange={(e) => setV(e.target.value)}
      onBlur={async () => { if (v !== notes) { await post(`/api/recipes/${recipeId}/interaction`, { notes: v }); invalidate(['recipes']); } }}
    />
  );
}

/** A photo for your own recipe, straight from the camera. */
function PhotoButton({ recipeId }: { recipeId: string }) {
  const app = useApp();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const input = useRef<HTMLInputElement>(null);
  return (
    <>
      <button className="btn ghost sm" style={{ marginBottom: 8 }} onClick={() => input.current?.click()}><Camera size={15} /> {nl ? 'Foto' : 'Photo'}</button>
      <input ref={input} type="file" accept="image/*" capture="environment" hidden onChange={async (e) => {
        const f = e.target.files?.[0];
        if (!f) return;
        try {
          const img = await shrink(f, 1200);
          await post(`/api/recipes/${recipeId}/photo`, { data: img.preview });
          invalidate(['recipes']);
        } catch (err: any) {
          toast({ text: err.message, error: true });
        }
      }} />
    </>
  );
}

/** How practical a recipe is with what's sold in your country. */
export function CompatBadge({ c, compact }: { c: { level: string; substitutions: number; unresolved: number; specialist: number }; compact?: boolean }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const text: Record<string, [string, string]> = {
    substitutions: [`With ${c.substitutions} substitution${c.substitutions === 1 ? '' : 's'}`, `Met ${c.substitutions} vervanging${c.substitutions === 1 ? '' : 'en'}`],
    partial: [`${c.unresolved} ingredient${c.unresolved === 1 ? '' : 's'} to check`, `${c.unresolved} ingrediënt${c.unresolved === 1 ? '' : 'en'} om na te kijken`],
    specialist: ['Needs a specialist shop', 'Speciaalzaak nodig'],
  };
  if (!text[c.level]) return null;
  return <span className={`pill compat ${c.level} ${compact ? 'compact' : ''}`}>{text[c.level][nl ? 1 : 0]}</span>;
}

const OFTEN: [number, string, string][] = [[-2, 'Never', 'Nooit'], [-1, 'Less', 'Minder'], [0, 'Normal', 'Normaal'], [1, 'More', 'Vaker'], [2, 'Favourite', 'Favoriet']];
/** How often the week planner should pick this recipe. */
function HowOften({ recipeId, value }: { recipeId: string; value: number }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  return (
    <div className="stack" style={{ gap: 4, margin: '0 0 10px' }}>
      <span className="tiny muted">{nl ? 'Hoe vaak in “Plan mijn week”' : 'How often in “Plan my week”'}</span>
      <div className="seg" role="radiogroup">
        {OFTEN.map(([v, en, nlLabel]) => (
          <button key={v} role="radio" aria-label={nl ? nlLabel : en} aria-checked={value === v} className={value === v ? 'on' : ''} onClick={async () => { await post(`/api/recipes/${recipeId}/interaction`, { priority: v }); invalidate(['recipes']); }}>
            {v === 2 ? '★' : nl ? nlLabel : en}
          </button>
        ))}
      </div>
    </div>
  );
}

/** The amounts used in this step, so you don't have to scroll back to the ingredient list. */
function StepIngredients({ text, ingredients, factor }: { text: string; ingredients: any[]; factor: number }) {
  const app = useApp();
  const t = text.toLowerCase();
  const used = ingredients.filter((i) => {
    const names = [i.product?.name, i.product?.name_nl, ...(i.product?.synonyms ?? []), i.name].filter(Boolean).map((n: string) => n.toLowerCase());
    return names.some((n: string) => n.length > 2 && (t.includes(n) || t.includes(n.split(' ').slice(-1)[0])));
  });
  if (!used.length) return null;
  return (
    <div className="step-ings">
      {used.map((i) => (
        <span key={i.position} className="chip">{i.quantity != null && i.product ? <b>{fmtQty(i.quantity * factor, i.product.unit, app.lang, i.product.piece_name)}</b> : null} {(i.product?.name ?? i.name).toLowerCase()}</span>
      ))}
    </div>
  );
}

/** A short, clearly audible beep (works on phones once the page has had a tap). */
function beep() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    for (let i = 0; i < 3; i++) {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.frequency.value = 880;
      g.gain.setValueAtTime(0.0001, ctx.currentTime + i * 0.35);
      g.gain.exponentialRampToValueAtTime(0.4, ctx.currentTime + i * 0.35 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + i * 0.35 + 0.25);
      o.connect(g).connect(ctx.destination);
      o.start(ctx.currentTime + i * 0.35);
      o.stop(ctx.currentTime + i * 0.35 + 0.3);
    }
  } catch {
    /* no audio */
  }
}
