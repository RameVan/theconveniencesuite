// Settings: eight categories, each one page. Every control reads and writes the settings store
// (settings.tsx): changes show at once, save in the background, and the small note at the bottom
// says when they're saved. Advanced options sit under "More options".
import { useEffect, useState, type ReactNode } from 'react';
import { ChevronLeft, ChevronRight, Globe, Salad, CalendarDays, Activity, Bell, LayoutGrid, UserRound, Copy, Download, LogOut, Trash2, Store } from 'lucide-react';
import { SubstitutionSheet } from '../components/Ingredient';
import { api, get, post, useQuery, invalidate } from '../api';
import { useApp } from '../app-context';
import { fmtQty } from '../i18n';
import { Stepper, useToast } from '../components/ui';
import { DietaryNeedsEditor, NutritionPeople } from '../components/DietaryNeeds';
import { IPhoneSettings } from '../components/IPhoneSettings';
import { STYLES } from '../appearance';
import { useSetting, useSettings } from '../settings';

type Txt = [string, string];
const CATS: { id: string; icon: typeof Globe; title: Txt; desc: Txt; tint: string }[] = [
  { id: 'general', icon: Globe, title: ['General', 'Algemeen'], desc: ['Language, appearance, accessibility', 'Taal, weergave, toegankelijkheid'], tint: 'var(--sky)' },
  { id: 'food', icon: Salad, title: ['Food preferences', 'Eetvoorkeuren'], desc: ['Diets, allergies, cuisines', 'Diëten, allergieën, keukens'], tint: 'var(--herb)' },
  { id: 'planning', icon: CalendarDays, title: ['Meal planning', 'Maaltijdplanning'], desc: ['Dinner days, cooking time, use-first', 'Kookdagen, kooktijd, eerst op'], tint: 'var(--saffron)' },
  { id: 'shopping', icon: Store, title: ['Shopping & ingredients', 'Boodschappen & ingrediënten'], desc: ['Country, supermarkets, usual types, substitutions', 'Land, supermarkten, vaste soorten, vervangingen'], tint: 'var(--sky)' },
  { id: 'nutrition', icon: Activity, title: ['Nutrition', 'Voeding'], desc: ['Calories, protein, other targets', 'Calorieën, eiwit, andere doelen'], tint: 'var(--tomato)' },
  { id: 'notifications', icon: Bell, title: ['Notifications', 'Meldingen'], desc: ['Expiry, meals, weekly planning', 'Houdbaarheid, maaltijden, weekplanning'], tint: 'var(--plum)' },
  { id: 'personal', icon: LayoutGrid, title: ['Personalisation', 'Persoonlijk'], desc: ['Home screen, start page, shortcuts', 'Startscherm, startpagina, snelkoppelingen'], tint: 'var(--herb-2)' },
  { id: 'account', icon: UserRound, title: ['Account & data', 'Account en gegevens'], desc: ['Household, devices, export', 'Huishouden, apparaten, export'], tint: 'var(--ink-3)' },
];
const DAYS = { en: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], nl: ['zo', 'ma', 'di', 'wo', 'do', 'vr', 'za'] };
const MEAL_TYPE_NL: Record<string, string> = { quick: 'snel', 'one-pan': 'één pan', traybake: 'ovenschotel', soup: 'soep', salad: 'salade', pasta: 'pasta', curry: 'curry', bowl: 'bowl', comfort: 'comfortfood', 'batch-cook': 'voor meerdere dagen', family: 'gezin', 'no-cook': 'zonder koken', budget: 'budget', 'low-carb': 'koolhydraatarm', 'high-protein': 'eiwitrijk' };
const PRIORITIES: [string, string, string][] = [['protein', 'More protein', 'Meer eiwit'], ['fibre', 'More fibre', 'Meer vezels'], ['veg', 'More vegetables', 'Meer groente'], ['lessSalt', 'Less salt', 'Minder zout'], ['lessSugar', 'Less sugar', 'Minder suiker'], ['lessSatFat', 'Less saturated fat', 'Minder verzadigd vet']];

// ---------- Building blocks (one look for every setting) ----------
function Group({ title, footer, children }: { title?: string; footer?: ReactNode; children: ReactNode }) {
  return (
    <section className="set-group">
      {title && <h2 className="set-title">{title}</h2>}
      <div className="set-card">{children}</div>
      {footer && <p className="set-foot">{footer}</p>}
    </section>
  );
}
function Row({ label, hint, children, stacked }: { label: string; hint?: ReactNode; children?: ReactNode; stacked?: boolean }) {
  return (
    <div className={`set-row ${stacked ? 'stacked' : ''}`}>
      <div className="set-label"><span>{label}</span>{hint && <span className="set-hint">{hint}</span>}</div>
      {children && <div className="set-control">{children}</div>}
    </div>
  );
}
function Toggle({ label, hint, on, onChange }: { label: string; hint?: string; on: boolean; onChange: (v: boolean) => void }) {
  return (
    <Row label={label} hint={hint}>
      <button className="switch" role="switch" aria-checked={on} aria-label={label} onClick={() => onChange(!on)} />
    </Row>
  );
}
function Choice<T extends string | number>({ label, hint, value, options, onChange }: { label: string; hint?: string; value: T; options: [T, string][]; onChange: (v: T) => void }) {
  return (
    <Row label={label} hint={hint} stacked>
      <div className="seg mini wrapseg" role="radiogroup" aria-label={label}>
        {options.map(([v, l]) => <button key={String(v)} role="radio" aria-checked={value === v} className={value === v ? 'on' : ''} onClick={() => onChange(v)}>{l}</button>)}
      </div>
    </Row>
  );
}
function Chips({ label, hint, all, on, onChange }: { label: string; hint?: string; all: [string, string][]; on: string[]; onChange: (v: string[]) => void }) {
  return (
    <Row label={label} hint={hint} stacked>
      <div className="chips set-chips" role="group" aria-label={label}>
        {all.map(([v, l]) => <button key={v} className={`chip ${on.includes(v) ? 'on' : ''}`} aria-pressed={on.includes(v)} onClick={() => onChange(on.includes(v) ? on.filter((x) => x !== v) : [...on, v])}>{l}</button>)}
      </div>
    </Row>
  );
}
function More({ label, children }: { label: string; children: ReactNode }) {
  return (
    <details className="set-more">
      <summary>{label}</summary>
      <div className="set-card">{children}</div>
    </details>
  );
}
/** A number field that saves when you're done typing (not on every keystroke) and only valid values. */
function NumberRow({ label, hint, value, min, max, step = 1, onSave }: { label: string; hint?: string; value: number; min: number; max: number; step?: number; onSave: (n: number) => void }) {
  const [v, setV] = useState(String(value));
  useEffect(() => setV(String(value)), [value]);
  const commit = () => {
    const n = Number(v.replace(',', '.'));
    if (Number.isFinite(n) && n >= min && n <= max) {
      if (n !== value) onSave(n);
    } else setV(String(value));
  };
  return (
    <Row label={label} hint={hint}>
      <input className="input set-num" inputMode="decimal" value={v} aria-label={label} onChange={(e) => setV(e.target.value)} onBlur={commit} onKeyDown={(e) => e.key === 'Enter' && (e.target as HTMLInputElement).blur()} />
    </Row>
  );
}

export function SettingsPage({ category }: { category?: string }) {
  const app = useApp();
  const nl = app.lang === 'nl';
  const cat = CATS.find((c) => c.id === category);
  if (!cat) return <SettingsHome />;
  const Page = { general: General, food: Food, planning: Planning, shopping: ShoppingIngredients, nutrition: Nutrition, notifications: Notifications, personal: Personal, account: Account }[cat.id]!;
  return (
    <>
      <div className="topbar">
        <a className="icon-btn ghost" href="#/settings" aria-label={nl ? 'Terug naar instellingen' : 'Back to settings'}><ChevronLeft /></a>
        <div className="grow"><h1>{nl ? cat.title[1] : cat.title[0]}</h1></div>
      </div>
      <div className="set-page"><Page /></div>
    </>
  );
}

function SettingsHome() {
  const app = useApp();
  const nl = app.lang === 'nl';
  return (
    <>
      <div className="topbar"><h1>{nl ? 'Instellingen' : 'Settings'}</h1></div>
      <div className="set-page">
        <a className="set-account" href="#/settings/account">
          <span className="set-avatar" aria-hidden>{(app.me?.user?.name ?? '?').slice(0, 1).toUpperCase()}</span>
          <span className="grow"><b>{app.me?.user?.name}</b><span className="set-hint">{app.me?.user?.email}</span></span>
          <ChevronRight size={18} className="muted" />
        </a>
        <div className="set-card set-nav">
          {CATS.filter((c) => c.id !== 'account').map((c) => (
            <a key={c.id} className="set-row set-link" href={`#/settings/${c.id}`}>
              <span className="set-icon" style={{ background: c.tint }} aria-hidden><c.icon size={17} /></span>
              <span className="set-label"><span>{nl ? c.title[1] : c.title[0]}</span><span className="set-hint">{nl ? c.desc[1] : c.desc[0]}</span></span>
              <ChevronRight size={18} className="muted" />
            </a>
          ))}
        </div>
        <p className="set-foot">{nl ? 'Instellingen worden in je account bewaard en volgen je naar elk apparaat. Alles werkt ook zonder iets in te stellen.' : 'Settings are saved to your account and follow you to every device. Everything works without changing anything.'}</p>
      </div>
    </>
  );
}

// ---------- General ----------
function General() {
  const app = useApp();
  const nl = app.lang === 'nl';
  const [language, setLanguage] = useSetting<string>('me', 'language');
  const [look, setLook] = useSetting<any>('me', 'appearance');
  const [ix, setIx] = useSetting<any>('household', 'interaction');
  return (
    <>
      <Group title={nl ? 'Taal' : 'Language'} footer={nl ? 'Spraak werkt in het Nederlands en Engels.' : 'Voice works in English and Dutch.'}>
        <Choice label={nl ? 'Taal van de app' : 'App language'} value={language} options={[['auto', nl ? 'Automatisch' : 'Automatic'], ['en', 'English'], ['nl', 'Nederlands']]} onChange={setLanguage} />
        <Row label={nl ? 'Eenheden' : 'Units'} hint={nl ? 'Lepels en kopjes worden omgerekend' : 'Spoons and cups are converted'}><span className="set-value">{nl ? 'Metrisch (g, ml)' : 'Metric (g, ml)'}</span></Row>
      </Group>
      <Group title={nl ? 'Weergave' : 'Appearance'}>
        <Row label={nl ? 'Stijl' : 'Style'} stacked>
          <div className="style-picks" role="radiogroup" aria-label={nl ? 'Stijl' : 'Style'}>
            {STYLES.map((s) => (
              <button key={s.id} role="radio" aria-checked={look.style === s.id} className={`style-pick ${look.style === s.id ? 'on' : ''}`} onClick={() => setLook({ style: s.id })}>
                <span className="sp-preview" style={{ background: s.bg }} aria-hidden>
                  <span className="sp-band" style={{ background: s.band }}><i style={{ background: s.onBand }} /></span>
                  <span className="sp-tiles">{s.tiles.map((c, i) => <i key={i} style={{ background: c }} />)}</span>
                  <span className="sp-card" style={{ background: s.card }}><i style={{ background: s.ink }} /><b style={{ background: s.accent }} /></span>
                </span>
                <span className="sp-name">{nl ? s.name[1] : s.name[0]}</span>
              </button>
            ))}
          </div>
        </Row>
        <Choice label={nl ? 'Licht of donker' : 'Light or dark'} hint={look.style === 'night' ? (nl ? 'Nachtvoorraad is altijd donker' : 'Night Pantry is always dark') : undefined} value={look.theme} options={[['system', nl ? 'Systeem' : 'System'], ['light', nl ? 'Licht' : 'Light'], ['dark', nl ? 'Donker' : 'Dark']]} onChange={(v) => setLook({ theme: v })} />
        <Toggle label={nl ? 'Uitgaven en verspilling tonen' : 'Show spending & waste'} hint={nl ? 'Bedragen en weggegooid eten in Statistieken' : 'Money and food thrown away, in Statistics'} on={look.showMoney !== false} onChange={(v) => setLook({ showMoney: v })} />
      </Group>
      <Group title={nl ? 'Toegankelijkheid' : 'Accessibility'}>
        <Choice label={nl ? 'Tekstgrootte' : 'Text size'} value={look.textSize} options={[['normal', nl ? 'Normaal' : 'Normal'], ['large', nl ? 'Groot' : 'Large']]} onChange={(v) => setLook({ textSize: v })} />
        <Choice label={nl ? 'Animaties' : 'Animations'} value={look.motion} options={[['full', nl ? 'Aan' : 'On'], ['reduced', nl ? 'Rustig' : 'Reduced'], ['off', nl ? 'Uit' : 'Off']]} onChange={(v) => setLook({ motion: v })} />
        <Toggle label={nl ? 'Spraak eerst' : 'Voice first'} hint={nl ? 'De microfoonknop luistert meteen' : 'The mic button starts listening straight away'} on={ix.voiceFirst !== false} onChange={(v) => setIx({ voiceFirst: v })} />
        <Toggle label={nl ? 'Eerst vragen bij weggooien' : 'Ask before throwing food away'} hint={nl ? 'Anders meteen, met Ongedaan maken' : 'Otherwise right away, with Undo'} on={!!ix.confirmDestructive} onChange={(v) => setIx({ confirmDestructive: v })} />
      </Group>
      <More label={nl ? 'Meer weergave-opties' : 'More display options'}>
        <Choice label={nl ? 'Ruimte' : 'Spacing'} value={look.density} options={[['comfortable', nl ? 'Ruim' : 'Comfortable'], ['compact', 'Compact']]} onChange={(v) => setLook({ density: v })} />
        <Choice label={nl ? 'Kaarten' : 'Cards'} value={look.cards} options={[['soft', nl ? 'Zacht' : 'Soft'], ['outlined', nl ? 'Omlijnd' : 'Outlined'], ['flat', nl ? 'Plat' : 'Flat']]} onChange={(v) => setLook({ cards: v })} />
      </More>
    </>
  );
}

// ---------- Food ----------
function Food() {
  const app = useApp();
  const nl = app.lang === 'nl';
  const opts = useQuery<any>('/api/preferences', ['preferences']).data;
  const plan = useQuery<any>(`/api/plan/auto/prefs?lang=${app.lang}`, ['preferences']).data;
  const [cuisines, setCuisines] = useSetting<string[]>('household', 'cuisines');
  const [fav, setFav] = useSetting<string[]>('household', 'favouriteFoods');
  const [types, setTypes] = useSetting<string[]>('household', 'mealTypes');
  return (
    <>
      <DietaryNeedsEditor />
      <Group title={nl ? 'Wat je lekker vindt' : 'What you like'} footer={nl ? 'Krijgt voorrang als PantryPip je week plant.' : 'Gets priority when PantryPip plans your week.'}>
        <Chips label={nl ? 'Favoriete keukens' : 'Favourite cuisines'} all={(opts?.cuisineOptions ?? []).map((c: string) => [c, c])} on={cuisines} onChange={setCuisines} />
        <Chips label={nl ? 'Favoriete ingrediënten' : 'Favourite ingredients'} all={(plan?.options ?? []).map((o: any) => [o.id, o.name])} on={fav} onChange={setFav} />
      </Group>
      <More label={nl ? 'Soorten maaltijden' : 'Meal types'}>
        <Chips label={nl ? 'Soorten maaltijden die je graag eet' : 'Meal types you like'} all={(opts?.mealTypeOptions ?? []).map((m: string) => [m, nl ? MEAL_TYPE_NL[m] ?? m : m.replace('-', ' ')])} on={types} onChange={setTypes} />
      </More>
    </>
  );
}

// ---------- Meal planning ----------
function Planning() {
  const app = useApp();
  const nl = app.lang === 'nl';
  const h = useSettings().settings.household;
  const set = useSettings().set;
  const s = (k: string) => (v: any) => set('household', k, v);
  const lvl: [string, string][] = [['low', nl ? 'Weinig' : 'Low'], ['normal', nl ? 'Normaal' : 'Normal'], ['high', nl ? 'Veel' : 'High']];
  return (
    <>
      <Group title={nl ? 'Je week' : 'Your week'}>
        <Row label={nl ? 'Aantal personen' : 'People'} hint={nl ? 'Standaard aantal porties' : 'Default servings'}><Stepper value={h.householdSize} onChange={s('householdSize')} max={12} label={nl ? 'personen' : 'people'} /></Row>
        <Row label={nl ? 'Op welke dagen kook je?' : 'Which days do you cook?'} hint={nl ? `${h.planDays.length} avonden per week` : `${h.planDays.length} dinners a week`} stacked>
          <div className="pz-days">{[1, 2, 3, 4, 5, 6, 0].map((d) => <button key={d} className={`chip ${h.planDays.includes(d) ? 'on' : ''}`} aria-pressed={h.planDays.includes(d)} onClick={() => s('planDays')(h.planDays.includes(d) ? h.planDays.filter((x: number) => x !== d) : [...h.planDays, d])}>{DAYS[app.lang][d]}</button>)}</div>
        </Row>
        <Choice label={nl ? 'Kooktijd doordeweeks' : 'Weeknight cooking time'} value={h.maxWeeknightMinutes ?? 240} options={[[20, '20′'], [30, '30′'], [45, '45′'], [60, '60′'], [240, nl ? 'Geen limiet' : 'Any']]} onChange={s('maxWeeknightMinutes')} />
        <Choice label={nl ? 'Eerst opmaken wat bederft' : 'Use up what spoils first'} hint={nl ? 'Hoe sterk het plannen dit laat meewegen' : 'How strongly planning favours it'} value={h.autoPlanFifo} options={[['off', nl ? 'Uit' : 'Off'], ['balanced', nl ? 'Normaal' : 'Balanced'], ['strong', nl ? 'Sterk' : 'Strong']]} onChange={s('autoPlanFifo')} />
      </Group>
      <Group title={nl ? 'Koken' : 'Cooking'}>
        <Toggle label={nl ? 'Koken haalt ingrediënten uit voorraad' : 'Cooking takes ingredients out of stock'} hint={nl ? 'Uit: alleen de maaltijd wordt gelogd' : 'Off: only the meal is logged'} on={h.interaction.autoDeduct !== false} onChange={(v) => set('household', 'interaction', { autoDeduct: v })} />
        <Toggle label={nl ? 'Stappen voorlezen' : 'Read steps aloud'} on={!!h.interaction.cookReadAloud} onChange={(v) => set('household', 'interaction', { cookReadAloud: v })} />
        <Toggle label={nl ? 'Handsfree koken' : 'Hands-free cooking'} hint={nl ? 'Luistert vanaf stap 1 naar “volgende”, “timer”…' : 'Listens from step 1 for “next”, “timer”…'} on={!!h.interaction.cookHandsFree} onChange={(v) => set('household', 'interaction', { cookHandsFree: v })} />
        <Toggle label={nl ? 'Scherm aan houden' : 'Keep the screen on'} on={h.interaction.keepAwake !== false} onChange={(v) => set('household', 'interaction', { keepAwake: v })} />
        <Toggle label={nl ? 'Afgevinkte boodschappen naar voorraad' : 'Ticked shopping goes into stock'} hint={nl ? 'Na 6 uur, als je de boodschappen niet zelf afrondt' : 'After 6 hours, if you don’t finish the trip yourself'} on={h.interaction.shoppingAutoComplete !== false} onChange={(v) => set('household', 'interaction', { shoppingAutoComplete: v })} />
      </Group>
      <More label={nl ? 'Meer planningsopties' : 'More planning options'}>
        <Choice label={nl ? 'In het weekend' : 'Weekend cooking time'} value={h.maxWeekendMinutes ?? 0} options={[[30, '30′'], [60, '60′'], [90, '90′'], [0, nl ? 'Geen limiet' : 'Any']]} onChange={(v) => s('maxWeekendMinutes')(v || null)} />
        <Choice label={nl ? 'Moeilijkheid' : 'Difficulty'} value={h.maxDifficulty} options={[['easy', nl ? 'Makkelijk' : 'Easy'], ['medium', nl ? 'Gemiddeld' : 'Medium'], ['hard', nl ? 'Alles' : 'Any']]} onChange={s('maxDifficulty')} />
        <Row label={nl ? 'Plandag' : 'Planning day'} hint={nl ? 'Herinnering als je week nog leeg is' : 'A reminder if your week is still empty'}>
          <select className="select set-select" value={h.planningDay} onChange={(e) => s('planningDay')(Number(e.target.value))} aria-label={nl ? 'Plandag' : 'Planning day'}>{[1, 2, 3, 4, 5, 6, 0].map((d) => <option key={d} value={d}>{DAYS[app.lang][d]}</option>)}</select>
        </Row>
        <Choice label={nl ? 'Gewicht van sterren en favorieten' : 'How much ratings count'} value={h.ratingWeight} options={lvl} onChange={s('ratingWeight')} />
        <Choice label={nl ? 'Ingrediënten delen tussen dagen' : 'Share ingredients across days'} value={h.overlap} options={lvl} onChange={s('overlap')} />
        <Choice label={nl ? 'Afwisseling' : 'Variety'} value={h.variety} options={lvl} onChange={s('variety')} />
        <Choice label={nl ? 'Budget per portie' : 'Budget per serving'} value={h.budgetPerServing ?? 0} options={[[2, '€2'], [3, '€3'], [4, '€4'], [6, '€6'], [0, nl ? 'Geen' : 'None']]} onChange={(v) => s('budgetPerServing')(v || null)} />
        <Choice label={nl ? 'Nieuwe recepten per week' : 'New recipes per week'} value={h.newPerWeek ?? -1} options={[[-1, nl ? 'Vanzelf' : 'Auto'], [0, '0'], [1, '1'], [2, '2'], [3, '3']]} onChange={(v) => s('newPerWeek')(v < 0 ? null : v)} />
      </More>
    </>
  );
}

// ---------- Nutrition ----------
function Nutrition() {
  const app = useApp();
  const nl = app.lang === 'nl';
  const [pri, setPri] = useSetting<string[]>('household', 'nutritionPriorities');
  const [sens, setSens] = useSetting<string>('household', 'scoringSensitivity');
  const [t, setT] = useSetting<any>('household', 'nutritionTargets');
  return (
    <>
      <NutritionPeople />
      <Group title={nl ? 'Waar je op let' : 'What matters to you'} footer={nl ? 'De score kijkt naar balans: minder eten scoort nooit beter. Geen medisch advies.' : 'The score is about balance: eating less never scores better. Not medical advice.'}>
        <Chips label={nl ? 'Prioriteiten' : 'Priorities'} hint={nl ? 'Je weekplanning houdt er rekening mee' : 'Your week plan takes these into account'} all={PRIORITIES.map(([v, en, nlL]) => [v, nl ? nlL : en])} on={pri} onChange={setPri} />
        <Choice label={nl ? 'Hoe streng is de score?' : 'How strict is the score?'} value={sens} options={[['gentle', nl ? 'Mild' : 'Gentle'], ['standard', nl ? 'Normaal' : 'Standard'], ['strict', nl ? 'Streng' : 'Strict']]} onChange={setSens} />
      </Group>
      <More label={nl ? 'Andere doelen per dag' : 'Other daily targets'}>
        <NumberRow label={nl ? 'Vezels, minimaal (g)' : 'Fibre, at least (g)'} value={t.fibre ?? 30} min={10} max={80} onSave={(n) => setT({ fibre: n })} />
        <NumberRow label={nl ? 'Zout, maximaal (g)' : 'Salt, at most (g)'} value={t.saltMax ?? 6} min={1} max={15} onSave={(n) => setT({ saltMax: n })} />
        <NumberRow label={nl ? 'Verzadigd vet, max (% energie)' : 'Saturated fat, max (% energy)'} value={t.satFatPct ?? 10} min={5} max={20} onSave={(n) => setT({ satFatPct: n })} />
        <NumberRow label={nl ? 'Suikers, max (% energie)' : 'Sugars, max (% energy)'} value={t.sugarPct ?? 12.5} min={5} max={30} onSave={(n) => setT({ sugarPct: n })} />
        <NumberRow label={nl ? 'Koolhydraten, min (% energie)' : 'Carbohydrate, min (% energy)'} value={t.carbMinPct ?? 40} min={0} max={60} onSave={(n) => setT({ carbMinPct: n })} />
        <NumberRow label={nl ? 'Koolhydraten, max (% energie)' : 'Carbohydrate, max (% energy)'} value={t.carbMaxPct ?? 60} min={20} max={80} onSave={(n) => setT({ carbMaxPct: n })} />
      </More>
    </>
  );
}

// ---------- Notifications ----------
function urlBase64ToUint8Array(base64: string) {
  const pad = '='.repeat((4 - (base64.length % 4)) % 4);
  const raw = atob((base64 + pad).replace(/-/g, '+').replace(/_/g, '/'));
  return Uint8Array.from(raw, (c) => c.charCodeAt(0));
}
function Notifications() {
  const app = useApp();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const [n, setN] = useSetting<any>('household', 'notifications');
  const [checkin, setCheckin] = useSetting<any>('household', 'cookCheckin');
  const [push, setPush] = useState<'unknown' | 'on' | 'off' | 'unsupported' | 'denied'>('unknown');
  useEffect(() => {
    if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) return setPush('unsupported');
    if (Notification.permission === 'denied') return setPush('denied');
    navigator.serviceWorker.getRegistration().then((reg) => reg?.pushManager.getSubscription()).then((s) => setPush(s ? 'on' : 'off')).catch(() => setPush('off'));
  }, []);
  const enable = async () => {
    try {
      const perm = await Notification.requestPermission();
      if (perm !== 'granted') return setPush(perm === 'denied' ? 'denied' : 'off');
      const reg = (await navigator.serviceWorker.getRegistration()) ?? (await navigator.serviceWorker.register('/sw.js'));
      await navigator.serviceWorker.ready;
      const { publicKey } = await get('/api/push/key');
      const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: urlBase64ToUint8Array(publicKey) });
      await post('/api/push/subscribe', sub.toJSON());
      setPush('on');
      toast({ text: nl ? 'Meldingen staan aan op dit apparaat' : 'Notifications are on for this device' });
    } catch (e: any) {
      toast({ text: e.message, error: true });
    }
  };
  const disable = async () => {
    const reg = await navigator.serviceWorker.getRegistration();
    const sub = await reg?.pushManager.getSubscription();
    if (sub) {
      await post('/api/push/unsubscribe', { endpoint: sub.endpoint });
      await sub.unsubscribe();
    }
    setPush('off');
  };
  return (
    <>
      <Group title={nl ? 'Op dit apparaat' : 'On this device'}>
        <Row label={nl ? 'Meldingen' : 'Notifications'} hint={push === 'unsupported' ? (nl ? 'Op iPhone: zet PantryPip eerst op je beginscherm' : 'On iPhone, add PantryPip to your home screen first') : push === 'denied' ? (nl ? 'Geblokkeerd in je browserinstellingen' : 'Blocked in your browser settings') : undefined}>
          {push === 'on' ? <button className="btn sm ghost" onClick={disable}>{nl ? 'Uitzetten' : 'Turn off'}</button> : push === 'off' ? <button className="btn sm primary" onClick={enable}>{nl ? 'Aanzetten' : 'Turn on'}</button> : null}
        </Row>
      </Group>
      <Group title={nl ? 'Dagelijkse kookvraag' : 'Daily cooking question'} footer={nl ? '“Heb je X gekookt?” Ja haalt de ingrediënten uit je voorraad.' : '“Did you cook X?” Yes takes the ingredients out of your stock.'}>
        <Toggle label={nl ? 'Vraag het me elke dag' : 'Ask me every day'} on={checkin.enabled} onChange={(v) => setCheckin({ enabled: v })} />
        {checkin.enabled && <Row label={nl ? 'Om' : 'At'}><input className="input set-time" type="time" value={checkin.time} onChange={(e) => e.target.value && setCheckin({ time: e.target.value })} aria-label={nl ? 'Tijd van de kookvraag' : 'Time of the cooking question'} /></Row>}
      </Group>
      <Group title={nl ? 'Herinneringen' : 'Reminders'}>
        <Choice label={nl ? 'Hoe vaak' : 'How often'} value={n.frequency} options={[['all', nl ? 'Wanneer nodig' : 'As needed'], ['daily', nl ? '1× per dag' : 'Daily summary'], ['off', nl ? 'Uit' : 'Off']]} onChange={(v) => setN({ frequency: v })} />
        {n.frequency !== 'off' && (
          <>
            <Toggle label={nl ? 'Bijna over de datum' : 'Food about to expire'} on={n.expiry} onChange={(v) => setN({ expiry: v })} />
            <Toggle label={nl ? 'Wat je vanavond kookt' : 'Tonight’s dinner'} on={n.prep} onChange={(v) => setN({ prep: v })} />
            {n.prep && <Row label={nl ? 'Om' : 'At'}><input className="input set-time" type="time" value={n.prepTime} onChange={(e) => e.target.value && setN({ prepTime: e.target.value })} aria-label={nl ? 'Tijd van de herinnering' : 'Reminder time'} /></Row>}
            <Toggle label={nl ? 'Week plannen' : 'Plan your week'} hint={nl ? 'Op je plandag, als je week leeg is' : 'On your planning day, if the week is empty'} on={n.plan} onChange={(v) => setN({ plan: v })} />
          </>
        )}
      </Group>
      {n.frequency !== 'off' && (
        <More label={nl ? 'Meer herinneringen' : 'More reminders'}>
          <Toggle label={nl ? 'Boodschappen voor morgen' : 'Shopping for tomorrow'} on={n.shopping} onChange={(v) => setN({ shopping: v })} />
          <Toggle label={nl ? 'Kookreeks' : 'Cooking streak'} hint={nl ? 'Standaard uit: een rustdag is prima' : 'Off by default: a rest day is fine'} on={n.streak} onChange={(v) => setN({ streak: v })} />
          <Toggle label={nl ? 'Uitdaging bijna voorbij' : 'Challenge ending'} on={n.challenge} onChange={(v) => setN({ challenge: v })} />
        </More>
      )}
    </>
  );
}

// ---------- Personalisation ----------
const XP_LABEL: Record<string, [string, string]> = {
  cooked: ['Meal cooked', 'Maaltijd gekookt'], newRecipe: ['New recipe', 'Nieuw recept'], favourite: ['Favourite recipe', 'Favoriet recept'], planned: ['Cooked as planned', 'Volgens plan'],
  balanced: ['Balanced meal (max)', 'Gebalanceerd (max)'], rescued: ['Per rescued food', 'Per gered product'], newCuisine: ['New cuisine', 'Nieuwe keuken'], streak: ['Streak bonus (max)', 'Reeksbonus (max)'],
  planWeek: ['Week cooked as planned', 'Week volgens plan'], zeroWasteWeek: ['Zero-waste week', 'Week zonder verspilling'], badge: ['Badge', 'Badge'], challenge: ['Challenge', 'Uitdaging'],
  journeyTask: ['Journey task', 'Reistaak'], journeyMilestone: ['Reward chest', 'Beloningskist'], journeyBoss: ['Chapter challenge', 'Hoofdstukuitdaging'], journeyBonus: ['Bonus task', 'Bonustaak'], trackLevel: ['Track level', 'Padniveau'],
};
function Personal() {
  const app = useApp();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const [start, setStart] = useSetting<string>('me', 'startPage');
  const [qa, setQa] = useSetting<any[]>('household', 'quickActions');
  const [xp, setXp] = useSetting<Record<string, number>>('household', 'xpRules');
  const game = useQuery<any>('/api/game', ['game']).data;
  const [q, setQ] = useState('');
  const [res, setRes] = useState<any[]>([]);
  const resetHome = async () => {
    await post('/api/dashboard/reset', {});
    invalidate(['dashboard']);
    toast({ text: nl ? 'Startscherm teruggezet' : 'Home screen reset' });
  };
  return (
    <>
      <Group title={nl ? 'Startscherm' : 'Home screen'}>
        <Row label={nl ? 'Widgets en indeling' : 'Widgets and layout'} hint={nl ? 'Toevoegen, verwijderen, verplaatsen' : 'Add, remove, rearrange'}><a className="btn sm" href="#/?edit=1">{nl ? 'Aanpassen' : 'Customise'}</a></Row>
        <Row label={nl ? 'Standaardindeling' : 'Default layout'}><button className="btn sm ghost" onClick={resetHome}>{nl ? 'Terugzetten' : 'Reset'}</button></Row>
        <Choice label={nl ? 'Openen op' : 'Open the app on'} value={start} options={[['home', nl ? 'Thuis' : 'Home'], ['groceries', nl ? 'Boodschappen' : 'Groceries'], ['recipes', nl ? 'Recepten' : 'Recipes'], ['plan', 'Planner'], ['progress', nl ? 'Voortgang' : 'Progress']]} onChange={setStart} />
      </Group>
      <Group title={nl ? 'Snel gebruiken' : 'One-tap use'} footer={nl ? 'Knoppen op Thuis voor wat je vaak gebruikt, zoals een glas melk.' : 'Buttons on Home for things you use often, like a glass of milk.'}>
        {qa.map((a, i) => (
          <Row key={i} label={a.label}><button className="icon-btn ghost" aria-label={`${nl ? 'Verwijder' : 'Remove'} ${a.label}`} onClick={() => setQa(qa.filter((_, j) => j !== i))}><Trash2 size={16} /></button></Row>
        ))}
        <Row label={nl ? 'Toevoegen' : 'Add'} stacked>
          <input className="input" value={q} placeholder={nl ? 'Product zoeken…' : 'Find a product…'} aria-label={nl ? 'Product zoeken' : 'Find a product'} onChange={(e) => { setQ(e.target.value); if (e.target.value.length > 1) get(`/api/products?q=${encodeURIComponent(e.target.value)}`).then(setRes); else setRes([]); }} />
          {res.slice(0, 4).map((x) => {
            const amount = x.unit === 'ml' ? 250 : x.unit === 'g' ? (x.piece_size ? x.piece_size * 2 : 50) : 1;
            const label = `${fmtQty(amount, x.unit, app.lang, x.piece_name)} ${x.name.toLowerCase()}`;
            return <button key={x.id} className="btn sm" style={{ marginTop: 6 }} onClick={() => { setQa([...qa, { productId: x.id, quantity: amount, label }]); setQ(''); setRes([]); }}>+ {label}</button>;
          })}
        </Row>
      </Group>
      <More label={nl ? 'Punten per actie (XP)' : 'Points per action (XP)'}>
        {Object.keys(XP_LABEL).map((k) => (
          <NumberRow key={k} label={XP_LABEL[k][nl ? 1 : 0]} value={xp[k] ?? game?.rules?.[k] ?? 0} min={0} max={500} onSave={(n) => setXp({ [k]: n })} />
        ))}
      </More>
    </>
  );
}

// ---------- Account & data ----------
function Account() {
  const app = useApp();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const [token, setToken] = useState<string | null>(null);
  const household = app.me?.household;
  return (
    <>
      <Group title={nl ? 'Account' : 'Account'}>
        <Row label={app.me?.user?.name ?? ''} hint={app.me?.user?.email} />
        <Row label={nl ? 'Afmelden' : 'Sign out'}><button className="btn sm" onClick={async () => { await post('/api/auth/logout', {}); location.reload(); }}><LogOut size={15} /> {nl ? 'Afmelden' : 'Sign out'}</button></Row>
      </Group>
      {household && (
        <Group title={nl ? 'Huishouden' : 'Household'} footer={(app.me?.members ?? []).map((m: any) => m.name).join(', ')}>
          <Row label={nl ? 'Uitnodigingscode' : 'Invite code'} hint={nl ? 'Deel met je huisgenoten' : 'Share with your household'}>
            <span className="set-value num">{household.invite_code}</span>
            <button className="icon-btn ghost" aria-label={nl ? 'Kopieer code' : 'Copy code'} onClick={() => navigator.clipboard?.writeText(household.invite_code).then(() => toast({ text: nl ? 'Gekopieerd' : 'Copied' }))}><Copy size={16} /></button>
          </Row>
        </Group>
      )}
      <Group title={nl ? 'Synchronisatie en privacy' : 'Sync and privacy'} footer={nl ? 'Alles staat op je eigen PantryPip-server. Instellingen volgen je account; weergave en taal zijn per persoon, de rest geldt voor het hele huishouden.' : 'Everything lives on your own PantryPip server. Settings follow your account; appearance and language are per person, the rest is shared by the household.'}>
        <Row label={nl ? 'Je gegevens exporteren' : 'Export your data'} hint="JSON"><a className="btn sm" href="/api/export" download><Download size={15} /> Export</a></Row>
        <Row label="AI" hint={app.config?.ai ? app.config.aiModel : nl ? 'Uit: bonnen worden op je apparaat gelezen' : 'Off: receipts are read on your device'} />
      </Group>
      <IPhoneSettings />
      <More label={nl ? 'Apparaten en integraties' : 'Devices and integrations'}>
        <Row label={nl ? 'Apparaat-token' : 'Device token'} hint={nl ? 'Voor Home Assistant of een slimme weegschaal' : 'For Home Assistant or a smart scale'}><button className="btn sm" onClick={async () => setToken((await post('/api/preferences/device-token', {})).token)}>{nl ? 'Maken' : 'Create'}</button></Row>
        {token && <Row label="X-Larder-Token" hint={<code style={{ wordBreak: 'break-all' }}>{token}</code>} />}
        <Row label={nl ? 'Barcodes' : 'Barcodes'} hint={`Open Food Facts ${app.config?.barcodeLookup ? '✓' : '✕'}`} />
      </More>
    </>
  );
}

// ---------- Shopping & ingredients ----------
function ShoppingIngredients() {
  const app = useApp();
  const nl = app.lang === 'nl';
  const toast = useToast();
  const [country, setCountry] = useSetting<string>('household', 'country');
  const [source, setSource] = useSetting<'auto' | 'manual'>('household', 'countrySource');
  const [chains, setChains] = useSetting<string[]>('household', 'chains');
  const { data: opts } = useQuery<any>('/api/ingredients/country', ['preferences']);
  const { data: types } = useQuery<any[]>('/api/ingredients/types', ['recipes', 'preferences']);
  const { data: review } = useQuery<any[]>('/api/ingredients/review', ['recipes']);
  const [subFor, setSubFor] = useState<any>(null);
  const [locating, setLocating] = useState(false);
  const current = opts?.countries.find((c: any) => c.code === country);

  // Location only picks the country (offline, on the server); it never overrides a country you chose.
  const detect = () => {
    if (!navigator.geolocation) return toast({ text: nl ? 'Locatie is niet beschikbaar' : 'Location isn’t available', error: true });
    setLocating(true);
    navigator.geolocation.getCurrentPosition(async (pos) => {
      try {
        const r = await post('/api/ingredients/locate', { lat: pos.coords.latitude, lon: pos.coords.longitude });
        if (r.country) {
          setCountry(r.country);
          setSource('auto');
          toast({ text: nl ? `Land: ${r.country}` : `Country: ${r.country}` });
        } else toast({ text: nl ? 'Dit land kent PantryPip nog niet' : 'PantryPip doesn’t know this country yet' });
      } finally {
        setLocating(false);
      }
    }, () => {
      setLocating(false);
      toast({ text: nl ? 'Geen toestemming voor locatie' : 'No permission for location', error: true });
    }, { maximumAge: 86_400_000, timeout: 10_000 });
  };

  return (
    <>
      <Group title={nl ? 'Waar je boodschappen doet' : 'Where you shop'} footer={nl ? 'Bepaalt welke supermarkten, producten en vervangingen PantryPip gebruikt. Je locatie wordt alleen gebruikt om het land te kiezen en verlaat je server niet.' : 'Decides which supermarkets, products and substitutions PantryPip uses. Your location only picks the country and never leaves your server.'}>
        <Row label={nl ? 'Land' : 'Country'} hint={source === 'auto' ? (nl ? 'Via je locatie' : 'From your location') : nl ? 'Zelf gekozen' : 'Chosen by you'} stacked>
          <div className="row wrap" style={{ gap: 6 }}>
            <div className="seg mini wrapseg" role="radiogroup" aria-label={nl ? 'Land' : 'Country'}>
              {(opts?.countries ?? []).map((c: any) => (
                <button key={c.code} role="radio" aria-checked={country === c.code} className={country === c.code ? 'on' : ''} onClick={() => { setCountry(c.code); setSource('manual'); setChains([]); }}>
                  {nl ? c.name_nl : c.name}{c.supported ? '' : nl ? ' (nog geen gegevens)' : ' (no data yet)'}
                </button>
              ))}
            </div>
            <button className="btn sm ghost" disabled={locating} onClick={detect}>{locating ? '…' : nl ? 'Bepaal via locatie' : 'Use my location'}</button>
          </div>
        </Row>
        {current && (
          <Chips label={nl ? 'Je supermarkten' : 'Your supermarkets'} hint={nl ? 'Niets gekozen = allemaal' : 'None picked = all of them'} all={current.chains.map((c: any) => [c.id, `${c.name}${c.products ? ` (${c.products})` : ''}`])} on={chains} onChange={setChains} />
        )}
      </Group>

      <Group title={nl ? 'Je vaste soorten' : 'Your usual types'} footer={nl ? 'Zeg je alleen “melk” of “kaas”, dan gebruikt PantryPip deze soort. De eerste keer vraagt het welke.' : 'When you just say “milk” or “cheese”, PantryPip uses this type. The first time, it asks.'}>
        {!types?.length && <Row label={nl ? 'Nog geen vaste soorten' : 'No usual types yet'} />}
        {types?.map((x: any) => (
          <Row key={x.family} label={nl ? x.name_nl : x.name} hint={x.choice ? (nl ? x.choice.name_nl ?? x.choice.name : x.choice.name) : undefined}>
            <button className="btn sm ghost" onClick={async () => { await api('PUT', '/api/ingredients/choice', { key: `f:${x.family}`, choice: null }); invalidate(['recipes', 'preferences']); }}>{nl ? 'Opnieuw vragen' : 'Ask again'}</button>
          </Row>
        ))}
      </Group>

      <Group title={nl ? 'Ingrediënten om na te kijken' : 'Ingredients to check'} footer={nl ? 'Uit geïmporteerde recepten: niet gekoppeld, of vervangen door iets dat erop lijkt. Je keuze geldt voor al je recepten.' : 'From imported recipes: not matched, or replaced by something close. Your choice applies to all your recipes.'}>
        {!review?.length && <Row label={nl ? 'Niets na te kijken' : 'Nothing to check'} />}
        {review?.slice(0, 40).map((x: any) => (
          <Row key={x.key} label={x.name} hint={`${x.recipes} ${nl ? (x.recipes === 1 ? 'recept' : 'recepten') : x.recipes === 1 ? 'recipe' : 'recipes'} · ${x.choice === 'keep' ? (nl ? 'zoals geschreven' : 'as written') : x.choice ? (nl ? 'eigen keuze' : 'your choice') : x.suggestion ? `→ ${nl ? x.suggestion.name_nl ?? x.suggestion.name : x.suggestion.name}` : nl ? 'niet gekoppeld' : 'not matched'}`}>
            <button className="btn sm" onClick={() => setSubFor({ product_id: x.choice && x.choice !== 'keep' ? x.choice : x.suggestion?.id ?? null, sub: { fromKey: x.key, original: x.name, status: x.status, choice: x.choice === 'keep' ? 'keep' : x.choice ? 'user' : 'default', options: x.options.filter((o: any) => o.to).map((o: any) => ({ id: o.to.id, kind: o.kind, note: o.note })) } })}>{nl ? 'Kies' : 'Choose'}</button>
          </Row>
        ))}
      </Group>
      {subFor && <SubstitutionSheet ing={subFor} onClose={() => setSubFor(null)} />}
    </>
  );
}

