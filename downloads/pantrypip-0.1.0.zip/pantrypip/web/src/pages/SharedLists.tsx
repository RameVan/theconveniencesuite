// Shared shopping lists: a named list with friends from other households, for one shop together.
// Everyone sees changes live, who's getting what (claims) and who has what in their cart. "Done shopping"
// puts only what you ticked into your own stock. Your household's own list (Shopping.tsx) is separate.
import { useState } from 'react';
import { ArrowLeft, Plus, Check, X, Users, ShoppingCart, Trash2, LogOut, Hand, Pencil, UserPlus } from 'lucide-react';
import { useQuery, post, patch, del, invalidate, requestId } from '../api';
import { useApp } from '../app-context';
import { useT } from '../i18n';
import { Empty, Sheet, Thumb, useToast } from '../components/ui';

const SCOPES = ['shared'];
type Who = { id: string; name: string; me: boolean } | null;

/** A small round initial, coloured per person, so you can tell at a glance who has what. */
function Face({ who }: { who: { id: string; name: string } }) {
  let h = 0;
  for (const c of who.id) h = (h * 31 + c.charCodeAt(0)) % 360;
  return <span className="face" style={{ ['--hue' as any]: h }} aria-hidden>{who.name.trim().charAt(0).toUpperCase() || '?'}</span>;
}

/** The messages people need, in their language; the server's own message otherwise. */
function errorText(e: any, nl: boolean) {
  const m: Record<string, [string, string]> = {
    not_found: ['This list isn’t there any more, or you’re no longer on it.', 'Deze lijst is er niet meer, of je staat er niet meer op.'],
    not_friends: ['You can only invite friends.', 'Je kunt alleen vrienden uitnodigen.'],
    owner_only: ['Only the person who made this list can do that.', 'Alleen wie de lijst maakte kan dat.'],
    not_your_claim: ['Someone else is getting this.', 'Iemand anders haalt dit.'],
    already_bought: ['This was already bought.', 'Dit is al gekocht.'],
    list_full: ['This list is full.', 'Deze lijst zit vol.'],
  };
  return m[e?.code]?.[nl ? 1 : 0] ?? e?.message ?? (nl ? 'Dat lukte niet' : 'That didn’t work');
}

function useAct() {
  const toast = useToast();
  const nl = useApp().lang === 'nl';
  const [busy, setBusy] = useState(false);
  const act = async <T,>(fn: () => Promise<T>, ok?: (r: T) => string | void) => {
    setBusy(true);
    try {
      const r = await fn();
      await invalidate(SCOPES);
      const m = ok?.(r);
      if (m) toast({ text: m });
      return r;
    } catch (e: any) {
      toast({ text: errorText(e, nl), error: true });
    } finally {
      setBusy(false);
    }
  };
  return { act, busy, nl };
}

export function SharedListsPage({ id }: { id?: string }) {
  return id ? <SharedList id={id} /> : <Overview />;
}

/** Friends to pick from (for a new list or more invites). */
function FriendPicker({ picked, onChange, exclude = [] }: { picked: string[]; onChange: (ids: string[]) => void; exclude?: string[] }) {
  const nl = useApp().lang === 'nl';
  const { data } = useQuery<any>('/api/friends', ['friends']);
  const friends = (data?.friends ?? []).filter((f: any) => !exclude.includes(f.id));
  if (data && !friends.length) {
    return <p className="small muted" style={{ margin: 0 }}>{(data.friends ?? []).length ? (nl ? 'Al je vrienden staan al op deze lijst.' : 'All your friends are on this list already.') : <>{nl ? 'Je hebt nog geen vrienden op PantryPip. ' : 'You don’t have friends on PantryPip yet. '}<a href="#/friends">{nl ? 'Vrienden toevoegen' : 'Add friends'}</a></>}</p>;
  }
  return (
    <div className="row wrap" style={{ gap: 8 }} role="group" aria-label={nl ? 'Vrienden' : 'Friends'}>
      {friends.map((f: any) => {
        const on = picked.includes(f.id);
        return <button key={f.id} type="button" className="chip" aria-pressed={on} onClick={() => onChange(on ? picked.filter((x) => x !== f.id) : [...picked, f.id])}><Face who={f} /> {f.name}</button>;
      })}
    </div>
  );
}

function Overview() {
  const t = useT();
  const { act, busy, nl } = useAct();
  const { data } = useQuery<any>('/api/shared-lists', SCOPES);
  const [name, setName] = useState('');
  const [picked, setPicked] = useState<string[]>([]);
  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    const r = await act(() => post<{ id: string }>('/api/shared-lists', { name: name.trim(), friends: picked }));
    if (r) {
      setName('');
      setPicked([]);
      location.hash = `#/shared/${r.id}`;
    }
  };
  return (
    <>
      <div className="topbar">
        <a className="icon-btn" href="#/shopping" aria-label={t('Back')}><ArrowLeft /></a>
        <div className="grow"><h1>{nl ? 'Gedeelde lijsten' : 'Shared lists'}</h1><div className="sub">{nl ? 'Samen boodschappen doen met vrienden' : 'Shop together with friends'}</div></div>
      </div>

      {!!data?.invites.length && (
        <>
          <div className="section-head"><h2>{nl ? 'Uitnodigingen' : 'Invites'}</h2></div>
          <div className="list">
            {data.invites.map((i: any) => (
              <div key={i.id} className="item shared-invite">
                <div className="grow" style={{ minWidth: 0 }}><div className="title ellipsis">{i.name}</div><div className="meta">{nl ? `${i.by} nodigt je uit` : `${i.by} invited you`}</div></div>
                <button className="btn sm ghost" disabled={busy} onClick={() => act(() => post(`/api/shared-lists/${i.id}/answer`, { join: false }))}>{nl ? 'Nee, bedankt' : 'No thanks'}</button>
                <button className="btn sm primary" disabled={busy} onClick={() => act(() => post(`/api/shared-lists/${i.id}/answer`, { join: true }), () => void (location.hash = `#/shared/${i.id}`))}><Check size={15} /> {nl ? 'Meedoen' : 'Join'}</button>
              </div>
            ))}
          </div>
        </>
      )}

      {data && !data.lists.length && !data.invites.length && (
        <Empty art="🧺" title={nl ? 'Nog geen gedeelde lijsten' : 'No shared lists yet'}>
          <p className="small">{nl ? 'Maak een lijst voor een gezamenlijke boodschappenronde: iedereen ziet live wat er nog moet en wie wat haalt.' : 'Make a list for a shop you do together: everyone sees live what’s left and who’s getting what.'}</p>
        </Empty>
      )}

      {!!data?.lists.length && (
        <div className="list" style={{ marginTop: 12 }}>
          {data.lists.map((l: any) => (
            <a key={l.id} className="item shared-row" href={`#/shared/${l.id}`}>
              <div className="faces">{l.members.slice(0, 4).map((m: any) => <Face key={m.id} who={m} />)}</div>
              <div className="grow" style={{ minWidth: 0 }}>
                <div className="title ellipsis">{l.name}</div>
                <div className="meta ellipsis">{l.members.map((m: any) => m.name).join(', ')}</div>
              </div>
              <span className="num muted small">{l.open}{l.cart ? ` · 🛒 ${l.cart}` : ''}</span>
            </a>
          ))}
        </div>
      )}

      <div className="section-head"><h2>{nl ? 'Nieuwe gedeelde lijst' : 'New shared list'}</h2></div>
      <form className="card stack" style={{ padding: 14 }} onSubmit={create}>
        <input className="input" value={name} maxLength={60} onChange={(e) => setName(e.target.value)} placeholder={nl ? 'Naam, bijv. “Weekend BBQ”' : 'Name, e.g. “Weekend BBQ”'} aria-label={nl ? 'Naam van de lijst' : 'List name'} />
        <div className="field">{nl ? 'Wie doet er mee?' : 'Who’s in?'}</div>
        <FriendPicker picked={picked} onChange={setPicked} />
        <button className="btn primary" disabled={busy || !name.trim()}><Plus size={16} /> {nl ? 'Lijst maken' : 'Make the list'}</button>
      </form>
    </>
  );
}

function SharedList({ id }: { id: string }) {
  const t = useT();
  const app = useApp();
  const { act, busy, nl } = useAct();
  const toast = useToast();
  const { data, error } = useQuery<any>(`/api/shared-lists/${id}`, SCOPES);
  const [name, setName] = useState('');
  const [people, setPeople] = useState(false);
  const [mode, setMode] = useState(false);
  const base = `/api/shared-lists/${id}`;

  if (error) {
    return (
      <>
        <div className="topbar"><a className="icon-btn" href="#/shared" aria-label={t('Back')}><ArrowLeft /></a><div className="grow"><h1>{nl ? 'Gedeelde lijst' : 'Shared list'}</h1></div></div>
        <Empty art="🔒" title={nl ? 'Deze lijst kun je niet zien' : 'You can’t see this list'}><p className="small">{errorText(error, nl)}</p></Empty>
      </>
    );
  }
  if (!data) return <div className="skeleton" style={{ height: 200, marginTop: 24 }} />;

  const label = (i: any) => (nl && i.name_nl) || i.name;
  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    const v = name.trim();
    if (!v) return;
    setName('');
    await act(() => post(`${base}/items`, { name: v }));
  };
  const tick = (i: any, on: boolean) => act(() => patch(`${base}/items/${i.id}`, { checked: on }));
  const claim = (i: any, on: boolean) => act(() => patch(`${base}/items/${i.id}`, { claimed: on }));
  const myCart = data.inCart.filter((i: any) => i.checkedBy?.me);
  const total = data.count + data.inCart.length;
  const finish = async () => {
    const r = await act(() => post(`${base}/finish`, { clientRequestId: requestId() }));
    if (!r) return;
    invalidate(['inventory', 'home']);
    setMode(false);
    const n = (r as any).result?.added.length ?? 0;
    toast({ text: nl ? `${n} ${n === 1 ? 'product' : 'producten'} in jouw voorraad gezet` : `${n} ${n === 1 ? 'product' : 'products'} moved to your stock` });
  };
  const byWhom = (w: Who, verbEn: string, verbNl: string) => (w ? (w.me ? (nl ? `jij ${verbNl}` : `you ${verbEn}`) : `${w.name} ${nl ? verbNl : verbEn}`) : '');

  return (
    <>
      <div className="topbar">
        <a className="icon-btn" href="#/shared" aria-label={t('Back')}><ArrowLeft /></a>
        <div className="grow" style={{ minWidth: 0 }}>
          <h1 className="shared-title">{data.name}</h1>
          <button className="sub plain shared-people" onClick={() => setPeople(true)} aria-label={nl ? 'Wie doen er mee' : 'Who’s on this list'}>
            <span className="faces">{data.members.filter((m: any) => m.status === 'joined').slice(0, 5).map((m: any) => <Face key={m.id} who={m} />)}</span>
            {data.members.filter((m: any) => m.status === 'joined').length} {nl ? 'mensen' : 'people'}
          </button>
        </div>
        {total > 0 && <button className="btn primary sm" onClick={() => setMode(true)}><ShoppingCart size={16} /> {t('Shopping mode')}</button>}
      </div>

      <form className="row" onSubmit={add}>
        <input className="input" value={name} maxLength={120} onChange={(e) => setName(e.target.value)} placeholder={nl ? 'Toevoegen… (bijv. “houtskool”)' : 'Add… (e.g. “charcoal”)'} aria-label={t('Add item')} enterKeyHint="done" />
        <button className="icon-btn" style={{ width: 46, height: 46, background: 'var(--herb)', color: '#fff', border: 0 }} aria-label={t('Add item')} disabled={busy}><Plus /></button>
      </form>

      {!total && !data.bought.length && <Empty art="🧺" title={t('Your list is empty')}><p className="small">{nl ? 'Wat iemand toevoegt, zien de anderen meteen.' : 'What anyone adds, the others see straight away.'}</p></Empty>}

      {data.groups.map((g: any) => (
        <section key={g.category}>
          <div className="section-head"><h2>{g.label[app.lang]}</h2><span className="tiny muted">{g.items.length}</span></div>
          <div className="list">
            {g.items.map((i: any) => (
              <div key={i.id} className="shop-item">
                <button className="check" onClick={() => tick(i, true)} aria-label={`${label(i)}: ${t('In cart')}`} aria-pressed={false}><Check /></button>
                <Thumb product={i.productId ? { id: i.productId, category: i.category } : { category: i.category }} />
                <div className="grow" style={{ minWidth: 0 }}>
                  <div className="title ellipsis">{label(i)}</div>
                  <div className="why-tag ellipsis">{[i.label, i.note, i.addedBy && byWhom(i.addedBy, 'added it', 'zette het erop')].filter(Boolean).join(' · ')}</div>
                </div>
                {/* Who's getting it: claim it, drop your claim, or see whose it is. */}
                {i.claimedBy && !i.claimedBy.me
                  ? <span className="pill plum claim"><Face who={i.claimedBy} /> {nl ? `${i.claimedBy.name} haalt het` : `${i.claimedBy.name}’s`}</span>
                  : <button className={`chip claim ${i.claimedBy?.me ? 'on' : ''}`} aria-pressed={!!i.claimedBy?.me} onClick={() => claim(i, !i.claimedBy?.me)} disabled={busy}><Hand size={14} /> {i.claimedBy?.me ? (nl ? 'Ik haal het' : 'I’m on it') : (nl ? 'Ik haal' : 'I’ll get')}</button>}
                <button className="icon-btn ghost" style={{ width: 32, height: 32 }} aria-label={`${nl ? 'Weghalen' : 'Remove'} ${label(i)}`} onClick={() => act(() => del(`${base}/items/${i.id}`))}><X size={16} /></button>
              </div>
            ))}
          </div>
        </section>
      ))}

      {data.inCart.length > 0 && (
        <>
          <div className="section-head"><h2>{nl ? 'In de mandjes' : 'In the carts'} ({data.inCart.length})</h2>{myCart.length > 0 && <button className="btn primary sm" onClick={finish} disabled={busy}><Check size={15} /> {nl ? 'Klaar met winkelen' : 'Done shopping'}</button>}</div>
          <div className="list">
            {data.inCart.map((i: any) => (
              <div key={i.id} className="shop-item done">
                <button className="check on" onClick={() => tick(i, false)} aria-label={`${label(i)}: ${nl ? 'uit het mandje' : 'out of the cart'}`} aria-pressed><Check /></button>
                <div className="grow" style={{ minWidth: 0 }}><div className="title ellipsis">{label(i)}</div>{i.label && <div className="why-tag">{i.label}</div>}</div>
                <span className={`pill ${i.checkedBy.me ? 'herb' : 'grey'} claim`}><Face who={i.checkedBy} /> {i.checkedBy.me ? (nl ? 'jij' : 'you') : i.checkedBy.name}</span>
              </div>
            ))}
          </div>
          <p className="tiny muted">{nl ? '“Klaar met winkelen” zet alleen wat jij hebt afgevinkt in jouw voorraad. Wat anderen afvinken, gaat naar hun eigen voorraad.' : '“Done shopping” moves only what you ticked into your own stock. What others tick goes to theirs.'}</p>
        </>
      )}

      {data.bought.length > 0 && (
        <>
          <div className="section-head"><h2>{nl ? 'Gekocht' : 'Bought'} ({data.bought.length})</h2><button className="link" onClick={() => act(() => post(`${base}/clear-bought`, {}))} disabled={busy}>{nl ? 'Wissen' : 'Clear'}</button></div>
          <div className="list">
            {data.bought.slice(0, 30).map((i: any) => (
              <div key={i.id} className="shop-item done">
                <div className="grow title ellipsis">{label(i)}</div>
                <span className="small muted">{byWhom(i.boughtBy, 'bought it', 'kocht het')}</span>
              </div>
            ))}
          </div>
        </>
      )}

      {people && <PeopleSheet data={data} onClose={() => setPeople(false)} />}

      {mode && (
        <div className="shopmode" role="dialog" aria-label={t('Shopping mode')}>
          <header>
            <button className="icon-btn" onClick={() => setMode(false)} aria-label={t('Close')}><X /></button>
            <h2 className="ellipsis">{data.name}</h2>
            <span className="num muted">{data.inCart.length}/{total}</span>
          </header>
          <div style={{ padding: '0 16px' }}><div className="progress"><i style={{ width: `${total ? (data.inCart.length / total) * 100 : 0}%` }} /></div></div>
          <div className="content">
            {data.groups.map((g: any) => (
              <div key={g.category}>
                <div className="small muted" style={{ margin: '14px 4px 8px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.06em' }}>{g.label[app.lang]}</div>
                {g.items.map((i: any) => (
                  <button key={i.id} className="big" onClick={() => (navigator.vibrate?.(10), tick(i, true))}>
                    <span className="check"><Check /></span>
                    <span className="grow">{label(i)}{i.claimedBy && <span className="tiny muted" style={{ display: 'block' }}>{i.claimedBy.me ? (nl ? 'jij haalt het' : 'you’re getting it') : (nl ? `${i.claimedBy.name} haalt het` : `${i.claimedBy.name} is getting it`)}</span>}</span>
                    <span className="q">{i.label}</span>
                  </button>
                ))}
              </div>
            ))}
            {data.inCart.map((i: any) => (
              <button key={i.id} className="big done" onClick={() => tick(i, false)}>
                <span className="check on"><Check /></span>
                <span className="grow" style={{ textDecoration: 'line-through' }}>{label(i)}</span>
                <span className="q">{i.checkedBy.me ? (nl ? 'jij' : 'you') : i.checkedBy.name}</span>
              </button>
            ))}
          </div>
          <footer><button className="btn primary block lg" onClick={finish} disabled={!myCart.length || busy}><Check size={18} /> {nl ? 'Klaar met winkelen' : 'Done shopping'} ({myCart.length})</button></footer>
        </div>
      )}
    </>
  );
}

/** Who's on the list. The owner invites, renames, takes people off and deletes; others can leave. */
function PeopleSheet({ data, onClose }: { data: any; onClose: () => void }) {
  const { act, busy, nl } = useAct();
  const [picked, setPicked] = useState<string[]>([]);
  const [rename, setRename] = useState<string | null>(null);
  const base = `/api/shared-lists/${data.id}`;
  const me = data.members.find((m: any) => m.me);
  const leave = async () => {
    if (!confirm(nl ? `“${data.name}” verlaten?` : `Leave “${data.name}”?`)) return;
    if (await act(() => del(`${base}/members/${me.id}`))) location.hash = '#/shared';
  };
  const remove = async () => {
    if (!confirm(nl ? `“${data.name}” voor iedereen verwijderen? Gekochte spullen blijven in ieders voorraad.` : `Delete “${data.name}” for everyone? Bought things stay in everyone’s stock.`)) return;
    if (await act(() => del(base))) location.hash = '#/shared';
  };
  return (
    <Sheet title={nl ? 'Wie doen er mee' : 'Who’s on this list'} onClose={onClose}>
      <div className="stack">
        <div className="list">
          {data.members.map((m: any) => (
            <div key={m.id} className="item">
              <Face who={m} />
              <div className="grow" style={{ minWidth: 0 }}>
                <div className="title ellipsis">{m.me ? (nl ? `${m.name} (jij)` : `${m.name} (you)`) : m.name}</div>
                <div className="meta">{m.owner ? (nl ? 'Maakte de lijst' : 'Made the list') : m.status === 'invited' ? (nl ? 'Uitgenodigd' : 'Invited') : (nl ? 'Doet mee' : 'Joined')}</div>
              </div>
              {data.mine && !m.owner && <button className="icon-btn ghost" aria-label={nl ? `${m.name} van de lijst halen` : `Take ${m.name} off the list`} disabled={busy} onClick={() => act(() => del(`${base}/members/${m.id}`))}><X size={16} /></button>}
            </div>
          ))}
        </div>
        {data.mine && (
          <>
            <div className="field">{nl ? 'Meer vrienden uitnodigen' : 'Invite more friends'}</div>
            <FriendPicker picked={picked} onChange={setPicked} exclude={data.members.map((m: any) => m.id)} />
            {picked.length > 0 && <button className="btn primary" disabled={busy} onClick={async () => { if (await act(() => post(`${base}/invite`, { friends: picked }), (r: any) => (nl ? `${r.invited} uitgenodigd` : `Invited ${r.invited}`))) setPicked([]); }}><UserPlus size={16} /> {nl ? 'Uitnodigen' : 'Invite'} ({picked.length})</button>}
            {rename == null
              ? <button className="btn ghost" onClick={() => setRename(data.name)}><Pencil size={15} /> {nl ? 'Naam wijzigen' : 'Rename'}</button>
              : (
                <form className="row" onSubmit={async (e) => { e.preventDefault(); if (rename.trim() && (await act(() => patch(base, { name: rename.trim() })))) setRename(null); }}>
                  <input className="input" value={rename} maxLength={60} autoFocus onChange={(e) => setRename(e.target.value)} aria-label={nl ? 'Naam van de lijst' : 'List name'} />
                  <button className="btn primary" disabled={busy || !rename.trim()}>{nl ? 'Opslaan' : 'Save'}</button>
                </form>
              )}
            <button className="btn ghost danger" onClick={remove} disabled={busy}><Trash2 size={15} /> {nl ? 'Lijst verwijderen' : 'Delete the list'}</button>
          </>
        )}
        {!data.mine && <button className="btn ghost" onClick={leave} disabled={busy}><LogOut size={15} /> {nl ? 'Lijst verlaten' : 'Leave the list'}</button>}
        <p className="tiny muted" style={{ margin: 0 }}><Users size={12} /> {nl ? 'Alleen mensen op deze lijst zien hem. Ze zien de lijst, niet je voorraad of je eigen boodschappenlijst.' : 'Only people on this list can see it. They see the list, not your stock or your own shopping list.'}</p>
      </div>
    </Sheet>
  );
}

/** The way in, on the household shopping list: your shared lists, with waiting invites. */
export function SharedListsLink() {
  const nl = useApp().lang === 'nl';
  const { data } = useQuery<any>('/api/shared-lists', SCOPES);
  const n = data?.lists.length ?? 0;
  const invites = data?.invites.length ?? 0;
  return (
    <a className="stats-link shared-link" href="#/shared">
      <Users size={18} aria-hidden />
      <span className="grow">{nl ? 'Gedeelde lijsten' : 'Shared lists'}<span className="tiny muted" style={{ display: 'block', fontWeight: 400 }}>{n ? (nl ? `${n} ${n === 1 ? 'lijst' : 'lijsten'} met vrienden` : `${n} ${n === 1 ? 'list' : 'lists'} with friends`) : (nl ? 'Samen boodschappen doen met vrienden' : 'Shop together with friends')}</span></span>
      {invites > 0 && <span className="badge" aria-label={nl ? `${invites} uitnodigingen` : `${invites} invites`}>{invites}</span>}
    </a>
  );
}
