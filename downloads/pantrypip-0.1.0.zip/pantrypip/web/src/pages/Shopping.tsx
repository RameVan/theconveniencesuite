import { GroceryTabs } from '../components/GroceryTabs';
import { useEffect, useState } from 'react';
import { Plus, ShoppingCart, X, Check, Sparkles, Minus, Repeat2, AlertTriangle } from 'lucide-react';
import { del, get, patch, post, requestId, useQuery, invalidate } from '../api';
import { useApp, SCOPES_ALL } from '../app-context';
import { useT, fmtQty, type Lang } from '../i18n';
import { Empty, Sheet, Thumb, useToast } from '../components/ui';
import { ProductPicker } from '../components/ProductPicker';
import { ShopLinks } from '../components/ShopLinks';
import { SharedListsLink } from './SharedLists';

/** "Need 4 · have 2 · buy 1 × 6 · 4 left over" for an item the meal plan put on the list. */
function planLine(p: { need: number; have: number; toBuy: number; packs: number; packSize: number; leftover: number; unit: string }, lang: Lang) {
  const nl = lang === 'nl';
  const q = (x: number) => fmtQty(x, p.unit, lang);
  return [
    `${nl ? 'Nodig' : 'Need'} ${q(p.need)}`,
    p.have > 0 ? `${nl ? 'in huis' : 'have'} ${q(p.have)}` : null,
    `${nl ? 'koop' : 'buy'} ${p.packs} × ${q(p.packSize)}`,
    p.leftover > 0 ? `${q(p.leftover)} ${nl ? 'over' : 'left over'}` : null,
  ].filter(Boolean).join(' · ');
}

const REASON: Record<string, [string, string]> = {
  meal_plan: ['Meal plan', 'Planner'], suggestion: ['Suggested', 'Voorstel'], manual: ['', ''], low_stock: ['Running low', 'Bijna op'], predicted: ['Predicted', 'Voorspeld'],
};

export function ShoppingPage() {
  const app = useApp();
  const t = useT();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const { data } = useQuery<any>('/api/shopping', ['shopping']);
  const sug = useQuery<any[]>('/api/shopping/suggestions', ['shopping', 'inventory']);
  const [name, setName] = useState('');
  const [mode, setMode] = useState(false);
  const [shopFor, setShopFor] = useState<string | null>(null);
  const [forRecipe, setForRecipe] = useState<any | null>(null);
  const fromPlan = (i: any) => i.reason === 'meal_plan' || !!i.plan;

  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    const v = name.trim();
    if (!v) return;
    setName('');
    // Natural phrases like "2 pakken melk" go through the assistant parser; plain names are added directly.
    if (/\d|\b(een|two|twee|drie|three|pak|pakken|liter|kg|gram)\b/i.test(v)) await post('/api/assistant', { text: v, context: 'shopping', lang: app.lang });
    else await post('/api/shopping', { name: v });
    invalidate(['shopping', 'home']);
  };
  const toggle = async (i: any) => {
    await patch(`/api/shopping/${i.id}`, { checked: !i.checked });
    invalidate(['shopping']);
  };
  const finish = async () => {
    const r = await post('/api/shopping/complete', { clientRequestId: requestId() });
    invalidate(SCOPES_ALL);
    setMode(false);
    toast({
      text: nl ? `${r.result.added.length} producten in je voorraad gezet` : `${r.result.added.length} products moved to your inventory`,
      undo: () => post('/api/inventory/undo', { batchId: r.batchId }).then(() => invalidate(SCOPES_ALL)),
    });
  };
  const items: any[] = (data?.groups ?? []).flatMap((g: any) => g.items);
  const checked: any[] = data?.checked ?? [];
  const total = items.length + checked.length;

  return (
    <>
      <div className="topbar">
        <div className="grow"><h1>{nl ? 'Boodschappen' : 'Groceries'}</h1></div>
        {total > 0 && <button className="btn primary sm" onClick={() => setMode(true)}><ShoppingCart size={16} /> {t('Shopping mode')}</button>}
      </div>
      <GroceryTabs current="list" />
      <SharedListsLink />
      <form className="row" onSubmit={add}>
        <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder={nl ? 'Toevoegen… (bijv. “2 pakken melk”)' : 'Add… (e.g. “2 cartons of milk”)'} aria-label={t('Add item')} enterKeyHint="done" />
        <button className="icon-btn" style={{ width: 46, height: 46, background: 'var(--herb)', color: '#fff', border: 0 }} aria-label={t('Add item')}><Plus /></button>
      </form>

      {!!sug.data?.length && (
        <>
          <div className="section-head"><h2><Sparkles size={16} color="var(--plum)" /> {t('Suggestions')}</h2><span className="tiny muted">{nl ? 'op basis van je gewoontes' : 'from your habits'}</span></div>
          <div className="list">
            {sug.data.slice(0, 6).map((s: any) => (
              <div key={s.productId} className="item" style={{ minHeight: 54 }}>
                <Thumb product={{ id: s.productId }} />
                <div className="grow"><div className="title">{s.name}</div><div className="meta">{s.detail}</div></div>
                <button className="icon-btn" aria-label={nl ? 'Niet nodig' : 'Not needed'} onClick={async () => { await post(`/api/shopping/suggestions/${s.productId}/reject`, {}); invalidate(['shopping']); }}><X size={16} /></button>
                <button className="icon-btn" style={{ background: 'var(--herb-soft)', color: 'var(--herb)', borderColor: 'transparent' }} aria-label={`${t('Add')} ${s.name}`} onClick={async () => { await post(`/api/shopping/suggestions/${s.productId}/accept`, { packages: s.packages }); invalidate(['shopping', 'home']); }}><Plus size={16} /></button>
              </div>
            ))}
          </div>
        </>
      )}

      {data && !total && <Empty art="🧺" title={t('Your list is empty')}><p className="small">{nl ? 'Plan maaltijden of zeg “zet koffie op de lijst”.' : 'Plan some meals, or say “add coffee to the list”.'}</p></Empty>}

      {data?.groups.map((g: any) => (
        <section key={g.category}>
          <div className="section-head"><h2>{g.label[app.lang]}</h2><span className="tiny muted">{g.items.length}</span></div>
          <div className="list">
            {g.items.map((i: any) => (
              <div key={i.id} className="shop-item">
                <button className={`check ${i.checked ? 'on' : ''}`} onClick={() => toggle(i)} aria-label={`${i.name}: ${t('In cart')}`} aria-pressed={!!i.checked}><Check /></button>
                <Thumb product={i.product ?? { category: i.category }} />
                <div className="grow" style={{ minWidth: 0 }}>
                  {/* Tap the name to search it in a webshop. */}
                  <button className="title ellipsis plain" style={{ display: 'block', maxWidth: '100%', textAlign: 'left' }} aria-expanded={shopFor === i.id} onClick={() => setShopFor(shopFor === i.id ? null : i.id)}>{(nl && i.product?.name_nl) || i.name}</button>
                  <div className="why-tag ellipsis">{[i.label, REASON[i.reason]?.[nl ? 1 : 0], i.note].filter(Boolean).join(' · ')}</div>
                  {/* Planned meals: need, in stock, buy, left over (packs as they're sold). */}
                  {i.plan && <span className="plan-line">{planLine(i.plan, app.lang)}</span>}
                </div>
                {i.product && (
                  <div className="row" style={{ gap: 4 }}>
                    {fromPlan(i) && <button className="icon-btn ghost" style={{ width: 32, height: 32 }} aria-label={nl ? `${i.name} vervangen` : `Swap ${i.name}`} onClick={() => setForRecipe(i)}><Repeat2 size={15} /></button>}
                    <button className="icon-btn ghost" style={{ width: 32, height: 32 }} aria-label="less" onClick={async () => {
                      // Taking off something a planned meal needs: say which meal first, and offer a swap.
                      if ((i.packages ?? 1) <= 1 && fromPlan(i)) return setForRecipe(i);
                      if ((i.packages ?? 1) <= 1) await del(`/api/shopping/${i.id}`); else await patch(`/api/shopping/${i.id}`, { packages: (i.packages ?? 1) - 1 }); invalidate(['shopping']);
                    }}><Minus size={15} /></button>
                    <b className="num" style={{ minWidth: 16, textAlign: 'center' }}>{i.packages ?? 1}</b>
                    <button className="icon-btn ghost" style={{ width: 32, height: 32 }} aria-label="more" onClick={async () => { await patch(`/api/shopping/${i.id}`, { packages: (i.packages ?? 1) + 1 }); invalidate(['shopping']); }}><Plus size={15} /></button>
                  </div>
                )}
                {!i.product && <button className="icon-btn ghost" aria-label="remove" onClick={async () => { await del(`/api/shopping/${i.id}`); invalidate(['shopping']); }}><X size={16} /></button>}
                {shopFor === i.id && <ShopLinks shops={data?.shops} term={i.product?.name_nl || i.name} nl={nl} />}
              </div>
            ))}
          </div>
        </section>
      ))}

      {checked.length > 0 && (
        <>
          <div className="section-head"><h2>{t('In cart')} ({checked.length})</h2><button className="btn primary sm" onClick={finish}><Check size={15} /> {t('Finish shopping')}</button></div>
          <div className="list">
            {checked.map((i: any) => (
              <div key={i.id} className="shop-item done">
                <button className="check on" onClick={() => toggle(i)} aria-label={i.name}><Check /></button>
                <div className="grow title">{(nl && i.product?.name_nl) || i.name}</div>
                <span className="muted small">{i.label}</span>
              </div>
            ))}
          </div>
          <p className="tiny muted">{nl ? '“Klaar met winkelen” zet afgevinkte producten in je voorraad (gebeurt na 6 uur ook vanzelf). Scan je bon daarna: hoeveelheden worden dan bijgewerkt, niet dubbel geteld.' : '“Finish shopping” moves ticked items into your inventory (it also happens automatically after 6 hours). Scan the receipt afterwards: quantities get corrected, never counted twice.'}</p>
        </>
      )}

      {forRecipe && <RecipeItemSheet item={forRecipe} onClose={() => setForRecipe(null)} />}

      {mode && (
        <div className="shopmode" role="dialog" aria-label={t('Shopping mode')}>
          <header>
            <button className="icon-btn" onClick={() => setMode(false)} aria-label={t('Close')}><X /></button>
            <h2>{t('Shopping mode')}</h2>
            <span className="num muted">{checked.length}/{total}</span>
          </header>
          <div style={{ padding: '0 16px' }}><div className="progress"><i style={{ width: `${total ? (checked.length / total) * 100 : 0}%` }} /></div></div>
          <div className="content">
            {data?.groups.map((g: any) => (
              <div key={g.category}>
                <div className="small muted" style={{ margin: '14px 4px 8px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.06em' }}>{g.label[app.lang]}</div>
                {g.items.map((i: any) => (
                  <button key={i.id} className="big" onClick={() => (navigator.vibrate?.(10), toggle(i))}>
                    <span className="check"><Check /></span>
                    <span className="grow">{(nl && i.product?.name_nl) || i.name}</span>
                    <span className="q">{i.label}</span>
                  </button>
                ))}
              </div>
            ))}
            {checked.map((i: any) => (
              <button key={i.id} className="big done" onClick={() => toggle(i)}>
                <span className="check on"><Check /></span>
                <span className="grow" style={{ textDecoration: 'line-through' }}>{(nl && i.product?.name_nl) || i.name}</span>
              </button>
            ))}
          </div>
          <footer><button className="btn primary block lg" onClick={finish} disabled={!checked.length}><Check size={18} /> {t('Finish shopping')} ({checked.length})</button></footer>
        </div>
      )}
    </>
  );
}

/**
 * A list item that planned meals need: which meals (with their day), then swap it for another product in
 * those meals (the list and the recipes follow), leave it out of them, or keep it.
 */
function RecipeItemSheet({ item, onClose }: { item: any; onClose: () => void }) {
  const app = useApp();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const [uses, setUses] = useState<any[] | null>(null);
  const [busy, setBusy] = useState(false);
  const name = (nl && item.product?.name_nl) || item.name;
  useEffect(() => {
    get<any[]>(`/api/shopping/${item.id}/uses`).then(setUses).catch(() => setUses([]));
  }, [item.id]);
  const day = (d: string) => new Date(d + 'T12:00:00Z').toLocaleDateString(nl ? 'nl-NL' : 'en-GB', { timeZone: 'UTC', weekday: 'short', day: 'numeric', month: 'short' });
  const meals = [...new Map((uses ?? []).map((u) => [u.slotId, u])).values()];
  const apply = async (body: any, done: string) => {
    setBusy(true);
    try {
      await post(`/api/shopping/${item.id}/replace`, body);
      invalidate(['shopping', 'planner', 'home']);
      toast({ text: done });
      onClose();
    } catch (e: any) {
      toast({ text: e.message, error: true });
      setBusy(false);
    }
  };
  const removeAnyway = async () => {
    await del(`/api/shopping/${item.id}`);
    invalidate(['shopping']);
    onClose();
  };
  return (
    <Sheet title={nl ? `${name} is nodig voor een recept` : `${name} is needed for a recipe`} onClose={onClose}>
      <div className="stack">
        {uses == null ? <div className="skeleton" style={{ height: 60 }} /> : meals.length ? (
          <div className="recipe-need">
            <AlertTriangle size={18} aria-hidden />
            <div>
              <b>{nl ? 'Nodig voor' : 'Needed for'}</b>
              <ul>{meals.map((u) => <li key={u.slotId}>{u.title} <span className="muted">· {day(u.date)}</span></li>)}</ul>
              <span className="small muted">{nl ? 'Weghalen werkt niet zolang deze maaltijden het nodig hebben: wissel het, of laat het weg uit de maaltijd.' : 'Removing it won’t stick while these meals need it: swap it, or leave it out of the meal.'}</span>
            </div>
          </div>
        ) : <p className="small muted" style={{ margin: 0 }}>{nl ? 'Geen geplande maaltijd heeft dit nog nodig.' : 'No planned meal needs this any more.'}</p>}
        {meals.length > 0 && (
          <>
            <div className="field">{nl ? `Wisselen voor iets anders in ${meals.length === 1 ? 'deze maaltijd' : `deze ${meals.length} maaltijden`}` : `Swap for something else in ${meals.length === 1 ? 'this meal' : `these ${meals.length} meals`}`}</div>
            <ProductPicker autoFocus like={item.product} exclude={[item.product_id ?? item.product?.id]} onPick={(p) => !busy && apply({ productId: p.id }, nl ? `${name} gewisseld voor ${p.name}. Recept en lijst aangepast.` : `Swapped ${name} for ${p.name}. Recipe and list updated.`)} />
            <div className="row wrap">
              <button className="btn" disabled={busy} onClick={() => apply({ omit: true }, nl ? `${name} weggelaten uit ${meals.length === 1 ? 'de maaltijd' : 'de maaltijden'}` : `Left ${name} out of ${meals.length === 1 ? 'the meal' : 'the meals'}`)}>{nl ? 'Weglaten uit de maaltijd' : 'Leave it out of the meal'}</button>
              <button className="btn ghost" onClick={onClose}>{nl ? 'Laten staan' : 'Keep it'}</button>
            </div>
          </>
        )}
        {uses != null && !meals.length && <button className="btn" onClick={removeAnyway}>{nl ? 'Van de lijst halen' : 'Remove from the list'}</button>}
      </div>
    </Sheet>
  );
}
