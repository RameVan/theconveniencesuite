import { GroceryTabs } from '../components/GroceryTabs';
import { useState } from 'react';
import { Plus, ShoppingCart, X, Check, Sparkles, Minus } from 'lucide-react';
import { del, patch, post, requestId, useQuery, invalidate } from '../api';
import { useApp, SCOPES_ALL } from '../app-context';
import { useT, fmtQty, type Lang } from '../i18n';
import { Empty, Thumb, useToast } from '../components/ui';
import { ShopLinks } from '../components/ShopLinks';

/** "Need 4 · have 2 · buy 1 × 6 · 4 left over" for an item the meal plan put on the list. */
function planLine(p: { need: number; have: number; toBuy: number; packs: number; packSize: number; leftover: number; unit: string }, lang: Lang) {
  const nl = lang === 'nl';
  const q = (x: number) => fmtQty(x, p.unit, lang);
  return [
    `${nl ? 'Nodig' : 'Need'} ${q(p.need)}`,
    p.have > 0 ? `${nl ? 'in huis' : 'have'} ${q(p.have)}` : null,
    `${nl ? 'koop' : 'buy'} ${p.packs} × ${q(p.packSize)}`,
    p.leftover > 0 ? `${q(p.leftover)} ${nl ? 'over' : 'left over'}` : null,
  ].filter(Boolean).join(' · ');
}

const REASON: Record<string, [string, string]> = {
  meal_plan: ['Meal plan', 'Planner'], suggestion: ['Suggested', 'Voorstel'], manual: ['', ''], low_stock: ['Running low', 'Bijna op'], predicted: ['Predicted', 'Voorspeld'],
};

export function ShoppingPage() {
  const app = useApp();
  const t = useT();
  const toast = useToast();
  const nl = app.lang === 'nl';
  const { data } = useQuery<any>('/api/shopping', ['shopping']);
  const sug = useQuery<any[]>('/api/shopping/suggestions', ['shopping', 'inventory']);
  const [name, setName] = useState('');
  const [mode, setMode] = useState(false);
  const [shopFor, setShopFor] = useState<string | null>(null);

  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    const v = name.trim();
    if (!v) return;
    setName('');
    // Natural phrases like "2 pakken melk" go through the assistant parser; plain names are added directly.
    if (/\d|\b(een|two|twee|drie|three|pak|pakken|liter|kg|gram)\b/i.test(v)) await post('/api/assistant', { text: v, context: 'shopping', lang: app.lang });
    else await post('/api/shopping', { name: v });
    invalidate(['shopping', 'home']);
  };
  const toggle = async (i: any) => {
    await patch(`/api/shopping/${i.id}`, { checked: !i.checked });
    invalidate(['shopping']);
  };
  const finish = async () => {
    const r = await post('/api/shopping/complete', { clientRequestId: requestId() });
    invalidate(SCOPES_ALL);
    setMode(false);
    toast({
      text: nl ? `${r.result.added.length} producten in je voorraad gezet` : `${r.result.added.length} products moved to your inventory`,
      undo: () => post('/api/inventory/undo', { batchId: r.batchId }).then(() => invalidate(SCOPES_ALL)),
    });
  };
  const items: any[] = (data?.groups ?? []).flatMap((g: any) => g.items);
  const checked: any[] = data?.checked ?? [];
  const total = items.length + checked.length;

  return (
    <>
      <div className="topbar">
        <div className="grow"><h1>{nl ? 'Boodschappen' : 'Groceries'}</h1></div>
        {total > 0 && <button className="btn primary sm" onClick={() => setMode(true)}><ShoppingCart size={16} /> {t('Shopping mode')}</button>}
      </div>
      <GroceryTabs current="list" />
      <form className="row" onSubmit={add}>
        <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder={nl ? 'Toevoegen… (bijv. “2 pakken melk”)' : 'Add… (e.g. “2 cartons of milk”)'} aria-label={t('Add item')} enterKeyHint="done" />
        <button className="icon-btn" style={{ width: 46, height: 46, background: 'var(--herb)', color: '#fff', border: 0 }} aria-label={t('Add item')}><Plus /></button>
      </form>

      {!!sug.data?.length && (
        <>
          <div className="section-head"><h2><Sparkles size={16} color="var(--plum)" /> {t('Suggestions')}</h2><span className="tiny muted">{nl ? 'op basis van je gewoontes' : 'from your habits'}</span></div>
          <div className="list">
            {sug.data.slice(0, 6).map((s: any) => (
              <div key={s.productId} className="item" style={{ minHeight: 54 }}>
                <Thumb product={{ id: s.productId }} />
                <div className="grow"><div className="title">{s.name}</div><div className="meta">{s.detail}</div></div>
                <button className="icon-btn" aria-label={nl ? 'Niet nodig' : 'Not needed'} onClick={async () => { await post(`/api/shopping/suggestions/${s.productId}/reject`, {}); invalidate(['shopping']); }}><X size={16} /></button>
                <button className="icon-btn" style={{ background: 'var(--herb-soft)', color: 'var(--herb)', borderColor: 'transparent' }} aria-label={`${t('Add')} ${s.name}`} onClick={async () => { await post(`/api/shopping/suggestions/${s.productId}/accept`, { packages: s.packages }); invalidate(['shopping', 'home']); }}><Plus size={16} /></button>
              </div>
            ))}
          </div>
        </>
      )}

      {data && !total && <Empty art="🧺" title={t('Your list is empty')}><p className="small">{nl ? 'Plan maaltijden of zeg “zet koffie op de lijst”.' : 'Plan some meals, or say “add coffee to the list”.'}</p></Empty>}

      {data?.groups.map((g: any) => (
        <section key={g.category}>
          <div className="section-head"><h2>{g.label[app.lang]}</h2><span className="tiny muted">{g.items.length}</span></div>
          <div className="list">
            {g.items.map((i: any) => (
              <div key={i.id} className="shop-item">
                <button className={`check ${i.checked ? 'on' : ''}`} onClick={() => toggle(i)} aria-label={`${i.name}: ${t('In cart')}`} aria-pressed={!!i.checked}><Check /></button>
                <Thumb product={i.product ?? { category: i.category }} />
                <div className="grow" style={{ minWidth: 0 }}>
                  {/* Tap the name to search it in a webshop. */}
                  <button className="title ellipsis plain" style={{ display: 'block', maxWidth: '100%', textAlign: 'left' }} aria-expanded={shopFor === i.id} onClick={() => setShopFor(shopFor === i.id ? null : i.id)}>{(nl && i.product?.name_nl) || i.name}</button>
                  <div className="why-tag ellipsis">{[i.label, REASON[i.reason]?.[nl ? 1 : 0], i.note].filter(Boolean).join(' · ')}</div>
                  {/* Planned meals: need, in stock, buy, left over (packs as they're sold). */}
                  {i.plan && <span className="plan-line">{planLine(i.plan, app.lang)}</span>}
                </div>
                {i.product && (
                  <div className="row" style={{ gap: 4 }}>
                    <button className="icon-btn ghost" style={{ width: 32, height: 32 }} aria-label="less" onClick={async () => { if ((i.packages ?? 1) <= 1) await del(`/api/shopping/${i.id}`); else await patch(`/api/shopping/${i.id}`, { packages: (i.packages ?? 1) - 1 }); invalidate(['shopping']); }}><Minus size={15} /></button>
                    <b className="num" style={{ minWidth: 16, textAlign: 'center' }}>{i.packages ?? 1}</b>
                    <button className="icon-btn ghost" style={{ width: 32, height: 32 }} aria-label="more" onClick={async () => { await patch(`/api/shopping/${i.id}`, { packages: (i.packages ?? 1) + 1 }); invalidate(['shopping']); }}><Plus size={15} /></button>
                  </div>
                )}
                {!i.product && <button className="icon-btn ghost" aria-label="remove" onClick={async () => { await del(`/api/shopping/${i.id}`); invalidate(['shopping']); }}><X size={16} /></button>}
                {shopFor === i.id && <ShopLinks shops={data?.shops} term={i.product?.name_nl || i.name} nl={nl} />}
              </div>
            ))}
          </div>
        </section>
      ))}

      {checked.length > 0 && (
        <>
          <div className="section-head"><h2>{t('In cart')} ({checked.length})</h2><button className="btn primary sm" onClick={finish}><Check size={15} /> {t('Finish shopping')}</button></div>
          <div className="list">
            {checked.map((i: any) => (
              <div key={i.id} className="shop-item done">
                <button className="check on" onClick={() => toggle(i)} aria-label={i.name}><Check /></button>
                <div className="grow title">{(nl && i.product?.name_nl) || i.name}</div>
                <span className="muted small">{i.label}</span>
              </div>
            ))}
          </div>
          <p className="tiny muted">{nl ? '“Klaar met winkelen” zet afgevinkte producten in je voorraad (gebeurt na 6 uur ook vanzelf). Scan je bon daarna: hoeveelheden worden dan bijgewerkt, niet dubbel geteld.' : '“Finish shopping” moves ticked items into your inventory (it also happens automatically after 6 hours). Scan the receipt afterwards: quantities get corrected, never counted twice.'}</p>
        </>
      )}

      {mode && (
        <div className="shopmode" role="dialog" aria-label={t('Shopping mode')}>
          <header>
            <button className="icon-btn" onClick={() => setMode(false)} aria-label={t('Close')}><X /></button>
            <h2>{t('Shopping mode')}</h2>
            <span className="num muted">{checked.length}/{total}</span>
          </header>
          <div style={{ padding: '0 16px' }}><div className="progress"><i style={{ width: `${total ? (checked.length / total) * 100 : 0}%` }} /></div></div>
          <div className="content">
            {data?.groups.map((g: any) => (
              <div key={g.category}>
                <div className="small muted" style={{ margin: '14px 4px 8px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.06em' }}>{g.label[app.lang]}</div>
                {g.items.map((i: any) => (
                  <button key={i.id} className="big" onClick={() => (navigator.vibrate?.(10), toggle(i))}>
                    <span className="check"><Check /></span>
                    <span className="grow">{(nl && i.product?.name_nl) || i.name}</span>
                    <span className="q">{i.label}</span>
                  </button>
                ))}
              </div>
            ))}
            {checked.map((i: any) => (
              <button key={i.id} className="big done" onClick={() => toggle(i)}>
                <span className="check on"><Check /></span>
                <span className="grow" style={{ textDecoration: 'line-through' }}>{(nl && i.product?.name_nl) || i.name}</span>
              </button>
            ))}
          </div>
          <footer><button className="btn primary block lg" onClick={finish} disabled={!checked.length}><Check size={18} /> {t('Finish shopping')} ({checked.length})</button></footer>
        </div>
      )}
    </>
  );
}
