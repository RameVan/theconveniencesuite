// Platform checks for iPhone/iPad behaviour (Safari, home-screen apps).
const ua = typeof navigator !== 'undefined' ? navigator.userAgent : '';

/** iPhone, iPad or iPod (iPadOS reports itself as a Mac with touch). */
export const isIOS = /iPhone|iPad|iPod/.test(ua) || (/Macintosh/.test(ua) && typeof navigator !== 'undefined' && navigator.maxTouchPoints > 1);

/** Running as an installed home-screen app rather than in a browser tab. */
export const isStandalone =
  typeof window !== 'undefined' && (window.matchMedia?.('(display-mode: standalone)').matches || (navigator as any).standalone === true);

/** Camera, microphone, service worker and push all need HTTPS (or localhost). */
export const isSecure = typeof window !== 'undefined' && window.isSecureContext;

/** On iPhone, notifications only work for apps added to the home screen (iOS 16.4+). */
export const canPushHere = typeof window !== 'undefined' && 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window && isSecure;
