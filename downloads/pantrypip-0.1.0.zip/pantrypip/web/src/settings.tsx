// The app's one copy of your settings (household + personal), backed by /api/settings.
// - Loaded before any screen renders (a cached copy paints instantly, the server copy confirms it).
// - A change shows at once (optimistic), is batched for a moment, then saved in one request; only
//   one request is in flight, and changes made meanwhile go in the next one, so nothing is lost.
// - Rejected by the server: the change is rolled back and you're told why. Network trouble: the
//   change stays, is kept across a reload, and is retried until it lands.
// - Fresh server copies (another device, another screen) apply whenever they're newer and never
//   undo a change that hasn't been saved yet.
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { ApiError, api, invalidate } from './api';

export type Scope = 'household' | 'me';
export interface Settings { household: Record<string, any>; me: Record<string, any>; rev: number }
type Patch = { household?: Record<string, any>; me?: Record<string, any> };
export type SaveStatus = 'idle' | 'saving' | 'saved' | 'offline' | 'error';

const OBJECTS = new Set(['nutritionTargets', 'xpRules', 'notifications', 'interaction', 'cookCheckin', 'appearance']);
const CACHE = 'larder.settings';
const PENDING = 'larder.settings.pending';

const isObj = (v: unknown): v is Record<string, any> => !!v && typeof v === 'object' && !Array.isArray(v);
/** Merge a patch into settings (objects merge field by field, like the server). */
function apply(s: Settings, p: Patch): Settings {
  const out: Settings = { household: { ...s.household }, me: { ...s.me }, rev: s.rev };
  for (const scope of ['household', 'me'] as const) {
    for (const [k, v] of Object.entries(p[scope] ?? {})) out[scope][k] = OBJECTS.has(k) && isObj(v) ? { ...(out[scope][k] ?? {}), ...v } : v;
  }
  return out;
}
/** Two patches as one: only the household and personal parts (the server accepts nothing else). */
const mergePatch = (a: Patch, b: Patch): Patch => {
  const m = apply({ household: a.household ?? {}, me: a.me ?? {}, rev: 0 }, b);
  const out: Patch = {};
  if (Object.keys(m.household).length) out.household = m.household;
  if (Object.keys(m.me).length) out.me = m.me;
  return out;
};
const empty = (p: Patch) => !Object.keys(p.household ?? {}).length && !Object.keys(p.me ?? {}).length;
const read = <T,>(k: string): T | null => {
  try {
    return JSON.parse(localStorage.getItem(k) ?? 'null');
  } catch {
    return null;
  }
};
const write = (k: string, v: unknown) => {
  try {
    if (v == null) localStorage.removeItem(k);
    else localStorage.setItem(k, JSON.stringify(v));
  } catch {
    /* private mode: settings still work, just without the offline copy */
  }
};

interface Ctx {
  settings: Settings;
  set: (scope: Scope, key: string, value: any) => void;
  /** The same Saving… / Saved / Not saved note, for saves that aren't settings (people, layouts). */
  track: <T>(p: Promise<T>) => Promise<T>;
  status: SaveStatus;
  error: string | null;
}
const SettingsCtx = createContext<Ctx>(null as any);
export const useSettings = () => useContext(SettingsCtx);
/** One setting and its setter. Object settings take partial updates: set({ prep: true }). */
export function useSetting<T = any>(scope: Scope, key: string): [T, (v: any) => void] {
  const { settings, set } = useSettings();
  return [settings[scope][key] as T, useCallback((v: any) => set(scope, key, v), [set, scope, key])];
}

export function SettingsProvider({ userId, children, fallback }: { userId: string; children: ReactNode; fallback?: ReactNode }) {
  const cacheKey = `${CACHE}.${userId}`;
  const pendingKey = `${PENDING}.${userId}`;
  const [server, setServer] = useState<Settings | null>(() => read<Settings>(cacheKey));
  const [loaded, setLoaded] = useState(false);
  const pending = useRef<Patch>(read<Patch>(pendingKey) ?? {});
  const inflight = useRef<Patch | null>(null);
  const [, bump] = useState(0);
  const [status, setStatus] = useState<SaveStatus>('idle');
  const [error, setError] = useState<string | null>(null);
  const timer = useRef<number>();
  const retry = useRef(0);
  const serverRef = useRef(server);
  serverRef.current = server;

  const accept = useCallback((s: Settings) => {
    // Never go back to an older copy (a slow GET arriving after a newer save).
    if (serverRef.current && s.rev < serverRef.current.rev) return;
    serverRef.current = s;
    setServer(s);
    write(cacheKey, s);
  }, [cacheKey]);

  const flush = useCallback(async () => {
    window.clearTimeout(timer.current);
    if (inflight.current || empty(pending.current)) return;
    const batch = pending.current;
    inflight.current = batch;
    pending.current = {};
    write(pendingKey, batch);
    setStatus('saving');
    try {
      const fresh = await api<Settings>('PATCH', '/api/settings', batch);
      inflight.current = null;
      retry.current = 0;
      accept(fresh);
      write(pendingKey, empty(pending.current) ? null : pending.current);
      setError(null);
      // Screens that depend on settings (recipes, planner, progress) refresh themselves.
      invalidate(['preferences', 'recipes', 'planner', 'game']);
      if (!empty(pending.current)) flush();
      else {
        setStatus('saved');
        timer.current = window.setTimeout(() => setStatus('idle'), 1600);
      }
    } catch (e: any) {
      inflight.current = null;
      if (e instanceof ApiError && e.status >= 400 && e.status < 500) {
        // Rejected: roll back this batch (keep anything changed since), say why.
        write(pendingKey, empty(pending.current) ? null : pending.current);
        setError(e.message);
        setStatus('error');
        bump((n) => n + 1);
        if (!empty(pending.current)) timer.current = window.setTimeout(flush, 400);
      } else {
        // Offline or server trouble: keep the change (it shows as yours) and try again.
        pending.current = mergePatch(batch, pending.current);
        write(pendingKey, pending.current);
        setStatus('offline');
        retry.current = Math.min(retry.current + 1, 6);
        timer.current = window.setTimeout(flush, Math.min(30_000, 1000 * 2 ** retry.current));
      }
    }
  }, [accept, pendingKey]);

  const set = useCallback((scope: Scope, key: string, value: any) => {
    pending.current = mergePatch(pending.current, { [scope]: { [key]: value } });
    write(pendingKey, pending.current);
    setError(null);
    setStatus('saving');
    bump((n) => n + 1);
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(flush, 450);
  }, [flush, pendingKey]);

  const track = useCallback(<T,>(p: Promise<T>) => {
    window.clearTimeout(timer.current);
    setStatus('saving');
    return p.then(
      (v) => {
        setStatus('saved');
        timer.current = window.setTimeout(() => setStatus('idle'), 1600);
        return v;
      },
      (e) => {
        setError(e?.message ?? String(e));
        setStatus(e instanceof ApiError && e.status < 500 ? 'error' : 'offline');
        throw e;
      },
    );
  }, []);

  const load = useCallback(async () => {
    try {
      accept(await api<Settings>('GET', '/api/settings'));
    } catch {
      /* keep the cached copy; we'll try again on the next change event */
    } finally {
      setLoaded(true);
    }
  }, [accept]);

  useEffect(() => {
    load();
    // Unsent changes from last time (closed while offline): send them now.
    if (!empty(pending.current)) flush();
    const online = () => flush();
    const hide = () => document.visibilityState === 'hidden' && flush();
    const changed = () => !inflight.current && load();
    addEventListener('online', online);
    addEventListener('pagehide', flush as any);
    document.addEventListener('visibilitychange', hide);
    addEventListener('larder:settings-changed', changed);
    return () => {
      removeEventListener('online', online);
      removeEventListener('pagehide', flush as any);
      document.removeEventListener('visibilitychange', hide);
      removeEventListener('larder:settings-changed', changed);
    };
  }, [load, flush]);

  // What you see: the server's copy, then whatever is on its way there.
  const view = useMemo(() => {
    if (!server) return null;
    let v = server;
    if (inflight.current) v = apply(v, inflight.current);
    return apply(v, pending.current);
  }, [server, status, error, pending.current, inflight.current]);

  if (!view || (!loaded && !read(cacheKey))) return <>{fallback ?? null}</>;
  return <SettingsCtx.Provider value={{ settings: view, set, track, status, error }}>{children}</SettingsCtx.Provider>;
}

/** The small "Saving… / Saved / Couldn't save" note. */
export function SaveIndicator({ lang }: { lang: 'en' | 'nl' }) {
  const { status, error } = useSettings();
  if (status === 'idle') return null;
  const nl = lang === 'nl';
  const text =
    status === 'saving' ? (nl ? 'Opslaan…' : 'Saving…')
      : status === 'saved' ? (nl ? 'Opgeslagen' : 'Saved')
        : status === 'offline' ? (nl ? 'Geen verbinding, wordt bewaard en opnieuw geprobeerd' : 'Offline: kept, will retry')
          : `${nl ? 'Niet opgeslagen' : 'Not saved'}: ${error ?? ''}`;
  return <div className={`save-note ${status}`} role="status" aria-live="polite">{status === 'saved' ? '✓ ' : ''}{text}</div>;
}
