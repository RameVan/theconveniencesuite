# Slate — working agreement

Slate is a self-hosted, block-based workspace (pages, block editor, databases). Product
requirements: `docs/spec.md`. Design: `docs/architecture.md`. Status: `docs/progress.md`.
Step-by-step plan: `plan.md`.

## Locked decisions (do not revisit without a recorded reason)

- **Stack:** Next.js 16 (App Router, route handlers, `cacheComponents: false`, `output: "standalone"`),
  React 19, TypeScript strict, Tailwind 4.
- **Database:** PostgreSQL via Drizzle ORM (`casing: "snake_case"`). Embedded PGlite when
  `DATABASE_URL` is empty (dev, tests, single-user installs). Databases must be UTF8.
- **Migrations:** generated SQL in `drizzle/` (`npm run db:generate`), applied at startup.
- **Editor:** Tiptap 3 / ProseMirror. Content stored as one row per top-level block with a stable id.
- **Database records** are rows in `pages` with `database_id`; scalar property values in
  `pages.properties` JSONB; relations in `relation_links`.
- **Formulas:** hand-written parser/type checker/interpreter in `src/lib/formula` — never `eval`.
- **Auth:** scrypt passwords, hashed session tokens in HttpOnly cookies, hashed API tokens.
- **Files:** `StorageAdapter` (local disk or S3-compatible).
- **Realtime:** Yjs + Hocuspocus WebSocket server started by the app, sharing session auth;
  REST versioned saves remain the fallback.

## Hard rules

1. **No feature gating.** Never add plans, tiers, quotas or checks that disable features per user.
   Only instance-wide infrastructure safeguards (documented in `.env.example`) are allowed, and
   they must never delete data. `tests/scale.test.ts` enforces the absence of plan checks.
2. **Authorization on the server, always.** Every service function checks access with
   `requirePage` / `requireRole` / `AccessResolver`. Inaccessible = 404. Never rely on the UI.
3. **Real persistence only.** No mock data, no browser-only state for content, no silent fallbacks.
4. **Never weaken validation, skip tests or mock to get green.** Fix the cause.
5. **No data loss.** Destructive operations need confirmation; conflicting edits are preserved;
   imports never overwrite existing data.
6. **No Notion dependency** (account, API, or copied code). Independent branding.
7. Logs never contain page content or secrets.

## Workflow

```bash
npm run typecheck && npm run lint && npm test && npm run build
npm run test:pg        # same workflows against real PostgreSQL
npm run dev            # http://localhost:3000
```

After each unit of work: run the checks above, exercise the real workflow in the browser,
update `docs/progress.md` (Done / Partial / Next / Blocked / Known defects), commit.
Bash in this repo is Git Bash on Windows: write multi-line edits with the file tools or a
script file, not inline `node -e` with backticks.
