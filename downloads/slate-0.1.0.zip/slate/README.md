# Slate

A self-hosted workspace for notes, docs and databases: pages nested as deep as you like, a
block editor, and real databases with views, relations, rollups and formulas.

**Every feature is available to every user.** Slate has no plans, tiers, or paywalls. There are no
limits on pages, blocks, databases, records, properties, members, history, or file uploads beyond
the infrastructure safeguards an administrator chooses to set.

Slate is an independent implementation. It does not use or need a Notion account, API token, or
subscription.

---

## Features

| Area | What you get |
|---|---|
| Pages | Unlimited nesting, sidebar tree with drag-and-drop, favourites, recents, icons (emoji or image), covers (gradients, colours, images, repositionable), full width / small text, breadcrumbs, duplicate, move, trash & restore |
| Editor | Paragraphs, headings, bulleted / numbered / nested lists, to-dos, toggles, quotes, callouts, dividers, code (syntax highlighting), tables, images, video, audio, files, bookmarks with previews, embeds (YouTube, Vimeo, Loom, Figma, …), block and inline equations (KaTeX), table of contents, breadcrumbs, sub-pages, inline databases, linked database views, @-mentions of pages; slash menu, Markdown shortcuts, drag handle and block menu, colours and highlights, paste and drop uploads, undo/redo, autosave with status |
| Databases | 21 property types (title, text, number, select, multi-select, status, date / range, checkbox, URL, email, phone, person, files, relation, rollup, formula, created / edited time and by, unique ID); records are full pages; table, board, list, gallery, calendar, timeline and chart views; nested AND/OR filters, multi-sorts, grouping, aggregations, search; two-way relations, rollups, a typed formula language; record templates; CSV import/export |
| Search | Full-text search across titles, content and record properties, permission-aware, with snippets, paths and type filters; command palette |
| Collaboration | Realtime co-editing with live cursors and presence, workspaces with owner / admin / editor / viewer roles, invitations, private pages, per-page sharing with inheritance and overrides, public read-only links, inline comment threads, @-mentions and an inbox |
| History | Automatic page versions, preview and restore (restores are themselves undoable), conflicting edits kept as versions |
| Import / export | Markdown, HTML, CSV, and a full-fidelity JSON/ZIP backup that round-trips pages, databases, relations and files; loss report for lossy formats |
| API | REST API with personal API tokens (`docs/api.md`) |
| Self-hosting | Runs with zero external services (embedded PostgreSQL via PGlite), or with PostgreSQL + S3-compatible storage via Docker Compose |

See [`docs/feature-matrix.md`](docs/feature-matrix.md) for a feature-by-feature comparison and
[`docs/progress.md`](docs/progress.md) for what is complete and what is planned.

---

## Quick start (no Docker)

Requirements: Node.js 20+ (24 recommended).

```bash
npm install
npm run dev
```

Open <http://localhost:3000>. The first account you create becomes the instance administrator.
With no `DATABASE_URL`, Slate stores everything in `./data` (embedded PostgreSQL + uploads).

Production build without Docker:

```bash
npm run build
npm start
```

## Docker Compose (PostgreSQL)

```bash
cp .env.example .env    # set POSTGRES_PASSWORD at least
docker compose up -d
```

This starts PostgreSQL 17 and Slate on port 3000 (realtime co-editing on 3001). Migrations run
automatically on startup. To use other host ports, set `SLATE_PORT` / `SLATE_COLLAB_PORT` in `.env`
(the app tells browsers which realtime port to use).

To run the end-to-end suite against a running stack (here on ports 3300/3301):

```bash
SLATE_PORT=3300 SLATE_COLLAB_PORT=3301 docker compose up -d
npx playwright test -c playwright.docker.config.ts
```

The suite signs up many users, so raise `AUTH_RATE_LIMIT_PER_MINUTE` for that stack (e.g. with a
Compose override file).

**Docker inside WSL 2 (Windows without Docker Desktop):** install `docker.io` and
`docker-compose-v2` in the Ubuntu distro and run `docker compose` there. WSL stops an idle distro
(and its containers) once no WSL terminal is open; keep one open while Slate should run, or raise
the idle timeout in `%UserProfile%\.wslconfig`.
Put Slate behind an HTTPS reverse proxy (Caddy, nginx, Traefik) for anything beyond a trusted
network, then set `SECURE_COOKIES=true` and `TRUST_PROXY=true`.

## Install on a phone or desktop

Slate is an installable web app (no app store needed). Open it in the browser, sign in, then:

- **iPhone / iPad (Safari):** Share button → **Add to Home Screen**. It opens full screen with its
  own icon. Home Screen apps keep their own sign-in, so sign in once more inside the app.
- **Android (Chrome):** ⋮ menu → **Install app** (or **Add to Home screen**). A full install needs
  HTTPS; over plain `http://` on a home network Chrome adds a shortcut instead.
- **Desktop (Chrome, Edge):** the install icon in the address bar.

The phone must reach the server: use the computer's network address (e.g. `http://192.168.1.20:3000`)
and allow the ports through its firewall. With Docker inside WSL 2 on Windows, also forward the ports
from Windows to WSL (depends on WSL's networking mode; see `docs/operations.md`).

## Configuration

All settings are environment variables; [`.env.example`](.env.example) documents every one.
The most important:

| Variable | Default | Purpose |
|---|---|---|
| `DATABASE_URL` | *(empty)* | PostgreSQL URL. Empty = embedded PGlite in `DATA_DIR/pglite`. The database must use UTF8. |
| `DATA_DIR` | `./data` | Embedded database and local uploads |
| `ALLOW_SIGNUP` | `true` | Open sign-up. Set `false` after creating accounts; invitations still work |
| `ALLOW_PUBLIC_SHARING` | `true` | Instance-wide switch for public links |
| `STORAGE_DRIVER` | `local` | `local` or `s3` (any S3-compatible service, with `S3_*` settings) |
| `MAX_UPLOAD_BYTES` | 100 MB | Per-file safeguard |
| `RATE_LIMIT_PER_MINUTE` / `AUTH_RATE_LIMIT_PER_MINUTE` | 1200 / 20 | Per-IP abuse protection |
| `REVISION_INTERVAL_SECONDS` | 300 | Minimum time between automatic page versions |
| `TRASH_RETENTION_DAYS` | 0 | Auto-delete trash after N days (0 = never) |
| `SECURE_COOKIES` | true in production | Mark the session cookie `Secure` (requires HTTPS) |
| `APP_URL` | – | Public URL used for sign-in redirects and links in emails |
| `SMTP_URL` / `SMTP_FROM` | – | Optional email about mentions and replies, e.g. `smtps://user:pass@smtp.example.com:465` |
| `OIDC_ISSUER` / `OIDC_CLIENT_ID` / `OIDC_CLIENT_SECRET` | – | Optional single sign-on with any OpenID Connect provider; see `docs/operations.md` |
| `REALTIME` / `COLLAB_PORT` / `COLLAB_PUBLIC_URL` | true / 3001 / – | Realtime co-editing server; see `docs/operations.md` for proxying |

Limits are **infrastructure safeguards**, identical for everyone, and never delete data: when one
is reached the request fails with a clear error. See [`docs/operations.md`](docs/operations.md).

## Development

```bash
npm run dev          # dev server
npm test             # unit + integration tests (embedded PostgreSQL, no setup needed)
npm run test:pg      # same core workflows against a real PostgreSQL server (embedded-postgres)
npm run test:online # link previews and video embeds against real websites (needs internet)
npm run build && npm run test:e2e   # Playwright end-to-end suite against the production build (installed Chrome;
                     #   PW_CHANNEL=msedge, or PW_CHANNEL=chromium after `npx playwright install chromium`)
npm run typecheck
npm run lint
npm run build
npm run db:generate  # create a migration after editing src/server/db/schema.ts
npm run db:migrate   # apply migrations (also done automatically at startup)
npm run files:cleanup
```

Project layout and design decisions: [`docs/architecture.md`](docs/architecture.md). The build plan
with every step: [`plan.md`](plan.md).

## Backups

- **Inside the app:** Settings → Import & export → *Export all content* produces a ZIP with
  `slate.json` (re-importable), Markdown, CSV and attachments.
- **PostgreSQL:** `pg_dump` / `pg_restore` plus a copy of `DATA_DIR/uploads` (or your S3 bucket).
- **Embedded PGlite:** stop Slate and copy `DATA_DIR`.

Step-by-step instructions: [`docs/operations.md`](docs/operations.md#backups).

## Troubleshooting

| Symptom | Fix |
|---|---|
| Login works but you are immediately logged out | You are on plain HTTP with `SECURE_COOKIES=true` (the production default). Use HTTPS, or set `SECURE_COOKIES=false` on a trusted network. |
| "Cross-origin request blocked" | The browser `Origin` does not match the `Host` header. Behind a proxy, forward the original `Host` (or set `X-Forwarded-Host` and `TRUST_PROXY=true`). |
| "The PostgreSQL database uses the WIN1252 encoding" | Recreate the database with `ENCODING 'UTF8'` (the Compose file already does). |
| Uploads fail with "at most N MB" | Raise `MAX_UPLOAD_BYTES` (and your proxy's body size limit). |
| Too many requests (429) | Raise `RATE_LIMIT_PER_MINUTE`, or set `TRUST_PROXY=true` so clients are not all seen as one IP. |
| Embedded database locked | Only one Slate process may use a PGlite `DATA_DIR`. Use PostgreSQL to run several instances. |
| Status shows "Saved" instead of "Live", no cursors | The browser cannot reach the realtime port (3001). Open it in your firewall or proxy it and set `COLLAB_PUBLIC_URL`. Editing still works via REST saves; the page switches to "Live" by itself once the port is reachable. |

## Security

Passwords are hashed with scrypt, sessions are HttpOnly cookies stored only as hashes, every
API call is authorised on the server, and uploaded files are served sandboxed. Details and the threat
model: [`docs/security.md`](docs/security.md).

## License

Original code in this repository. Dependencies are permissively licensed (MIT / Apache-2.0 /
PostgreSQL / ISC); no code was copied from Notion's repositories.
