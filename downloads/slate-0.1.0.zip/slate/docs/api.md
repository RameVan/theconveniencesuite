# REST API

Base path: `/api`. All bodies are JSON unless noted. Errors use
`{ "error": { "code": string, "message": string, "details"?: any } }` with HTTP status
400 (invalid input), 401 (sign in), 403 (forbidden), 404 (not found **or** no access), 409
(conflict), 413 (too large), 429 (rate limited).

## Authentication

* **Browser:** the `slate_session` HttpOnly cookie set by `/api/auth/login` or `/api/auth/signup`.
  State-changing requests must send an `Origin` header matching the host (CSRF protection).
* **Scripts:** a personal API token (Settings → API tokens, or `POST /api/auth/tokens`) sent as
  `Authorization: Bearer slt_…`. Tokens act with the creating user's permissions. No Origin check.

```bash
curl -H "Authorization: Bearer $SLATE_TOKEN" https://slate.example.com/api/workspaces
```

## Endpoints

### Account
| Method | Path | Body / notes |
|---|---|---|
| POST | `/auth/signup` | `{ name, email, password, inviteToken? }` → `{ user, workspaceId }` |
| POST | `/auth/login` | `{ email, password }` |
| POST | `/auth/password/forgot` | `{ email }` → `{ ok, emailAvailable }` (same answer whether or not the account exists; needs SMTP_URL and APP_URL) |
| POST | `/auth/password/reset` | `{ token, password }` — single-use link token from the email, valid 1 hour; signs out every session |
| GET | `/auth/oidc/start?next=` ; `/auth/oidc/callback` | browser redirects for single sign-on (when configured; `GET /auth/me` returns `sso`) |
| POST | `/auth/logout` | |
| GET | `/auth/me` | current user + instance flags |
| PATCH | `/auth/me` | `{ name?, avatarUrl? }` |
| POST | `/auth/password` | `{ currentPassword, newPassword }` (signs out other sessions) |
| GET / DELETE | `/auth/sessions` | list / revoke all other sessions |
| DELETE | `/auth/sessions/:id` | revoke one |
| GET / POST | `/auth/tokens` | list / create `{ name }` → `{ token }` (shown once) |
| DELETE | `/auth/tokens/:id` | revoke |
| DELETE | `/auth/account` | `{ password }` |

### Workspaces & members
| Method | Path | Body / notes |
|---|---|---|
| GET / POST | `/workspaces` | create `{ name, icon?, starter? }` |
| GET / PATCH / DELETE | `/workspaces/:id` | delete needs `{ confirmName }` (owner) |
| GET | `/workspaces/:id/tree` | sidebar nodes + favourites |
| GET | `/workspaces/:id/recent` | recently visited pages |
| GET | `/workspaces/:id/trash?q=` | trashed pages |
| GET | `/workspaces/:id/databases` | databases you can see |
| GET | `/workspaces/:id/members` | |
| PATCH / DELETE | `/workspaces/:id/members/:userId` | `{ role }` / remove (or leave, for yourself) |
| GET / POST | `/workspaces/:id/invitations` | create `{ email, role }` → `{ path }` |
| DELETE | `/workspaces/:id/invitations/:invId` | |
| GET / POST | `/invitations/:token` | preview / accept |
| GET | `/workspaces/:id/storage` | bytes used |
| GET | `/workspaces/:id/export` | ZIP backup of everything you can see |
| POST | `/workspaces/:id/import` | `multipart/form-data`: `file` (.md, .zip, .csv, .json), optional `parentId`, `databaseId` |

### Pages
| Method | Path | Body / notes |
|---|---|---|
| POST | `/pages` | `{ workspaceId, parentId?, title?, icon?, cover?, kind?: "page"\|"database", visibility?, blocks? }` |
| GET | `/pages/:id` | page, access, breadcrumbs, content (blocks), children, database/record data |
| PATCH | `/pages/:id` | `{ title?, icon?, cover?, fullWidth?, smallText?, visibility?, isTemplate? }` |
| DELETE | `/pages/:id` | permanent delete (must be in the trash; full access) |
| PUT | `/pages/:id/content` | `{ baseVersion?, blocks: [{ id, content }] }` → 409 if `baseVersion` is stale |
| GET | `/pages/:id/version` | `{ version, updatedAt }` |
| POST | `/pages/:id/move` | `{ parentId, beforeId?, afterId?, visibility? }` |
| POST | `/pages/:id/duplicate` | deep copy |
| POST | `/pages/:id/archive`, `/pages/:id/restore` | trash / restore |
| PUT / DELETE / PATCH | `/pages/:id/favorite` | PATCH `{ beforeId }` reorders your favourites (null: last) |
| GET | `/pages/:id/revisions` | history |
| GET / POST | `/pages/:id/revisions/:revId` | read / restore |
| GET / PUT | `/pages/:id/sharing` | grant `{ email, access: "full"\|"edit"\|"view"\|"none"\|null }` |
| PUT | `/pages/:id/public` | `{ enabled }` → `{ token }` |
| GET | `/pages/:id/export?format=md\|html\|json&subpages=1` | |
| GET / POST | `/pages/:id/comments` | `{ body, id?, parentId?, blockId?, quote? }` — `parentId` replies to a thread; `blockId`+`quote` make an inline thread (its anchor is a `comment` mark with `threadId` = the thread's id, which the client may choose). Mention people in `body` as `@[Name](user:<id>)`. |
| PATCH / DELETE | `/pages/:id/comments/:commentId` | `{ resolved?, body? }` (resolve threads, not replies); deleting a thread deletes its replies |
| GET | `/notifications?workspaceId=&limit=` | your mentions and replies (only pages you can still view) + `unread` |
| POST | `/notifications/read` | `{ ids: [...] }` or `{ all: true, workspaceId? }` |

**Blocks** are ProseMirror node JSON objects. Each top-level block needs a unique `id`
(`[A-Za-z0-9_-]{1,64}`); allowed node and mark types are listed in `src/lib/blocks.ts`.

### Databases
| Method | Path | Body / notes |
|---|---|---|
| GET / PATCH | `/databases/:id` | schema, views, templates; PATCH `{ defaultTemplateId }` |
| POST | `/databases/:id/properties` | `{ name, type, config?, twoWay?, syncedName? }` |
| PATCH / DELETE | `/properties/:id` | `{ name?, type?, config?, position? }` |
| POST | `/databases/:id/views` | `{ name?, type?, config? }` |
| PATCH / DELETE | `/views/:id`; POST `/views/:id/duplicate` | |
| POST | `/databases/:id/query` | `{ viewId?, config?, search?, offset?, limit?, groupLimit?, groupKey? }` → rows with computed values, `total`, `matched`, `offset`, `hasMore`, groups (with `count`), aggregations over all matches. With `limit`, only that page of rows is returned (grouped views: `groupLimit` rows per group, or more of one group with `groupKey` + `offset`/`limit`); without it, all rows. |
| GET | `/databases/:id/records?q=` | title search (relation pickers) |
| POST | `/databases/:id/records` | `{ title?, values?, templateId?, isTemplate? }` |
| POST | `/databases/:id/reorder` | `{ id, beforeId }` moves one record (before `beforeId`, or to the end with `null`); `{ ids: [...] }` sets the order of the given records |
| GET | `/databases/:id/export?viewId=` | CSV |
| GET / PATCH | `/records/:id` | PATCH `{ title?, values: { [propertyIdOrName]: value } }` |

**Values** by type: text/url/email/phone → string; number → number; checkbox → boolean;
select/status → option id or name (unknown names create a new select option); multi-select →
array of ids or names; date → `"YYYY-MM-DD"` or `{ start, end?, includeTime? }`; person → array
of member user ids; files → `[{ name, url }]`; relation → array of record ids in the target
database; computed types are read-only.

### Realtime (WebSocket)
`ws(s)://<host>:3001` (or `COLLAB_PUBLIC_URL`) speaks the Hocuspocus/Yjs protocol; the document
name is the page id and the Yjs fragment is `default`. Authentication uses the session cookie;
viewers are read-only. Scripts should use the REST endpoints instead.

### Other
| Method | Path | Notes |
|---|---|---|
| GET | `/search?q=&workspaceId=&type=page\|database\|record&limit=` | permission-aware |
| POST | `/files` | `multipart/form-data`: `file`, `workspaceId` → `{ id, url }` |
| GET | `/files/:id?download=1` | |
| GET / POST | `/templates` | list / apply `{ key, workspaceId, parentId? }` |
| GET | `/unfurl?url=` | link preview (blocks private network targets) |
| GET | `/share/:token?page=` ; POST `/share/:token/query` | public read-only access; the query takes `{ databaseId, viewId?, block?: { pageId, blockId } }` (a linked block's own views are read from the block) |
| GET | `/health` | `{ ok }` |
