# Architecture

## Overview

```
Browser (React 19 client components, Tiptap editor, SWR cache)
   │  JSON over HTTPS  (cookie session or Bearer API token)
   ▼
Next.js 16 route handlers  /api/**      ← thin: parse, authenticate, call a service
   │
   ▼
Domain services  src/server/services/*  ← all business rules + authorization
   │
   ▼
Drizzle ORM  →  PostgreSQL (pg driver)  or  PGlite (embedded Postgres, dev/tests)
                File storage: local disk or S3-compatible
```

* One deployable Next.js process (`output: "standalone"`). It is stateless except for the
  in-memory rate limiter, so several instances can run behind a load balancer against one
  PostgreSQL and one S3 bucket (switch the rate limiter to a shared store for strict limits).
* **No external services are required**: with no `DATABASE_URL` the app uses an embedded PGlite
  database in `DATA_DIR/pglite`, and files go to `DATA_DIR/uploads`.

## Source layout

| Path | Contents |
|---|---|
| `src/server/db/` | Drizzle schema, connection (pg / PGlite), migration runner |
| `src/server/services/` | auth, workspaces, pages, blocks, permissions, databases, records, query, search, revisions, files, import/export, templates |
| `src/server/http.ts` | `api()` wrapper: auth, CSRF/origin check, rate limit, zod errors → HTTP |
| `src/lib/formula/` | Formula tokenizer, parser, type checker, evaluator (shared, no `eval`) |
| `src/lib/db-types.ts` | Property/view/filter types shared by client and server |
| `src/lib/markdown.ts` | Block JSON ⇄ Markdown/HTML converters |
| `src/lib/editor-schema.ts` | Editor schema shared by the browser and the realtime server |
| `src/server/collab.ts` | Realtime co-editing server (Yjs/Hocuspocus) |
| `src/app/api/**` | REST route handlers (documented in `docs/api.md`) |
| `src/app/(app)/**` | Authenticated UI: sidebar, page view, database views |
| `src/components/editor/` | Tiptap editor, custom nodes, slash menu, drag handle |
| `src/components/database/` | Table, board, list, gallery, calendar, timeline, chart views |
| `drizzle/` | Generated SQL migrations (committed) |
| `tests/` | Vitest unit + integration tests (run on in-memory PGlite) |

## Data model

```
users ─< sessions            users ─< api_tokens
users ─< workspace_members >─ workspaces ─< invitations
workspaces ─< pages (tree via parent_id; records via database_id)
pages ─< blocks              (composite PK page_id+id; one row per top-level block)
pages(kind=database) ─< database_properties, database_views
database_properties ─< relation_links >─ pages (from/to)
pages ─< page_permissions >─ users
pages ─< page_revisions      pages ─< favorites >─ users      pages ─< page_visits
workspaces ─< files          workspaces ─< audit_events
```

### Pages, databases and records are all rows in `pages`
* `kind = 'page' | 'database'`. A database is a page with a schema.
* A **record** is a page with `database_id` set (its `parent_id` is NULL). Records have full page
  content (blocks), sub-pages, history, and permissions like any page.
* Hierarchy is real: `parent_id` is a self-referencing FK (`ON DELETE CASCADE`). Ordering uses a
  `position` double (fractional indexing: insert between neighbours without renumbering).
* For permission inheritance a record's parent is its database.

### Blocks
* Each **top-level** block is a row: `(page_id, id, position, type, content JSONB, text)`. `content`
  is the ProseMirror node JSON (validated against an allow-list of node and mark types); `text`
  is extracted plain text for search. Nested structure (list items, toggle children, table cells)
  lives inside the top-level block's JSON. This keeps per-block identity, searchability,
  per-block diffing on save, and export fidelity, without the cost of a row per list item.
* Block IDs are UUIDs assigned client-side by an editor plugin and unique per page (composite
  PK), so a malicious client cannot overwrite another page's block by reusing an ID.

### Property values — JSONB on the record + typed side table for relations
Three options were considered:

| Option | Pros | Cons |
|---|---|---|
| EAV table (`record_id, property_id, value_*`) | Typed columns, SQL filtering | Many joins per row, slow wide reads, complex writes |
| One SQL column per property (DDL on schema change) | Fast SQL | Runtime DDL, migrations per user action — rejected |
| **JSONB map `properties` on the record** | One read per row, no DDL, flexible types, GIN-indexable | Validation must be in the app |

Slate stores scalar values in `pages.properties` (`{propertyId: value}`), validated per type by
`src/server/services/properties.ts`. **Relations** are the exception: they live in
`relation_links (property_id, from_page_id, to_page_id, position)` with foreign keys and cascades,
so links stay valid when records are renamed or moved and are removed when a record is
permanently deleted. Two-way relations store the mirrored row on the synced property in the same
transaction. Title, created/edited time and by are real columns.

### Views
`database_views.config` (JSONB) holds `filter` (AND/OR tree), `sorts`, `groupBy`, `subGroupBy`,
`visibleProperties`, `propertyWidths`, `propertyOrder`, `aggregations`, and type-specific options
(calendar/timeline date property, gallery cover, chart axis). A *linked view* is a
`databaseView` block that references a database and owns its own view list in the block JSON.

### Query execution
`queryDatabase()` loads the records of one database (non-archived) with their property JSON,
batch-loads relation links, computes rollups and formulas, then filters, sorts, groups and
aggregates in TypeScript. This keeps formulas/rollups (which are not expressible in SQL)
consistent with filtering. It handles tens of thousands of rows per database in well under a
second (see `tests/scale.test.ts`). The service boundary allows pushing simple filters down to
SQL later without changing callers.

### Formulas
A hand-written Pratt parser produces an AST; a type checker infers `number | text | boolean | date
| list | empty` and reports positioned errors; the evaluator walks the AST. There is no `eval`,
no `Function`, no property access on host objects. Limits: expression length, AST depth, and an
evaluation step budget. Dependencies between formula properties are resolved in topological
order; cycles are reported as errors on the property (never hang). Rollups can feed formulas.

## Authorization

* Every service function takes an `Actor` (`userId`) and checks access itself; route handlers
  never rely on the UI hiding controls.
* **Workspace roles**: `owner > admin > editor > viewer`. Owners/admins manage members.
* **Page access levels**: `none < view < edit < full` (`full` = may share/manage permissions and
  delete). Effective access is computed by walking the ancestor chain (record → database →
  parents):
  1. The nearest explicit `page_permissions` row for the user wins (it can also be `none` to
     revoke inherited access).
  2. A `private` page (or an ancestor) is visible only to its creator unless an explicit grant
     exists at or below it.
  3. Otherwise the workspace role applies: owner/admin → `full`, editor → `edit`,
     viewer → `view`, non-member → `none`.
* Single-page checks use a recursive CTE; list endpoints (sidebar, search, query) use a bulk
  in-memory resolver over the workspace's structural rows.
* Public links: `pages.public_share_token` (random 32 bytes, base64url). `/share/<token>` serves
  the page and its descendants read-only. Disabled globally with `ALLOW_PUBLIC_SHARING=false`.

## Authentication & security
* Passwords hashed with Node's `scrypt` (N=2^15, r=8, p=1, 16-byte salt), constant-time compare.
* Sessions: random 32-byte token in an `HttpOnly; SameSite=Lax; Secure (in production)` cookie;
  only the SHA-256 hash is stored; sliding expiry (`SESSION_TTL_DAYS`), revocable per session.
* API tokens (`Authorization: Bearer slt_…`) are hashed the same way.
* CSRF: state-changing cookie-authenticated requests must carry an `Origin` matching the host.
* Input validated with zod at every route; ORM parameterization prevents SQL injection.
* Rate limiting per IP (auth endpoints stricter); request body size limits; upload size limit and
  MIME sniffing; uploaded files served with `X-Content-Type-Options: nosniff` and
  `Content-Disposition: attachment` for anything that could execute (HTML, SVG, XML).
* URL unfurling (bookmarks) resolves DNS and refuses private/loopback/link-local addresses
  (SSRF protection), with timeouts and a response size cap.
* Logs contain request method, route, status and duration — never page content or secrets.
* No encryption-at-rest claims: data is protected by database/disk controls of the deployment.

## Version history
`page_revisions` stores snapshots (title, icon, cover, properties, relation links, blocks). After a
content or property save, a snapshot is written if the latest one is older than
`REVISION_INTERVAL_SECONDS` (default 300) and the content hash changed. Restoring first snapshots
the current state, so a restore is itself reversible. Relations restore only to targets that
still exist.

## Concurrency and realtime co-editing
* **Realtime (default):** `src/server/collab.ts` runs a Hocuspocus (Yjs CRDT) WebSocket server,
  started from `instrumentation.ts` on `COLLAB_PORT`. Each page is a Yjs document; editors use
  Tiptap's Collaboration and caret extensions over the same schema the server uses
  (`src/lib/editor-schema.ts`). Connections authenticate with the session cookie and are checked
  with `requirePage`; viewers are read-only.
* **Persistence:** edits are written to the block table (debounced, via `saveContent`, so history,
  search and export keep working) and the Yjs state is stored in `page_ydocs` with the page
  `version` it matches. The stored history is always reused — content written by other means
  (restore, REST/API saves) is applied to it as a minimal diff (`updateYFragment`) — so clients that
  reconnect with an older copy merge instead of duplicating content. REST writes are pushed into
  open documents immediately.
* **Fallback:** if the realtime server is unreachable, the editor uses versioned REST saves: each
  save sends `baseVersion`; on mismatch the server returns `409` and stores the rejected content as a
  "conflict" revision so nothing is lost. Idle REST clients poll for newer versions.

## Files
`StorageAdapter` with `local` (DATA_DIR/uploads, content-addressed by id) and `s3` (any
S3-compatible endpoint via `@aws-sdk/client-s3`, loaded lazily). Files are served through
`/api/files/:id`, which checks the requester can read the workspace/page (or a public share that
references it). A cleanup job deletes files unreferenced by any block, property, icon or cover and
older than 24h (`npm run files:cleanup`).

## Infrastructure limits (not feature limits)
All configurable via environment, documented in `.env.example`:
`MAX_UPLOAD_BYTES`, `MAX_JSON_BODY_BYTES`, `RATE_LIMIT_PER_MINUTE`, `AUTH_RATE_LIMIT_PER_MINUTE`,
`DB_STATEMENT_TIMEOUT_MS`, `MAX_IMPORT_BYTES`. None of them depends on a user, plan or role, and
reaching one returns an explicit error without deleting data. There is no plan/tier concept in
the codebase.
