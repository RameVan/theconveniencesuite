# Feature matrix

How each major Notion capability maps to Slate, where it lives in the code, and its status.
**Status:** ✅ implemented and verified (automated tests and/or browser check) · 🟡 implemented,
partly verified or with known limits · ⏳ planned.
"Plan gate in Notion" notes where hosted Notion restricts the feature by plan; Slate has no gates.

## Workspace & navigation

| Feature | Plan gate in Notion | Slate implementation | Status |
|---|---|---|---|
| Multiple workspaces, switcher | — | `services/workspaces.ts`, sidebar switcher | ✅ |
| Nested pages (unlimited depth) | — | `pages.parent_id` self-FK; recursive CTEs | ✅ (120 levels tested) |
| Sidebar tree, expand/collapse | — | `components/sidebar.tsx` | ✅ |
| Favorites, recents | — | `favorites`, `page_visits` tables | ✅ (favourites reorder by drag or Move up/down) |
| Private / Workspace / Shared sections | — | `visibility` + grants | ✅ |
| Drag-and-drop reorder / nest in sidebar | — | HTML5 DnD → `POST /pages/:id/move` (`beforeId/afterId`) | ✅ (E2E: nest + move to top level) |
| Icons (emoji/image), covers (gradient/colour/image, reposition) | — | `page/cover.tsx`, emoji picker | ✅ |
| Breadcrumbs | — | top bar + breadcrumb block | ✅ |
| Context menus, duplicate, move, delete | — | sidebar & page `•••` menus | ✅ |
| Trash with restore, permanent delete | Free: 30-day trash | `archived_root_id` batches | ✅ |
| Keyboard shortcuts, command palette | — | `search-dialog.tsx`, shortcuts dialog | ✅ |
| Mobile layout, installable app | — | drawer sidebar, responsive views, web app manifest, touch block menu | ✅ (`e2e/iphone.spec.ts`; used on an iPhone) |

## Editor

| Feature | Plan gate in Notion | Slate implementation | Status |
|---|---|---|---|
| Text, H1–H3, lists, nested lists, to-dos | Block limit on Free for teams | Tiptap StarterKit + TaskList | ✅ |
| Toggle, quote, callout, divider | — | custom nodes | ✅ |
| Code blocks with highlighting, language picker | — | lowlight + node view | ✅ |
| Inline formatting, colours, highlights, links | — | marks + bubble toolbar | ✅ |
| Images, files, video, audio (upload or URL) | File size cap on Free (5 MB) | `files` + node views; admin-set `MAX_UPLOAD_BYTES` | ✅ (paste upload verified) |
| Bookmarks with previews | — | `/api/unfurl` with SSRF guard | ✅ (online tests: example.com, GitHub, YouTube; private addresses refused) |
| Embeds (YouTube, Vimeo, Loom, Figma, …) | — | allow-listed sandboxed iframes | ✅ (YouTube and Vimeo players load; online test + browser check) |
| Tables | — | TableKit (resizable) | ✅ |
| Table of contents, breadcrumb block | — | live node views | ✅ |
| Block & inline equations | — | KaTeX (`trust: false`) | ✅ |
| Sub-page blocks, @-mentions of pages | — | `childPage`, `pageLink` nodes | ✅ |
| Inline databases & linked views | — | `databaseView` node | ✅ |
| Slash menu, Markdown shortcuts | — | `@tiptap/suggestion`, input rules | ✅ |
| Drag handle, block menu (turn into, colour, duplicate, delete, copy link) | — | `drag-handle.tsx`, `block-actions.tsx` | ✅ (E2E: handle drag in realtime mode; moves by block id in one transaction) |
| Multi-block selection | — | ProseMirror selection | ✅ |
| Paste from other apps (HTML), files | — | ProseMirror + upload handlers | ✅ |
| Undo / redo | — | history extension | ✅ |
| Autosave with status | — | debounced versioned saves + keepalive on unload | ✅ |
| Stable block IDs, structured storage | — | one row per top-level block, allow-list validation | ✅ |

## Databases

| Feature | Plan gate in Notion | Slate implementation | Status |
|---|---|---|---|
| Unlimited databases, rows, properties | Block limits on Free (teams) | no caps; 200 DBs / 5,001 rows tested | ✅ |
| 21 property types incl. relation, rollup, formula, unique ID | — | `services/databases.ts`, `compute.ts` | ✅ |
| Typed validation, select option auto-creation | — | `normalizeValue` | ✅ |
| Type conversion keeping values | — | `convertType` through text | ✅ |
| Records as full pages, record templates, default template | Templates on all plans | pages with `database_id`, `is_template` | ✅ |
| Table: inline edit, resize, reorder, hide, wrap, aggregations | — | `views/table.tsx` | ✅ (E2E: cell edit, rename, column resize, column and row reorder) |
| Board with drag between columns | — | `views/board.tsx` | ✅ (E2E: card drag between columns) |
| List, gallery, calendar, timeline, chart | Chart: paid plans | `views/*` | ✅ render verified; E2E: calendar drag, timeline move + stretch |
| Very large databases (no record limits) | Row limits on lower plans | paged queries, SQL push-down, cached evaluation, virtualised table rows | ✅ (differential + cache tests; 50k-record benchmark; E2E) |
| Filters with nested AND/OR groups, relative dates | Advanced filters on paid | `matchFilter` | ✅ |
| Multi-sort, grouping, hide empty groups | — | `runQuery` | ✅ |
| Search within a database | — | query `search` | ✅ |
| Linked views of existing databases | — | `databaseView` block with `databaseId` | ✅ (new linked blocks have their own views, stored in the block; server + E2E tests) |
| Two-way relations | — | `relation_links` + synced property | ✅ |
| Rollups (20 functions) | — | `applyRollup` | ✅ |
| Formulas with type checking & cycle detection | — | `lib/formula` | ✅ (27 unit tests) |
| Database-level permissions | Paid | page permissions on the database page (records inherit) | ✅ |
| CSV import/export | — | `transfer.ts` | ✅ round-trip tested |

## Search, collaboration, history

| Feature | Plan gate in Notion | Slate implementation | Status |
|---|---|---|---|
| Full-text search of titles, content, properties | Search history limited on Free | Postgres `tsvector` + `ILIKE` | ✅ |
| Permission-aware results | — | `AccessResolver` filtering | ✅ (IDOR tests) |
| Members, roles (owner/admin/editor/viewer), invitations | Guests/admin roles on paid plans | `workspaces.ts` | ✅ |
| Page sharing with inheritance and overrides | Advanced on paid | `page_permissions` nearest-grant rule | ✅ |
| Public read-only links | Some options paid | share tokens, `/share/[token]` | ✅ |
| Comments | — | page and inline threads (anchored to text), replies, resolve/reopen | ✅ (server tests + E2E) |
| @-mentions of people, notifications inbox | — | `mention` node, comment mention tokens, `notifications` table, Inbox | ✅ (server tests incl. no leaks to people without access + E2E) |
| Concurrent editing safety | — | CRDT merging in realtime mode; versioned saves, 409 + conflict copies in fallback mode | ✅ |
| Realtime character-level co-editing, live cursors, presence | — | Yjs + Hocuspocus (`server/collab.ts`), REST fallback with background reconnect | ✅ (two-client server tests + two-browser E2E: typing both ways, presence, carets) |
| Version history | 7 days on Free, 30/90 on paid | unlimited, `page_revisions` | ✅ |
| Restore versions (undoable) | Paid | `restoreRevision` | ✅ |

## Import / export & operations

| Feature | Plan gate in Notion | Slate implementation | Status |
|---|---|---|---|
| Markdown import (files, folders → nested pages) | — | `importMarkdown` | ✅ |
| Markdown / HTML export, loss report | PDF export on paid | `lib/markdown.ts` | ✅ |
| Full workspace export & re-import (JSON + files) | Workspace export on paid (some formats) | `buildExportZip` / `importSlate` | ✅ |
| REST API with personal tokens | Integrations on all plans, rate-limited | `/api/**`, `docs/api.md` | ✅ |
| Import a Notion export (Markdown & CSV ZIP) | — | `import-notion.ts`: hierarchy, databases with record pages, links, images, nested ZIPs | ✅ (server tests + E2E) |
| Self-hosting, Docker | — | Dockerfile, Compose, standalone build | ✅ (image built; Compose stack with PostgreSQL passes the E2E suite and a restart check) |
| Backups | — | pg_dump / PGlite copy / in-app export | ✅ documented |
| SSO (OIDC) | Enterprise | `services/oidc.ts`, any OpenID Connect provider | ✅ (tests + E2E against a local OpenID provider) |
