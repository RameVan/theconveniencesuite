# Formula language

Formulas compute a value for each database record. They are parsed into a syntax tree, type
checked when you save them, and evaluated by an interpreter — never with `eval`. Evaluation has
a step budget, and text and list results have size caps, so a formula cannot hang the server.

## Grammar

```
expression  := ternary
ternary     := or ( "?" expression ":" expression )?
or          := and ( ("or" | "||") and )*
and         := not ( ("and" | "&&") not )*
not         := ("not" | "!") not | comparison
comparison  := additive ( ("==" | "!=" | "=" | "<" | "<=" | ">" | ">=") additive )?
additive    := multiplicative ( ("+" | "-") multiplicative )*
multiplicative := unary ( ("*" | "/" | "%") unary )*
unary       := "-" unary | power
power       := postfix ( "^" unary )?            // right associative
postfix     := primary ( "." name "(" args? ")" )*   // x.f(a) is sugar for f(x, a)
primary     := number | string | true | false
             | prop("Property name")
             | name "(" args? ")"
             | "(" expression ")"
             | "[" args? "]"                      // list literal
             | name                               // let-bound variable, or current/index in lambdas
```

Strings use `"…"` or `'…'` with `\n`, `\t`, `\"` escapes. Comments: `/* … */` and `// …`.

## Types

`number`, `text`, `boolean`, `date` (with optional end and time), `list`, and *empty*.

| Property type | Formula type |
|---|---|
| Number, ID without prefix | number |
| Checkbox | boolean |
| Date, Created/Last edited time | date |
| Multi-select, Person, Relation, Files | list (of names / titles) |
| Select, Status, Text, URL, Email, Phone, Title, ID with prefix | text |
| Rollup, Formula | the type of their result |

`+` adds numbers, joins text (when either side is text) and concatenates lists. Comparisons need
matching types. Empty values propagate: `empty + empty` is empty; `5 > empty` is false.

## Functions

| Group | Functions |
|---|---|
| Logic | `if(c, a, b)`, `ifs(c1, v1, c2, v2, …, else)`, `and(…)`, `or(…)`, `not(x)`, `empty(x)`, `equal(a, b)`, `let(name, value, expr)` |
| Math | `abs`, `ceil`, `floor`, `round(n, digits?)`, `sqrt`, `cbrt`, `exp`, `ln`, `log10`, `log2`, `pow`, `mod`, `sign`, `pi()`, `e()`, `min(…)`, `max(…)`, `sum(…)`, `mean(…)`/`average(…)`, `median(…)` (lists are flattened) |
| Text | `concat(…)`, `length`, `lower`, `upper`, `trim`, `contains`, `startsWith`, `endsWith`, `indexOf`, `replace`, `replaceAll`, `substring`, `slice`, `split`, `join`, `repeat`, `padStart`, `padEnd`, `format`, `toNumber` |
| Dates | `now()`, `today()`, `dateAdd(d, n, unit)`, `dateSubtract(d, n, unit)`, `dateBetween(a, b, unit)`, `dateStart`, `dateEnd`, `dateRange(a, b)`, `parseDate(text)`, `formatDate(d, "YYYY-MM-DD")`, `timestamp`, `fromTimestamp`, `year`, `month`, `date`, `weekday`, `hour`, `minute`, `week` |
| Lists | `at(list, i)`, `first`, `last`, `slice`, `sort`, `reverse`, `unique`, `includes`, `flat`, `count`, `map(list, expr)`, `filter(list, cond)`, `find`, `findIndex`, `some`, `every` |
| Record | `id()` |

Date units: `years`, `quarters`, `months`, `weeks`, `days`, `hours`, `minutes`, `seconds`,
`milliseconds`. `formatDate` tokens: `YYYY YY MMMM MMM MM M DD D dddd ddd HH H hh h mm ss A`.
Dates are evaluated in UTC.

Inside `map`, `filter`, `find`, `findIndex`, `some` and `every`, `current` is the item and
`index` its position.

## Examples

```
prop("Price") * prop("Quantity")
if(prop("Due") < today() and prop("Status") != "Done", "⚠ Overdue", "")
dateBetween(prop("End"), prop("Start"), "days") + 1
join(map(prop("Tags"), upper(current)), ", ")
let(total, sum(prop("Hours")), round(total / 8, 1)) + " days"
```

## Dependencies and cycles

Formulas may read other formulas and rollups. When a formula is saved, references to unknown
properties and cycles between formulas of the same database (`A → B → A`) are rejected with an
error naming the path. Cycles that run through relations to other databases are detected while
the values are computed, and appear as an error value in that cell; they never hang. Renaming
a property rewrites the `prop("…")` references in the database's formulas.
