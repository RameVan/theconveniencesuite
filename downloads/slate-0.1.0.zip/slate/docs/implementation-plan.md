# Implementation plan

Each milestone ends with tests, a manual check in the browser, docs updates and a commit.

## Milestone 1 — Foundation
- Next.js 16 + TypeScript + Tailwind 4 scaffold, ESLint, Vitest.
- Drizzle schema + generated SQL migrations; pg / PGlite connection switch; migration runner.
- Auth: signup (first user becomes instance admin), login, logout, sessions, API tokens.
- Workspaces + memberships; page CRUD with real hierarchy; sidebar tree.
- Dockerfile + docker-compose (PostgreSQL 17 + app).

## Milestone 2 — Editor
- Block model (top-level block rows), save/load with validation and versioning.
- Tiptap editor: StarterKit, task lists, code highlighting, colors/highlight, tables, images,
  custom nodes (callout, toggle, equation, bookmark, embed, file, TOC, breadcrumb, child page,
  database view), slash menu, markdown shortcuts, block drag handle, bubble toolbar.
- Autosave with status indicator; page icon & cover.

## Milestone 3 — Databases
- Property schema CRUD for all property types; typed validation; unique IDs.
- Records as pages; table view with inline editing, column resize/reorder.
- Filter (AND/OR groups), sort, group, aggregations, search within a database.
- Board, list, gallery, calendar, timeline, chart views; linked views.
- Relations (two-way), rollups, formula engine.

## Milestone 4 — Product completeness
- Global search (Postgres FTS) with permission filtering; command palette.
- Templates (page, record, starter workspace); duplicate page/database.
- Attachments (local + S3), unreferenced-file cleanup.
- Trash & restore; version history & restore.
- Import/export: Markdown, HTML, JSON (full fidelity), CSV, workspace ZIP backup.

## Milestone 5 — Collaboration & hardening
- Invitations, member roles, page sharing, public links.
- Optimistic concurrency + conflict copies.
- Security tests (IDOR, private pages, search leakage), rate limits.
- Scale tests (hundreds of databases, thousands of records, deep nesting).
- README, deployment, backup/restore docs.

## Milestone 6 — Realtime (next)
- Yjs document per page, `y-prosemirror` binding, Hocuspocus WebSocket server with the same
  session auth, persistence of Yjs updates into the block table, presence cursors.
