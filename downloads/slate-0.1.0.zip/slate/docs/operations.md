# Operations

## Deployment options

| Setup | When | Notes |
|---|---|---|
| `npm start` with embedded PGlite | Personal use, small teams on one machine | Zero dependencies. One process per `DATA_DIR`. |
| Docker Compose (PostgreSQL 17) | Teams, servers | `docker compose up -d`. Data in the `pgdata` and `uploads` volumes. |
| Several app instances + PostgreSQL + S3 | Larger installations | Put a load balancer in front. Set `RATE_LIMIT_STORE=database` so all instances share rate limits (otherwise each counts on its own). Realtime documents are held per instance, so route all WebSocket connections for a page to one instance (sticky sessions), or run a single realtime instance. |

Always serve Slate over HTTPS outside a trusted network. Behind a reverse proxy, set
`TRUST_PROXY=true` so client IPs (rate limiting) and `X-Forwarded-Host` (CSRF origin check) are honoured.

### Ports

| Port | Purpose | Variable |
|---|---|---|
| 3000 | Web app and REST API | `PORT` |
| 3001 | Realtime co-editing (WebSocket, Yjs/Hocuspocus) | `COLLAB_PORT` (`REALTIME=false` disables it) |

Browsers connect to `ws(s)://<same host>:3001` by default. Behind a reverse proxy, route a path to
port 3001 and set `COLLAB_PUBLIC_URL` to it. If the realtime server cannot be reached, editors fall
back to versioned REST saves automatically (after a few seconds) and keep retrying in the
background (up to once a minute); they switch to live editing as soon as the server is reachable.

### Example: Caddy

```
slate.example.com {
  handle_path /collab* {
    reverse_proxy localhost:3001
  }
  reverse_proxy localhost:3000
  request_body {
    max_size 600MB
  }
}
```

with `COLLAB_PUBLIC_URL=wss://slate.example.com/collab`, `TRUST_PROXY=true`, `SECURE_COOKIES=true`.
The realtime server checks the WebSocket `Origin`: the page's host name must match the `Host`
header (or appear in `COLLAB_ALLOWED_ORIGINS`).

## Reaching Slate from other devices (Docker inside WSL 2)

How a phone on the same network reaches Docker inside WSL 2 depends on WSL's networking mode
(`wsl -- wslinfo --networking-mode`). Run the commands once in an **administrator** PowerShell;
the examples use ports 3080/3081.

**Mirrored mode** (`networkingMode=mirrored` in `%UserProfile%\.wslconfig`): WSL's ports are the
host's ports, but the Hyper-V firewall for WSL blocks incoming connections by default. Allow Slate's:

```powershell
New-NetFirewallHyperVRule -Name Slate -DisplayName Slate -Direction Inbound -VMCreatorId '{40E0AC32-46A5-438A-A0B2-2B479E8F2E90}' -Protocol TCP -LocalPorts 3080,3081 -Action Allow
```

(Remove with `Remove-NetFirewallHyperVRule -Name Slate`.)

**NAT mode** (the default): ports are only forwarded to the Windows host's `localhost`, so forward
them and open the Windows firewall:

```powershell
netsh interface portproxy add v4tov4 listenaddress=0.0.0.0 listenport=3080 connectaddress=127.0.0.1 connectport=3080
netsh interface portproxy add v4tov4 listenaddress=0.0.0.0 listenport=3081 connectaddress=127.0.0.1 connectport=3081
New-NetFirewallRule -DisplayName "Slate" -Direction Inbound -Protocol TCP -LocalPort 3080,3081 -Action Allow -Profile Private
```

(Remove with `netsh interface portproxy delete v4tov4 listenaddress=0.0.0.0 listenport=3080` and 3081,
and `Remove-NetFirewallRule -DisplayName Slate`.)

Then open `http://<computer's network address>:3080` on the phone, and set `APP_URL` to that address
so links in emails work there too.

### Starting automatically on Windows

Inside WSL, systemd starts Docker and Compose restarts the containers (`restart: unless-stopped`).
WSL itself starts only when something uses it, and stops a distribution that has been idle for a
while. A scheduled task that runs at sign-in starts it and keeps it running:

```powershell
$user = "$env:USERDOMAIN$env:USERNAME"
$action = New-ScheduledTaskAction -Execute "C:WindowsSystem32conhost.exe" -Argument "--headless C:WindowsSystem32wsl.exe -d Ubuntu -u root -- sleep infinity"
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $user
$settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)
$principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
Register-ScheduledTask -TaskName "Slate (keep WSL running)" -Action $action -Trigger $trigger -Settings $settings -Principal $principal
```

Slate is then up a few seconds after you sign in (not before: starting at boot without a signed-in
user would need the task to store your Windows password). Remove it with
`Unregister-ScheduledTask -TaskName "Slate (keep WSL running)"`.

## Email notifications

Optional. Set `SMTP_URL` (e.g. `smtps://user:password@smtp.example.com:465`) and `SMTP_FROM`; set
`APP_URL` so emails link to the page or comment thread. People are emailed when they are mentioned
or someone replies in a thread they are in — only for pages they can view — and can turn emails off
in Settings → My account. Emails are sent in the background; if the mail server is unreachable the
in-app Inbox still gets the notification and the log records only the error code.

Forgotten passwords use the same mail settings: "Forgot password?" on the login page emails a
reset link. It needs both `SMTP_URL` and `APP_URL`; without them the page says to ask the
administrator.

## Single sign-on (OpenID Connect)

Optional and available to everyone (no plan or tier). Set `OIDC_ISSUER`, `OIDC_CLIENT_ID` and, for
confidential clients, `OIDC_CLIENT_SECRET`; set `APP_URL` and register
`<APP_URL>/api/auth/oidc/callback` as the redirect URI. The login page then shows
"Continue with <OIDC_DISPLAY_NAME>".

* Sign-in uses the authorization code flow with PKCE, state and nonce. Email and profile claims are
  read from the ID token or, if absent there, from the UserInfo endpoint.
* Accounts are matched by issuer + subject. On a first sign-in, an existing Slate account is
  linked only when the provider marks the email as **verified**; otherwise a new account is
  created if `OIDC_ALLOW_SIGNUP` (default: `ALLOW_SIGNUP`) allows it. New accounts get their own
  workspace, like sign-up; to join a team, an admin invites the email as usual.
* Accounts created through SSO have no password (password login is refused). Password sign-in
  stays available for everyone else.
* Plain-HTTP issuers are accepted only on `localhost` / `127.0.0.1` (for testing).

## Migrations

Migrations live in `drizzle/` and are applied automatically when the server starts (and by
`npm run db:migrate`). To change the schema:

1. Edit `src/server/db/schema.ts`.
2. `npm run db:generate -- --name describe_change`
3. Review the generated SQL in `drizzle/`, commit it.

Migrations are forward-only. Back up before upgrading.

## Backups

### PostgreSQL

```bash
# backup (custom format, compressed)
docker compose exec -T db pg_dump -U slate -Fc slate > slate-$(date +%F).dump
docker run --rm -v slate_uploads:/data -v "$PWD":/backup alpine tar czf /backup/uploads-$(date +%F).tgz -C /data uploads

# restore into an empty database
docker compose stop app
docker compose exec -T db dropdb -U slate slate
docker compose exec -T db createdb -U slate -E UTF8 -T template0 slate
docker compose exec -T db pg_restore -U slate -d slate < slate-2026-10-19.dump
docker run --rm -v slate_uploads:/data -v "$PWD":/backup alpine sh -c "cd /data && tar xzf /backup/uploads-2026-10-19.tgz"
docker compose start app
```

With `STORAGE_DRIVER=s3`, back up the bucket with your provider's tools (versioning recommended).

### Embedded PGlite

Stop Slate, then copy the whole `DATA_DIR` (it contains `pglite/` and `uploads/`). Restore by
copying it back while Slate is stopped.

### Application-level export

Settings → Import & export → *Export all content* (or `GET /api/workspaces/:id/export`) creates a
ZIP with `slate.json` (full fidelity: pages, blocks, databases, properties, views, relations,
files), Markdown, CSV and `loss-report.md`. Import it into any Slate instance; everything gets new
IDs, so importing never overwrites existing data. Members, permissions, comments and page
history are not part of this export — use a database backup for a complete restore.

## Infrastructure safeguards

These protect the server. They apply equally to everyone, are not tied to any plan, and
never delete data: when one is hit the request fails with a clear error.

| Variable | Default | Effect when exceeded |
|---|---|---|
| `MAX_UPLOAD_BYTES` | 104857600 | Upload rejected with 413 |
| `MAX_JSON_BODY_BYTES` | 20971520 | Request rejected with 413 (very large single-page saves) |
| `MAX_IMPORT_BYTES` | 524288000 | Import rejected with 413 |
| `RATE_LIMIT_PER_MINUTE` | 1200 | 429 for that client IP for the rest of the minute |
| `AUTH_RATE_LIMIT_PER_MINUTE` | 20 | 429 on login/sign-up/password endpoints |
| `DB_STATEMENT_TIMEOUT_MS` | 30000 | Query cancelled; the transaction rolls back |
| `DB_POOL_MAX` | 10 | Requests wait for a connection |
| `STORAGE_WARN_BYTES` | 0 (off) | Warning shown in Settings → Storage; uploads continue |

Formula evaluation also has fixed internal safety limits (step budget, maximum text/list size,
nesting depth) that stop pathological formulas.

## Housekeeping

* **Trash retention:** `TRASH_RETENTION_DAYS=N` purges trash older than N days every 6 hours
  (0 = keep until deleted manually).
* **Unreferenced files:** `npm run files:cleanup` deletes uploads no page, property, icon, cover
  or page-history version references and that are older than 24 hours. Set
  `FILE_CLEANUP_ON_SCHEDULE=true` to also run it every 6 hours.

## Performance notes

Measured with the embedded database on a laptop (`tests/scale.test.ts`):
200 databases created in ~0.5 s; 5,000-record CSV import in ~0.5 s; a filter + sort + group +
formula query over 5,001 records in ~0.13 s; a 3,000-block page saved, loaded and searched in ~1 s;
120 levels of nesting. Queries load one database's records into memory to evaluate formulas and
rollups; databases with hundreds of thousands of records work but get slower — see
`docs/progress.md` for the planned SQL push-down.

## Monitoring

`GET /api/health` returns `{"ok":true}` when the database is reachable (used by the Docker
health check). Request logs contain method, path, status and duration only.
