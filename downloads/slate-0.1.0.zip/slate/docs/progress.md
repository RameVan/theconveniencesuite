# Progress

Last updated: 2026-10-19 (Milestone 8 in progress — comments, mentions, inbox; large databases).

Working agreement: `CLAUDE.md`. Requirements and milestone exit criteria: `docs/spec.md`.
(Both were created on 2026-10-19 from the original project brief and `docs/architecture.md`,
because they did not exist when autonomous work started — default noted here.)

## Current milestone: M8 Scale & polish — ✅ exit criteria met (partials listed below)
Exit criteria were not specified for M8; defaults written into `docs/spec.md` (2026-10-19).

| M8 item | Status | Evidence |
|---|---|---|
| Inline comment threads, @-mentions, inbox | ✅ | `tests/comments.test.ts` (9 + 1), `tests/collab.test.ts` (live mentions), `e2e/comments.spec.ts` |
| SQL push-down + virtualised rows | ✅ (calendars fetch the visible weeks, timelines page, charts load group totals) | `tests/query-pushdown.test.ts`, `scripts/bench-db.ts`, E2E "large tables load page by page" |
| Per-block linked view settings | ✅ | `tests/linked-views.test.ts`, E2E "a linked view has its own views" | |
| Notion export importer | ✅ | `tests/import-notion.test.ts` (export built in Notion's file layout), E2E "import a Notion export" | |
| Optional OIDC sign-in | ✅ | `tests/oidc.test.ts` and `e2e/sso.spec.ts` against a real OpenID provider (`oidc-provider`) on localhost; migration `0004` |
| Shared rate-limit store | ✅ | `RATE_LIMIT_STORE=database` (atomic upsert per request, database clock); `tests/rate-limit.test.ts`; migration `0003` | |

## Previous milestone: M7 Automated end-to-end tests — ✅ exit criteria met

| Exit criterion (`docs/spec.md`) | Evidence |
|---|---|
| Playwright suite for the main workflows | `e2e/`: sign-up, starter content, new page + typing right after the title, Markdown shortcuts, slash menu, reload persistence; search → open; trash → restore; public link read-only for an anonymous visitor (private API 401); database cell edit + rename |
| Drag interactions | Sidebar nest + move to top level; block handle (real mouse drag, realtime mode); board card between columns; calendar day to day; table column resize, column reorder, row reorder; timeline bar move + stretch |
| Realtime in two browsers | `e2e/realtime.spec.ts`: invited editor, both "Live", presence both ways, typing both ways, remote caret label, persisted once in order |
| Runs against the production build | `scripts/e2e-server.mjs` starts `.next/standalone/server.js` on 3200/3201 with a temporary data dir |
| tests / lint / typecheck / build green | see "Verification" |

## Verification (commands run for this milestone)

```bash
# Latest full run (end of M8):
npx tsc --noEmit                      # clean
npx eslint .                          # clean
npx vitest run                        # 19 files: 129 passed, 1 skipped (opt-in real-PG suite)
npm run test:pg                       # real PostgreSQL: 1 passed (applies migration 0002)
npx next build                        # success
npx playwright test                   # 25 passed (installed Chrome; includes SSO against a local OpenID provider)
npx playwright test e2e/comments.spec.ts --repeat-each=3   # 3 passed
# M7 runs:
npx playwright test e2e/realtime.spec.ts --repeat-each=8   # 8 passed (stability check)
npx playwright test e2e/database.spec.ts --repeat-each=3   # 6 passed
```

## Done
* M1–M5 (see `plan.md` and `docs/feature-matrix.md`): foundation, editor, databases, product
  completeness, collaboration & hardening.
* **M6 realtime co-editing**: Yjs/Hocuspocus server started with the app on `COLLAB_PORT` (3001),
  session-cookie auth, per-connection `requirePage`, read-only viewers, Origin check, rate limit;
  shared editor schema; `page_ydocs` persistence with version tracking; debounced persistence to
  blocks through `saveContent` (revisions, search, export unchanged); REST writes pushed into live
  documents; Tiptap Collaboration + live carets + presence avatars; automatic REST fallback.
* **M7 end-to-end suite** (`e2e/*.spec.ts`, `playwright.config.ts`, `scripts/e2e-server.mjs`):
  `npm run build && npm run test:e2e`. CI workflow `.github/workflows/ci.yml` runs typecheck, lint,
  unit/integration, real-PG, build and E2E (bundled Chromium).
* **Editor: provisional editor until realtime is in sync.** The page opens with a REST editor so
  typing is never lost while the WebSocket connects; it switches to the live document once the
  user pauses and both documents are equal (unsaved REST edits are saved first).
* **Editor: block drag moves by block id** (`block-drag.ts`) in one transaction, so a drag can't
  delete the wrong block when remote edits shift positions mid-drag.

## Done in M8 so far
* **Comments**: threads with replies, resolve/reopen, delete (thread deletes replies); inline threads
  anchored with a `comment` mark (overlapping allowed) — select text → *Comment* in the toolbar,
  highlighted until resolved, click the highlight to open the thread. Viewers comment on the page
  (anchors need edit access since they change the document).
* **@-mentions of people** in pages (`@` menu lists members, then pages) and in comments
  (`@Name` autocomplete, stored as `@[Name](user:id)`).
* **Inbox** in the sidebar with unread count: mentions in pages and comments, replies to threads
  you are in; opens the page at the block or thread (`?thread=`). A mention notifies only people
  who can view the page; the list re-checks access, so revoked access hides old notifications.
  Re-saves, undo and restores don't notify twice (one notification per user and block).
* Migration `0002` (additive: new nullable comment columns, `notifications` table).

### Large databases (50,000 records, PostgreSQL, `npx tsx scripts/bench-db.ts 50000`)
| Query | Before | Now (100-row pages) |
|---|---|---|
| Default view | ~1 s, 31 MB JSON | 65–75 ms, 0.1 MB (any page, e.g. offset 40,000: ~100 ms) |
| Filter + sort on stored properties | 0.3–1.6 s | ~100 ms (SQL) |
| Title sort / search / grouping | ~1 s, up to 33 MB | first page 0.5–0.8 s, next pages 70–110 ms (cached evaluation) |

* Query API pages rows (`offset`/`limit`, `groupLimit`/`groupKey`); totals, group counts and
  aggregations still cover every match. Without `limit` it returns all rows (API compatibility).
* SQL push-down only where semantics are identical to the in-memory engine (checkbox,
  select/status, number filters and sorts, manual order); text sorts, search, grouping,
  aggregations, dates and computed properties run in memory. A differential test compares both
  engines on 250 random configs with malformed stored values; it is mutation-checked.
* In-memory results are cached per (database, user, view config, search, properties, day) and
  validated by a fingerprint of the records; only used when every record shares the database's
  access (re-checked on each request), so a cached order never outlives an access change.
* Client: tables, lists, galleries and boards load 100 rows at a time (automatically on scroll,
  or "Load more"); boards and grouped views load 50 per group; long tables render only the rows
  near the viewport. Footer counts show all matches.
* Calendars fetch only records that can appear in the visible weeks (start date from 62 days —
  the longest span drawn — before the grid to its end), plus a one-row count of undated records.
* Date filters run in SQL too (PostgreSQL 16+), when every stored value of that property is
  canonical ("YYYY-MM-DD" or a UTC ISO timestamp, as Slate writes them); otherwise in memory.
  Differential test with 200 random date conditions; 50k records: ~155 ms per page. Date sorts stay
  in memory.
* Timelines page their records like tables; charts request one row per group (counts and
  aggregations still cover every record).
* Table row drag now moves one record (`{ id, beforeId }`): with paged loading the client no
  longer knows the full order, and the old endpoint renumbered only the ids it was sent.

### Linked views
* A new "Linked view of database" block starts with copies of the database's views, stored in the
  block (`views` attr). Adding, renaming, re-laying-out, filtering or sorting them changes only
  that block — it needs edit access to the page, not to the database. Signed-in queries send the
  view's configuration; public pages query through the block (`block: { pageId, blockId }`), and
  the server reads the views from the block after checking the page and database are in the share.
* Blocks created before this change keep using the database's views (no migration needed).
* "Export view as CSV" is offered for database views only.

### Notion export import
* Settings → Import accepts Notion's "Markdown & CSV" ZIP (detected by the 32-hex ids in file
  names, or a ZIP of ZIPs). Pages keep their hierarchy; each database becomes a Slate database under
  its parent page (using the `_all.csv` when present), and record pages fill the matching rows'
  content (property lines under the title are dropped only when they name a CSV column). Links
  between exported files point at the imported pages; images are uploaded. Nothing existing is
  touched. Default noted: rows are matched to record pages by title, in order; unmatched record
  pages are imported as ordinary pages with a warning.
* Not covered: Notion's HTML export, relations/rollups between exported databases (they arrive as
  text columns), comments, and page icons/covers (not in the Markdown export). Verified only against
  exports built to Notion's documented layout in tests, not a real Notion workspace (no account used).

### Single sign-on
* `OIDC_ISSUER` / `OIDC_CLIENT_ID` / `OIDC_CLIENT_SECRET` enable "Continue with …" on the login
  page (authorization code + PKCE via `openid-client`). Identities are keyed by issuer + subject;
  existing accounts link only through a verified email; new accounts follow `OIDC_ALLOW_SIGNUP`.
  Details: `docs/operations.md`. Not tested against a hosted provider (no credentials used);
  tested against `oidc-provider`, a certified OpenID Provider implementation, running locally.
* Found while testing: redirect URLs were built from Next's reported URL, which says
  `localhost` in standalone mode even when the browser used another host. Now from `APP_URL`,
  else the `Host` header (forwarded headers only with `TRUST_PROXY`); unit-tested.
* Accounts created through SSO can set a password in Settings (from the app, not with an API token)
  and can delete their account by typing their email.

### Docker Compose verification (2026-10-19)
* Docker Engine 29.1.3 + Compose 2.40.3 installed inside the WSL 2 Ubuntu 26.04 distro from Ubuntu's
  archive (`docker.io`, `docker-compose-v2`; no Docker Desktop, no Windows admin changes).
* `docker compose build` builds the image; `docker compose up -d` starts PostgreSQL 17 + Slate,
  healthy, migrations applied on PostgreSQL, realtime server up.
* `npx playwright test -c playwright.docker.config.ts` against the stack on ports 3300/3301:
  14 passed (all specs except SSO, which needs an OpenID provider configured for the stack).
* Restart check: content created over the API was intact after `docker compose restart`.
* Fixed: with the realtime port published on another host port (`SLATE_COLLAB_PORT`), browsers
  still dialled 3001 and silently fell back to REST saves. Compose now passes the published port
  as `COLLAB_PUBLIC_PORT`, which the app advertises; verified by the realtime specs over 3301.
* Environment note: WSL shuts the distro (and the containers) down when no WSL process is
  attached; documented in the README.

### Email notifications (2026-10-20)
* `SMTP_URL` / `SMTP_FROM` enable emails for mentions and replies (same recipients as the Inbox,
  so only people who can view the page), with a link when `APP_URL` is set; per-user switch in
  Settings → My account (migration `0005`). Tested against a real SMTP server running locally
  (`smtp-server`): delivery, link and text, opt-out, no email without access or without SMTP, and
  an unreachable server (in-app notification kept, no content in the log). Delivery through your own
  mail provider needs its SMTP credentials in `.env`.

### Requested 2026-10-20
* **Block handle**: it disappeared while the pointer crossed the margin towards it, so blocks could
  neither be moved nor changed. Fixed (pointer tracked on the page). "Turn into" now converts every
  line of a block (a 3-item to-do list becomes three headings), and right-clicking a block opens
  the block menu (Shift/Ctrl+right-click keeps the browser menu).
* **Phones / touch screens**: the block handle needs hover, so on touch screens an options button
  follows the block with the cursor (right of the text) and opens the block menu. The menu has
  **Move up / Move down** (also Ctrl+Shift+↑/↓ on a keyboard), since touch can't drag blocks. The
  formatting toolbar sits below a selection on phones (the system copy/paste bar is above) and
  scrolls sideways if it doesn't fit. `e2e/iphone.spec.ts`.
* **Show password** button on every password field (login, sign-up, settings, reset).
* **Forgot password**: emailed reset link (see `docs/security.md`); migration `0006`.
* **iPhone**: installable (manifest, icons, Home Screen tags); fields are 16px on touch screens so
  iPhone Safari doesn't zoom in; shortcut hints hidden on touch. `e2e/iphone.spec.ts`.
* Found while testing: typing fast right after picking an @-mention in a comment could scramble
  the text (cursor moved a frame late). Fixed. And the E2E server ran with the project's real
  `.env` (Next copies it into the build), so tests may have tried to email fictitious
  example.com addresses through the real mail server; the E2E server now strips it.

### Online checks (2026-10-20)
* `npm run test:online` (opt-in, needs internet): link previews of example.com, GitHub (redirect,
  Open Graph title/description/image) and YouTube; private addresses refused; YouTube and Vimeo
  embeds load their players; a pasted bookmark shows the page title. Also checked by eye in the
  browser.
* Fixed: in REST fallback mode, an idle page never picked up changes saved elsewhere: its 15 s
  check restarted on every re-render (the parent passed a new callback each time). E2E
  `e2e/fallback.spec.ts`, which also checks that typing then closing the tab at once still saves.
* Fixed: YouTube links previewed as just "www.youtube.com". Its title sits ~770 KB into the page,
  past the 512 KB read limit; previews now read up to 2 MB (still stopping at </head>).

### Auto-start (2026-10-20)
* Scheduled task "Slate (keep WSL running)" starts WSL at sign-in and keeps it running; Docker
  brings Slate back. Tested: after `wsl --shutdown`, running the task had Slate healthy in ~8 s and
  it stayed up (checked every 10 s for 90 s, LAN address included). See `docs/operations.md`.

### Accessibility pass (2026-10-20)
* `e2e/accessibility.spec.ts`: axe-core (WCAG 2.1 A/AA rules) on sign-in, sign-up, a page with
  the sidebar, Settings, and a database in table and board views, in light and dark mode; plus a
  keyboard test (focus stays in dialogs, Escape closes and returns focus). Any violation fails.
* Fixed what it found: grey text below 4.5:1 contrast (muted/faint colours darkened, lighter in
  dark mode); white text on the blue and red buttons (light blue/red now darker, dark mode uses
  dark text); the page tree held a non-item button; the database table's ARIA structure (selection
  column and "Add a property" were outside cells; "New", "Load more" and totals now sit after the
  table); empty editable cells had no accessible name (now "Status: empty"; Space opens them
  too); the profile name and API token fields had no label.
* Fixed: a dialog's focus handling restarted whenever its parent re-rendered with a new close
  callback, which could pull focus back to the first field while typing.
* Not covered by the scan: the editor's slash menu and block menus, comments, and screen-reader
  testing by a person.

### Reordering (2026-10-20)
* Database view tabs: drag a tab, or "Move left/right" in its menu.
* Favourites: drag within the Favorites section, or "Move up/down" in the row's menu (touch and
  keyboard). Stored per user (`PATCH /api/pages/:id/favorite { beforeId }`); only your own
  favourites can be moved. The row menu button is now labelled and shows on keyboard focus and on
  touch screens. Unit test in `tests/core.test.ts`; E2E in `e2e/workspace.spec.ts`.

## Defects found and fixed during M8
* **Every page open saved the page** (new version, no change): Tiptap's `setEditable()` emits an
  "update" by default, which the editor treated as an edit. Effect: extra versions and spurious
  409 conflicts for anyone else editing the page over REST. Fixed (`setEditable(x, false)`);
  E2E regression test "opening a page does not save it".
* **Realtime stores of unchanged content created new versions**: the live document was compared
  with stored blocks as JSON strings, but PostgreSQL `jsonb` reorders keys and Yjs adds empty
  mark attrs, so they never matched. Now compared in validated, key-sorted form; block writes skip
  unchanged blocks the same way (they were rewritten on every save). Regression tests in
  `tests/collab.test.ts` and `tests/comments.test.ts` (verified to fail without the fix).
* **Images and links in Markdown ZIP imports were lost**: relative references went through the
  URL sanitiser before the importer could resolve them (images ended up empty, `page.md` links
  became `https://page.md`). Archive imports now keep relative references, resolve them, and
  drop only those pointing outside the archive. Regression test in `tests/import-notion.test.ts`.
* **Editor broken over plain HTTP on a LAN address**: `crypto.randomUUID` (block ids, select
  options, filters) only exists in secure contexts. Replaced by `src/lib/uid.ts` (falls back to
  `getRandomValues`); `tests/uid.test.ts`.

## Defects found and fixed during M7
* **Typing lost while the realtime connection was opening** (keystrokes before sync went to an
  editor that was not mounted yet) → provisional REST editor + guarded swap (see Done).
* **Block drag in realtime mode could delete content** (ProseMirror's native move deleted whatever
  was selected at drop time after remote re-mapping) → id-based move; drops onto node views
  (callouts) handled in the capture phase.
* **Empty table cells were nearly impossible to click** (the clickable area collapsed to 0 px
  height when the cell had no value) → minimum height on editable cells. Found by the E2E suite.
* Test-only: Playwright can press keys before ProseMirror has handled the browser's async
  `selectionchange` after a click; the realtime spec waits for the caret (`caretAtEnd`) instead
  of sleeping. Not reproducible by a human (needs a key press within milliseconds of a click).

## Done after M7
* **Realtime retry from fallback mode** (`use-collab.ts`): after a failed connection the page keeps
  saving over REST and retries in the background (5 s, 10 s, 20 s … max 60 s, and at once on the
  browser's `online` event); when an attempt syncs, the existing guarded swap moves the page to
  live editing without a reload. Access denials are not retried. E2E: `e2e/realtime.spec.ts`
  (realtime socket blocked with `routeWebSocket`, edit saved over REST, unblocked → "Live", later
  edits persist). Verified: tsc, eslint, vitest (85 passed), `npx playwright test` (8 passed),
  the new test 3× in a row.

## Defects found and fixed during M6
* **Duplicated text after a server restart** (found in the browser): a client that kept its Yjs
  document across a restart merged its copy with a document the new process rebuilt from blocks.
  Fix: the Yjs history is persisted as soon as it is built or updated (on load and after REST
  pushes), so it is never rebuilt while clients may hold it. Regression tests:
  `tests/collab-restart.test.ts` (edit + REST push + restart; view-only session + restart).
* Test helper produced invalid emails for names with spaces (fixed in the helper; validation unchanged).

## Partial
* **Mixed clients**: a client in REST fallback mode editing the same page as realtime clients
  gets a 409 on save (its version is kept as a "conflict" revision, nothing is lost). It does not
  merge live while realtime is unreachable; it retries in the background and switches to live
  editing as soon as it connects.
* **Multi-instance realtime**: documents are held in the process that serves the WebSocket;
  several instances need sticky routing per page (documented in `docs/operations.md`).
* **Block drag across to-do lists under Playwright**: Playwright's `mouse.move` hangs on such a
  path, so the spec dispatches drag events there. Checked by hand on 2026-10-20 in the app's browser
  with real mouse drags in realtime mode (a paragraph up across a 3-item to-do list, a heading down
  across it): order correct on screen and on the server, no content lost.
* **Public share pages** show mention chips as plain "@Name" (no link to the person).
* **CI workflow** has not run yet (no GitHub remote here); the same commands pass locally.
* **Older linked blocks** (created before per-block views) show the database's views until someone picks "Use separate views here" in the view menu.
* **Rate limiting** is per process unless `RATE_LIMIT_STORE=database` (one extra small query per request).
* **Date sorts and text sorts** run in memory (cached between pages).
* **Public share pages** query databases without paging.

## Next (in order)
1. CI on GitHub (needs a GitHub repository; the workflow is ready).
2. Accessibility of the editor's slash and block menus and of comments (not in the automated scan yet).

## Blocked
* None. (Docker was installed on 2026-10-19 — see "Docker Compose verification".)

## Known defects
* Once in an E2E run right after a build, /signup waited over 90 s for /api/auth/me; not reproduced in the following runs.
* (Dev-only data: the "Focus test" page in the local database still contains
  "Body textBody text" from before the duplication fix; it is test data and was left as evidence.)
