# Research notes

Date: 2026-10-19. Sources: the public `makenotion` GitHub organization (inspected with `gh`), the
Notion public API type definitions in `notion-sdk-js`, and the bundled documentation of the
frameworks used (Next.js 16 docs ship inside `node_modules/next/dist/docs`).

## 1. What the `makenotion` organization contains

| Repository | License | What it is | Reusable for Slate? |
|---|---|---|---|
| `notion-sdk-js` | MIT | Typed HTTP client for the Notion public API (`src/api-endpoints/*.ts` holds request/response types for pages, blocks, databases, data sources, views, search, comments, file uploads). | Reference only. Its type definitions are a useful inventory of property types, filter operators and block types. It contains no editor, storage, or server. |
| `notion-cookbook` | MIT | Example scripts, "Workers" sync templates (GitHub, Linear, …), agent skills. | Reference only. Integration examples that *call* Notion. |
| `notion-mcp-server` | MIT | Self-hosted MCP server that proxies the Notion API (now marked "no longer actively maintained" in favour of the hosted remote MCP). | Reference for designing our own API surface; not reusable as storage or UI. |
| `notion-agents-sdk-js`, `skills`, `notion-skills-github-sync`, `claude-code-notion-plugin`, `cursor-notion-plugin`, `lore` | MIT / none | Agent tooling built on top of the Notion API. | No. |
| `notion-as-code-template`, `notion-sdk-typescript-starter` | MIT / none | Starter templates for API scripts. | No. |
| Forks: `TypeScript`, `typescript-go`, `luxon`, `refinery`, `molecule`, `patch-package`, `vtsls`, `memcache`, Pulumi SDKs, … | Various | Forks of third-party infrastructure. | No. |

**Conclusion:** the organization does **not** contain the source of the Notion application
(editor, database engine, sync engine, permissions, storage). Every repository is either an API
client, an example, agent tooling, or an unrelated fork. Slate is therefore an original,
independent implementation. No code was copied from these repositories; they were used only to
cross-check the vocabulary of property types and filters.

### Property types listed in the public API (`data-sources.ts`)
`title, rich_text, number, select, multi_select, status, date, people, files, checkbox, url,
email, phone_number, formula, relation, rollup, created_time, created_by, last_edited_time,
last_edited_by, unique_id` — Slate implements all of them.

### Filter vocabulary in the public API
Text: `equals, does_not_equal, contains, does_not_contain, starts_with, ends_with, is_empty,
is_not_empty`. Number: comparisons. Date: `before, after, on_or_before, on_or_after, past_week,
next_week, this_week`. Compound filters: `and` / `or` nesting. Slate's filter model mirrors
these semantics with its own JSON shape.

## 2. Hosted Notion vs. public API vs. open source

| Area | Hosted Notion | Public API | Open-source repos |
|---|---|---|---|
| Editor | Proprietary block editor, realtime multiplayer | Read/write blocks, no editor | None |
| Databases | Full engine: views, formulas 2.0, relations, rollups | Query/filter/sort data sources; view metadata | Types only |
| Storage / sync | Proprietary (Postgres shards + caching per public engineering posts) | N/A | None |
| Permissions | Workspace/teamspace/page sharing | Integration capability scopes | None |
| Plan gating | Block limits for multi-member Free plans, 7-day page history on Free, guest caps, file-size caps, analytics, SAML etc. on paid tiers | Rate limited | N/A |

Slate re-implements the hosted product's *user-facing* behaviour on its own storage, with no plan
gating at all.

## 3. Notion user-facing functionality (behavioural reference)

* **Pages** are blocks; any page can nest pages; sidebar shows the tree with Favorites, Shared
  (workspace) and Private sections; Trash keeps deleted pages for recovery.
* **Blocks**: text, headings 1–3, to-do, bulleted/numbered lists, toggle, quote, callout,
  divider, code (with language), image/video/audio/file, bookmark, embed, table, table of
  contents, equation, breadcrumb, child page, linked database. Slash menu (`/`) inserts blocks;
  Markdown shortcuts (`#`, `-`, `1.`, `[]`, `>`, ```` ``` ````) convert blocks; drag handle (`⋮⋮`)
  reorders.
* **Databases** are pages holding a schema plus records; every record is a full page. Views
  (table, board, list, gallery, calendar, timeline, chart) each store their own filter, sort,
  group, visible properties and layout options. Linked views show an existing database
  elsewhere. Relations can be two-way; rollups aggregate across relations; formulas compute values
  with a typed expression language.
* **Search** (`Ctrl/Cmd+K`/`P`) covers titles and content with recent pages first.
* **Sharing** has workspace roles and per-page access with inheritance; "Publish/Share to web"
  produces a public read-only link.
* **Page history** lists snapshots that can be restored.

## 4. Framework research (current docs)

* **Next.js 16.4** (bundled docs): App Router; `params` are Promises in route handlers
  (`ctx.params`); middleware is renamed `proxy`; `cacheComponents` (opt-in) keeps hidden routes
  mounted via `<Activity>`. Slate disables `cacheComponents` because the editor and database views
  hold large client-side state and must unmount predictably; all data comes from dynamic API
  route handlers anyway. `serverExternalPackages` is used for `@electric-sql/pglite` and `pg`.
* **Editor: Tiptap 3 (ProseMirror)**, MIT. Chosen over raw ProseMirror (more boilerplate) and
  BlockNote (MPL-2.0 core, but several features are under a separate business license — the kind
  of feature gate this project avoids). Tiptap 3's open-source packages cover StarterKit, tables,
  task lists, code highlighting (lowlight), placeholder, suggestion (slash menu) and React node
  views. Slate adds its own nodes (callout, toggle, equation, bookmark, embed, TOC, breadcrumb,
  child page, database view) and its own block-ID plugin.
* **Database: PostgreSQL** via **Drizzle ORM 0.45**, which supports both `node-postgres` and
  **PGlite** (Postgres 17 compiled to WASM, Apache-2.0/PostgreSQL license). PGlite lets the app run
  locally and in tests with real Postgres semantics (JSONB, `tsvector`, recursive CTEs,
  transactions) without installing a server; production uses a real PostgreSQL via
  `DATABASE_URL`.
* **Full-text search**: Postgres `to_tsvector('simple', …)` + GIN indexes, with prefix queries
  (`:*`) and an `ILIKE` fallback for substrings; works identically in PGlite.
* **Realtime collaboration**: Yjs + `y-prosemirror` + a WebSocket provider (Hocuspocus or
  y-websocket) is the standard approach for ProseMirror. It requires a long-lived WebSocket server
  next to Next.js. Slate ships optimistic concurrency (versioned saves, conflict detection with
  no-loss conflict copies, background refresh) in v1 and documents Yjs as Milestone 6.
* **Accessibility**: WAI-ARIA patterns for menus (`role="menu"`), dialogs (`role="dialog"`,
  focus return), tree views (`role="tree"`/`treeitem` with `aria-expanded`) and combobox
  (command palette via `cmdk`, which implements the listbox pattern).
