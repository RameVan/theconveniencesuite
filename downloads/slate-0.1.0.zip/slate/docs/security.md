# Security

## Threat model

Slate protects workspace content from:

* **Other users of the same server** — members of other workspaces, workspace members without
  access to a private or restricted page, guests, and anonymous visitors of public links.
* **Web attackers** — cross-site request forgery, cross-site scripting through page content,
  uploaded files or link URLs, server-side request forgery through link previews, brute-force
  login, ID guessing (IDOR).

Slate does **not** protect against someone with access to the server, the database or the
storage bucket: data is stored unencrypted by the application. Use disk/database encryption at
the infrastructure level if you need encryption at rest. Slate makes no end-to-end or
zero-knowledge encryption claims.

## Controls

| Area | Implementation |
|---|---|
| Passwords | scrypt (N=2^15, r=8, p=1, 16-byte salt), constant-time comparison; unknown emails take the same time as wrong passwords |
| Password reset | Emailed single-use link, valid one hour, only its SHA-256 stored; the answer is the same whether or not the account exists; the link is built from `APP_URL` only (never the request's host, which an attacker could forge); using it cancels other links and signs out every session; auth rate limit |
| Sessions | 32-byte random token in an `HttpOnly`, `SameSite=Lax`, `Secure` (production) cookie; only its SHA-256 is stored; sliding expiry; list/revoke in Settings; password change revokes other sessions |
| API tokens | `slt_` + 32 random bytes, stored hashed, revocable |
| CSRF | Cookie-authenticated non-GET requests must carry an `Origin` (or `Sec-Fetch-Site: same-origin`) matching the host |
| Authorization | Enforced in every service function on the server (`src/server/services/permissions.ts`); inaccessible resources return 404 so IDs cannot be probed; search, relation pickers, rollups, breadcrumbs and exports filter by access |
| Input validation | zod schemas on every route; block content checked against an allow-list of node/mark types; JSON body size limits |
| SQL injection | Parameterised queries through Drizzle ORM; raw SQL uses bound parameters only |
| XSS | React escaping; editor schema allow-list; link/src URLs restricted to http(s)/mailto/tel/relative; HTML export escapes all text; KaTeX with `trust: false` |
| Uploaded files | Type detected from content (never trusted from the client); only images, PDF, audio/video and plain text are served inline; everything else is `attachment`; all file responses carry `X-Content-Type-Options: nosniff` and a sandboxing CSP |
| SSRF | Link previews resolve DNS and refuse private, loopback, link-local and multicast addresses on every redirect hop; 5-second timeout; 512 KB read limit |
| Embeds | iframes only for known providers, sandboxed, `referrerpolicy=strict-origin-when-cross-origin` |
| Public links | Random 24-byte tokens, revocable, instance-wide switch `ALLOW_PUBLIC_SHARING`; private sub-pages are never exposed through a parent's link |
| Realtime (WebSocket) | Same session cookie as the app; every connection re-checks page access; viewers are read-only (their updates are rejected by the server); the `Origin` must match the host (or `COLLAB_ALLOWED_ORIGINS`); per-IP connection rate limit; content is validated against the block allow-list before it is written to the database |
| Mentions & notifications | A mention (in a page or comment) notifies only people who can view that page, checked when sending; the inbox re-checks access when listing, so notifications (and their excerpts) disappear when access is revoked; you can only read or mark your own notifications. Comment thread ids are restricted to `[A-Za-z0-9_-]` (they are used in the highlight CSS) |
| Single sign-on (OIDC) | Authorization code + PKCE, state and nonce checked; flow secrets in a short-lived HttpOnly cookie scoped to the callback path; identities keyed by issuer + subject; existing accounts linked only through a provider-verified email; post-login redirects limited to same-site paths; HTTPS issuers required except on loopback |
| Rate limiting | Per-IP limits on all API routes and stricter ones on authentication; per process by default, or shared through the database (`RATE_LIMIT_STORE=database`) for several instances |
| Headers | `X-Frame-Options: SAMEORIGIN`, `frame-ancestors 'self'`, `nosniff`, `Referrer-Policy`, `Permissions-Policy`; `X-Powered-By` removed |
| Logging | Method, path, status and duration only — no request bodies, query strings, cookies or page content |
| CSV export | Cells starting with `=`, `+`, `@`, tab or CR (or a non-numeric `-`) are prefixed with `'` to prevent spreadsheet formula injection |
| Audit trail | `audit_events` records sign-in-independent security actions (membership, sharing, publishing, deletion, import/export) without content |

## Permission rules

1. Workspace roles: owner and admin get full access, editor gets edit, viewer gets view.
2. A page marked **Private** (and everything under it) is visible only to its creator, plus
   people explicitly granted access to it or to a sub-page.
3. An explicit per-page grant (`full`, `edit`, `view`, or `none`) applies to that page and its
   descendants and overrides inherited access. The nearest grant wins.
4. Database records inherit from their database.

Tests in `tests/core.test.ts` and `tests/api.test.ts` cover these rules, including ID-guessing
attempts through every main endpoint.

## Data deletion

* Pages go to the Trash first; *Delete permanently* removes the page, sub-pages, records, blocks,
  relation links and history (database cascades).
* Deleting a workspace removes all of its content and uploaded files.
* Deleting an account removes the user, their sessions and tokens, and workspaces where they
  were the only member; shared workspaces must have another owner first.
* Unreferenced uploads are removed by `npm run files:cleanup`.

## Reporting

Report vulnerabilities privately to the maintainers of your deployment.
