# Product specification

Derived from the original project brief (2026-10-19). Slate reproduces the core functionality
and usability of Notion as an independent, self-hosted application with **no artificial
subscription-based feature restrictions**.

## Principles
- Every core feature is available to every authorized user. No plan/tier logic exists.
- Infrastructure safeguards (payload size, upload size, rate limits, timeouts, storage warnings,
  concurrency) are configurable, documented, identical for everyone, and never delete data.
- Works for single users and small teams out of the box without a paid licence or external services.

## Milestones and exit criteria

### M1 Foundation — ✅
Scaffold, schema + migrations, authentication, workspaces, page hierarchy, Docker setup.
*Exit:* sign up, create workspace and nested pages, reload with data intact; tests green.

### M2 Editor — ✅
Structured block model, rich-text editor with all block types in the brief, slash commands,
Markdown shortcuts, drag reordering, autosave, icons and covers.
*Exit:* every block type can be created, edited, saved and reloaded.

### M3 Databases — ✅
Typed properties (all types in the brief), records as pages, views (table, board, calendar,
timeline, list, gallery, chart), filters with AND/OR groups, sorts, grouping, aggregations,
relations (two-way), rollups, safe formulas with cycle detection.
*Exit:* hundreds of databases / thousands of records without caps; engine tests green.

### M4 Product completeness — ✅
Search, templates, attachments, trash, version history, import/export (Markdown, HTML, JSON, CSV).
*Exit:* export → import round trip without unacceptable loss; permission-aware search.

### M5 Collaboration & hardening — ✅ (except realtime)
Invitations, roles, sharing, permissions with inheritance, public links, security & performance
tests, backups, deployment docs.
*Exit:* IDOR tests pass; documented backup/restore; production build.

### M6 Realtime collaboration — done
- Simultaneous editing of the same page by several users with character-level merging (CRDT).
- Presence: see who else is on the page and their cursors.
- Same authentication and authorization as the REST API (viewers are read-only).
- Content persisted to the block table (search, export, history keep working).
- REST writes (restore, import, API) are reflected in open editors.
- Graceful fallback to versioned REST saves when the realtime connection is unavailable.
*Exit:* automated test with two clients editing concurrently converges and persists; browser
check with two sessions; viewer cannot write; tests/lint/typecheck/build green.

### M7 Automated end-to-end tests — done
Playwright suite for the main workflows and drag interactions.

### M8 Scale & polish — done
- Inline comment threads anchored to text, replies, resolve/reopen; @-mentions of people in pages
  and comments; an inbox of mentions and replies. Notifications never reveal pages the recipient
  cannot view (checked when sent and again when listed).
- Large databases: filters/sorts evaluated in SQL where possible; virtualised table rows.
- Per-block linked view settings (a linked database block has its own views).
- Importer for Notion's own export (Markdown & CSV ZIP), keeping hierarchy and databases.
- Optional OIDC sign-in (ungated), accounts linked by verified email.
- Rate limits shared between instances (PostgreSQL-backed).
*Exit:* each item has server tests and, where it has UI, an end-to-end test; a 50,000-record
database queries and scrolls smoothly on PostgreSQL; tests/lint/typecheck/build/E2E green.

## Definition of done (whole project)
Working local launch; PostgreSQL persistence; secure auth/authz; functional editor, hierarchy,
databases and views; relations and safe formulas; search; import/export; recovery and history;
no feature gates; automated tests; Docker Compose; `.env.example`; migration and backup docs;
README; documented list of incomplete features.
