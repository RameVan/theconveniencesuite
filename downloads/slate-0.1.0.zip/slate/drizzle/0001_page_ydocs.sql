CREATE TABLE "page_ydocs" (
	"page_id" text PRIMARY KEY NOT NULL,
	"state" "bytea" NOT NULL,
	"content_version" integer NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "page_ydocs" ADD CONSTRAINT "page_ydocs_page_id_pages_id_fk" FOREIGN KEY ("page_id") REFERENCES "public"."pages"("id") ON DELETE cascade ON UPDATE no action;