// Automated accessibility checks (axe-core, WCAG 2.1 A/AA rules) on the main screens, in light
// and dark mode. Any violation fails the test with the rule, its impact and the offending nodes.
import { test, expect, type Page } from "@playwright/test";
import { readFileSync } from "node:fs";
import { signUp, apiJson, newPage } from "./helpers";

const axeSource = readFileSync(require.resolve("axe-core/axe.min.js"), "utf8");

type Violation = { id: string; impact: string; help: string; nodes: { target: string[] }[] };

async function audit(page: Page, label: string) {
  await page.addScriptTag({ content: axeSource });
  const violations: Violation[] = await page.evaluate(async () => {
    // @ts-expect-error injected above
    const r = await window.axe.run(document, { runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"] } });
    return r.violations.map((v: Violation) => ({ id: v.id, impact: v.impact, help: v.help, nodes: v.nodes.map((n) => ({ target: n.target })) }));
  });
  const report = violations.map((v) => `${label}: [${v.impact}] ${v.id} — ${v.help}\n    ${v.nodes.map((n) => n.target.join(" ")).slice(0, 8).join("\n    ")}`);
  expect(report, report.join("\n")).toEqual([]);
}

for (const scheme of ["light", "dark"] as const) {
  test.describe(`${scheme} mode`, () => {
    test.use({ colorScheme: scheme });

    test("sign-in and sign-up screens", async ({ page }) => {
      await page.goto("/login");
      await expect(page.getByLabel("Password", { exact: true })).toBeVisible();
      await audit(page, "login");
      await page.goto("/signup");
      await expect(page.getByLabel("Password", { exact: true })).toBeVisible();
      await audit(page, "signup");
    });

    test("a page with content, the sidebar and the settings dialog", async ({ page }) => {
      const { workspaceId } = await signUp(page, "Reader");
      const id = await newPage(page, workspaceId, "Accessible page");
      await apiJson(page, "PUT", `/api/pages/${id}/favorite`);
      await apiJson(page, "PUT", `/api/pages/${id}/content`, {
        blocks: [
          { id: "h", content: { type: "heading", attrs: { level: 2 }, content: [{ type: "text", text: "Section" }] } },
          { id: "p", content: { type: "paragraph", content: [{ type: "text", text: "Some text with a " }, { type: "text", text: "link", marks: [{ type: "link", attrs: { href: "https://example.com" } }] }] } },
          { id: "t", content: { type: "taskList", content: [{ type: "taskItem", attrs: { checked: true }, content: [{ type: "paragraph", content: [{ type: "text", text: "Done thing" }] }] }] } },
        ],
      });
      await page.goto(`/w/${workspaceId}/p/${id}`);
      await expect(page.locator(".ProseMirror")).toContainText("Done thing");
      await audit(page, "page");

      await page.getByRole("button", { name: /settings/i }).first().click();
      await expect(page.getByRole("dialog")).toBeVisible();
      await audit(page, "settings");
    });

    test("a database in table and board views", async ({ page }) => {
      const { workspaceId } = await signUp(page, "Tabler");
      const db = (await apiJson<{ page: { id: string } }>(page, "POST", "/api/pages", { workspaceId, kind: "database", title: "Tracker" })).page.id;
      const status = (await apiJson<{ property: { id: string } }>(page, "POST", `/api/databases/${db}/properties`, { name: "Status", type: "status" })).property;
      await apiJson(page, "POST", `/api/databases/${db}/properties`, { name: "Due", type: "date" });
      for (const title of ["First", "Second"]) await apiJson(page, "POST", `/api/databases/${db}/records`, { title, values: {} });
      await apiJson(page, "POST", `/api/databases/${db}/views`, { name: "Board", type: "board", config: { groupBy: status.id } });
      await page.goto(`/w/${workspaceId}/p/${db}`);
      await expect(page.getByText("Second").first()).toBeVisible();
      await audit(page, "table");
      await page.locator("[data-view-tab]").filter({ hasText: "Board" }).getByRole("button").first().click();
      await expect(page.getByText("Second").first()).toBeVisible();
      await audit(page, "board");
    });
  });
}

test("dialogs keep keyboard focus inside and give it back on Escape", async ({ page }) => {
  await signUp(page, "Keys");
  const opener = page.getByRole("button", { name: /settings/i }).first();
  await opener.click();
  const dialog = page.getByRole("dialog");
  await expect(dialog).toBeVisible();
  const inDialog = () => dialog.evaluate((d) => d.contains(document.activeElement));
  await expect.poll(inDialog).toBe(true);
  // Tab around more times than there are controls: focus never leaves the dialog.
  for (let i = 0; i < 40; i++) await page.keyboard.press("Tab");
  expect(await inDialog()).toBe(true);
  for (let i = 0; i < 5; i++) await page.keyboard.press("Shift+Tab");
  expect(await inDialog()).toBe(true);
  // Typing in a field keeps focus there.
  const name = dialog.getByLabel("Name", { exact: true });
  await name.click();
  await page.keyboard.type(" Smith");
  await expect(name).toBeFocused();
  await page.keyboard.press("Escape");
  await expect(dialog).toBeHidden();
  await expect(opener).toBeFocused();
});
