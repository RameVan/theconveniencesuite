import { test, expect, type Page } from "@playwright/test";
import { signUp, apiJson, newPage, caretAtEnd } from "./helpers";

type Note = { kind: string; pageId: string; commentId: string | null; readAt: string | null };
const notes = (p: Page, ws: string) => apiJson<{ notifications: Note[]; unread: number }>(p, "GET", `/api/notifications?workspaceId=${ws}`);

test("inline comment threads, @-mentions and the inbox", async ({ page, browser }) => {
  const { workspaceId } = await signUp(page, "Ada");
  const guestContext = await browser.newContext();
  const grace = await guestContext.newPage();
  const { email } = await signUp(grace, "Grace");
  const inv = await apiJson<{ path: string }>(page, "POST", `/api/workspaces/${workspaceId}/invitations`, { email, role: "editor" });
  await apiJson(grace, "POST", `/api/invitations/${inv.path.split("/").pop()}`);

  const id = await newPage(page, workspaceId, "Launch plan");
  await apiJson(page, "PUT", `/api/pages/${id}/content`, { blocks: [{ id: "b1", content: { type: "paragraph", content: [{ type: "text", text: "The budget is due Friday" }] } }] });
  await page.goto(`/w/${workspaceId}/p/${id}`);
  const editor = page.locator(".ProseMirror");
  await expect(editor).toContainText("due Friday");

  // Select "Friday" and comment on it, mentioning Grace.
  await editor.click();
  await page.keyboard.press("Control+End");
  await caretAtEnd(page);
  await page.keyboard.press("Control+Shift+ArrowLeft");
  await page.getByRole("button", { name: "Comment", exact: true }).click();
  const panel = page.getByRole("complementary", { name: "Comments" });
  const composer = panel.getByRole("textbox", { name: "Add a comment…" });
  await expect(composer).toBeFocused();
  await composer.pressSequentially("Can @Gra");
  await expect(panel.getByRole("option", { name: /Grace/ })).toBeVisible();
  await composer.press("Enter");
  await composer.pressSequentially("check the number?");
  await expect(composer).toHaveValue("Can @Grace check the number?");
  await panel.getByRole("button", { name: "Comment", exact: true }).first().click();

  const thread = panel.locator("[data-thread-card]").first();
  await expect(thread).toContainText("Friday");
  await expect(thread.locator(".mention")).toHaveText("@Grace");
  const anchor = editor.locator("span[data-thread]");
  await expect(anchor).toHaveText("Friday");
  await expect.poll(async () => JSON.stringify((await apiJson<{ content: unknown[] }>(page, "GET", `/api/pages/${id}`)).content), { timeout: 15_000 }).toContain('"type":"comment"');

  // Grace sees the mention in her inbox and jumps to the thread.
  await grace.goto(`/w/${workspaceId}`);
  const inbox = grace.getByRole("button", { name: /^Inbox, 1 unread$/ });
  await expect(inbox).toBeVisible({ timeout: 35_000 });
  await inbox.click();
  const dialog = grace.getByRole("dialog", { name: "Inbox" });
  await expect(dialog).toContainText("Ada mentioned you in a comment on");
  await expect(dialog).toContainText("Can @Grace check the number?");
  await dialog.getByRole("button", { name: /Launch plan/ }).click();
  await grace.waitForURL(/\?thread=/);
  const gPanel = grace.getByRole("complementary", { name: "Comments" });
  await expect(gPanel.locator("[data-thread-card]").first()).toHaveClass(/ring-accent/);
  await gPanel.getByRole("button", { name: "Reply…" }).click();
  await gPanel.getByRole("textbox", { name: "Reply…" }).fill("Checked, it is right");
  await gPanel.getByRole("button", { name: "Reply", exact: true }).click();
  await expect(gPanel).toContainText("Checked, it is right");
  await expect.poll(async () => (await notes(grace, workspaceId)).unread).toBe(0);

  // Ada is told about the reply.
  await expect.poll(async () => (await notes(page, workspaceId)).notifications.map((n) => n.kind)).toContain("reply");

  // Ada mentions Grace in the page body.
  await editor.click();
  await page.keyboard.press("Control+End");
  await caretAtEnd(page);
  await page.keyboard.press("Enter");
  await page.keyboard.type("Thanks @Gra");
  await expect(page.getByRole("button", { name: /Grace/ }).first()).toBeVisible();
  await page.keyboard.press("Enter");
  await expect(editor.locator('[data-type="mention"]')).toHaveText("@Grace");
  await expect
    .poll(async () => (await notes(grace, workspaceId)).notifications.filter((n) => n.kind === "page_mention").length, { timeout: 20_000 })
    .toBe(1);

  // Resolving the thread removes the highlight.
  const bg = () => anchor.evaluate((el) => getComputedStyle(el).backgroundColor);
  expect(await bg()).not.toBe("rgba(0, 0, 0, 0)");
  await thread.hover();
  await thread.getByRole("button", { name: "Resolve thread" }).click();
  await expect.poll(bg).toBe("rgba(0, 0, 0, 0)");
  await guestContext.close();
});
