import { test, expect, type Page } from "@playwright/test";
import { signUp, apiJson } from "./helpers";

type Prop = { id: string; name: string; type: string; config: { options?: { id: string; name: string }[] } };
type Meta = { properties: Prop[]; views: { id: string; name: string; type: string; config: { propertyWidths?: Record<string, number>; visibleProperties?: string[] } }[] };
type Row = { id: string; title: string; values: Record<string, unknown> };

const pad = (n: number) => String(n).padStart(2, "0");
const now = new Date();
const day = (d: number) => `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(d)}`;

/** A database with Status, Due and Notes properties, two records, and board + calendar views. */
async function seed(page: Page, workspaceId: string) {
  const db = (await apiJson<{ page: { id: string } }>(page, "POST", "/api/pages", { workspaceId, kind: "database", title: "Tracker" })).page.id;
  await apiJson(page, "POST", `/api/databases/${db}/properties`, { name: "Status", type: "status" });
  await apiJson(page, "POST", `/api/databases/${db}/properties`, { name: "Due", type: "date" });
  await apiJson(page, "POST", `/api/databases/${db}/properties`, { name: "Notes", type: "rich_text" });
  const rec = async (title: string, status: string, d: number) =>
    (await apiJson<{ row: Row }>(page, "POST", `/api/databases/${db}/records`, { title, values: { Status: status, Due: day(d) } })).row.id;
  const a = await rec("Write spec", "Not started", 10);
  const b = await rec("Ship release", "In progress", 12);
  const meta = await apiJson<Meta>(page, "GET", `/api/databases/${db}`);
  const status = meta.properties.find((p) => p.name === "Status")!;
  const dueProp = meta.properties.find((p) => p.name === "Due")!;
  await apiJson(page, "POST", `/api/databases/${db}/views`, { name: "Board", type: "board", config: { groupBy: status.id } });
  await apiJson(page, "POST", `/api/databases/${db}/views`, { name: "Calendar", type: "calendar", config: { dateProperty: dueProp.id } });
  return { db, spec: a, release: b, status, dueProp };
}

const record = (page: Page, id: string) => apiJson<{ row: Row }>(page, "GET", `/api/records/${id}`).then((r) => r.row);

test("edit cells, resize a column, and drag cards on board and calendar", async ({ page }) => {
  const { workspaceId } = await signUp(page, "Planner");
  const { db, spec, release, status, dueProp } = await seed(page, workspaceId);
  await page.goto(`/w/${workspaceId}/p/${db}`);
  const table = page.getByRole("table");
  await expect(table.getByRole("row").filter({ hasText: "Write spec" })).toBeVisible();

  // Edit a text cell: click, type, Enter.
  const notesCol = (await table.getByRole("columnheader").allInnerTexts()).findIndex((t) => t.includes("Notes"));
  expect(notesCol).toBeGreaterThan(-1);
  const specRow = table.getByRole("row").filter({ hasText: "Write spec" });
  await specRow.getByRole("cell").nth(notesCol).getByRole("button").click();
  await page.keyboard.type("Draft by Friday");
  await page.keyboard.press("Enter");
  await expect(specRow).toContainText("Draft by Friday");
  const notesId = (await apiJson<Meta>(page, "GET", `/api/databases/${db}`)).properties.find((p) => p.name === "Notes")!.id;
  await expect.poll(async () => (await record(page, spec)).values[notesId]).toBe("Draft by Friday");

  // Rename a record from its title cell (the first column after the row-selection one).
  await specRow.getByRole("cell").nth(1).getByRole("button").first().click();
  await page.keyboard.press("Control+A");
  await page.keyboard.type("Write the spec");
  await page.keyboard.press("Enter");
  await expect.poll(async () => (await record(page, spec)).title).toBe("Write the spec");

  // Resize the Notes column by dragging the header's right edge.
  const header = table.getByRole("columnheader").nth(notesCol);
  await header.hover(); // scrolls it into view first
  const hb = (await header.boundingBox())!;
  await page.mouse.move(hb.x + hb.width - 1, hb.y + hb.height / 2);
  await page.mouse.down();
  await page.mouse.move(hb.x + hb.width + 120, hb.y + hb.height / 2, { steps: 6 });
  await page.mouse.up();
  await expect.poll(async () => Math.round((await header.boundingBox())!.width)).toBeGreaterThan(Math.round(hb.width) + 100);
  await expect
    .poll(async () => (await apiJson<Meta>(page, "GET", `/api/databases/${db}`)).views.find((v) => v.name === "Table")!.config.propertyWidths?.[notesId] ?? 0)
    .toBeGreaterThan(hb.width + 100);

  // Board: drag "Ship release" into the Done column.
  await page.getByRole("button", { name: "Board", exact: true }).click();
  const card = page.getByText("Ship release", { exact: true });
  await expect(card).toBeVisible();
  const doneColumn = page.locator("div.w-\\[260px\\]").filter({ hasText: /^Done/ });
  await card.dragTo(doneColumn);
  const done = status.config.options!.find((o) => o.name === "Done")!.id;
  await expect.poll(async () => (await record(page, release)).values[status.id]).toBe(done);
  await expect(doneColumn).toContainText("Ship release");

  // Calendar: drag "Write the spec" from the 10th to the 20th.
  await page.getByRole("button", { name: "Calendar", exact: true }).click();
  const cell = (d: number) => page.locator(".grid-cols-7 > div").filter({ has: page.locator("span", { hasText: new RegExp(`^${d}$`) }) });
  await expect(cell(10).getByRole("button", { name: "Write the spec" })).toBeVisible();
  await cell(10).getByRole("button", { name: "Write the spec" }).dragTo(cell(20));
  await expect(cell(20).getByRole("button", { name: "Write the spec" })).toBeVisible();
  await expect.poll(async () => JSON.stringify((await record(page, spec)).values[dueProp.id])).toContain(day(20));

  // Everything survives a reload.
  await page.reload();
  await expect(cell(20).getByRole("button", { name: "Write the spec" })).toBeVisible();
});

test("reorder table rows and columns, move and stretch timeline bars", async ({ page }) => {
  const { workspaceId } = await signUp(page, "Scheduler");
  const { db, spec, release, dueProp } = await seed(page, workspaceId);
  await apiJson(page, "PATCH", `/api/records/${spec}`, { values: { Due: { start: day(10), end: day(12) } } });
  await apiJson(page, "POST", `/api/databases/${db}/views`, { name: "Timeline", type: "timeline", config: { dateProperty: dueProp.id, timelineScale: "day" } });
  await page.goto(`/w/${workspaceId}/p/${db}`);
  const table = page.getByRole("table");
  const rowTitles = async () => (await table.getByRole("row").allInnerTexts()).slice(1).map((t) => t.split("\n").find((x) => x.trim())?.trim());
  await expect.poll(rowTitles).toEqual(["Write spec", "Ship release"]);

  // Row reorder with the grip: "Ship release" above "Write spec".
  const releaseRow = table.getByRole("row").filter({ hasText: "Ship release" });
  await releaseRow.hover();
  await releaseRow.getByTitle("Drag to reorder").dragTo(table.getByRole("row").filter({ hasText: "Write spec" }));
  await expect.poll(rowTitles).toEqual(["Ship release", "Write spec"]);
  await expect
    .poll(async () => (await apiJson<{ rows: Row[] }>(page, "POST", `/api/databases/${db}/query`, {})).rows.map((r) => r.id))
    .toEqual([release, spec]);

  // Column reorder: drop "Notes" onto "Tags" → Notes comes right after Name.
  const header = (name: string) => table.getByRole("columnheader").filter({ hasText: new RegExp(`^${name}`) });
  await header("Notes").dragTo(header("Tags"));
  await expect.poll(async () => (await table.getByRole("columnheader").allInnerTexts()).map((t) => t.trim()).filter(Boolean).slice(0, 3)).toEqual(["Name", "Notes", "Tags"]);
  const meta = await apiJson<Meta>(page, "GET", `/api/databases/${db}`);
  const notesId = meta.properties.find((p) => p.name === "Notes")!.id;
  expect(meta.views.find((v) => v.name === "Table")!.config.visibleProperties![1]).toBe(notesId);

  // Timeline: move the 10th–12th bar by two days, then stretch its end by one day.
  await page.getByRole("button", { name: "Timeline", exact: true }).click();
  const bar = page.locator("[data-bar]").filter({ hasText: "Write spec" });
  await expect(bar).toBeVisible();
  await bar.scrollIntoViewIfNeeded();
  const b = (await bar.boundingBox())!;
  const dayW = b.width / 3;
  await page.mouse.move(b.x + b.width / 2, b.y + b.height / 2);
  await page.mouse.down();
  await page.mouse.move(b.x + b.width / 2 + dayW * 2, b.y + b.height / 2, { steps: 5 });
  await page.mouse.up();
  await expect.poll(async () => (await record(page, spec)).values[dueProp.id]).toMatchObject({ start: day(12), end: day(14) });

  await bar.evaluate((el) => el.scrollIntoView({ inline: "center", block: "center" }));
  const b2 = (await bar.boundingBox())!;
  await page.mouse.move(b2.x + b2.width - 1, b2.y + b2.height / 2);
  await page.mouse.down();
  await page.mouse.move(b2.x + b2.width - 1 + dayW, b2.y + b2.height / 2, { steps: 5 });
  await page.mouse.up();
  await expect.poll(async () => (await record(page, spec)).values[dueProp.id]).toMatchObject({ start: day(12), end: day(15) });
});

test("large tables load page by page and render only visible rows", async ({ page }) => {
  const { workspaceId } = await signUp(page, "Bulk");
  const db = (await apiJson<{ page: { id: string } }>(page, "POST", "/api/pages", { workspaceId, kind: "database", title: "Big table" })).page.id;
  const N = 360;
  await page.evaluate(
    async ({ db, N }) => {
      for (let i = 0; i < N; i += 30)
        await Promise.all(
          Array.from({ length: Math.min(30, N - i) }, (_, k) =>
            fetch(`/api/databases/${db}/records`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ title: `Item ${String(i + k).padStart(3, "0")}` }) }),
          ),
        );
    },
    { db, N },
  );
  await page.goto(`/w/${workspaceId}/p/${db}`);
  const table = page.getByRole("table");
  await expect(table.getByRole("row").filter({ hasText: "Item" }).first()).toBeVisible();
  // First page only, with the total known.
  await expect(page.getByText(`100 of ${N}`)).toBeVisible();
  await expect(page.getByRole("button", { name: `Count ${N}` })).toBeAttached();

  // Scrolling loads the rest; long tables keep only nearby rows in the DOM.
  for (let i = 0; i < 20 && (await page.getByRole("button", { name: "Load more" }).count()); i++) {
    await page.getByRole("button", { name: "Load more" }).scrollIntoViewIfNeeded();
    await page.waitForTimeout(300);
  }
  await expect(page.getByRole("button", { name: "Load more" })).toHaveCount(0);
  await expect(page.locator(`[data-virtual-rows="${N}"]`)).toBeAttached();
  const rendered = await table.getByRole("row").filter({ hasText: "Item" }).count();
  expect(rendered).toBeLessThan(N);
  // The last record is reachable at the bottom.
  await page.getByRole("button", { name: /^\+?\s*New$/ }).last().scrollIntoViewIfNeeded();
  await expect(table.getByRole("row").filter({ hasText: `Item ${String(N - 1).padStart(3, "0")}` })).toBeVisible();
});

test("a linked view has its own views, separate from the database", async ({ page }) => {
  const { workspaceId } = await signUp(page, "Linker");
  const dbId = (await apiJson<{ page: { id: string } }>(page, "POST", "/api/pages", { workspaceId, kind: "database", title: "Task list" })).page.id;
  await apiJson(page, "POST", `/api/databases/${dbId}/records`, { title: "Linked record" });
  const pageId = (await apiJson<{ page: { id: string } }>(page, "POST", "/api/pages", { workspaceId, title: "Dashboard" })).page.id;
  await page.goto(`/w/${workspaceId}/p/${pageId}`);
  const editor = page.locator(".ProseMirror");
  await editor.click();
  await page.keyboard.type("/linked");
  await expect(page.getByRole("option", { name: /Linked view of database/ })).toBeVisible();
  await page.keyboard.press("Enter");
  await page.getByRole("button", { name: /Task list/ }).click();
  const block = page.getByRole("region", { name: "Database Task list" });
  await expect(block.getByRole("table")).toContainText("Linked record");

  // Change this block's layout to a list.
  await block.getByTitle("View options").click();
  await page.getByRole("menuitem", { name: "Change layout" }).hover();
  await page.getByRole("menuitem", { name: "List" }).click();
  await expect(block.getByRole("table")).toHaveCount(0);
  await expect(block).toContainText("Linked record");

  // Stored in the block; the database keeps its table view.
  type Block = { type: string; attrs?: { databaseId?: string; views?: { type: string }[] } };
  await expect
    .poll(async () => (await apiJson<{ content: Block[] }>(page, "GET", `/api/pages/${pageId}`)).content.find((b) => b.type === "databaseView")?.attrs?.views?.[0]?.type, { timeout: 15_000 })
    .toBe("list");
  expect((await apiJson<{ views: { type: string }[] }>(page, "GET", `/api/databases/${dbId}`)).views.map((v) => v.type)).toEqual(["table"]);
  await page.reload();
  await expect(page.getByRole("region", { name: "Database Task list" })).toContainText("Linked record");
  await expect(page.getByRole("region", { name: "Database Task list" }).getByRole("table")).toHaveCount(0);
});

test("calendars fetch only the weeks on screen", async ({ page }) => {
  const { workspaceId } = await signUp(page, "Calendarist");
  const { db } = await seed(page, workspaceId); // two records on the 10th and 12th of this month
  const far = new Date(now.getFullYear(), now.getMonth() + 5, 15);
  const farDay = `${far.getFullYear()}-${pad(far.getMonth() + 1)}-15`;
  await apiJson(page, "POST", `/api/databases/${db}/records`, { title: "Far future", values: { Due: farDay } });
  await apiJson(page, "POST", `/api/databases/${db}/records`, { title: "No date yet" });
  await apiJson(page, "POST", `/api/databases/${db}/records`, { title: "Long trip", values: { Due: { start: day(1), end: day(20) } } });

  const fetched: string[][] = [];
  page.on("response", async (r) => {
    if (!r.url().endsWith("/query") || r.request().method() !== "POST") return;
    const body = JSON.parse(r.request().postData() ?? "{}");
    if (body.limit === 1) return; // the undated count
    fetched.push(((await r.json()) as { rows: { title: string }[] }).rows.map((x) => x.title));
  });
  await page.goto(`/w/${workspaceId}/p/${db}`);
  await page.getByRole("button", { name: "Calendar", exact: true }).click();
  const cell = (d: number) => page.locator(".grid-cols-7 > div").filter({ has: page.locator("span", { hasText: new RegExp(`^${d}$`) }) });
  await expect(cell(10).getByRole("button", { name: "Write spec" })).toBeVisible();
  await expect(cell(15).getByRole("button", { name: "Long trip" })).toBeVisible();
  await expect(page.getByText("1 record without a Due")).toBeVisible();
  await expect.poll(() => fetched.length).toBeGreaterThan(0);
  const visible = fetched[fetched.length - 1];
  expect(visible).toEqual(expect.arrayContaining(["Write spec", "Ship release", "Long trip"]));
  expect(visible).not.toContain("Far future");
  expect(visible).not.toContain("No date yet");

  // Navigating reaches the far record.
  for (let i = 0; i < 5; i++) await page.getByRole("button", { name: "Next month" }).click();
  await expect(cell(15).getByRole("button", { name: "Far future" })).toBeVisible();
});

test("an older linked block can switch to its own views; inline databases don't offer it", async ({ page }) => {
  const { workspaceId } = await signUp(page, "Detacher");
  const dbId = (await apiJson<{ page: { id: string } }>(page, "POST", "/api/pages", { workspaceId, kind: "database", title: "Shared tasks" })).page.id;
  await apiJson(page, "POST", `/api/databases/${dbId}/records`, { title: "Row one" });
  const pageId = (await apiJson<{ page: { id: string } }>(page, "POST", "/api/pages", { workspaceId, title: "Old dashboard" })).page.id;
  const inlineId = (await apiJson<{ page: { id: string } }>(page, "POST", "/api/pages", { workspaceId, kind: "database", title: "Local list", parentId: pageId })).page.id;
  // Blocks as created before per-block views existed: no "views" attribute.
  await apiJson(page, "PUT", `/api/pages/${pageId}/content`, {
    blocks: [
      { id: "old-link", content: { type: "databaseView", attrs: { databaseId: dbId } } },
      { id: "inline-db", content: { type: "databaseView", attrs: { databaseId: inlineId } } },
    ],
  });
  await page.goto(`/w/${workspaceId}/p/${pageId}`);
  const linked = page.getByRole("region", { name: "Database Shared tasks" });
  const inline = page.getByRole("region", { name: "Database Local list" });
  await expect(linked).toContainText("Row one");

  await inline.getByTitle("View options").click();
  await expect(page.getByRole("menuitem", { name: "Rename" })).toBeVisible();
  await expect(page.getByRole("menuitem", { name: "Use separate views here" })).toHaveCount(0);
  await page.keyboard.press("Escape");

  await linked.getByTitle("View options").click();
  await page.getByRole("menuitem", { name: "Use separate views here" }).click();
  await linked.getByTitle("View options").click();
  await page.getByRole("menuitem", { name: "Change layout" }).hover();
  await page.getByRole("menuitem", { name: "List" }).click();
  await expect(linked.getByRole("table")).toHaveCount(0);

  type Block = { attrs?: { id?: string; views?: { type: string }[] } };
  await expect
    .poll(async () => (await apiJson<{ content: Block[] }>(page, "GET", `/api/pages/${pageId}`)).content.find((b) => b.attrs?.id === "old-link")?.attrs?.views?.[0]?.type, { timeout: 15_000 })
    .toBe("list");
  expect((await apiJson<{ views: { type: string }[] }>(page, "GET", `/api/databases/${dbId}`)).views.map((v) => v.type)).toEqual(["table"]);
});

test("charts load group totals and timelines load page by page", async ({ page }) => {
  const { workspaceId } = await signUp(page, "Charter");
  const { db, status, dueProp } = await seed(page, workspaceId);
  const N = 128; // plus the two seeded records
  await page.evaluate(
    async ({ db, N }) => {
      for (let i = 0; i < N; i += 32)
        await Promise.all(
          Array.from({ length: Math.min(32, N - i) }, (_, k) =>
            fetch(`/api/databases/${db}/records`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ title: `Bulk ${i + k}`, values: { Status: (i + k) % 3 ? "Done" : "In progress", Due: "2026-03-01" } }) }),
          ),
        );
    },
    { db, N },
  );
  await apiJson(page, "POST", `/api/databases/${db}/views`, { name: "Chart", type: "chart", config: { groupBy: status.id } });
  await apiJson(page, "POST", `/api/databases/${db}/views`, { name: "Timeline", type: "timeline", config: { dateProperty: dueProp.id } });

  const responses: { rows: unknown[]; groups: { count: number; rowIds: string[] }[] | null }[] = [];
  page.on("response", async (r) => {
    if (r.url().endsWith("/query") && r.request().method() === "POST") responses.push(await r.json());
  });
  await page.goto(`/w/${workspaceId}/p/${db}`);
  await page.getByRole("button", { name: "Chart", exact: true }).click();
  await expect(page.getByRole("img")).toBeVisible();
  await expect.poll(() => responses.filter((x) => x.groups).length).toBeGreaterThan(0);
  const chart = responses.filter((x) => x.groups).pop()!;
  expect(chart.groups!.every((g) => g.rowIds.length <= 1)).toBe(true);
  expect(chart.groups!.reduce((s, g) => s + g.count, 0)).toBe(N + 2);

  await page.getByRole("button", { name: "Timeline", exact: true }).click();
  await expect(page.getByText(`100 of ${N + 2}`)).toBeVisible();
  await page.getByRole("button", { name: "Load more" }).click();
  await expect(page.getByRole("button", { name: "Load more" })).toHaveCount(0);
  await expect(page.locator("[data-bar]")).toHaveCount(N + 2);
});

test("view tabs reorder by dragging or from the view menu", async ({ page }) => {
  const { workspaceId } = await signUp(page, "Tabber");
  const { db } = await seed(page, workspaceId); // views: Table, Board, Calendar
  await page.goto(`/w/${workspaceId}/p/${db}`);
  const tabs = page.locator("[data-view-tab]");
  const names = async () => (await tabs.allInnerTexts()).map((t) => t.trim());
  await expect.poll(names).toEqual(["Table", "Board", "Calendar"]);
  const serverOrder = async () => (await apiJson<Meta>(page, "GET", `/api/databases/${db}`)).views.map((v) => v.name);

  // Drag "Calendar" onto the left half of "Table".
  const table = page.locator("[data-view-tab]").filter({ hasText: "Table" });
  const tb = (await table.boundingBox())!;
  await page.locator("[data-view-tab]").filter({ hasText: "Calendar" }).dragTo(table, { targetPosition: { x: 4, y: tb.height / 2 } });
  await expect.poll(names).toEqual(["Calendar", "Table", "Board"]);
  await expect.poll(serverOrder).toEqual(["Calendar", "Table", "Board"]);

  // "Move right" from the active view's menu (no dragging needed, e.g. on a phone).
  await page.getByRole("button", { name: "Calendar", exact: true }).click();
  await page.getByTitle("View options").click();
  await page.getByRole("menuitem", { name: "Move right" }).click();
  await expect.poll(names).toEqual(["Table", "Calendar", "Board"]);
  await expect.poll(serverOrder).toEqual(["Table", "Calendar", "Board"]);
  await page.reload();
  await expect.poll(names).toEqual(["Table", "Calendar", "Board"]);
});
