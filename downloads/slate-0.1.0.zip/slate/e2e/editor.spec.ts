import { test, expect, type Page } from "@playwright/test";
import { signUp, apiJson, waitForSaved, caretInBlock } from "./helpers";

const blocks = (page: Page) => page.locator(".ProseMirror > *");

test("write a page with shortcuts and slash commands, reorder blocks, and reload intact", async ({ page }) => {
  await signUp(page, "Writer");

  // Starter content exists.
  await page.getByRole("link", { name: "Getting started" }).click();
  await expect(page.locator(".ProseMirror")).toContainText("Welcome to Slate");

  // New page with the keyboard shortcut; typing right after Enter must not be lost.
  await page.keyboard.press("Control+Shift+N");
  await page.waitForURL(/\/p\/[0-9a-f-]+\?new=1$/);
  const pageId = page.url().split("/p/")[1].split("?")[0];
  await page.getByLabel("Page title").fill("Meeting notes");
  await page.getByLabel("Page title").press("Enter");
  await page.keyboard.type("# Agenda");
  await page.keyboard.press("Enter");
  await page.keyboard.type("- first point");
  await page.keyboard.press("Enter");
  await page.keyboard.press("Tab");
  await page.keyboard.type("nested point");
  await page.keyboard.press("Enter");
  await page.keyboard.press("Enter");
  await page.keyboard.press("Enter");
  // Slash menu: callout.
  await page.keyboard.type("/callout");
  await expect(page.getByRole("option", { name: /Callout/ })).toBeVisible();
  await page.keyboard.press("Enter");
  await page.keyboard.type("Remember the budget");
  await page.keyboard.press("Enter");
  await page.keyboard.press("Enter");
  await page.keyboard.press("Enter");
  await page.keyboard.type("[] follow up");

  const editor = page.locator(".ProseMirror");
  await expect(editor.locator("h1")).toHaveText("Agenda");
  await expect(editor.locator("ul ul li")).toHaveText("nested point");
  await expect(editor.locator('[data-type="callout"]')).toContainText("Remember the budget");
  await expect(editor.locator('ul[data-type="taskList"]')).toContainText("follow up");

  // After a pause the page switches to the realtime document.
  await expect(page.locator("header [aria-live]")).toHaveText(/Live/, { timeout: 15_000 });

  // Drag the heading below the callout with the ⋮⋮ handle (real mouse drag).
  await editor.locator("h1").hover();
  const handle = page.getByRole("button", { name: "Drag to move, click for block options" });
  await expect(handle).toBeVisible();
  const hb = (await handle.boundingBox())!;
  const callout = (await editor.locator('[data-type="callout"]').boundingBox())!;
  await page.mouse.move(hb.x + hb.width / 2, hb.y + hb.height / 2);
  await page.mouse.down();
  await page.mouse.move(callout.x + 40, callout.y + callout.height - 3, { steps: 8 });
  await page.mouse.up();
  await expect(blocks(page).nth(2)).toHaveText("Agenda");

  // Drag the to-do list to the top (drag events dispatched in the page).
  await editor.locator('ul[data-type="taskList"]').hover();
  await expect(handle).toBeVisible();
  await page.evaluate(() => {
    const handleEl = document.querySelector('[aria-label="Drag to move, click for block options"]')!;
    const first = document.querySelector(".ProseMirror > *")!.getBoundingClientRect();
    const dt = new DataTransfer();
    const at = { clientX: first.x + 20, clientY: first.y + 2, bubbles: true, cancelable: true, dataTransfer: dt };
    handleEl.dispatchEvent(new DragEvent("dragstart", { bubbles: true, cancelable: true, dataTransfer: dt }));
    const target = document.elementFromPoint(at.clientX, at.clientY)!;
    target.dispatchEvent(new DragEvent("dragover", at));
    target.dispatchEvent(new DragEvent("drop", at));
    handleEl.dispatchEvent(new DragEvent("dragend", { bubbles: true, dataTransfer: dt }));
  });
  await expect(blocks(page).first()).toContainText("follow up");
  await waitForSaved(page);

  // Reload: everything persisted, in the new order.
  await page.reload();
  await expect(page.getByLabel("Page title")).toHaveValue("Meeting notes");
  await expect(blocks(page).first()).toContainText("follow up");
  await expect(blocks(page).nth(3)).toHaveText("Agenda");
  await expect.poll(async () => (await apiJson<{ content: { type: string }[] }>(page, "GET", `/api/pages/${pageId}`)).content.map((b) => b.type).slice(0, 4)).toEqual([
    "taskList",
    "bulletList",
    "callout",
    "heading",
  ]);
});

test("opening a page does not save it", async ({ page }) => {
  const { workspaceId } = await signUp(page, "Reader");
  const id = (await apiJson<{ page: { id: string } }>(page, "POST", "/api/pages", { workspaceId, title: "Untouched" })).page.id;
  await apiJson(page, "PUT", `/api/pages/${id}/content`, {
    blocks: [{ id: "u1", content: { type: "paragraph", content: [{ type: "text", text: "Read me", marks: [{ type: "bold" }] }] } }],
  });
  const version = async () => (await apiJson<{ page: { version: number } }>(page, "GET", `/api/pages/${id}`)).page.version;
  const before = await version();
  await page.goto(`/w/${workspaceId}/p/${id}`);
  await expect(page.locator("header [aria-live]")).toHaveText(/Live/, { timeout: 15_000 });
  await page.waitForTimeout(2_000); // past the autosave debounce
  expect(await version()).toBe(before);
});

test("the block handle stays reachable, and blocks change type from its menu or a right-click", async ({ page }) => {
  const { workspaceId } = await signUp(page, "Mover");
  const id = (await apiJson<{ page: { id: string } }>(page, "POST", "/api/pages", { workspaceId, title: "Types" })).page.id;
  const item = (t: string) => ({ type: "taskItem", attrs: { checked: false }, content: [{ type: "paragraph", content: [{ type: "text", text: t }] }] });
  await apiJson(page, "PUT", `/api/pages/${id}/content`, {
    blocks: [
      { id: "todo", content: { type: "taskList", content: [item("Buy milk"), item("Call Sam"), item("Pay rent")] } },
      { id: "para", content: { type: "paragraph", content: [{ type: "text", text: "Plain text line" }] } },
    ],
  });
  await page.goto(`/w/${workspaceId}/p/${id}`);
  const editor = page.locator(".ProseMirror");
  await expect(editor).toContainText("Pay rent");

  // Move from the text to the handle the way a person does: through the gap, in small steps.
  const first = (await editor.locator("li").first().boundingBox())!;
  await page.mouse.move(first.x + 60, first.y + first.height / 2);
  const handle = page.getByRole("button", { name: "Drag to move, click for block options" });
  await expect(handle).toBeVisible();
  const hb = (await handle.boundingBox())!;
  await page.mouse.move(hb.x + hb.width / 2, hb.y + hb.height / 2, { steps: 25 });
  await expect(handle).toBeVisible();
  await page.mouse.click(hb.x + hb.width / 2, hb.y + hb.height / 2);
  await page.getByRole("menuitem", { name: "Turn into" }).hover().catch(() => {});
  await page.getByRole("menuitem", { name: "Heading 3" }).click();
  // Every item of the to-do list became a heading, not just the first.
  await expect(editor.locator("h3")).toHaveText(["Buy milk", "Call Sam", "Pay rent"]);
  await expect(editor.locator('ul[data-type="taskList"]')).toHaveCount(0);

  // Right-click a block for the same menu.
  await editor.getByText("Plain text line").click({ button: "right" });
  await page.getByRole("menuitem", { name: "Turn into" }).hover().catch(() => {});
  await page.getByRole("menuitem", { name: "To-do list" }).click();
  await expect(editor.locator('ul[data-type="taskList"]')).toContainText("Plain text line");
  await waitForSaved(page);
  await expect
    .poll(async () => (await apiJson<{ content: { type: string }[] }>(page, "GET", `/api/pages/${id}`)).content.map((b) => b.type).slice(0, 4))
    .toEqual(["heading", "heading", "heading", "taskList"]); // the editor keeps an empty line after a final list
});

test("Ctrl+Shift+Up/Down moves the block with the cursor", async ({ page }) => {
  const { workspaceId } = await signUp(page, "Keyboarder");
  const id = (await apiJson<{ page: { id: string } }>(page, "POST", "/api/pages", { workspaceId, title: "Keys" })).page.id;
  const p = (pid: string, t: string) => ({ id: pid, content: { type: "paragraph", content: [{ type: "text", text: t }] } });
  await apiJson(page, "PUT", `/api/pages/${id}/content`, { blocks: [p("a", "Alpha"), p("b", "Bravo"), p("c", "Charlie")] });
  await page.goto(`/w/${workspaceId}/p/${id}`);
  const editor = page.locator(".ProseMirror");
  await editor.getByText("Charlie").click();
  await caretInBlock(page, "Charlie");
  await page.keyboard.press("Control+Shift+ArrowUp");
  await page.keyboard.press("Control+Shift+ArrowUp");
  await expect(editor.locator("p")).toHaveText(["Charlie", "Alpha", "Bravo"]);
  await page.keyboard.press("Control+Shift+ArrowDown");
  await expect(editor.locator("p")).toHaveText(["Alpha", "Charlie", "Bravo"]);
  // The cursor stayed in the moved block: typing goes there.
  await page.keyboard.type("!");
  await expect(editor.locator("p").nth(1)).toContainText("!");
  await waitForSaved(page);
  await expect
    .poll(async () => JSON.stringify((await apiJson<{ content: unknown[] }>(page, "GET", `/api/pages/${id}`)).content))
    .toMatch(/Alpha.*Charlie.*!.*Bravo/);
});
