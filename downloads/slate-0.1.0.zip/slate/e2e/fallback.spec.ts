// The editor without the realtime connection (REST saves): nothing typed is lost when the tab
// closes, and an idle page picks up changes made elsewhere.
import { test, expect, type Page } from "@playwright/test";
import { signUp, apiJson, newPage } from "./helpers";

/** Refuse every realtime WebSocket, so the editor stays in REST mode. */
async function blockRealtime(page: Page) {
  await page.routeWebSocket(/:\d+\/?$/, (ws) => ws.close({ code: 1013, reason: "unavailable" }));
}

const text = async (page: Page, id: string) => JSON.stringify((await apiJson<{ content: unknown[] }>(page, "GET", `/api/pages/${id}`)).content);

test("typing and closing the tab at once still saves the last words", async ({ page, context }) => {
  await blockRealtime(page);
  const { workspaceId } = await signUp(page, "Hasty");
  const id = await newPage(page, workspaceId, "Quick note");
  await page.goto(`/w/${workspaceId}/p/${id}`);
  await page.locator(".ProseMirror").click();
  await page.keyboard.type("Last words before closing");
  // Close well within the autosave delay; the page saves on its way out.
  await page.close({ runBeforeUnload: true });

  const other = await context.newPage();
  await other.goto("/");
  await expect.poll(() => text(other, id), { timeout: 10_000 }).toContain("Last words before closing");
});

test("an idle page shows changes saved elsewhere", async ({ page }) => {
  await blockRealtime(page);
  const { workspaceId } = await signUp(page, "Watcher");
  const id = await newPage(page, workspaceId, "Shared list");
  await apiJson(page, "PUT", `/api/pages/${id}/content`, { blocks: [{ id: "a", content: { type: "paragraph", content: [{ type: "text", text: "Original line" }] } }] });
  await page.goto(`/w/${workspaceId}/p/${id}`);
  const editor = page.locator(".ProseMirror");
  await expect(editor).toContainText("Original line");
  await expect(page.locator("header [aria-live]")).not.toHaveText(/Live/);

  // Someone else saves a new version (here through the API, as another client would).
  const cur = await apiJson<{ page: { version: number } }>(page, "GET", `/api/pages/${id}`);
  await apiJson(page, "PUT", `/api/pages/${id}/content`, {
    baseVersion: cur.page.version,
    blocks: [{ id: "a", content: { type: "paragraph", content: [{ type: "text", text: "Updated from another device" }] } }],
  });
  // The idle page checks every 15 s and shows the new content without a reload.
  await expect(editor).toContainText("Updated from another device", { timeout: 25_000 });
  await expect(editor).not.toContainText("Original line");
});
