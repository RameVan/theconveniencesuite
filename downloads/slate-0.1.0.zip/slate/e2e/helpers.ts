import { expect, type Page } from "@playwright/test";

let n = 0;

/** Sign up through the real form; returns the workspace id the app lands in. */
export async function signUp(page: Page, name = "E2E User") {
  const email = `e2e-${Date.now()}-${n++}@example.com`;
  await page.goto("/signup");
  await page.getByLabel("Name").fill(name);
  await page.getByLabel("Email").fill(email);
  await page.getByLabel("Password", { exact: true }).fill("e2e-password-123");
  await page.getByRole("button", { name: "Create account" }).click();
  await page.waitForURL(/\/w\/[0-9a-f-]+$/);
  const workspaceId = page.url().split("/w/")[1];
  await expect(page.getByRole("tree", { name: "Workspace" })).toBeVisible();
  return { email, workspaceId };
}

/** JSON API call with the page's session (same origin, so CSRF checks pass). */
export async function apiJson<T = Record<string, unknown>>(page: Page, method: string, url: string, body?: unknown): Promise<T> {
  return page.evaluate(
    async ({ method, url, body }) => {
      const res = await fetch(url, { method, headers: body ? { "content-type": "application/json" } : undefined, body: body ? JSON.stringify(body) : undefined });
      if (!res.ok) throw new Error(`${method} ${url} → ${res.status} ${await res.text()}`);
      return res.json();
    },
    { method, url, body },
  ) as Promise<T>;
}

/** The sidebar row (not the whole subtree) of the page with this exact title. */
export const treeRow = (page: Page, title: string) => page.getByRole("tree", { name: "Workspace" }).getByRole("link", { name: title, exact: true }).locator("xpath=..");

/** Create a page through the API and open it. */
export async function newPage(page: Page, workspaceId: string, title: string, parentId: string | null = null) {
  const r = await apiJson<{ page: { id: string } }>(page, "POST", "/api/pages", { workspaceId, title, parentId });
  return r.page.id;
}

export async function waitForSaved(page: Page) {
  await expect(page.locator("header [aria-live]")).toHaveText(/Saved|Live/, { timeout: 15_000 });
}

/**
 * Wait until the editor has picked up a caret move to the end of the document. ProseMirror reads
 * clicks and navigation keys from the browser's async `selectionchange` event, and Playwright can
 * press the next key before that event is handled (no human types that fast).
 */
export async function caretAtEnd(page: Page) {
  await expect
    .poll(() =>
      page.evaluate(() => {
        const ed = (document.querySelector(".ProseMirror") as unknown as { editor?: { state: { selection: { from: number }; doc: { content: { size: number } } } } }).editor;
        return !!ed && ed.state.selection.from === ed.state.doc.content.size - 1;
      }),
    )
    .toBe(true);
}

/** Wait until the editor's cursor is inside the top-level block containing `text` (see caretAtEnd). */
export async function caretInBlock(page: Page, text: string) {
  await expect
    .poll(() =>
      page.evaluate((t) => {
        const ed = (document.querySelector(".ProseMirror") as unknown as { editor?: { state: { selection: { from: number }; doc: { resolve: (p: number) => { node: (d: number) => { textContent: string } } } } } }).editor;
        if (!ed) return false;
        return ed.state.doc.resolve(ed.state.selection.from).node(1)?.textContent.includes(t) ?? false;
      }, text),
    )
    .toBe(true);
}
