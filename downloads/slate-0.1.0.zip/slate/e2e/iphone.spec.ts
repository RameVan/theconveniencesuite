// Slate at iPhone size (Chrome with the iPhone 13 profile: viewport, touch, mobile layout).
import { test, expect, devices, type Page } from "@playwright/test";
import { signUp, apiJson } from "./helpers";

const iphone = devices["iPhone 13"];
test.use({ viewport: iphone.viewport, userAgent: iphone.userAgent, deviceScaleFactor: 2, isMobile: true, hasTouch: true });

/** Text fields under 16px make iPhone Safari zoom in (and a Home Screen app stays zoomed). */
const smallFields = (page: Page) =>
  page.evaluate(() =>
    [...document.querySelectorAll("input, textarea, select")]
      .filter((e) => (e as HTMLElement).offsetParent !== null && !["checkbox", "radio", "range", "hidden"].includes((e as HTMLInputElement).type))
      .map((e) => `${e.tagName.toLowerCase()} ${(e as HTMLInputElement).name || (e as HTMLInputElement).placeholder || ""}: ${getComputedStyle(e).fontSize}`)
      .filter((s) => parseFloat(s.split(": ")[1]) < 16),
  );

test("works as an iPhone app: no zooming fields, fits the screen, drawer sidebar", async ({ page }) => {
  await page.goto("/signup");
  expect(await smallFields(page)).toEqual([]);
  const { workspaceId } = await signUp(page, "Phone User");
  const id = (await apiJson<{ page: { id: string } }>(page, "POST", "/api/pages", { workspaceId, title: "Groceries" })).page.id;
  await page.goto(`/w/${workspaceId}/p/${id}`);
  await expect(page.getByLabel("Page title")).toHaveValue("Groceries");
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(iphone.viewport.width);

  // The sidebar opens as a drawer, without desktop keyboard hints.
  await page.getByRole("button", { name: /Open sidebar/ }).click();
  const tree = page.getByRole("tree", { name: "Workspace" });
  await expect(tree.getByRole("link", { name: "Groceries" })).toBeVisible();
  await expect(page.locator(".kbd-hint").first()).toBeHidden();
  await tree.getByRole("link", { name: "Tasks", exact: true }).click();
  await expect(page.getByRole("table")).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(iphone.viewport.width);

  // Search and settings dialogs: fields stay at 16px or more.
  await page.getByRole("button", { name: /Open sidebar/ }).click();
  await page.getByRole("navigation", { name: "Sidebar" }).getByRole("button", { name: "Search" }).click();
  await expect(page.getByPlaceholder(/Search/)).toBeVisible();
  expect(await smallFields(page)).toEqual([]);
});

test("on a touch screen, the block with the cursor gets an options button to move and change it", async ({ page }) => {
  const { workspaceId } = await signUp(page, "Thumb");
  const id = (await apiJson<{ page: { id: string } }>(page, "POST", "/api/pages", { workspaceId, title: "Phone edits" })).page.id;
  const p = (pid: string, t: string) => ({ id: pid, content: { type: "paragraph", content: [{ type: "text", text: t }] } });
  await apiJson(page, "PUT", `/api/pages/${id}/content`, { blocks: [p("one", "First line"), p("two", "Second line"), p("three", "Third line")] });
  await page.goto(`/w/${workspaceId}/p/${id}`);
  const editor = page.locator(".ProseMirror");
  await editor.getByText("Third line").tap();
  const options = page.getByRole("button", { name: "Block options" });
  await expect(options).toBeVisible();
  // It sits inside the screen, right of the text.
  const box = (await options.boundingBox())!;
  expect(box.x + box.width).toBeLessThanOrEqual(page.viewportSize()!.width);
  await options.tap();
  await page.getByRole("menuitem", { name: "Move up" }).tap();
  await expect(editor.locator("p")).toHaveText(["First line", "Third line", "Second line"]);

  await editor.getByText("Third line").tap();
  await page.getByRole("button", { name: "Block options" }).tap();
  await page.getByRole("menuitem", { name: "Turn into" }).tap();
  await page.getByRole("menuitem", { name: "Heading 2" }).tap();
  await expect(editor.locator("h2")).toHaveText("Third line");
});

test("the formatting toolbar for selected text fits on the phone screen", async ({ page }) => {
  const { workspaceId } = await signUp(page, "Formatter");
  const id = (await apiJson<{ page: { id: string } }>(page, "POST", "/api/pages", { workspaceId, title: "Format" })).page.id;
  await apiJson(page, "PUT", `/api/pages/${id}/content`, { blocks: [{ id: "a", content: { type: "paragraph", content: [{ type: "text", text: "Make this word bold please" }] } }] });
  await page.goto(`/w/${workspaceId}/p/${id}`);
  await page.locator(".ProseMirror").getByText("Make this word").tap();
  // Select "word" the way a long-press would.
  await page.evaluate(() => {
    const ed = (document.querySelector(".ProseMirror") as unknown as { editor: { chain: () => { focus: () => { setTextSelection: (r: { from: number; to: number }) => { run: () => void } } } } }).editor;
    ed.chain().focus().setTextSelection({ from: 11, to: 15 }).run();
  });
  const bold = page.getByRole("button", { name: "Bold" });
  await expect(bold).toBeVisible();
  const bar = (await bold.locator("xpath=..").boundingBox())!;
  expect(bar.x).toBeGreaterThanOrEqual(0);
  expect(bar.x + bar.width).toBeLessThanOrEqual(page.viewportSize()!.width);
  await bold.tap();
  await expect(page.locator(".ProseMirror strong")).toHaveText("word");
});
