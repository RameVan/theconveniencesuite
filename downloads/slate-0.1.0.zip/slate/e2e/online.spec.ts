// Embeds and bookmarks against real websites. Needs internet: npm run test:online
import { test, expect } from "@playwright/test";
import { signUp, apiJson } from "./helpers";

test.skip(!process.env.SLATE_ONLINE_TESTS, "needs internet (npm run test:online)");

test("YouTube and Vimeo embeds load their players; bookmarks show the page's title", async ({ page }) => {
  const { workspaceId } = await signUp(page, "Online");
  const id = (await apiJson<{ page: { id: string } }>(page, "POST", "/api/pages", { workspaceId, title: "Links" })).page.id;
  await apiJson(page, "PUT", `/api/pages/${id}/content`, {
    blocks: [
      { id: "yt", content: { type: "embed", attrs: { url: "https://www.youtube.com/watch?v=jNQXAC9IVRw" } } },
      { id: "vm", content: { type: "embed", attrs: { url: "https://vimeo.com/76979871" } } },
      { id: "bm", content: { type: "bookmark", attrs: { url: null } } },
    ],
  });
  await page.goto(`/w/${workspaceId}/p/${id}`);

  const yt = page.locator('iframe[src^="https://www.youtube-nocookie.com/embed/jNQXAC9IVRw"]');
  const vm = page.locator('iframe[src^="https://player.vimeo.com/video/76979871"]');
  await expect(yt).toBeVisible();
  await expect(vm).toBeVisible();
  // The players really load (lazy frames: scroll each into view, then wait for its document).
  for (const sel of ['iframe[src^="https://www.youtube-nocookie.com/"]', 'iframe[src^="https://player.vimeo.com/"]']) {
    await page.locator(sel).scrollIntoViewIfNeeded();
    await expect(page.frameLocator(sel).locator("body")).toBeVisible({ timeout: 20_000 });
  }

  // Bookmark: paste a link, the preview fills in from the real page.
  await page.getByPlaceholder("Paste a link to create a bookmark").fill("https://example.com");
  await page.keyboard.press("Enter");
  await expect(page.locator(".ProseMirror a[href='https://example.com/']")).toContainText("Example Domain", { timeout: 20_000 });
});
