import { test, expect } from "@playwright/test";
import { signUp, apiJson, newPage, caretAtEnd } from "./helpers";

test("two people edit the same page live and see each other", async ({ page, browser }) => {
  // Owner sets up a page and invites a second user into the workspace.
  const { workspaceId } = await signUp(page, "Ada");
  const id = await newPage(page, workspaceId, "Shared plan");
  const guestContext = await browser.newContext();
  const guest = await guestContext.newPage();
  const { email } = await signUp(guest, "Grace");
  const inv = await apiJson<{ path: string }>(page, "POST", `/api/workspaces/${workspaceId}/invitations`, { email, role: "editor" });
  const token = inv.path.split("/").filter(Boolean).pop()!;
  await apiJson(guest, "POST", `/api/invitations/${token}`);

  const url = `/w/${workspaceId}/p/${id}`;
  await page.goto(url);
  await guest.goto(url);
  const status = (p: typeof page) => p.locator("header [aria-live]");
  await expect(status(page)).toHaveText(/Live/, { timeout: 20_000 });
  await expect(status(guest)).toHaveText(/Live/, { timeout: 20_000 });

  // Presence: each sees the other in the top bar.
  await expect(page.getByLabel(/Also here: .*Grace/)).toBeVisible();
  await expect(guest.getByLabel(/Also here: .*Ada/)).toBeVisible();

  // Ada types; Grace sees it without reloading, and vice versa.
  await page.locator(".ProseMirror").click();
  await page.keyboard.type("Hello from Ada");
  await expect(guest.locator(".ProseMirror")).toContainText("Hello from Ada");
  await guest.locator(".ProseMirror").click();
  await guest.keyboard.press("Control+End");
  await caretAtEnd(guest);
  await guest.keyboard.press("Enter");
  await guest.keyboard.type("Reply from Grace");
  await expect(page.locator(".ProseMirror")).toContainText("Reply from Grace");

  // Remote caret label is shown.
  await expect(page.locator(".collaboration-carets__label", { hasText: "Grace" })).toBeVisible();

  // Both edits are persisted once, in order.
  await expect
    .poll(async () => JSON.stringify((await apiJson<{ content: unknown[] }>(page, "GET", `/api/pages/${id}`)).content), { timeout: 15_000 })
    .toMatch(/Hello from Ada.*Reply from Grace/);
  const text = JSON.stringify((await apiJson<{ content: unknown[] }>(page, "GET", `/api/pages/${id}`)).content);
  expect(text.split("Hello from Ada").length).toBe(2);
  await guestContext.close();
});

test("a page that fell back to saving without realtime switches to live once it is reachable", async ({ page }) => {
  let reachable = false;
  const attempts = { refused: 0, connected: 0 };
  await page.routeWebSocket(/:\d+\/?$/, (ws) => {
    if (reachable) {
      attempts.connected++;
      ws.connectToServer();
    } else {
      attempts.refused++;
      ws.close({ code: 1013, reason: "unavailable" });
    }
  });
  const { workspaceId } = await signUp(page, "Offline Olivia");
  const id = await newPage(page, workspaceId, "Patchy network");
  await page.goto(`/w/${workspaceId}/p/${id}`);
  const status = page.locator("header [aria-live]");

  // Realtime is unreachable: edits are saved over REST.
  await page.locator(".ProseMirror").click();
  await page.keyboard.type("Written while realtime was down");
  await expect(status).toHaveText(/Saved/, { timeout: 15_000 });
  await expect(status).not.toHaveText(/Live/);
  expect(attempts.refused).toBeGreaterThan(0);

  // Once the realtime server is reachable again the page switches over without a reload.
  reachable = true;
  await expect(status).toHaveText(/Live/, { timeout: 30_000 });
  expect(attempts.connected).toBeGreaterThan(0);
  await expect(page.locator(".ProseMirror")).toHaveText("Written while realtime was down");
  await page.locator(".ProseMirror").click();
  await page.keyboard.press("Control+End");
  await caretAtEnd(page);
  await page.keyboard.type(" and after");
  await expect
    .poll(async () => JSON.stringify((await apiJson<{ content: unknown[] }>(page, "GET", `/api/pages/${id}`)).content), { timeout: 15_000 })
    .toContain("Written while realtime was down and after");
  await page.reload();
  await expect(page.locator(".ProseMirror")).toHaveText("Written while realtime was down and after");
});
