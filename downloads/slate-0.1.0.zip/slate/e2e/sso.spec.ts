import { test, expect } from "@playwright/test";
import http from "node:http";
import { apiJson } from "./helpers";

// A real OpenID Connect provider (oidc-provider) on the issuer the e2e server is configured with.
type Account = { email: string; email_verified: boolean; name: string };
const accounts: Record<string, Account> = {};
let loginAs = "";
let server: http.Server;

test.beforeAll(async () => {
  const { default: Provider } = await import("oidc-provider");
  const issuer = "http://127.0.0.1:3299";
  const provider = new Provider(issuer, {
    clients: [{ client_id: "slate-e2e", client_secret: "e2e-secret", redirect_uris: ["http://127.0.0.1:3200/api/auth/oidc/callback"], grant_types: ["authorization_code"], response_types: ["code"] }],
    findAccount: async (_ctx, id) => ({ accountId: id, claims: async () => ({ sub: id, ...accounts[id] }) }),
    claims: { openid: ["sub"], email: ["email", "email_verified"], profile: ["name"] },
    features: { devInteractions: { enabled: false } },
    interactions: { url: (_ctx, interaction) => `/interaction/${interaction.uid}` },
    cookies: { keys: ["e2e-cookie-key"] },
  });
  const callback = provider.callback();
  server = http.createServer(async (req, res) => {
    if (req.url?.startsWith("/interaction/")) {
      // Stand-in for the provider's login screen: the person signs in as `loginAs`.
      const details = await provider.interactionDetails(req, res);
      const grant = new provider.Grant({ accountId: loginAs, clientId: "slate-e2e" });
      grant.addOIDCScope(String(details.params.scope));
      await provider.interactionFinished(req, res, { login: { accountId: loginAs }, consent: { grantId: await grant.save() } }, { mergeWithLastSubmission: false });
      return;
    }
    callback(req, res);
  });
  await new Promise<void>((r) => server.listen(3299, "127.0.0.1", r));
});
test.afterAll(() => server?.close());

test("sign in with single sign-on, sign out, and sign in again", async ({ page }) => {
  accounts.lin = { email: `lin-${Date.now()}@example.com`, email_verified: true, name: "Lin Park" };
  loginAs = "lin";
  await page.goto("/login");
  await page.getByRole("link", { name: "Continue with Test SSO" }).click();
  await page.waitForURL(/\/w\/[0-9a-f-]+/);
  await expect(page.getByRole("tree", { name: "Workspace" })).toBeVisible();
  const me = await apiJson<{ user: { id: string; email: string; name: string } }>(page, "GET", "/api/auth/me");
  expect(me.user).toMatchObject({ email: accounts.lin.email, name: "Lin Park" });

  await page.context().clearCookies();
  await page.goto("/login");
  await page.getByRole("link", { name: "Continue with Test SSO" }).click();
  await page.waitForURL(/\/w\/[0-9a-f-]+/);
  expect((await apiJson<{ user: { id: string } }>(page, "GET", "/api/auth/me")).user.id).toBe(me.user.id);
});

test("a provider without a verified email gets a clear message", async ({ page }) => {
  accounts.anon = { email: "anon@example.com", email_verified: false, name: "Anon" };
  loginAs = "anon";
  await page.goto("/login");
  await page.getByRole("link", { name: "Continue with Test SSO" }).click();
  await expect(page.getByRole("alert").filter({ hasText: "did not share a verified email" })).toBeVisible();
  await expect(page).toHaveURL(/\/login/);
});
