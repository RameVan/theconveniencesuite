import { test, expect } from "@playwright/test";
import { signUp, apiJson, newPage, treeRow } from "./helpers";

test("sidebar drag-and-drop nests and reorders pages", async ({ page }) => {
  const { workspaceId } = await signUp(page, "Organizer");
  const alpha = await newPage(page, workspaceId, "Alpha");
  const beta = await newPage(page, workspaceId, "Beta");
  await page.reload();
  const tree = page.getByRole("tree", { name: "Workspace" });
  await expect(tree.getByRole("link", { name: "Beta" })).toBeVisible();

  // Drop Beta onto the middle of Alpha → Beta becomes a sub-page of Alpha.
  await treeRow(page, "Beta").dragTo(treeRow(page, "Alpha"));
  await expect.poll(async () => (await apiJson<{ page: { parentId: string | null } }>(page, "GET", `/api/pages/${beta}`)).page.parentId).toBe(alpha);
  await expect(tree.getByRole("treeitem", { name: /Alpha$/ }).getByRole("group").getByRole("link", { name: "Beta", exact: true })).toBeVisible();

  // Drag Beta back out, above "Getting started" (top edge) → top level, first position.
  const gs = treeRow(page, "Getting started");
  await treeRow(page, "Beta").dragTo(gs, { targetPosition: { x: 40, y: 2 } });
  await expect.poll(async () => (await apiJson<{ page: { parentId: string | null } }>(page, "GET", `/api/pages/${beta}`)).page.parentId).toBeNull();
  await expect(tree.getByRole("treeitem").first()).toContainText("Beta");
});

test("search, trash and restore", async ({ page }) => {
  const { workspaceId } = await signUp(page, "Finder");
  const id = await newPage(page, workspaceId, "Quarterly zebra report");
  await page.reload();

  await page.keyboard.press("Control+K");
  await page.getByPlaceholder(/Search/).fill("zebra");
  await expect(page.getByRole("option", { name: /Quarterly zebra report/ })).toBeVisible();
  await page.keyboard.press("Enter");
  await page.waitForURL(new RegExp(`/p/${id}`));

  // Move to trash from the page menu, then restore from the Trash dialog.
  await page.getByRole("button", { name: "More actions" }).click();
  await page.getByRole("menuitem", { name: "Move to Trash" }).click();
  await expect(page.getByText("This page is in the Trash.")).toBeVisible();
  await page.getByRole("button", { name: "Trash" }).click();
  const dialog = page.getByRole("dialog", { name: "Trash" });
  await expect(dialog.getByText("Quarterly zebra report")).toBeVisible();
  await dialog.getByRole("button", { name: "Restore" }).click();
  await expect(dialog.getByText("The trash is empty.")).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(page.getByRole("tree", { name: "Workspace" }).getByRole("link", { name: "Quarterly zebra report" })).toBeVisible();
});

test("public link shows the page read-only to anonymous visitors", async ({ page, browser }) => {
  const { workspaceId } = await signUp(page, "Publisher");
  const id = await newPage(page, workspaceId, "Public handbook");
  await apiJson(page, "PUT", `/api/pages/${id}/content`, { blocks: [{ id: "b1", content: { type: "paragraph", content: [{ type: "text", text: "Welcome, visitor" }] } }] });
  await page.goto(`/w/${workspaceId}/p/${id}`);
  await page.getByRole("button", { name: "Share" }).click();
  await page.getByRole("switch").click();
  const link = await page.locator('input[readonly]').inputValue();
  expect(link).toContain("/share/");

  const anon = await browser.newContext();
  const visitor = await anon.newPage();
  await visitor.goto(link);
  await expect(visitor.getByRole("heading", { name: "Public handbook" })).toBeVisible();
  await expect(visitor.locator(".ProseMirror")).toContainText("Welcome, visitor");
  await expect(visitor.locator(".ProseMirror")).toHaveAttribute("contenteditable", "false");
  // The private app is not reachable for the visitor.
  const res = await visitor.request.get(`/api/pages/${id}`);
  expect(res.status()).toBe(401);
  await anon.close();
});

test("import a Notion export from Settings and follow its links", async ({ page }) => {
  const { zipSync, strToU8 } = await import("fflate");
  const home = "Team Home 0123456789abcdef0123456789abcdef";
  const proj = "Projects 11111111111111111111111111111111";
  const tasks = "Tasks 33333333333333333333333333333333";
  const enc = (s: string) => encodeURIComponent(s).replace(/%2F/g, "/");
  const zip = zipSync({
    [`${home}.md`]: strToU8(`# Team Home\n\nStart with [Projects](${enc(`${home}/${proj}.md`)}).\n`),
    [`${home}/${proj}.md`]: strToU8(`# Projects\n\nAll our projects.\n`),
    [`${home}/${tasks}_all.csv`]: strToU8(`Name,Status\nWrite spec,Done\nShip it,Not started\n`),
    [`${home}/${tasks}/Write spec 44444444444444444444444444444444.md`]: strToU8(`# Write spec\n\nStatus: Done\n\nThe details.\n`),
  });
  await signUp(page, "Importer");
  await page.getByRole("navigation", { name: "Sidebar" }).getByRole("button", { name: "Import", exact: true }).click();
  await page.locator('input[type="file"]').setInputFiles({ name: "Export-abc.zip", mimeType: "application/zip", buffer: Buffer.from(zip) });
  await expect(page.getByText("Import complete")).toBeVisible({ timeout: 20_000 });
  await expect(page.getByText(/2 pages, 1 databases, 2 records/)).toBeVisible();
  await page.getByRole("button", { name: "Open imported content" }).click();
  await expect(page.getByLabel("Page title")).toHaveValue("Team Home");
  const href = await page.locator(".ProseMirror a", { hasText: "Projects" }).getAttribute("href");
  expect(href).toMatch(/^\/w\/[0-9a-f-]+\/p\/[0-9a-f-]+$/);
  await page.goto(href!);
  await expect(page.getByLabel("Page title")).toHaveValue("Projects");
  // The database sits under Team Home, with the record page holding its body.
  const tree = page.getByRole("tree", { name: "Workspace" });
  await expect(tree.getByRole("treeitem", { name: /Team Home$/ }).getByRole("group").getByRole("link", { name: "Tasks", exact: true })).toBeAttached();
});

test("Slate can be installed as an app (manifest and icons)", async ({ page, request }) => {
  await page.goto("/login");
  const href = await page.locator('link[rel="manifest"]').getAttribute("href");
  expect(href).toBeTruthy();
  const manifest = await (await request.get(href!)).json();
  expect(manifest).toMatchObject({ name: "Slate", display: "standalone", start_url: "/" });
  expect(manifest.icons.map((i: { sizes: string; purpose: string }) => `${i.sizes} ${i.purpose}`)).toEqual(["192x192 any", "512x512 any", "512x512 maskable"]);
  const apple = await page.locator('link[rel="apple-touch-icon"]').getAttribute("href");
  for (const src of [...manifest.icons.map((i: { src: string }) => i.src), apple]) {
    const res = await request.get(src);
    expect(res.status(), src).toBe(200);
    expect(res.headers()["content-type"]).toContain("image/png");
  }
});

test("passwords can be shown while typing, and forgotten passwords have a way back", async ({ page }) => {
  await page.goto("/signup");
  const field = page.getByLabel("Password", { exact: true });
  await field.fill("my-secret-pass");
  await expect(field).toHaveAttribute("type", "password");
  await page.getByRole("button", { name: "Show password" }).click();
  await expect(field).toHaveAttribute("type", "text");
  await expect(field).toHaveValue("my-secret-pass");
  await page.getByRole("button", { name: "Hide password" }).click();
  await expect(field).toHaveAttribute("type", "password");

  await page.goto("/login");
  await page.getByRole("link", { name: "Forgot password?" }).click();
  await page.waitForURL(/\/forgot-password$/);
  await page.getByLabel("Email").fill("someone@example.com");
  await page.getByRole("button", { name: "Send reset link" }).click();
  // The test server has no email set up, and says so.
  await expect(page.getByRole("status")).toContainText("can’t send email");

  await page.goto("/reset-password?token=not-a-real-token-123");
  await page.getByLabel("New password", { exact: true }).fill("whatever-1234");
  await page.getByRole("button", { name: "Set new password" }).click();
  await expect(page.getByRole("alert").filter({ hasText: "invalid" })).toBeVisible();
});

test("favorites can be reordered by dragging or from their menu", async ({ page }) => {
  const { workspaceId } = await signUp(page, "Collector");
  for (const title of ["Red", "Green", "Blue"]) {
    const id = await newPage(page, workspaceId, title);
    await apiJson(page, "PUT", `/api/pages/${id}/favorite`);
  }
  await page.reload();
  const favs = page.getByRole("group", { name: "Favorites" });
  const order = () => favs.getByRole("link").allInnerTexts();
  await expect.poll(order).toEqual(["Red", "Green", "Blue"]);

  // Drag Blue onto the top half of Red → first.
  const row = (t: string) => favs.getByRole("link", { name: t, exact: true }).locator("xpath=..");
  await row("Blue").dragTo(row("Red"), { targetPosition: { x: 40, y: 4 } });
  await expect.poll(order).toEqual(["Blue", "Red", "Green"]);

  // Touch and keyboard users: "Move down" in the row's menu.
  await favs.getByRole("button", { name: "More actions for Blue" }).click();
  await page.getByRole("menuitem", { name: "Move down" }).click();
  await expect.poll(order).toEqual(["Red", "Blue", "Green"]);

  // The order is stored: it survives a reload.
  await page.reload();
  await expect.poll(order).toEqual(["Red", "Blue", "Green"]);
});
