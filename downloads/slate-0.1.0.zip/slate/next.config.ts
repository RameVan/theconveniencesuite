import type { NextConfig } from "next";

const securityHeaders = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "X-Frame-Options", value: "SAMEORIGIN" },
  { key: "Content-Security-Policy", value: "frame-ancestors 'self'; object-src 'none'; base-uri 'self'" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
];

const nextConfig: NextConfig = {
  // The editor and database views keep large client state; routes must unmount predictably.
  cacheComponents: false,
  output: "standalone",
  poweredByHeader: false,
  serverExternalPackages: ["@electric-sql/pglite", "pg", "@aws-sdk/client-s3", "@hocuspocus/server", "yjs", "ws", "nodemailer"],
  // Runtime data and development files never belong in the deployable bundle.
  // SQL migrations are read from disk at startup.
  outputFileTracingIncludes: { "/**": ["drizzle/**/*"] },
  outputFileTracingExcludes: {
    "/**": ["data/**/*", "tests/**/*", "docs/**/*", "scripts/**/*", ".git/**/*", "src/**/*", "*.md", "Dockerfile", "docker-compose.yml"],
  },
  turbopack: {
    rules: {
      "*.css": {
        loaders: ["@tailwindcss/turbopack"],
        as: "*.css",
      },
    },
  },
  async headers() {
    return [{ source: "/:path*", headers: securityHeaders }];
  },
};

export default nextConfig;
