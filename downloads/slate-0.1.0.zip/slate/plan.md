# Slate — full implementation plan

Slate is a self-hosted, block-based workspace (pages, block editor, databases) with **no
subscription feature gates**. This file lists every step needed to build it. A box is ticked only
when the step is implemented **and** verified (tests and/or a check in the browser).

Legend: `[x]` done and verified · `[~]` implemented, partly verified or with known limits · `[ ]` not started.
Status notes: `docs/progress.md` · design decisions: `docs/architecture.md` · feature map: `docs/feature-matrix.md`.

---

## Phase 0 — Research and design
- [x] 0.1 Inspect the project directory (it was empty) and the toolchain (Node 24, npm, git; no Docker or PostgreSQL installed locally)
- [x] 0.2 Survey the `makenotion` GitHub organization: repositories, licenses, purpose
- [x] 0.3 Confirm the org does not contain the Notion app source; treat the repos as reference only
- [x] 0.4 Collect property types and filter vocabulary from `notion-sdk-js` types
- [x] 0.5 Read the bundled Next.js 16 docs (route handlers, cacheComponents, config, instrumentation, tracing)
- [x] 0.6 Choose the editor (Tiptap 3, MIT) and the database layer (Drizzle + PostgreSQL / PGlite)
- [x] 0.7 Write `docs/research.md`
- [x] 0.8 Write `docs/architecture.md` (data model, authorization, storage trade-offs)
- [x] 0.9 Write `docs/implementation-plan.md` (milestones)
- [x] 0.10 Write `docs/feature-matrix.md` (every Notion feature → Slate implementation → status)
- [x] 0.11 Create `docs/progress.md` and keep it current

## Phase 1 — Foundation
### 1A. Project scaffold
- [x] 1A.1 Next.js 16 + React 19 + TypeScript + Tailwind 4 + ESLint scaffold
- [x] 1A.2 Install pinned dependencies (Drizzle, pg, PGlite, zod, Tiptap 3, lowlight, KaTeX, cmdk, fflate, marked, lucide-react, swr, AWS S3 client)
- [x] 1A.3 Initialise a git repository
- [x] 1A.4 `next.config.ts`: cacheComponents off, `serverExternalPackages`, security headers, `output: "standalone"`, tracing includes/excludes
- [x] 1A.5 Vitest config and npm scripts (`test`, `test:pg`, `typecheck`, `lint`, `db:generate`, `db:migrate`, `files:cleanup`)
- [x] 1A.6 `.env.example` with every setting documented and no secrets
- [x] 1A.7 `.gitignore` / `.dockerignore` for `data/`, `.env`, build output

### 1B. Database layer
- [x] 1B.1 Drizzle schema: users, sessions, api_tokens, workspaces, workspace_members, invitations, pages, blocks, database_properties, database_views, relation_links, page_permissions, page_revisions, favorites, page_visits, files, comments, audit_events
- [x] 1B.2 Full-text `tsvector` generated columns + GIN indexes on page titles and block text
- [x] 1B.3 Connection factory: `postgres://` → node-postgres pool, otherwise embedded PGlite (`memory://` for tests)
- [x] 1B.4 Generate the initial SQL migration; verified on PGlite and real PostgreSQL
- [x] 1B.5 Migrations applied automatically at startup (`instrumentation.ts`) and via `npm run db:migrate`
- [x] 1B.6 Statement timeout and pool size configurable; UTF8 encoding enforced

### 1C. HTTP infrastructure
- [x] 1C.1 `api()` route wrapper: JSON parsing with a size limit, zod validation errors → 400, typed errors → 401/403/404/409/413/429
- [x] 1C.2 CSRF protection: an `Origin` check on cookie-authenticated mutations
- [x] 1C.3 Per-IP rate limiter (a general limit plus a stricter one for auth endpoints)
- [x] 1C.4 Request logging without page content or secrets
- [x] 1C.5 Security headers (nosniff, frame-ancestors, referrer policy, permissions policy)

### 1D. Authentication
- [x] 1D.1 Password hashing with scrypt and constant-time verification
- [x] 1D.2 Sign-up (the first user becomes the instance admin; `ALLOW_SIGNUP` switch; invitations bypass it)
- [x] 1D.3 Log in / log out with an HttpOnly session cookie that stores only the token hash in the DB
- [x] 1D.4 Sliding session expiry; list and revoke sessions
- [x] 1D.5 Personal API tokens (create, list, revoke; `Authorization: Bearer`)
- [x] 1D.6 Change name and password; delete account (documented data handling)
- [x] 1D.7 Login and sign-up pages

### 1E. Workspaces
- [x] 1E.1 Create a workspace (the creator is owner) and seed it with starter content
- [x] 1E.2 List my workspaces; rename; change icon; delete (owner only, typed confirmation)
- [x] 1E.3 Workspace switcher in the sidebar
- [x] 1E.4 Remember the last-opened workspace

### 1F. Page hierarchy
- [x] 1F.1 Create page (root or child), with fractional `position`
- [x] 1F.2 Get page with breadcrumbs, access level, and children
- [x] 1F.3 Update title / icon / cover / full-width / small-text
- [x] 1F.4 Move page (re-parent and reorder via `beforeId`/`afterId`) with cycle prevention
- [x] 1F.5 Sidebar tree API (accessible non-record pages only)
- [x] 1F.6 Sidebar UI: expand/collapse, Private / Workspace / Shared / Favorites sections, database records listed under databases
- [x] 1F.7 Drag-and-drop reorder and re-parent in the sidebar (E2E)
- [x] 1F.8 Page context menu: rename, duplicate, copy link, favourite, open in new tab, delete
- [x] 1F.9 Breadcrumbs in the page header

### 1G. Deployment
- [x] 1G.1 Multi-stage `Dockerfile` (standalone output, non-root user, migrations) — image built and run
- [x] 1G.2 `docker-compose.yml` with PostgreSQL 17, app, volumes — E2E suite passes against it
- [x] 1G.3 Health-check endpoint `/api/health`

## Phase 2 — Block editor
### 2A. Block model
- [x] 2A.1 One row per top-level block: `(page_id, id, position, type, content JSONB, text)`
- [x] 2A.2 Allow-list validation of node and mark types; sanitise link URLs (http/https/mailto/tel/relative only)
- [x] 2A.3 Plain-text extraction for search
- [x] 2A.4 Save endpoint: diff (insert / update / delete), transactional, `baseVersion` check → 409 on conflict
- [x] 2A.5 Store a conflict copy as a revision so rejected edits are never lost
- [x] 2A.6 Load endpoint returns the blocks as a document

### 2B. Editor core (Tiptap)
- [x] 2B.1 Paragraphs, headings H1–H3, bulleted / numbered / nested lists, to-do lists
- [x] 2B.2 Bold, italic, underline, strikethrough, inline code, links, text colour, highlight
- [x] 2B.3 Quote, divider, code block with syntax highlighting and a language picker
- [x] 2B.4 Tables (insert, resize, header row)
- [x] 2B.5 Block-ID plugin: a unique, stable `id` on every top-level node, duplicates fixed on paste/split
- [x] 2B.6 Placeholder text
- [x] 2B.7 Markdown shortcuts (`#`, `-`, `1.`, `[]`, `>`, ```` ``` ````, `---`, `**bold**`, `$x$`, …)
- [x] 2B.8 Undo / redo
- [x] 2B.9 Paste from external apps (HTML and plain text), with a sanitised schema

### 2C. Custom blocks
- [x] 2C.1 Callout (emoji + coloured background, editable content)
- [x] 2C.2 Toggle (collapsible, persisted open state, nested content)
- [x] 2C.3 Block equation (KaTeX) and inline equation
- [x] 2C.4 Image (upload, URL, caption, resize)
- [x] 2C.5 File attachment block (upload, download link, size)
- [x] 2C.6 Video and audio (uploaded file or URL; YouTube/Vimeo iframes) — players checked online (`npm run test:online`)
- [x] 2C.7 Bookmark with URL preview (server unfurl with SSRF protection) — checked online (`npm run test:online`)
- [x] 2C.8 Table of contents (live from headings, click to scroll)
- [x] 2C.9 Breadcrumb block
- [x] 2C.10 Child-page block (creates a sub-page; shows its live title and icon; deleting the block trashes the page with Undo)
- [x] 2C.11 Inline database block / linked database view block

### 2D. Editor interactions
- [x] 2D.1 Slash menu with search, keyboard navigation, and every block type
- [x] 2D.2 Floating format toolbar on selection (marks, link, colour, turn into, inline equation)
- [x] 2D.3 Block drag handle (⋮⋮) with drag-to-reorder and a block menu (delete, duplicate, turn into, colour, copy link, move up/down); right-click menu; touch options button — E2E
- [x] 2D.4 Multi-block selection: select across blocks, delete, format
- [x] 2D.5 Autosave (debounced) with a "Saving… / Saved / Offline / Changed elsewhere" indicator
- [x] 2D.6 Save on page hide/unload (keepalive request) — E2E (`e2e/fallback.spec.ts`)
- [x] 2D.7 Poll for newer versions while idle and refresh without losing local edits — E2E

### 2E. Page chrome
- [x] 2E.1 Editable title (Enter moves focus into the body; auto-sizing)
- [x] 2E.2 Icon picker (emoji grid with search, random, remove, uploaded image)
- [x] 2E.3 Cover (gradients, colours, upload, URL, reposition, remove)
- [x] 2E.4 Page options: full width, small text

## Phase 3 — Database engine
### 3A. Schema
- [x] 3A.1 Create a database (full page or inline) with a default schema and table view
- [x] 3A.2 Property CRUD: add, rename (formulas updated), change type (with value conversion), delete (views scrubbed), reorder
- [x] 3A.3 All 21 property types incl. unique ID (prefix, atomic counter)
- [x] 3A.4 Typed value validation on write
- [x] 3A.5 Select / status option management (add, rename, recolour, regroup, reorder, delete)

### 3B. Records
- [x] 3B.1 Create a record (optionally from a template, optionally with initial values)
- [x] 3B.2 Update property values inline
- [x] 3B.3 Records open as full pages (properties panel above the editor)
- [x] 3B.4 Delete (trash) / restore / duplicate records, bulk delete from the table
- [x] 3B.5 Record templates (default template, picker on "New", edit templates)

### 3C. Query engine
- [x] 3C.1 Filter tree with AND/OR groups, with operators per type
- [x] 3C.2 Relative date filters (today, this week, past/next week, month, year)
- [x] 3C.3 Multi-key sorts (all types, empty values last)
- [x] 3C.4 Grouping (select, status, multi-select, checkbox, person, relation, text, date by month), hide empty groups
- [x] 3C.5 Aggregations (count, empty / not-empty, unique, sum, average, median, min, max, range, earliest, latest, % checked …)
- [x] 3C.6 Quick search within a database
- [x] 3C.7 Manual ordering (drag rows) when no sort is set — E2E

### 3D. Relations, rollups, formulas
- [x] 3D.1 Relation property to any database in the workspace (including itself)
- [x] 3D.2 Two-way relations with a synced property on the target, kept consistent in transactions
- [x] 3D.3 Relation picker UI with search and "create new"
- [x] 3D.4 Rollups (20 functions)
- [x] 3D.5 Formula grammar documented in `docs/formulas.md`
- [x] 3D.6 Tokenizer and Pratt parser with positioned errors
- [x] 3D.7 Type checker (number, text, boolean, date, list, empty)
- [x] 3D.8 Evaluator with a step budget (no `eval`)
- [x] 3D.9 Function library: math, text, logic, dates, lists, conversion, lambdas, `let`
- [x] 3D.10 Formula dependencies, cycle detection (save-time within a database, compute-time across relations)
- [x] 3D.11 Formula editor with live type check, error messages and function reference

### 3E. Views
- [x] 3E.1 View CRUD (add, rename, change layout, duplicate, delete, reorder by dragging or Move left/right) — E2E
- [x] 3E.2 Table: inline editing, column resize, reorder, hide, wrap, footer aggregations, add row / column — E2E
- [x] 3E.3 Board: group by select / status / multi-select / person / checkbox, drag cards between columns — E2E
- [x] 3E.4 List view
- [x] 3E.5 Gallery: cover from page cover / files property, card size
- [x] 3E.6 Calendar: month grid by date property, create on a day, drag to reschedule — E2E
- [x] 3E.7 Timeline: bars from a date range or end-date property, zoom, drag to move/resize — E2E
- [x] 3E.8 Chart: column / bar / line / donut by group, counts or aggregated values
- [x] 3E.9 View toolbar: filter, sort, group, properties, layout, search, new record
- [x] 3E.10 Linked database views — show an existing database elsewhere, with their own per-block views

## Phase 4 — Product completeness
### 4A. Search
- [x] 4A.1 Search service: titles, block text, database titles, record titles, text property values
- [x] 4A.2 Prefix FTS + ILIKE fallback, ranked, with snippets and paths
- [x] 4A.3 Permission filtering (never return inaccessible content)
- [x] 4A.4 Filters: content type (page / database / record), workspace
- [x] 4A.5 Search modal (Ctrl/Cmd+K) with keyboard navigation, previews, and recent pages
- [x] 4A.6 Command palette actions (new page/database, templates, theme, sidebar, settings, import, export, trash, shortcuts)

### 4B. Favourites and recents
- [x] 4B.1 Favourite / unfavourite, ordered favourites section — reorder by dragging or Move up/down
- [x] 4B.2 Record page visits; recently visited list (home and search)

### 4C. Templates
- [x] 4C.1 Page templates (meeting notes, project brief, weekly journal, product spec)
- [x] 4C.2 Database templates (task tracker, CRM, reading list, roadmap)
- [x] 4C.3 Starter workspace content
- [x] 4C.4 Duplicate page / database (deep copy with new IDs; relations remapped inside the copy)

### 4D. Files
- [x] 4D.1 Storage adapter interface; local disk driver
- [~] 4D.2 S3-compatible driver (lazy-loaded AWS SDK) — not run against an S3 service here
- [x] 4D.3 Upload endpoint: size limit, MIME sniffing, SHA-256, workspace scoping
- [x] 4D.4 Download endpoint with an access check, safe `Content-Disposition` and sandbox CSP
- [x] 4D.5 Paste and drop uploads in the editor (paste verified)
- [x] 4D.6 Unreferenced-file cleanup (`npm run files:cleanup`, optional schedule)
- [x] 4D.7 Storage usage display and a warning threshold

### 4E. Trash
- [x] 4E.1 Archive a page subtree (`archived_root_id`), hidden everywhere
- [x] 4E.2 Trash list with filter; restore (to the original parent, or the top level if the parent is gone)
- [x] 4E.3 Permanent delete (with confirmation); optional retention purge

### 4F. Version history
- [x] 4F.1 Snapshot policy (interval, hash de-duplication)
- [x] 4F.2 History panel: list revisions with time and author
- [x] 4F.3 Preview a revision (read-only render)
- [x] 4F.4 Restore (snapshot the current state first; relations restored only to existing targets)

### 4G. Import / export
- [x] 4G.1 Block JSON → Markdown converter (with a loss report)
- [x] 4G.2 Markdown → block JSON parser (via the `marked` lexer)
- [x] 4G.3 Block JSON → HTML (escaped, standalone document)
- [x] 4G.4 Page export: Markdown, HTML, ZIP with sub-pages
- [x] 4G.5 Database export: CSV (computed values, formula-injection guard)
- [x] 4G.6 Workspace export: ZIP with full-fidelity JSON + Markdown + CSV + files + `loss-report.md`
- [x] 4G.7 Markdown import (single files or a ZIP with folders → page tree, relative images uploaded)
- [x] 4G.8 CSV import → new database (type inference) or into an existing database
- [x] 4G.9 JSON / ZIP import: validation, ID remapping, never overwrites, import report
- [x] 4G.10 Import / export UI

## Phase 5 — Collaboration and hardening
### 5A. Members and sharing
- [x] 5A.1 Member list, change role, remove member, leave (owner protections)
- [x] 5A.2 Invitations: create link (token hash stored), list, revoke, accept flow (sign-up or log-in)
- [x] 5A.3 Page share panel: per-user access (full / edit / view / none), private vs. workspace
- [x] 5A.4 Permission inheritance with explicit overrides (nearest grant wins)
- [x] 5A.5 Public read-only link (`/share/<token>`), admin switch `ALLOW_PUBLIC_SHARING`
- [x] 5A.6 Public share renders sub-pages, databases and records read-only
- [x] 5A.7 Comments on pages (add, resolve, delete)

### 5B. Server-side authorization coverage
- [x] 5B.1 Every service function checks access
- [x] 5B.2 IDOR tests: guessing IDs across workspaces / private pages fails
- [x] 5B.3 Search, relation pickers, rollups and breadcrumbs never leak inaccessible titles
- [x] 5B.4 Audit events for security-relevant actions

### 5C. Concurrency
- [x] 5C.1 Versioned saves + 409 handling in the UI (metadata edits do not cause false conflicts)
- [x] 5C.2 Test: concurrent saves never lose data
- [x] 5C.3 (Milestone 6) Realtime co-editing with Yjs + Hocuspocus + presence (see Phase 6)

### 5D. Settings and UX polish
- [x] 5D.1 Settings: account, sessions, API tokens, workspace, members, import/export, storage
- [x] 5D.2 Light / dark / system theme (no flash)
- [x] 5D.3 Keyboard shortcuts and a shortcut help panel
- [x] 5D.4 Responsive layout: collapsible / resizable sidebar, mobile drawer
- [x] 5D.5 Empty states, loading skeletons, toasts with undo
- [x] 5D.6 Confirmation for destructive actions
- [x] 5D.7 Accessible menus, dialogs (focus trap, Escape), tree roles, labels — axe-core WCAG 2.1 AA scan of the main screens in light and dark mode (`e2e/accessibility.spec.ts`)

### 5E. Testing
- [x] 5E.1 Unit: formula tokenizer / parser / type checker / evaluator / functions / safety
- [x] 5E.2 Filters, sorts, grouping, aggregations, property validation (integration)
- [x] 5E.3 Markdown / HTML / CSV converters
- [x] 5E.4 Auth, sessions, tokens
- [x] 5E.5 Page create / nest / move / duplicate / archive / restore / delete
- [x] 5E.6 Database schema changes, records, relations (two-way), rollups
- [x] 5E.7 Revisions and restore
- [x] 5E.8 Import / export round trip
- [x] 5E.9 API: permission enforcement through the route handlers
- [x] 5E.10 Scale: 200 databases, 5,001 records, 120-level nesting, 3,000-block page
- [x] 5E.11 No plan gating: static check that the codebase has no plan/tier checks
- [x] 5E.12 Large operations fail atomically (transaction rollback test)
- [x] 5E.13 End-to-end workflow in a real browser — automated Playwright suite (`e2e/`, 6.2)

### 5F. Documentation
- [x] 5F.1 README: features, quick start, Docker Compose, configuration, troubleshooting
- [x] 5F.2 `docs/api.md`
- [x] 5F.3 `docs/formulas.md`
- [x] 5F.4 `docs/operations.md`: migrations, backups, restore, limits, scaling
- [x] 5F.5 `docs/security.md`: threat model, controls
- [x] 5F.6 `docs/progress.md`
- [x] 5F.7 Final run: typecheck, lint, tests, migrations, production build — all green

## Phase 6 — After v1 (planned)
- [x] 6.1 Realtime co-editing (Yjs, Hocuspocus, presence cursors)
  - [x] 6.1a Shared editor schema for browser and server (`src/lib/editor-schema.ts`)
  - [x] 6.1b `page_ydocs` table + migration; Yjs state stored with the page version it matches
  - [x] 6.1c Realtime server in `instrumentation.ts`: cookie auth, `requirePage`, read-only viewers, Origin check, rate limit
  - [x] 6.1d Persist to the block table via `saveContent` (history, search, export unchanged); block ids enforced
  - [x] 6.1e REST writes (restore, API save) pushed into open documents
  - [x] 6.1f No duplication when clients reconnect after REST writes or server restarts
  - [x] 6.1g Client: Collaboration + live carets, presence avatars, "Live" status, automatic REST fallback
  - [x] 6.1h Tests: two clients converge, viewer read-only, outsiders/foreign origins rejected, persistence, restarts
  - [x] 6.1i Docs: ports, proxy setup, security notes
- [x] 6.2 Automated Playwright end-to-end suite (`e2e/`): editor, sidebar, search/trash, public link, database views and all drag interactions, two-browser realtime
  - [x] 6.2b Fallback clients retry realtime in the background and switch to live editing without reload
  - [x] 6.2a CI workflow (`.github/workflows/ci.yml`) running every check including E2E — not yet run on GitHub
- [x] 6.3 SQL push-down of filters/sorts and virtualised rows for very large databases (paged queries; calendar, timeline and chart still load every record)
- [x] 6.4 Per-block linked view settings (new linked blocks own copies of the views; older blocks keep the database's)
- [x] 6.5 Inline comments anchored to text ranges and @-mentions of people with notifications
- [x] 6.6 Importer for Notion's own Markdown/CSV export ZIP (pages, databases + record pages, links, images, nested ZIPs)
- [x] 6.7 SSO (OIDC) as an optional, ungated auth provider (tested against a local OpenID provider)
- [x] 6.8 Shared rate-limit store for multi-instance deployments (`RATE_LIMIT_STORE=database`)
