import { defineConfig } from "@playwright/test";

// End-to-end tests against the production build. `npm run test:e2e` builds nothing: run
// `npm run build` first. Uses an installed Chrome by default (PW_CHANNEL=msedge for Edge,
// PW_CHANNEL=chromium after `npx playwright install chromium`).
const port = process.env.E2E_PORT || "3200";

export default defineConfig({
  testDir: "./e2e",
  timeout: 90_000,
  expect: { timeout: 10_000 },
  fullyParallel: false,
  workers: 1,
  retries: 0,
  reporter: [["list"]],
  use: {
    baseURL: `http://127.0.0.1:${port}`,
    channel: process.env.PW_CHANNEL === "chromium" ? undefined : (process.env.PW_CHANNEL ?? "chrome"),
    viewport: { width: 1280, height: 860 },
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
  },
  outputDir: "test-results",
  webServer: {
    command: "node scripts/e2e-server.mjs",
    url: `http://127.0.0.1:${port}/api/health`,
    reuseExistingServer: false,
    timeout: 120_000,
  },
});
