import base from "./playwright.config";
import { defineConfig } from "@playwright/test";

// The E2E suite against an already running Docker Compose stack (no local server is started):
//   SLATE_PORT=3300 SLATE_COLLAB_PORT=3301 docker compose up -d   (see docs/operations.md)
//   npx playwright test -c playwright.docker.config.ts
// Single sign-on is skipped: it needs an OpenID provider configured for the stack.
const url = process.env.E2E_BASE_URL || "http://127.0.0.1:3300";

export default defineConfig({
  ...base,
  testIgnore: ["**/sso.spec.ts"],
  use: { ...base.use, baseURL: url },
  webServer: undefined,
});
