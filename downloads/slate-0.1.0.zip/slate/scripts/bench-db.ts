// Database query benchmark on a throwaway PostgreSQL (embedded-postgres) or BENCH_DATABASE_URL.
// Usage: npx tsx scripts/bench-db.ts [records=50000]
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { sql } from "drizzle-orm";
import { createDb, setDbHandle } from "../src/server/db";
import { pages } from "../src/server/db/schema";
import { signup, createSession, type Actor } from "../src/server/services/auth";
import { createWorkspace } from "../src/server/services/workspaces";
import { createPage } from "../src/server/services/pages";
import { addProperty, loadDatabaseMeta, queryDatabase } from "../src/server/services/databases";
import { newId } from "../src/server/crypto";
import { Computer, runQuery } from "../src/server/services/compute";
import { AccessResolver } from "../src/server/services/permissions";

const N = Number(process.argv[2] ?? 50_000);

async function main() {
  let url = process.env.BENCH_DATABASE_URL;
  let stop = async () => {};
  if (!url) {
    const { default: EmbeddedPostgres } = await import("embedded-postgres");
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "slate-bench-"));
    const port = 55000 + Math.floor(Math.random() * 900);
    const pg = new EmbeddedPostgres({ databaseDir: dir, user: "slate", password: "slate", port, persistent: false, initdbFlags: ["--encoding=UTF8", "--locale=C"], onLog: () => {} });
    await pg.initialise();
    await pg.start();
    await pg.createDatabase("slate_bench");
    url = `postgres://slate:slate@127.0.0.1:${port}/slate_bench`;
    stop = async () => {
      await pg.stop();
      fs.rmSync(dir, { recursive: true, force: true });
    };
  }
  const h = await createDb(url);
  setDbHandle(h);
  try {
    const user = await signup(h.db, { email: "bench@example.com", password: "password123", name: "Bench" }, { bypassSignupSwitch: true });
    const s = await createSession(h.db, user.id);
    const actor: Actor = { userId: user.id, sessionId: s.sessionId, via: "session" };
    const ws = await createWorkspace(h.db, actor, { name: "Bench", starter: false });
    const dbPage = await createPage(h.db, actor, { workspaceId: ws.id, kind: "database", title: "Big" });
    const amount = await addProperty(h.db, actor, dbPage.id, { name: "Amount", type: "number" });
    const stage = await addProperty(h.db, actor, dbPage.id, { name: "Stage", type: "select", config: { options: ["Lead", "Qualified", "Won", "Lost"].map((n, i) => ({ id: `o${i}`, name: n, color: "blue" })) } });
    const due = await addProperty(h.db, actor, dbPage.id, { name: "Due", type: "date" });
    const done = await addProperty(h.db, actor, dbPage.id, { name: "Done", type: "checkbox" });
    await addProperty(h.db, actor, dbPage.id, { name: "Score", type: "formula", config: { expression: 'prop("Amount") * 2' } });

    const t = Date.now();
    for (let i = 0; i < N; i += 1000) {
      const rows = Array.from({ length: Math.min(1000, N - i) }, (_, k) => {
        const n = i + k;
        return {
          id: newId(),
          workspaceId: ws.id,
          databaseId: dbPage.id,
          kind: "page" as const,
          title: `Record ${n}`,
          position: n,
          properties: { [amount.id]: (n * 7919) % 10_000, [stage.id]: `o${n % 4}`, [due.id]: { start: `2026-${String((n % 12) + 1).padStart(2, "0")}-15` }, [done.id]: n % 3 === 0 },
          createdBy: user.id,
          updatedBy: user.id,
        };
      });
      await h.db.insert(pages).values(rows);
    }
    await h.db.execute(sql`ANALYZE pages`);
    console.log(`inserted ${N} records in ${Date.now() - t} ms`);

    const meta = await loadDatabaseMeta(h.db, dbPage.id);
    const view = meta.views[0];
    const run = async (label: string, config: Record<string, unknown>, search?: string, page?: { limit: number; offset?: number; groupLimit?: number }) => {
      const times: number[] = [];
      let size = 0;
      let rows = 0;
      for (let i = 0; i < 3; i++) {
        const t0 = Date.now();
        const r = await queryDatabase(h.db, actor, dbPage.id, { viewId: view.id, config, search, ...page });
        times.push(Date.now() - t0);
        size = JSON.stringify(r).length;
        rows = r.rows.length;
      }
      console.log(`${label.padEnd(34)} rows=${String(rows).padStart(6)}  json=${(size / 1e6).toFixed(1).padStart(5)} MB  ms=${times.join(", ")}`);
    };
    // Where the time goes (default view).
    {
      const lap = (() => { let t0 = Date.now(); return () => { const d = Date.now() - t0; t0 = Date.now(); return d; }; })();
      const computer = new Computer(h.db);
      const resolver = await AccessResolver.load(h.db, ws.id, actor.userId);
      const tAccess = lap();
      computer.canView = (id) => resolver.canView(id);
      const props = await computer.loadProps(dbPage.id);
      const records = (await computer.loadRecords(dbPage.id)).filter((r) => resolver.canView(r.id));
      const tLoad = lap();
      await computer.prepare(dbPage.id, records.map((r) => r.id));
      const tPrep = lap();
      const result = runQuery({ props, records, computer, config: view.config });
      const tRun = lap();
      const json = JSON.stringify(result);
      const tJson = lap();
      console.log(`profile: access=${tAccess}ms load=${tLoad}ms prepare=${tPrep}ms runQuery=${tRun}ms stringify=${tJson}ms (${(json.length / 1e6).toFixed(1)} MB)`);
    }
    await run("all rows (default view)", {});
    await run("filter Stage=Won, sort Amount desc", {
      filter: { kind: "group", id: "g", op: "and", filters: [{ kind: "condition", id: "c", propertyId: stage.id, operator: "equals", value: "o2" }] },
      sorts: [{ propertyId: amount.id, direction: "desc" }],
    });
    await run("search 'Record 4999'", {}, "Record 4999");
    await run("group by Stage", { groupBy: stage.id });
    {
      const t0 = Date.now();
      for (let i = 0; i < 3; i++)
        await h.db.execute(sql`select md5(string_agg(id || ':' || position || ':' || updated_at::text || ':' || coalesce(archived_at::text, '') || ':' || is_template::text, ',' order by id)) as v from pages where database_id = ${dbPage.id}`);
      console.log(`fingerprint query: ${((Date.now() - t0) / 3).toFixed(0)} ms`);
    }
    console.log("--- paged (limit 100), as the app requests it:");
    const filtered = {
      filter: { kind: "group", id: "g", op: "and", filters: [{ kind: "condition", id: "c", propertyId: stage.id, operator: "equals", value: "o2" }] },
      sorts: [{ propertyId: amount.id, direction: "desc" }],
    };
    await run("first page, default view", {}, undefined, { limit: 100 });
    await run("page at offset 40000", {}, undefined, { limit: 100, offset: 40_000 });
    await run("filter + sort (SQL)", filtered, undefined, { limit: 100 });
    await run("date filter (SQL)", { filter: { kind: "group", id: "g", op: "and", filters: [{ kind: "condition", id: "d", propertyId: due.id, operator: "on_or_after", value: "2026-06-01" }] } }, undefined, { limit: 100 });
    await run("sort by title (in memory)", { sorts: [{ propertyId: meta.properties.find((p) => p.type === "title")!.id, direction: "asc" }] }, undefined, { limit: 100 });
    await run("search (in memory)", {}, "Record 4999", { limit: 100 });
    await run("group by Stage (25 per group)", { groupBy: stage.id }, undefined, { limit: 100, groupLimit: 25 });
  } finally {
    await h.close();
    await stop();
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
