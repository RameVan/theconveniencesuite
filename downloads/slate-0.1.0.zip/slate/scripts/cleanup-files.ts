// Delete uploaded files that nothing references any more (and are older than 24 hours),
// and purge trash older than TRASH_RETENTION_DAYS when that is set.
// Usage: npm run files:cleanup [-- --min-age-hours=48]
import { createDb } from "../src/server/db";
import { cleanupUnreferencedFiles } from "../src/server/services/files";
import { purgeExpiredTrash } from "../src/server/services/pages";
import { config } from "../src/server/config";

async function main() {
  const arg = process.argv.find((a) => a.startsWith("--min-age-hours="));
  const minAge = arg ? Number(arg.split("=")[1]) : 24;
  const handle = await createDb();
  const purged = await purgeExpiredTrash(handle.db, config.trashRetentionDays);
  const removed = await cleanupUnreferencedFiles(handle.db, minAge);
  console.log(`Purged ${purged} expired trash item(s); removed ${removed} unreferenced file(s).`);
  await handle.close();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
