// Starts the production (standalone) build on a throwaway data directory for end-to-end tests.
// Run `npm run build` first. Used by playwright.config.ts.
import { spawn } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const standalone = path.join(root, ".next", "standalone");
if (!fs.existsSync(path.join(standalone, "server.js"))) {
  console.error("No production build found. Run `npm run build` first.");
  process.exit(1);
}
// The standalone server serves static assets from its own folder.
fs.cpSync(path.join(root, ".next", "static"), path.join(standalone, ".next", "static"), { recursive: true });
fs.cpSync(path.join(root, "public"), path.join(standalone, "public"), { recursive: true });
// Next copies the project's .env files into the build; tests must never use real settings
// (mail server, public URL, sign-in provider), so remove them.
for (const f of fs.readdirSync(standalone)) if (/^\.env/.test(f)) fs.rmSync(path.join(standalone, f));

const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), "slate-e2e-"));
const port = process.env.E2E_PORT || "3200";
const child = spawn(process.execPath, ["server.js"], {
  cwd: standalone,
  stdio: "inherit",
  env: {
    ...process.env,
    NODE_ENV: "production",
    PORT: port,
    HOSTNAME: "127.0.0.1",
    COLLAB_PORT: process.env.E2E_COLLAB_PORT || "3201",
    COLLAB_HOST: "127.0.0.1",
    DATA_DIR: dataDir,
    DATABASE_URL: "",
    SECURE_COOKIES: "false",
    AUTH_RATE_LIMIT_PER_MINUTE: "500",
    RATE_LIMIT_PER_MINUTE: "10000",
    REVISION_INTERVAL_SECONDS: "0",
    SLATE_LOG_REQUESTS: "0",
    // Explicitly off, whatever the environment says: no real email, no real public URL.
    SMTP_URL: "",
    APP_URL: "",
    // Single sign-on against the OpenID provider that e2e/sso.spec.ts starts on this port.
    OIDC_ISSUER: process.env.E2E_OIDC_ISSUER || "http://127.0.0.1:3299",
    OIDC_CLIENT_ID: "slate-e2e",
    OIDC_CLIENT_SECRET: "e2e-secret",
    OIDC_DISPLAY_NAME: "Test SSO",
  },
});
const stop = () => {
  child.kill();
  setTimeout(() => fs.rmSync(dataDir, { recursive: true, force: true }), 500);
};
process.on("SIGINT", stop);
process.on("SIGTERM", stop);
child.on("exit", (code) => process.exit(code ?? 0));
