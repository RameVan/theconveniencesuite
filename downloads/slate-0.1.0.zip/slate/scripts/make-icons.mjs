// Generates the PNG app icons used when Slate is installed on a phone or desktop
// (public/icons/*). Run after changing the artwork: node scripts/make-icons.mjs
import fs from "node:fs";
import sharp from "sharp";

const BG = "#2f2d29";
// The three lines of the Slate mark, drawn in a 64x64 box.
const glyph = (scale, offset) =>
  `<g transform="translate(${offset} ${offset}) scale(${scale})"><path d="M20 22h24M20 32h24M20 42h14" stroke="#fff" stroke-width="5" stroke-linecap="round" fill="none"/></g>`;

// Rounded square, as on the web (any purpose).
const rounded = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="${BG}"/>${glyph(1, 0)}</svg>`;
// Full-bleed square with the mark inside the central safe zone (maskable icons, Apple touch icon):
// launchers cut their own shape, so nothing important may sit near the edges.
const fullBleed = (contentScale) => {
  const offset = (64 - 64 * contentScale) / 2;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" fill="${BG}"/>${glyph(contentScale, offset)}</svg>`;
};

fs.mkdirSync("public/icons", { recursive: true });
const out = [
  ["public/icons/icon-192.png", rounded, 192],
  ["public/icons/icon-512.png", rounded, 512],
  ["public/icons/maskable-512.png", fullBleed(0.8), 512],
  ["public/icons/apple-touch-icon.png", fullBleed(0.9), 180],
];
for (const [file, svg, size] of out) {
  await sharp(Buffer.from(svg), { density: 1200 }).resize(size, size).png().toFile(file);
  console.log(`${file} (${size}x${size})`);
}
