// Apply database migrations: `npm run db:migrate` (uses DATABASE_URL, or the embedded PGlite database).
import { createDb } from "../src/server/db";

async function main() {
  const handle = await createDb(undefined, { migrate: true });
  console.log(`Migrations applied (${handle.driver}).`);
  await handle.close();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
