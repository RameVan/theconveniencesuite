import { NextResponse } from "next/server";
import { z } from "zod";
import { api, SESSION_COOKIE } from "@/server/http";
import { deleteAccount } from "@/server/services/auth";

export const DELETE = api(
  async (ctx) => {
    const body = await ctx.body(z.object({ password: z.string().optional(), email: z.string().optional() }));
    await deleteAccount(ctx.db, ctx.actor, body);
    const res = NextResponse.json({ ok: true });
    res.cookies.set({ name: SESSION_COOKIE, value: "", path: "/", maxAge: 0 });
    return res;
  },
  { limit: "auth" },
);
