import { NextResponse } from "next/server";
import { z } from "zod";
import { api, sessionCookie } from "@/server/http";
import { login, createSession } from "@/server/services/auth";

export const POST = api(
  async (ctx) => {
    const body = await ctx.body(z.object({ email: z.string().max(400), password: z.string().max(400) }));
    const user = await login(ctx.db, body);
    const s = await createSession(ctx.db, user.id, ctx.req.headers.get("user-agent"));
    const res = NextResponse.json({ user });
    res.cookies.set(sessionCookie(s.token, s.expiresAt));
    return res;
  },
  { auth: "optional", limit: "auth" },
);
