import { NextResponse } from "next/server";
import { api, SESSION_COOKIE } from "@/server/http";
import { deleteSession } from "@/server/services/auth";

export const POST = api(
  async (ctx) => {
    if (ctx.actor?.sessionId) await deleteSession(ctx.db, ctx.actor.sessionId);
    const res = NextResponse.json({ ok: true });
    res.cookies.set({ name: SESSION_COOKIE, value: "", path: "/", maxAge: 0 });
    return res;
  },
  { auth: "optional" },
);
