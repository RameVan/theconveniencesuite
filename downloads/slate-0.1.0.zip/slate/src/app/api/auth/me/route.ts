import { z } from "zod";
import { api } from "@/server/http";
import { updateProfile, countUsers } from "@/server/services/auth";
import { config } from "@/server/config";
import { emailEnabled } from "@/server/services/email";

export const GET = api(
  async (ctx) => ({
    user: ctx.user,
    signupAllowed: config.allowSignup || (await countUsers(ctx.db)) === 0,
    publicSharing: config.allowPublicSharing,
    maxUploadBytes: config.maxUploadBytes,
    realtime: config.realtimeEnabled ? { port: config.collabPublicPort, url: config.collabPublicUrl } : null,
    sso: config.oidc ? { name: config.oidc.displayName } : null,
    email: emailEnabled(),
  }),
  { auth: "optional" },
);

export const PATCH = api(async (ctx) => {
  const body = await ctx.body(z.object({ name: z.string().optional(), avatarUrl: z.string().nullable().optional(), emailNotifications: z.boolean().optional() }));
  return { user: await updateProfile(ctx.db, ctx.actor, body) };
});
