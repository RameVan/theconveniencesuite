import { NextResponse } from "next/server";
import { api, sessionCookie, requestOrigin } from "@/server/http";
import { AppError } from "@/server/errors";
import { createSession } from "@/server/services/auth";
import { createWorkspace } from "@/server/services/workspaces";
import { finishOidc, oidcRedirectUri, OIDC_COOKIE } from "@/server/services/oidc";

/** The identity provider sends the browser back here with a code. */
export const GET = api(
  async (ctx) => {
    const base = requestOrigin(ctx.req);
    // Rebuild the callback URL on the registered redirect URI (proxies may change the host).
    const callback = new URL(oidcRedirectUri(base));
    callback.search = ctx.req.nextUrl.search;
    try {
      const { user, created, next } = await finishOidc(ctx.db, callback, ctx.req.cookies.get(OIDC_COOKIE)?.value);
      const s = await createSession(ctx.db, user.id, ctx.req.headers.get("user-agent"));
      if (created) await createWorkspace(ctx.db, { userId: user.id, sessionId: s.sessionId, via: "session" }, { name: user.name.split(" ")[0] + "'s workspace" });
      const res = NextResponse.redirect(new URL(next ?? "/", base));
      res.cookies.set(sessionCookie(s.token, s.expiresAt));
      res.cookies.delete({ name: OIDC_COOKIE, path: "/api/auth/oidc" });
      return res;
    } catch (e) {
      const message = e instanceof AppError ? e.message : "Sign-in failed. Please try again.";
      const res = NextResponse.redirect(new URL(`/login?error=${encodeURIComponent(message)}`, base));
      res.cookies.delete({ name: OIDC_COOKIE, path: "/api/auth/oidc" });
      return res;
    }
  },
  { auth: "optional", limit: "auth" },
);
