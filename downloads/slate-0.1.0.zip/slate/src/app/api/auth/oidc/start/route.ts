import { NextResponse } from "next/server";
import { api, requestOrigin } from "@/server/http";
import { config } from "@/server/config";
import { startOidc, oidcRedirectUri, OIDC_COOKIE } from "@/server/services/oidc";

/** Redirects the browser to the identity provider. */
export const GET = api(
  async (ctx) => {
    const flow = await startOidc(oidcRedirectUri(requestOrigin(ctx.req)), ctx.query("next"));
    const res = NextResponse.redirect(flow.url);
    res.cookies.set({ name: OIDC_COOKIE, value: flow.cookie, httpOnly: true, sameSite: "lax", secure: config.secureCookies, path: "/api/auth/oidc", maxAge: flow.maxAge });
    return res;
  },
  { auth: "optional", limit: "auth" },
);
