import { z } from "zod";
import { api } from "@/server/http";
import { requestPasswordReset } from "@/server/services/password-reset";

export const POST = api(async (ctx) => requestPasswordReset(ctx.db, await ctx.body(z.object({ email: z.string().max(300) }))), { auth: "optional", limit: "auth" });
