import { api } from "@/server/http";
import { resetPassword, resetInput } from "@/server/services/password-reset";

export const POST = api(async (ctx) => resetPassword(ctx.db, await ctx.body(resetInput)), { auth: "optional", limit: "auth" });
