import { z } from "zod";
import { api } from "@/server/http";
import { changePassword } from "@/server/services/auth";

export const POST = api(
  async (ctx) => {
    const body = await ctx.body(z.object({ currentPassword: z.string().optional(), newPassword: z.string() }));
    await changePassword(ctx.db, ctx.actor, body);
    return { ok: true };
  },
  { limit: "auth" },
);
