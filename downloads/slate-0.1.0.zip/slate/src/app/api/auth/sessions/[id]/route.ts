import { api } from "@/server/http";
import { revokeSession } from "@/server/services/auth";

export const DELETE = api<{ id: string }>(async (ctx, { id }) => {
  await revokeSession(ctx.db, ctx.actor, id);
  return { ok: true };
});
