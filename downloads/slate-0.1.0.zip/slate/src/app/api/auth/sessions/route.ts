import { api } from "@/server/http";
import { listSessions, revokeOtherSessions } from "@/server/services/auth";

export const GET = api(async (ctx) => ({ sessions: await listSessions(ctx.db, ctx.actor) }));
export const DELETE = api(async (ctx) => {
  await revokeOtherSessions(ctx.db, ctx.actor);
  return { ok: true };
});
