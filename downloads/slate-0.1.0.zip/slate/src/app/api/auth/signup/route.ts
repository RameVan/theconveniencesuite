import { NextResponse } from "next/server";
import { z } from "zod";
import { api, sessionCookie } from "@/server/http";
import { signup, createSession } from "@/server/services/auth";
import { previewInvitation, acceptInvitation, createWorkspace } from "@/server/services/workspaces";

export const POST = api(
  async (ctx) => {
    const body = await ctx.body(z.object({ email: z.string(), password: z.string(), name: z.string(), inviteToken: z.string().max(200).optional() }));
    let invited = false;
    if (body.inviteToken) {
      const inv = await previewInvitation(ctx.db, body.inviteToken);
      invited = inv.email === body.email.trim().toLowerCase();
    }
    const user = await signup(ctx.db, body, { bypassSignupSwitch: invited });
    const s = await createSession(ctx.db, user.id, ctx.req.headers.get("user-agent"));
    const actor = { userId: user.id, sessionId: s.sessionId, via: "session" as const };
    let workspaceId: string | null = null;
    if (invited && body.inviteToken) workspaceId = (await acceptInvitation(ctx.db, actor, body.inviteToken)).workspaceId;
    else workspaceId = (await createWorkspace(ctx.db, actor, { name: user.name.split(" ")[0] + "'s workspace" })).id;
    const res = NextResponse.json({ user, workspaceId });
    res.cookies.set(sessionCookie(s.token, s.expiresAt));
    return res;
  },
  { auth: "optional", limit: "auth" },
);
