import { api } from "@/server/http";
import { revokeApiToken } from "@/server/services/auth";

export const DELETE = api<{ id: string }>(async (ctx, { id }) => {
  await revokeApiToken(ctx.db, ctx.actor, id);
  return { ok: true };
});
