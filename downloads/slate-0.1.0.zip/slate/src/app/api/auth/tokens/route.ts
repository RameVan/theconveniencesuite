import { z } from "zod";
import { api } from "@/server/http";
import { listApiTokens, createApiToken } from "@/server/services/auth";

export const GET = api(async (ctx) => ({ tokens: await listApiTokens(ctx.db, ctx.actor) }));
export const POST = api(async (ctx) => {
  const { name } = await ctx.body(z.object({ name: z.string() }));
  return createApiToken(ctx.db, ctx.actor, name);
});
