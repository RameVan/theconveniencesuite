import { api } from "@/server/http";
import { exportDatabaseCsv } from "@/server/services/transfer";

export const GET = api<{ id: string }>(async (ctx, { id }) => {
  const out = await exportDatabaseCsv(ctx.db, ctx.actor, id, ctx.query("viewId"));
  return new Response(new Uint8Array(out.body), {
    headers: { "content-type": out.contentType, "content-disposition": "attachment; filename*=UTF-8''" + encodeURIComponent(out.filename) },
  });
});
