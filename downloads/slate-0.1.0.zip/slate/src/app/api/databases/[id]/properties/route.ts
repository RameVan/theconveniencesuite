import { api } from "@/server/http";
import { addProperty, addPropertyInput } from "@/server/services/databases";

export const POST = api<{ id: string }>(async (ctx, { id }) => ({ property: await addProperty(ctx.db, ctx.actor, id, await ctx.body(addPropertyInput)) }));
