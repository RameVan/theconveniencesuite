import { api } from "@/server/http";
import { queryDatabase, queryInput } from "@/server/services/databases";

export const POST = api<{ id: string }>(async (ctx, { id }) => queryDatabase(ctx.db, ctx.actor, id, await ctx.body(queryInput)));
