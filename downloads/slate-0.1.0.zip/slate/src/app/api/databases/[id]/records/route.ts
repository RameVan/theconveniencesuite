import { api } from "@/server/http";
import { createRecord, createRecordInput, searchRecords } from "@/server/services/databases";

export const GET = api<{ id: string }>(async (ctx, { id }) => ({ records: await searchRecords(ctx.db, ctx.actor, id, ctx.query("q") ?? "", 50) }));
export const POST = api<{ id: string }>(async (ctx, { id }) => createRecord(ctx.db, ctx.actor, id, await ctx.body(createRecordInput)));
