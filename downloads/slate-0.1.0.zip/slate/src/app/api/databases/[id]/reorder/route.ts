import { z } from "zod";
import { api } from "@/server/http";
import { moveRecord, reorderRecords } from "@/server/services/databases";

const body = z.union([
  // Move one record before another (beforeId null: to the end).
  z.object({ id: z.string().max(100), beforeId: z.string().max(100).nullable() }),
  // Set the order of the given records (positions 1..n).
  z.object({ ids: z.array(z.string()) }),
]);

export const POST = api<{ id: string }>(async (ctx, { id }) => {
  const data = await ctx.body(body);
  if ("ids" in data) await reorderRecords(ctx.db, ctx.actor, id, data.ids);
  else await moveRecord(ctx.db, ctx.actor, id, data.id, data.beforeId);
  return { ok: true };
});
