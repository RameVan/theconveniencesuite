import { z } from "zod";
import { api } from "@/server/http";
import { getDatabase, setDefaultTemplate } from "@/server/services/databases";

export const GET = api<{ id: string }>(async (ctx, { id }) => getDatabase(ctx.db, ctx.actor, id));
export const PATCH = api<{ id: string }>(async (ctx, { id }) => {
  const body = await ctx.body(z.object({ defaultTemplateId: z.string().nullable().optional() }));
  if (body.defaultTemplateId !== undefined) await setDefaultTemplate(ctx.db, ctx.actor, id, body.defaultTemplateId);
  return getDatabase(ctx.db, ctx.actor, id);
});
