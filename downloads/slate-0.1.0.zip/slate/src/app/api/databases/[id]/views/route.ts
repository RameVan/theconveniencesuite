import { api } from "@/server/http";
import { createView, viewInput } from "@/server/services/databases";

export const POST = api<{ id: string }>(async (ctx, { id }) => ({ view: await createView(ctx.db, ctx.actor, id, await ctx.body(viewInput)) }));
