import { api } from "@/server/http";
import { readFile, INLINE_TYPES } from "@/server/services/files";

export const GET = api<{ id: string }>(
  async (ctx, { id }) => {
    const { meta, data } = await readFile(ctx.db, ctx.actor, id, ctx.query("share"));
    const inline = INLINE_TYPES.has(meta.mime) && ctx.query("download") !== "1";
    return new Response(new Uint8Array(data), {
      headers: {
        "content-type": meta.mime,
        "content-length": String(data.length),
        "content-disposition": (inline ? "inline" : "attachment") + "; filename*=UTF-8''" + encodeURIComponent(meta.name),
        "x-content-type-options": "nosniff",
        "content-security-policy": "default-src 'none'; img-src 'self'; media-src 'self'; style-src 'unsafe-inline'; sandbox",
        "cache-control": "private, max-age=31536000, immutable",
      },
    });
  },
  { auth: "optional" },
);
