import { api } from "@/server/http";
import { uploadFile } from "@/server/services/files";
import { badRequest, tooLarge } from "@/server/errors";
import { config } from "@/server/config";

export const POST = api(async (ctx) => {
  const len = Number(ctx.req.headers.get("content-length") || 0);
  if (len > config.maxUploadBytes + 1_000_000) throw tooLarge("Files can be at most " + Math.round(config.maxUploadBytes / 1048576) + " MB on this server (MAX_UPLOAD_BYTES)");
  const form = await ctx.req.formData();
  const file = form.get("file");
  const workspaceId = form.get("workspaceId");
  if (!(file instanceof File) || typeof workspaceId !== "string") throw badRequest("Attach a file and a workspaceId");
  return uploadFile(ctx.db, ctx.actor, workspaceId, { name: file.name, type: file.type, data: Buffer.from(await file.arrayBuffer()) });
});
