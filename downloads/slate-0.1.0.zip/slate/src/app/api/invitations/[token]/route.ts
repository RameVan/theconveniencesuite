import { api } from "@/server/http";
import { previewInvitation, acceptInvitation } from "@/server/services/workspaces";

export const GET = api<{ token: string }>(async (ctx, { token }) => previewInvitation(ctx.db, token), { auth: "optional", limit: "auth" });
export const POST = api<{ token: string }>(async (ctx, { token }) => acceptInvitation(ctx.db, ctx.actor, token), { limit: "auth" });
