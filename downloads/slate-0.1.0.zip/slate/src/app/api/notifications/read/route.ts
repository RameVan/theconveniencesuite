import { api } from "@/server/http";
import { markRead, markReadInput } from "@/server/services/notifications";

export const POST = api(async (ctx) => markRead(ctx.db, ctx.actor, await ctx.body(markReadInput)));
