import { api } from "@/server/http";
import { listNotifications } from "@/server/services/notifications";

export const GET = api(async (ctx) =>
  listNotifications(ctx.db, ctx.actor, { workspaceId: ctx.query("workspaceId") ?? undefined, limit: Number(ctx.query("limit")) || undefined }),
);
