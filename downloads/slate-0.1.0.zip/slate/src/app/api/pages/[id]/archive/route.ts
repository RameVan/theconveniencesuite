import { api } from "@/server/http";
import { archivePage } from "@/server/services/pages";

export const POST = api<{ id: string }>(async (ctx, { id }) => archivePage(ctx.db, ctx.actor, id));
