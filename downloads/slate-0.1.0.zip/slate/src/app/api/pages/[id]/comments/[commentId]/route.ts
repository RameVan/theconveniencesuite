import { z } from "zod";
import { api } from "@/server/http";
import { updateComment, deleteComment } from "@/server/services/comments";

export const PATCH = api<{ id: string; commentId: string }>(async (ctx, { id, commentId }) => {
  await updateComment(ctx.db, ctx.actor, id, commentId, await ctx.body(z.object({ resolved: z.boolean().optional(), body: z.string().optional() })));
  return { ok: true };
});
export const DELETE = api<{ id: string; commentId: string }>(async (ctx, { id, commentId }) => {
  await deleteComment(ctx.db, ctx.actor, id, commentId);
  return { ok: true };
});
