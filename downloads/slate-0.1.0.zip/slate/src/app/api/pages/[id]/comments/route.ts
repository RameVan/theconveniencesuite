import { api } from "@/server/http";
import { listComments, addComment, commentInput } from "@/server/services/comments";

export const GET = api<{ id: string }>(async (ctx, { id }) => ({ comments: await listComments(ctx.db, ctx.actor, id) }));
export const POST = api<{ id: string }>(async (ctx, { id }) => addComment(ctx.db, ctx.actor, id, await ctx.body(commentInput)));
