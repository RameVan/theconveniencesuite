import { api } from "@/server/http";
import { saveContent, saveContentInput } from "@/server/services/pages";
import { notifyContentChanged } from "@/server/collab";

export const PUT = api<{ id: string }>(async (ctx, { id }) => {
  const result = await saveContent(ctx.db, ctx.actor, id, await ctx.body(saveContentInput));
  // Editors connected through the realtime server receive the new content.
  await notifyContentChanged(id).catch((err) => console.error("[collab] notify failed:", err instanceof Error ? err.message : err));
  return result;
});
// sendBeacon/keepalive saves on page unload use POST.
export const POST = PUT;
