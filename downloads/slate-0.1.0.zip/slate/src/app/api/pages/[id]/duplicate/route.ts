import { api } from "@/server/http";
import { duplicatePage } from "@/server/services/pages";

export const POST = api<{ id: string }>(async (ctx, { id }) => ({ page: await duplicatePage(ctx.db, ctx.actor, id) }));
