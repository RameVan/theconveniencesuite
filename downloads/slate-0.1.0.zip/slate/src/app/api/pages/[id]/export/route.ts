import { api } from "@/server/http";
import { exportPage } from "@/server/services/transfer";

export const GET = api<{ id: string }>(async (ctx, { id }) => {
  const fmt = ctx.query("format");
  const format = fmt === "html" ? "html" : fmt === "json" ? "json" : "md";
  const out = await exportPage(ctx.db, ctx.actor, id, format, { subpages: ctx.query("subpages") === "1" });
  return new Response(new Uint8Array(out.body), {
    headers: {
      "content-type": out.contentType,
      "content-disposition": "attachment; filename*=UTF-8''" + encodeURIComponent(out.filename),
    },
  });
});
