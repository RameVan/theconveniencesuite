import { api } from "@/server/http";
import { z } from "zod";
import { setFavorite, moveFavorite } from "@/server/services/pages";

export const PUT = api<{ id: string }>(async (ctx, { id }) => setFavorite(ctx.db, ctx.actor, id, true));
export const DELETE = api<{ id: string }>(async (ctx, { id }) => setFavorite(ctx.db, ctx.actor, id, false));
/** Reorder: { beforeId } puts this favourite before another one (null: last). */
export const PATCH = api<{ id: string }>(async (ctx, { id }) => {
  const { beforeId } = await ctx.body(z.object({ beforeId: z.string().max(100).nullable() }));
  return moveFavorite(ctx.db, ctx.actor, id, beforeId);
});
