import { api } from "@/server/http";
import { movePage, moveInput } from "@/server/services/pages";

export const POST = api<{ id: string }>(async (ctx, { id }) => ({ page: await movePage(ctx.db, ctx.actor, id, await ctx.body(moveInput)) }));
