import { z } from "zod";
import { api } from "@/server/http";
import { setPublicShare } from "@/server/services/sharing";

export const PUT = api<{ id: string }>(async (ctx, { id }) => {
  const { enabled } = await ctx.body(z.object({ enabled: z.boolean() }));
  return setPublicShare(ctx.db, ctx.actor, id, enabled);
});
