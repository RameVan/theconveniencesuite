import { api } from "@/server/http";
import { restorePage } from "@/server/services/pages";

export const POST = api<{ id: string }>(async (ctx, { id }) => restorePage(ctx.db, ctx.actor, id));
