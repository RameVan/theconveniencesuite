import { api } from "@/server/http";
import { getRevision, restoreRevision } from "@/server/services/revisions";
import { notifyContentChanged } from "@/server/collab";

export const GET = api<{ id: string; revId: string }>(async (ctx, { id, revId }) => ({ revision: await getRevision(ctx.db, ctx.actor, id, revId) }));
export const POST = api<{ id: string; revId: string }>(async (ctx, { id, revId }) => {
  const result = await restoreRevision(ctx.db, ctx.actor, id, revId);
  await notifyContentChanged(id).catch((err) => console.error("[collab] notify failed:", err instanceof Error ? err.message : err));
  return result;
});
