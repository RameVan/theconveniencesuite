import { api } from "@/server/http";
import { listRevisions } from "@/server/services/revisions";

export const GET = api<{ id: string }>(async (ctx, { id }) => ({ revisions: await listRevisions(ctx.db, ctx.actor, id) }));
