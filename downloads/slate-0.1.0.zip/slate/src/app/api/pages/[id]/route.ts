import { api } from "@/server/http";
import { getPage, updatePage, updatePageInput, deletePermanently } from "@/server/services/pages";

export const GET = api<{ id: string }>(async (ctx, { id }) => getPage(ctx.db, ctx.actor, id));
export const PATCH = api<{ id: string }>(async (ctx, { id }) => ({ page: await updatePage(ctx.db, ctx.actor, id, await ctx.body(updatePageInput)) }));
export const DELETE = api<{ id: string }>(async (ctx, { id }) => deletePermanently(ctx.db, ctx.actor, id));
