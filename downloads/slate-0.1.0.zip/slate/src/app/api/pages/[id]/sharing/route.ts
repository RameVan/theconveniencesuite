import { api } from "@/server/http";
import { getSharing, setUserAccess, grantInput } from "@/server/services/sharing";

export const GET = api<{ id: string }>(async (ctx, { id }) => getSharing(ctx.db, ctx.actor, id));
export const PUT = api<{ id: string }>(async (ctx, { id }) => setUserAccess(ctx.db, ctx.actor, id, await ctx.body(grantInput)));
