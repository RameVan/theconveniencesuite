import { api } from "@/server/http";
import { getPageVersion } from "@/server/services/pages";

export const GET = api<{ id: string }>(async (ctx, { id }) => getPageVersion(ctx.db, ctx.actor, id));
