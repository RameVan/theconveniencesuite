import { api } from "@/server/http";
import { recordVisit } from "@/server/services/pages";

export const POST = api<{ id: string }>(async (ctx, { id }) => {
  await recordVisit(ctx.db, ctx.actor, id);
  return { ok: true };
});
