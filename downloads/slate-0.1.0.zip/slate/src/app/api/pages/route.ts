import { api } from "@/server/http";
import { createPage, createPageInput, serializePage } from "@/server/services/pages";

export const POST = api(async (ctx) => {
  const page = await createPage(ctx.db, ctx.actor, await ctx.body(createPageInput));
  return { page: serializePage(page, "full") };
});
