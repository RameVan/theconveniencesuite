import { api } from "@/server/http";
import { updateProperty, deleteProperty, updatePropertyInput } from "@/server/services/databases";

export const PATCH = api<{ id: string }>(async (ctx, { id }) => ({ property: await updateProperty(ctx.db, ctx.actor, id, await ctx.body(updatePropertyInput)) }));
export const DELETE = api<{ id: string }>(async (ctx, { id }) => deleteProperty(ctx.db, ctx.actor, id));
