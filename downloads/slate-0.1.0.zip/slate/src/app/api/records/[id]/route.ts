import { api } from "@/server/http";
import { getRecordRow, updateRecord, updateRecordInput } from "@/server/services/databases";

export const GET = api<{ id: string }>(async (ctx, { id }) => getRecordRow(ctx.db, ctx.actor, id));
export const PATCH = api<{ id: string }>(async (ctx, { id }) => updateRecord(ctx.db, ctx.actor, id, await ctx.body(updateRecordInput)));
