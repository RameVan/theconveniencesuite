import { api } from "@/server/http";
import { search } from "@/server/services/search";

export const GET = api(async (ctx) => {
  const type = ctx.query("type");
  const results = await search(ctx.db, ctx.actor, {
    q: ctx.query("q") ?? "",
    workspaceId: ctx.query("workspaceId"),
    type: type === "page" || type === "database" || type === "record" ? type : null,
    limit: Math.min(100, Number(ctx.query("limit") || 30)),
  });
  return { results };
});
