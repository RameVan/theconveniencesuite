import { z } from "zod";
import { api } from "@/server/http";
import { queryPublicDatabase } from "@/server/services/sharing";

export const POST = api<{ token: string }>(
  async (ctx, { token }) => {
    const body = await ctx.body(
      z.object({
        databaseId: z.string().max(100),
        viewId: z.string().max(100).nullable().optional(),
        block: z.object({ pageId: z.string().max(100), blockId: z.string().max(100) }).nullable().optional(),
      }),
    );
    return queryPublicDatabase(ctx.db, token, body.databaseId, body.viewId, body.block);
  },
  { auth: "optional" },
);
