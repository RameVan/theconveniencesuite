import { api } from "@/server/http";
import { getPublicPage } from "@/server/services/sharing";

export const GET = api<{ token: string }>(async (ctx, { token }) => getPublicPage(ctx.db, token, ctx.query("page") ?? undefined), { auth: "optional" });
