import { api } from "@/server/http";
import { listTemplates, applyTemplate, applyTemplateInput } from "@/server/services/templates";
import { serializePage } from "@/server/services/pages";

export const GET = api(async () => ({ templates: listTemplates() }));
export const POST = api(async (ctx) => ({ page: serializePage(await applyTemplate(ctx.db, ctx.actor, await ctx.body(applyTemplateInput)), "full") }));
