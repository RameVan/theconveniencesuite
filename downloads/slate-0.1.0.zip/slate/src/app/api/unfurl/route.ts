import { api, rateLimit } from "@/server/http";
import { unfurl } from "@/server/services/unfurl";
import { badRequest } from "@/server/errors";

export const GET = api(async (ctx) => {
  await rateLimit("unfurl:" + ctx.actor.userId, 60);
  const url = ctx.query("url");
  if (!url) throw badRequest("Missing url");
  return unfurl(url);
});
