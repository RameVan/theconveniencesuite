import { api } from "@/server/http";
import { duplicateView } from "@/server/services/databases";

export const POST = api<{ id: string }>(async (ctx, { id }) => duplicateView(ctx.db, ctx.actor, id));
