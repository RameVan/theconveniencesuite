import { api } from "@/server/http";
import { updateView, deleteView, viewInput } from "@/server/services/databases";

export const PATCH = api<{ id: string }>(async (ctx, { id }) => ({ view: await updateView(ctx.db, ctx.actor, id, await ctx.body(viewInput)) }));
export const DELETE = api<{ id: string }>(async (ctx, { id }) => deleteView(ctx.db, ctx.actor, id));
