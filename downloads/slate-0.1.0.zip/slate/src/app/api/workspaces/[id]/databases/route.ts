import { and, eq, isNull } from "drizzle-orm";
import { api } from "@/server/http";
import { pages } from "@/server/db/schema";
import { AccessResolver } from "@/server/services/permissions";
import { notFound } from "@/server/errors";

// Databases in a workspace (for relation targets and linked views).
export const GET = api<{ id: string }>(async (ctx, { id }) => {
  const resolver = await AccessResolver.load(ctx.db, id, ctx.actor.userId);
  if (!resolver.role) throw notFound("Workspace not found");
  const rows = await ctx.db
    .select({ id: pages.id, title: pages.title, icon: pages.icon })
    .from(pages)
    .where(and(eq(pages.workspaceId, id), eq(pages.kind, "database"), isNull(pages.archivedAt)));
  return { databases: rows.filter((r) => resolver.canView(r.id) && !resolver.isArchived(r.id)) };
});
