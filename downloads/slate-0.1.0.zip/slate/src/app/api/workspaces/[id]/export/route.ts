import { api } from "@/server/http";
import { exportWorkspace } from "@/server/services/transfer";

export const GET = api<{ id: string }>(async (ctx, { id }) => {
  const zip = await exportWorkspace(ctx.db, ctx.actor, id);
  const date = new Date().toISOString().slice(0, 10);
  return new Response(new Uint8Array(zip), {
    headers: {
      "content-type": "application/zip",
      "content-disposition": 'attachment; filename="slate-export-' + date + '.zip"',
    },
  });
});
