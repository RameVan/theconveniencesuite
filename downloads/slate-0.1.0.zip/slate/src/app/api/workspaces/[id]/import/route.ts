import { api } from "@/server/http";
import { importUpload } from "@/server/services/transfer";
import { badRequest, tooLarge } from "@/server/errors";
import { config } from "@/server/config";

export const POST = api<{ id: string }>(async (ctx, { id }) => {
  const len = Number(ctx.req.headers.get("content-length") || 0);
  if (len > config.maxImportBytes + 1_000_000) throw tooLarge("This import is larger than MAX_IMPORT_BYTES");
  const form = await ctx.req.formData();
  const file = form.get("file");
  if (!(file instanceof File)) throw badRequest("Attach a file");
  const parentId = (form.get("parentId") as string) || null;
  const databaseId = (form.get("databaseId") as string) || null;
  const data = Buffer.from(await file.arrayBuffer());
  return importUpload(ctx.db, ctx.actor, id, { name: file.name, data }, { parentId, databaseId });
});
