import { api } from "@/server/http";
import { revokeInvitation } from "@/server/services/workspaces";

export const DELETE = api<{ id: string; invId: string }>(async (ctx, { id, invId }) => {
  await revokeInvitation(ctx.db, ctx.actor, id, invId);
  return { ok: true };
});
