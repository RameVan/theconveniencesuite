import { api } from "@/server/http";
import { listInvitations, createInvitation, inviteInput } from "@/server/services/workspaces";

export const GET = api<{ id: string }>(async (ctx, { id }) => ({ invitations: await listInvitations(ctx.db, ctx.actor, id) }));
export const POST = api<{ id: string }>(async (ctx, { id }) => createInvitation(ctx.db, ctx.actor, id, await ctx.body(inviteInput)));
