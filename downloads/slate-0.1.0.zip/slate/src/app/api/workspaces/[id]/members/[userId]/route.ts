import { z } from "zod";
import { api } from "@/server/http";
import { updateMemberRole, removeMember } from "@/server/services/workspaces";

export const PATCH = api<{ id: string; userId: string }>(async (ctx, { id, userId }) => {
  const { role } = await ctx.body(z.object({ role: z.enum(["owner", "admin", "editor", "viewer"]) }));
  await updateMemberRole(ctx.db, ctx.actor, id, userId, role);
  return { ok: true };
});
export const DELETE = api<{ id: string; userId: string }>(async (ctx, { id, userId }) => {
  await removeMember(ctx.db, ctx.actor, id, userId);
  return { ok: true };
});
