import { api } from "@/server/http";
import { listMembers } from "@/server/services/workspaces";

export const GET = api<{ id: string }>(async (ctx, { id }) => ({ members: await listMembers(ctx.db, ctx.actor, id) }));
