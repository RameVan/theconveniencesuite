import { api } from "@/server/http";
import { recentPages } from "@/server/services/pages";

export const GET = api<{ id: string }>(async (ctx, { id }) => ({ pages: await recentPages(ctx.db, ctx.actor, id, 20) }));
