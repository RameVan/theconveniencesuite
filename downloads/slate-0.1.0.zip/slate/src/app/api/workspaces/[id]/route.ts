import { z } from "zod";
import { api } from "@/server/http";
import { getWorkspace, updateWorkspace, deleteWorkspace, workspaceInput } from "@/server/services/workspaces";

export const GET = api<{ id: string }>(async (ctx, { id }) => ({ workspace: await getWorkspace(ctx.db, ctx.actor, id) }));
export const PATCH = api<{ id: string }>(async (ctx, { id }) => ({ workspace: await updateWorkspace(ctx.db, ctx.actor, id, await ctx.body(workspaceInput.partial())) }));
export const DELETE = api<{ id: string }>(async (ctx, { id }) => {
  const { confirmName } = await ctx.body(z.object({ confirmName: z.string() }));
  await deleteWorkspace(ctx.db, ctx.actor, id, confirmName);
  return { ok: true };
});
