import { api } from "@/server/http";
import { storageUsage } from "@/server/services/files";

export const GET = api<{ id: string }>(async (ctx, { id }) => storageUsage(ctx.db, ctx.actor, id));
