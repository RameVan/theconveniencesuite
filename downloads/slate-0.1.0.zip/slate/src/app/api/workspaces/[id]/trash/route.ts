import { api } from "@/server/http";
import { listTrash } from "@/server/services/pages";

export const GET = api<{ id: string }>(async (ctx, { id }) => ({ pages: await listTrash(ctx.db, ctx.actor, id, ctx.query("q") ?? undefined) }));
