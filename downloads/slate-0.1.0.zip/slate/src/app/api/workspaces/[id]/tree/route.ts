import { api } from "@/server/http";
import { getTree } from "@/server/services/pages";

export const GET = api<{ id: string }>(async (ctx, { id }) => getTree(ctx.db, ctx.actor, id));
