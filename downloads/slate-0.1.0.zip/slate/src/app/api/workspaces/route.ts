import { api } from "@/server/http";
import { listWorkspaces, createWorkspace, workspaceInput } from "@/server/services/workspaces";

export const GET = api(async (ctx) => ({ workspaces: await listWorkspaces(ctx.db, ctx.actor) }));
export const POST = api(async (ctx) => ({ workspace: await createWorkspace(ctx.db, ctx.actor, await ctx.body(workspaceInput)) }));
