"use client";
import { AuthCard, ForgotPasswordForm, AuthSwitch } from "@/components/auth-forms";

export default function ForgotPasswordPage() {
  return (
    <AuthCard title="Forgot your password?" subtitle="We’ll email you a link to choose a new one.">
      <ForgotPasswordForm />
      <AuthSwitch to="login" />
    </AuthCard>
  );
}
