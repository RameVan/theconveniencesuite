"use client";
import { useParams, useRouter } from "next/navigation";
import useSWR, { mutate } from "swr";
import { useState } from "react";
import { AuthCard, SignupForm, LoginForm } from "@/components/auth-forms";
import { useMe } from "@/client/hooks";
import { api, errorMessage } from "@/client/api";
import { Spinner } from "@/client/ui";

export default function InvitePage() {
  const { token } = useParams<{ token: string }>();
  const router = useRouter();
  const { data: me, isLoading: meLoading } = useMe();
  const { data: inv, error } = useSWR<{ workspaceName: string; email: string; role: string }>(`/api/invitations/${token}`);
  const [mode, setMode] = useState<"signup" | "login">("signup");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  if (error) return <AuthCard title="Invitation unavailable" subtitle={errorMessage(error)}>{null}</AuthCard>;
  if (!inv || meLoading)
    return (
      <div className="flex h-full items-center justify-center">
        <Spinner />
      </div>
    );
  const title = `Join ${inv.workspaceName}`;
  if (me?.user) {
    return (
      <AuthCard title={title} subtitle={`You were invited as ${inv.role} (${inv.email}).`}>
        {err && <p className="mb-3 text-sm text-danger">{err}</p>}
        <button
          className="btn btn-primary w-full"
          disabled={busy}
          onClick={async () => {
            setBusy(true);
            try {
              const r = await api.post<{ workspaceId: string }>(`/api/invitations/${token}`);
              await mutate("/api/workspaces");
              router.replace(`/w/${r.workspaceId}`);
            } catch (e) {
              setErr(errorMessage(e));
              setBusy(false);
            }
          }}
        >
          Accept invitation
        </button>
        {me.user.email !== inv.email && <p className="mt-3 text-xs text-muted">You are signed in as {me.user.email}. This invitation is for {inv.email}.</p>}
      </AuthCard>
    );
  }
  return (
    <AuthCard title={title} subtitle={`Invited as ${inv.role}. ${mode === "signup" ? "Create an account to join." : "Log in to join."}`}>
      {mode === "signup" ? <SignupForm inviteToken={token} presetEmail={inv.email} /> : <LoginForm next={`/invite/${token}`} />}
      <p className="mt-4 text-center text-sm text-muted">
        <button className="underline" onClick={() => setMode(mode === "signup" ? "login" : "signup")}>
          {mode === "signup" ? "I already have an account" : "Create a new account instead"}
        </button>
      </p>
    </AuthCard>
  );
}
