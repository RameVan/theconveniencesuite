import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Providers } from "@/client/providers";

export const metadata: Metadata = {
  title: "Slate",
  description: "A self-hosted workspace for notes, docs and databases.",
  icons: { icon: "/icon.svg", apple: "/icons/apple-touch-icon.png" },
  // iPhone/iPad "Add to Home Screen": open as an app, not a browser tab.
  appleWebApp: { capable: true, title: "Slate", statusBarStyle: "default" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#1d1c1a" },
  ],
};

// Applies the saved theme before first paint to avoid a light/dark flash.
const themeScript = `(function(){try{var t=localStorage.getItem("slate-theme")||"system";var d=t==="dark"||(t==="system"&&matchMedia("(prefers-color-scheme: dark)").matches);document.documentElement.dataset.theme=d?"dark":"light";}catch(e){}})();`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body className="h-full antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
