"use client";
import { Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { AuthCard, LoginForm, AuthSwitch } from "@/components/auth-forms";
import { useMe } from "@/client/hooks";

function Inner() {
  const params = useSearchParams();
  const { data } = useMe();
  return (
    <AuthCard title="Log in" subtitle="Welcome back to your workspace.">
      {params.get("reset") && (
        <p role="status" className="mb-3 rounded-md bg-accent-soft px-3 py-2 text-sm">
          Your password was changed. Log in with the new one.
        </p>
      )}
      {params.get("error") && (
        <p role="alert" className="mb-3 rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">
          {params.get("error")}
        </p>
      )}
      {data?.sso && (
        <>
          <a className="btn mb-3 flex w-full justify-center" href={`/api/auth/oidc/start${params.get("next") ? `?next=${encodeURIComponent(params.get("next")!)}` : ""}`}>
            Continue with {data.sso.name}
          </a>
          <div className="mb-3 flex items-center gap-2 text-xs text-faint">
            <span className="h-px flex-1 bg-line" /> or with email <span className="h-px flex-1 bg-line" />
          </div>
        </>
      )}
      <LoginForm next={params.get("next") ?? undefined} />
      {data?.signupAllowed && <AuthSwitch to="signup" />}
    </AuthCard>
  );
}

export default function LoginPage() {
  return (
    <Suspense>
      <Inner />
    </Suspense>
  );
}
