"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useMe, useWorkspaces } from "@/client/hooks";
import { api, errorMessage } from "@/client/api";
import { Spinner, useUi } from "@/client/ui";

export default function Home() {
  const router = useRouter();
  const { toast } = useUi();
  const { data: me, isLoading } = useMe();
  const { data: ws } = useWorkspaces();

  useEffect(() => {
    if (isLoading) return;
    if (!me?.user) {
      router.replace(me?.signupAllowed ? "/signup" : "/login");
      return;
    }
    if (!ws) return;
    let last: string | null = null;
    try {
      last = localStorage.getItem("slate-last-workspace");
    } catch {
      /* ignore */
    }
    const target = ws.workspaces.find((w) => w.id === last) ?? ws.workspaces[0];
    if (target) router.replace(`/w/${target.id}`);
    else
      api
        .post<{ workspace: { id: string } }>("/api/workspaces", { name: `${me.user.name.split(" ")[0]}'s workspace` })
        .then((r) => router.replace(`/w/${r.workspace.id}`))
        .catch((e) => toast(errorMessage(e), "error"));
  }, [me, ws, isLoading, router, toast]);

  return (
    <div className="flex h-full items-center justify-center">
      <Spinner size={20} />
    </div>
  );
}
