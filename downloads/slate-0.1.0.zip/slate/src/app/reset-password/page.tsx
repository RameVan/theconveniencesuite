"use client";
import { Suspense } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { AuthCard, ResetPasswordForm } from "@/components/auth-forms";

function Inner() {
  const token = useSearchParams().get("token");
  return (
    <AuthCard title="Choose a new password">
      {token ? (
        <ResetPasswordForm token={token} />
      ) : (
        <p className="text-sm">
          This link is incomplete. <Link className="underline" href="/forgot-password">Ask for a new one</Link>.
        </p>
      )}
    </AuthCard>
  );
}

export default function ResetPasswordPage() {
  return (
    <Suspense>
      <Inner />
    </Suspense>
  );
}
