"use client";
import { Suspense, useEffect, useMemo } from "react";
import { useParams, useSearchParams } from "next/navigation";
import useSWR from "swr";
import Link from "next/link";
import { Spinner, cx } from "@/client/ui";
import { errorMessage } from "@/client/api";
import { EditorEnvContext, type EditorEnv } from "@/components/editor/context";
import { PageLookupContext } from "@/components/editor/lookup";
import { ReadOnlyBlocks } from "@/components/read-only-blocks";
import { DatabaseView } from "@/components/database/database-view";
import { RecordProperties } from "@/components/database/record-properties";
import { PageIcon, pageTitle } from "@/components/page-icon";
import { Logo } from "@/components/auth-forms";
import { parseCover, withShare } from "@/components/page/cover";
import type { PMNode } from "@/lib/blocks";
import type { PageResponse, PageSummary } from "@/client/types";

interface Shared {
  rootId: string;
  page: { id: string; title: string; icon: string | null; cover: string | null; kind: "page" | "database"; fullWidth: boolean; smallText: boolean; databaseId: string | null; updatedAt: string };
  content: PMNode[];
  children: PageSummary[];
  record: PageResponse["record"];
}

function SharedPage() {
  const { token } = useParams<{ token: string }>();
  const search = useSearchParams();
  const pageId = search.get("page");
  const { data, error } = useSWR<Shared>(`/api/share/${token}${pageId ? `?page=${encodeURIComponent(pageId)}` : ""}`);
  useEffect(() => {
    if (data) document.title = `${data.page.title || "Untitled"} · Slate`;
  }, [data]);
  const env = useMemo<EditorEnv | null>(
    () =>
      data
        ? {
            workspaceId: "",
            pageId: data.page.id,
            editable: false,
            breadcrumbs: [],
            pageTitle: data.page.title,
            shareToken: token,
            navigate: () => {},
            hrefFor: (id) => `/share/${token}?page=${id}`,
          }
        : null,
    [data, token],
  );
  const lookup = useMemo(() => ({ pages: new Map((data?.children ?? []).map((c) => [c.id, { title: c.title, icon: c.icon, kind: c.kind }])), offline: true }), [data]);

  if (error)
    return (
      <div className="flex h-full flex-col items-center justify-center gap-2 p-6 text-center">
        <h1 className="text-lg font-semibold">This page is not available</h1>
        <p className="text-sm text-muted">{errorMessage(error)}</p>
      </div>
    );
  if (!data || !env)
    return (
      <div className="flex h-full items-center justify-center">
        <Spinner />
      </div>
    );
  const cover = data.page.cover ? parseCover(data.page.cover) : null;
  return (
    <EditorEnvContext.Provider value={env}>
      <PageLookupContext.Provider value={lookup}>
        <div className="min-h-full">
          <header className="flex h-11 items-center justify-between border-b border-line px-4 text-sm">
            <div className="flex items-center gap-2">
              {data.page.id !== data.rootId && (
                <Link href={`/share/${token}`} className="link-btn">
                  ← Back
                </Link>
              )}
              <PageIcon icon={data.page.icon} kind={data.page.kind} size={14} />
              <span className="truncate">{pageTitle(data.page.title)}</span>
            </div>
            <Link href="/" className="opacity-70 hover:opacity-100">
              <Logo size={18} />
            </Link>
          </header>
          {cover && <div className="h-[30vh] max-h-[280px] w-full" style={cover.isImage && cover.url ? { ...cover.style, backgroundImage: `url("${withShare(cover.url, token)}")` } : cover.style} />}
          <main className={cx("mx-auto px-6 pb-24 sm:px-12", data.page.fullWidth || data.page.kind === "database" ? "max-w-none" : "max-w-[900px]")}>
            <div className={cover ? "pt-6" : "pt-16"}>
              {data.page.icon && (
                <div className="mb-2">
                  <PageIcon icon={withShare(data.page.icon, token)} size={64} />
                </div>
              )}
              <h1 className="mb-4 text-[40px] font-bold leading-tight">{pageTitle(data.page.title)}</h1>
            </div>
            {data.record && <RecordProperties pageId={data.page.id} record={data.record} editable={false} onChanged={() => {}} shareMode />}
            {data.page.kind === "database" ? <DatabaseView databaseId={data.page.id} full shareToken={token} /> : <ReadOnlyBlocks blocks={data.content} smallText={data.page.smallText} />}
            <p className="mt-16 text-xs text-faint">Last updated {new Date(data.page.updatedAt).toLocaleString()} · Published with Slate</p>
          </main>
        </div>
      </PageLookupContext.Provider>
    </EditorEnvContext.Provider>
  );
}

export default function SharePage() {
  return (
    <Suspense>
      <SharedPage />
    </Suspense>
  );
}
