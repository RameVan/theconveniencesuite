"use client";
import { AuthCard, SignupForm, AuthSwitch } from "@/components/auth-forms";
import { useMe } from "@/client/hooks";
import { Spinner } from "@/client/ui";

export default function SignupPage() {
  const { data, isLoading } = useMe();
  if (isLoading)
    return (
      <div className="flex h-full items-center justify-center">
        <Spinner />
      </div>
    );
  if (data && !data.signupAllowed)
    return (
      <AuthCard title="Sign-up is closed" subtitle="This server only accepts new accounts through invitations. Ask an administrator for an invite link.">
        <AuthSwitch to="login" />
      </AuthCard>
    );
  return (
    <AuthCard title="Create your account" subtitle="Everything is included: unlimited pages, databases, history and members.">
      <SignupForm />
      <AuthSwitch to="login" />
    </AuthCard>
  );
}
