"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { mutate } from "swr";
import { useMe, useWorkspaces, useMediaQuery, useLocalStorage, refreshTree } from "@/client/hooks";
import { WorkspaceContext, type WorkspaceCtx } from "@/client/workspace-context";
import { api, errorMessage } from "@/client/api";
import { Spinner, useUi, cx } from "@/client/ui";
import { applyTheme, getThemePref } from "@/client/providers";
import { Sidebar } from "@/components/sidebar";
import { SearchDialog } from "@/components/search-dialog";
import { SettingsDialog } from "@/components/settings-dialog";
import { TrashDialog } from "@/components/trash-dialog";
import { TemplatesDialog } from "@/components/templates-dialog";

export default function WorkspaceLayout({ children }: { children: React.ReactNode }) {
  const { workspaceId } = useParams<{ workspaceId: string }>();
  const router = useRouter();
  const { toast } = useUi();
  const { data: me, isLoading: meLoading } = useMe();
  const { data: wsData, error: wsError } = useWorkspaces();
  const isMobile = useMediaQuery("(max-width: 768px)");
  const [sidebarPref, setSidebarPref] = useLocalStorage("slate-sidebar-open", true);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [width, setWidth] = useLocalStorage("slate-sidebar-width", 248);
  const [searchOpen, setSearchOpen] = useState(false);
  const [settingsTab, setSettingsTab] = useState<string | null>(null);
  const [trashOpen, setTrashOpen] = useState(false);
  const [templatesParent, setTemplatesParent] = useState<string | null | undefined>(undefined);

  useEffect(() => {
    if (!meLoading && !me?.user) router.replace(`/login?next=${encodeURIComponent(location.pathname)}`);
  }, [me, meLoading, router]);

  useEffect(() => {
    try {
      localStorage.setItem("slate-last-workspace", workspaceId);
    } catch {
      /* ignore */
    }
  }, [workspaceId]);

  const workspace = wsData?.workspaces.find((w) => w.id === workspaceId) ?? null;
  const sidebarOpen = isMobile ? mobileOpen : sidebarPref;
  const toggleSidebar = useCallback(() => (isMobile ? setMobileOpen((v) => !v) : setSidebarPref(!sidebarPref)), [isMobile, sidebarPref, setSidebarPref]);

  const createPage = useCallback<WorkspaceCtx["createPage"]>(
    async (opts = {}) => {
      try {
        const r = await api.post<{ page: { id: string } }>("/api/pages", {
          workspaceId,
          parentId: opts.parentId ?? null,
          kind: opts.kind ?? "page",
          title: opts.title ?? "",
          visibility: opts.visibility ?? (workspace?.role && workspace.role !== "viewer" ? "workspace" : "private"),
        });
        await refreshTree(workspaceId);
        if (opts.parentId) mutate(`/api/pages/${opts.parentId}`);
        if (opts.navigate !== false) {
          router.push(`/w/${workspaceId}/p/${r.page.id}?new=1`);
          if (isMobile) setMobileOpen(false);
        }
        return r.page.id;
      } catch (e) {
        toast(errorMessage(e), "error");
        return null;
      }
    },
    [workspaceId, workspace, router, toast, isMobile],
  );

  const ctx = useMemo<WorkspaceCtx | null>(
    () =>
      workspace && me?.user
        ? {
            workspace,
            workspaces: wsData!.workspaces,
            me: me.user,
            canEdit: !!workspace.role && workspace.role !== "viewer",
            openSearch: () => setSearchOpen(true),
            openSettings: (tab) => setSettingsTab(tab ?? "account"),
            openTrash: () => setTrashOpen(true),
            openTemplates: (parentId) => setTemplatesParent(parentId ?? null),
            createPage,
            navigate: (pageId) => {
              router.push(`/w/${workspaceId}/p/${pageId}`);
              if (isMobile) setMobileOpen(false);
            },
            toggleSidebar,
            sidebarOpen,
          }
        : null,
    [workspace, me, wsData, createPage, router, workspaceId, toggleSidebar, sidebarOpen, isMobile],
  );

  // Global shortcuts.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const mod = e.metaKey || e.ctrlKey;
      if (!mod) return;
      const k = e.key.toLowerCase();
      if (k === "k" || (k === "p" && !e.shiftKey)) {
        e.preventDefault();
        setSearchOpen(true);
      } else if (k === "\\") {
        e.preventDefault();
        toggleSidebar();
      } else if (k === "n" && e.shiftKey) {
        e.preventDefault();
        createPage();
      } else if (k === "l" && e.shiftKey) {
        e.preventDefault();
        const dark = document.documentElement.dataset.theme === "dark";
        applyTheme(dark ? "light" : "dark");
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [toggleSidebar, createPage]);

  useEffect(() => {
    // keep the theme preference applied on mount (system changes are handled in Providers)
    applyTheme(getThemePref());
  }, []);

  if (wsError) return <FullMessage title="Could not load workspaces" body={errorMessage(wsError)} />;
  if (!me?.user || !wsData)
    return (
      <div className="flex h-full items-center justify-center">
        <Spinner size={20} />
      </div>
    );
  if (!workspace) return <FullMessage title="Workspace not found" body="It may have been deleted, or you are no longer a member." action={{ label: "Go home", href: "/" }} />;

  return (
    <WorkspaceContext.Provider value={ctx}>
      <div className="flex h-dvh overflow-hidden">
        {isMobile ? (
          <>
            <div className={cx("fixed inset-0 z-30 bg-black/30 transition-opacity", mobileOpen ? "opacity-100" : "pointer-events-none opacity-0")} onClick={() => setMobileOpen(false)} />
            <aside className={cx("fixed inset-y-0 left-0 z-40 w-[85vw] max-w-[300px] border-r border-line transition-transform", mobileOpen ? "translate-x-0" : "-translate-x-full")}>
              <Sidebar onNavigate={() => setMobileOpen(false)} />
            </aside>
          </>
        ) : (
          sidebarPref && (
            <aside className="relative flex-none border-r border-line" style={{ width }}>
              <Sidebar />
              <div
                className="absolute inset-y-0 -right-1 z-10 w-2 cursor-col-resize hover:bg-accent-soft"
                onMouseDown={(e) => {
                  e.preventDefault();
                  const startX = e.clientX;
                  const startW = width;
                  const onMove = (ev: MouseEvent) => setWidth(Math.min(480, Math.max(200, startW + ev.clientX - startX)));
                  const onUp = () => {
                    window.removeEventListener("mousemove", onMove);
                    window.removeEventListener("mouseup", onUp);
                  };
                  window.addEventListener("mousemove", onMove);
                  window.addEventListener("mouseup", onUp);
                }}
              />
            </aside>
          )
        )}
        <main className="relative flex min-w-0 flex-1 flex-col">{children}</main>
      </div>
      <SearchDialog open={searchOpen} onClose={() => setSearchOpen(false)} />
      <SettingsDialog tab={settingsTab} onTab={setSettingsTab} />
      <TrashDialog open={trashOpen} onClose={() => setTrashOpen(false)} />
      <TemplatesDialog parentId={templatesParent} onClose={() => setTemplatesParent(undefined)} />
    </WorkspaceContext.Provider>
  );
}

function FullMessage({ title, body, action }: { title: string; body: string; action?: { label: string; href: string } }) {
  return (
    <div className="flex h-full flex-col items-center justify-center gap-2 p-6 text-center">
      <h1 className="text-lg font-semibold">{title}</h1>
      <p className="text-sm text-muted">{body}</p>
      {action && (
        <a className="btn mt-2" href={action.href}>
          {action.label}
        </a>
      )}
    </div>
  );
}
