"use client";
import { useParams } from "next/navigation";
import { PageView } from "@/components/page/page-view";

export default function Page() {
  const { pageId } = useParams<{ pageId: string }>();
  return <PageView key={pageId} pageId={pageId} />;
}
