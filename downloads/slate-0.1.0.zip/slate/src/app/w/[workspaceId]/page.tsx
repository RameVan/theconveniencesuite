"use client";
import useSWR from "swr";
import Link from "next/link";
import { Plus, LayoutTemplate, Upload, Database, Menu as MenuIcon } from "lucide-react";
import { useWorkspace } from "@/client/workspace-context";
import { PageIcon, pageTitle } from "@/components/page-icon";
import type { PageSummary } from "@/client/types";

export default function WorkspaceHome() {
  const ws = useWorkspace();
  const { data } = useSWR<{ pages: (PageSummary & { visitedAt: string })[] }>(`/api/workspaces/${ws.workspace.id}/recent`);
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  return (
    <div className="flex-1 overflow-y-auto">
      {!ws.sidebarOpen && (
        <div className="p-2">
          <button className="icon-btn" onClick={ws.toggleSidebar} aria-label="Open sidebar">
            <MenuIcon size={18} />
          </button>
        </div>
      )}
      <div className="mx-auto max-w-3xl px-6 py-16">
        <h1 className="text-3xl font-bold">
          {greeting}, {ws.me.name.split(" ")[0]}
        </h1>
        <p className="mt-1 text-muted">{ws.workspace.name}</p>
        <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Action icon={<Plus size={18} />} label="New page" onClick={() => ws.createPage()} />
          <Action icon={<Database size={18} />} label="New database" onClick={() => ws.createPage({ kind: "database", title: "Untitled database" })} />
          <Action icon={<LayoutTemplate size={18} />} label="Templates" onClick={() => ws.openTemplates(null)} />
          <Action icon={<Upload size={18} />} label="Import" onClick={() => ws.openSettings("import")} />
        </div>
        <h2 className="mb-3 mt-12 text-sm font-medium text-muted">Recently visited</h2>
        {!data && (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="skeleton h-24" />
            ))}
          </div>
        )}
        {data?.pages.length === 0 && <p className="text-sm text-muted">Pages you open will appear here. Open the sidebar to browse your workspace.</p>}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {data?.pages.map((p) => (
            <Link key={p.id} href={`/w/${ws.workspace.id}/p/${p.id}`} className="rounded-lg border border-line p-4 hover:bg-hover">
              <PageIcon icon={p.icon} kind={p.kind} size={24} />
              <div className="mt-3 truncate text-sm font-medium">{pageTitle(p.title)}</div>
              <div className="mt-1 text-xs text-faint">{new Date(p.visitedAt).toLocaleDateString()}</div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}

function Action({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="flex flex-col items-start gap-3 rounded-lg border border-line p-4 text-left text-sm font-medium hover:bg-hover">
      <span className="text-muted">{icon}</span>
      {label}
    </button>
  );
}
