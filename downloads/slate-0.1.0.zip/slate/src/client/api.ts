"use client";
// Thin JSON client for the Slate REST API.

export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public details?: unknown,
  ) {
    super(message);
  }
}

async function parse(res: Response) {
  const text = await res.text();
  let body: unknown = null;
  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    body = null;
  }
  if (!res.ok) {
    const err = (body as { error?: { code: string; message: string; details?: unknown } } | null)?.error;
    throw new ApiError(res.status, err?.code ?? "http_error", err?.message ?? (res.status === 0 ? "Network error" : `Request failed (${res.status})`), err?.details);
  }
  return body;
}

export async function request<T = unknown>(method: string, url: string, body?: unknown, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(url, {
      method,
      credentials: "same-origin",
      headers: body !== undefined && !(body instanceof FormData) ? { "content-type": "application/json" } : undefined,
      body: body === undefined ? undefined : body instanceof FormData ? body : JSON.stringify(body),
      ...init,
    });
  } catch {
    throw new ApiError(0, "network", "You appear to be offline. Changes will be retried.");
  }
  return parse(res) as Promise<T>;
}

export const api = {
  get: <T = unknown>(url: string) => request<T>("GET", url),
  post: <T = unknown>(url: string, body?: unknown) => request<T>("POST", url, body ?? {}),
  put: <T = unknown>(url: string, body?: unknown) => request<T>("PUT", url, body ?? {}),
  patch: <T = unknown>(url: string, body?: unknown) => request<T>("PATCH", url, body ?? {}),
  del: <T = unknown>(url: string, body?: unknown) => request<T>("DELETE", url, body),
  upload: <T = unknown>(url: string, form: FormData) => request<T>("POST", url, form),
};

export const fetcher = (url: string) => api.get(url);

export function errorMessage(e: unknown): string {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return "Something went wrong";
}
