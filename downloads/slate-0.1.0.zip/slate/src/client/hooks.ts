"use client";
import useSWR, { mutate as globalMutate } from "swr";
import { useCallback, useMemo, useSyncExternalStore } from "react";
import type { Me, Workspace, TreeNode, PageSummary, PageResponse, Member, DatabaseMeta } from "./types";

export function useMe() {
  return useSWR<{ user: Me | null; signupAllowed: boolean; publicSharing: boolean; maxUploadBytes: number; realtime: { port: number; url: string | null } | null; sso: { name: string } | null; email: boolean }>("/api/auth/me");
}

export function useWorkspaces() {
  return useSWR<{ workspaces: Workspace[] }>("/api/workspaces");
}

export function useTree(workspaceId: string | null) {
  return useSWR<{ nodes: TreeNode[]; favorites: PageSummary[]; role: Workspace["role"] }>(workspaceId ? `/api/workspaces/${workspaceId}/tree` : null);
}

export function usePage(pageId: string | null) {
  return useSWR<PageResponse>(pageId ? `/api/pages/${pageId}` : null, { revalidateOnFocus: false, keepPreviousData: false });
}

export function useMembers(workspaceId: string | null) {
  return useSWR<{ members: Member[] }>(workspaceId ? `/api/workspaces/${workspaceId}/members` : null);
}

export function useDatabaseMeta(databaseId: string | null) {
  return useSWR<DatabaseMeta>(databaseId ? `/api/databases/${databaseId}` : null);
}

export function useWorkspaceDatabases(workspaceId: string | null) {
  return useSWR<{ databases: { id: string; title: string; icon: string | null }[] }>(workspaceId ? `/api/workspaces/${workspaceId}/databases` : null);
}

/** Revalidate everything that shows page titles/icons (sidebar, breadcrumbs, open pages). */
export function refreshPages(workspaceId?: string) {
  if (workspaceId) globalMutate(`/api/workspaces/${workspaceId}/tree`);
  globalMutate((key) => typeof key === "string" && (key.startsWith("/api/pages/") || key.startsWith("/api/databases/")), undefined, { revalidate: true });
}

export function refreshTree(workspaceId: string) {
  return globalMutate(`/api/workspaces/${workspaceId}/tree`);
}

export function useMediaQuery(q: string) {
  const subscribe = useCallback(
    (cb: () => void) => {
      const mq = matchMedia(q);
      mq.addEventListener("change", cb);
      return () => mq.removeEventListener("change", cb);
    },
    [q],
  );
  return useSyncExternalStore(
    subscribe,
    () => matchMedia(q).matches,
    () => false,
  );
}

// localStorage-backed state shared by every component using the same key. Falls back to memory
// when storage is unavailable (private mode, blocked site data).
const storageListeners = new Set<() => void>();
const memoryStore = new Map<string, string>();
function subscribeStorage(cb: () => void) {
  storageListeners.add(cb);
  window.addEventListener("storage", cb);
  return () => {
    storageListeners.delete(cb);
    window.removeEventListener("storage", cb);
  };
}
function readStorage(key: string): string | null {
  try {
    return localStorage.getItem(key) ?? memoryStore.get(key) ?? null;
  } catch {
    return memoryStore.get(key) ?? null;
  }
}

export function useLocalStorage<T>(key: string, initial: T): [T, (v: T) => void] {
  const raw = useSyncExternalStore(
    subscribeStorage,
    () => readStorage(key),
    () => null,
  );
  const initialJson = JSON.stringify(initial);
  const value = useMemo<T>(() => {
    try {
      return JSON.parse(raw ?? initialJson) as T;
    } catch {
      return JSON.parse(initialJson) as T;
    }
  }, [raw, initialJson]);
  const set = useCallback(
    (v: T) => {
      const json = JSON.stringify(v);
      memoryStore.set(key, json);
      try {
        localStorage.setItem(key, json);
      } catch {
        /* memory fallback only */
      }
      storageListeners.forEach((l) => l());
    },
    [key],
  );
  return [value, set];
}
