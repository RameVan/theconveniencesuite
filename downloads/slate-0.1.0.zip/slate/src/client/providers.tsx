"use client";
import { SWRConfig } from "swr";
import { useEffect, type ReactNode } from "react";
import { fetcher } from "./api";
import { UiProvider } from "./ui";

export type ThemePref = "light" | "dark" | "system";

export function getThemePref(): ThemePref {
  try {
    return (localStorage.getItem("slate-theme") as ThemePref) || "system";
  } catch {
    return "system";
  }
}

export function applyTheme(pref: ThemePref) {
  try {
    localStorage.setItem("slate-theme", pref);
  } catch {
    /* storage unavailable */
  }
  const dark = pref === "dark" || (pref === "system" && matchMedia("(prefers-color-scheme: dark)").matches);
  document.documentElement.dataset.theme = dark ? "dark" : "light";
}

export function Providers({ children }: { children: ReactNode }) {
  useEffect(() => {
    const mq = matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => getThemePref() === "system" && applyTheme("system");
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);
  return (
    <SWRConfig value={{ fetcher, revalidateOnFocus: true, shouldRetryOnError: (e) => (e as { status?: number })?.status === 0, dedupingInterval: 1500 }}>
      <UiProvider>{children}</UiProvider>
    </SWRConfig>
  );
}
