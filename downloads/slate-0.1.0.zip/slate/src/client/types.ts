import type { PMNode } from "@/lib/blocks";
import type { PropertyDef, ViewDef, CellValue, QueryResult } from "@/lib/db-types";

export type Access = "none" | "view" | "edit" | "full";
export type Role = "owner" | "admin" | "editor" | "viewer";

export interface Me {
  id: string;
  email: string;
  name: string;
  isAdmin: boolean;
  avatarUrl: string | null;
  hasPassword: boolean;
  emailNotifications: boolean;
}

export interface Workspace {
  id: string;
  name: string;
  icon: string | null;
  role: Role | null;
}

export interface PageSummary {
  id: string;
  title: string;
  icon: string | null;
  kind: "page" | "database";
  databaseId: string | null;
  parentId: string | null;
}

export interface TreeNode {
  id: string;
  parentId: string | null;
  title: string;
  icon: string | null;
  kind: "page" | "database";
  position: number;
  visibility: "workspace" | "private";
  section: "workspace" | "private" | "shared";
  isInline: boolean;
}

export interface PageData {
  id: string;
  workspaceId: string;
  parentId: string | null;
  databaseId: string | null;
  kind: "page" | "database";
  title: string;
  icon: string | null;
  cover: string | null;
  visibility: "workspace" | "private";
  isTemplate: boolean;
  isInline: boolean;
  fullWidth: boolean;
  smallText: boolean;
  version: number;
  createdAt: string;
  createdBy: string | null;
  updatedAt: string;
  updatedBy: string | null;
  archivedAt: string | null;
  publicShareToken: string | null;
}

export interface DatabaseMeta {
  id: string;
  title: string;
  icon: string | null;
  workspaceId?: string;
  /** The page an inline database lives in (null at the top level). */
  parentId?: string | null;
  properties: PropertyDef[];
  views: ViewDef[];
  templates: { id: string; title: string; icon: string | null }[];
  defaultTemplateId: string | null;
  access?: Access;
}

export interface Refs {
  pages: Record<string, { title: string; icon: string | null }>;
  users: Record<string, { name: string; avatarUrl: string | null }>;
}

export interface PageResponse {
  page: PageData;
  access: Access;
  role: Role | null;
  breadcrumbs: PageSummary[];
  content: PMNode[];
  children: PageSummary[];
  favorite: boolean;
  database: DatabaseMeta | null;
  record: { database: { id: string; title: string; icon: string | null }; properties: PropertyDef[]; values: Record<string, CellValue>; refs: Refs } | null;
}

export type QueryResponse = QueryResult & { refs: Refs };

export interface Member {
  id: string;
  name: string;
  email: string;
  avatarUrl: string | null;
  role: Role;
}
