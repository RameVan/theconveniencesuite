"use client";
// Small, dependency-free UI primitives: popovers, menus, dialogs, toasts, confirmations.
import { createContext, useCallback, useContext, useEffect, useLayoutEffect, useRef, useState, useSyncExternalStore, type ReactNode, type CSSProperties } from "react";
import { createPortal } from "react-dom";
import { X, Check, ChevronRight } from "lucide-react";

export function cx(...c: (string | false | null | undefined)[]) {
  return c.filter(Boolean).join(" ");
}

// ------------------------------------------------------------------ Portal

const noopSubscribe = () => () => {};

/** True only after hydration on the client. */
export function useIsClient() {
  return useSyncExternalStore(
    noopSubscribe,
    () => true,
    () => false,
  );
}

export function Portal({ children }: { children: ReactNode }) {
  const isClient = useIsClient();
  return isClient ? createPortal(children, document.body) : null;
}

// ------------------------------------------------------------------ Popover

export type Anchor = HTMLElement | DOMRect | { x: number; y: number } | null;

function rectOf(a: Anchor): DOMRect | null {
  if (!a) return null;
  if (a instanceof HTMLElement) return a.getBoundingClientRect();
  if ("width" in a) return a as DOMRect;
  return new DOMRect(a.x, a.y, 0, 0);
}

export function Popover({
  anchor,
  open,
  onClose,
  children,
  placement = "bottom-start",
  className,
  style,
  offset = 4,
  modal = false,
}: {
  anchor: Anchor;
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  placement?: "bottom-start" | "bottom-end" | "right-start" | "top-start" | "bottom-center";
  className?: string;
  style?: CSSProperties;
  offset?: number;
  modal?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<{ left: number; top: number } | null>(null);

  useLayoutEffect(() => {
    if (!open) return;
    const place = () => {
      const r = rectOf(anchor);
      const el = ref.current;
      if (!r || !el) return;
      const w = el.offsetWidth;
      const h = el.offsetHeight;
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      let left = r.left;
      let top = r.bottom + offset;
      if (placement === "bottom-end") left = r.right - w;
      if (placement === "bottom-center") left = r.left + r.width / 2 - w / 2;
      if (placement === "right-start") {
        left = r.right + offset;
        top = r.top;
        if (left + w > vw - 8) left = r.left - w - offset;
      }
      if (placement === "top-start") top = r.top - h - offset;
      if (top + h > vh - 8) top = Math.max(8, placement === "right-start" ? vh - h - 8 : r.top - h - offset);
      if (top < 8) top = 8;
      left = Math.max(8, Math.min(left, vw - w - 8));
      setPos({ left, top });
    };
    place();
    const ro = new ResizeObserver(place);
    if (ref.current) ro.observe(ref.current);
    window.addEventListener("resize", place);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", place);
    };
  }, [open, anchor, placement, offset]);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      const t = e.target as Node;
      if (ref.current?.contains(t)) return;
      if (anchor instanceof HTMLElement && anchor.contains(t)) return;
      // Clicks inside nested popovers (portaled later in the DOM) do not close parents.
      const layers = Array.from(document.querySelectorAll("[data-popover-layer]"));
      const mine = layers.indexOf(ref.current as Element);
      if (layers.slice(mine + 1).some((l) => l.contains(t))) return;
      onClose();
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      const layers = Array.from(document.querySelectorAll("[data-popover-layer]"));
      if (layers[layers.length - 1] === ref.current) {
        e.stopPropagation();
        onClose();
      }
    };
    document.addEventListener("mousedown", onDown, true);
    document.addEventListener("keydown", onKey, true);
    return () => {
      document.removeEventListener("mousedown", onDown, true);
      document.removeEventListener("keydown", onKey, true);
    };
  }, [open, onClose, anchor]);

  if (!open) return null;
  return (
    <Portal>
      {modal && <div className="fixed inset-0 z-40" />}
      <div
        ref={ref}
        data-popover-layer=""
        className={cx("fixed z-50 rounded-lg border border-line bg-elevated text-fg", className)}
        style={{ left: pos?.left ?? -9999, top: pos?.top ?? -9999, boxShadow: "var(--shadow)", ...style }}
      >
        {children}
      </div>
    </Portal>
  );
}

// ------------------------------------------------------------------ Menu

export interface MenuItem {
  label: string;
  icon?: ReactNode;
  hint?: string;
  danger?: boolean;
  checked?: boolean;
  disabled?: boolean;
  onSelect?: () => void;
  submenu?: MenuItem[];
  divider?: boolean;
  heading?: boolean;
}

export function Menu({ items, onClose, filter = false, autoFocus = true, width = 240 }: { items: MenuItem[]; onClose: () => void; filter?: boolean; autoFocus?: boolean; width?: number }) {
  const [query, setQuery] = useState("");
  const [active, setActive] = useState(0);
  const [sub, setSub] = useState<{ index: number; el: HTMLElement } | null>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const shown = items.filter((i) => i.divider || i.heading || !query || i.label.toLowerCase().includes(query.toLowerCase()));
  const selectable = shown.map((i, idx) => (!i.divider && !i.heading && !i.disabled ? idx : -1)).filter((i) => i >= 0);

  useEffect(() => {
    if (autoFocus && !filter) listRef.current?.focus();
  }, [autoFocus, filter]);

  const activeIdx = active < 0 || !selectable.includes(active) ? (selectable[0] ?? -1) : active;

  const choose = (i: MenuItem, el?: HTMLElement | null) => {
    if (i.disabled) return;
    if (i.submenu) {
      if (el) setSub({ index: shown.indexOf(i), el });
      return;
    }
    i.onSelect?.();
    onClose();
  };
  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      const pos = selectable.indexOf(activeIdx);
      const next = e.key === "ArrowDown" ? selectable[(pos + 1) % selectable.length] : selectable[(pos - 1 + selectable.length) % selectable.length];
      setActive(next ?? 0);
      listRef.current?.querySelector(`[data-idx="${next}"]`)?.scrollIntoView({ block: "nearest" });
    } else if (e.key === "Enter") {
      e.preventDefault();
      const item = shown[activeIdx];
      if (item) choose(item, listRef.current?.querySelector(`[data-idx="${activeIdx}"]`) as HTMLElement);
    } else if (e.key === "ArrowRight") {
      const item = shown[activeIdx];
      if (item?.submenu) choose(item, listRef.current?.querySelector(`[data-idx="${activeIdx}"]`) as HTMLElement);
    }
  };

  return (
    <div style={{ width }} className="py-1" onKeyDown={onKey}>
      {filter && (
        <div className="px-2 pb-1">
          <input
            autoFocus
            className="input w-full"
            placeholder="Search…"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setActive(-1);
            }}
          />
        </div>
      )}
      <div ref={listRef} tabIndex={-1} role="menu" className="max-h-[60vh] overflow-y-auto outline-none">
        {shown.map((item, idx) =>
          item.divider ? (
            <div key={idx} className="my-1 border-t border-line" />
          ) : item.heading ? (
            <div key={idx} className="px-3 pb-1 pt-2 text-xs font-medium text-muted">
              {item.label}
            </div>
          ) : (
            <button
              key={idx}
              data-idx={idx}
              role="menuitem"
              disabled={item.disabled}
              onMouseEnter={(e) => {
                setActive(idx);
                if (item.submenu) setSub({ index: idx, el: e.currentTarget });
                else setSub(null);
              }}
              onClick={(e) => choose(item, e.currentTarget)}
              className={cx(
                "mx-1 flex w-[calc(100%-8px)] items-center gap-2 rounded px-2 py-1.5 text-left text-sm",
                activeIdx === idx && "bg-hover",
                item.danger && "text-danger",
                item.disabled && "opacity-40",
              )}
            >
              {item.icon && <span className="flex w-5 flex-none items-center justify-center text-muted">{item.icon}</span>}
              <span className="flex-1 truncate">{item.label}</span>
              {item.hint && <span className="text-xs text-faint">{item.hint}</span>}
              {item.checked && <Check size={14} className="text-fg" />}
              {item.submenu && <ChevronRight size={14} className="text-faint" />}
            </button>
          ),
        )}
        {!selectable.length && <div className="px-3 py-2 text-sm text-muted">No results</div>}
      </div>
      {sub && shown[sub.index]?.submenu && (
        <Popover anchor={sub.el} open onClose={() => setSub(null)} placement="right-start">
          <Menu items={shown[sub.index].submenu!} onClose={onClose} autoFocus={false} width={220} />
        </Popover>
      )}
    </div>
  );
}

/** A button that opens a menu. */
export function MenuButton({
  items,
  children,
  className,
  title,
  placement = "bottom-start",
  width,
}: {
  items: MenuItem[] | (() => MenuItem[]);
  children: ReactNode;
  className?: string;
  title?: string;
  placement?: "bottom-start" | "bottom-end";
  width?: number;
}) {
  const [anchor, setAnchor] = useState<HTMLElement | null>(null);
  return (
    <>
      <button
        type="button"
        title={title}
        aria-label={title}
        aria-haspopup="menu"
        aria-expanded={!!anchor}
        className={className}
        onClick={(e) => {
          e.stopPropagation();
          setAnchor(anchor ? null : e.currentTarget);
        }}
      >
        {children}
      </button>
      <Popover anchor={anchor} open={!!anchor} onClose={() => setAnchor(null)} placement={placement}>
        <Menu items={typeof items === "function" ? items() : items} onClose={() => setAnchor(null)} width={width} />
      </Popover>
    </>
  );
}

// ------------------------------------------------------------------ Dialog

export function Dialog({
  open,
  onClose,
  children,
  title,
  width = 480,
  className,
  bare = false,
  align = "center",
}: {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  title?: string;
  width?: number | string;
  className?: string;
  bare?: boolean;
  align?: "center" | "top";
}) {
  const ref = useRef<HTMLDivElement>(null);
  // Callers often pass a new onClose on every render; reading it from a ref keeps the effect below
  // from re-running (which would move focus back to the first field mid-typing).
  const onCloseRef = useRef(onClose);
  useEffect(() => {
    onCloseRef.current = onClose;
  });
  useEffect(() => {
    if (!open) return;
    const prev = document.activeElement as HTMLElement | null;
    const t = setTimeout(() => {
      const el = ref.current?.querySelector<HTMLElement>("[autofocus], input, textarea, button, [tabindex]");
      el?.focus();
    }, 0);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !document.querySelector("[data-popover-layer]")) {
        e.stopPropagation();
        onCloseRef.current();
      }
      if (e.key === "Tab" && ref.current) {
        const f = Array.from(ref.current.querySelectorAll<HTMLElement>("a[href],button:not([disabled]),input,textarea,select,[tabindex]:not([tabindex='-1'])"));
        if (!f.length) return;
        const first = f[0],
          last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      clearTimeout(t);
      document.removeEventListener("keydown", onKey);
      prev?.focus?.();
    };
  }, [open]);
  if (!open) return null;
  return (
    <Portal>
      <div className={cx("fixed inset-0 z-40 flex justify-center bg-black/30 p-4", align === "top" ? "items-start pt-[12vh]" : "items-center")} onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
        <div
          ref={ref}
          role="dialog"
          aria-modal="true"
          aria-label={title}
          className={cx("max-h-[85vh] w-full overflow-hidden rounded-xl border border-line bg-elevated text-fg", className)}
          style={{ maxWidth: width, boxShadow: "var(--shadow)" }}
        >
          {!bare && title && (
            <div className="flex items-center justify-between border-b border-line px-5 py-3">
              <h2 className="text-base font-semibold">{title}</h2>
              <button className="icon-btn" onClick={onClose} aria-label="Close">
                <X size={16} />
              </button>
            </div>
          )}
          {children}
        </div>
      </div>
    </Portal>
  );
}

// ------------------------------------------------------------------ Toasts & confirm

interface Toast {
  id: number;
  message: string;
  kind: "info" | "error" | "success";
  action?: { label: string; run: () => void };
}
interface ConfirmOpts {
  title: string;
  message?: string;
  confirmLabel?: string;
  danger?: boolean;
  requireText?: string;
}

const UiCtx = createContext<{
  toast: (message: string, kind?: Toast["kind"], action?: Toast["action"]) => void;
  confirm: (o: ConfirmOpts) => Promise<boolean>;
} | null>(null);

export function UiProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [confirmState, setConfirmState] = useState<(ConfirmOpts & { resolve: (v: boolean) => void }) | null>(null);
  const [typed, setTyped] = useState("");
  const toast = useCallback((message: string, kind: Toast["kind"] = "info", action?: Toast["action"]) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-3), { id, message, kind, action }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), kind === "error" ? 7000 : 4000);
  }, []);
  const confirm = useCallback((o: ConfirmOpts) => {
    setTyped("");
    return new Promise<boolean>((resolve) => setConfirmState({ ...o, resolve }));
  }, []);
  const close = (v: boolean) => {
    confirmState?.resolve(v);
    setConfirmState(null);
  };
  return (
    <UiCtx.Provider value={{ toast, confirm }}>
      {children}
      <Portal>
        <div className="pointer-events-none fixed bottom-4 left-1/2 z-[60] flex -translate-x-1/2 flex-col items-center gap-2" aria-live="polite">
          {toasts.map((t) => (
            <div
              key={t.id}
              className={cx("pointer-events-auto flex max-w-[90vw] items-center gap-3 rounded-lg px-4 py-2.5 text-sm text-white shadow-lg", t.kind === "error" ? "bg-[#b5372e]" : "bg-[#2f2d29]")}
            >
              <span>{t.message}</span>
              {t.action && (
                <button
                  className="font-semibold underline"
                  onClick={() => {
                    t.action!.run();
                    setToasts((x) => x.filter((y) => y.id !== t.id));
                  }}
                >
                  {t.action.label}
                </button>
              )}
            </div>
          ))}
        </div>
      </Portal>
      <Dialog open={!!confirmState} onClose={() => close(false)} width={420} bare title={confirmState?.title}>
        {confirmState && (
          <form
            className="p-5"
            onSubmit={(e) => {
              e.preventDefault();
              if (!confirmState.requireText || typed === confirmState.requireText) close(true);
            }}
          >
            <h2 className="mb-2 text-base font-semibold">{confirmState.title}</h2>
            {confirmState.message && <p className="mb-4 text-sm text-muted">{confirmState.message}</p>}
            {confirmState.requireText && (
              <input className="input mb-4 w-full" autoFocus placeholder={`Type "${confirmState.requireText}" to confirm`} value={typed} onChange={(e) => setTyped(e.target.value)} />
            )}
            <div className="flex justify-end gap-2">
              <button type="button" className="btn" onClick={() => close(false)}>
                Cancel
              </button>
              <button
                type="submit"
                autoFocus={!confirmState.requireText}
                disabled={!!confirmState.requireText && typed !== confirmState.requireText}
                className={cx("btn", confirmState.danger ? "btn-danger" : "btn-primary")}
              >
                {confirmState.confirmLabel ?? "Confirm"}
              </button>
            </div>
          </form>
        )}
      </Dialog>
    </UiCtx.Provider>
  );
}

export function useUi() {
  const ctx = useContext(UiCtx);
  if (!ctx) throw new Error("UiProvider missing");
  return ctx;
}

// ------------------------------------------------------------------ misc

export function Spinner({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" className="animate-spin text-muted" aria-label="Loading">
      <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="3" opacity="0.25" />
      <path d="M21 12a9 9 0 0 0-9-9" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

export function Kbd({ children }: { children: ReactNode }) {
  return <kbd className="rounded border border-line bg-subtle px-1.5 py-0.5 font-mono text-[11px] text-muted">{children}</kbd>;
}

export const isMac = () => typeof navigator !== "undefined" && /Mac|iPhone|iPad/.test(navigator.platform);
export const modKey = () => (isMac() ? "⌘" : "Ctrl");

/** Start a file download from an API URL without navigating away. */
export function downloadUrl(url: string) {
  const a = document.createElement("a");
  a.href = url;
  a.download = "";
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
}
