"use client";
import { api } from "./api";

export interface Uploaded {
  id: string;
  name: string;
  mime: string;
  size: number;
  url: string;
}

export async function uploadFile(workspaceId: string, file: File): Promise<Uploaded> {
  const form = new FormData();
  form.set("file", file);
  form.set("workspaceId", workspaceId);
  return api.upload<Uploaded>("/api/files", form);
}

export function pickFile(accept?: string): Promise<File | null> {
  return new Promise((resolve) => {
    const input = document.createElement("input");
    input.type = "file";
    if (accept) input.accept = accept;
    input.onchange = () => resolve(input.files?.[0] ?? null);
    input.oncancel = () => resolve(null);
    input.click();
  });
}

export function formatBytes(b: number | null | undefined) {
  if (!b) return "";
  if (b > 1e9) return `${(b / 1e9).toFixed(1)} GB`;
  if (b > 1e6) return `${(b / 1e6).toFixed(1)} MB`;
  if (b > 1e3) return `${Math.round(b / 1e3)} KB`;
  return `${b} B`;
}
