"use client";
import { createContext, useContext } from "react";
import type { Me, Workspace } from "./types";

export interface WorkspaceCtx {
  workspace: Workspace;
  workspaces: Workspace[];
  me: Me;
  canEdit: boolean;
  openSearch: () => void;
  openSettings: (tab?: string) => void;
  openTrash: () => void;
  openTemplates: (parentId?: string | null) => void;
  createPage: (opts?: { parentId?: string | null; kind?: "page" | "database"; visibility?: "workspace" | "private"; title?: string; navigate?: boolean }) => Promise<string | null>;
  navigate: (pageId: string) => void;
  toggleSidebar: () => void;
  sidebarOpen: boolean;
}

export const WorkspaceContext = createContext<WorkspaceCtx | null>(null);

export function useWorkspace() {
  const ctx = useContext(WorkspaceContext);
  if (!ctx) throw new Error("WorkspaceContext missing");
  return ctx;
}

export function useOptionalWorkspace() {
  return useContext(WorkspaceContext);
}
