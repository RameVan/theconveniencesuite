"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { mutate } from "swr";
import { api, errorMessage } from "@/client/api";
import { Spinner } from "@/client/ui";
import { PasswordInput } from "./password-input";

export function Logo({ size = 28 }: { size?: number }) {
  return (
    <span className="inline-flex items-center gap-2 font-semibold tracking-tight">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src="/icon.svg" alt="" width={size} height={size} />
      <span style={{ fontSize: size * 0.7 }}>Slate</span>
    </span>
  );
}

export function AuthCard({ title, subtitle, children }: { title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <main className="flex min-h-full items-center justify-center bg-sidebar px-4 py-12">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex justify-center">
          <Logo />
        </div>
        <div className="rounded-xl border border-line bg-bg p-6" style={{ boxShadow: "var(--shadow)" }}>
          <h1 className="text-xl font-semibold">{title}</h1>
          {subtitle && <p className="mt-1 text-sm text-muted">{subtitle}</p>}
          <div className="mt-5">{children}</div>
        </div>
      </div>
    </main>
  );
}

function Field({ label, ...props }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="mb-3 block">
      <span className="mb-1 block text-xs font-medium text-muted">{label}</span>
      {props.type === "password" ? <PasswordInput {...props} /> : <input className="input w-full" {...props} />}
    </label>
  );
}

export function LoginForm({ next }: { next?: string }) {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  return (
    <form
      onSubmit={async (e) => {
        e.preventDefault();
        setBusy(true);
        setError(null);
        try {
          await api.post("/api/auth/login", { email, password });
          await mutate("/api/auth/me");
          router.replace(next && next.startsWith("/") && !next.startsWith("//") ? next : "/");
        } catch (err) {
          setError(errorMessage(err));
          setBusy(false);
        }
      }}
    >
      <Field label="Email" type="email" autoComplete="email" required autoFocus value={email} onChange={(e) => setEmail(e.target.value)} />
      <Field label="Password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
      <p className="-mt-1 mb-3 text-right text-xs">
        <Link className="text-muted underline hover:text-fg" href="/forgot-password">
          Forgot password?
        </Link>
      </p>
      {error && (
        <p role="alert" className="mb-3 text-sm text-danger">
          {error}
        </p>
      )}
      <button className="btn btn-primary w-full" disabled={busy}>
        {busy ? <Spinner /> : "Continue"}
      </button>
    </form>
  );
}

export function SignupForm({ inviteToken, presetEmail }: { inviteToken?: string; presetEmail?: string }) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState(presetEmail ?? "");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  return (
    <form
      onSubmit={async (e) => {
        e.preventDefault();
        setBusy(true);
        setError(null);
        try {
          const res = await api.post<{ workspaceId: string | null }>("/api/auth/signup", { name, email, password, inviteToken });
          await mutate("/api/auth/me");
          router.replace(res.workspaceId ? `/w/${res.workspaceId}` : "/");
        } catch (err) {
          setError(errorMessage(err));
          setBusy(false);
        }
      }}
    >
      <Field label="Name" autoComplete="name" required autoFocus value={name} onChange={(e) => setName(e.target.value)} />
      <Field label="Email" type="email" autoComplete="email" required value={email} readOnly={!!presetEmail} onChange={(e) => setEmail(e.target.value)} />
      <Field label="Password" type="password" autoComplete="new-password" minLength={8} required value={password} onChange={(e) => setPassword(e.target.value)} />
      <p className="-mt-1 mb-3 text-xs text-muted">At least 8 characters.</p>
      {error && (
        <p role="alert" className="mb-3 text-sm text-danger">
          {error}
        </p>
      )}
      <button className="btn btn-primary w-full" disabled={busy}>
        {busy ? <Spinner /> : "Create account"}
      </button>
    </form>
  );
}

/** Ask for a password reset link. The answer never reveals whether an account exists. */
export function ForgotPasswordForm() {
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "busy" | "sent" | "unavailable">("idle");
  const [error, setError] = useState<string | null>(null);
  if (state === "sent")
    return (
      <div role="status" className="text-sm">
        <p>If an account uses <b>{email}</b>, we’ve sent it a link to choose a new password. The link works for one hour.</p>
        <p className="mt-2 text-muted">No email? Check your spam folder, or ask the person who runs this Slate.</p>
      </div>
    );
  if (state === "unavailable")
    return (
      <p role="status" className="text-sm">
        This server can’t send email, so passwords can’t be reset by email here. Ask the person who runs this Slate to set up email (SMTP_URL and APP_URL), or to help you sign in.
      </p>
    );
  return (
    <form
      onSubmit={async (e) => {
        e.preventDefault();
        setState("busy");
        setError(null);
        try {
          const r = await api.post<{ ok: boolean; emailAvailable: boolean }>("/api/auth/password/forgot", { email });
          setState(r.emailAvailable ? "sent" : "unavailable");
        } catch (err) {
          setError(errorMessage(err));
          setState("idle");
        }
      }}
    >
      <Field label="Email" type="email" autoComplete="email" required autoFocus value={email} onChange={(e) => setEmail(e.target.value)} />
      {error && (
        <p role="alert" className="mb-3 text-sm text-danger">
          {error}
        </p>
      )}
      <button className="btn btn-primary w-full" disabled={state === "busy"}>
        {state === "busy" ? <Spinner /> : "Send reset link"}
      </button>
    </form>
  );
}

/** Choose a new password with the token from the reset email. */
export function ResetPasswordForm({ token }: { token: string }) {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  return (
    <form
      onSubmit={async (e) => {
        e.preventDefault();
        setBusy(true);
        setError(null);
        try {
          await api.post("/api/auth/password/reset", { token, password });
          router.replace("/login?reset=1");
        } catch (err) {
          setError(errorMessage(err));
          setBusy(false);
        }
      }}
    >
      <Field label="New password" type="password" autoComplete="new-password" minLength={8} required autoFocus value={password} onChange={(e) => setPassword(e.target.value)} />
      <p className="-mt-1 mb-3 text-xs text-muted">At least 8 characters. You’ll be signed out everywhere else.</p>
      {error && (
        <p role="alert" className="mb-3 text-sm text-danger">
          {error}
        </p>
      )}
      <button className="btn btn-primary w-full" disabled={busy}>
        {busy ? <Spinner /> : "Set new password"}
      </button>
    </form>
  );
}

export function AuthSwitch({ to }: { to: "login" | "signup" }) {
  return (
    <p className="mt-4 text-center text-sm text-muted">
      {to === "login" ? "Already have an account? " : "New here? "}
      <Link className="text-fg underline" href={to === "login" ? "/login" : "/signup"}>
        {to === "login" ? "Log in" : "Create an account"}
      </Link>
    </p>
  );
}
