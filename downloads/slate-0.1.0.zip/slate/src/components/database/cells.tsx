"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { Check, Plus, X, Paperclip, Upload, AlertTriangle, ArrowUpRight, Search } from "lucide-react";
import { api, errorMessage } from "@/client/api";
import { uploadFile, pickFile } from "@/client/upload";
import { Popover, useUi, cx, Spinner } from "@/client/ui";
import { formatCell, formatDate, formatNumber, isDateValue } from "@/lib/format";
import { COLORS, READONLY_TYPES, type CellValue, type PropertyDef, type SelectOption, type DateValue, type FileValue, type Color } from "@/lib/db-types";
import { DatePicker } from "./date-picker";
import { useDb } from "./context";
import { PageIcon, pageTitle } from "../page-icon";
import type { Refs } from "@/client/types";

// ------------------------------------------------------------------ display

export function Tag({ option, onRemove }: { option: Pick<SelectOption, "name" | "color">; onRemove?: () => void }) {
  return (
    <span className={cx("tag", `tag-${option.color}`)}>
      <span className="truncate">{option.name}</span>
      {onRemove && (
        <button className="ml-1 opacity-60 hover:opacity-100" onClick={onRemove} aria-label={`Remove ${option.name}`}>
          <X size={11} />
        </button>
      )}
    </span>
  );
}

export function StatusTag({ option }: { option: Pick<SelectOption, "name" | "color"> }) {
  return (
    <span className={cx("tag gap-1.5 rounded-full", `tag-${option.color}`)}>
      <span className={cx("h-2 w-2 flex-none rounded-full", `bg-current fg-${option.color}`)} />
      <span className="truncate">{option.name}</span>
    </span>
  );
}

export function PersonChip({ name }: { name: string }) {
  return (
    <span className="inline-flex max-w-full items-center gap-1.5">
      <span className="flex h-5 w-5 flex-none items-center justify-center rounded-full bg-subtle text-[10px] font-medium">{name.slice(0, 1).toUpperCase()}</span>
      <span className="truncate">{name}</span>
    </span>
  );
}

export function CellDisplay({ prop, value, refs, wrap = false, hrefFor, compact = false }: { prop: PropertyDef; value: CellValue; refs?: Refs; wrap?: boolean; hrefFor?: (id: string) => string; compact?: boolean }) {
  if (value === null || value === undefined || (Array.isArray(value) && value.length === 0) || value === "") return null;
  if (typeof value === "object" && !Array.isArray(value) && "type" in value && value.type === "error") {
    return (
      <span className="inline-flex items-center gap-1 text-xs text-danger" title={value.message}>
        <AlertTriangle size={12} /> {compact ? "Error" : value.message}
      </span>
    );
  }
  const textCls = wrap ? "whitespace-pre-wrap break-words" : "truncate";
  switch (prop.type) {
    case "title":
      return <span className={cx("font-medium", textCls)}>{String(value)}</span>;
    case "select": {
      const o = prop.config.options?.find((x) => x.id === value);
      return o ? <Tag option={o} /> : null;
    }
    case "status": {
      const o = prop.config.options?.find((x) => x.id === value);
      return o ? <StatusTag option={o} /> : null;
    }
    case "multi_select":
      return (
        <span className={cx("flex gap-1", wrap ? "flex-wrap" : "overflow-hidden")}>
          {(value as string[]).map((id) => {
            const o = prop.config.options?.find((x) => x.id === id);
            return o ? <Tag key={id} option={o} /> : null;
          })}
        </span>
      );
    case "checkbox":
      return <CheckboxBox checked={value === true} />;
    case "number":
      return <span className="block truncate text-right tabular-nums">{typeof value === "number" ? formatNumber(value, prop) : String(value)}</span>;
    case "url":
      return (
        <a href={String(value)} target="_blank" rel="noopener noreferrer nofollow" className={cx("underline decoration-line-strong underline-offset-2", textCls)} onClick={(e) => e.stopPropagation()}>
          {String(value).replace(/^https?:\/\//, "")}
        </a>
      );
    case "email":
      return (
        <a href={`mailto:${value}`} className={cx("underline decoration-line-strong underline-offset-2", textCls)} onClick={(e) => e.stopPropagation()}>
          {String(value)}
        </a>
      );
    case "phone":
      return (
        <a href={`tel:${value}`} className={textCls} onClick={(e) => e.stopPropagation()}>
          {String(value)}
        </a>
      );
    case "date":
    case "created_time":
    case "last_edited_time":
      return isDateValue(value) ? <span className="truncate">{formatDate(value, prop.config.dateFormat)}</span> : null;
    case "person":
    case "created_by":
    case "last_edited_by":
      return (
        <span className={cx("flex gap-2", wrap ? "flex-wrap" : "overflow-hidden")}>
          {(value as string[]).map((id) => (
            <PersonChip key={id} name={refs?.users[id]?.name ?? "Unknown"} />
          ))}
        </span>
      );
    case "files":
      return (
        <span className={cx("flex gap-2", wrap ? "flex-wrap" : "overflow-hidden")}>
          {(value as unknown as FileValue[]).map((f, i) => (
            <a key={i} href={f.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 truncate text-muted hover:text-fg" onClick={(e) => e.stopPropagation()}>
              <Paperclip size={12} /> {f.name}
            </a>
          ))}
        </span>
      );
    case "relation":
      return (
        <span className={cx("flex gap-1.5", wrap ? "flex-wrap" : "overflow-hidden")}>
          {(value as string[]).map((id) => {
            const p = refs?.pages[id];
            const inner = (
              <>
                <PageIcon icon={p?.icon} size={14} />
                <span className="truncate border-b border-line-strong">{pageTitle(p?.title)}</span>
              </>
            );
            return hrefFor ? (
              <Link key={id} href={hrefFor(id)} className="inline-flex max-w-full items-center gap-1" onClick={(e) => e.stopPropagation()}>
                {inner}
              </Link>
            ) : (
              <span key={id} className="inline-flex max-w-full items-center gap-1">
                {inner}
              </span>
            );
          })}
        </span>
      );
    case "formula":
    case "rollup":
      return <ComputedDisplay value={value} prop={prop} wrap={wrap} />;
    default:
      return <span className={textCls}>{formatCell(prop, value)}</span>;
  }
}

function ComputedDisplay({ value, prop, wrap }: { value: CellValue; prop: PropertyDef; wrap: boolean }) {
  if (typeof value === "boolean") return <CheckboxBox checked={value} />;
  if (typeof value === "number") return <span className="block truncate text-right tabular-nums">{formatNumber(value, prop)}</span>;
  if (isDateValue(value)) return <span className="truncate">{formatDate(value)}</span>;
  if (value && typeof value === "object" && !Array.isArray(value) && "type" in value && value.type === "list") {
    return (
      <span className={cx("flex gap-1", wrap ? "flex-wrap" : "overflow-hidden")}>
        {value.items.map((i, k) => (
          <span key={k} className="tag tag-default">
            {formatCell({ ...prop, type: "rich_text" }, i)}
          </span>
        ))}
      </span>
    );
  }
  return <span className={wrap ? "whitespace-pre-wrap break-words" : "truncate"}>{formatCell({ ...prop, type: "rich_text" }, value)}</span>;
}

export function CheckboxBox({ checked, onToggle }: { checked: boolean; onToggle?: () => void }) {
  return (
    <span
      role={onToggle ? "checkbox" : undefined}
      aria-checked={onToggle ? checked : undefined}
      tabIndex={onToggle ? 0 : undefined}
      onClick={
        onToggle
          ? (e) => {
              e.stopPropagation();
              onToggle();
            }
          : undefined
      }
      onKeyDown={onToggle ? (e) => (e.key === " " || e.key === "Enter") && (e.preventDefault(), onToggle()) : undefined}
      className={cx("inline-flex h-4 w-4 flex-none items-center justify-center rounded-[3px] border", checked ? "border-accent bg-accent text-accent-fg" : "border-line-strong", onToggle && "cursor-pointer")}
    >
      {checked && <Check size={12} strokeWidth={3} />}
    </span>
  );
}

// ------------------------------------------------------------------ editing

export function isEditableType(p: PropertyDef) {
  return !READONLY_TYPES.has(p.type);
}

/** Popover editor for one cell. Calls onCommit with the new raw value. */
export function CellEditor({ prop, value, recordId, onCommit, onClose }: { prop: PropertyDef; value: CellValue; recordId: string; onCommit: (v: unknown) => void; onClose: () => void }) {
  switch (prop.type) {
    case "title":
    case "rich_text":
    case "url":
    case "email":
    case "phone":
    case "number":
      return <TextEditor prop={prop} value={value} onCommit={onCommit} onClose={onClose} />;
    case "select":
    case "multi_select":
    case "status":
      return <OptionEditor prop={prop} value={value} onCommit={onCommit} />;
    case "date":
      return <DatePicker value={isDateValue(value) ? value : null} onChange={(v) => onCommit(v)} />;
    case "person":
      return <PersonEditor value={(value as string[]) ?? []} onCommit={onCommit} />;
    case "files":
      return <FilesEditor value={(value as unknown as FileValue[]) ?? []} onCommit={onCommit} />;
    case "relation":
      return <RelationEditor prop={prop} value={(value as string[]) ?? []} recordId={recordId} onCommit={onCommit} />;
    default:
      return <div className="p-3 text-sm text-muted">This value is computed automatically.</div>;
  }
}

function TextEditor({ prop, value, onCommit, onClose }: { prop: PropertyDef; value: CellValue; onCommit: (v: unknown) => void; onClose: () => void }) {
  const [v, setV] = useState(value == null ? "" : String(value));
  const ref = useRef<HTMLTextAreaElement>(null);
  const committed = useRef(false);
  const latest = useRef(v);
  useEffect(() => {
    const el = ref.current;
    if (el) {
      el.focus();
      el.setSelectionRange(el.value.length, el.value.length);
    }
  }, []);
  useEffect(
    () => () => {
      // Clicking outside commits the latest text.
      const cur = latest.current;
      if (!committed.current) onCommit(prop.type === "number" ? (cur.trim() === "" ? null : cur) : cur);
    },
    [], // eslint-disable-line react-hooks/exhaustive-deps
  );
  const commit = () => {
    committed.current = true;
    onCommit(prop.type === "number" ? (v.trim() === "" ? null : v) : v);
    onClose();
  };
  return (
    <div className="w-[min(360px,90vw)] p-1.5">
      <textarea
        ref={ref}
        rows={prop.type === "rich_text" ? 4 : 1}
        className="w-full resize-none rounded bg-transparent px-1.5 py-1 text-sm outline-none"
        value={v}
        inputMode={prop.type === "number" ? "decimal" : prop.type === "email" ? "email" : prop.type === "phone" ? "tel" : prop.type === "url" ? "url" : undefined}
        placeholder={prop.type === "url" ? "https://…" : prop.type === "number" ? "0" : "Empty"}
        onChange={(e) => {
          setV(e.target.value);
          latest.current = e.target.value;
        }}
        onKeyDown={(e) => {
          if (e.key === "Enter" && (!e.shiftKey || prop.type !== "rich_text")) {
            e.preventDefault();
            commit();
          }
          if (e.key === "Escape") {
            committed.current = true;
            onClose();
          }
        }}
      />
    </div>
  );
}

function nextColor(options: SelectOption[]): Color {
  return COLORS[(options.length % (COLORS.length - 1)) + 1];
}

function OptionEditor({ prop, value, onCommit }: { prop: PropertyDef; value: CellValue; onCommit: (v: unknown) => void }) {
  const multi = prop.type === "multi_select";
  const db = useDb();
  const [q, setQ] = useState("");
  const [active, setActive] = useState(0);
  const selected = multi ? ((value as string[]) ?? []) : value ? [value as string] : [];
  const options = prop.config.options ?? [];
  const filtered = options.filter((o) => o.name.toLowerCase().includes(q.toLowerCase()));
  const exact = options.some((o) => o.name.toLowerCase() === q.trim().toLowerCase());
  const canCreate = q.trim() && !exact && prop.type !== "status" && db.editable;
  const toggle = (id: string) => {
    if (multi) onCommit(selected.includes(id) ? selected.filter((x) => x !== id) : [...selected, id]);
    else onCommit(selected[0] === id ? null : id);
  };
  const create = async () => {
    const name = q.trim();
    if (!name) return;
    setQ("");
    // Passing the option name creates it server-side.
    onCommit(multi ? [...selected, name] : name);
    setTimeout(db.refreshMeta, 300);
  };
  const groups = prop.type === "status" ? (prop.config.groups ?? []) : null;
  const renderOption = (o: SelectOption, i: number) => (
    <button
      key={o.id}
      className={cx("flex w-full items-center gap-2 rounded px-2 py-1 text-left", i === active && "bg-hover")}
      onMouseEnter={() => setActive(i)}
      onClick={() => toggle(o.id)}
    >
      {prop.type === "status" ? <StatusTag option={o} /> : <Tag option={o} />}
      {selected.includes(o.id) && <Check size={14} className="ml-auto" />}
    </button>
  );
  return (
    <div className="w-[280px] p-1.5 text-sm">
      <div className="mb-1 flex flex-wrap items-center gap-1 rounded bg-subtle px-1.5 py-1">
        {selected.map((id) => {
          const o = options.find((x) => x.id === id);
          return o ? <Tag key={id} option={o} onRemove={() => toggle(id)} /> : null;
        })}
        <input
          autoFocus
          className="min-w-[60px] flex-1 bg-transparent py-0.5 outline-none"
          placeholder={selected.length ? "" : prop.type === "status" ? "Search status…" : "Search or create…"}
          value={q}
          onChange={(e) => {
            setQ(e.target.value);
            setActive(0);
          }}
          onKeyDown={(e) => {
            if (e.key === "ArrowDown") setActive((a) => Math.min(a + 1, filtered.length - (canCreate ? 0 : 1)));
            if (e.key === "ArrowUp") setActive((a) => Math.max(0, a - 1));
            if (e.key === "Enter") {
              e.preventDefault();
              if (filtered[active]) toggle(filtered[active].id);
              else if (canCreate) create();
            }
            if (e.key === "Backspace" && !q && selected.length) toggle(selected[selected.length - 1]);
          }}
        />
      </div>
      <div className="max-h-64 overflow-y-auto">
        {groups
          ? groups.map((g) => {
              const opts = filtered.filter((o) => g.optionIds.includes(o.id));
              if (!opts.length) return null;
              return (
                <div key={g.id}>
                  <div className="px-2 pb-0.5 pt-1.5 text-xs text-muted">{g.name}</div>
                  {opts.map((o) => renderOption(o, filtered.indexOf(o)))}
                </div>
              );
            })
          : filtered.map((o, i) => renderOption(o, i))}
        {canCreate && (
          <button className={cx("flex w-full items-center gap-2 rounded px-2 py-1 text-left", active === filtered.length && "bg-hover")} onClick={create}>
            <span className="text-muted">Create</span> <Tag option={{ name: q.trim(), color: nextColor(options) }} />
          </button>
        )}
        {!filtered.length && !canCreate && <p className="px-2 py-1.5 text-muted">No options</p>}
      </div>
    </div>
  );
}

function PersonEditor({ value, onCommit }: { value: string[]; onCommit: (v: unknown) => void }) {
  const db = useDb();
  const [q, setQ] = useState("");
  const list = db.members.filter((m) => m.name.toLowerCase().includes(q.toLowerCase()) || m.email.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="w-[260px] p-1.5 text-sm">
      <input autoFocus className="input mb-1 h-7 w-full" placeholder="Search people…" value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="max-h-64 overflow-y-auto">
        {list.map((m) => (
          <button key={m.id} className="flex w-full items-center gap-2 rounded px-2 py-1 text-left hover:bg-hover" onClick={() => onCommit(value.includes(m.id) ? value.filter((x) => x !== m.id) : [...value, m.id])}>
            <PersonChip name={m.name} />
            {value.includes(m.id) && <Check size={14} className="ml-auto" />}
          </button>
        ))}
        {!list.length && <p className="px-2 py-1.5 text-muted">No members found</p>}
      </div>
    </div>
  );
}

function FilesEditor({ value, onCommit }: { value: FileValue[]; onCommit: (v: unknown) => void }) {
  const db = useDb();
  const { toast } = useUi();
  const [busy, setBusy] = useState(false);
  const [url, setUrl] = useState("");
  return (
    <div className="w-[300px] p-2 text-sm">
      {value.map((f, i) => (
        <div key={i} className="group flex items-center gap-2 rounded px-1 py-1 hover:bg-hover">
          <Paperclip size={13} className="text-muted" />
          <a href={f.url} target="_blank" rel="noopener noreferrer" className="flex-1 truncate">
            {f.name}
          </a>
          <button className="icon-btn h-5 w-5 opacity-0 group-hover:opacity-100" onClick={() => onCommit(value.filter((_, k) => k !== i))} aria-label="Remove file">
            <X size={12} />
          </button>
        </div>
      ))}
      <div className="mt-1 flex gap-1">
        <button
          className="btn btn-sm"
          disabled={busy}
          onClick={async () => {
            const f = await pickFile();
            if (!f) return;
            setBusy(true);
            try {
              const u = await uploadFile(db.workspaceId, f);
              onCommit([...value, { name: u.name, url: u.url, fileId: u.id }]);
            } catch (e) {
              toast(errorMessage(e), "error");
            } finally {
              setBusy(false);
            }
          }}
        >
          {busy ? <Spinner size={12} /> : <Upload size={13} />} Upload
        </button>
        <form
          className="flex flex-1"
          onSubmit={(e) => {
            e.preventDefault();
            if (!/^https?:\/\//.test(url)) return;
            onCommit([...value, { name: url.split("/").pop() || url, url }]);
            setUrl("");
          }}
        >
          <input className="input h-[26px] w-full text-xs" placeholder="or paste a link" value={url} onChange={(e) => setUrl(e.target.value)} />
        </form>
      </div>
    </div>
  );
}

function RelationEditor({ prop, value, recordId, onCommit }: { prop: PropertyDef; value: string[]; recordId: string; onCommit: (v: unknown) => void }) {
  const db = useDb();
  const { toast } = useUi();
  const target = prop.config.targetDatabaseId;
  const [q, setQ] = useState("");
  const [list, setList] = useState<{ id: string; title: string; icon: string | null }[] | null>(null);
  const [selectedInfo, setSelectedInfo] = useState<Record<string, { title: string; icon: string | null }>>(() => ({ ...(db.result?.refs.pages ?? {}) }));
  useEffect(() => {
    if (!target) return;
    let alive = true;
    const t = setTimeout(() => {
      api
        .get<{ records: { id: string; title: string; icon: string | null }[] }>(`/api/databases/${target}/records?q=${encodeURIComponent(q)}`)
        .then((r) => {
          if (!alive) return;
          setList(r.records);
          setSelectedInfo((s) => ({ ...s, ...Object.fromEntries(r.records.map((x) => [x.id, { title: x.title, icon: x.icon }])) }));
        })
        .catch(() => alive && setList([]));
    }, 150);
    return () => {
      alive = false;
      clearTimeout(t);
    };
  }, [q, target]);
  const single = prop.config.limit === 1;
  const toggle = (id: string) => onCommit(value.includes(id) ? value.filter((x) => x !== id) : single ? [id] : [...value, id]);
  const options = (list ?? []).filter((r) => r.id !== recordId || target !== db.databaseId || true);
  return (
    <div className="w-[320px] p-1.5 text-sm">
      {value.length > 0 && (
        <div className="mb-1 border-b border-line pb-1">
          {value.map((id) => (
            <div key={id} className="group flex items-center gap-2 rounded px-2 py-1 hover:bg-hover">
              <PageIcon icon={selectedInfo[id]?.icon} size={14} />
              <span className="flex-1 truncate">{pageTitle(selectedInfo[id]?.title)}</span>
              <Link href={db.hrefFor(id)} className="icon-btn h-5 w-5 opacity-0 group-hover:opacity-100" title="Open">
                <ArrowUpRight size={12} />
              </Link>
              <button className="icon-btn h-5 w-5" onClick={() => toggle(id)} aria-label="Remove link">
                <X size={12} />
              </button>
            </div>
          ))}
        </div>
      )}
      <div className="flex items-center gap-1 px-1">
        <Search size={13} className="text-faint" />
        <input autoFocus className="h-7 flex-1 bg-transparent outline-none" placeholder="Link or create a record…" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <div className="max-h-64 overflow-y-auto">
        {!list && <Spinner />}
        {options
          .filter((r) => !value.includes(r.id))
          .map((r) => (
            <button key={r.id} className="flex w-full items-center gap-2 rounded px-2 py-1 text-left hover:bg-hover" onClick={() => toggle(r.id)}>
              <PageIcon icon={r.icon} size={14} />
              <span className="truncate">{pageTitle(r.title)}</span>
              <Plus size={13} className="ml-auto text-faint" />
            </button>
          ))}
        {q.trim() && db.editable && (
          <button
            className="flex w-full items-center gap-2 rounded px-2 py-1 text-left text-muted hover:bg-hover"
            onClick={async () => {
              try {
                const r = await api.post<{ row: { id: string } }>(`/api/databases/${target}/records`, { title: q.trim() });
                setSelectedInfo((s) => ({ ...s, [r.row.id]: { title: q.trim(), icon: null } }));
                onCommit(single ? [r.row.id] : [...value, r.row.id]);
                setQ("");
              } catch (e) {
                toast(errorMessage(e), "error");
              }
            }}
          >
            <Plus size={13} /> New record “{q.trim()}”
          </button>
        )}
      </div>
    </div>
  );
}

/** A cell that shows its value and opens the right editor on click. */
export function EditableCell({
  prop,
  row,
  className,
  wrap,
  placeholder,
}: {
  prop: PropertyDef;
  row: { id: string; values: Record<string, CellValue> };
  className?: string;
  wrap?: boolean;
  placeholder?: string;
}) {
  const db = useDb();
  const [anchor, setAnchor] = useState<HTMLElement | null>(null);
  const value = row.values[prop.id] ?? null;
  const editable = db.editable && isEditableType(prop);
  const content = useMemo(() => <CellDisplay prop={prop} value={value} refs={db.result?.refs} wrap={wrap} hrefFor={db.hrefFor} compact />, [prop, value, db.result?.refs, wrap, db.hrefFor]);
  if (prop.type === "checkbox") {
    return (
      <div className={cx("flex items-center", className)}>
        <CheckboxBox checked={value === true} onToggle={editable ? () => db.setValue(row.id, prop.id, !(value === true)) : undefined} />
      </div>
    );
  }
  return (
    <>
      <div
        className={cx("min-w-0", editable && "min-h-5 cursor-pointer", className)}
        role={editable ? "button" : undefined}
        tabIndex={editable ? 0 : undefined}
        aria-haspopup={editable ? "dialog" : undefined}
        // An empty cell has no text to name the button by.
        aria-label={editable && (value === null || value === "" || (Array.isArray(value) && !value.length)) ? `${prop.name}: empty` : undefined}
        onClick={(e) => {
          if (!editable) return;
          e.stopPropagation();
          setAnchor(e.currentTarget);
        }}
        onKeyDown={(e) => {
          if (editable && (e.key === "Enter" || e.key === " ")) {
            e.preventDefault();
            setAnchor(e.currentTarget);
          }
        }}
      >
        {content ?? (placeholder ? <span className="text-faint">{placeholder}</span> : null)}
      </div>
      {anchor && (
        <Popover anchor={anchor} open onClose={() => setAnchor(null)} placement="bottom-start" offset={-anchor.offsetHeight}>
          <CellEditor
            prop={prop}
            value={value}
            recordId={row.id}
            onClose={() => setAnchor(null)}
            onCommit={(v) => {
              const same = JSON.stringify(v ?? null) === JSON.stringify(value ?? null) || (v === "" && value == null);
              if (!same) db.setValue(row.id, prop.id, v);
              if (prop.type === "select" || prop.type === "status") setAnchor(null);
            }}
          />
        </Popover>
      )}
    </>
  );
}

export { formatDate };
export type { DateValue };
