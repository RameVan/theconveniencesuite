"use client";
import { createContext, useContext } from "react";
import type { PropertyDef, ViewDef, ViewConfig, CellValue, QueryRow } from "@/lib/db-types";
import type { DatabaseMeta, Member, QueryResponse } from "@/client/types";

export interface DbCtx {
  databaseId: string;
  workspaceId: string;
  meta: DatabaseMeta;
  view: ViewDef;
  /** Effective config (saved view config). */
  config: ViewConfig;
  props: PropertyDef[];
  visibleProps: PropertyDef[];
  titleProp: PropertyDef;
  result: QueryResponse | undefined;
  rowsById: Map<string, QueryRow>;
  members: Member[];
  editable: boolean;
  shareToken?: string | null;
  setValue: (recordId: string, propertyId: string, value: unknown) => Promise<void>;
  createRecord: (values?: Record<string, unknown>, opts?: { open?: boolean; templateId?: string | null }) => Promise<string | null>;
  openRecord: (recordId: string) => void;
  updateConfig: (patch: Partial<ViewConfig>) => Promise<void>;
  refresh: () => void;
  refreshMeta: () => void;
  /** The views shown as tabs: the database's, or a linked block's own views. */
  views: ViewDef[];
  /** Whether views can be added/changed here (database edit access, or the block's page is editable). */
  viewsEditable: boolean;
  /** True when the views belong to this block, not to the database. */
  ownViews: boolean;
  /** Linked blocks still showing the database's views: copy them into the block. */
  useOwnViews?: () => void;
  viewOps: ViewOps;
  /** Month shown by calendar views (live calendars only fetch records around it). */
  calendarMonth: Date;
  setCalendarMonth: (month: Date) => void;
  /** Records without a date in a live calendar view (null when all rows are loaded). */
  undatedCount: number | null;
  /** More rows exist than are loaded (paged views); loadMore() fetches the next page. */
  hasMore: boolean;
  loadingMore: boolean;
  loadMore: () => void;
  hrefFor: (pageId: string) => string;
}

export interface ViewOps {
  add: (type: ViewDef["type"]) => Promise<string | null>;
  rename: (id: string, name: string) => Promise<void>;
  setType: (id: string, type: ViewDef["type"]) => Promise<void>;
  duplicate: (id: string) => Promise<string | null>;
  remove: (id: string) => Promise<void>;
  /** Put a view before `beforeId` (or last, with null). */
  move: (id: string, beforeId: string | null) => Promise<void>;
}

export const DatabaseContext = createContext<DbCtx | null>(null);

export function useDb() {
  const ctx = useContext(DatabaseContext);
  if (!ctx) throw new Error("DatabaseContext missing");
  return ctx;
}

export function cellOf(row: QueryRow | undefined, propertyId: string): CellValue {
  return row?.values[propertyId] ?? null;
}
