"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import useSWR, { mutate as globalMutate } from "swr";
import useSWRInfinite from "swr/infinite";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowUpRight, Database } from "lucide-react";
import { api, errorMessage } from "@/client/api";
import { useDatabaseMeta, useMembers, useLocalStorage, refreshTree } from "@/client/hooks";
import { useOptionalWorkspace } from "@/client/workspace-context";
import { useUi, Spinner, cx } from "@/client/ui";
import type { PropertyDef, ViewConfig, ViewDef, QueryRow, FilterGroup } from "@/lib/db-types";
import type { DatabaseMeta, QueryResponse, Member } from "@/client/types";
import { DatabaseContext, type DbCtx, type ViewOps } from "./context";
import { defaultViewConfig } from "@/lib/db-types";
import { uid } from "@/lib/uid";
import { ViewTabs, Toolbar } from "./toolbar";
import { TableView } from "./views/table";
import { BoardView } from "./views/board";
import { ListView, GalleryView } from "./views/cards";
import { CalendarView, calendarGrid, MAX_SPAN_DAYS } from "./views/calendar";
import { TimelineView } from "./views/timeline";
import { ChartView } from "./views/chart";
import { PageIcon, pageTitle } from "../page-icon";

interface Props {
  databaseId: string;
  inline?: boolean;
  full?: boolean;
  viewId?: string | null;
  onViewChange?: (id: string) => void;
  shareToken?: string | null;
  /** A linked block's own views (instead of the database's); changed through onOwnViewsChange. */
  ownViews?: ViewDef[] | null;
  onOwnViewsChange?: (views: ViewDef[]) => void;
  /** The block holding ownViews (public pages look its views up on the server). */
  block?: { pageId: string; blockId: string } | null;
  /** Older linked blocks: start using separate copies of the database's views. */
  onUseOwnViews?: (views: ViewDef[]) => void;
}

/** Views with `id` moved before `beforeId` (or to the end). */
function reordered(views: ViewDef[], id: string, beforeId: string | null): ViewDef[] {
  const moving = views.find((v) => v.id === id);
  if (!moving || id === beforeId) return views;
  const rest = views.filter((v) => v.id !== id);
  const at = beforeId ? rest.findIndex((v) => v.id === beforeId) : -1;
  return at < 0 ? [...rest, moving] : [...rest.slice(0, at), moving, ...rest.slice(at)];
}

const PAGED_VIEWS = new Set(["table", "list", "gallery", "board", "timeline", "chart"]);
/** Rows per request in paged views, and rows per group (board column) added by "Load more". */
const PAGE = 100;
const GROUP_PAGE = 50;

type ShareQuery = QueryResponse & { views: ViewDef[]; properties: PropertyDef[] };

export function DatabaseView(props: Props) {
  if (props.shareToken) return <SharedDatabaseView {...props} shareToken={props.shareToken} />;
  return <LiveDatabaseView {...props} />;
}

function LiveDatabaseView({ databaseId, inline, viewId: viewProp, onViewChange, ownViews, onOwnViewsChange, onUseOwnViews, block }: Props) {
  const ws = useOptionalWorkspace();
  const { data: meta, error, mutate: mutateMeta } = useDatabaseMeta(databaseId);
  const { data: membersData } = useMembers(ws?.workspace.id ?? null);
  if (error)
    return (
      <div className="rounded-md border border-line p-4 text-sm text-muted">
        <Database size={14} className="mr-1 inline" /> {error.status === 404 ? "This database was deleted or you don’t have access to it." : errorMessage(error)}
      </div>
    );
  if (!meta)
    return (
      <div className="space-y-2 py-2">
        <div className="skeleton h-6 w-48" />
        <div className="skeleton h-8 w-full" />
        <div className="skeleton h-8 w-full" />
      </div>
    );
  return (
    <DatabaseInner
      meta={meta}
      members={membersData?.members ?? []}
      inline={!!inline}
      viewProp={viewProp}
      onViewChange={onViewChange}
      ownViews={ownViews?.length ? ownViews : null}
      onOwnViewsChange={onOwnViewsChange}
      // Only links to a database elsewhere (not the database living in this page) can detach.
      onUseOwnViews={onUseOwnViews && !ownViews?.length && block && meta.parentId !== block.pageId ? onUseOwnViews : undefined}
      editable={meta.access === "edit" || meta.access === "full"}
      refreshMeta={() => mutateMeta()}
      workspaceId={ws?.workspace.id ?? meta.workspaceId ?? ""}
    />
  );
}

function DatabaseInner({
  meta,
  members,
  inline,
  viewProp,
  onViewChange,
  editable,
  refreshMeta,
  workspaceId,
  shareToken,
  sharedResult,
  ownViews,
  onOwnViewsChange,
  onUseOwnViews,
}: {
  onUseOwnViews?: (views: ViewDef[]) => void;
  ownViews?: ViewDef[] | null;
  onOwnViewsChange?: (views: ViewDef[]) => void;
  meta: DatabaseMeta;
  members: Member[];
  inline: boolean;
  viewProp?: string | null;
  onViewChange?: (id: string) => void;
  editable: boolean;
  refreshMeta: () => void;
  workspaceId: string;
  shareToken?: string | null;
  sharedResult?: { data: ShareQuery | undefined; setView: (id: string) => void; refresh: () => void };
}) {
  const router = useRouter();
  const { toast } = useUi();
  const [storedView, setStoredView] = useLocalStorage<string | null>(`slate-view-${meta.id}`, null);
  const [localView, setLocalView] = useState<string | null>(null);
  const activeId = viewProp ?? localView ?? storedView;
  const views = ownViews ?? meta.views;
  const view = views.find((v) => v.id === activeId) ?? views[0];
  const viewsEditable = ownViews ? !!onOwnViewsChange : editable;
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  // Viewers can still filter/sort locally without saving the view.
  const [localConfigs, setLocalConfigs] = useState<Record<string, Partial<ViewConfig>>>({});
  useEffect(() => {
    const t = setTimeout(() => setDebounced(search), 200);
    return () => clearTimeout(t);
  }, [search]);

  const localConfig = useMemo(() => (view ? (localConfigs[view.id] ?? {}) : {}), [localConfigs, view]);
  const config: ViewConfig = useMemo(() => ({ ...(view?.config ?? {}), ...localConfig }), [view, localConfig]);
  const [calendarMonth, setCalendarMonth] = useState(() => new Date(new Date().getFullYear(), new Date().getMonth(), 1));
  // Live calendars fetch the records that can appear in the visible weeks: starting from
  // MAX_SPAN_DAYS before the grid to its end (a day of margin each side for time zones).
  const calendarFilter = useMemo<FilterGroup | null>(() => {
    if (shareToken || view?.type !== "calendar" || !config.dateProperty) return null;
    const { gridStart, weeks } = calendarGrid(calendarMonth);
    const day = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    const from = day(new Date(gridStart.getFullYear(), gridStart.getMonth(), gridStart.getDate() - MAX_SPAN_DAYS - 1));
    const to = day(new Date(gridStart.getFullYear(), gridStart.getMonth(), gridStart.getDate() + weeks * 7));
    return {
      kind: "group",
      id: "calendar-window",
      op: "and",
      filters: [
        ...(config.filter ? [config.filter] : []),
        { kind: "condition", id: "calendar-from", propertyId: config.dateProperty, operator: "on_or_after", value: from },
        { kind: "condition", id: "calendar-to", propertyId: config.dateProperty, operator: "on_or_before", value: to },
      ],
    };
  }, [shareToken, view?.type, config.dateProperty, config.filter, calendarMonth]);
  const queryConfig = useMemo(() => {
    // A block's own view is not stored with the database: its whole configuration is sent.
    const extra: Partial<ViewConfig> = ownViews ? { ...(view?.config ?? {}), ...localConfig } : { ...localConfig };
    if (view?.type === "chart" && config.chartValueProperty) {
      extra.aggregations = { ...(config.aggregations ?? {}), [config.chartValueProperty]: config.chartAggregate ?? "sum" };
    }
    if (calendarFilter) extra.filter = calendarFilter;
    return Object.keys(extra).length ? extra : null;
  }, [localConfig, view?.type, view?.config, config, ownViews, calendarFilter]);

  // Undated records of a live calendar (not part of the date-window query).
  const undatedKey =
    calendarFilter && view && config.dateProperty
      ? JSON.stringify({
          url: `/api/databases/${meta.id}/query`,
          viewId: ownViews ? null : view.id,
          search: debounced || null,
          config: {
            ...(ownViews ? (view.config ?? {}) : {}),
            ...localConfig,
            filter: { kind: "group", id: "undated", op: "and", filters: [...(config.filter ? [config.filter] : []), { kind: "condition", id: "undated-date", propertyId: config.dateProperty, operator: "is_empty" }] },
          },
        })
      : null;
  const { data: undated } = useSWR<QueryResponse>(undatedKey, (k: string) => {
    const { url, ...body } = JSON.parse(k);
    return api.post<QueryResponse>(url, { ...body, offset: 0, limit: 1 });
  });

  // Lists, tables, galleries, boards and timelines load rows page by page (boards: rows per
  // column); charts load one row per group; calendars load the weeks on screen.
  const paged = !!view && PAGED_VIEWS.has(view.type);
  const grouped = paged && !!config.groupBy;
  const baseKey = !shareToken && view ? JSON.stringify([meta.id, view.id, debounced, queryConfig]) : null;
  const [groupLimitState, setGroupLimit] = useState({ key: "", n: GROUP_PAGE });
  const groupLimit = groupLimitState.key === baseKey ? groupLimitState.n : GROUP_PAGE;
  type Page = QueryResponse & { _viewId?: string };
  const {
    data: pages,
    mutate: mutateQuery,
    size,
    setSize,
  } = useSWRInfinite<Page>(
    (i: number, prev: Page | null) => {
      if (!baseKey || !view) return null;
      if (prev && !prev.hasMore) return null;
      if (i > 0 && (!paged || grouped)) return null;
      // Charts only need each group's count and aggregations: one row per group.
      return [`/api/databases/${meta.id}/query`, view.id, debounced, JSON.stringify(queryConfig), i, paged ? (grouped ? (view.type === "chart" ? 1 : groupLimit) : PAGE) : 0, grouped, !!ownViews];
    },
    async ([url, vid, q, cfg, i, n, g, own]: [string, string, string, string, number, number, boolean, boolean]) => {
      const paging = !n ? {} : g ? { offset: 0, limit: PAGE, groupLimit: n } : { offset: i * PAGE, limit: PAGE };
      return { ...(await api.post<QueryResponse>(url, { viewId: vid, search: q || null, config: JSON.parse(cfg), ...paging, ...(own ? { viewId: null } : {}) })), _viewId: vid };
    },
    { keepPreviousData: true, revalidateOnFocus: true, revalidateFirstPage: false },
  );
  const liveResult = useMemo<Page | undefined>(() => {
    if (!pages?.length) return undefined;
    const last = pages[pages.length - 1];
    return pages.length === 1 ? pages[0] : { ...pages[0], rows: pages.flatMap((pg) => pg.rows), hasMore: last.hasMore };
  }, [pages]);
  // Data kept from another view while the new one loads is not shown.
  const result = shareToken ? sharedResult?.data : liveResult && liveResult._viewId === view?.id ? liveResult : undefined;
  const hasMore = !!result && (grouped ? !!result.groups?.some((g) => g.rowIds.length < g.count) : !!result.hasMore);
  const loadingMore = !shareToken && !!pages && size > pages.length;
  const loadMore = useCallback(() => {
    if (!hasMore || loadingMore || !baseKey) return;
    if (grouped) setGroupLimit({ key: baseKey, n: Math.min(5_000, groupLimit + GROUP_PAGE) });
    else setSize(size + 1);
  }, [hasMore, loadingMore, baseKey, grouped, groupLimit, setSize, size]);

  const selectView = (id: string) => {
    if (onViewChange) onViewChange(id);
    else {
      setLocalView(id);
      if (!inline) setStoredView(id);
    }
    sharedResult?.setView(id);
  };

  const refresh = useCallback(() => {
    if (shareToken) sharedResult?.refresh();
    else mutateQuery();
  }, [mutateQuery, shareToken, sharedResult]);

  const updateConfig = useCallback(
    async (patch: Partial<ViewConfig>) => {
      if (!view) return;
      if (ownViews && onOwnViewsChange) {
        onOwnViewsChange(ownViews.map((v) => (v.id === view.id ? { ...v, config: { ...v.config, ...patch } } : v)));
        return;
      }
      if (!editable || ownViews) {
        setLocalConfigs((all) => ({ ...all, [view.id]: { ...(all[view.id] ?? {}), ...patch } }));
        return;
      }
      // Optimistic: patch the view in the meta cache.
      globalMutate(
        `/api/databases/${meta.id}`,
        (m: DatabaseMeta | undefined) => (m ? { ...m, views: m.views.map((v) => (v.id === view.id ? { ...v, config: { ...v.config, ...patch } } : v)) } : m),
        { revalidate: false },
      );
      try {
        await api.patch(`/api/views/${view.id}`, { config: patch });
        refreshMeta();
        mutateQuery();
      } catch (e) {
        toast(errorMessage(e), "error");
        refreshMeta();
      }
    },
    [view, editable, meta.id, refreshMeta, mutateQuery, toast, ownViews, onOwnViewsChange],
  );

  const viewOps = useMemo<ViewOps>(() => {
    const report = (e: unknown) => (toast(errorMessage(e), "error"), null);
    if (ownViews) {
      const save = (next: ViewDef[]) => onOwnViewsChange?.(next.map((v, i) => ({ ...v, position: i })));
      const title = (t: string) => t[0].toUpperCase() + t.slice(1);
      return {
        add: async (type) => {
          const v: ViewDef = { id: uid(), databaseId: meta.id, name: title(type), type, config: defaultViewConfig(type, meta.properties), position: ownViews.length };
          save([...ownViews, v]);
          return v.id;
        },
        rename: async (id, name) => save(ownViews.map((v) => (v.id === id ? { ...v, name } : v))),
        // Keep the view's settings; fill in what the new layout needs (group, date property, ...).
        setType: async (id, type) => save(ownViews.map((v) => (v.id === id ? { ...v, type, config: { ...defaultViewConfig(type, meta.properties), ...v.config } } : v))),
        duplicate: async (id) => {
          const at = ownViews.findIndex((v) => v.id === id);
          if (at < 0) return null;
          const copy: ViewDef = { ...ownViews[at], id: uid(), name: ownViews[at].name + " (copy)" };
          save([...ownViews.slice(0, at + 1), copy, ...ownViews.slice(at + 1)]);
          return copy.id;
        },
        remove: async (id) => save(ownViews.filter((v) => v.id !== id)),
        move: async (id, beforeId) => save(reordered(ownViews, id, beforeId)),
      };
    }
    return {
      add: async (type) => {
        const r = await api.post<{ view: ViewDef }>("/api/databases/" + meta.id + "/views", { type }).catch(report);
        refreshMeta();
        return r?.view.id ?? null;
      },
      rename: async (id, name) => {
        await api.patch("/api/views/" + id, { name }).catch(report);
        refreshMeta();
      },
      setType: async (id, type) => {
        await api.patch("/api/views/" + id, { type }).catch(report);
        refreshMeta();
      },
      duplicate: async (id) => {
        const r = await api.post<{ id: string }>("/api/views/" + id + "/duplicate").catch(report);
        refreshMeta();
        return r?.id ?? null;
      },
      remove: async (id) => {
        await api.del("/api/views/" + id).catch(report);
        refreshMeta();
      },
      move: async (id, beforeId) => {
        // New positions for the views whose position changes (all of them only when positions tie).
        const next = reordered(meta.views, id, beforeId);
        const i = next.findIndex((v) => v.id === id);
        const prev = next[i - 1]?.position;
        const after = next[i + 1]?.position;
        let changes: { id: string; position: number }[];
        if (prev === undefined && after === undefined) return;
        else if (prev === undefined) changes = [{ id, position: after! - 1 }];
        else if (after === undefined) changes = [{ id, position: prev + 1 }];
        else if (after - prev > 1e-9) changes = [{ id, position: (prev + after) / 2 }];
        else changes = next.map((v, k) => ({ id: v.id, position: k }));
        // Show the new order at once.
        globalMutate(`/api/databases/${meta.id}`, (m: DatabaseMeta | undefined) => (m ? { ...m, views: next } : m), { revalidate: false });
        for (const c of changes) await api.patch("/api/views/" + c.id, { position: c.position }).catch(report);
        refreshMeta();
      },
    };
  }, [ownViews, onOwnViewsChange, meta.id, meta.properties, meta.views, refreshMeta, toast]);

  const setValue = useCallback(
    async (recordId: string, propertyId: string, value: unknown) => {
      const prop = meta.properties.find((p) => p.id === propertyId);
      if (!prop) return;
      mutateQuery(
        (all) =>
          all?.map((d) => ({
            ...d,
            rows: d.rows.map((r) => (r.id === recordId ? { ...r, title: prop.type === "title" ? String(value ?? "") : r.title, values: { ...r.values, [propertyId]: (value ?? null) as QueryRow["values"][string] } } : r)),
          })),
        { revalidate: false },
      );
      try {
        await api.patch(`/api/records/${recordId}`, prop.type === "title" ? { title: String(value ?? "") } : { values: { [propertyId]: value } });
        if (prop.type === "title") refreshTree(workspaceId);
        if (["select", "multi_select", "status"].includes(prop.type)) refreshMeta();
      } catch (e) {
        toast(errorMessage(e), "error");
      } finally {
        mutateQuery();
        globalMutate(`/api/pages/${recordId}`);
      }
    },
    [meta.properties, mutateQuery, toast, workspaceId, refreshMeta],
  );

  const openRecord = useCallback((id: string) => router.push(`/w/${workspaceId}/p/${id}`), [router, workspaceId]);

  const createRecord = useCallback(
    async (values?: Record<string, unknown>, opts?: { open?: boolean; templateId?: string | null }) => {
      try {
        const r = await api.post<{ row: { id: string } }>(`/api/databases/${meta.id}/records`, { values: values ?? {}, templateId: opts?.templateId ?? null });
        await mutateQuery();
        if (opts?.open) openRecord(r.row.id);
        return r.row.id;
      } catch (e) {
        toast(errorMessage(e), "error");
        return null;
      }
    },
    [meta.id, mutateQuery, openRecord, toast],
  );

  const props = meta.properties;
  const titleProp = props.find((p) => p.type === "title") ?? props[0];
  const visibleIds = config.visibleProperties ?? props.map((p) => p.id);
  const visibleProps = [titleProp, ...visibleIds.map((id) => props.find((p) => p.id === id)).filter((p): p is PropertyDef => !!p && p.type !== "title")];
  const rowsById = useMemo(() => new Map((result?.rows ?? []).map((r) => [r.id, r])), [result]);

  if (!view) return <div className="text-sm text-muted">This database has no views.</div>;

  const ctx: DbCtx = {
    databaseId: meta.id,
    workspaceId,
    meta,
    view,
    config,
    props,
    visibleProps,
    titleProp,
    result,
    rowsById,
    members,
    editable,
    shareToken,
    setValue,
    createRecord,
    openRecord: shareToken ? (id) => router.push(`/share/${shareToken}?page=${id}`) : openRecord,
    updateConfig,
    refresh,
    refreshMeta,
    calendarMonth,
    setCalendarMonth,
    undatedCount: calendarFilter ? (undated?.matched ?? null) : null,
    views,
    viewsEditable,
    ownViews: !!ownViews,
    useOwnViews: onUseOwnViews ? () => onUseOwnViews(meta.views) : undefined,
    viewOps,
    hasMore: !shareToken && hasMore,
    loadingMore,
    loadMore,
    hrefFor: shareToken ? (id) => `/share/${shareToken}?page=${id}` : (id) => `/w/${workspaceId}/p/${id}`,
  };

  return (
    <DatabaseContext.Provider value={ctx}>
      <section className={cx("min-w-0 max-w-full", inline && "my-1")} aria-label={`Database ${meta.title || "Untitled"}`}>
        {inline && (
          <div className="mb-1 flex items-center gap-2">
            <Link href={ctx.hrefFor(meta.id)} className="flex min-w-0 items-center gap-2 rounded px-1 text-lg font-semibold hover:bg-hover">
              <PageIcon icon={meta.icon} kind="database" size={18} />
              <span className="truncate">{pageTitle(meta.title)}</span>
              <ArrowUpRight size={14} className="flex-none text-faint" />
            </Link>
          </div>
        )}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line pb-1">
          <ViewTabs activeId={view.id} onSelect={selectView} />
          <Toolbar search={search} onSearch={setSearch} onNew={(templateId) => createRecord({}, { open: true, templateId })} />
        </div>
        {!result ? (
          <div className="flex justify-center py-8">
            <Spinner />
          </div>
        ) : (
          <div className="pt-1">
            {view.type === "table" && <TableView />}
            {view.type === "board" && <BoardView />}
            {view.type === "list" && <ListView />}
            {view.type === "gallery" && <GalleryView />}
            {view.type === "calendar" && <CalendarView />}
            {view.type === "timeline" && <TimelineView />}
            {view.type === "chart" && <ChartView />}
            {result.total > 0 && result.rows.length === 0 && <p className="py-3 text-sm text-muted">No records match the current filters{search ? " and search" : ""}.</p>}
          </div>
        )}
      </section>
    </DatabaseContext.Provider>
  );
}

function SharedDatabaseView({ databaseId, inline, shareToken, ownViews, block, viewId: initialView }: Props & { shareToken: string }) {
  const [viewId, setViewId] = useState<string | null>(ownViews?.length ? (initialView ?? null) : null);
  // Blocks with their own views are queried through the block, so the server uses its views.
  const viaBlock = ownViews?.length && block ? block : null;
  const key = [`/api/share/${shareToken}/query`, databaseId, viewId, viaBlock?.blockId];
  const { data, error, mutate } = useSWR<ShareQuery>(key, () => api.post<ShareQuery>(`/api/share/${shareToken}/query`, { databaseId, viewId, block: viaBlock }));
  if (error) return <div className="rounded-md border border-line p-4 text-sm text-muted">This database is not available.</div>;
  if (!data)
    return (
      <div className="flex justify-center py-6">
        <Spinner />
      </div>
    );
  const meta: DatabaseMeta = { id: databaseId, title: "", icon: null, properties: data.properties, views: data.views, templates: [], defaultTemplateId: null, access: "view" };
  return (
    <DatabaseInner
      meta={meta}
      members={[]}
      inline={!!inline}
      viewProp={viewId ?? data.views[0]?.id}
      onViewChange={setViewId}
      editable={false}
      refreshMeta={() => mutate()}
      workspaceId=""
      shareToken={shareToken}
      sharedResult={{ data, setView: setViewId, refresh: () => mutate() }}
    />
  );
}
