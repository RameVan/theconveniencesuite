"use client";
import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cx } from "@/client/ui";
import type { DateValue } from "@/lib/db-types";

const pad = (n: number) => String(n).padStart(2, "0");
const ymd = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parseYmd = (s: string) => {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
  return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
};

export function MonthGrid({ month, selected, rangeEnd, onPick }: { month: Date; selected: string | null; rangeEnd?: string | null; onPick: (ymd: string) => void }) {
  const first = new Date(month.getFullYear(), month.getMonth(), 1);
  const startDow = (first.getDay() + 6) % 7; // Monday first
  const days = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();
  const cells: (Date | null)[] = [...Array(startDow).fill(null), ...Array.from({ length: days }, (_, i) => new Date(month.getFullYear(), month.getMonth(), i + 1))];
  const today = ymd(new Date());
  return (
    <div className="grid grid-cols-7 gap-0.5 text-center text-xs">
      {["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"].map((d) => (
        <div key={d} className="py-1 text-faint">
          {d}
        </div>
      ))}
      {cells.map((d, i) => {
        if (!d) return <div key={i} />;
        const key = ymd(d);
        const inRange = selected && rangeEnd && key >= selected && key <= rangeEnd;
        const isSel = key === selected || key === rangeEnd;
        return (
          <button
            key={i}
            type="button"
            onClick={() => onPick(key)}
            className={cx("h-7 rounded text-[13px]", isSel ? "bg-accent text-accent-fg" : inRange ? "bg-accent-soft" : "hover:bg-hover", key === today && !isSel && "font-bold text-accent")}
          >
            {d.getDate()}
          </button>
        );
      })}
    </div>
  );
}

export function DatePicker({ value, onChange }: { value: DateValue | null; onChange: (v: DateValue | null) => void }) {
  const [hasEnd, setHasEnd] = useState(!!value?.end);
  const [includeTime, setIncludeTime] = useState(!!value?.includeTime);
  const [picking, setPicking] = useState<"start" | "end">("start");
  const startDate = value?.start ? (value.includeTime ? new Date(value.start) : parseYmd(value.start)) : null;
  const [month, setMonth] = useState(() => startDate ?? new Date());
  const startYmd = startDate ? ymd(startDate) : null;
  const endYmd = value?.end ? ymd(value.includeTime ? new Date(value.end) : parseYmd(value.end)!) : null;
  const startTime = value?.includeTime && startDate ? `${pad(startDate.getHours())}:${pad(startDate.getMinutes())}` : "09:00";

  const emit = (start: string | null, end: string | null, time: boolean, t = startTime) => {
    if (!start) return onChange(null);
    if (time) {
      const toIso = (d: string) => new Date(`${d}T${t}`).toISOString();
      onChange({ start: toIso(start), end: end ? toIso(end) : null, includeTime: true });
    } else onChange({ start, end, includeTime: false });
  };

  return (
    <div className="w-[264px] p-3 text-sm">
      <div className="mb-2 flex gap-1">
        <input
          className={cx("input h-7 flex-1 text-xs", picking === "start" && "border-accent")}
          value={startYmd ?? ""}
          placeholder="Start"
          onFocus={() => setPicking("start")}
          onChange={(e) => parseYmd(e.target.value) && emit(e.target.value, hasEnd ? endYmd : null, includeTime)}
        />
        {hasEnd && (
          <input
            className={cx("input h-7 flex-1 text-xs", picking === "end" && "border-accent")}
            value={endYmd ?? ""}
            placeholder="End"
            onFocus={() => setPicking("end")}
            onChange={(e) => parseYmd(e.target.value) && emit(startYmd, e.target.value, includeTime)}
          />
        )}
      </div>
      <div className="mb-1 flex items-center justify-between">
        <span className="font-medium">{month.toLocaleString(undefined, { month: "long", year: "numeric" })}</span>
        <span className="flex">
          <button type="button" className="icon-btn h-6 w-6" onClick={() => setMonth(new Date())} title="Today">
            •
          </button>
          <button type="button" className="icon-btn h-6 w-6" onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() - 1, 1))} aria-label="Previous month">
            <ChevronLeft size={14} />
          </button>
          <button type="button" className="icon-btn h-6 w-6" onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() + 1, 1))} aria-label="Next month">
            <ChevronRight size={14} />
          </button>
        </span>
      </div>
      <MonthGrid
        month={month}
        selected={startYmd}
        rangeEnd={hasEnd ? endYmd : null}
        onPick={(d) => {
          if (hasEnd && picking === "end") {
            emit(startYmd && d < startYmd ? d : startYmd, startYmd && d < startYmd ? startYmd : d, includeTime);
            setPicking("start");
          } else {
            emit(d, hasEnd ? (endYmd && endYmd >= d ? endYmd : null) : null, includeTime);
            if (hasEnd) setPicking("end");
          }
        }}
      />
      <div className="mt-3 space-y-2 border-t border-line pt-2">
        <label className="flex items-center justify-between">
          End date
          <input
            type="checkbox"
            checked={hasEnd}
            onChange={(e) => {
              setHasEnd(e.target.checked);
              if (!e.target.checked) emit(startYmd, null, includeTime);
              else setPicking("end");
            }}
          />
        </label>
        <label className="flex items-center justify-between">
          Include time
          <input
            type="checkbox"
            checked={includeTime}
            onChange={(e) => {
              setIncludeTime(e.target.checked);
              emit(startYmd, hasEnd ? endYmd : null, e.target.checked);
            }}
          />
        </label>
        {includeTime && (
          <input type="time" className="input h-7 w-full" value={startTime} onChange={(e) => emit(startYmd, hasEnd ? endYmd : null, true, e.target.value)} />
        )}
        <button type="button" className="link-btn w-full text-left" onClick={() => onChange(null)}>
          Clear
        </button>
      </div>
    </div>
  );
}
