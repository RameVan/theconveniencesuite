"use client";
import { useEffect, useRef } from "react";
import { Spinner } from "@/client/ui";
import { useDb } from "./context";

/** Loads the next page when scrolled near (or on click); shows how many rows are loaded. */
export function LoadMore({ shown, total }: { shown: number; total: number }) {
  const db = useDb();
  const ref = useRef<HTMLDivElement>(null);
  const { hasMore, loadMore, loadingMore } = db;
  useEffect(() => {
    const el = ref.current;
    if (!el || !hasMore) return;
    const io = new IntersectionObserver((entries) => entries.some((e) => e.isIntersecting) && loadMore(), { rootMargin: "600px 0px" });
    io.observe(el);
    return () => io.disconnect();
  }, [hasMore, loadMore]);
  if (!hasMore) return null;
  return (
    <div ref={ref} className="flex items-center gap-3 px-2 py-2 text-sm text-muted">
      <button className="link-btn" onClick={loadMore} disabled={loadingMore}>
        Load more
      </button>
      <span className="text-xs text-faint">
        {shown.toLocaleString()} of {total.toLocaleString()}
      </span>
      {loadingMore && <Spinner size={14} />}
    </div>
  );
}

/** "Load more" for one group of a grouped view (loads more rows in every group). */
export function GroupLoadMore({ shown, total }: { shown: number; total: number }) {
  const db = useDb();
  if (shown >= total || db.shareToken) return null;
  return (
    <button className="flex w-full items-center gap-2 px-2 py-1.5 text-left text-sm text-muted hover:bg-hover" onClick={db.loadMore} disabled={db.loadingMore}>
      Load more <span className="text-xs text-faint">{shown.toLocaleString()} of {total.toLocaleString()}</span>
    </button>
  );
}
