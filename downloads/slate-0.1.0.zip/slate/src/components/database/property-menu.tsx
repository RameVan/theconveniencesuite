"use client";
import { useMemo, useState } from "react";
import useSWR from "swr";
import {
  ArrowUp,
  ArrowDown,
  EyeOff,
  Trash2,
  Filter,
  Type,
  Hash,
  CircleDot,
  List,
  Loader,
  Calendar,
  CheckSquare,
  Link2,
  AtSign,
  Phone,
  User,
  Paperclip,
  ArrowUpRight,
  Search,
  Sigma,
  Clock,
  UserCheck,
  Fingerprint,
  GripVertical,
  Plus,
  X,
  WrapText,
  ChevronRight,
  Text,
} from "lucide-react";
import { api, errorMessage } from "@/client/api";
import { Popover, Menu, useUi, cx, type MenuItem } from "@/client/ui";
import { compile, FUNCTION_DOCS, FormulaError, type FType } from "@/lib/formula";
import { COLORS, PROPERTY_TYPES, PROPERTY_TYPE_LABELS, ROLLUP_FUNCTIONS, type PropertyDef, type PropertyType, type SelectOption, type PropertyConfig, type Color } from "@/lib/db-types";
import { useDb } from "./context";
import { Tag } from "./cells";
import { useWorkspaceDatabases } from "@/client/hooks";
import type { DatabaseMeta } from "@/client/types";
import { PageIcon, pageTitle } from "../page-icon";
import { uid } from "@/lib/uid";

export const TYPE_ICONS: Record<PropertyType, React.ComponentType<{ size?: number; className?: string }>> = {
  title: Text,
  rich_text: Type,
  number: Hash,
  select: CircleDot,
  multi_select: List,
  status: Loader,
  date: Calendar,
  checkbox: CheckSquare,
  url: Link2,
  email: AtSign,
  phone: Phone,
  person: User,
  files: Paperclip,
  relation: ArrowUpRight,
  rollup: Search,
  formula: Sigma,
  created_time: Clock,
  created_by: UserCheck,
  last_edited_time: Clock,
  last_edited_by: UserCheck,
  unique_id: Fingerprint,
};

export function PropIcon({ type, size = 14, className }: { type: PropertyType; size?: number; className?: string }) {
  const I = TYPE_ICONS[type] ?? Type;
  return <I size={size} className={cx("flex-none text-muted", className)} />;
}

const ADDABLE = PROPERTY_TYPES.filter((t) => t !== "title");

function formulaEnv(props: PropertyDef[], self?: string): Record<string, FType> {
  const env: Record<string, FType> = {};
  for (const p of props) {
    if (p.id === self) continue;
    env[p.name] =
      p.type === "number" ? "number" : p.type === "checkbox" ? "boolean" : ["date", "created_time", "last_edited_time"].includes(p.type) ? "date" : ["multi_select", "person", "relation", "files"].includes(p.type) ? "list" : ["formula", "rollup"].includes(p.type) ? "any" : "text";
  }
  return env;
}

export function PropertyMenu({ prop, anchor, onClose }: { prop: PropertyDef; anchor: HTMLElement | null; onClose: () => void }) {
  const db = useDb();
  const { toast, confirm } = useUi();
  const [name, setName] = useState(prop.name);
  const [typeAnchor, setTypeAnchor] = useState<HTMLElement | null>(null);

  const patch = async (body: { name?: string; type?: PropertyType; config?: PropertyConfig }) => {
    try {
      await api.patch(`/api/properties/${prop.id}`, body);
      db.refreshMeta();
      db.refresh();
    } catch (e) {
      toast(errorMessage(e), "error");
      throw e;
    }
  };

  const sorts = db.config.sorts ?? [];
  const items: MenuItem[] = [
    { label: "Sort ascending", icon: <ArrowUp size={15} />, onSelect: () => db.updateConfig({ sorts: [{ propertyId: prop.id, direction: "asc" }, ...sorts.filter((s) => s.propertyId !== prop.id)] }) },
    { label: "Sort descending", icon: <ArrowDown size={15} />, onSelect: () => db.updateConfig({ sorts: [{ propertyId: prop.id, direction: "desc" }, ...sorts.filter((s) => s.propertyId !== prop.id)] }) },
    {
      label: "Filter",
      icon: <Filter size={15} />,
      onSelect: () => {
        const root = db.config.filter ?? { kind: "group" as const, id: "root", op: "and" as const, filters: [] };
        const op = ["checkbox"].includes(prop.type) ? "is_checked" : ["number", "date"].includes(prop.type) ? "is_not_empty" : prop.type === "select" || prop.type === "status" ? "equals" : "contains";
        db.updateConfig({ filter: { ...root, filters: [...root.filters, { kind: "condition", id: uid(), propertyId: prop.id, operator: op as never, value: null }] } });
        document.dispatchEvent(new CustomEvent("slate:open-filter", { detail: db.databaseId }));
      },
    },
  ];
  if (prop.type !== "title") {
    items.push({
      label: "Hide in view",
      icon: <EyeOff size={15} />,
      onSelect: () => db.updateConfig({ visibleProperties: (db.config.visibleProperties ?? db.props.map((p) => p.id)).filter((id) => id !== prop.id) }),
    });
  }
  items.push({ label: db.config.wrapCells ? "Don't wrap cells" : "Wrap cells", icon: <WrapText size={15} />, onSelect: () => db.updateConfig({ wrapCells: !db.config.wrapCells }) });
  if (prop.type !== "title" && db.editable) {
    items.push({ divider: true, label: "" });
    items.push({
      label: "Delete property",
      icon: <Trash2 size={15} />,
      danger: true,
      onSelect: async () => {
        if (!(await confirm({ title: `Delete “${prop.name}”?`, message: "Values in this property will be removed from every record. Page history still has them.", danger: true, confirmLabel: "Delete" }))) return;
        try {
          await api.del(`/api/properties/${prop.id}`);
          db.refreshMeta();
          db.refresh();
        } catch (e) {
          toast(errorMessage(e), "error");
        }
      },
    });
  }

  return (
    <Popover anchor={anchor} open={!!anchor} onClose={onClose}>
      <div className="w-[280px]" onKeyDown={(e) => e.stopPropagation()}>
        {db.editable && (
          <div className="border-b border-line p-2">
            <div className="flex items-center gap-1">
              <input
                className="input h-7 flex-1"
                value={name}
                aria-label="Property name"
                onChange={(e) => setName(e.target.value)}
                onBlur={() => name.trim() && name !== prop.name && patch({ name: name.trim() })}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    if (name.trim() && name !== prop.name) patch({ name: name.trim() });
                    onClose();
                  }
                }}
              />
            </div>
            {prop.type !== "title" && (
              <button className="mt-1 flex w-full items-center gap-2 rounded px-2 py-1.5 text-left text-sm hover:bg-hover" onClick={(e) => setTypeAnchor(e.currentTarget)}>
                <PropIcon type={prop.type} />
                <span className="flex-1">Type</span>
                <span className="text-muted">{PROPERTY_TYPE_LABELS[prop.type]}</span>
                <ChevronRight size={14} className="text-faint" />
              </button>
            )}
            <PropertyConfigEditor prop={prop} onSave={(config) => patch({ config })} />
          </div>
        )}
        <Menu items={items} onClose={onClose} autoFocus={false} width={280} />
      </div>
      <Popover anchor={typeAnchor} open={!!typeAnchor} onClose={() => setTypeAnchor(null)} placement="right-start">
        <Menu
          filter
          width={230}
          onClose={() => setTypeAnchor(null)}
          items={ADDABLE.map((t) => ({
            label: PROPERTY_TYPE_LABELS[t],
            icon: <PropIcon type={t} />,
            checked: t === prop.type,
            onSelect: async () => {
              if (t === prop.type) return;
              if (t === "relation") {
                toast("Create a new Relation property to link databases", "info");
                return;
              }
              if (!(await confirm({ title: `Change “${prop.name}” to ${PROPERTY_TYPE_LABELS[t]}?`, message: "Existing values are converted where possible. The previous values remain in page history.", confirmLabel: "Change type" }))) return;
              await patch({ type: t }).catch(() => {});
            },
          }))}
        />
      </Popover>
    </Popover>
  );
}

/** Type-specific settings shown inside the property menu. */
function PropertyConfigEditor({ prop, onSave }: { prop: PropertyDef; onSave: (c: PropertyConfig) => Promise<void> }) {
  switch (prop.type) {
    case "select":
    case "multi_select":
    case "status":
      return <OptionsEditor prop={prop} onSave={onSave} />;
    case "number":
      return (
        <div className="mt-2 space-y-1 text-sm">
          <label className="flex items-center justify-between gap-2">
            <span className="text-muted">Format</span>
            <select className="input h-7" value={prop.config.format ?? "number"} onChange={(e) => onSave({ format: e.target.value as PropertyConfig["format"] })}>
              <option value="number">Number</option>
              <option value="number_commas">Number with commas</option>
              <option value="percent">Percent</option>
              <option value="dollar">US dollar</option>
              <option value="euro">Euro</option>
              <option value="pound">Pound</option>
              <option value="yen">Yen</option>
              <option value="rupee">Rupee</option>
            </select>
          </label>
          <label className="flex items-center justify-between gap-2">
            <span className="text-muted">Decimals</span>
            <select className="input h-7" value={prop.config.precision ?? ""} onChange={(e) => onSave({ precision: e.target.value === "" ? undefined : Number(e.target.value) } as PropertyConfig)}>
              <option value="">Auto</option>
              {[0, 1, 2, 3, 4].map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </select>
          </label>
        </div>
      );
    case "date":
    case "created_time":
    case "last_edited_time":
      return (
        <label className="mt-2 flex items-center justify-between gap-2 text-sm">
          <span className="text-muted">Date format</span>
          <select className="input h-7" value={prop.config.dateFormat ?? "full"} onChange={(e) => onSave({ dateFormat: e.target.value as PropertyConfig["dateFormat"] })}>
            <option value="full">Oct 19, 2026</option>
            <option value="short">10/19/2026</option>
            <option value="iso">2026-10-19</option>
            <option value="relative">Relative</option>
          </select>
        </label>
      );
    case "unique_id":
      return <PrefixEditor prop={prop} onSave={onSave} />;
    case "relation":
      return <RelationInfo prop={prop} onSave={onSave} />;
    case "rollup":
      return <RollupEditor prop={prop} onSave={onSave} />;
    case "formula":
      return <FormulaEditor prop={prop} onSave={onSave} />;
    default:
      return null;
  }
}

function PrefixEditor({ prop, onSave }: { prop: PropertyDef; onSave: (c: PropertyConfig) => Promise<void> }) {
  const [v, setV] = useState(prop.config.prefix ?? "");
  return (
    <label className="mt-2 flex items-center justify-between gap-2 text-sm">
      <span className="text-muted">Prefix</span>
      <input className="input h-7 w-32" value={v} maxLength={20} placeholder="e.g. TASK" onChange={(e) => setV(e.target.value)} onBlur={() => v !== (prop.config.prefix ?? "") && onSave({ prefix: v })} />
    </label>
  );
}

function OptionsEditor({ prop, onSave }: { prop: PropertyDef; onSave: (c: PropertyConfig) => Promise<void> }) {
  const [opts, setOpts] = useState<SelectOption[]>(prop.config.options ?? []);
  // Re-sync when the saved options change (adjusting state during render, not in an effect).
  const [syncedOptions, setSyncedOptions] = useState(prop.config.options);
  if (prop.config.options !== syncedOptions) {
    setSyncedOptions(prop.config.options);
    setOpts(prop.config.options ?? []);
  }
  const [newName, setNewName] = useState("");
  const [editing, setEditing] = useState<{ id: string; anchor: HTMLElement } | null>(null);
  const [dragId, setDragId] = useState<string | null>(null);
  const save = (next: SelectOption[], extra: Partial<PropertyConfig> = {}) => {
    setOpts(next);
    onSave({ options: next, ...extra });
  };
  const groups = prop.type === "status" ? (prop.config.groups ?? []) : null;
  const add = () => {
    const name = newName.trim();
    if (!name || opts.some((o) => o.name.toLowerCase() === name.toLowerCase())) return;
    const o: SelectOption = { id: uid(), name, color: COLORS[(opts.length % (COLORS.length - 1)) + 1] };
    const extra: Partial<PropertyConfig> = {};
    if (groups?.length) extra.groups = groups.map((g, i) => (i === 0 ? { ...g, optionIds: [...g.optionIds, o.id] } : g));
    save([...opts, o], extra);
    setNewName("");
  };
  const editOpt = opts.find((o) => o.id === editing?.id);
  const renderRow = (o: SelectOption) => (
    <div
      key={o.id}
      draggable
      onDragStart={() => setDragId(o.id)}
      onDragOver={(e) => e.preventDefault()}
      onDrop={() => {
        if (!dragId || dragId === o.id) return;
        const from = opts.findIndex((x) => x.id === dragId);
        const to = opts.findIndex((x) => x.id === o.id);
        const next = [...opts];
        const [m] = next.splice(from, 1);
        next.splice(to, 0, m);
        save(next);
        setDragId(null);
      }}
      className="group flex items-center gap-1 rounded px-1 py-0.5 hover:bg-hover"
    >
      <GripVertical size={12} className="cursor-grab text-faint" />
      <button className="min-w-0 flex-1 text-left" onClick={(e) => setEditing({ id: o.id, anchor: e.currentTarget })}>
        <Tag option={o} />
      </button>
    </div>
  );
  return (
    <div className="mt-2 text-sm">
      <div className="mb-1 text-xs text-muted">Options</div>
      <div className="max-h-56 overflow-y-auto">
        {groups
          ? groups.map((g) => (
              <div key={g.id}>
                <div className="px-1 pt-1 text-[11px] uppercase tracking-wide text-faint">{g.name}</div>
                {opts.filter((o) => g.optionIds.includes(o.id)).map(renderRow)}
              </div>
            ))
          : opts.map(renderRow)}
      </div>
      <form
        className="mt-1 flex gap-1"
        onSubmit={(e) => {
          e.preventDefault();
          add();
        }}
      >
        <input className="input h-7 flex-1" placeholder="Add an option…" value={newName} onChange={(e) => setNewName(e.target.value)} />
        <button className="icon-btn" aria-label="Add option">
          <Plus size={14} />
        </button>
      </form>
      {editOpt && (
        <Popover anchor={editing!.anchor} open onClose={() => setEditing(null)} placement="right-start">
          <div className="w-52 p-2 text-sm" onKeyDown={(e) => e.stopPropagation()}>
            <input
              autoFocus
              className="input mb-2 h-7 w-full"
              defaultValue={editOpt.name}
              onBlur={(e) => {
                const n = e.target.value.trim();
                if (n && n !== editOpt.name) save(opts.map((o) => (o.id === editOpt.id ? { ...o, name: n } : o)));
              }}
              onKeyDown={(e) => e.key === "Enter" && (e.target as HTMLInputElement).blur()}
            />
            {groups && (
              <label className="mb-2 flex items-center justify-between gap-2 text-xs">
                <span className="text-muted">Group</span>
                <select
                  className="input h-7"
                  value={groups.find((g) => g.optionIds.includes(editOpt.id))?.id ?? ""}
                  onChange={(e) => onSave({ options: opts, groups: groups.map((g) => ({ ...g, optionIds: g.id === e.target.value ? [...g.optionIds.filter((x) => x !== editOpt.id), editOpt.id] : g.optionIds.filter((x) => x !== editOpt.id) })) })}
                >
                  {groups.map((g) => (
                    <option key={g.id} value={g.id}>
                      {g.name}
                    </option>
                  ))}
                </select>
              </label>
            )}
            <div className="mb-2 grid grid-cols-5 gap-1">
              {COLORS.map((c: Color) => (
                <button key={c} title={c} onClick={() => save(opts.map((o) => (o.id === editOpt.id ? { ...o, color: c } : o)))} className={cx("tag h-6 justify-center", `tag-${c}`, editOpt.color === c && "ring-2 ring-accent")}>
                  A
                </button>
              ))}
            </div>
            <button
              className="flex w-full items-center gap-2 rounded px-2 py-1 text-left text-danger hover:bg-hover"
              onClick={() => {
                save(opts.filter((o) => o.id !== editOpt.id));
                setEditing(null);
              }}
            >
              <Trash2 size={13} /> Delete option
            </button>
          </div>
        </Popover>
      )}
    </div>
  );
}

function RelationInfo({ prop, onSave }: { prop: PropertyDef; onSave: (c: PropertyConfig) => Promise<void> }) {
  const db = useDb();
  const { data } = useWorkspaceDatabases(db.workspaceId);
  const target = data?.databases.find((d) => d.id === prop.config.targetDatabaseId);
  return (
    <div className="mt-2 space-y-1 text-sm">
      <div className="flex items-center justify-between gap-2">
        <span className="text-muted">Related to</span>
        <span className="flex items-center gap-1 truncate">
          <PageIcon icon={target?.icon} kind="database" size={14} /> {pageTitle(target?.title)}
        </span>
      </div>
      <div className="flex items-center justify-between gap-2">
        <span className="text-muted">Two-way</span>
        <span>{prop.config.syncedPropertyId ? "Yes" : "No"}</span>
      </div>
      <label className="flex items-center justify-between gap-2">
        <span className="text-muted">Limit</span>
        <select className="input h-7" value={prop.config.limit === 1 ? "1" : ""} onChange={(e) => onSave({ limit: e.target.value === "1" ? 1 : null })}>
          <option value="">No limit</option>
          <option value="1">1 record</option>
        </select>
      </label>
    </div>
  );
}

function RollupEditor({ prop, onSave }: { prop: PropertyDef; onSave: (c: PropertyConfig) => Promise<void> }) {
  const db = useDb();
  const relations = db.props.filter((p) => p.type === "relation");
  const rel = relations.find((r) => r.id === prop.config.relationPropertyId);
  const { data: target } = useSWR<DatabaseMeta>(rel?.config.targetDatabaseId ? `/api/databases/${rel.config.targetDatabaseId}` : null);
  return (
    <div className="mt-2 space-y-1 text-sm">
      <label className="flex items-center justify-between gap-2">
        <span className="text-muted">Relation</span>
        <select className="input h-7 max-w-[150px]" value={prop.config.relationPropertyId ?? ""} onChange={(e) => onSave({ relationPropertyId: e.target.value, targetPropertyId: "title" })}>
          <option value="">Choose…</option>
          {relations.map((r) => (
            <option key={r.id} value={r.id}>
              {r.name}
            </option>
          ))}
        </select>
      </label>
      {rel && (
        <label className="flex items-center justify-between gap-2">
          <span className="text-muted">Property</span>
          <select className="input h-7 max-w-[150px]" value={prop.config.targetPropertyId ?? "title"} onChange={(e) => onSave({ targetPropertyId: e.target.value })}>
            {target?.properties.map((p) => (
              <option key={p.id} value={p.type === "title" ? "title" : p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </label>
      )}
      <label className="flex items-center justify-between gap-2">
        <span className="text-muted">Calculate</span>
        <select className="input h-7 max-w-[150px]" value={prop.config.function ?? "show_original"} onChange={(e) => onSave({ function: e.target.value as PropertyConfig["function"] })}>
          {ROLLUP_FUNCTIONS.map((f) => (
            <option key={f} value={f}>
              {f.replace(/_/g, " ")}
            </option>
          ))}
        </select>
      </label>
      {!relations.length && <p className="text-xs text-muted">Add a Relation property first.</p>}
    </div>
  );
}

function FormulaEditor({ prop, onSave }: { prop: PropertyDef; onSave: (c: PropertyConfig) => Promise<void> }) {
  const db = useDb();
  const [expr, setExpr] = useState(prop.config.expression ?? "");
  const [showRef, setShowRef] = useState(false);
  const env = useMemo(() => formulaEnv(db.props, prop.id), [db.props, prop.id]);
  const check = useMemo(() => {
    if (!expr.trim()) return { ok: true, msg: "Enter a formula" };
    try {
      const c = compile(expr, { props: { ...env, [prop.name]: "any" } });
      return { ok: true, msg: `Result type: ${c.type}` };
    } catch (e) {
      return { ok: false, msg: e instanceof FormulaError ? e.message : String(e) };
    }
  }, [expr, env, prop.name]);
  return (
    <div className="mt-2 text-sm">
      <textarea
        className="input h-24 w-full font-mono text-xs"
        spellCheck={false}
        value={expr}
        placeholder={'prop("Price") * prop("Quantity")'}
        onChange={(e) => setExpr(e.target.value)}
        onKeyDown={(e) => e.stopPropagation()}
        aria-label="Formula"
      />
      <div className={cx("mt-1 text-xs", check.ok ? "text-muted" : "text-danger")}>{check.msg}</div>
      <div className="mt-1 flex items-center gap-1">
        <button className="btn btn-primary btn-sm" disabled={!check.ok || expr === prop.config.expression} onClick={() => onSave({ expression: expr })}>
          Save formula
        </button>
        <button className="link-btn" onClick={() => setShowRef(!showRef)}>
          {showRef ? "Hide" : "Functions & properties"}
        </button>
      </div>
      {showRef && (
        <div className="mt-2 max-h-48 overflow-y-auto rounded border border-line p-1 text-xs">
          <div className="px-1 pb-1 font-medium text-muted">Properties</div>
          {db.props
            .filter((p) => p.id !== prop.id)
            .map((p) => (
              <button key={p.id} className="block w-full truncate rounded px-1 py-0.5 text-left font-mono hover:bg-hover" onClick={() => setExpr((x) => `${x}prop("${p.name}")`)}>
                prop(&quot;{p.name}&quot;)
              </button>
            ))}
          <div className="px-1 pb-1 pt-2 font-medium text-muted">Functions</div>
          {FUNCTION_DOCS.map((f) => (
            <button key={f.name} className="block w-full rounded px-1 py-0.5 text-left hover:bg-hover" onClick={() => setExpr((x) => `${x}${f.name}(`)} title={f.doc}>
              <span className="font-mono">{f.name}</span> <span className="text-faint">— {f.doc.replace(/^[^—]*—\s*/, "")}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/** "+" in the table header: name + type, and target database for relations. */
export function AddPropertyMenu({ anchor, onClose }: { anchor: HTMLElement | null; onClose: () => void }) {
  const db = useDb();
  const { toast } = useUi();
  const [name, setName] = useState("");
  const [relation, setRelation] = useState<{ target: string | null; twoWay: boolean } | null>(null);
  const { data: dbs } = useWorkspaceDatabases(relation ? db.workspaceId : null);
  const create = async (type: PropertyType, config: PropertyConfig = {}, twoWay = false) => {
    try {
      await api.post(`/api/databases/${db.databaseId}/properties`, { name: name.trim() || PROPERTY_TYPE_LABELS[type], type, config, twoWay });
      db.refreshMeta();
      db.refresh();
      onClose();
      setName("");
      setRelation(null);
    } catch (e) {
      toast(errorMessage(e), "error");
    }
  };
  return (
    <Popover
      anchor={anchor}
      open={!!anchor}
      onClose={() => {
        onClose();
        setRelation(null);
      }}
      placement="bottom-end"
    >
      <div className="w-[260px] p-2" onKeyDown={(e) => e.stopPropagation()}>
        <input autoFocus className="input mb-2 h-7 w-full" placeholder="Property name" value={name} onChange={(e) => setName(e.target.value)} />
        {relation ? (
          <div className="text-sm">
            <div className="mb-1 text-xs text-muted">Relate to database</div>
            <div className="max-h-48 overflow-y-auto">
              {dbs?.databases.map((d) => (
                <button key={d.id} className={cx("flex w-full items-center gap-2 rounded px-2 py-1 text-left hover:bg-hover", relation.target === d.id && "bg-active")} onClick={() => setRelation({ ...relation, target: d.id })}>
                  <PageIcon icon={d.icon} kind="database" size={14} /> <span className="truncate">{pageTitle(d.title)}</span>
                  {d.id === db.databaseId && <span className="ml-auto text-xs text-faint">this database</span>}
                </button>
              ))}
            </div>
            <label className="mt-2 flex items-center gap-2 text-sm">
              <input type="checkbox" checked={relation.twoWay} onChange={(e) => setRelation({ ...relation, twoWay: e.target.checked })} />
              Show on the related database too (two-way)
            </label>
            <div className="mt-2 flex justify-end gap-1">
              <button className="btn btn-sm" onClick={() => setRelation(null)}>
                Back
              </button>
              <button className="btn btn-primary btn-sm" disabled={!relation.target} onClick={() => create("relation", { targetDatabaseId: relation.target! }, relation.twoWay)}>
                Add relation
              </button>
            </div>
          </div>
        ) : (
          <div className="max-h-[320px] overflow-y-auto">
            {ADDABLE.map((t) => (
              <button
                key={t}
                className="flex w-full items-center gap-2 rounded px-2 py-1.5 text-left text-sm hover:bg-hover"
                onClick={() => (t === "relation" ? setRelation({ target: null, twoWay: true }) : create(t))}
              >
                <PropIcon type={t} /> {PROPERTY_TYPE_LABELS[t]}
              </button>
            ))}
          </div>
        )}
      </div>
    </Popover>
  );
}

export { X };
