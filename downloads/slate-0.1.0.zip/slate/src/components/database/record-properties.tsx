"use client";
import { useState } from "react";
import Link from "next/link";
import { mutate as globalMutate } from "swr";
import { Plus, ChevronDown, ChevronRight } from "lucide-react";
import { api, errorMessage } from "@/client/api";
import { useDatabaseMeta, useMembers } from "@/client/hooks";
import { useOptionalWorkspace } from "@/client/workspace-context";
import { useUi, cx } from "@/client/ui";
import type { CellValue, PropertyDef, ViewConfig } from "@/lib/db-types";
import type { PageResponse } from "@/client/types";
import { DatabaseContext, type DbCtx } from "./context";
import { EditableCell, CellDisplay } from "./cells";
import { PropIcon, PropertyMenu, AddPropertyMenu } from "./property-menu";
import { PageIcon, pageTitle } from "../page-icon";

type Record = NonNullable<PageResponse["record"]>;

export function RecordProperties({ pageId, record, editable, onChanged, shareMode }: { pageId: string; record: Record; editable: boolean; onChanged: () => void; shareMode?: boolean }) {
  const ws = useOptionalWorkspace();
  const { toast } = useUi();
  const { data: meta, mutate: mutateMeta } = useDatabaseMeta(shareMode ? null : record.database.id);
  const { data: members } = useMembers(shareMode ? null : (ws?.workspace.id ?? null));
  const [values, setValues] = useState(record.values);
  const [collapsed, setCollapsed] = useState(false);
  const [menu, setMenu] = useState<{ prop: PropertyDef; anchor: HTMLElement } | null>(null);
  const [addAnchor, setAddAnchor] = useState<HTMLElement | null>(null);
  const props = (meta?.properties ?? record.properties).filter((p) => p.type !== "title");
  const [syncedValues, setSyncedValues] = useState(record.values);
  if (record.values !== syncedValues) {
    setSyncedValues(record.values);
    setValues(record.values);
  }

  const ctx: DbCtx | null = meta
    ? {
        databaseId: record.database.id,
        workspaceId: ws?.workspace.id ?? "",
        meta,
        view: meta.views[0],
        config: {} as ViewConfig,
        props: meta.properties,
        visibleProps: meta.properties,
        titleProp: meta.properties.find((p) => p.type === "title")!,
        result: { rows: [], total: 0, matched: 0, offset: 0, hasMore: false, groups: null, aggregations: {}, formulaErrors: {}, refs: record.refs },
        rowsById: new Map(),
        members: members?.members ?? [],
        editable,
        setValue: async (_rid, propertyId, value) => {
          setValues((v) => ({ ...v, [propertyId]: (value ?? null) as CellValue }));
          try {
            await api.patch(`/api/records/${pageId}`, { values: { [propertyId]: value } });
            const prop = meta.properties.find((p) => p.id === propertyId);
            if (prop && ["select", "multi_select", "status"].includes(prop.type)) mutateMeta();
          } catch (e) {
            toast(errorMessage(e), "error");
          }
          onChanged();
          globalMutate((k) => Array.isArray(k) && typeof k[0] === "string" && k[0] === `/api/databases/${record.database.id}/query`);
        },
        createRecord: async () => null,
        openRecord: () => {},
        updateConfig: async () => {},
        refresh: onChanged,
        refreshMeta: () => {
          mutateMeta();
          onChanged();
        },
        calendarMonth: new Date(),
        setCalendarMonth: () => {},
        undatedCount: null,
        views: meta.views,
        viewsEditable: false,
        ownViews: false,
        viewOps: { add: async () => null, rename: async () => {}, setType: async () => {}, duplicate: async () => null, remove: async () => {}, move: async () => {} },
        hasMore: false,
        loadingMore: false,
        loadMore: () => {},
        hrefFor: (id) => `/w/${ws?.workspace.id}/p/${id}`,
      }
    : null;

  const row = { id: pageId, values };
  const body = (
    <div className="mb-4 mt-1 border-b border-line pb-3">
      <div className="mb-1 flex items-center gap-2 text-xs text-muted">
        <button className="flex items-center gap-1 hover:text-fg" onClick={() => setCollapsed(!collapsed)} aria-expanded={!collapsed}>
          {collapsed ? <ChevronRight size={13} /> : <ChevronDown size={13} />} Properties
        </button>
        <span>·</span>
        {shareMode ? (
          <span className="flex items-center gap-1">
            <PageIcon icon={record.database.icon} kind="database" size={12} /> {pageTitle(record.database.title)}
          </span>
        ) : (
          <Link href={`/w/${ws?.workspace.id}/p/${record.database.id}`} className="flex items-center gap-1 hover:text-fg">
            <PageIcon icon={record.database.icon} kind="database" size={12} /> {pageTitle(record.database.title)}
          </Link>
        )}
      </div>
      {!collapsed && (
        <div className="space-y-0.5">
          {props.map((p) => (
            <div key={p.id} className="flex min-h-[34px] items-start gap-2 text-sm">
              <button
                className={cx("flex w-40 flex-none items-center gap-2 rounded px-1.5 py-1.5 text-left text-muted sm:w-48", ctx && "hover:bg-hover")}
                onClick={(e) => ctx && setMenu({ prop: p, anchor: e.currentTarget })}
                disabled={!ctx}
              >
                <PropIcon type={p.type} />
                <span className="truncate">{p.name}</span>
              </button>
              <div className="min-w-0 flex-1 rounded px-1.5 py-1.5 hover:bg-hover">
                {ctx ? (
                  <EditableCell prop={p} row={row} wrap placeholder={editable && !["formula", "rollup", "created_time", "created_by", "last_edited_time", "last_edited_by", "unique_id"].includes(p.type) ? "Empty" : undefined} />
                ) : (
                  <CellDisplay prop={p} value={values[p.id]} refs={record.refs} wrap />
                )}
              </div>
            </div>
          ))}
          {ctx && editable && (
            <button className="flex items-center gap-2 rounded px-1.5 py-1.5 text-sm text-faint hover:bg-hover" onClick={(e) => setAddAnchor(e.currentTarget)}>
              <Plus size={14} /> Add a property
            </button>
          )}
        </div>
      )}
    </div>
  );
  if (!ctx) return body;
  return (
    <DatabaseContext.Provider value={ctx}>
      {body}
      {menu && <PropertyMenu prop={ctx.props.find((p) => p.id === menu.prop.id) ?? menu.prop} anchor={menu.anchor} onClose={() => setMenu(null)} />}
      <AddPropertyMenu anchor={addAnchor} onClose={() => setAddAnchor(null)} />
    </DatabaseContext.Provider>
  );
}
