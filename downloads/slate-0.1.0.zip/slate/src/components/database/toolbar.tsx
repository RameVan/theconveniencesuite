"use client";
import { useEffect, useState } from "react";
import { Filter, ArrowUpDown, Group, SlidersHorizontal, Search, Plus, X, ChevronDown, Table2, Kanban, List, LayoutGrid, CalendarDays, GanttChart, BarChart3, Trash2, Copy, PenLine, Eye, EyeOff, GripVertical, Download, FileText, ArrowLeft, ArrowRight } from "lucide-react";
import { api } from "@/client/api";
import { Popover, Menu, useUi, cx, MenuButton, type MenuItem, downloadUrl } from "@/client/ui";
import { OPERATORS_BY_TYPE, OPERATOR_LABELS, filterFamily, VIEW_TYPES, AGGREGATIONS, type FilterCondition, type FilterGroup, type PropertyDef, type ViewType, type ViewDef, type FilterOperator } from "@/lib/db-types";
import { useDb } from "./context";
import { PropIcon } from "./property-menu";
import { Tag } from "./cells";
import { uid } from "@/lib/uid";

export const VIEW_ICONS: Record<ViewType, React.ComponentType<{ size?: number; className?: string }>> = {
  table: Table2,
  board: Kanban,
  list: List,
  gallery: LayoutGrid,
  calendar: CalendarDays,
  timeline: GanttChart,
  chart: BarChart3,
};

const RELATIVE = [
  ["today", "Today"],
  ["tomorrow", "Tomorrow"],
  ["yesterday", "Yesterday"],
  ["this_week", "This week"],
  ["past_week", "Past week"],
  ["next_week", "Next week"],
  ["this_month", "This month"],
  ["past_month", "Past month"],
  ["next_month", "Next month"],
  ["past_year", "Past year"],
  ["next_year", "Next year"],
] as const;

export function ViewTabs({ onSelect, activeId }: { onSelect: (id: string) => void; activeId: string }) {
  const db = useDb();
  const { confirm } = useUi();
  const [addAnchor, setAddAnchor] = useState<HTMLElement | null>(null);
  const [dragView, setDragView] = useState<string | null>(null);
  const [dropOn, setDropOn] = useState<string | null>(null);
  const addView = async (type: ViewType) => {
    const id = await db.viewOps.add(type);
    if (id) onSelect(id);
  };
  const viewMenu = (v: ViewDef): MenuItem[] => [
    {
      label: "Rename",
      icon: <PenLine size={15} />,
      onSelect: async () => {
        const name = prompt("View name", v.name);
        if (!name?.trim()) return;
        await db.viewOps.rename(v.id, name.trim());
      },
    },
    {
      label: "Change layout",
      icon: <SlidersHorizontal size={15} />,
      submenu: VIEW_TYPES.map((t) => {
        const I = VIEW_ICONS[t];
        return {
          label: t[0].toUpperCase() + t.slice(1),
          icon: <I size={15} />,
          checked: v.type === t,
          onSelect: () => db.viewOps.setType(v.id, t),
        };
      }),
    },
    {
      label: "Move left",
      icon: <ArrowLeft size={15} />,
      disabled: db.views[0]?.id === v.id,
      onSelect: () => {
        const i = db.views.findIndex((x) => x.id === v.id);
        db.viewOps.move(v.id, db.views[i - 1].id);
      },
    },
    {
      label: "Move right",
      icon: <ArrowRight size={15} />,
      disabled: db.views[db.views.length - 1]?.id === v.id,
      onSelect: () => {
        const i = db.views.findIndex((x) => x.id === v.id);
        db.viewOps.move(v.id, db.views[i + 2]?.id ?? null);
      },
    },
    {
      label: "Duplicate view",
      icon: <Copy size={15} />,
      onSelect: async () => {
        const id = await db.viewOps.duplicate(v.id);
        if (id) onSelect(id);
      },
    },
    ...(db.ownViews ? [] : [{ label: "Export view as CSV", icon: <Download size={15} />, onSelect: () => downloadUrl(`/api/databases/${db.databaseId}/export?viewId=${v.id}`) }]),
    ...(db.useOwnViews
      ? [
          {
            label: "Use separate views here",
            icon: <Copy size={15} />,
            onSelect: () => db.useOwnViews!(),
          },
        ]
      : []),
    { divider: true, label: "" },
    {
      label: "Delete view",
      icon: <Trash2 size={15} />,
      danger: true,
      disabled: db.views.length <= 1,
      onSelect: async () => {
        if (!(await confirm({ title: `Delete view “${v.name}”?`, message: "Records are not affected.", danger: true, confirmLabel: "Delete" }))) return;
        await db.viewOps.remove(v.id);
        onSelect(db.views.find((x) => x.id !== v.id)!.id);
      },
    },
  ];
  return (
    <div className="flex min-w-0 max-w-full items-center gap-0.5 overflow-x-auto">
      {db.views.map((v) => {
        const I = VIEW_ICONS[v.type] ?? Table2;
        const active = v.id === activeId;
        return (
          <div
            key={v.id}
            data-view-tab={v.id}
            className={cx("flex flex-none items-center rounded-md", active && "bg-hover", dragView && dropOn === v.id && "ring-2 ring-accent")}
            draggable={db.viewsEditable}
            onDragStart={(e) => {
              setDragView(v.id);
              e.dataTransfer.effectAllowed = "move";
              e.dataTransfer.setData("text/plain", v.name);
            }}
            onDragOver={(e) => {
              if (!dragView || dragView === v.id) return;
              e.preventDefault();
              setDropOn(v.id);
            }}
            onDragLeave={() => setDropOn(null)}
            onDrop={(e) => {
              e.preventDefault();
              if (!dragView || dragView === v.id) return;
              // Left half: before this tab; right half: after it.
              const r = e.currentTarget.getBoundingClientRect();
              const idx = db.views.findIndex((x) => x.id === v.id);
              const beforeId = e.clientX < r.left + r.width / 2 ? v.id : (db.views[idx + 1]?.id ?? null);
              db.viewOps.move(dragView, beforeId === dragView ? (db.views[idx + 2]?.id ?? null) : beforeId);
              setDragView(null);
              setDropOn(null);
            }}
            onDragEnd={() => {
              setDragView(null);
              setDropOn(null);
            }}
          >
            <button className={cx("flex items-center gap-1.5 px-2 py-1 text-sm", active ? "font-medium" : "text-muted hover:text-fg")} onClick={() => onSelect(v.id)}>
              <I size={14} /> {v.name}
            </button>
            {active && (db.viewsEditable || db.useOwnViews) && (
              <MenuButton className="icon-btn h-6 w-5" title="View options" items={() => (db.viewsEditable ? viewMenu(v) : viewMenu(v).filter((i) => i.label === "Use separate views here"))}>
                <ChevronDown size={13} />
              </MenuButton>
            )}
          </div>
        );
      })}
      {db.viewsEditable && (
        <button className="icon-btn flex-none" title="Add a view" onClick={(e) => setAddAnchor(e.currentTarget)}>
          <Plus size={15} />
        </button>
      )}
      <Popover anchor={addAnchor} open={!!addAnchor} onClose={() => setAddAnchor(null)}>
        <Menu
          onClose={() => setAddAnchor(null)}
          width={200}
          items={VIEW_TYPES.map((t) => {
            const I = VIEW_ICONS[t];
            return { label: t[0].toUpperCase() + t.slice(1), icon: <I size={15} />, onSelect: () => addView(t) };
          })}
        />
      </Popover>
    </div>
  );
}

export function Toolbar({ search, onSearch, onNew }: { search: string; onSearch: (s: string) => void; onNew: (templateId?: string | null) => void }) {
  const db = useDb();
  const [open, setOpen] = useState<null | { kind: "filter" | "sort" | "group" | "props" | "layout"; anchor: HTMLElement }>(null);
  const [searchOpen, setSearchOpen] = useState(!!search);
  const filterCount = countConditions(db.config.filter);
  const sortCount = db.config.sorts?.length ?? 0;
  useEffect(() => {
    const on = (e: Event) => {
      if ((e as CustomEvent).detail !== db.databaseId) return;
      const btn = document.querySelector<HTMLElement>(`[data-filter-btn="${db.databaseId}"]`);
      if (btn) setOpen({ kind: "filter", anchor: btn });
    };
    document.addEventListener("slate:open-filter", on);
    return () => document.removeEventListener("slate:open-filter", on);
  }, [db.databaseId]);
  const btn = (kind: "filter" | "sort" | "group" | "props" | "layout", icon: React.ReactNode, label: string, active = false, extra?: Record<string, string>) => (
    <button {...extra} className={cx("flex items-center gap-1 rounded px-1.5 py-1 text-sm hover:bg-hover", active ? "text-accent" : "text-muted")} onClick={(e) => setOpen({ kind, anchor: e.currentTarget })} title={label}>
      {icon}
      <span className="hidden lg:inline">{label}</span>
    </button>
  );
  return (
    <div className="flex min-w-0 flex-wrap items-center gap-0.5">
      {btn("filter", <Filter size={14} />, filterCount ? `Filter (${filterCount})` : "Filter", filterCount > 0, { "data-filter-btn": db.databaseId })}
      {btn("sort", <ArrowUpDown size={14} />, sortCount ? `Sort (${sortCount})` : "Sort", sortCount > 0)}
      {db.view.type !== "calendar" && db.view.type !== "timeline" && btn("group", <Group size={14} />, "Group", !!db.config.groupBy)}
      {btn("props", <Eye size={14} />, "Properties")}
      {btn("layout", <SlidersHorizontal size={14} />, "Layout")}
      {searchOpen ? (
        <span className="flex items-center rounded border border-line px-1">
          <Search size={13} className="text-faint" />
          <input
            autoFocus
            className="h-6 w-28 bg-transparent px-1 text-sm outline-none sm:w-40"
            placeholder="Search…"
            value={search}
            onChange={(e) => onSearch(e.target.value)}
            onKeyDown={(e) => e.key === "Escape" && (onSearch(""), setSearchOpen(false))}
          />
          <button className="text-faint hover:text-fg" onClick={() => (onSearch(""), setSearchOpen(false))} aria-label="Clear search">
            <X size={13} />
          </button>
        </span>
      ) : (
        <button className="icon-btn" title="Search" onClick={() => setSearchOpen(true)}>
          <Search size={14} />
        </button>
      )}
      {db.editable && (
        <span className="ml-1 flex">
          <button className="btn btn-primary btn-sm rounded-r-none" onClick={() => onNew(db.meta.defaultTemplateId)}>
            New
          </button>
          <MenuButton
            className="btn btn-primary btn-sm rounded-l-none border-l border-white/30 px-1"
            title="New from template"
            placement="bottom-end"
            width={240}
            items={() => [
              { label: "Templates", heading: true },
              { label: "Empty record", icon: <FileText size={15} />, onSelect: () => onNew(null) },
              ...db.meta.templates.map((t) => ({
                label: t.title || "Untitled template",
                icon: <span>{t.icon ?? "📄"}</span>,
                checked: db.meta.defaultTemplateId === t.id,
                onSelect: () => onNew(t.id),
                hint: db.meta.defaultTemplateId === t.id ? "default" : undefined,
              })),
              { divider: true, label: "" },
              {
                label: "New template",
                icon: <Plus size={15} />,
                onSelect: async () => {
                  const r = await api.post<{ row: { id: string } }>(`/api/databases/${db.databaseId}/records`, { title: "New template", isTemplate: true });
                  db.refreshMeta();
                  db.openRecord(r.row.id);
                },
              },
              ...(db.meta.templates.length
                ? [
                    {
                      label: "Set default template",
                      submenu: [
                        { label: "None", checked: !db.meta.defaultTemplateId, onSelect: () => setDefault(db.databaseId, null, db.refreshMeta) },
                        ...db.meta.templates.map((t) => ({ label: t.title || "Untitled", checked: db.meta.defaultTemplateId === t.id, onSelect: () => setDefault(db.databaseId, t.id, db.refreshMeta) })),
                      ],
                    },
                    { label: "Edit a template", submenu: db.meta.templates.map((t) => ({ label: t.title || "Untitled", onSelect: () => db.openRecord(t.id) })) },
                  ]
                : []),
            ]}
          >
            <ChevronDown size={13} />
          </MenuButton>
        </span>
      )}
      <Popover anchor={open?.anchor ?? null} open={!!open} onClose={() => setOpen(null)} placement="bottom-end">
        {open?.kind === "filter" && <FilterBuilder />}
        {open?.kind === "sort" && <SortBuilder />}
        {open?.kind === "group" && <GroupPicker onDone={() => setOpen(null)} />}
        {open?.kind === "props" && <PropertiesPanel />}
        {open?.kind === "layout" && <LayoutPanel />}
      </Popover>
    </div>
  );
}

async function setDefault(databaseId: string, id: string | null, refresh: () => void) {
  await api.patch(`/api/databases/${databaseId}`, { defaultTemplateId: id });
  refresh();
}

function countConditions(g: FilterGroup | null | undefined): number {
  if (!g) return 0;
  return g.filters.reduce((n, f) => n + (f.kind === "group" ? countConditions(f) : 1), 0);
}

// ------------------------------------------------------------------ filters

function defaultOperator(p: PropertyDef): FilterOperator {
  const fam = filterFamily(p.type);
  return OPERATORS_BY_TYPE[fam][0];
}

function FilterBuilder() {
  const db = useDb();
  const root: FilterGroup = db.config.filter ?? { kind: "group", id: "root", op: "and", filters: [] };
  const save = (g: FilterGroup) => db.updateConfig({ filter: g });
  return (
    <div className="w-[min(640px,94vw)] p-3 text-sm" onKeyDown={(e) => e.stopPropagation()}>
      <GroupEditor group={root} onChange={save} depth={0} />
      {!root.filters.length && <p className="mb-2 text-muted">No filters applied to this view.</p>}
    </div>
  );
}

function GroupEditor({ group, onChange, depth, onRemove }: { group: FilterGroup; onChange: (g: FilterGroup) => void; depth: number; onRemove?: () => void }) {
  const db = useDb();
  const update = (i: number, f: FilterGroup["filters"][number] | null) => {
    const filters = [...group.filters];
    if (f) filters[i] = f;
    else filters.splice(i, 1);
    onChange({ ...group, filters });
  };
  const first = db.props[0];
  return (
    <div className={cx(depth > 0 && "rounded-md border border-line bg-subtle p-2")}>
      {group.filters.map((f, i) => (
        <div key={f.id} className="mb-1.5 flex items-start gap-1.5">
          <div className="w-16 flex-none pt-1 text-xs text-muted">
            {i === 0 ? (
              "Where"
            ) : i === 1 ? (
              <select className="rounded bg-transparent hover:bg-hover" value={group.op} onChange={(e) => onChange({ ...group, op: e.target.value as "and" | "or" })} aria-label="Combine filters with">
                <option value="and">And</option>
                <option value="or">Or</option>
              </select>
            ) : (
              <span className="pl-1">{group.op === "and" ? "And" : "Or"}</span>
            )}
          </div>
          <div className="min-w-0 flex-1">{f.kind === "group" ? <GroupEditor group={f} depth={depth + 1} onChange={(g) => update(i, g)} onRemove={() => update(i, null)} /> : <ConditionEditor cond={f} onChange={(c) => update(i, c)} />}</div>
          {f.kind === "condition" && (
            <button className="icon-btn" onClick={() => update(i, null)} aria-label="Remove filter">
              <X size={14} />
            </button>
          )}
        </div>
      ))}
      <div className="flex gap-2">
        <button
          className="link-btn flex items-center gap-1"
          onClick={() => onChange({ ...group, filters: [...group.filters, { kind: "condition", id: uid(), propertyId: first.id, operator: defaultOperator(first), value: null }] })}
        >
          <Plus size={13} /> Add filter
        </button>
        {depth === 0 && (
          <button
            className="link-btn flex items-center gap-1"
            onClick={() =>
              onChange({
                ...group,
                filters: [...group.filters, { kind: "group", id: uid(), op: group.op === "and" ? "or" : "and", filters: [{ kind: "condition", id: uid(), propertyId: first.id, operator: defaultOperator(first), value: null }] }],
              })
            }
          >
            <Plus size={13} /> Add filter group
          </button>
        )}
        {onRemove && (
          <button className="link-btn ml-auto flex items-center gap-1" onClick={onRemove}>
            <Trash2 size={13} /> Remove group
          </button>
        )}
      </div>
    </div>
  );
}

function ConditionEditor({ cond, onChange }: { cond: FilterCondition; onChange: (c: FilterCondition) => void }) {
  const db = useDb();
  const prop = db.props.find((p) => p.id === cond.propertyId) ?? db.titleProp;
  const fam = filterFamily(prop.type);
  const ops = OPERATORS_BY_TYPE[fam];
  const noValue = ["is_empty", "is_not_empty", "is_checked", "is_not_checked"].includes(cond.operator);
  return (
    <div className="flex flex-wrap items-center gap-1.5">
      <select
        className="input h-7 max-w-[160px]"
        value={prop.id}
        onChange={(e) => {
          const p = db.props.find((x) => x.id === e.target.value)!;
          onChange({ ...cond, propertyId: p.id, operator: defaultOperator(p), value: null });
        }}
        aria-label="Property"
      >
        {db.props.map((p) => (
          <option key={p.id} value={p.id}>
            {p.name}
          </option>
        ))}
      </select>
      <select className="input h-7" value={cond.operator} onChange={(e) => onChange({ ...cond, operator: e.target.value as FilterOperator })} aria-label="Condition">
        {ops.map((o) => (
          <option key={o} value={o}>
            {OPERATOR_LABELS[o]}
          </option>
        ))}
      </select>
      {!noValue && <FilterValue key={`${cond.id}:${cond.propertyId}:${cond.operator}`} prop={prop} cond={cond} onChange={(value) => onChange({ ...cond, value })} />}
    </div>
  );
}

function FilterValue({ prop, cond, onChange }: { prop: PropertyDef; cond: FilterCondition; onChange: (v: unknown) => void }) {
  const db = useDb();
  const [v, setV] = useState(String(cond.value ?? ""));
  if (prop.type === "select" || prop.type === "status" || prop.type === "multi_select") {
    return (
      <select className="input h-7 min-w-[120px]" value={String(cond.value ?? "")} onChange={(e) => onChange(e.target.value || null)} aria-label="Value">
        <option value="">Choose…</option>
        {prop.config.options?.map((o) => (
          <option key={o.id} value={o.id}>
            {o.name}
          </option>
        ))}
      </select>
    );
  }
  if (prop.type === "person" || prop.type === "created_by" || prop.type === "last_edited_by") {
    return (
      <select className="input h-7 min-w-[120px]" value={String(cond.value ?? "")} onChange={(e) => onChange(e.target.value || null)} aria-label="Value">
        <option value="">Choose…</option>
        {db.members.map((m) => (
          <option key={m.id} value={m.id}>
            {m.name}
          </option>
        ))}
      </select>
    );
  }
  if (cond.operator === "is_relative") {
    return (
      <select className="input h-7" value={String(cond.value ?? "")} onChange={(e) => onChange(e.target.value || null)} aria-label="Value">
        <option value="">Choose…</option>
        {RELATIVE.map(([k, l]) => (
          <option key={k} value={k}>
            {l}
          </option>
        ))}
      </select>
    );
  }
  if (filterFamily(prop.type) === "date") {
    return <input type="date" className="input h-7" value={v} onChange={(e) => (setV(e.target.value), onChange(e.target.value || null))} aria-label="Date" />;
  }
  return (
    <input
      className="input h-7 min-w-[120px] flex-1"
      type={filterFamily(prop.type) === "number" ? "number" : "text"}
      placeholder="Value"
      value={v}
      onChange={(e) => setV(e.target.value)}
      onBlur={() => onChange(v === "" ? null : v)}
      onKeyDown={(e) => e.key === "Enter" && onChange(v === "" ? null : v)}
      aria-label="Value"
    />
  );
}

// ------------------------------------------------------------------ sorts

function SortBuilder() {
  const db = useDb();
  const sorts = db.config.sorts ?? [];
  const [drag, setDrag] = useState<number | null>(null);
  const save = (s: typeof sorts) => db.updateConfig({ sorts: s });
  return (
    <div className="w-[min(420px,94vw)] p-3 text-sm">
      {sorts.map((s, i) => (
        <div
          key={i}
          className="mb-1.5 flex items-center gap-1.5"
          draggable
          onDragStart={() => setDrag(i)}
          onDragOver={(e) => e.preventDefault()}
          onDrop={() => {
            if (drag == null || drag === i) return;
            const next = [...sorts];
            const [m] = next.splice(drag, 1);
            next.splice(i, 0, m);
            save(next);
            setDrag(null);
          }}
        >
          <GripVertical size={14} className="cursor-grab text-faint" />
          <select className="input h-7 flex-1" value={s.propertyId} onChange={(e) => save(sorts.map((x, k) => (k === i ? { ...x, propertyId: e.target.value } : x)))} aria-label="Sort property">
            {db.props.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
          <select className="input h-7" value={s.direction} onChange={(e) => save(sorts.map((x, k) => (k === i ? { ...x, direction: e.target.value as "asc" | "desc" } : x)))} aria-label="Direction">
            <option value="asc">Ascending</option>
            <option value="desc">Descending</option>
          </select>
          <button className="icon-btn" onClick={() => save(sorts.filter((_, k) => k !== i))} aria-label="Remove sort">
            <X size={14} />
          </button>
        </div>
      ))}
      {!sorts.length && <p className="mb-2 text-muted">No sorts. Records keep their manual order.</p>}
      <div className="flex gap-2">
        <button className="link-btn flex items-center gap-1" onClick={() => save([...sorts, { propertyId: db.titleProp.id, direction: "asc" }])}>
          <Plus size={13} /> Add sort
        </button>
        {sorts.length > 0 && (
          <button className="link-btn flex items-center gap-1" onClick={() => save([])}>
            <Trash2 size={13} /> Delete sorts
          </button>
        )}
      </div>
    </div>
  );
}

function GroupPicker({ onDone }: { onDone: () => void }) {
  const db = useDb();
  const groupable = db.props.filter((p) => !["files", "rollup", "title"].includes(p.type) || p.type === "title");
  return (
    <div className="w-[260px] p-1">
      <Menu
        filter
        width={250}
        onClose={onDone}
        items={[
          { label: "None", checked: !db.config.groupBy, onSelect: () => db.updateConfig({ groupBy: null }) },
          ...groupable.map((p) => ({ label: p.name, icon: <PropIcon type={p.type} />, checked: db.config.groupBy === p.id, onSelect: () => db.updateConfig({ groupBy: p.id }) })),
        ]}
      />
      {db.config.groupBy && (
        <label className="flex items-center gap-2 border-t border-line px-3 py-2 text-sm">
          <input type="checkbox" checked={!!db.config.hideEmptyGroups} onChange={(e) => db.updateConfig({ hideEmptyGroups: e.target.checked })} />
          Hide empty groups
        </label>
      )}
    </div>
  );
}

function PropertiesPanel() {
  const db = useDb();
  const visible = db.config.visibleProperties ?? db.props.map((p) => p.id);
  const [drag, setDrag] = useState<string | null>(null);
  const ordered = [...db.props.filter((p) => visible.includes(p.id)).sort((a, b) => visible.indexOf(a.id) - visible.indexOf(b.id)), ...db.props.filter((p) => !visible.includes(p.id))];
  const toggle = (id: string) => db.updateConfig({ visibleProperties: visible.includes(id) ? visible.filter((x) => x !== id) : [...visible, id] });
  return (
    <div className="w-[280px] p-2 text-sm">
      <div className="mb-1 flex items-center justify-between px-1 text-xs text-muted">
        <span>Properties in this view</span>
        <span className="flex gap-1">
          <button className="link-btn" onClick={() => db.updateConfig({ visibleProperties: db.props.map((p) => p.id) })}>
            Show all
          </button>
          <button className="link-btn" onClick={() => db.updateConfig({ visibleProperties: [db.titleProp.id] })}>
            Hide all
          </button>
        </span>
      </div>
      <div className="max-h-[50vh] overflow-y-auto">
        {ordered.map((p) => (
          <div
            key={p.id}
            draggable={visible.includes(p.id)}
            onDragStart={() => setDrag(p.id)}
            onDragOver={(e) => e.preventDefault()}
            onDrop={() => {
              if (!drag || drag === p.id || !visible.includes(p.id)) return;
              const next = visible.filter((x) => x !== drag);
              next.splice(next.indexOf(p.id), 0, drag);
              db.updateConfig({ visibleProperties: next });
              setDrag(null);
            }}
            className="flex items-center gap-2 rounded px-1 py-1 hover:bg-hover"
          >
            <GripVertical size={13} className={cx("text-faint", visible.includes(p.id) ? "cursor-grab" : "opacity-0")} />
            <PropIcon type={p.type} />
            <span className="flex-1 truncate">{p.name}</span>
            {p.type !== "title" && (
              <button className="icon-btn h-6 w-6" onClick={() => toggle(p.id)} aria-label={visible.includes(p.id) ? `Hide ${p.name}` : `Show ${p.name}`}>
                {visible.includes(p.id) ? <Eye size={14} /> : <EyeOff size={14} className="text-faint" />}
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function LayoutPanel() {
  const db = useDb();
  const v = db.view;
  const dateProps = db.props.filter((p) => ["date", "created_time", "last_edited_time"].includes(p.type));
  const fileProps = db.props.filter((p) => p.type === "files");
  const numericProps = db.props.filter((p) => ["number", "formula", "rollup"].includes(p.type));
  const setType = async (t: ViewType) => {
    await db.viewOps.setType(v.id, t);
  };
  return (
    <div className="w-[300px] p-3 text-sm">
      <div className="mb-2 grid grid-cols-4 gap-1">
        {VIEW_TYPES.map((t) => {
          const I = VIEW_ICONS[t];
          return (
            <button key={t} disabled={!db.viewsEditable} onClick={() => setType(t)} className={cx("flex flex-col items-center gap-1 rounded-md border p-2 text-xs", v.type === t ? "border-accent text-accent" : "border-line hover:bg-hover")}>
              <I size={16} /> {t[0].toUpperCase() + t.slice(1)}
            </button>
          );
        })}
      </div>
      <div className="space-y-2">
        {(v.type === "calendar" || v.type === "timeline") && (
          <label className="flex items-center justify-between gap-2">
            <span className="text-muted">{v.type === "calendar" ? "Show by" : "Dates from"}</span>
            <select className="input h-7 max-w-[160px]" value={db.config.dateProperty ?? ""} onChange={(e) => db.updateConfig({ dateProperty: e.target.value || null })}>
              <option value="">Choose…</option>
              {dateProps.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </label>
        )}
        {v.type === "timeline" && (
          <>
            <label className="flex items-center justify-between gap-2">
              <span className="text-muted">End date (optional)</span>
              <select className="input h-7 max-w-[160px]" value={db.config.endDateProperty ?? ""} onChange={(e) => db.updateConfig({ endDateProperty: e.target.value || null })}>
                <option value="">Use date range</option>
                {dateProps.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="flex items-center justify-between gap-2">
              <span className="text-muted">Zoom</span>
              <select className="input h-7" value={db.config.timelineScale ?? "week"} onChange={(e) => db.updateConfig({ timelineScale: e.target.value as "day" })}>
                <option value="day">Days</option>
                <option value="week">Weeks</option>
                <option value="month">Months</option>
              </select>
            </label>
          </>
        )}
        {(v.type === "gallery" || v.type === "board") && (
          <label className="flex items-center justify-between gap-2">
            <span className="text-muted">Card preview</span>
            <select className="input h-7 max-w-[160px]" value={db.config.cardCover ?? (v.type === "gallery" ? "page_cover" : "none")} onChange={(e) => db.updateConfig({ cardCover: e.target.value })}>
              <option value="none">None</option>
              <option value="page_cover">Page cover</option>
              {fileProps.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </label>
        )}
        {v.type === "gallery" && (
          <label className="flex items-center justify-between gap-2">
            <span className="text-muted">Card size</span>
            <select className="input h-7" value={db.config.cardSize ?? "medium"} onChange={(e) => db.updateConfig({ cardSize: e.target.value as "medium" })}>
              <option value="small">Small</option>
              <option value="medium">Medium</option>
              <option value="large">Large</option>
            </select>
          </label>
        )}
        {v.type === "chart" && (
          <>
            <label className="flex items-center justify-between gap-2">
              <span className="text-muted">Chart</span>
              <select className="input h-7" value={db.config.chartType ?? "column"} onChange={(e) => db.updateConfig({ chartType: e.target.value as "bar" })}>
                <option value="column">Vertical bars</option>
                <option value="bar">Horizontal bars</option>
                <option value="line">Line</option>
                <option value="donut">Donut</option>
              </select>
            </label>
            <label className="flex items-center justify-between gap-2">
              <span className="text-muted">Group by (X axis)</span>
              <select className="input h-7 max-w-[160px]" value={db.config.groupBy ?? ""} onChange={(e) => db.updateConfig({ groupBy: e.target.value || null })}>
                <option value="">Choose…</option>
                {db.props.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="flex items-center justify-between gap-2">
              <span className="text-muted">Value</span>
              <select
                className="input h-7 max-w-[160px]"
                value={db.config.chartValueProperty ? `${db.config.chartAggregate ?? "sum"}:${db.config.chartValueProperty}` : "count"}
                onChange={(e) => {
                  if (e.target.value === "count") db.updateConfig({ chartValueProperty: null, chartAggregate: "count" });
                  else {
                    const [agg, pid] = e.target.value.split(":");
                    db.updateConfig({ chartValueProperty: pid, chartAggregate: agg as "sum" });
                  }
                }}
              >
                <option value="count">Count of records</option>
                {numericProps.flatMap((p) =>
                  (["sum", "average", "min", "max"] as const).map((a) => (
                    <option key={`${a}:${p.id}`} value={`${a}:${p.id}`}>
                      {a[0].toUpperCase() + a.slice(1)} of {p.name}
                    </option>
                  )),
                )}
              </select>
            </label>
          </>
        )}
        {v.type === "table" && (
          <label className="flex items-center justify-between gap-2">
            <span className="text-muted">Wrap all cells</span>
            <input type="checkbox" checked={!!db.config.wrapCells} onChange={(e) => db.updateConfig({ wrapCells: e.target.checked })} />
          </label>
        )}
      </div>
    </div>
  );
}

export function AggregationMenu({ prop, anchor, onClose }: { prop: PropertyDef; anchor: HTMLElement | null; onClose: () => void }) {
  const db = useDb();
  const numeric = ["number", "formula", "rollup", "unique_id"].includes(prop.type);
  const dateLike = ["date", "created_time", "last_edited_time"].includes(prop.type);
  const list = AGGREGATIONS.filter((a) => {
    if (["sum", "average", "median", "min", "max", "range"].includes(a)) return numeric;
    if (["earliest", "latest"].includes(a)) return dateLike;
    if (["checked", "unchecked", "percent_checked"].includes(a)) return prop.type === "checkbox";
    return true;
  });
  const current = db.config.aggregations?.[prop.id] ?? "none";
  return (
    <Popover anchor={anchor} open={!!anchor} onClose={onClose} placement="top-start">
      <Menu
        width={210}
        onClose={onClose}
        items={list.map((a) => ({
          label: a === "none" ? "None" : a.replace(/_/g, " ").replace(/^\w/, (c) => c.toUpperCase()),
          checked: current === a,
          onSelect: () => db.updateConfig({ aggregations: { ...(db.config.aggregations ?? {}), [prop.id]: a } }),
        }))}
      />
    </Popover>
  );
}

export { Tag };
