"use client";
import { useState } from "react";
import { Plus } from "lucide-react";
import { cx } from "@/client/ui";
import type { QueryRow, PropertyDef } from "@/lib/db-types";
import { useDb } from "../context";
import { GroupHeader, groupValueFor } from "./table";
import { RecordCard } from "./cards";
import { GroupLoadMore } from "../load-more";

const BOARDABLE = ["select", "status", "multi_select", "checkbox", "person"];

export function BoardView() {
  const db = useDb();
  const [drag, setDrag] = useState<{ id: string; from: string } | null>(null);
  const [over, setOver] = useState<string | null>(null);
  const groupProp = db.config.groupBy ? db.props.find((p) => p.id === db.config.groupBy) : null;
  const groups = db.result?.groups;

  if (!groupProp || !groups) {
    const candidates = db.props.filter((p) => BOARDABLE.includes(p.type));
    return (
      <div className="rounded-md border border-dashed border-line p-6 text-center text-sm text-muted">
        <p className="mb-2">Boards group records into columns by a property.</p>
        {candidates.length ? (
          <div className="flex flex-wrap justify-center gap-2">
            {candidates.map((p) => (
              <button key={p.id} className="btn btn-sm" onClick={() => db.updateConfig({ groupBy: p.id })}>
                Group by {p.name}
              </button>
            ))}
          </div>
        ) : (
          <p>Add a Select or Status property to use a board.</p>
        )}
      </div>
    );
  }

  const moveTo = (rowId: string, from: string, to: string) => {
    if (from === to) return;
    const row = db.rowsById.get(rowId);
    if (!row) return;
    let value: unknown = groupValueFor(groupProp, to);
    if (groupProp.type === "multi_select" || groupProp.type === "person") {
      const cur = ((row.values[groupProp.id] as string[]) ?? []).filter((x) => x !== from);
      value = to === "__empty__" ? [] : [...new Set([...cur, to])];
    }
    db.setValue(rowId, groupProp.id, value);
  };

  return (
    <div className="flex gap-3 overflow-x-auto pb-4">
      {groups.map((g) => {
        const list = g.rowIds.map((id) => db.rowsById.get(id)).filter((r): r is QueryRow => !!r);
        return (
          <div
            key={g.key}
            className={cx("flex w-[260px] flex-none flex-col rounded-lg p-1.5", over === g.key ? "bg-accent-soft" : "bg-subtle/60")}
            onDragOver={(e) => {
              if (!drag) return;
              e.preventDefault();
              setOver(g.key);
            }}
            onDragLeave={() => setOver(null)}
            onDrop={(e) => {
              e.preventDefault();
              if (drag) moveTo(drag.id, drag.from, g.key);
              setDrag(null);
              setOver(null);
            }}
          >
            <div className="px-1">
              <GroupHeader group={g} prop={groupProp as PropertyDef} open onToggle={() => {}} count={g.count ?? list.length} />
            </div>
            <div className="flex flex-col gap-1.5">
              {list.map((r) => (
                <div key={r.id} draggable={db.editable} onDragStart={() => setDrag({ id: r.id, from: g.key })} onDragEnd={() => setDrag(null)} className={cx(drag?.id === r.id && "opacity-50")}>
                  <RecordCard row={r} />
                </div>
              ))}
            </div>
            <GroupLoadMore shown={list.length} total={g.count ?? list.length} />
            {db.editable && (
              <button className="mt-1 flex items-center gap-1 rounded px-2 py-1.5 text-sm text-muted hover:bg-hover" onClick={() => db.createRecord({ [groupProp.id]: groupValueFor(groupProp, g.key) }, { open: false })}>
                <Plus size={14} /> New
              </button>
            )}
          </div>
        );
      })}
    </div>
  );
}
