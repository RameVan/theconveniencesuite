"use client";
import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Plus } from "lucide-react";
import { cx } from "@/client/ui";
import { isDateValue } from "@/lib/format";
import type { DateValue, QueryRow } from "@/lib/db-types";
import { useDb } from "../context";
import { PageIcon, pageTitle } from "../../page-icon";

const pad = (n: number) => String(n).padStart(2, "0");
const keyOf = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export function dayOf(s: string): string {
  return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : keyOf(new Date(s));
}
export function addDays(ymd: string, n: number) {
  const [y, m, d] = ymd.split("-").map(Number);
  return keyOf(new Date(y, m - 1, d + n));
}
export function diffDays(a: string, b: string) {
  const [y1, m1, d1] = a.split("-").map(Number);
  const [y2, m2, d2] = b.split("-").map(Number);
  return Math.round((Date.UTC(y1, m1 - 1, d1) - Date.UTC(y2, m2 - 1, d2)) / 86_400_000);
}

/** Shift a date value so that it starts on `newStart` (keeping its duration and time of day). */
export function moveDate(v: DateValue, newStart: string): DateValue {
  const delta = diffDays(newStart, dayOf(v.start));
  const shift = (s: string) => {
    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return addDays(s, delta);
    const d = new Date(s);
    d.setDate(d.getDate() + delta);
    return d.toISOString();
  };
  return { start: shift(v.start), end: v.end ? shift(v.end) : null, includeTime: v.includeTime };
}

/** Longest span (days) a record is drawn across; records starting earlier than this before the grid are off-screen. */
export const MAX_SPAN_DAYS = 62;

/** The weeks shown for a month: Monday on or before the 1st, through the week of the last day. */
export function calendarGrid(month: Date) {
  const startOffset = (month.getDay() + 6) % 7;
  const gridStart = new Date(month.getFullYear(), month.getMonth(), 1 - startOffset);
  const weeks = Math.ceil((startOffset + new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate()) / 7);
  const gridEnd = new Date(gridStart.getFullYear(), gridStart.getMonth(), gridStart.getDate() + weeks * 7 - 1);
  return { gridStart, weeks, from: keyOf(gridStart), to: keyOf(gridEnd) };
}

export function CalendarView() {
  const db = useDb();
  const month = db.calendarMonth;
  const setMonth = db.setCalendarMonth;
  const [drag, setDrag] = useState<string | null>(null);
  const prop = db.props.find((p) => p.id === db.config.dateProperty);

  const byDay = useMemo(() => {
    const m = new Map<string, QueryRow[]>();
    if (!prop) return m;
    for (const r of db.result?.rows ?? []) {
      const v = r.values[prop.id];
      if (!isDateValue(v)) continue;
      const start = dayOf(v.start);
      const end = v.end ? dayOf(v.end) : start;
      const span = Math.max(0, diffDays(end, start));
      for (let i = 0; i <= Math.min(span, MAX_SPAN_DAYS); i++) {
        const k = addDays(start, i);
        m.set(k, [...(m.get(k) ?? []), r]);
      }
    }
    return m;
  }, [db.result, prop]);

  if (!prop)
    return (
      <div className="rounded-md border border-dashed border-line p-6 text-center text-sm text-muted">
        <p className="mb-2">Calendars place records on a date property.</p>
        <div className="flex flex-wrap justify-center gap-2">
          {db.props
            .filter((p) => ["date", "created_time", "last_edited_time"].includes(p.type))
            .map((p) => (
              <button key={p.id} className="btn btn-sm" onClick={() => db.updateConfig({ dateProperty: p.id })}>
                Use {p.name}
              </button>
            ))}
        </div>
      </div>
    );

  const { gridStart, weeks } = calendarGrid(month);
  const today = keyOf(new Date());
  const canWrite = db.editable && prop.type === "date";

  return (
    <div>
      <div className="mb-2 flex items-center gap-2">
        <span className="text-base font-semibold">{month.toLocaleString(undefined, { month: "long", year: "numeric" })}</span>
        <span className="ml-auto flex items-center gap-1">
          <button className="btn btn-sm" onClick={() => setMonth(new Date(new Date().getFullYear(), new Date().getMonth(), 1))}>
            Today
          </button>
          <button className="icon-btn" onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() - 1, 1))} aria-label="Previous month">
            <ChevronLeft size={16} />
          </button>
          <button className="icon-btn" onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() + 1, 1))} aria-label="Next month">
            <ChevronRight size={16} />
          </button>
        </span>
      </div>
      <div className="grid grid-cols-7 border-l border-t border-line text-xs">
        {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d) => (
          <div key={d} className="border-b border-r border-line px-2 py-1 text-muted">
            {d}
          </div>
        ))}
        {Array.from({ length: weeks * 7 }).map((_, i) => {
          const d = new Date(gridStart.getFullYear(), gridStart.getMonth(), gridStart.getDate() + i);
          const k = keyOf(d);
          const inMonth = d.getMonth() === month.getMonth();
          const items = byDay.get(k) ?? [];
          return (
            <div
              key={k}
              className={cx("group relative min-h-[104px] border-b border-r border-line p-1", !inMonth && "bg-subtle/50")}
              onDragOver={(e) => drag && e.preventDefault()}
              onDrop={() => {
                if (!drag) return;
                const row = db.rowsById.get(drag);
                const v = row?.values[prop.id];
                if (isDateValue(v)) db.setValue(drag, prop.id, moveDate(v, k));
                setDrag(null);
              }}
            >
              <div className="flex items-center justify-between">
                <span className={cx("flex h-6 min-w-6 items-center justify-center rounded-full px-1", k === today ? "bg-accent text-accent-fg" : inMonth ? "text-fg" : "text-faint")}>{d.getDate()}</span>
                {canWrite && (
                  <button className="icon-btn h-5 w-5 opacity-0 group-hover:opacity-100" title="New record on this day" onClick={() => db.createRecord({ [prop.id]: { start: k } })}>
                    <Plus size={13} />
                  </button>
                )}
              </div>
              <div className="mt-0.5 space-y-0.5">
                {items.slice(0, 4).map((r) => (
                  <button
                    key={r.id}
                    draggable={canWrite}
                    onDragStart={() => setDrag(r.id)}
                    onClick={() => db.openRecord(r.id)}
                    className="flex w-full items-center gap-1 truncate rounded border border-line bg-bg px-1.5 py-0.5 text-left shadow-sm hover:bg-hover"
                  >
                    {r.icon && <PageIcon icon={r.icon} size={12} />}
                    <span className="truncate">{pageTitle(r.title)}</span>
                  </button>
                ))}
                {items.length > 4 && <div className="px-1 text-faint">+{items.length - 4} more</div>}
              </div>
            </div>
          );
        })}
      </div>
      {(() => {
        // Live views fetch only the visible weeks, so they count undated records separately.
        const undated = db.undatedCount ?? (db.result?.rows ?? []).filter((r) => !isDateValue(r.values[prop.id])).length;
        return undated ? <p className="mt-2 text-xs text-muted">{undated} record{undated === 1 ? "" : "s"} without a {prop.name}</p> : null;
      })()}
    </div>
  );
}
