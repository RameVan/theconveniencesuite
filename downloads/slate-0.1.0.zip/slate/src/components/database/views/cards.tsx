"use client";
import { Plus } from "lucide-react";
import { cx } from "@/client/ui";
import type { QueryRow, FileValue } from "@/lib/db-types";
import { useDb } from "../context";
import { CellDisplay } from "../cells";
import { PageIcon, pageTitle } from "../../page-icon";
import { parseCover, withShare } from "../../page/cover";
import { useGroupedRows, GroupHeader } from "./table";
import { useState } from "react";
import { LoadMore, GroupLoadMore } from "../load-more";

function coverFor(row: QueryRow, mode: string | undefined, share?: string | null): { style?: React.CSSProperties; img?: string } | null {
  if (!mode || mode === "none") return null;
  if (mode === "page_cover") {
    if (!row.cover) return null;
    const c = parseCover(row.cover);
    return c.isImage && c.url ? { img: withShare(c.url, share) } : { style: c.style };
  }
  const files = row.values[mode] as unknown as FileValue[] | null;
  const img = files?.find((f) => /\.(png|jpe?g|gif|webp|avif)$/i.test(f.name) || f.url.startsWith("/api/files/"));
  return img ? { img: withShare(img.url, share) } : null;
}

export function RecordCard({ row, size = "medium", showCover }: { row: QueryRow; size?: "small" | "medium" | "large"; showCover?: boolean }) {
  const db = useDb();
  const props = db.visibleProps.filter((p) => p.type !== "title");
  const cover = showCover || db.view.type === "board" ? coverFor(row, db.config.cardCover ?? (db.view.type === "gallery" ? "page_cover" : "none"), db.shareToken) : null;
  return (
    <button onClick={() => db.openRecord(row.id)} className="w-full overflow-hidden rounded-md border border-line bg-bg text-left shadow-[0_1px_2px_rgba(0,0,0,0.04)] hover:bg-hover">
      {db.view.type === "gallery" && (
        <div className={cx("w-full border-b border-line bg-subtle", size === "small" ? "h-24" : size === "large" ? "h-48" : "h-36")} style={cover?.style}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          {cover?.img && <img src={cover.img} alt="" className="h-full w-full object-cover" />}
        </div>
      )}
      {db.view.type === "board" && cover && (
        <div className="h-28 w-full bg-subtle" style={cover.style}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          {cover.img && <img src={cover.img} alt="" className="h-full w-full object-cover" />}
        </div>
      )}
      <div className="space-y-1.5 p-2.5">
        <div className="flex items-center gap-1.5 text-sm font-medium">
          {row.icon && <PageIcon icon={row.icon} size={15} />}
          <span className="truncate">{pageTitle(row.title)}</span>
        </div>
        {props.map((p) => {
          const v = row.values[p.id];
          if (v === null || v === undefined || v === "" || (Array.isArray(v) && !v.length)) return null;
          return (
            <div key={p.id} className="text-xs text-muted" title={p.name}>
              <CellDisplay prop={p} value={v} refs={db.result?.refs} compact />
            </div>
          );
        })}
      </div>
    </button>
  );
}

export function ListView() {
  const db = useDb();
  const groups = useGroupedRows();
  const [closed, setClosed] = useState<Record<string, boolean>>({});
  const props = db.visibleProps.filter((p) => p.type !== "title");
  const groupProp = db.config.groupBy ? db.props.find((p) => p.id === db.config.groupBy) : null;
  const renderRows = (rows: QueryRow[]) =>
    rows.map((r) => (
      <button key={r.id} onClick={() => db.openRecord(r.id)} className="flex w-full items-center gap-3 border-b border-line px-1 py-2 text-left text-sm hover:bg-hover">
        <PageIcon icon={r.icon} size={16} />
        <span className="min-w-0 flex-1 truncate font-medium">{pageTitle(r.title)}</span>
        <span className="hidden max-w-[60%] items-center gap-3 overflow-hidden text-xs text-muted sm:flex">
          {props.map((p) => (
            <span key={p.id} className="max-w-[180px] truncate">
              <CellDisplay prop={p} value={r.values[p.id]} refs={db.result?.refs} compact />
            </span>
          ))}
        </span>
      </button>
    ));
  return (
    <div>
      {groups && groupProp
        ? groups.map(({ group, rows }) => (
            <div key={group.key} className="mb-2">
              <GroupHeader group={group} prop={groupProp} open={!closed[group.key]} onToggle={() => setClosed({ ...closed, [group.key]: !closed[group.key] })} count={group.count ?? rows.length} />
              {!closed[group.key] && renderRows(rows)}
              {!closed[group.key] && <GroupLoadMore shown={rows.length} total={group.count ?? rows.length} />}
            </div>
          ))
        : (
            <>
              {renderRows(db.result?.rows ?? [])}
              <LoadMore shown={db.result?.rows.length ?? 0} total={db.result?.matched ?? 0} />
            </>
          )}
      {db.editable && (
        <button className="flex w-full items-center gap-1.5 px-1 py-2 text-sm text-faint hover:bg-hover" onClick={() => db.createRecord({}, { open: true })}>
          <Plus size={14} /> New
        </button>
      )}
    </div>
  );
}

export function GalleryView() {
  const db = useDb();
  const groups = useGroupedRows();
  const groupProp = db.config.groupBy ? db.props.find((p) => p.id === db.config.groupBy) : null;
  const size = db.config.cardSize ?? "medium";
  const grid = (rows: QueryRow[]) => (
    <div className={cx("grid gap-3", size === "small" ? "grid-cols-2 sm:grid-cols-4 lg:grid-cols-5" : size === "large" ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3" : "grid-cols-2 sm:grid-cols-3 lg:grid-cols-4")}>
      {rows.map((r) => (
        <RecordCard key={r.id} row={r} size={size} showCover />
      ))}
      {db.editable && (
        <button className="flex min-h-[120px] items-center justify-center gap-1 rounded-md border border-dashed border-line text-sm text-faint hover:bg-hover" onClick={() => db.createRecord({}, { open: true })}>
          <Plus size={14} /> New
        </button>
      )}
    </div>
  );
  return groups && groupProp ? (
    <div className="space-y-4">
      {groups.map(({ group, rows }) => (
        <div key={group.key}>
          <GroupHeader group={group} prop={groupProp} open onToggle={() => {}} count={group.count ?? rows.length} />
          {grid(rows)}
          <GroupLoadMore shown={rows.length} total={group.count ?? rows.length} />
        </div>
      ))}
    </div>
  ) : (
    <>
      {grid(db.result?.rows ?? [])}
      <LoadMore shown={db.result?.rows.length ?? 0} total={db.result?.matched ?? 0} />
    </>
  );
}
