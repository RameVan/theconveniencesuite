"use client";
import { useState } from "react";
import { useDb } from "../context";
import { formatCell } from "@/lib/format";

const PALETTE = ["var(--c-blue-fg)", "var(--c-green-fg)", "var(--c-orange-fg)", "var(--c-purple-fg)", "var(--c-pink-fg)", "var(--c-yellow-fg)", "var(--c-red-fg)", "var(--c-brown-fg)", "var(--c-gray-fg)"];
const COLOR_VAR = (c: string, i: number) => (c && c !== "default" ? `var(--c-${c}-fg)` : PALETTE[i % PALETTE.length]);

export function ChartView() {
  const db = useDb();
  const [hover, setHover] = useState<number | null>(null);
  const groupProp = db.config.groupBy ? db.props.find((p) => p.id === db.config.groupBy) : null;
  const valueProp = db.config.chartValueProperty ? db.props.find((p) => p.id === db.config.chartValueProperty) : null;
  if (!groupProp || !db.result?.groups)
    return (
      <div className="rounded-md border border-dashed border-line p-6 text-center text-sm text-muted">
        Choose a property to group by in <b>Layout</b> to draw a chart.
      </div>
    );
  const data = db.result.groups
    .map((g, i) => {
      // Counts and aggregations cover every record (the chart only loads one row per group).
      const raw = valueProp ? g.aggregations[valueProp.id] : (g.count ?? g.rowIds.length);
      return { label: g.label, value: typeof raw === "number" ? raw : 0, color: COLOR_VAR(g.color, i) };
    })
    .filter((d) => d.value !== 0 || !db.config.hideEmptyGroups);
  const max = Math.max(1, ...data.map((d) => d.value));
  const total = data.reduce((s, d) => s + d.value, 0);
  const fmt = (n: number) => (valueProp ? formatCell({ ...valueProp, type: "number" }, n) : String(n));
  const type = db.config.chartType ?? "column";
  const title = valueProp ? `${(db.config.chartAggregate ?? "sum").replace(/^\w/, (c) => c.toUpperCase())} of ${valueProp.name} by ${groupProp.name}` : `Count by ${groupProp.name}`;

  if (type === "donut") {
    const starts = data.map((_, i) => data.slice(0, i).reduce((s2, d2) => s2 + d2.value, 0));
    const R = 80;
    const r = 50;
    const arcs = data.map((d, i) => {
      const a0 = (starts[i] / Math.max(total, 1)) * Math.PI * 2;
      const a1 = ((starts[i] + d.value) / Math.max(total, 1)) * Math.PI * 2;
      const large = a1 - a0 > Math.PI ? 1 : 0;
      const p = (a: number, rad: number) => [100 + rad * Math.sin(a), 100 - rad * Math.cos(a)];
      const [x0, y0] = p(a0, R);
      const [x1, y1] = p(a1, R);
      const [x2, y2] = p(a1, r);
      const [x3, y3] = p(a0, r);
      const full = data.length === 1 || a1 - a0 >= Math.PI * 2 - 1e-6;
      const path = full ? `M100,${100 - R} A${R},${R} 0 1,1 99.99,${100 - R} L99.99,${100 - r} A${r},${r} 0 1,0 100,${100 - r} Z` : `M${x0},${y0} A${R},${R} 0 ${large},1 ${x1},${y1} L${x2},${y2} A${r},${r} 0 ${large},0 ${x3},${y3} Z`;
      return <path key={i} d={path} fill={d.color} opacity={hover === null || hover === i ? 0.9 : 0.35} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)} />;
    });
    return (
      <figure className="flex flex-col items-center gap-4 py-4 sm:flex-row sm:justify-center">
        <svg viewBox="0 0 200 200" width={220} height={220} role="img" aria-label={title}>
          {arcs}
          <text x="100" y="96" textAnchor="middle" className="fill-[var(--fg)] text-[18px] font-semibold">
            {hover !== null ? fmt(data[hover].value) : fmt(total)}
          </text>
          <text x="100" y="116" textAnchor="middle" className="fill-[var(--fg-muted)] text-[10px]">
            {hover !== null ? data[hover].label : "Total"}
          </text>
        </svg>
        <figcaption className="space-y-1 text-sm">
          <div className="mb-2 font-medium">{title}</div>
          {data.map((d, i) => (
            <div key={i} className="flex items-center gap-2" onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>
              <span className="h-3 w-3 rounded-sm" style={{ background: d.color }} />
              <span className="flex-1">{d.label}</span>
              <span className="tabular-nums text-muted">{fmt(d.value)}</span>
            </div>
          ))}
        </figcaption>
      </figure>
    );
  }

  if (type === "bar") {
    return (
      <figure className="py-3">
        <figcaption className="mb-3 text-sm font-medium">{title}</figcaption>
        <div className="space-y-1.5">
          {data.map((d, i) => (
            <div key={i} className="flex items-center gap-2 text-sm">
              <span className="w-32 flex-none truncate text-right text-muted">{d.label}</span>
              <div className="h-6 flex-1">
                <div className="h-full rounded-r" style={{ width: `${(d.value / max) * 100}%`, background: d.color, opacity: 0.85, minWidth: d.value ? 2 : 0 }} />
              </div>
              <span className="w-16 tabular-nums">{fmt(d.value)}</span>
            </div>
          ))}
        </div>
      </figure>
    );
  }

  const W = Math.max(320, data.length * 64);
  const H = 240;
  const padB = 40;
  const padL = 36;
  const bw = (W - padL) / Math.max(1, data.length);
  const y = (v: number) => H - padB - (v / max) * (H - padB - 16);
  return (
    <figure className="overflow-x-auto py-3">
      <figcaption className="mb-2 text-sm font-medium">{title}</figcaption>
      <svg width={W} height={H} role="img" aria-label={title} className="text-xs">
        {[0, 0.25, 0.5, 0.75, 1].map((t) => (
          <g key={t}>
            <line x1={padL} x2={W} y1={y(max * t)} y2={y(max * t)} stroke="var(--border)" />
            <text x={padL - 6} y={y(max * t) + 4} textAnchor="end" fill="var(--fg-faint)">
              {Math.round(max * t * 100) / 100}
            </text>
          </g>
        ))}
        {type === "line" ? (
          <>
            <polyline fill="none" stroke="var(--accent)" strokeWidth={2} points={data.map((d, i) => `${padL + bw * i + bw / 2},${y(d.value)}`).join(" ")} />
            {data.map((d, i) => (
              <circle key={i} cx={padL + bw * i + bw / 2} cy={y(d.value)} r={hover === i ? 5 : 3.5} fill="var(--accent)" onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)} />
            ))}
          </>
        ) : (
          data.map((d, i) => (
            <rect
              key={i}
              x={padL + bw * i + bw * 0.15}
              y={y(d.value)}
              width={bw * 0.7}
              height={Math.max(0, H - padB - y(d.value))}
              rx={3}
              fill={d.color}
              opacity={hover === null || hover === i ? 0.85 : 0.4}
              onMouseEnter={() => setHover(i)}
              onMouseLeave={() => setHover(null)}
            />
          ))
        )}
        {data.map((d, i) => (
          <text key={i} x={padL + bw * i + bw / 2} y={H - padB + 16} textAnchor="middle" fill="var(--fg-muted)">
            {d.label.length > 10 ? d.label.slice(0, 9) + "…" : d.label}
          </text>
        ))}
        {hover !== null && (
          <text x={padL + bw * hover + bw / 2} y={y(data[hover].value) - 8} textAnchor="middle" fill="var(--fg)" fontWeight={600}>
            {fmt(data[hover].value)}
          </text>
        )}
      </svg>
    </figure>
  );
}
