"use client";
import { useMemo, useState } from "react";
import { Plus, ArrowUpRight, ChevronRight, GripVertical, Trash2, X } from "lucide-react";
import { api, errorMessage } from "@/client/api";
import { cx, useUi } from "@/client/ui";
import { formatCell } from "@/lib/format";
import type { PropertyDef, QueryRow, CellValue, QueryGroup } from "@/lib/db-types";
import { useDb } from "../context";
import { EditableCell, Tag, StatusTag, CheckboxBox } from "../cells";
import { PropertyMenu, AddPropertyMenu, PropIcon } from "../property-menu";
import { AggregationMenu } from "../toolbar";
import { PageIcon } from "../../page-icon";
import { LoadMore, GroupLoadMore } from "../load-more";
import { VirtualRows } from "../virtual-rows";

const DEFAULT_WIDTH = 180;
const TITLE_WIDTH = 280;

export function groupValueFor(prop: PropertyDef, key: string): unknown {
  if (key === "__empty__") return null;
  if (prop.type === "multi_select" || prop.type === "person" || prop.type === "relation") return [key];
  if (prop.type === "checkbox") return key === "true";
  return key;
}

export function GroupHeader({ group, prop, open, onToggle, count }: { group: QueryGroup; prop: PropertyDef; open: boolean; onToggle: () => void; count: number }) {
  const opt = prop.config.options?.find((o) => o.id === group.key);
  return (
    <button className="flex items-center gap-2 py-1.5 text-sm" onClick={onToggle} aria-expanded={open}>
      <ChevronRight size={14} className={cx("text-muted transition-transform", open && "rotate-90")} />
      {opt ? prop.type === "status" ? <StatusTag option={opt} /> : <Tag option={opt} /> : prop.type === "checkbox" ? <CheckboxBox checked={group.key === "true"} /> : <span className="font-medium">{group.label}</span>}
      <span className="text-muted">{count}</span>
    </button>
  );
}

/** A table row holding one full-width cell, for the controls between and after the records. */
function FullRow({ children }: { children: React.ReactNode }) {
  return (
    <div role="row">
      <div role="cell">{children}</div>
    </div>
  );
}

export function TableView() {
  const db = useDb();
  const { toast, confirm } = useUi();
  const [menu, setMenu] = useState<{ prop: PropertyDef; anchor: HTMLElement } | null>(null);
  const [addAnchor, setAddAnchor] = useState<HTMLElement | null>(null);
  const [aggMenu, setAggMenu] = useState<{ prop: PropertyDef; anchor: HTMLElement } | null>(null);
  const [colDrag, setColDrag] = useState<string | null>(null);
  const [rowDrag, setRowDrag] = useState<string | null>(null);
  const [closed, setClosed] = useState<Record<string, boolean>>({});
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const widths = db.config.propertyWidths ?? {};
  const [liveWidths, setLiveWidths] = useState<Record<string, number>>({});
  const width = (p: PropertyDef) => liveWidths[p.id] ?? widths[p.id] ?? (p.type === "title" ? TITLE_WIDTH : DEFAULT_WIDTH);
  const cols = db.visibleProps;
  const totalWidth = cols.reduce((s, p) => s + width(p), 0) + 32 + 44;
  const rows = db.result?.rows ?? [];
  const canReorder = db.editable && !(db.config.sorts?.length) && !db.config.groupBy;
  const groupProp = db.config.groupBy ? db.props.find((p) => p.id === db.config.groupBy) : null;

  const startResize = (e: React.MouseEvent, p: PropertyDef) => {
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX;
    const startW = width(p);
    let w = startW;
    const onMove = (ev: MouseEvent) => {
      w = Math.max(80, Math.min(800, startW + ev.clientX - startX));
      setLiveWidths((x) => ({ ...x, [p.id]: w }));
    };
    const onUp = () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
      db.updateConfig({ propertyWidths: { ...widths, [p.id]: w } });
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  };

  const dropColumn = (target: string) => {
    if (!colDrag || colDrag === target) return;
    const ids = cols.map((c) => c.id).filter((id) => id !== colDrag);
    ids.splice(ids.indexOf(target), 0, colDrag);
    db.updateConfig({ visibleProperties: ids });
    setColDrag(null);
  };

  const dropRow = async (targetId: string) => {
    if (!rowDrag || rowDrag === targetId) return;
    const moved = rowDrag;
    setRowDrag(null);
    try {
      // Only the loaded rows are known here, so move the one record rather than sending an order.
      await api.post(`/api/databases/${db.databaseId}/reorder`, { id: moved, beforeId: targetId });
      db.refresh();
    } catch (e) {
      toast(errorMessage(e), "error");
    }
  };

  const deleteSelected = async () => {
    if (!(await confirm({ title: `Delete ${selected.size} record${selected.size === 1 ? "" : "s"}?`, message: "They move to the Trash and can be restored.", danger: true, confirmLabel: "Delete" }))) return;
    for (const id of selected) await api.post(`/api/pages/${id}/archive`).catch(() => {});
    setSelected(new Set());
    db.refresh();
  };

  const renderRow = (row: QueryRow) => (
    <div
      key={row.id}
      role="row"
      className={cx("group/row flex border-b border-line hover:bg-hover/50", selected.has(row.id) && "bg-accent-soft")}
      onDragOver={(e) => rowDrag && e.preventDefault()}
      onDrop={() => dropRow(row.id)}
    >
      <div role="cell" className="flex w-8 flex-none items-center justify-center gap-0.5 opacity-0 group-hover/row:opacity-100 focus-within:opacity-100" style={selected.size ? { opacity: 1 } : undefined}>
        {db.editable && (
          <input
            type="checkbox"
            className="h-3.5 w-3.5 accent-[var(--accent)]"
            checked={selected.has(row.id)}
            aria-label="Select row"
            onChange={(e) => {
              const next = new Set(selected);
              if (e.target.checked) next.add(row.id);
              else next.delete(row.id);
              setSelected(next);
            }}
          />
        )}
        {canReorder && (
          <span draggable onDragStart={() => setRowDrag(row.id)} onDragEnd={() => setRowDrag(null)} className="cursor-grab text-faint" title="Drag to reorder">
            <GripVertical size={13} />
          </span>
        )}
      </div>
      {cols.map((p) => (
        <div key={p.id} role="cell" className={cx("relative flex min-h-[34px] flex-none items-start border-r border-line px-2 py-[7px] text-sm", p.type === "number" && "justify-end")} style={{ width: width(p) }}>
          {p.type === "title" ? (
            <div className="flex w-full min-w-0 items-start gap-1.5">
              {row.icon && <PageIcon icon={row.icon} size={16} className="mt-0.5" />}
              <EditableCell prop={p} row={row} className="min-w-0 flex-1" wrap={db.config.wrapCells} placeholder={db.editable ? " " : undefined} />
              <button
                onClick={() => db.openRecord(row.id)}
                className="flex flex-none items-center gap-0.5 rounded border border-line bg-bg px-1.5 py-0.5 text-[11px] font-medium text-muted opacity-0 hover:bg-hover group-hover/row:opacity-100"
              >
                <ArrowUpRight size={11} /> Open
              </button>
            </div>
          ) : (
            <EditableCell prop={p} row={row} className="w-full" wrap={db.config.wrapCells} placeholder={db.editable ? " " : undefined} />
          )}
        </div>
      ))}
      <div className="w-11 flex-none" />
    </div>
  );

  const newRow = (values?: Record<string, unknown>) =>
    db.editable && (
      <button className="flex h-8 w-full items-center gap-1.5 border-b border-line pl-10 text-sm text-faint hover:bg-hover" onClick={() => db.createRecord(values)}>
        <Plus size={14} /> New
      </button>
    );

  const footer = (count: number, aggs: Record<string, CellValue> | undefined) => (
    <div className="flex text-xs text-muted">
      <div className="w-8 flex-none" />
      {cols.map((p) => {
        const agg = db.config.aggregations?.[p.id];
        const val = aggs?.[p.id];
        return (
          <button key={p.id} className="group/agg flex h-8 flex-none items-center justify-end gap-1 px-2 hover:bg-hover" style={{ width: width(p) }} onClick={(e) => setAggMenu({ prop: p, anchor: e.currentTarget })}>
            {agg && agg !== "none" ? (
              <>
                <span className="uppercase tracking-wide text-faint">{agg.replace(/_/g, " ")}</span>
                <span className="font-medium text-fg">{formatAgg(p, agg, val ?? null)}</span>
              </>
            ) : (
              <span className="opacity-0 group-hover/agg:opacity-100">{p.type === "title" ? `Count ${count}` : "Calculate"}</span>
            )}
          </button>
        );
      })}
    </div>
  );

  const groups = db.result?.groups;
  return (
    <div className="relative">
      {selected.size > 0 && (
        <div className="sticky top-0 z-10 mb-1 flex items-center gap-2 rounded-md bg-accent px-3 py-1.5 text-sm text-accent-fg">
          {selected.size} selected
          <button className="ml-2 flex items-center gap-1 rounded px-2 py-0.5 hover:bg-white/15" onClick={deleteSelected}>
            <Trash2 size={13} /> Delete
          </button>
          <button className="ml-auto rounded p-0.5 hover:bg-white/15" onClick={() => setSelected(new Set())} aria-label="Clear selection">
            <X size={14} />
          </button>
        </div>
      )}
      <div className="overflow-x-auto">
        <div style={{ minWidth: totalWidth }}>
          <div role="table" aria-label={db.meta.title || "Database"}>
          <div role="row" className="flex border-b border-line text-sm text-muted">
            <div role="columnheader" className="w-8 flex-none">
              {db.editable && rows.length > 0 && (
                <input
                  type="checkbox"
                  className="ml-2 mt-2.5 h-3.5 w-3.5 accent-[var(--accent)]"
                  aria-label="Select all"
                  checked={selected.size === rows.length}
                  onChange={(e) => setSelected(e.target.checked ? new Set(rows.map((r) => r.id)) : new Set())}
                />
              )}
            </div>
            {cols.map((p) => (
              <div
                key={p.id}
                role="columnheader"
                className="group/h relative flex h-[34px] flex-none items-center border-r border-line"
                style={{ width: width(p) }}
                draggable={db.editable}
                onDragStart={() => setColDrag(p.id)}
                onDragOver={(e) => colDrag && e.preventDefault()}
                onDrop={() => dropColumn(p.id)}
              >
                <button className="flex h-full min-w-0 flex-1 items-center gap-1.5 px-2 hover:bg-hover" onClick={(e) => setMenu({ prop: p, anchor: e.currentTarget })}>
                  <PropIcon type={p.type} />
                  <span className="truncate">{p.name}</span>
                  {db.config.sorts?.some((s) => s.propertyId === p.id) && <span className="text-[10px] text-accent">{db.config.sorts!.find((s) => s.propertyId === p.id)!.direction === "asc" ? "↑" : "↓"}</span>}
                </button>
                <div className="absolute -right-1 top-0 z-10 h-full w-2 cursor-col-resize opacity-0 hover:bg-accent group-hover/h:opacity-40" onMouseDown={(e) => startResize(e, p)} />
              </div>
            ))}
            {db.editable && (
              <div role="columnheader" className="flex w-11 flex-none">
                <button className="flex w-full items-center justify-center hover:bg-hover" onClick={(e) => setAddAnchor(e.currentTarget)} title="Add a property" aria-label="Add a property">
                  <Plus size={15} />
                </button>
              </div>
            )}
          </div>
          {groups && groupProp &&
            groups.map((g) => {
              const open = !closed[g.key];
              const list = g.rowIds.map((id) => db.rowsById.get(id)).filter((r): r is QueryRow => !!r);
              return (
                <div key={g.key} className="mt-2">
                  <FullRow>
                    <GroupHeader group={g} prop={groupProp} open={open} onToggle={() => setClosed({ ...closed, [g.key]: open })} count={g.count ?? list.length} />
                  </FullRow>
                  {open && (
                    <>
                      <div role="rowgroup" className="border-t border-line">
                        {list.map(renderRow)}
                      </div>
                      <FullRow>
                        <GroupLoadMore shown={list.length} total={g.count ?? list.length} />
                        {newRow({ [groupProp.id]: groupValueFor(groupProp, g.key) })}
                        {footer(g.count ?? list.length, g.aggregations)}
                      </FullRow>
                    </>
                  )}
                </div>
              );
            })}
          {!(groups && groupProp) && <VirtualRows rows={rows} render={renderRow} enabled={!db.config.wrapCells} />}
          </div>
          {!(groups && groupProp) && (
            <>
              <LoadMore shown={rows.length} total={db.result?.matched ?? rows.length} />
              {newRow()}
              {footer(db.result?.matched ?? rows.length, db.result?.aggregations)}
            </>
          )}
        </div>
      </div>
      {menu && <PropertyMenu prop={db.props.find((p) => p.id === menu.prop.id) ?? menu.prop} anchor={menu.anchor} onClose={() => setMenu(null)} />}
      <AddPropertyMenu anchor={addAnchor} onClose={() => setAddAnchor(null)} />
      {aggMenu && <AggregationMenu prop={aggMenu.prop} anchor={aggMenu.anchor} onClose={() => setAggMenu(null)} />}
    </div>
  );
}

export function formatAgg(p: PropertyDef, agg: string, v: CellValue): string {
  if (v === null || v === undefined) return "–";
  if (typeof v === "number") {
    if (agg.startsWith("percent")) return `${v}%`;
    if (["count", "count_values", "unique", "empty", "not_empty", "checked", "unchecked"].includes(agg)) return String(v);
    return formatCell({ ...p, type: p.type === "number" ? "number" : "rich_text" }, v);
  }
  return formatCell({ ...p, type: "date" }, v);
}

export function useGroupedRows() {
  const db = useDb();
  return useMemo(() => {
    const groups = db.result?.groups ?? null;
    return groups?.map((g) => ({ group: g, rows: g.rowIds.map((id) => db.rowsById.get(id)).filter((r): r is QueryRow => !!r) })) ?? null;
  }, [db.result, db.rowsById]);
}
