"use client";
import { useMemo, useRef } from "react";
import { cx } from "@/client/ui";
import { isDateValue } from "@/lib/format";
import type { DateValue, QueryRow } from "@/lib/db-types";
import { useDb } from "../context";
import { PageIcon, pageTitle } from "../../page-icon";
import { addDays, dayOf, diffDays } from "./calendar";
import { LoadMore } from "../load-more";

const DAY_W = { day: 40, week: 16, month: 5 } as const;

export function TimelineView() {
  const db = useDb();
  const scale = db.config.timelineScale ?? "week";
  const dayW = DAY_W[scale];
  const prop = db.props.find((p) => p.id === db.config.dateProperty);
  const endProp = db.props.find((p) => p.id === db.config.endDateProperty);
  const scrollRef = useRef<HTMLDivElement>(null);
  const canWrite = db.editable && prop?.type === "date";

  const items = useMemo(() => {
    if (!prop) return [];
    return (db.result?.rows ?? []).map((r) => {
      const v = r.values[prop.id];
      if (!isDateValue(v))
        return {
          row: r,
          start: null as string | null,
          end: null as string | null,
        };
      const start = dayOf(v.start);
      const endV = endProp ? r.values[endProp.id] : null;
      const end =
        endProp && isDateValue(endV)
          ? dayOf(endV.start)
          : v.end
            ? dayOf(v.end)
            : start;
      return { row: r, start, end: end < start ? start : end };
    });
  }, [db.result, prop, endProp]);

  if (!prop)
    return (
      <div className="rounded-md border border-dashed border-line p-6 text-center text-sm text-muted">
        <p className="mb-2">Timelines show records as bars between dates.</p>
        <div className="flex flex-wrap justify-center gap-2">
          {db.props
            .filter((p) => p.type === "date")
            .map((p) => (
              <button
                key={p.id}
                className="btn btn-sm"
                onClick={() => db.updateConfig({ dateProperty: p.id })}
              >
                Use {p.name}
              </button>
            ))}
        </div>
      </div>
    );

  const today = dayOf(new Date().toISOString().slice(0, 10));
  const dated = items.filter((i) => i.start);
  const minStart = dated.reduce((m, i) => (i.start! < m ? i.start! : m), today);
  const maxEnd = dated.reduce((m, i) => (i.end! > m ? i.end! : m), today);
  const rangeStart = addDays(minStart, -14);
  const totalDays = Math.max(90, diffDays(maxEnd, rangeStart) + 45);
  const width = totalDays * dayW;
  const x = (d: string) => diffDays(d, rangeStart) * dayW;

  const ticks: { x: number; label: string; major: boolean }[] = [];
  for (let i = 0; i < totalDays; i++) {
    const d = addDays(rangeStart, i);
    const [, m, day] = d.split("-").map(Number);
    const date = new Date(d + "T00:00:00");
    if (scale === "day")
      ticks.push({ x: i * dayW, label: String(day), major: day === 1 });
    else if (scale === "week" && date.getDay() === 1)
      ticks.push({
        x: i * dayW,
        label: `${date.toLocaleString(undefined, { month: "short" })} ${day}`,
        major: day <= 7,
      });
    else if (scale === "month" && day === 1)
      ticks.push({
        x: i * dayW,
        label: date.toLocaleString(undefined, {
          month: "short",
          year: m === 1 ? "numeric" : undefined,
        }),
        major: true,
      });
  }

  const drag = (
    e: React.MouseEvent,
    row: QueryRow,
    mode: "move" | "end",
    start: string,
    end: string,
  ) => {
    if (!canWrite) return;
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX;
    const el = e.currentTarget.closest("[data-bar]") as HTMLElement;
    const origLeft = el.offsetLeft;
    const origWidth = el.offsetWidth;
    let delta = 0;
    const onMove = (ev: MouseEvent) => {
      delta = Math.round((ev.clientX - startX) / dayW);
      if (mode === "move") el.style.left = `${origLeft + delta * dayW}px`;
      else el.style.width = `${Math.max(dayW, origWidth + delta * dayW)}px`;
    };
    const onUp = () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
      if (!delta) {
        if (mode === "move") db.openRecord(row.id);
        return;
      }
      const v = row.values[prop!.id] as DateValue;
      if (mode === "move") {
        if (endProp) {
          db.setValue(row.id, prop!.id, { ...v, start: addDays(start, delta) });
          const ev2 = row.values[endProp.id];
          if (isDateValue(ev2))
            db.setValue(row.id, endProp.id, {
              ...ev2,
              start: addDays(dayOf(ev2.start), delta),
            });
        } else
          db.setValue(row.id, prop!.id, {
            start: addDays(start, delta),
            end: v.end ? addDays(end, delta) : null,
            includeTime: false,
          });
      } else {
        const newEnd =
          addDays(end, delta) < start ? start : addDays(end, delta);
        if (endProp) db.setValue(row.id, endProp.id, { start: newEnd });
        else
          db.setValue(row.id, prop!.id, {
            start,
            end: newEnd === start ? null : newEnd,
            includeTime: false,
          });
      }
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  };

  return (
    <>
      <div className="flex overflow-hidden rounded-md border border-line">
        <div className="w-48 flex-none border-r border-line text-sm sm:w-60">
          <div className="h-8 border-b border-line px-2 py-1.5 text-xs text-muted">
            {db.titleProp.name}
          </div>
          {items.map(({ row }) => (
            <button
              key={row.id}
              onClick={() => db.openRecord(row.id)}
              className="flex h-9 w-full items-center gap-1.5 border-b border-line px-2 text-left hover:bg-hover"
            >
              <PageIcon icon={row.icon} size={14} />
              <span className="truncate">{pageTitle(row.title)}</span>
            </button>
          ))}
        </div>
        <div ref={scrollRef} className="min-w-0 flex-1 overflow-x-auto">
          <div className="relative" style={{ width }}>
            <div className="relative h-8 border-b border-line text-xs text-muted">
              {ticks.map((t, i) => (
                <span
                  key={i}
                  className={cx(
                    "absolute top-1.5 whitespace-nowrap pl-1",
                    t.major && "font-medium text-fg",
                  )}
                  style={{ left: t.x }}
                >
                  {t.label}
                </span>
              ))}
            </div>
            <div
              className="pointer-events-none absolute bottom-0 top-8 w-px bg-accent"
              style={{ left: x(today) + dayW / 2 }}
            />
            {ticks.map((t, i) => (
              <div
                key={i}
                className="pointer-events-none absolute bottom-0 top-8 w-px bg-line/60"
                style={{ left: t.x }}
              />
            ))}
            {items.map(({ row, start, end }) => (
              <div key={row.id} className="relative h-9 border-b border-line">
                {start && end ? (
                  <div
                    data-bar=""
                    className={cx(
                      "group absolute top-1.5 flex h-6 items-center rounded-md border border-accent/40 bg-accent-soft px-2 text-xs",
                      canWrite ? "cursor-grab" : "cursor-pointer",
                    )}
                    style={{
                      left: x(start),
                      width: Math.max(dayW, (diffDays(end, start) + 1) * dayW),
                    }}
                    onMouseDown={(e) =>
                      canWrite ? drag(e, row, "move", start, end) : undefined
                    }
                    onClick={() => !canWrite && db.openRecord(row.id)}
                    title={`${start} → ${end}`}
                  >
                    <span className="truncate">{pageTitle(row.title)}</span>
                    {canWrite && (
                      <span
                        className="absolute -right-1 top-0 h-full w-2 cursor-ew-resize"
                        onMouseDown={(e) => drag(e, row, "end", start, end)}
                      />
                    )}
                  </div>
                ) : (
                  canWrite && (
                    <button
                      className="absolute top-2 text-xs text-faint hover:text-fg"
                      style={{ left: x(today) + 8 }}
                      onClick={() =>
                        db.setValue(row.id, prop.id, { start: today })
                      }
                    >
                      + Add dates
                    </button>
                  )
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
      <LoadMore
        shown={db.result?.rows.length ?? 0}
        total={db.result?.matched ?? 0}
      />
    </>
  );
}
