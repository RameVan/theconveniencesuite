"use client";
import { Fragment, useEffect, useRef, useState } from "react";

const OVERSCAN = 20;
const MIN_ROWS = 150;

/**
 * Renders only the rows near the viewport (plus spacers keeping the full height), for long tables
 * with single-line rows. Row height is measured from a rendered row. Disabled for short lists and
 * wrapped cells (variable heights), where every row is rendered.
 */
export function VirtualRows<T extends { id: string }>({ rows, render, enabled }: { rows: T[]; render: (row: T) => React.ReactNode; enabled: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const virtual = enabled && rows.length > MIN_ROWS;
  const [win, setWin] = useState({ start: 0, end: 80, h: 35 });

  useEffect(() => {
    if (!virtual) return;
    let frame = 0;
    const update = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const el = ref.current;
        if (!el) return;
        const sample = el.children[1] as HTMLElement | undefined; // first rendered row (after the top spacer)
        setWin((prev) => {
          const h = sample && sample.offsetHeight > 0 ? sample.offsetHeight : prev.h;
          const top = Math.max(0, -el.getBoundingClientRect().top);
          const start = Math.max(0, Math.floor(top / h) - OVERSCAN);
          const end = Math.min(rows.length, Math.ceil((top + window.innerHeight) / h) + OVERSCAN);
          return prev.start === start && prev.end === end && prev.h === h ? prev : { start, end, h };
        });
      });
    };
    update();
    window.addEventListener("scroll", update, true);
    window.addEventListener("resize", update);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("scroll", update, true);
      window.removeEventListener("resize", update);
    };
  }, [virtual, rows.length]);

  if (!virtual)
    return (
      <>
        {rows.map((r) => (
          <Fragment key={r.id}>{render(r)}</Fragment>
        ))}
      </>
    );
  const start = Math.min(win.start, rows.length);
  const end = Math.min(Math.max(win.end, start), rows.length);
  return (
    <div ref={ref} data-virtual-rows={rows.length}>
      <div style={{ height: start * win.h }} aria-hidden />
      {rows.slice(start, end).map((r) => (
        <Fragment key={r.id}>{render(r)}</Fragment>
      ))}
      <div style={{ height: (rows.length - end) * win.h }} aria-hidden />
    </div>
  );
}
