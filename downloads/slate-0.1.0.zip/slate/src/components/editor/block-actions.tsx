"use client";
import type { Editor } from "@tiptap/react";
import { NodeSelection, TextSelection } from "@tiptap/pm/state";
import { Type, Heading1, Heading2, Heading3, List, ListOrdered, ListTodo, Quote, Code2, Lightbulb, ChevronRight, Trash2, Copy, Palette, Link2, ArrowUp, ArrowDown } from "lucide-react";
import type { MenuItem } from "@/client/ui";
import { moveBlock, topLevelBlockAt } from "./block-drag";

const COLOR_NAMES = ["gray", "brown", "orange", "yellow", "green", "blue", "purple", "pink", "red"] as const;

/** Put the cursor inside the top-level block at `pos` (or keep the current selection when pos is null). */
/** Focus the block at `pos` with all of its text selected, so a conversion applies to every line
 * (e.g. each item of a to-do list), not just the first. */
function focusBlock(editor: Editor, pos: number | null) {
  if (pos == null) return editor.chain().focus();
  const node = editor.state.doc.nodeAt(pos);
  if (!node) return editor.chain().focus();
  return editor
    .chain()
    .focus()
    .command(({ tr }) => {
      const from = TextSelection.near(tr.doc.resolve(Math.min(pos + 1, tr.doc.content.size)), 1);
      const to = TextSelection.near(tr.doc.resolve(Math.min(pos + node.nodeSize - 1, tr.doc.content.size)), -1);
      tr.setSelection(TextSelection.between(from.$from, to.$to));
      return true;
    });
}

/** After converting a whole block, leave a cursor at its end rather than a selection. */
const collapse = (editor: Editor) => editor.commands.setTextSelection(editor.state.selection.to);

/** "Turn into" conversions. When `pos` is set they apply to that top-level block. */
export function turnIntoItems(editor: Editor, pos: number | null): MenuItem[] {
  const wrapCallout = () => {
    const node = pos != null ? editor.state.doc.nodeAt(pos) : null;
    if (pos != null && node) {
      editor
        .chain()
        .focus()
        .command(({ tr, state }) => {
          const callout = state.schema.nodes.callout.create({ icon: "💡", color: "gray" }, node.isTextblock ? state.schema.nodes.paragraph.create(null, node.content) : node);
          tr.replaceWith(pos, pos + node.nodeSize, callout);
          return true;
        })
        .run();
    } else editor.chain().focus().wrapIn("callout").run();
  };
  const wrapToggle = () => {
    const node = pos != null ? editor.state.doc.nodeAt(pos) : null;
    if (pos != null && node?.isTextblock) {
      editor
        .chain()
        .focus()
        .command(({ tr, state }) => {
          tr.replaceWith(pos, pos + node.nodeSize, state.schema.nodes.toggle.create({ open: true }, [state.schema.nodes.paragraph.create(null, node.content)]));
          return true;
        })
        .run();
    }
  };
  return [
    { label: "Turn into", heading: true },
    { label: "Text", icon: <Type size={15} />, onSelect: () => focusBlock(editor, pos).clearNodes().setParagraph().run() && collapse(editor) },
    { label: "Heading 1", icon: <Heading1 size={15} />, onSelect: () => focusBlock(editor, pos).clearNodes().setHeading({ level: 1 }).run() && collapse(editor) },
    { label: "Heading 2", icon: <Heading2 size={15} />, onSelect: () => focusBlock(editor, pos).clearNodes().setHeading({ level: 2 }).run() && collapse(editor) },
    { label: "Heading 3", icon: <Heading3 size={15} />, onSelect: () => focusBlock(editor, pos).clearNodes().setHeading({ level: 3 }).run() && collapse(editor) },
    { label: "Bulleted list", icon: <List size={15} />, onSelect: () => focusBlock(editor, pos).clearNodes().toggleBulletList().run() && collapse(editor) },
    { label: "Numbered list", icon: <ListOrdered size={15} />, onSelect: () => focusBlock(editor, pos).clearNodes().toggleOrderedList().run() && collapse(editor) },
    { label: "To-do list", icon: <ListTodo size={15} />, onSelect: () => focusBlock(editor, pos).clearNodes().toggleTaskList().run() && collapse(editor) },
    { label: "Toggle", icon: <ChevronRight size={15} />, onSelect: wrapToggle },
    { label: "Quote", icon: <Quote size={15} />, onSelect: () => focusBlock(editor, pos).clearNodes().toggleBlockquote().run() && collapse(editor) },
    { label: "Callout", icon: <Lightbulb size={15} />, onSelect: wrapCallout },
    { label: "Code", icon: <Code2 size={15} />, onSelect: () => focusBlock(editor, pos).clearNodes().setCodeBlock().run() && collapse(editor) },
  ];
}

/** Menu for the drag handle of the block at `pos`. */
export function blockMenuItems(editor: Editor, pos: number, onCopyLink?: (blockId: string) => void): MenuItem[] {
  const node = editor.state.doc.nodeAt(pos);
  if (!node) return [];
  const colorSub: MenuItem[] = [
    { label: "Text color", heading: true },
    { label: "Default", onSelect: () => selectBlock(editor, pos) && editor.chain().unsetColor().unsetHighlight().run() },
    ...COLOR_NAMES.map((c) => ({
      label: c[0].toUpperCase() + c.slice(1),
      icon: <span className={`fg-${c} text-xs font-semibold`}>A</span>,
      onSelect: () => selectBlock(editor, pos) && editor.chain().setColor(`var(--c-${c}-fg)`).run(),
    })),
    { label: "Background", heading: true },
    ...COLOR_NAMES.map((c) => ({
      label: `${c[0].toUpperCase() + c.slice(1)} background`,
      icon: <span className={`block h-4 w-4 rounded bg-c-${c}`} />,
      onSelect: () => selectBlock(editor, pos) && editor.chain().setHighlight({ color: `var(--c-${c}-bg)` }).run(),
    })),
  ];
  const index = topLevelBlockAt(editor.state.doc, pos)?.index ?? 0;
  const items: MenuItem[] = [
    {
      label: "Move up",
      icon: <ArrowUp size={15} />,
      hint: "Ctrl+Shift+↑",
      disabled: index === 0,
      onSelect: () => {
        moveBlock(editor.view, pos, -1);
        editor.commands.focus();
      },
    },
    {
      label: "Move down",
      icon: <ArrowDown size={15} />,
      hint: "Ctrl+Shift+↓",
      disabled: index >= editor.state.doc.childCount - 1,
      onSelect: () => {
        moveBlock(editor.view, pos, 1);
        editor.commands.focus();
      },
    },
    {
      label: "Delete",
      icon: <Trash2 size={15} />,
      hint: "Del",
      onSelect: () =>
        editor
          .chain()
          .focus()
          .command(({ tr }) => {
            tr.delete(pos, pos + node.nodeSize);
            return true;
          })
          .run(),
    },
    {
      label: "Duplicate",
      icon: <Copy size={15} />,
      onSelect: () =>
        editor
          .chain()
          .focus()
          .command(({ tr }) => {
            const copy = node.type.create({ ...node.attrs, id: null }, node.content, node.marks);
            tr.insert(pos + node.nodeSize, copy);
            return true;
          })
          .run(),
    },
  ];
  if (node.isTextblock || ["bulletList", "orderedList", "taskList", "blockquote", "callout", "toggle"].includes(node.type.name)) {
    items.push({ label: "Turn into", icon: <Type size={15} />, submenu: turnIntoItems(editor, pos).slice(1) });
    items.push({ label: "Color", icon: <Palette size={15} />, submenu: colorSub });
  }
  if (onCopyLink && node.attrs.id) items.push({ label: "Copy link to block", icon: <Link2 size={15} />, onSelect: () => onCopyLink(node.attrs.id) });
  return items;
}

function selectBlock(editor: Editor, pos: number) {
  const node = editor.state.doc.nodeAt(pos);
  if (!node) return false;
  editor
    .chain()
    .focus()
    .command(({ tr }) => {
      if (node.isAtom) tr.setSelection(NodeSelection.create(tr.doc, pos));
      else tr.setSelection(TextSelection.create(tr.doc, pos + 1, pos + node.nodeSize - 1));
      return true;
    })
    .run();
  return true;
}
