"use client";
import type { EditorView } from "@tiptap/pm/view";
import { TextSelection } from "@tiptap/pm/state";

/** Block being dragged with the ⋮⋮ handle, by its stable id (positions may shift during the drag). */
const dragging = new WeakMap<EditorView, string>();

export function startBlockDrag(view: EditorView, blockId: string) {
  dragging.set(view, blockId);
}

export function isBlockDragging(view: EditorView) {
  return dragging.has(view);
}

export function endBlockDrag(view: EditorView) {
  dragging.delete(view);
}

function findBlock(view: EditorView, id: string): { pos: number; size: number } | null {
  let found: { pos: number; size: number } | null = null;
  view.state.doc.forEach((node, offset) => {
    if (!found && node.attrs.id === id) found = { pos: offset, size: node.nodeSize };
  });
  return found;
}

/**
 * Handle a drop of a block dragged with the handle: move it before or after the top-level block
 * under the pointer in a single transaction. Returns false when no handle drag is in progress.
 */
export function dropBlock(view: EditorView, event: DragEvent): boolean {
  const id = dragging.get(view);
  if (!id) return false;
  dragging.delete(view);
  event.preventDefault();
  const source = findBlock(view, id);
  if (!source) return true;
  const doc = view.state.doc;
  // Target slot: before/after the top-level block under the pointer.
  const coords = view.posAtCoords({ left: event.clientX, top: event.clientY });
  let insertAt = doc.content.size;
  if (coords) {
    const $pos = doc.resolve(coords.inside >= 0 ? coords.inside : coords.pos);
    const index = Math.min($pos.index(0), doc.childCount - 1);
    let start = 0;
    for (let i = 0; i < index; i++) start += doc.child(i).nodeSize;
    const dom = view.nodeDOM(start) as HTMLElement | null;
    const rect = dom?.getBoundingClientRect();
    const after = rect ? event.clientY > rect.top + rect.height / 2 : true;
    insertAt = after ? start + doc.child(index).nodeSize : start;
  }
  if (insertAt >= source.pos && insertAt <= source.pos + source.size) return true; // dropped onto itself
  const node = doc.nodeAt(source.pos);
  if (!node) return true;
  const tr = view.state.tr.delete(source.pos, source.pos + source.size);
  const target = tr.mapping.map(insertAt);
  tr.insert(target, node);
  tr.setSelection(TextSelection.near(tr.doc.resolve(Math.min(target + 1, tr.doc.content.size))));
  view.dispatch(tr.scrollIntoView());
  view.focus();
  return true;
}

/** Top-level block index and start position for a document position (inside or at a block). */
export function topLevelBlockAt(doc: EditorView["state"]["doc"], pos: number): { index: number; start: number } | null {
  let start = 0;
  for (let i = 0; i < doc.childCount; i++) {
    const end = start + doc.child(i).nodeSize;
    if (pos >= start && pos < end) return { index: i, start };
    start = end;
  }
  return null;
}

/**
 * Swap the top-level block starting at `pos` with its neighbour above (-1) or below (1), in one
 * transaction. The cursor stays at the same place inside the moved block. Returns false at the edge.
 */
export function moveBlock(view: EditorView, pos: number, dir: -1 | 1): boolean {
  const { state } = view;
  const doc = state.doc;
  const at = topLevelBlockAt(doc, pos);
  if (!at) return false;
  const node = doc.child(at.index);
  const neighbour = doc.childCount > at.index + dir && at.index + dir >= 0 ? doc.child(at.index + dir) : null;
  if (!neighbour) return false;
  const { from, to } = state.selection;
  const inside = from >= at.start && to <= at.start + node.nodeSize;
  const tr = state.tr.delete(at.start, at.start + node.nodeSize);
  const target = dir === -1 ? at.start - neighbour.nodeSize : at.start + neighbour.nodeSize;
  tr.insert(target, node);
  const shift = target - at.start;
  const sel = inside ? TextSelection.create(tr.doc, from + shift, to + shift) : TextSelection.near(tr.doc.resolve(Math.min(target + 1, tr.doc.content.size)));
  view.dispatch(tr.setSelection(sel).scrollIntoView());
  return true;
}
