"use client";
import { useContext, useState } from "react";
import type { Editor } from "@tiptap/react";
import { BubbleMenu } from "@tiptap/react/menus";
import { NodeSelection } from "@tiptap/pm/state";
import { Bold, Italic, Underline, Strikethrough, Code, Link2, ChevronDown, Baseline, Sigma, Unlink, MessageSquareText } from "lucide-react";
import { Popover, Menu, cx, type MenuItem } from "@/client/ui";
import { turnIntoItems } from "./block-actions";
import { EditorEnvContext } from "./context";
import { addCommentMark } from "./comment-marks";
import { uid } from "@/lib/uid";

const COLOR_NAMES = ["default", "gray", "brown", "orange", "yellow", "green", "blue", "purple", "pink", "red"] as const;

export function BubbleToolbar({ editor }: { editor: Editor }) {
  const [turnAnchor, setTurnAnchor] = useState<HTMLElement | null>(null);
  const [colorAnchor, setColorAnchor] = useState<HTMLElement | null>(null);
  const [linkAnchor, setLinkAnchor] = useState<HTMLElement | null>(null);
  const [href, setHref] = useState("");
  const env = useContext(EditorEnvContext);
  const [touch] = useState(() => typeof window !== "undefined" && window.matchMedia("(hover: none) and (pointer: coarse)").matches);

  const blockLabel = () => {
    if (editor.isActive("heading", { level: 1 })) return "Heading 1";
    if (editor.isActive("heading", { level: 2 })) return "Heading 2";
    if (editor.isActive("heading", { level: 3 })) return "Heading 3";
    if (editor.isActive("taskList")) return "To-do";
    if (editor.isActive("bulletList")) return "Bulleted list";
    if (editor.isActive("orderedList")) return "Numbered list";
    if (editor.isActive("blockquote")) return "Quote";
    return "Text";
  };

  const btn = (active: boolean, onClick: () => void, icon: React.ReactNode, label: string) => (
    <button
      type="button"
      aria-label={label}
      title={label}
      aria-pressed={active}
      onMouseDown={(e) => e.preventDefault()}
      onClick={onClick}
      className={cx("flex h-8 min-w-8 items-center justify-center rounded px-1.5 hover:bg-hover", active && "text-accent")}
    >
      {icon}
    </button>
  );

  const colorItems: MenuItem[] = [
    { label: "Text color", heading: true },
    ...COLOR_NAMES.map((c) => ({
      label: c === "default" ? "Default" : c[0].toUpperCase() + c.slice(1),
      icon: <span className={cx("flex h-5 w-5 items-center justify-center rounded border border-line text-xs font-semibold", c !== "default" && `fg-${c}`)}>A</span>,
      onSelect: () => (c === "default" ? editor.chain().focus().unsetColor().run() : editor.chain().focus().setColor(`var(--c-${c}-fg)`).run()),
    })),
    { label: "Background", heading: true },
    ...COLOR_NAMES.map((c) => ({
      label: c === "default" ? "Default" : `${c[0].toUpperCase() + c.slice(1)} background`,
      icon: <span className={cx("block h-5 w-5 rounded border border-line", c !== "default" && `bg-c-${c}`)} />,
      onSelect: () => (c === "default" ? editor.chain().focus().unsetHighlight().run() : editor.chain().focus().setHighlight({ color: `var(--c-${c}-bg)` }).run()),
    })),
  ];

  return (
    <BubbleMenu
      editor={editor}
      // Phones show their own copy/paste bar above a selection: put ours below it there.
      options={{ placement: touch ? "bottom" : "top", offset: touch ? 12 : 8 }}
      shouldShow={({ editor: ed, state }) => {
        const { selection } = state;
        if (selection.empty || selection instanceof NodeSelection) return false;
        if (ed.isActive("codeBlock") || !ed.isEditable) return false;
        return state.doc.textBetween(selection.from, selection.to).length > 0;
      }}
    >
      <div className="flex max-w-[calc(100vw-16px)] items-center gap-0.5 overflow-x-auto rounded-lg border border-line bg-elevated p-1 text-sm text-fg" style={{ boxShadow: "var(--shadow)" }}>
        <button type="button" onMouseDown={(e) => e.preventDefault()} onClick={(e) => setTurnAnchor(e.currentTarget)} className="flex h-8 items-center gap-1 rounded px-2 hover:bg-hover">
          {blockLabel()} <ChevronDown size={13} className="text-faint" />
        </button>
        <div className="mx-0.5 h-5 w-px bg-line" />
        {btn(editor.isActive("bold"), () => editor.chain().focus().toggleBold().run(), <Bold size={15} />, "Bold")}
        {btn(editor.isActive("italic"), () => editor.chain().focus().toggleItalic().run(), <Italic size={15} />, "Italic")}
        {btn(editor.isActive("underline"), () => editor.chain().focus().toggleUnderline().run(), <Underline size={15} />, "Underline")}
        {btn(editor.isActive("strike"), () => editor.chain().focus().toggleStrike().run(), <Strikethrough size={15} />, "Strikethrough")}
        {btn(editor.isActive("code"), () => editor.chain().focus().toggleCode().run(), <Code size={15} />, "Inline code")}
        {btn(
          false,
          () => {
            const { from, to } = editor.state.selection;
            const text = editor.state.doc.textBetween(from, to);
            editor.chain().focus().insertContentAt({ from, to }, { type: "inlineMath", attrs: { latex: text } }).run();
          },
          <Sigma size={15} />,
          "Inline equation",
        )}
        {editor.isActive("link")
          ? btn(true, () => editor.chain().focus().extendMarkRange("link").unsetLink().run(), <Unlink size={15} />, "Remove link")
          : btn(
              false,
              () => {
                setHref("");
                setLinkAnchor(document.activeElement?.closest(".ProseMirror")?.querySelector(".ProseMirror-selectednode") as HTMLElement ?? (document.querySelector("[data-bubble-anchor]") as HTMLElement));
              },
              <Link2 size={15} />,
              "Add link",
            )}
        <span data-bubble-anchor="" />
        {env?.onComment && (
          <>
            <div className="mx-0.5 h-5 w-px bg-line" />
            <button
              type="button"
              aria-label="Comment"
              title="Comment"
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => {
                const threadId = uid();
                const anchor = addCommentMark(editor, threadId);
                if (anchor) env.onComment?.({ threadId, ...anchor });
              }}
              className="flex h-8 items-center gap-1 rounded px-2 hover:bg-hover"
            >
              <MessageSquareText size={15} /> Comment
            </button>
          </>
        )}
        <button type="button" aria-label="Color" title="Color" onMouseDown={(e) => e.preventDefault()} onClick={(e) => setColorAnchor(e.currentTarget)} className="flex h-8 items-center gap-0.5 rounded px-1.5 hover:bg-hover">
          <Baseline size={15} />
          <ChevronDown size={12} className="text-faint" />
        </button>
      </div>
      <Popover anchor={turnAnchor} open={!!turnAnchor} onClose={() => setTurnAnchor(null)}>
        <Menu items={turnIntoItems(editor, null)} onClose={() => setTurnAnchor(null)} width={220} />
      </Popover>
      <Popover anchor={colorAnchor} open={!!colorAnchor} onClose={() => setColorAnchor(null)}>
        <Menu items={colorItems} onClose={() => setColorAnchor(null)} width={220} />
      </Popover>
      <Popover anchor={linkAnchor} open={!!linkAnchor} onClose={() => setLinkAnchor(null)} placement="bottom-start">
        <form
          className="flex w-80 gap-2 p-2"
          onSubmit={(e) => {
            e.preventDefault();
            const url = href.trim();
            if (url) editor.chain().focus().extendMarkRange("link").setLink({ href: /^(https?:|mailto:|tel:|\/|#)/i.test(url) ? url : `https://${url}` }).run();
            setLinkAnchor(null);
          }}
        >
          <input autoFocus className="input h-8 flex-1" placeholder="Paste a link…" value={href} onChange={(e) => setHref(e.target.value)} />
          <button className="btn btn-primary btn-sm h-8">Link</button>
        </form>
      </Popover>
    </BubbleMenu>
  );
}
