"use client";
import type { Editor } from "@tiptap/core";

/** Thread ids of the comment anchors at (or around) a clicked DOM element, innermost first. */
export function threadIdsAt(target: EventTarget | null): string[] {
  const ids: string[] = [];
  let el = target instanceof Element ? target.closest("[data-thread]") : null;
  while (el && el.closest(".ProseMirror")) {
    const id = el.getAttribute("data-thread");
    if (id) ids.push(id);
    el = el.parentElement?.closest("[data-thread]") ?? null;
  }
  return ids;
}

/** Anchor the current text selection to a new thread. Returns the quoted text and its block. */
export function addCommentMark(editor: Editor, threadId: string): { quote: string; blockId: string | null } | null {
  const { from, to, empty } = editor.state.selection;
  const type = editor.schema.marks.comment;
  if (empty || !type) return null;
  const quote = editor.state.doc.textBetween(from, to, " ", " ").trim();
  if (!quote) return null;
  const top = editor.state.doc.resolve(from).node(1);
  editor.view.dispatch(editor.state.tr.addMark(from, to, type.create({ threadId })));
  return { quote: quote.slice(0, 1000), blockId: (top?.attrs.id as string | undefined) ?? null };
}

/** Remove a thread's anchor from the page (cancelled draft or deleted thread). */
export function removeCommentMark(editor: Editor, threadId: string) {
  const type = editor.schema.marks.comment;
  if (!type) return;
  const tr = editor.state.tr;
  editor.state.doc.descendants((node, pos) => {
    for (const m of node.marks) if (m.type === type && m.attrs.threadId === threadId) tr.removeMark(pos, pos + node.nodeSize, m);
  });
  if (tr.docChanged) editor.view.dispatch(tr);
}

/** Scroll the editor to a thread's anchor. */
export function revealCommentMark(editor: Editor, threadId: string) {
  const el = (editor.view.dom as HTMLElement).querySelector(`[data-thread="${CSS.escape(threadId)}"]`);
  el?.scrollIntoView({ block: "center", behavior: "smooth" });
  return !!el;
}
