"use client";
import { createContext, useContext } from "react";
import type { PageSummary } from "@/client/types";

export interface EditorEnv {
  workspaceId: string;
  pageId: string;
  editable: boolean;
  breadcrumbs: PageSummary[];
  pageTitle: string;
  /** Public share token when rendering a shared page (read-only). */
  shareToken?: string | null;
  navigate: (pageId: string) => void;
  hrefFor: (pageId: string) => string;
  /** Start an inline comment thread on the selection (its anchor mark is already applied). */
  onComment?: (draft: { threadId: string; quote: string; blockId: string | null }) => void;
}

export const EditorEnvContext = createContext<EditorEnv | null>(null);

export function useEditorEnv(): EditorEnv {
  const ctx = useContext(EditorEnvContext);
  if (!ctx) throw new Error("EditorEnvContext missing");
  return ctx;
}
