"use client";
import { useEffect, useRef, useState } from "react";
import type { Editor } from "@tiptap/react";
import { NodeSelection, TextSelection } from "@tiptap/pm/state";
import { GripVertical, Plus } from "lucide-react";
import { Popover, Menu, cx, useUi } from "@/client/ui";
import { blockMenuItems } from "./block-actions";
import { startBlockDrag, endBlockDrag, topLevelBlockAt } from "./block-drag";

/** Width of the strip left of the text where the handle sits (it must stay visible there). */
const HANDLE_ZONE = 64;

/** The top-level block whose vertical span contains clientY, with its DOM node. */
function blockAtY(
  editor: Editor,
  clientY: number,
): { pos: number; dom: HTMLElement } | null {
  const view = editor.view;
  let offset = 0;
  for (let i = 0; i < view.state.doc.childCount; i++) {
    const child = view.state.doc.child(i);
    const dom = view.nodeDOM(offset) as HTMLElement | null;
    if (dom && dom.nodeType === 1) {
      const r = dom.getBoundingClientRect();
      if (clientY >= r.top - 4 && clientY <= r.bottom + 4)
        return { pos: offset, dom };
    }
    offset += child.nodeSize;
  }
  return null;
}

/**
 * Hover handle to the left of each top-level block: "+" inserts a block below, "⋮⋮" drags the
 * block or opens the block menu on click. Right-clicking a block opens the same menu.
 */
export function DragHandle({
  editor,
  container,
}: {
  editor: Editor;
  container: HTMLElement | null;
}) {
  const { toast } = useUi();
  const [block, setBlock] = useState<{
    pos: number;
    top: number;
    left: number;
    height: number;
  } | null>(null);
  const [menu, setMenu] = useState<HTMLElement | null>(null);
  const [menuPos, setMenuPos] = useState<number | null>(null);
  const handleRef = useRef<HTMLDivElement>(null);
  const pointRef = useRef<HTMLDivElement>(null);
  const [point, setPoint] = useState<{ top: number; left: number } | null>(
    null,
  );
  // Touch screens have no hover: the handle follows the block with the cursor instead, and sits
  // right of the text (the left margin is too narrow on a phone). It opens the menu; no dragging.
  const [touch] = useState(
    () =>
      typeof window !== "undefined" &&
      window.matchMedia("(hover: none) and (pointer: coarse)").matches,
  );

  useEffect(() => {
    if (!container || !touch) return;
    const update = () => {
      if (menu) return;
      const view = editor.view;
      const at = topLevelBlockAt(view.state.doc, view.state.selection.from);
      const dom = at ? (view.nodeDOM(at.start) as HTMLElement | null) : null;
      if (!at || !dom || dom.nodeType !== 1) return setBlock(null);
      const r = dom.getBoundingClientRect();
      const host = container.getBoundingClientRect();
      const rootRect = (view.dom as HTMLElement).getBoundingClientRect();
      const lineHeight = Math.min(
        r.height,
        parseFloat(getComputedStyle(dom).lineHeight) || 24,
      );
      const next = {
        pos: at.start,
        top:
          r.top -
          host.top +
          container.scrollTop +
          Math.max(0, (lineHeight - 24) / 2),
        left: rootRect.right - host.left - 2,
        height: r.height,
      };
      setBlock((prev) =>
        prev &&
        prev.pos === next.pos &&
        prev.top === next.top &&
        prev.left === next.left &&
        prev.height === next.height
          ? prev
          : next,
      );
    };
    editor.on("selectionUpdate", update);
    editor.on("update", update);
    editor.on("focus", update);
    return () => {
      editor.off("selectionUpdate", update);
      editor.off("update", update);
      editor.off("focus", update);
    };
  }, [editor, container, menu, touch]);

  useEffect(() => {
    if (!container || touch) return;
    // Tracked on the whole document: the handle sits left of the text, outside the editor's box,
    // so leaving the editor on the way to the handle must not hide it.
    const onMove = (e: MouseEvent) => {
      if (menu) return;
      if (handleRef.current?.contains(e.target as Node)) return;
      const view = editor.view;
      const root = view.dom as HTMLElement;
      const rootRect = root.getBoundingClientRect();
      const inColumn =
        e.clientX >= rootRect.left - HANDLE_ZONE &&
        e.clientX <= rootRect.right + 8;
      if (
        !inColumn ||
        e.clientY < rootRect.top - 4 ||
        e.clientY > rootRect.bottom + 4
      ) {
        setBlock(null);
        return;
      }
      const found = blockAtY(editor, e.clientY);
      // Between blocks (margins), keep the current handle rather than flicker.
      if (!found) return;
      const r = found.dom.getBoundingClientRect();
      const host = container.getBoundingClientRect();
      const lineHeight = Math.min(
        r.height,
        parseFloat(getComputedStyle(found.dom).lineHeight) || 24,
      );
      const firstLine = [
        "H1",
        "H2",
        "H3",
        "P",
        "UL",
        "OL",
        "BLOCKQUOTE",
      ].includes(found.dom.tagName)
        ? lineHeight
        : 26;
      const next = {
        pos: found.pos,
        top:
          r.top -
          host.top +
          container.scrollTop +
          Math.max(0, (Math.min(firstLine, r.height) - 24) / 2) +
          (found.dom.tagName === "H1" ? 6 : 0),
        left: rootRect.left - host.left - 50,
        height: r.height,
      };
      setBlock((prev) =>
        prev &&
        prev.pos === next.pos &&
        prev.top === next.top &&
        prev.left === next.left &&
        prev.height === next.height
          ? prev
          : next,
      );
    };
    // Right-click a block for its menu. Shift/Ctrl+right-click, or right-click while text is
    // selected, keeps the browser's own menu (copy, paste, spelling). The selection is read on
    // mouse-down: browsers select the word under the pointer before the menu event.
    let hadTextSelection = false;
    const onMouseDown = (e: MouseEvent) => {
      if (e.button === 2)
        hadTextSelection =
          !editor.state.selection.empty &&
          !(editor.state.selection instanceof NodeSelection);
    };
    const onContextMenu = (e: MouseEvent) => {
      if (
        !editor.isEditable ||
        e.shiftKey ||
        e.ctrlKey ||
        e.metaKey ||
        hadTextSelection
      )
        return;
      const root = editor.view.dom as HTMLElement;
      if (!root.contains(e.target as Node)) return;
      const found = blockAtY(editor, e.clientY);
      if (!found) return;
      e.preventDefault();
      const host = container.getBoundingClientRect();
      setPoint({
        top: e.clientY - host.top + container.scrollTop,
        left: e.clientX - host.left,
      });
      setMenuPos(found.pos);
      editor.view.dispatch(
        editor.state.tr.setSelection(
          NodeSelection.create(editor.state.doc, found.pos),
        ),
      );
      requestAnimationFrame(() => setMenu(pointRef.current));
    };
    document.addEventListener("mousemove", onMove);
    container.addEventListener("mousedown", onMouseDown, true);
    container.addEventListener("contextmenu", onContextMenu);
    return () => {
      document.removeEventListener("mousemove", onMove);
      container.removeEventListener("mousedown", onMouseDown, true);
      container.removeEventListener("contextmenu", onContextMenu);
    };
  }, [editor, container, menu, touch]);

  const pointAnchor = point && (
    <div
      ref={pointRef}
      aria-hidden
      className="pointer-events-none absolute h-px w-px"
      style={{ top: point.top, left: point.left }}
    />
  );
  const blockMenu = (
    <Popover
      anchor={menu}
      open={!!menu}
      onClose={() => {
        setMenu(null);
        setPoint(null);
      }}
      placement="bottom-start"
    >
      <Menu
        items={
          menuPos != null
            ? blockMenuItems(editor, menuPos, (id) => {
                navigator.clipboard?.writeText(
                  `${location.origin}${location.pathname}#block-${id}`,
                );
                toast("Link to block copied");
              })
            : []
        }
        onClose={() => {
          setMenu(null);
          setPoint(null);
        }}
        width={230}
      />
    </Popover>
  );

  if (!editor.isEditable) return null;
  if (!block)
    return (
      <>
        {pointAnchor}
        {blockMenu}
      </>
    );

  const onDragStart = (e: React.DragEvent) => {
    const view = editor.view;
    const pos = block.pos;
    const node = view.state.doc.nodeAt(pos);
    if (!node) return;
    view.dispatch(
      view.state.tr.setSelection(NodeSelection.create(view.state.doc, pos)),
    );
    // The editor's drop handler moves the block by id (see block-drag.ts). ProseMirror's built-in
    // move deletes whatever is selected at drop time, which realtime sync can have re-mapped.
    if (typeof node.attrs.id === "string") startBlockDrag(view, node.attrs.id);
    const dom = view.nodeDOM(pos) as HTMLElement | null;
    e.dataTransfer.effectAllowed = "copyMove";
    e.dataTransfer.setData("text/plain", node.textContent);
    e.dataTransfer.setData("text/html", dom?.outerHTML ?? "");
    if (dom) e.dataTransfer.setDragImage(dom, 0, 0);
  };

  return (
    <>
      <div
        ref={handleRef}
        className={cx("block-handle visible")}
        style={{ top: block.top, left: block.left }}
      >
        {!touch && (
          <button
            className="icon-btn h-6 w-6"
            title="Click to add a block below"
            aria-label="Add block below"
            onClick={() => {
              const node = editor.state.doc.nodeAt(block.pos);
              if (!node) return;
              const after = block.pos + node.nodeSize;
              editor
                .chain()
                .insertContentAt(after, {
                  type: "paragraph",
                  content: [{ type: "text", text: "/" }],
                })
                .command(({ tr }) => {
                  tr.setSelection(TextSelection.create(tr.doc, after + 2));
                  return true;
                })
                .focus()
                .run();
            }}
          >
            <Plus size={16} />
          </button>
        )}
        <div
          role="button"
          tabIndex={0}
          aria-label={
            touch ? "Block options" : "Drag to move, click for block options"
          }
          title={touch ? "Block options" : "Drag to move · Click for options"}
          draggable={!touch}
          onDragStart={onDragStart}
          onDragEnd={() => {
            endBlockDrag(editor.view);
            setBlock(null);
          }}
          onClick={(e) => {
            setMenuPos(block.pos);
            const node = editor.state.doc.nodeAt(block.pos);
            if (node)
              editor.view.dispatch(
                editor.state.tr.setSelection(
                  NodeSelection.create(editor.state.doc, block.pos),
                ),
              );
            setMenu(e.currentTarget);
          }}
          onMouseDown={
            (e) =>
              touch &&
              e.preventDefault() /* keep the keyboard and cursor where they are */
          }
          className={cx(
            "icon-btn h-6 w-5",
            touch ? "h-8 w-6" : "cursor-grab active:cursor-grabbing",
          )}
        >
          <GripVertical size={16} />
        </div>
      </div>
      {pointAnchor}
      {blockMenu}
    </>
  );
}
