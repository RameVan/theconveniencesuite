"use client";
import { forwardRef, useCallback, useEffect, useImperativeHandle, useMemo, useRef, useState } from "react";
import { useEditor, EditorContent, type Editor as TEditor } from "@tiptap/react";
import { api, ApiError } from "@/client/api";
import { uploadFile } from "@/client/upload";
import { useUi } from "@/client/ui";
import type { PMNode } from "@/lib/blocks";
import { ySyncPluginKey } from "@tiptap/y-tiptap";
import { buildExtensions, type CollabOptions } from "./extensions";
import type { CollabSession } from "./use-collab";
import { BubbleToolbar } from "./bubble-toolbar";
import { DragHandle } from "./drag-handle";
import { dropBlock, isBlockDragging } from "./block-drag";

export type SaveStatus = "saved" | "saving" | "unsaved" | "offline" | "conflict" | "error";

export interface EditorHandle {
  focusStart: () => void;
  saveNow: () => Promise<void>;
  editor: TEditor | null;
}

interface Props {
  pageId: string;
  workspaceId: string;
  content: PMNode[];
  version: number;
  editable: boolean;
  smallText?: boolean;
  onStatus?: (s: SaveStatus) => void;
  onRemoteChange?: () => void;
  onChildPagesRemoved?: (ids: string[]) => void;
  onChildPagesRestored?: (ids: string[]) => void;
  /** Realtime session; when set, content syncs through Yjs instead of REST saves. */
  collab?: CollabSession | null;
  /** Selection to restore when this editor replaces another one (switch to realtime). */
  restoreSelection?: { from: number; to: number; focused: boolean } | null;
}

function toDoc(content: PMNode[]) {
  return { type: "doc", content: content.length ? content : [{ type: "paragraph" }] };
}

function childPageIds(editor: TEditor): Set<string> {
  const out = new Set<string>();
  editor.state.doc.forEach((n) => {
    if (n.type.name === "childPage" && n.attrs.pageId) out.add(n.attrs.pageId);
  });
  return out;
}

export const BlockEditor = forwardRef<EditorHandle, Props>(function BlockEditor(
  { pageId, workspaceId, content, version, editable, smallText, onStatus, onRemoteChange, onChildPagesRemoved, onChildPagesRestored, collab, restoreSelection },
  ref,
) {
  const { toast } = useUi();
  const versionRef = useRef(version);
  const dirty = useRef(false);
  const saving = useRef<Promise<void> | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const statusRef = useRef<SaveStatus>("saved");
  const childPages = useRef<Set<string>>(new Set());
  const removedByUs = useRef<Set<string>>(new Set());
  const [container, setContainer] = useState<HTMLDivElement | null>(null);
  const editorRef = useRef<TEditor | null>(null);

  const setStatus = useCallback(
    (s: SaveStatus) => {
      statusRef.current = s;
      onStatus?.(s);
    },
    [onStatus],
  );

  const save = useCallback(async () => {
    const editor = editorRef.current;
    if (!editor || !dirty.current || statusRef.current === "conflict") return;
    if (saving.current) {
      await saving.current;
      if (!dirty.current) return;
    }
    dirty.current = false;
    setStatus("saving");
    const blocks = (editor.getJSON().content ?? []).filter((b) => b.attrs?.id).map((b) => ({ id: b.attrs!.id as string, content: b }));
    const run = (async () => {
      try {
        const r = await api.put<{ version: number }>(`/api/pages/${pageId}/content`, { baseVersion: versionRef.current, blocks });
        versionRef.current = r.version;
        setStatus(dirty.current ? "unsaved" : "saved");
      } catch (e) {
        dirty.current = true;
        if (e instanceof ApiError && e.status === 409) {
          setStatus("conflict");
        } else if (e instanceof ApiError && e.status === 0) {
          setStatus("offline");
          timer.current = setTimeout(() => save(), 5000);
        } else {
          setStatus("error");
          toast(e instanceof Error ? `Could not save: ${e.message}` : "Could not save", "error");
        }
      }
    })();
    saving.current = run;
    await run;
    saving.current = null;
  }, [pageId, setStatus, toast]);

  const scheduleSave = useCallback(() => {
    dirty.current = true;
    if (statusRef.current !== "conflict" && statusRef.current !== "offline") setStatus("unsaved");
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => save(), 700);
  }, [save, setStatus]);

  const collabOpts: CollabOptions | null = collab ? { document: collab.doc, provider: collab.provider, user: collab.user } : null;
  const extensions = useMemo(() => buildExtensions({ onSave: () => save(), editable, collab: collabOpts }), [collab?.doc]); // eslint-disable-line react-hooks/exhaustive-deps

  const insertFiles = useCallback(
    async (editor: TEditor, files: File[], pos?: number) => {
      for (const f of files) {
        try {
          const u = await uploadFile(workspaceId, f);
          const node = u.mime.startsWith("image/")
            ? { type: "image", attrs: { src: u.url, alt: u.name } }
            : u.mime.startsWith("video/")
              ? { type: "video", attrs: { src: u.url, name: u.name } }
              : u.mime.startsWith("audio/")
                ? { type: "audio", attrs: { src: u.url, name: u.name } }
                : { type: "fileBlock", attrs: { src: u.url, name: u.name, size: u.size, mime: u.mime } };
          if (pos != null) editor.chain().insertContentAt(pos, node).run();
          else editor.chain().focus().insertContent(node).run();
        } catch (e) {
          toast(e instanceof Error ? e.message : "Upload failed", "error");
        }
      }
    },
    [workspaceId, toast],
  );

  const editor = useEditor(
    {
      extensions,
      // In realtime mode the document comes from the Yjs state.
      content: collab ? undefined : toDoc(content),
      editable,
      immediatelyRender: false,
      shouldRerenderOnTransaction: false,
      editorProps: {
        attributes: { class: "ProseMirror", spellcheck: "true", "aria-label": "Page content" },
        handlePaste: (_view, event) => {
          const files = Array.from(event.clipboardData?.files ?? []);
          if (!files.length || !editorRef.current) return false;
          event.preventDefault();
          insertFiles(editorRef.current, files);
          return true;
        },
        handleDrop: (view, event, _slice, moved) => {
          if (dropBlock(view, event as DragEvent)) return true;
          if (moved) return false;
          const files = Array.from(event.dataTransfer?.files ?? []);
          if (!files.length || !editorRef.current) return false;
          event.preventDefault();
          const coords = view.posAtCoords({ left: event.clientX, top: event.clientY });
          insertFiles(editorRef.current, files, coords?.pos);
          return true;
        },
      },
      onCreate: ({ editor }) => {
        editorRef.current = editor;
        childPages.current = childPageIds(editor);
        // Give legacy/empty blocks ids without marking the page dirty.
        editor.view.dispatch(editor.state.tr.setMeta("blockIdInit", true).setMeta("addToHistory", false));
      },
      onUpdate: ({ editor, transaction }) => {
        if (transaction.getMeta("remoteRefresh")) return;
        const fromRemote = !!(transaction.getMeta(ySyncPluginKey) as { isChangeOrigin?: boolean } | undefined)?.isChangeOrigin;
        if (collab) {
          // Remote edits only update our bookkeeping; trashing removed sub-pages is the remover's job.
          if (fromRemote) {
            childPages.current = childPageIds(editor);
            return;
          }
        } else scheduleSave();
        const now = childPageIds(editor);
        const removed = [...childPages.current].filter((id) => !now.has(id));
        const restored = [...now].filter((id) => !childPages.current.has(id) && removedByUs.current.has(id));
        childPages.current = now;
        if (removed.length) {
          removed.forEach((id) => removedByUs.current.add(id));
          onChildPagesRemoved?.(removed);
        }
        if (restored.length) {
          restored.forEach((id) => removedByUs.current.delete(id));
          onChildPagesRestored?.(restored);
        }
      },
    },
    [pageId, collab?.doc],
  );

  useEffect(() => {
    editorRef.current = editor;
  }, [editor]);

  // Keep the caret where it was when switching from the REST editor to the realtime one.
  const restored = useRef(false);
  useEffect(() => {
    if (!editor || !restoreSelection || restored.current) return;
    restored.current = true;
    const size = editor.state.doc.content.size;
    try {
      editor.commands.setTextSelection({ from: Math.min(restoreSelection.from, size), to: Math.min(restoreSelection.to, size) });
    } catch {
      /* positions no longer valid */
    }
    if (restoreSelection.focused) editor.view.focus();
  }, [editor, restoreSelection]);

  // Realtime status: connected and fully synced = saved.
  useEffect(() => {
    if (!collab) return;
    const p = collab.provider;
    let connected = true;
    let unsynced = 0;
    const update = () => setStatus(!connected ? "offline" : unsynced > 0 ? "saving" : "saved");
    const onStatusEv = ({ status }: { status: string }) => {
      connected = status === "connected";
      update();
    };
    const onUnsynced = ({ number }: { number: number }) => {
      unsynced = number;
      update();
    };
    p.on("status", onStatusEv);
    p.on("unsyncedChanges", onUnsynced);
    update();
    return () => {
      p.off("status", onStatusEv);
      p.off("unsyncedChanges", onUnsynced);
    };
  }, [collab, setStatus]);

  useEffect(() => {
    versionRef.current = version;
  }, [version]);

  useEffect(() => {
    // No "update" event: toggling editability is not an edit (it would trigger a no-op save).
    editor?.setEditable(editable, false);
  }, [editor, editable]);

  // Save before leaving the page / hiding the tab (REST mode only).
  useEffect(() => {
    if (collab) return;
    const flush = () => {
      if (!dirty.current || !editorRef.current || statusRef.current === "conflict") return;
      const blocks = (editorRef.current.getJSON().content ?? []).filter((b) => b.attrs?.id).map((b) => ({ id: b.attrs!.id, content: b }));
      dirty.current = false;
      fetch(`/api/pages/${pageId}/content`, {
        method: "POST",
        keepalive: true,
        credentials: "same-origin",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ baseVersion: versionRef.current, blocks }),
      }).catch(() => {});
    };
    const onVis = () => document.visibilityState === "hidden" && flush();
    window.addEventListener("beforeunload", flush);
    document.addEventListener("visibilitychange", onVis);
    return () => {
      window.removeEventListener("beforeunload", flush);
      document.removeEventListener("visibilitychange", onVis);
      if (timer.current) clearTimeout(timer.current);
      flush();
    };
  }, [pageId, collab]);

  // Pick up changes saved elsewhere while this editor is idle. The callback lives in a ref: the
  // parent passes a new function on every render, and restarting the timer each time meant the
  // check never ran on pages that re-render often.
  const onRemoteChangeRef = useRef(onRemoteChange);
  useEffect(() => {
    onRemoteChangeRef.current = onRemoteChange;
  });
  useEffect(() => {
    if (!editor || collab) return;
    const t = setInterval(async () => {
      if (document.visibilityState !== "visible" || dirty.current || saving.current || editor.isFocused) return;
      try {
        const v = await api.get<{ version: number }>(`/api/pages/${pageId}/version`);
        if (v.version > versionRef.current) onRemoteChangeRef.current?.();
      } catch {
        /* offline: ignore */
      }
    }, 15000);
    return () => clearInterval(t);
  }, [editor, pageId, collab]);

  // Apply new server content (after a remote change or a restore) without marking dirty.
  const lastApplied = useRef(version);
  useEffect(() => {
    if (!editor || version === lastApplied.current) return;
    lastApplied.current = version;
    if (collab) return; // Yjs already carries remote changes
    if (dirty.current) return;
    const { from, to } = editor.state.selection;
    editor.commands.setContent(toDoc(content), { emitUpdate: false });
    editor.view.dispatch(editor.state.tr.setMeta("remoteRefresh", true).setMeta("addToHistory", false));
    try {
      editor.commands.setTextSelection({ from: Math.min(from, editor.state.doc.content.size), to: Math.min(to, editor.state.doc.content.size) });
    } catch {
      /* ignore */
    }
    childPages.current = childPageIds(editor);
    setStatus("saved");
  }, [editor, version, content, setStatus, collab]);

  useImperativeHandle(
    ref,
    () => ({
      focusStart: () => {
        if (!editor) return;
        // Focus synchronously so keystrokes typed right after Enter land in the body.
        editor.commands.setTextSelection(1);
        editor.view.focus();
      },
      saveNow: () => save(),
      editor,
    }),
    [editor, save],
  );

  // Scroll to #block-<id> anchors.
  useEffect(() => {
    if (!editor) return;
    const m = /^#block-([\w-]+)$/.exec(location.hash);
    if (!m) return;
    const el = (editor.view.dom as HTMLElement).querySelector(`[data-block-id="${CSS.escape(m[1])}"]`);
    if (el) {
      el.scrollIntoView({ block: "center" });
      (el as HTMLElement).animate([{ background: "var(--accent-soft)" }, { background: "transparent" }], { duration: 2000 });
    }
  }, [editor]);

  return (
    <div
      ref={setContainer}
      className={`slate-editor relative ${smallText ? "small-text" : ""}`}
      // Handle drops of ⋮⋮ block drags here (capture phase), so node views and margins accept them too.
      onDragOverCapture={(e) => {
        if (editor && isBlockDragging(editor.view)) e.preventDefault();
      }}
      onDropCapture={(e) => {
        if (editor && dropBlock(editor.view, e.nativeEvent)) e.stopPropagation();
      }}
    >
      {editor && editable && <BubbleToolbar editor={editor} />}
      {editor && editable && <DragHandle editor={editor} container={container} />}
      <EditorContent editor={editor} />
      {!editor && (
        <div className="space-y-3 py-2">
          <div className="skeleton h-5 w-3/4" />
          <div className="skeleton h-5 w-2/3" />
          <div className="skeleton h-5 w-1/2" />
        </div>
      )}
    </div>
  );
});
