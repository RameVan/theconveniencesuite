"use client";
import { Extension, type AnyExtension } from "@tiptap/core";
import { ReactNodeViewRenderer } from "@tiptap/react";
import { Placeholder } from "@tiptap/extensions";
import { Collaboration } from "@tiptap/extension-collaboration";
import { CollaborationCaret } from "@tiptap/extension-collaboration-caret";
import type { Doc } from "yjs";
import { schemaExtensions, YDOC_FIELD } from "@/lib/editor-schema";
import {
  CalloutView,
  ToggleView,
  EquationView,
  InlineMathView,
  BookmarkView,
  EmbedView,
  MediaView,
  FileView,
  ImageView,
  TocView,
  BreadcrumbView,
  ChildPageView,
  DatabaseBlockView,
  PageLinkView,
  CodeBlockView,
} from "./node-views";
import { SlashCommand } from "./slash-menu";
import { PageMention } from "./mention";
import { moveBlock, topLevelBlockAt } from "./block-drag";

export { lowlight, BlockId } from "@/lib/editor-schema";

// React node views layered over the shared schema (which the server also uses).
const VIEWS: Record<string, Parameters<typeof ReactNodeViewRenderer>[0]> = {
  callout: CalloutView,
  toggle: ToggleView,
  equation: EquationView,
  inlineMath: InlineMathView,
  bookmark: BookmarkView,
  embed: EmbedView,
  video: MediaView,
  audio: MediaView,
  fileBlock: FileView,
  image: ImageView,
  toc: TocView,
  breadcrumb: BreadcrumbView,
  childPage: ChildPageView,
  databaseView: DatabaseBlockView,
  pageLink: PageLinkView,
  codeBlock: CodeBlockView,
};

/** Ctrl/Cmd+Shift+↑/↓ moves the block with the cursor up or down. */
const BlockMoveShortcuts = Extension.create({
  name: "blockMoveShortcuts",
  addKeyboardShortcuts() {
    const move = (dir: -1 | 1) => () => {
      const at = topLevelBlockAt(this.editor.state.doc, this.editor.state.selection.from);
      return at ? moveBlock(this.editor.view, at.start, dir) : false;
    };
    return { "Mod-Shift-ArrowUp": move(-1), "Mod-Shift-ArrowDown": move(1) };
  },
});

const SaveShortcut = Extension.create<{ onSave: () => void }>({
  name: "saveShortcut",
  addOptions() {
    return { onSave: () => {} };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-s": () => {
        this.options.onSave();
        return true;
      },
    };
  },
});

export interface CollabOptions {
  document: Doc;
  provider: unknown;
  user: { name: string; color: string };
}

export function buildExtensions(opts: { onSave: () => void; editable: boolean; collab?: CollabOptions | null }): AnyExtension[] {
  const base = schemaExtensions({ editable: opts.editable, collaborative: !!opts.collab }).map((ext) => {
    const view = VIEWS[ext.name];
    return view
      ? ext.extend({
          addNodeView() {
            return ReactNodeViewRenderer(view);
          },
        })
      : ext;
  });
  const extra: AnyExtension[] = [
    Placeholder.configure({
      includeChildren: true,
      placeholder: ({ node }) => {
        if (node.type.name === "heading") return `Heading ${node.attrs.level}`;
        if (node.type.name === "paragraph") return "Write, or press '/' for commands…";
        return "";
      },
    }),
    SlashCommand,
    PageMention,
    SaveShortcut.configure({ onSave: opts.onSave }),
    BlockMoveShortcuts,
  ];
  if (opts.collab) {
    extra.push(Collaboration.configure({ document: opts.collab.document, field: YDOC_FIELD }));
    extra.push(CollaborationCaret.configure({ provider: opts.collab.provider, user: opts.collab.user }));
  }
  return [...base, ...extra];
}
