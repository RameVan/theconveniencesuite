"use client";
import { createContext, useContext } from "react";
import useSWR from "swr";
import type { PageResponse } from "@/client/types";

export interface PageInfo {
  title: string;
  icon: string | null;
  kind: "page" | "database";
}

/** Known page titles (sidebar tree + current page children), keyed by id. */
export const PageLookupContext = createContext<{ pages: Map<string, PageInfo>; offline?: boolean }>({ pages: new Map() });

/** Title/icon for a referenced page: from the known map, else fetched (undefined while loading, null if inaccessible). */
export function usePageLookup(id: string | null): PageInfo | null | undefined {
  const { pages, offline } = useContext(PageLookupContext);
  const known = id ? pages.get(id) : undefined;
  const { data, error } = useSWR<PageResponse>(!known && id && !offline ? `/api/pages/${id}` : null, { revalidateOnFocus: false });
  if (!id) return null;
  if (known) return known;
  if (error || offline) return null;
  if (data) return { title: data.page.title, icon: data.page.icon, kind: data.page.kind };
  return undefined;
}
