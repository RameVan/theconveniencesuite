"use client";
import { Extension } from "@tiptap/core";
import Suggestion, { type SuggestionProps, type SuggestionKeyDownProps } from "@tiptap/suggestion";
import { PluginKey } from "@tiptap/pm/state";
import { Fragment, forwardRef, useEffect, useImperativeHandle, useState } from "react";
import { api } from "@/client/api";
import { cx } from "@/client/ui";
import { PageIcon, pageTitle } from "../page-icon";
import { suggestionRenderer, type MenuRef } from "./slash-menu";

interface PageHit {
  id: string;
  title: string;
  icon: string | null;
  kind: "page" | "database";
  path: string[];
}

interface PersonHit {
  id: string;
  kind: "person";
  name: string;
  email: string;
}

type Hit = PageHit | PersonHit;

const memberCache = new Map<string, { at: number; list: Promise<PersonHit[]> }>();
/** Workspace members for @-mentions (cached for a minute). */
function members(workspaceId: string): Promise<PersonHit[]> {
  const hit = memberCache.get(workspaceId);
  if (hit && Date.now() - hit.at < 60_000) return hit.list;
  const list = api
    .get<{ members: { id: string; name: string; email: string }[] }>(`/api/workspaces/${workspaceId}/members`)
    .then((r) => r.members.map((m) => ({ id: m.id, kind: "person" as const, name: m.name, email: m.email })))
    .catch(() => []);
  memberCache.set(workspaceId, { at: Date.now(), list });
  return list;
}

/** Workspace used by @-mention searches; set by the page view. */
export const mentionScope: { workspaceId: string | null } = { workspaceId: null };

const MentionList = forwardRef<MenuRef, SuggestionProps<Hit>>(function MentionList(props, ref) {
  const [index, setIndex] = useState(0);
  useEffect(() => setIndex(0), [props.items]);
  useImperativeHandle(ref, () => ({
    onKeyDown: ({ event }: SuggestionKeyDownProps) => {
      if (event.key === "ArrowDown") {
        setIndex((i) => (i + 1) % Math.max(1, props.items.length));
        return true;
      }
      if (event.key === "ArrowUp") {
        setIndex((i) => (i - 1 + props.items.length) % Math.max(1, props.items.length));
        return true;
      }
      if (event.key === "Enter" || event.key === "Tab") {
        const item = props.items[index];
        if (item) props.command(item);
        return true;
      }
      return false;
    },
  }));
  return (
    <div className="max-h-72 w-80 overflow-y-auto rounded-lg border border-line bg-elevated py-1" style={{ boxShadow: "var(--shadow)" }}>
      {!props.items.length && <div className="px-3 py-2 text-sm text-muted">{props.query ? "No people or pages found" : "Type to search people and pages"}</div>}
      {props.items.map((p, i) => (
        <Fragment key={p.id}>
          {(i === 0 || (props.items[i - 1].kind === "person") !== (p.kind === "person")) && (
            <div className="px-3 pb-1 pt-1 text-xs font-medium text-muted">{p.kind === "person" ? "People" : "Link to page"}</div>
          )}
          {p.kind === "person" ? (
            <button
              className={cx("mx-1 flex w-[calc(100%-8px)] items-center gap-2 rounded px-2 py-1.5 text-left text-sm", i === index && "bg-hover")}
              onMouseEnter={() => setIndex(i)}
              onMouseDown={(e) => {
                e.preventDefault();
                props.command(p);
              }}
            >
              <span className="flex h-5 w-5 flex-none items-center justify-center rounded-full bg-subtle text-[10px] font-medium">{p.name.slice(0, 1).toUpperCase()}</span>
              <span className="min-w-0 truncate">{p.name}</span>
              <span className="ml-auto truncate text-xs text-faint">{p.email}</span>
            </button>
          ) : (
        <button
          className={cx("mx-1 flex w-[calc(100%-8px)] items-center gap-2 rounded px-2 py-1.5 text-left text-sm", i === index && "bg-hover")}
          onMouseEnter={() => setIndex(i)}
          onMouseDown={(e) => {
            e.preventDefault();
            props.command(p);
          }}
        >
          <PageIcon icon={p.icon} kind={p.kind} />
          <span className="min-w-0">
            <span className="block truncate">{pageTitle(p.title)}</span>
            {p.path.length > 0 && <span className="block truncate text-xs text-faint">{p.path.join(" / ")}</span>}
          </span>
        </button>
          )}
        </Fragment>
      ))}
    </div>
  );
});

export const PageMention = Extension.create({
  name: "pageMention",
  addProseMirrorPlugins() {
    return [
      Suggestion<Hit>({
        editor: this.editor,
        pluginKey: new PluginKey("pageMention"),
        char: "@",
        allowSpaces: true,
        items: async ({ query }) => {
          const wsId = mentionScope.workspaceId;
          if (!wsId) return [];
          const q = query.trim().toLowerCase();
          const [people, pages] = await Promise.all([
            members(wsId).then((list) => list.filter((m) => !q || m.name.toLowerCase().includes(q) || m.email.toLowerCase().startsWith(q)).slice(0, q ? 5 : 3)),
            api
              .get<{ results: PageHit[] }>(`/api/search?workspaceId=${wsId}&limit=8&q=${encodeURIComponent(query)}`)
              .then((r) => r.results)
              .catch(() => [] as PageHit[]),
          ]);
          return [...people, ...pages];
        },
        command: ({ editor, range, props }) => {
          const node = props.kind === "person" ? { type: "mention", attrs: { userId: props.id, label: props.name } } : { type: "pageLink", attrs: { pageId: props.id, title: props.title } };
          editor
            .chain()
            .focus()
            .deleteRange(range)
            .insertContent([node, { type: "text", text: " " }])
            .run();
        },
        render: suggestionRenderer(MentionList),
      }),
    ];
  },
});
