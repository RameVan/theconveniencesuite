"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { NodeViewWrapper, NodeViewContent, type NodeViewProps } from "@tiptap/react";
import katex from "katex";
import Link from "next/link";
import { ChevronRight, Link2, Image as ImageIcon, Paperclip, Film, Music, Globe, Copy, Check, Download, Sigma, Database as DbIcon, Upload, ExternalLink } from "lucide-react";
import { api, errorMessage } from "@/client/api";
import { uploadFile, pickFile, formatBytes } from "@/client/upload";
import { Popover, useUi, cx, Spinner } from "@/client/ui";
import { EmojiPicker } from "../emoji-picker";
import { PageIcon, pageTitle } from "../page-icon";
import { useEditorEnv } from "./context";
import { usePageLookup } from "./lookup";
import { DatabaseView } from "../database/database-view";
import { COLORS } from "@/lib/db-types";
import type { ViewDef } from "@/lib/db-types";
import { uid } from "@/lib/uid";

function fileUrl(src: string | null | undefined, share?: string | null) {
  if (!src) return "";
  if (share && src.startsWith("/api/files/")) return `${src}${src.includes("?") ? "&" : "?"}share=${encodeURIComponent(share)}`;
  return src;
}

// ------------------------------------------------------------------ Callout

export function CalloutView({ node, updateAttributes, editor }: NodeViewProps) {
  const [anchor, setAnchor] = useState<HTMLElement | null>(null);
  const color = String(node.attrs.color ?? "gray");
  return (
    <NodeViewWrapper className={cx("my-1 flex gap-2 rounded-md px-4 py-3", `bg-c-${color}`)} data-type="callout">
      <button contentEditable={false} className="mt-0.5 h-7 w-7 flex-none rounded text-xl leading-none hover:bg-hover" onClick={(e) => editor.isEditable && setAnchor(e.currentTarget)} aria-label="Change callout icon">
        {node.attrs.icon || "💡"}
      </button>
      <NodeViewContent className="min-w-0 flex-1 [&_p]:!py-0.5" />
      <Popover anchor={anchor} open={!!anchor} onClose={() => setAnchor(null)}>
        <div contentEditable={false}>
          <EmojiPicker
            onSelect={(e) => {
              updateAttributes({ icon: e });
              setAnchor(null);
            }}
          />
          <div className="flex flex-wrap gap-1 border-t border-line p-2">
            {COLORS.map((c) => (
              <button
                key={c}
                title={c}
                onClick={() => updateAttributes({ color: c === "default" ? "gray" : c })}
                className={cx("h-6 w-6 rounded border border-line", `bg-c-${c === "default" ? "default" : c}`, color === c && "ring-2 ring-accent")}
              />
            ))}
          </div>
        </div>
      </Popover>
    </NodeViewWrapper>
  );
}

// ------------------------------------------------------------------ Toggle

export function ToggleView({ node, updateAttributes }: NodeViewProps) {
  const open = node.attrs.open !== false;
  return (
    <NodeViewWrapper className="toggle-block my-0.5 flex gap-1" data-toggle={open ? "open" : "closed"}>
      <button
        contentEditable={false}
        className="mt-[5px] flex h-6 w-6 flex-none items-center justify-center rounded hover:bg-hover"
        onClick={() => updateAttributes({ open: !open })}
        aria-label={open ? "Collapse" : "Expand"}
        aria-expanded={open}
      >
        <ChevronRight size={16} className={cx("transition-transform", open && "rotate-90")} />
      </button>
      <NodeViewContent className="toggle-body min-w-0 flex-1" />
    </NodeViewWrapper>
  );
}

// ------------------------------------------------------------------ Equations

function renderTex(latex: string, display: boolean) {
  try {
    return katex.renderToString(latex, { displayMode: display, throwOnError: false, trust: false, strict: "ignore" });
  } catch {
    return "";
  }
}

function TexEditor({ value, onDone, anchor, onClose }: { value: string; onDone: (v: string) => void; anchor: HTMLElement | null; onClose: () => void }) {
  const [v, setV] = useState(value);
  return (
    <Popover anchor={anchor} open={!!anchor} onClose={() => (onDone(v), onClose())}>
      <div className="w-[360px] p-2" contentEditable={false}>
        <textarea
          autoFocus
          className="input h-24 w-full font-mono text-sm"
          value={v}
          placeholder="E = mc^2"
          onChange={(e) => setV(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              onDone(v);
              onClose();
            }
          }}
        />
        <div className="mt-1 flex items-center justify-between text-xs text-muted">
          <span>KaTeX syntax · ⇧↵ for a new line</span>
          <button
            className="btn btn-primary btn-sm"
            onClick={() => {
              onDone(v);
              onClose();
            }}
          >
            Done
          </button>
        </div>
      </div>
    </Popover>
  );
}

export function EquationView({ node, updateAttributes, editor, selected }: NodeViewProps) {
  const [anchor, setAnchor] = useState<HTMLElement | null>(null);
  const latex = String(node.attrs.latex ?? "");
  const html = useMemo(() => renderTex(latex, true), [latex]);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!latex && editor.isEditable && selected && ref.current) setAnchor(ref.current);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <NodeViewWrapper>
      <div
        ref={ref}
        contentEditable={false}
        className={cx("my-1 cursor-pointer overflow-x-auto rounded-md px-2 py-3 text-center hover:bg-hover", selected && "bg-accent-soft")}
        onClick={(e) => editor.isEditable && setAnchor(e.currentTarget)}
      >
        {latex ? (
          <span dangerouslySetInnerHTML={{ __html: html }} />
        ) : (
          <span className="flex items-center justify-center gap-2 text-sm text-muted">
            <Sigma size={16} /> Add a TeX equation
          </span>
        )}
      </div>
      {anchor && <TexEditor value={latex} anchor={anchor} onClose={() => setAnchor(null)} onDone={(v) => updateAttributes({ latex: v })} />}
    </NodeViewWrapper>
  );
}

export function InlineMathView({ node, updateAttributes, editor }: NodeViewProps) {
  const [anchor, setAnchor] = useState<HTMLElement | null>(null);
  const latex = String(node.attrs.latex ?? "");
  const html = useMemo(() => renderTex(latex, false), [latex]);
  return (
    <NodeViewWrapper as="span" className="inline-math" onClick={(e: React.MouseEvent<HTMLElement>) => editor.isEditable && setAnchor(e.currentTarget)}>
      {latex ? <span dangerouslySetInnerHTML={{ __html: html }} /> : <span className="text-muted">ƒ(x)</span>}
      {anchor && <TexEditor value={latex} anchor={anchor} onClose={() => setAnchor(null)} onDone={(v) => updateAttributes({ latex: v })} />}
    </NodeViewWrapper>
  );
}

// ------------------------------------------------------------------ URL input shared by bookmark/embed/media

function UrlPrompt({ icon, placeholder, onSubmit, onUpload, accept, busy }: { icon: React.ReactNode; placeholder: string; onSubmit: (url: string) => void; onUpload?: (f: File) => void; accept?: string; busy?: boolean }) {
  const [url, setUrl] = useState("");
  const env = useEditorEnv();
  if (!env.editable) return <div className="my-1 rounded-md bg-subtle px-3 py-3 text-sm text-muted">Empty block</div>;
  return (
    <div contentEditable={false} className="my-1 flex flex-wrap items-center gap-2 rounded-md bg-subtle px-3 py-2.5 text-sm">
      <span className="text-muted">{icon}</span>
      <form
        className="flex min-w-[200px] flex-1 gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          if (url.trim()) onSubmit(url.trim());
        }}
      >
        <input className="input h-7 flex-1" placeholder={placeholder} value={url} onChange={(e) => setUrl(e.target.value)} autoFocus />
        <button className="btn btn-sm" disabled={busy || !url.trim()}>
          {busy ? <Spinner size={12} /> : "Embed"}
        </button>
      </form>
      {onUpload && (
        <button
          className="btn btn-sm"
          disabled={busy}
          onClick={async () => {
            const f = await pickFile(accept);
            if (f) onUpload(f);
          }}
        >
          <Upload size={13} /> Upload
        </button>
      )}
    </div>
  );
}

function useUploader(onDone: (u: { url: string; name: string; size: number; mime: string }) => void) {
  const env = useEditorEnv();
  const { toast } = useUi();
  const [busy, setBusy] = useState(false);
  const upload = async (f: File) => {
    setBusy(true);
    try {
      const u = await uploadFile(env.workspaceId, f);
      onDone(u);
    } catch (e) {
      toast(errorMessage(e), "error");
    } finally {
      setBusy(false);
    }
  };
  return { busy, upload };
}

// ------------------------------------------------------------------ Bookmark

export function BookmarkView({ node, updateAttributes, selected }: NodeViewProps) {
  const { toast } = useUi();
  const [busy, setBusy] = useState(false);
  const a = node.attrs as { url: string | null; title: string | null; description: string | null; image: string | null; icon: string | null };
  if (!a.url)
    return (
      <NodeViewWrapper>
        <UrlPrompt
          icon={<Link2 size={16} />}
          placeholder="Paste a link to create a bookmark"
          busy={busy}
          onSubmit={async (url) => {
            setBusy(true);
            const full = /^https?:\/\//i.test(url) ? url : `https://${url}`;
            try {
              const r = await api.get<{ url: string; title: string; description: string | null; image: string | null; icon: string | null }>(`/api/unfurl?url=${encodeURIComponent(full)}`);
              updateAttributes(r);
            } catch (e) {
              updateAttributes({ url: full, title: full });
              toast(errorMessage(e), "error");
            } finally {
              setBusy(false);
            }
          }}
        />
      </NodeViewWrapper>
    );
  return (
    <NodeViewWrapper>
      <a href={a.url} target="_blank" rel="noopener noreferrer nofollow" contentEditable={false} className={cx("my-1 flex overflow-hidden rounded-md border border-line hover:bg-hover", selected && "ring-2 ring-accent-soft")}>
        <div className="min-w-0 flex-1 p-3">
          <div className="truncate text-sm font-medium">{a.title || a.url}</div>
          {a.description && <div className="mt-1 line-clamp-2 text-xs text-muted">{a.description}</div>}
          <div className="mt-2 flex items-center gap-1.5 text-xs text-muted">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            {a.icon && <img src={a.icon} alt="" width={14} height={14} onError={(e) => ((e.target as HTMLImageElement).style.display = "none")} />}
            <span className="truncate">{a.url}</span>
          </div>
        </div>
        {a.image && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={a.image} alt="" className="hidden h-auto w-48 flex-none object-cover sm:block" onError={(e) => ((e.target as HTMLImageElement).style.display = "none")} />
        )}
      </a>
    </NodeViewWrapper>
  );
}

// ------------------------------------------------------------------ Embed

export function toEmbedUrl(raw: string): string | null {
  let u: URL;
  try {
    u = new URL(raw);
  } catch {
    return null;
  }
  const host = u.hostname.replace(/^www\./, "");
  if (host === "youtube.com" || host === "m.youtube.com") {
    const id = u.searchParams.get("v") ?? (u.pathname.startsWith("/shorts/") ? u.pathname.split("/")[2] : null);
    return id ? `https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}` : null;
  }
  if (host === "youtu.be") return `https://www.youtube-nocookie.com/embed/${encodeURIComponent(u.pathname.slice(1))}`;
  if (host === "vimeo.com") return `https://player.vimeo.com/video/${encodeURIComponent(u.pathname.split("/").filter(Boolean)[0] ?? "")}`;
  if (host === "loom.com") return `https://www.loom.com/embed/${encodeURIComponent(u.pathname.split("/").pop() ?? "")}`;
  if (host === "figma.com") return `https://www.figma.com/embed?embed_host=slate&url=${encodeURIComponent(raw)}`;
  if (host === "codepen.io") return raw.replace("/pen/", "/embed/");
  if (host === "open.spotify.com") return `https://open.spotify.com/embed${u.pathname}`;
  if (host === "google.com" && u.pathname.startsWith("/maps")) return `https://maps.google.com/maps?q=${encodeURIComponent(u.searchParams.get("q") ?? "")}&output=embed`;
  if (host === "docs.google.com") return raw.replace(/\/edit.*$/, "/preview");
  return null;
}

export function EmbedView({ node, updateAttributes }: NodeViewProps) {
  const url = node.attrs.url as string | null;
  if (!url)
    return (
      <NodeViewWrapper>
        <UrlPrompt icon={<Globe size={16} />} placeholder="Paste a YouTube, Vimeo, Loom, Figma, CodePen or Google Docs link" onSubmit={(u) => updateAttributes({ url: /^https?:/i.test(u) ? u : `https://${u}` })} />
      </NodeViewWrapper>
    );
  const embed = toEmbedUrl(url);
  return (
    <NodeViewWrapper>
      <div contentEditable={false} className="my-1">
        {embed ? (
          <div className="relative w-full overflow-hidden rounded-md border border-line bg-subtle" style={{ paddingTop: "56.25%" }}>
            <iframe
              src={embed}
              className="absolute inset-0 h-full w-full"
              sandbox="allow-scripts allow-same-origin allow-popups allow-presentation allow-forms"
              allow="fullscreen; picture-in-picture"
              referrerPolicy="strict-origin-when-cross-origin"
              loading="lazy"
              title="Embedded content"
            />
          </div>
        ) : (
          <a href={url} target="_blank" rel="noopener noreferrer nofollow" className="flex items-center gap-2 rounded-md border border-line px-3 py-2.5 text-sm hover:bg-hover">
            <Globe size={16} className="text-muted" /> <span className="truncate">{url}</span> <ExternalLink size={13} className="ml-auto text-faint" />
          </a>
        )}
      </div>
    </NodeViewWrapper>
  );
}

// ------------------------------------------------------------------ Video / audio

export function MediaView({ node, updateAttributes }: NodeViewProps) {
  const env = useEditorEnv();
  const isVideo = node.type.name === "video";
  const { busy, upload } = useUploader((u) => updateAttributes({ src: u.url, name: u.name }));
  const src = node.attrs.src as string | null;
  if (!src)
    return (
      <NodeViewWrapper>
        <UrlPrompt
          icon={isVideo ? <Film size={16} /> : <Music size={16} />}
          placeholder={isVideo ? "Paste a video link (YouTube links embed too)" : "Paste an audio file link"}
          accept={isVideo ? "video/*" : "audio/*"}
          busy={busy}
          onUpload={upload}
          onSubmit={(u) => {
            const embed = isVideo ? toEmbedUrl(u) : null;
            updateAttributes({ src: embed ?? u, name: u });
          }}
        />
      </NodeViewWrapper>
    );
  const isIframe = /youtube-nocookie|player\.vimeo|loom\.com\/embed/.test(src);
  return (
    <NodeViewWrapper>
      <div contentEditable={false} className="my-1">
        {isVideo && isIframe ? (
          <div className="relative w-full overflow-hidden rounded-md" style={{ paddingTop: "56.25%" }}>
            <iframe src={src} className="absolute inset-0 h-full w-full" sandbox="allow-scripts allow-same-origin allow-presentation" allow="fullscreen" title="Video" loading="lazy" />
          </div>
        ) : isVideo ? (
          <video controls src={fileUrl(src, env.shareToken)} className="w-full rounded-md" preload="metadata" />
        ) : (
          <audio controls src={fileUrl(src, env.shareToken)} className="w-full" preload="metadata" />
        )}
      </div>
    </NodeViewWrapper>
  );
}

// ------------------------------------------------------------------ File

export function FileView({ node, updateAttributes, selected }: NodeViewProps) {
  const env = useEditorEnv();
  const { busy, upload } = useUploader((u) => updateAttributes({ src: u.url, name: u.name, size: u.size, mime: u.mime }));
  const a = node.attrs as { src: string | null; name: string | null; size: number | null };
  if (!a.src)
    return (
      <NodeViewWrapper>
        <UrlPrompt icon={<Paperclip size={16} />} placeholder="Paste a file link, or upload" busy={busy} onUpload={upload} onSubmit={(u) => updateAttributes({ src: u, name: u.split("/").pop() || u })} />
      </NodeViewWrapper>
    );
  const href = fileUrl(a.src, env.shareToken);
  return (
    <NodeViewWrapper>
      <div contentEditable={false} className={cx("my-1 flex items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-hover", selected && "bg-accent-soft")}>
        <Paperclip size={16} className="text-muted" />
        <a href={href} target="_blank" rel="noopener noreferrer" className="truncate">
          {a.name || "File"}
        </a>
        <span className="text-xs text-faint">{formatBytes(a.size)}</span>
        <a href={`${href}${href.includes("?") ? "&" : "?"}download=1`} className="icon-btn ml-auto" title="Download" aria-label="Download">
          <Download size={14} />
        </a>
      </div>
    </NodeViewWrapper>
  );
}

// ------------------------------------------------------------------ Image

export function ImageView({ node, updateAttributes, selected, editor }: NodeViewProps) {
  const env = useEditorEnv();
  const { busy, upload } = useUploader((u) => updateAttributes({ src: u.url, alt: u.name }));
  const a = node.attrs as { src: string | null; alt: string | null; caption: string | null; width: number | null };
  const imgRef = useRef<HTMLImageElement>(null);
  if (!a.src)
    return (
      <NodeViewWrapper>
        <div
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            const f = e.dataTransfer.files?.[0];
            if (f && f.type.startsWith("image/")) {
              e.preventDefault();
              e.stopPropagation();
              upload(f);
            }
          }}
        >
          <UrlPrompt icon={<ImageIcon size={16} />} placeholder="Paste an image link, upload, or drop an image" accept="image/*" busy={busy} onUpload={upload} onSubmit={(u) => updateAttributes({ src: u })} />
        </div>
      </NodeViewWrapper>
    );
  const startResize = (e: React.MouseEvent, side: 1 | -1) => {
    e.preventDefault();
    const startX = e.clientX;
    const startW = imgRef.current?.offsetWidth ?? 400;
    const max = imgRef.current?.parentElement?.parentElement?.offsetWidth ?? 900;
    const onMove = (ev: MouseEvent) => {
      const w = Math.max(80, Math.min(max, startW + (ev.clientX - startX) * side * 2));
      if (imgRef.current) imgRef.current.style.width = `${w}px`;
    };
    const onUp = () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
      updateAttributes({ width: imgRef.current?.offsetWidth ?? null });
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  };
  return (
    <NodeViewWrapper>
      <figure className="my-2 flex flex-col items-center" contentEditable={false}>
        <div className={cx("group relative max-w-full rounded", selected && "ring-2 ring-accent")}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img ref={imgRef} src={fileUrl(a.src, env.shareToken)} alt={a.alt ?? ""} style={{ width: a.width ? `${a.width}px` : undefined }} className="block max-w-full rounded" draggable={false} />
          {editor.isEditable && (
            <>
              <div className="absolute inset-y-0 left-1 my-auto h-12 w-1.5 cursor-ew-resize rounded-full bg-black/40 opacity-0 group-hover:opacity-100" onMouseDown={(e) => startResize(e, -1)} />
              <div className="absolute inset-y-0 right-1 my-auto h-12 w-1.5 cursor-ew-resize rounded-full bg-black/40 opacity-0 group-hover:opacity-100" onMouseDown={(e) => startResize(e, 1)} />
            </>
          )}
        </div>
        {(editor.isEditable || a.caption) && (
          <input
            className="mt-1 w-full bg-transparent text-center text-sm text-muted outline-none placeholder:text-faint"
            placeholder={editor.isEditable ? "Add a caption…" : ""}
            readOnly={!editor.isEditable}
            value={a.caption ?? ""}
            onChange={(e) => updateAttributes({ caption: e.target.value || null })}
            onKeyDown={(e) => e.stopPropagation()}
          />
        )}
      </figure>
    </NodeViewWrapper>
  );
}

// ------------------------------------------------------------------ Table of contents

export function TocView({ editor }: NodeViewProps) {
  const [items, setItems] = useState<{ level: number; text: string; pos: number }[]>([]);
  useEffect(() => {
    const compute = () => {
      const out: { level: number; text: string; pos: number }[] = [];
      editor.state.doc.descendants((n, pos) => {
        if (n.type.name === "heading") out.push({ level: n.attrs.level, text: n.textContent, pos });
        return n.type.name !== "heading";
      });
      setItems(out);
    };
    compute();
    editor.on("update", compute);
    return () => {
      editor.off("update", compute);
    };
  }, [editor]);
  return (
    <NodeViewWrapper>
      <div contentEditable={false} className="my-1 rounded-md py-1">
        {!items.length && <p className="text-sm text-muted">Add headings to create a table of contents.</p>}
        {items.map((h, i) => (
          <button
            key={i}
            className="block w-full truncate rounded px-1 py-0.5 text-left text-sm text-muted underline decoration-line underline-offset-4 hover:bg-hover hover:text-fg"
            style={{ paddingLeft: 4 + (h.level - 1) * 18 }}
            onClick={() => {
              const dom = editor.view.nodeDOM(h.pos) as HTMLElement | null;
              dom?.scrollIntoView({ behavior: "smooth", block: "start" });
            }}
          >
            {h.text || "Untitled heading"}
          </button>
        ))}
      </div>
    </NodeViewWrapper>
  );
}

// ------------------------------------------------------------------ Breadcrumb

export function BreadcrumbView() {
  const env = useEditorEnv();
  return (
    <NodeViewWrapper>
      <div contentEditable={false} className="my-1 flex flex-wrap items-center gap-1 text-sm text-muted">
        {env.breadcrumbs.map((b) => (
          <span key={b.id} className="flex items-center gap-1">
            <Link href={env.hrefFor(b.id)} className="flex items-center gap-1 rounded px-1 hover:bg-hover">
              <PageIcon icon={b.icon} kind={b.kind} size={14} /> {pageTitle(b.title)}
            </Link>
            <span className="text-faint">/</span>
          </span>
        ))}
        <span className="px-1 text-fg">{pageTitle(env.pageTitle)}</span>
      </div>
    </NodeViewWrapper>
  );
}

// ------------------------------------------------------------------ Child page / page link

export function ChildPageView({ node, selected }: NodeViewProps) {
  const env = useEditorEnv();
  const info = usePageLookup(node.attrs.pageId as string | null);
  if (!node.attrs.pageId) return <NodeViewWrapper />;
  return (
    <NodeViewWrapper>
      <Link
        href={env.hrefFor(node.attrs.pageId)}
        contentEditable={false}
        draggable={false}
        className={cx("my-0.5 flex items-center gap-2 rounded px-1 py-1 hover:bg-hover", selected && "bg-accent-soft")}
      >
        <PageIcon icon={info?.icon} kind={info?.kind ?? "page"} size={18} />
        <span className="border-b border-line-strong font-medium leading-tight">{info ? pageTitle(info.title) : info === null ? "Page not available" : "…"}</span>
      </Link>
    </NodeViewWrapper>
  );
}

export function PageLinkView({ node }: NodeViewProps) {
  const env = useEditorEnv();
  const info = usePageLookup(node.attrs.pageId as string | null);
  const title = info ? pageTitle(info.title) : (node.attrs.title as string) || "Untitled";
  return (
    <NodeViewWrapper as="span">
      <Link href={env.hrefFor(node.attrs.pageId)} className="page-link inline-flex items-baseline gap-1" contentEditable={false} draggable={false}>
        <PageIcon icon={info?.icon} kind={info?.kind ?? "page"} size={14} className="relative top-[2px]" />
        {title}
      </Link>
    </NodeViewWrapper>
  );
}

// ------------------------------------------------------------------ Inline database / linked view

export function DatabaseBlockView({ node, updateAttributes, editor }: NodeViewProps) {
  const env = useEditorEnv();
  const databaseId = node.attrs.databaseId as string | null;
  const ownViews = Array.isArray(node.attrs.views) && node.attrs.views.length ? (node.attrs.views as ViewDef[]) : null;
  if (!databaseId)
    return (
      <NodeViewWrapper>
        <DatabasePicker
          onPick={async (id) => {
            // A linked view starts with copies of the database's views and is then independent:
            // filters, sorts and layouts set here don't change the database or other pages.
            const meta = await api.get<{ views: ViewDef[] }>(`/api/databases/${id}`).catch(() => null);
            const views = (meta?.views ?? []).map((v) => ({ ...v, id: uid() }));
            updateAttributes({ databaseId: id, views: views.length ? views : null, viewId: views[0]?.id ?? null });
          }}
        />
      </NodeViewWrapper>
    );
  return (
    <NodeViewWrapper>
      <div contentEditable={false} className="my-2" onKeyDown={(e) => e.stopPropagation()} onPaste={(e) => e.stopPropagation()}>
        <DatabaseView
          databaseId={databaseId}
          inline
          viewId={(node.attrs.viewId as string) ?? null}
          onViewChange={(id) => editor.isEditable && updateAttributes({ viewId: id })}
          ownViews={ownViews}
          onOwnViewsChange={editor.isEditable ? (views) => updateAttributes({ views }) : undefined}
          onUseOwnViews={editor.isEditable ? (views) => updateAttributes({ views: views.map((v) => ({ ...v })) }) : undefined}
          block={node.attrs.id ? { pageId: env.pageId, blockId: node.attrs.id as string } : null}
          shareToken={env.shareToken}
        />
      </div>
    </NodeViewWrapper>
  );
}

function DatabasePicker({ onPick }: { onPick: (id: string) => void }) {
  const env = useEditorEnv();
  const [q, setQ] = useState("");
  const [list, setList] = useState<{ id: string; title: string; icon: string | null }[] | null>(null);
  useEffect(() => {
    api.get<{ databases: { id: string; title: string; icon: string | null }[] }>(`/api/workspaces/${env.workspaceId}/databases`).then((r) => setList(r.databases)).catch(() => setList([]));
  }, [env.workspaceId]);
  return (
    <div contentEditable={false} className="my-1 rounded-md border border-line p-2">
      <div className="mb-2 flex items-center gap-2 text-sm text-muted">
        <DbIcon size={15} /> Choose a database to show a linked view of
      </div>
      <input className="input mb-2 h-7 w-full" placeholder="Search databases…" value={q} onChange={(e) => setQ(e.target.value)} autoFocus />
      <div className="max-h-56 overflow-y-auto">
        {!list && <Spinner />}
        {list
          ?.filter((d) => d.title.toLowerCase().includes(q.toLowerCase()))
          .map((d) => (
            <button key={d.id} className="flex w-full items-center gap-2 rounded px-2 py-1 text-left text-sm hover:bg-hover" onClick={() => onPick(d.id)}>
              <PageIcon icon={d.icon} kind="database" /> {pageTitle(d.title)}
            </button>
          ))}
        {list?.length === 0 && <p className="p-2 text-sm text-muted">No databases yet.</p>}
      </div>
    </div>
  );
}

// ------------------------------------------------------------------ Code block

const LANGUAGES = [
  "plaintext", "bash", "c", "cpp", "csharp", "css", "diff", "go", "graphql", "ini", "java", "javascript", "json", "kotlin", "less", "lua", "makefile", "markdown",
  "objectivec", "perl", "php", "python", "r", "ruby", "rust", "scss", "shell", "sql", "swift", "typescript", "xml", "yaml",
];

export function CodeBlockView({ node, updateAttributes, editor }: NodeViewProps) {
  const [copied, setCopied] = useState(false);
  return (
    <NodeViewWrapper className="group relative my-1">
      <div contentEditable={false} className="absolute left-2 right-2 top-1.5 z-10 flex items-center justify-between text-xs opacity-60 transition-opacity group-hover:opacity-100">
        <select
          className="rounded bg-transparent px-1 py-0.5 text-muted outline-none hover:bg-hover"
          value={node.attrs.language ?? "plaintext"}
          disabled={!editor.isEditable}
          onChange={(e) => updateAttributes({ language: e.target.value })}
          aria-label="Code language"
        >
          {LANGUAGES.map((l) => (
            <option key={l} value={l}>
              {l}
            </option>
          ))}
        </select>
        <button
          className="flex items-center gap-1 rounded px-1.5 py-0.5 text-muted hover:bg-hover"
          onClick={() => {
            navigator.clipboard?.writeText(node.textContent);
            setCopied(true);
            setTimeout(() => setCopied(false), 1200);
          }}
        >
          {copied ? <Check size={12} /> : <Copy size={12} />} {copied ? "Copied" : "Copy"}
        </button>
      </div>
      <pre spellCheck={false}>
        <NodeViewContent<"code"> as="code" />
      </pre>
    </NodeViewWrapper>
  );
}
