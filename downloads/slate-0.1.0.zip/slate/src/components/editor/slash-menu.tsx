"use client";
import { Extension, type Editor, type Range } from "@tiptap/core";
import { ReactRenderer } from "@tiptap/react";
import Suggestion, { type SuggestionProps, type SuggestionKeyDownProps } from "@tiptap/suggestion";
import { PluginKey } from "@tiptap/pm/state";
import { forwardRef, useEffect, useImperativeHandle, useRef, useState, type ReactNode } from "react";
import {
  Type,
  Heading1,
  Heading2,
  Heading3,
  List,
  ListOrdered,
  ListTodo,
  ChevronRight,
  Quote,
  Minus,
  Lightbulb,
  Code2,
  Table,
  FileText,
  Database,
  Image as ImageIcon,
  Film,
  Music,
  Paperclip,
  Link2,
  Globe,
  Sigma,
  ListTree,
  Route,
  AtSign,
  Palette,
  Table2,
} from "lucide-react";
import { cx } from "@/client/ui";

export interface SlashItem {
  title: string;
  description: string;
  keywords: string;
  icon: ReactNode;
  group: string;
  run: (editor: Editor, range: Range) => void;
}

/** Hooks the page view fills in so slash items can create pages/databases via the API. */
export interface SlashHooks {
  createChildPage?: (kind: "page" | "database", inline: boolean) => Promise<string | null>;
}
export const slashHooks: SlashHooks = {};

const COLOR_NAMES = ["gray", "brown", "orange", "yellow", "green", "blue", "purple", "pink", "red"] as const;

export function slashItems(): SlashItem[] {
  const block = (title: string, description: string, keywords: string, icon: ReactNode, run: SlashItem["run"], group = "Basic blocks"): SlashItem => ({ title, description, keywords, icon, run, group });
  const insertAtom = (type: string, attrs: Record<string, unknown> = {}) => (editor: Editor, range: Range) =>
    editor.chain().focus().deleteRange(range).insertContent({ type, attrs }).run();
  const items: SlashItem[] = [
    block("Text", "Plain paragraph", "paragraph p", <Type size={18} />, (e, r) => e.chain().focus().deleteRange(r).setParagraph().run()),
    block("Heading 1", "Large section heading", "h1 title #", <Heading1 size={18} />, (e, r) => e.chain().focus().deleteRange(r).setHeading({ level: 1 }).run()),
    block("Heading 2", "Medium section heading", "h2 subtitle ##", <Heading2 size={18} />, (e, r) => e.chain().focus().deleteRange(r).setHeading({ level: 2 }).run()),
    block("Heading 3", "Small section heading", "h3 ###", <Heading3 size={18} />, (e, r) => e.chain().focus().deleteRange(r).setHeading({ level: 3 }).run()),
    block("Bulleted list", "Simple bulleted list", "ul unordered bullet -", <List size={18} />, (e, r) => e.chain().focus().deleteRange(r).toggleBulletList().run()),
    block("Numbered list", "List with numbering", "ol ordered number 1.", <ListOrdered size={18} />, (e, r) => e.chain().focus().deleteRange(r).toggleOrderedList().run()),
    block("To-do list", "Track tasks with checkboxes", "todo task checkbox check []", <ListTodo size={18} />, (e, r) => e.chain().focus().deleteRange(r).toggleTaskList().run()),
    block("Toggle list", "Hide content inside a toggle", "toggle collapse details expand", <ChevronRight size={18} />, (e, r) =>
      e
        .chain()
        .focus()
        .deleteRange(r)
        .insertContent({ type: "toggle", attrs: { open: true }, content: [{ type: "paragraph" }] })
        .run(),
    ),
    block("Quote", "Capture a quote", "blockquote citation >", <Quote size={18} />, (e, r) => e.chain().focus().deleteRange(r).toggleBlockquote().run()),
    block("Divider", "Visually separate blocks", "hr line separator ---", <Minus size={18} />, (e, r) => e.chain().focus().deleteRange(r).setHorizontalRule().run()),
    block("Callout", "Make writing stand out", "callout note info tip warning", <Lightbulb size={18} />, (e, r) =>
      e
        .chain()
        .focus()
        .deleteRange(r)
        .insertContent({ type: "callout", attrs: { icon: "💡", color: "gray" }, content: [{ type: "paragraph" }] })
        .run(),
    ),
    block("Code", "Code snippet with highlighting", "code snippet pre ```", <Code2 size={18} />, (e, r) => e.chain().focus().deleteRange(r).setCodeBlock().run()),
    block("Table", "Simple table", "table grid rows columns", <Table size={18} />, (e, r) => e.chain().focus().deleteRange(r).insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run()),
    block(
      "Page",
      "Embed a sub-page inside this page",
      "page subpage child new",
      <FileText size={18} />,
      async (e, r) => {
        e.chain().focus().deleteRange(r).run();
        const id = await slashHooks.createChildPage?.("page", false);
        if (id) e.chain().focus().insertContent({ type: "childPage", attrs: { pageId: id } }).run();
      },
      "Pages & databases",
    ),
    block(
      "Link to page",
      "Mention another page inline",
      "link mention @ reference",
      <AtSign size={18} />,
      (e, r) => e.chain().focus().deleteRange(r).insertContent("@").run(),
      "Pages & databases",
    ),
    block(
      "Database – inline",
      "Table, board, calendar and more, inside this page",
      "database table inline db",
      <Table2 size={18} />,
      async (e, r) => {
        e.chain().focus().deleteRange(r).run();
        const id = await slashHooks.createChildPage?.("database", true);
        if (id) e.chain().focus().insertContent({ type: "databaseView", attrs: { databaseId: id } }).run();
      },
      "Pages & databases",
    ),
    block(
      "Database – full page",
      "A database as a sub-page",
      "database page full db",
      <Database size={18} />,
      async (e, r) => {
        e.chain().focus().deleteRange(r).run();
        const id = await slashHooks.createChildPage?.("database", false);
        if (id) e.chain().focus().insertContent({ type: "childPage", attrs: { pageId: id } }).run();
      },
      "Pages & databases",
    ),
    block("Linked view of database", "Show an existing database here", "linked view database existing", <Route size={18} />, insertAtom("databaseView", { databaseId: null }), "Pages & databases"),
    block("Image", "Upload or embed an image", "image picture photo img", <ImageIcon size={18} />, insertAtom("image", { src: null }), "Media"),
    block("Video", "Upload or embed a video", "video movie youtube", <Film size={18} />, insertAtom("video"), "Media"),
    block("Audio", "Upload or embed audio", "audio sound music podcast", <Music size={18} />, insertAtom("audio"), "Media"),
    block("File", "Upload or link a file", "file attachment upload pdf", <Paperclip size={18} />, insertAtom("fileBlock"), "Media"),
    block("Web bookmark", "Visual link preview", "bookmark link url preview", <Link2 size={18} />, insertAtom("bookmark"), "Media"),
    block("Embed", "YouTube, Figma, Loom, CodePen…", "embed iframe youtube figma loom", <Globe size={18} />, insertAtom("embed"), "Media"),
    block("Block equation", "Display a TeX formula", "math equation latex tex formula", <Sigma size={18} />, insertAtom("equation", { latex: "" }), "Advanced"),
    block("Inline equation", "TeX inside a sentence", "math inline latex $", <Sigma size={18} />, (e, r) => e.chain().focus().deleteRange(r).insertContent({ type: "inlineMath", attrs: { latex: "x^2" } }).run(), "Advanced"),
    block("Table of contents", "Links to the headings on this page", "toc contents outline", <ListTree size={18} />, insertAtom("toc"), "Advanced"),
    block("Breadcrumb", "Show where this page lives", "breadcrumb path location", <Route size={18} />, insertAtom("breadcrumb"), "Advanced"),
  ];
  for (const c of COLOR_NAMES) {
    items.push(
      block(`${c[0].toUpperCase()}${c.slice(1)} text`, "Change text color", `color ${c} text`, <Palette size={18} className={`fg-${c}`} />, (e, r) =>
        e.chain().focus().deleteRange(r).setColor(`var(--c-${c}-fg)`).run(), "Colors"),
    );
  }
  for (const c of COLOR_NAMES) {
    items.push(
      block(`${c[0].toUpperCase()}${c.slice(1)} background`, "Highlight text", `color ${c} background highlight`, <span className={`block h-4 w-4 rounded bg-c-${c}`} />, (e, r) =>
        e.chain().focus().deleteRange(r).setHighlight({ color: `var(--c-${c}-bg)` }).run(), "Colors"),
    );
  }
  return items;
}

function filterItems(query: string) {
  const q = query.toLowerCase().trim();
  const all = slashItems();
  if (!q) return all.filter((i) => i.group !== "Colors");
  return all
    .map((i) => {
      const t = i.title.toLowerCase();
      const score = t.startsWith(q) ? 3 : t.includes(q) ? 2 : i.keywords.includes(q) ? 1 : 0;
      return [score, i] as const;
    })
    .filter(([s]) => s > 0)
    .sort((a, b) => b[0] - a[0])
    .map(([, i]) => i);
}

interface MenuRef {
  onKeyDown: (p: SuggestionKeyDownProps) => boolean;
}

const SlashMenu = forwardRef<MenuRef, SuggestionProps<SlashItem>>(function SlashMenu(props, ref) {
  const [index, setIndex] = useState(0);
  const listRef = useRef<HTMLDivElement>(null);
  useEffect(() => setIndex(0), [props.items]);
  useEffect(() => {
    listRef.current?.querySelector(`[data-index="${index}"]`)?.scrollIntoView({ block: "nearest" });
  }, [index]);
  const select = (i: number) => {
    const item = props.items[i];
    if (item) props.command(item);
  };
  useImperativeHandle(ref, () => ({
    onKeyDown: ({ event }) => {
      if (event.key === "ArrowDown") {
        setIndex((i) => (i + 1) % Math.max(1, props.items.length));
        return true;
      }
      if (event.key === "ArrowUp") {
        setIndex((i) => (i - 1 + props.items.length) % Math.max(1, props.items.length));
        return true;
      }
      if (event.key === "Enter" || event.key === "Tab") {
        select(index);
        return true;
      }
      return false;
    },
  }));
  if (!props.items.length) return <div className="w-72 rounded-lg border border-line bg-elevated p-3 text-sm text-muted" style={{ boxShadow: "var(--shadow)" }}>No matching blocks</div>;
  let lastGroup = "";
  return (
    <div ref={listRef} className="max-h-[340px] w-72 overflow-y-auto rounded-lg border border-line bg-elevated py-1" style={{ boxShadow: "var(--shadow)" }} role="listbox">
      {props.items.map((item, i) => {
        const header = item.group !== lastGroup ? item.group : null;
        lastGroup = item.group;
        return (
          <div key={item.title}>
            {header && <div className="px-3 pb-1 pt-2 text-xs font-medium text-muted">{header}</div>}
            <button
              data-index={i}
              role="option"
              aria-selected={i === index}
              className={cx("mx-1 flex w-[calc(100%-8px)] items-center gap-3 rounded px-2 py-1.5 text-left", i === index && "bg-hover")}
              onMouseEnter={() => setIndex(i)}
              onMouseDown={(e) => {
                e.preventDefault();
                select(i);
              }}
            >
              <span className="flex h-9 w-9 flex-none items-center justify-center rounded-md border border-line bg-bg text-muted">{item.icon}</span>
              <span className="min-w-0">
                <span className="block truncate text-sm">{item.title}</span>
                <span className="block truncate text-xs text-muted">{item.description}</span>
              </span>
            </button>
          </div>
        );
      })}
    </div>
  );
});

/** Shared positioning for suggestion popups (slash menu, @-mentions). */
export function suggestionRenderer<T>(Component: React.ForwardRefExoticComponent<SuggestionProps<T> & React.RefAttributes<MenuRef>>) {
  return () => {
    let renderer: ReactRenderer<MenuRef, SuggestionProps<T>> | null = null;
    let el: HTMLDivElement | null = null;
    const place = (props: SuggestionProps<T>) => {
      const rect = props.clientRect?.();
      if (!rect || !el) return;
      const h = el.offsetHeight || 340;
      const below = rect.bottom + 6 + h < window.innerHeight;
      el.style.left = `${Math.min(rect.left, window.innerWidth - 300)}px`;
      el.style.top = below ? `${rect.bottom + 6}px` : `${Math.max(8, rect.top - h - 6)}px`;
    };
    return {
      onStart: (props: SuggestionProps<T>) => {
        renderer = new ReactRenderer(Component, { props, editor: props.editor });
        el = document.createElement("div");
        el.style.position = "fixed";
        el.style.zIndex = "60";
        el.appendChild(renderer.element);
        document.body.appendChild(el);
        requestAnimationFrame(() => place(props));
      },
      onUpdate: (props: SuggestionProps<T>) => {
        renderer?.updateProps(props);
        requestAnimationFrame(() => place(props));
      },
      onKeyDown: (props: SuggestionKeyDownProps) => {
        if (props.event.key === "Escape") {
          el?.remove();
          el = null;
          return true;
        }
        return renderer?.ref?.onKeyDown(props) ?? false;
      },
      onExit: () => {
        el?.remove();
        el = null;
        renderer?.destroy();
        renderer = null;
      },
    };
  };
}

export const SlashCommand = Extension.create({
  name: "slashCommand",
  addProseMirrorPlugins() {
    return [
      Suggestion<SlashItem>({
        editor: this.editor,
        pluginKey: new PluginKey("slashCommand"),
        char: "/",
        startOfLine: false,
        allowSpaces: false,
        allow: ({ state, range }) => {
          const $from = state.doc.resolve(range.from);
          return $from.parent.type.name !== "codeBlock";
        },
        items: ({ query }) => filterItems(query),
        command: ({ editor, range, props }) => props.run(editor, range),
        render: suggestionRenderer(SlashMenu),
      }),
    ];
  },
});

export type { MenuRef };
