"use client";
import { useEffect, useMemo, useState } from "react";
import * as Y from "yjs";
import { HocuspocusProvider } from "@hocuspocus/provider";

export interface CollabSession {
  doc: Y.Doc;
  provider: HocuspocusProvider;
  user: { name: string; color: string };
}

export interface Peer {
  clientId: number;
  name: string;
  color: string;
}

type State = { key: string; status: "ready"; session: CollabSession } | { key: string; status: "failed"; reason: string; retry: boolean };

/** Delay before the n-th reconnection attempt after a failure (5 s, 10 s, 20 s, … up to 60 s). */
export const retryDelay = (n: number) => Math.min(60_000, 5_000 * 2 ** n);

const COLORS = ["#d9730d", "#448361", "#337ea9", "#9065b0", "#c14c8a", "#d44c47", "#cb912f", "#2e8b8b"];
export function colorFor(id: string) {
  let h = 0;
  for (const c of id) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return COLORS[h % COLORS.length];
}

export function collabUrl(realtime: { port: number; url: string | null }) {
  if (realtime.url) return realtime.url;
  const proto = location.protocol === "https:" ? "wss:" : "ws:";
  return `${proto}//${location.hostname}:${realtime.port}`;
}

/**
 * Connects a page to the realtime server. Resolves to a session once the document has synced,
 * or to "failed" (caller falls back to REST saves) if the server rejects or does not answer.
 * After a failure it keeps retrying in the background (with backoff, and at once when the browser
 * comes back online) and resolves to "ready" when a later attempt succeeds; access denials are
 * not retried.
 */
export function useCollab(pageId: string, opts: { enabled: boolean; realtime: { port: number; url: string | null } | null; user: { id: string; name: string } }) {
  const [state, setState] = useState<State | null>(null);
  const [attempt, setAttempt] = useState({ key: "", n: 0 });
  const key = `${pageId}:${opts.enabled ? "on" : "off"}`;
  const n = attempt.key === key ? attempt.n : 0;
  const url = opts.realtime && typeof window !== "undefined" ? collabUrl(opts.realtime) : null;
  const userName = opts.user.name;
  const userId = opts.user.id;

  useEffect(() => {
    if (!opts.enabled || !url) return;
    const doc = new Y.Doc();
    let settled = false;
    const provider = new HocuspocusProvider({ url, name: pageId, document: doc });
    const settle = (s: State) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      setState(s);
    };
    const timer = setTimeout(() => settle({ key, status: "failed", reason: "timeout", retry: true }), 6000);
    provider.on("synced", () => settle({ key, status: "ready", session: { doc, provider, user: { name: userName, color: colorFor(userId) } } }));
    provider.on("authenticationFailed", () => settle({ key, status: "failed", reason: "denied", retry: false }));
    provider.on("close", ({ event }: { event: { code: number } }) => {
      // Closed before the first sync: unreachable, or rejected (no access, archived page).
      if (!settled && event.code !== 1000) settle({ key, status: "failed", reason: `closed ${event.code}`, retry: event.code !== 4401 && event.code !== 4403 });
    });
    return () => {
      clearTimeout(timer);
      provider.destroy();
      doc.destroy();
    };
  }, [pageId, url, opts.enabled, key, n, userName, userId]);

  // After a retryable failure, try again later (a new attempt replaces the failed provider).
  const failed = state?.key === key && state.status === "failed" ? state : null;
  const retryable = !!failed?.retry && opts.enabled && !!url;
  useEffect(() => {
    if (!retryable) return;
    const again = () => setAttempt({ key, n: n + 1 });
    const t = setTimeout(again, retryDelay(n));
    window.addEventListener("online", again);
    return () => {
      clearTimeout(t);
      window.removeEventListener("online", again);
    };
  }, [retryable, key, n]);

  if (!opts.enabled || !url) return { status: "off" as const, session: null };
  if (!state || state.key !== key) return { status: "connecting" as const, session: null };
  return state.status === "ready" ? { status: "ready" as const, session: state.session } : { status: "failed" as const, session: null };
}

/** Other people currently on the page (from awareness). */
export function usePeers(session: CollabSession | null): Peer[] {
  const [peers, setPeers] = useState<Peer[]>([]);
  useEffect(() => {
    const awareness = session?.provider.awareness;
    if (!awareness) return;
    const update = () => {
      const list: Peer[] = [];
      awareness.getStates().forEach((st, clientId) => {
        const u = (st as { user?: { name?: string; color?: string } }).user;
        if (clientId !== awareness.clientID && u?.name) list.push({ clientId, name: u.name, color: u.color ?? "#888" });
      });
      setPeers(list);
    };
    awareness.on("change", update);
    const t = setTimeout(update, 0);
    return () => {
      clearTimeout(t);
      awareness.off("change", update);
    };
  }, [session]);
  return useMemo(() => (session ? peers : []), [session, peers]);
}
