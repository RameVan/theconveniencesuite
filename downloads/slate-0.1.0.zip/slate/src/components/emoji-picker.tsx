"use client";
import { useMemo, useState } from "react";
import { Shuffle, Trash2, Upload } from "lucide-react";
import { cx } from "@/client/ui";

// Curated emoji set with search keywords ("emoji keyword keyword").
const DATA: Record<string, string[]> = {
  Smileys: [
    "😀 grin smile happy", "😃 smile happy joy", "😄 laugh happy", "😁 beam grin", "😆 laugh squint", "😅 sweat smile", "🤣 rofl laugh", "😂 tears joy laugh",
    "🙂 slight smile", "🙃 upside down", "😉 wink", "😊 blush smile", "😇 halo angel", "🥰 love hearts", "😍 heart eyes love", "🤩 star struck",
    "😘 kiss", "😋 yum tasty", "😛 tongue", "🤪 zany crazy", "🤔 thinking hmm", "🤨 raised eyebrow", "😐 neutral", "😑 expressionless",
    "😶 no mouth", "🙄 eye roll", "😏 smirk", "😬 grimace", "😌 relieved", "😔 pensive", "😴 sleep zzz", "🤒 sick",
    "🤯 mind blown exploding", "🥳 party celebrate", "😎 cool sunglasses", "🤓 nerd glasses", "🧐 monocle", "😕 confused", "😮 open mouth wow", "😲 astonished",
    "😳 flushed", "🥺 pleading", "😢 cry sad", "😭 sob", "😱 scream fear", "😤 triumph huff", "😡 angry rage", "🤬 cursing",
    "💀 skull dead", "👻 ghost", "👽 alien", "🤖 robot bot", "💩 poop", "😺 cat smile", "🙈 see no evil monkey", "🫠 melting",
  ],
  People: [
    "👋 wave hello", "🤚 raised back hand", "✋ hand stop", "👌 ok", "✌️ peace victory", "🤞 fingers crossed luck", "🤟 love you", "🤘 rock",
    "👈 point left", "👉 point right", "👆 point up", "👇 point down", "👍 thumbs up yes like", "👎 thumbs down no", "✊ fist", "👏 clap applause",
    "🙌 raise hands hooray", "🙏 pray thanks please", "✍️ writing", "💪 muscle strong", "🧠 brain think", "👀 eyes look", "👤 user person", "👥 users people team",
    "🧑‍💻 developer coder", "🧑‍🎨 artist designer", "🧑‍🏫 teacher", "🧑‍🔬 scientist", "🧑‍🚀 astronaut", "🧑‍🍳 cook chef", "🦸 hero", "🧙 wizard mage",
  ],
  Nature: [
    "🌱 seedling grow sprout", "🌿 herb leaf", "🍀 clover luck", "🌵 cactus", "🌲 tree evergreen", "🌳 tree", "🌴 palm", "🍁 maple leaf autumn",
    "🌸 cherry blossom flower", "🌻 sunflower", "🌹 rose", "🌷 tulip", "🌈 rainbow", "☀️ sun", "🌙 moon night", "⭐ star",
    "🌟 glowing star", "✨ sparkles magic", "⚡ lightning zap", "🔥 fire hot lit", "💧 droplet water", "🌊 wave ocean", "❄️ snowflake cold", "☁️ cloud",
    "🐶 dog puppy", "🐱 cat kitten", "🦊 fox", "🐻 bear", "🐼 panda", "🦁 lion", "🐯 tiger", "🐸 frog",
    "🐵 monkey", "🦄 unicorn", "🐝 bee", "🦋 butterfly", "🐢 turtle slow", "🐙 octopus", "🐳 whale", "🦉 owl",
  ],
  Food: [
    "🍎 apple", "🍋 lemon", "🍌 banana", "🍉 watermelon", "🍇 grapes", "🍓 strawberry", "🥑 avocado", "🥕 carrot",
    "🌽 corn", "🍞 bread", "🧀 cheese", "🍕 pizza", "🍔 burger", "🌮 taco", "🍣 sushi", "🍜 noodles ramen",
    "🍩 donut", "🍪 cookie", "🎂 cake birthday", "🍫 chocolate", "☕ coffee", "🍵 tea", "🍺 beer", "🍷 wine",
  ],
  Activities: [
    "⚽ soccer football", "🏀 basketball", "🎾 tennis", "🏈 american football", "🎯 target goal dart", "🎮 game controller", "🎲 dice game", "🧩 puzzle",
    "🎨 art palette paint", "🎬 film movie clapper", "🎤 microphone sing", "🎧 headphones music", "🎵 music note", "🎸 guitar", "🎹 piano", "🏆 trophy win award",
    "🥇 gold medal first", "🏅 medal", "🎉 party tada celebrate", "🎊 confetti", "🎁 gift present", "🎈 balloon", "🏃 run", "🧘 yoga meditate",
  ],
  Travel: [
    "🚀 rocket launch ship", "✈️ airplane travel flight", "🚗 car", "🚲 bicycle bike", "🚂 train", "⛵ sailboat", "🏠 house home", "🏢 office building",
    "🏫 school", "🏥 hospital", "🏰 castle", "🗽 statue liberty", "🗺️ map", "🧭 compass direction", "🏔️ mountain", "🏖️ beach",
    "🏕️ camping", "🌍 globe earth world", "🌐 globe network web", "🗓️ calendar", "⏰ alarm clock", "⌛ hourglass time", "🧳 luggage", "📍 pin location",
  ],
  Objects: [
    "💡 idea bulb light", "📌 pushpin pin", "📎 paperclip attach", "📝 memo note write", "📄 page document", "📃 page curl", "📑 bookmark tabs", "📚 books library",
    "📖 open book read", "📓 notebook", "📒 ledger", "📕 book red", "🗂️ dividers folders", "📁 folder", "📂 open folder", "🗃️ card file box database",
    "🗄️ file cabinet", "📊 bar chart stats", "📈 chart up growth", "📉 chart down", "📋 clipboard", "✅ check done task", "☑️ checkbox", "✔️ check mark",
    "❌ cross no", "⚠️ warning", "🚫 prohibited", "❓ question", "❗ exclamation", "💬 speech chat comment", "💭 thought", "📣 megaphone announce",
    "🔔 bell notification", "🔑 key", "🔒 lock private", "🔓 unlock", "🛠️ tools build", "🔧 wrench fix", "🔨 hammer", "⚙️ gear settings",
    "🧪 test tube experiment", "🔬 microscope research", "🔭 telescope", "💻 laptop computer", "🖥️ desktop", "⌨️ keyboard", "🖱️ mouse", "📱 phone mobile",
    "📷 camera photo", "🎥 video camera", "📺 tv", "🔍 search magnifier", "🧲 magnet", "💰 money bag", "💳 credit card", "💎 gem diamond",
    "🧾 receipt invoice", "✉️ envelope email", "📦 package box", "🏷️ label tag", "🖊️ pen", "✏️ pencil edit", "🖍️ crayon", "📐 ruler triangle design",
  ],
  Symbols: [
    "❤️ red heart love", "🧡 orange heart", "💛 yellow heart", "💚 green heart", "💙 blue heart", "💜 purple heart", "🖤 black heart", "🤍 white heart",
    "💯 hundred", "🔴 red circle", "🟠 orange circle", "🟡 yellow circle", "🟢 green circle", "🔵 blue circle", "🟣 purple circle", "⚫ black circle",
    "🟥 red square", "🟩 green square", "🟦 blue square", "♻️ recycle", "➕ plus", "➖ minus", "➡️ arrow right", "⬅️ arrow left",
    "⬆️ arrow up", "⬇️ arrow down", "🔄 refresh sync", "🔗 link chain", "#️⃣ hash number", "🆕 new", "🆗 ok", "ℹ️ info",
  ],
};

const ALL = Object.values(DATA).flat();

export function EmojiPicker({
  onSelect,
  onRemove,
  onUpload,
}: {
  onSelect: (emoji: string) => void;
  onRemove?: () => void;
  onUpload?: () => void;
}) {
  const [q, setQ] = useState("");
  const results = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return null;
    return ALL.filter((e) => e.toLowerCase().includes(needle)).map((e) => e.split(" ")[0]);
  }, [q]);
  const grid = (list: string[]) => (
    <div className="grid grid-cols-8 gap-0.5">
      {list.map((e) => (
        <button key={e} className="flex h-8 w-8 items-center justify-center rounded text-xl hover:bg-hover" onClick={() => onSelect(e)} title={e}>
          {e}
        </button>
      ))}
    </div>
  );
  return (
    <div className="w-[300px] p-2">
      <div className="mb-2 flex items-center gap-1">
        <input autoFocus className="input h-7 flex-1" placeholder="Filter…" value={q} onChange={(e) => setQ(e.target.value)} />
        <button className="icon-btn" title="Random" onClick={() => onSelect(ALL[Math.floor(Math.random() * ALL.length)].split(" ")[0])}>
          <Shuffle size={15} />
        </button>
        {onUpload && (
          <button className="icon-btn" title="Upload an image" onClick={onUpload}>
            <Upload size={15} />
          </button>
        )}
        {onRemove && (
          <button className="icon-btn" title="Remove" onClick={onRemove}>
            <Trash2 size={15} />
          </button>
        )}
      </div>
      <div className={cx("max-h-[300px] overflow-y-auto pr-1")}>
        {results ? (
          results.length ? grid(results) : <p className="p-4 text-center text-sm text-muted">No emoji found</p>
        ) : (
          Object.entries(DATA).map(([cat, list]) => (
            <div key={cat} className="mb-2">
              <div className="px-1 pb-1 text-xs font-medium text-muted">{cat}</div>
              {grid(list.map((e) => e.split(" ")[0]))}
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export function randomEmoji() {
  const pool = ["📄", "📝", "📚", "🚀", "💡", "🎯", "🌱", "🗂️", "📌", "✨", "🧭", "🔖"];
  return pool[Math.floor(Math.random() * pool.length)];
}
