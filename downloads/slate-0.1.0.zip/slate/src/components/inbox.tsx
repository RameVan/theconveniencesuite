"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import useSWR from "swr";
import { Inbox as InboxIcon, AtSign, MessageSquareReply, CheckCheck } from "lucide-react";
import { api, errorMessage } from "@/client/api";
import { Dialog, Spinner, useUi, cx } from "@/client/ui";
import { useWorkspace } from "@/client/workspace-context";
import { PageIcon, pageTitle } from "./page-icon";

interface Notification {
  id: string;
  kind: "page_mention" | "comment_mention" | "reply";
  pageId: string;
  pageTitle: string;
  pageIcon: string | null;
  commentId: string | null;
  blockId: string | null;
  excerpt: string;
  createdAt: string;
  readAt: string | null;
  actorName: string | null;
}

const VERB: Record<Notification["kind"], string> = {
  page_mention: "mentioned you in",
  comment_mention: "mentioned you in a comment on",
  reply: "replied to a comment on",
};

/** Sidebar entry with unread count; opens the list of mentions and replies. */
export function InboxButton() {
  const ws = useWorkspace();
  const router = useRouter();
  const { toast } = useUi();
  const [open, setOpen] = useState(false);
  const key = `/api/notifications?workspaceId=${ws.workspace.id}`;
  const { data, mutate } = useSWR<{ notifications: Notification[]; unread: number }>(key, { refreshInterval: 30_000 });
  const unread = data?.unread ?? 0;

  const markRead = async (body: { ids: string[] } | { all: true; workspaceId: string }) => {
    try {
      await api.post("/api/notifications/read", body);
      mutate();
    } catch (e) {
      toast(errorMessage(e), "error");
    }
  };

  const go = (n: Notification) => {
    if (!n.readAt) markRead({ ids: [n.id] });
    setOpen(false);
    const base = `/w/${ws.workspace.id}/p/${n.pageId}`;
    router.push(n.commentId ? `${base}?thread=${n.commentId}` : n.blockId ? `${base}#block-${n.blockId}` : base);
  };

  return (
    <>
      <button
        className="flex w-full items-center gap-2 rounded-md px-2 py-1 text-left text-muted hover:bg-hover hover:text-fg"
        onClick={() => {
          setOpen(true);
          mutate();
        }}
        aria-label={unread ? `Inbox, ${unread} unread` : "Inbox"}
      >
        <span className="flex w-5 justify-center">
          <InboxIcon size={16} />
        </span>
        <span className="flex-1">Inbox</span>
        {unread > 0 && <span className="min-w-5 rounded-full bg-danger px-1.5 text-center text-[11px] font-semibold leading-5 text-white">{unread > 99 ? "99+" : unread}</span>}
      </button>
      <Dialog open={open} onClose={() => setOpen(false)} title="Inbox" width={520} align="top">
        <div className="flex items-center justify-between pb-2">
          <span className="text-sm text-muted">Mentions and replies</span>
          {unread > 0 && (
            <button className="link-btn flex items-center gap-1" onClick={() => markRead({ all: true, workspaceId: ws.workspace.id })}>
              <CheckCheck size={14} /> Mark all as read
            </button>
          )}
        </div>
        <div className="-mx-2 max-h-[60vh] overflow-y-auto">
          {!data && <Spinner />}
          {data && !data.notifications.length && <p className="px-2 py-6 text-center text-sm text-muted">You’re all caught up. Mentions of you and replies to your comments appear here.</p>}
          {data?.notifications.map((n) => (
            <button key={n.id} className={cx("flex w-full gap-3 rounded-md px-2 py-2 text-left hover:bg-hover", !n.readAt && "bg-accent-soft/40")} onClick={() => go(n)}>
              <span className="mt-0.5 flex h-7 w-7 flex-none items-center justify-center rounded-full bg-subtle text-muted">{n.kind === "reply" ? <MessageSquareReply size={14} /> : <AtSign size={14} />}</span>
              <span className="min-w-0 flex-1">
                <span className="block text-sm">
                  <span className="font-medium">{n.actorName ?? "Someone"}</span> {VERB[n.kind]}{" "}
                  <span className="inline-flex items-baseline gap-1 font-medium">
                    <PageIcon icon={n.pageIcon} size={13} className="relative top-[1px]" />
                    {pageTitle(n.pageTitle)}
                  </span>
                </span>
                {n.excerpt && <span className="mt-0.5 line-clamp-2 block text-sm text-muted">{n.excerpt}</span>}
                <span className="mt-0.5 block text-xs text-faint">{new Date(n.createdAt).toLocaleString()}</span>
              </span>
              {!n.readAt && <span className="mt-2 h-2 w-2 flex-none rounded-full bg-accent" aria-label="Unread" />}
            </button>
          ))}
        </div>
      </Dialog>
    </>
  );
}
