"use client";
import { FileText, Database, File } from "lucide-react";
import { cx } from "@/client/ui";

export function isImageIcon(icon: string | null | undefined) {
  return !!icon && (icon.startsWith("/api/files/") || icon.startsWith("http://") || icon.startsWith("https://"));
}

export function PageIcon({
  icon,
  kind = "page",
  size = 16,
  className,
  hasContent = true,
}: {
  icon: string | null | undefined;
  kind?: "page" | "database";
  size?: number;
  className?: string;
  hasContent?: boolean;
}) {
  if (isImageIcon(icon)) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={icon!} alt="" width={size} height={size} className={cx("flex-none rounded-sm object-cover", className)} style={{ width: size, height: size }} />;
  }
  if (icon) {
    return (
      <span className={cx("inline-flex flex-none items-center justify-center leading-none", className)} style={{ width: size, height: size, fontSize: size * 0.95 }} aria-hidden>
        {icon}
      </span>
    );
  }
  const Icon = kind === "database" ? Database : hasContent ? FileText : File;
  return <Icon size={size * 0.95} className={cx("flex-none text-muted", className)} strokeWidth={1.75} aria-hidden />;
}

export function pageTitle(t: string | null | undefined) {
  return t?.trim() ? t : "Untitled";
}
