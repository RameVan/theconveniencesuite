"use client";
import { Fragment, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import useSWR, { mutate } from "swr";
import { X, Check, Trash2, RotateCcw } from "lucide-react";
import { api, errorMessage } from "@/client/api";
import { useUi, Spinner, cx } from "@/client/ui";
import { useWorkspace } from "@/client/workspace-context";
import { useMembers } from "@/client/hooks";
import { COMMENT_MENTION_RE, commentMentionToken } from "@/lib/mentions";

export interface Comment {
  id: string;
  parentId: string | null;
  blockId: string | null;
  quote: string | null;
  body: string;
  resolved: boolean;
  createdAt: string;
  editedAt: string | null;
  userId: string | null;
  userName: string | null;
}

export interface Thread {
  root: Comment;
  replies: Comment[];
}

export const commentsKey = (pageId: string) => `/api/pages/${pageId}/comments`;

export function useThreads(pageId: string) {
  const { data } = useSWR<{ comments: Comment[] }>(commentsKey(pageId));
  return useMemo(() => {
    if (!data) return null;
    const threads = new Map<string, Thread>();
    for (const c of data.comments) if (!c.parentId) threads.set(c.id, { root: c, replies: [] });
    for (const c of data.comments) if (c.parentId) threads.get(c.parentId)?.replies.push(c);
    return { threads: [...threads.values()], byId: new Map(data.comments.map((c) => [c.id, c])) };
  }, [data]);
}

/** A new inline thread being written: its anchor mark is already in the page. */
export interface Draft {
  threadId: string;
  quote: string;
  blockId: string | null;
}

export function CommentsPanel({
  pageId,
  onClose,
  draft,
  onDraftDone,
  activeThread,
  onSelectThread,
}: {
  pageId: string;
  onClose: () => void;
  draft?: Draft | null;
  /** Called with `saved` = false when the draft is cancelled (the anchor should be removed). */
  onDraftDone?: (draft: Draft, saved: boolean) => void;
  activeThread?: string | null;
  onSelectThread?: (threadId: string | null) => void;
}) {
  const { toast } = useUi();
  const key = commentsKey(pageId);
  const data = useThreads(pageId);
  const [showResolved, setShowResolved] = useState(false);
  const list = data?.threads.filter((t) => showResolved || !t.root.resolved || t.root.id === activeThread) ?? [];
  const pageThreads = list.filter((t) => !t.root.quote);
  const inlineThreads = list.filter((t) => t.root.quote);

  const post = async (body: Record<string, unknown>) => {
    try {
      await api.post(key, body);
      await mutate(key);
      return true;
    } catch (err) {
      toast(errorMessage(err), "error");
      return false;
    }
  };

  useEffect(() => {
    if (!activeThread) return;
    document.getElementById(`thread-${activeThread}`)?.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }, [activeThread, data]);

  return (
    <aside className="flex w-full max-w-[360px] flex-none flex-col border-l border-line bg-bg max-md:fixed max-md:inset-y-0 max-md:right-0 max-md:z-30" aria-label="Comments">
      <div className="flex h-11 items-center justify-between border-b border-line px-3">
        <span className="font-medium">Comments</span>
        <div className="flex items-center gap-1">
          <button className={cx("link-btn", showResolved && "bg-hover")} onClick={() => setShowResolved(!showResolved)}>
            {showResolved ? "Hide resolved" : "Show resolved"}
          </button>
          <button className="icon-btn" onClick={onClose} aria-label="Close comments">
            <X size={16} />
          </button>
        </div>
      </div>
      <div className="flex-1 space-y-3 overflow-y-auto p-3">
        {draft && (
          <div className="rounded-lg border border-accent p-3 text-sm" aria-label="New comment">
            <Quote text={draft.quote} />
            <Composer
              autoFocus
              placeholder="Add a comment…"
              submitLabel="Comment"
              onCancel={() => onDraftDone?.(draft, false)}
              onSubmit={async (body) => {
                const ok = await post({ id: draft.threadId, body, quote: draft.quote, blockId: draft.blockId ?? undefined });
                if (ok) {
                  onDraftDone?.(draft, true);
                  onSelectThread?.(draft.threadId);
                }
                return ok;
              }}
            />
          </div>
        )}
        {!data && <Spinner />}
        {data && !list.length && !draft && <p className="text-sm text-muted">No comments yet. Select text in the page and choose Comment, or comment on the whole page below.</p>}
        {[...inlineThreads, ...pageThreads].map((t) => (
          <ThreadCard key={t.root.id} pageId={pageId} thread={t} active={t.root.id === activeThread} onSelect={() => onSelectThread?.(t.root.id === activeThread ? null : t.root.id)} onPost={post} />
        ))}
      </div>
      <div className="border-t border-line p-3">
        <Composer placeholder="Comment on this page…" submitLabel="Comment" onSubmit={(body) => post({ body })} />
      </div>
    </aside>
  );
}

function Quote({ text }: { text: string }) {
  return <div className="mb-2 line-clamp-3 border-l-[3px] border-[var(--c-yellow-fg,#cb912f)] pl-2 text-muted">{text}</div>;
}

function ThreadCard({ pageId, thread, active, onSelect, onPost }: { pageId: string; thread: Thread; active: boolean; onSelect: () => void; onPost: (body: Record<string, unknown>) => Promise<boolean> }) {
  const { root, replies } = thread;
  const { toast } = useUi();
  const key = commentsKey(pageId);
  const [replying, setReplying] = useState(false);
  return (
    <div
      id={`thread-${root.id}`}
      data-thread-card={root.id}
      className={cx("rounded-lg border p-3 text-sm", active ? "border-accent ring-1 ring-accent" : "border-line", root.resolved && "opacity-60")}
      onClick={(e) => {
        if (!(e.target as HTMLElement).closest("button, textarea, a")) onSelect();
      }}
    >
      {root.quote && <Quote text={root.quote} />}
      <CommentItem pageId={pageId} c={root} thread>
        <button
          className="icon-btn h-6 w-6"
          title={root.resolved ? "Reopen" : "Resolve"}
          aria-label={root.resolved ? "Reopen thread" : "Resolve thread"}
          onClick={async () => {
            await api.patch(`${key}/${root.id}`, { resolved: !root.resolved }).catch((e) => toast(errorMessage(e), "error"));
            mutate(key);
          }}
        >
          {root.resolved ? <RotateCcw size={13} /> : <Check size={13} />}
        </button>
      </CommentItem>
      {replies.map((r) => (
        <div key={r.id} className="mt-3 border-t border-line pt-3">
          <CommentItem pageId={pageId} c={r} />
        </div>
      ))}
      {!root.resolved &&
        (replying ? (
          <div className="mt-3">
            <Composer autoFocus placeholder="Reply…" submitLabel="Reply" onCancel={() => setReplying(false)} onSubmit={async (body) => (await onPost({ body, parentId: root.id })) && (setReplying(false), true)} />
          </div>
        ) : (
          <button className="mt-2 w-full rounded border border-line px-2 py-1 text-left text-faint hover:bg-hover" onClick={() => setReplying(true)}>
            Reply…
          </button>
        ))}
    </div>
  );
}

function CommentItem({ pageId, c, thread, children }: { pageId: string; c: Comment; thread?: boolean; children?: React.ReactNode }) {
  const ws = useWorkspace();
  const { toast, confirm } = useUi();
  const key = commentsKey(pageId);
  return (
    <div className="group">
      <div className="mb-1 flex items-center gap-2">
        <span className="flex h-5 w-5 items-center justify-center rounded-full bg-subtle text-[10px] font-medium">{(c.userName ?? "?").slice(0, 1).toUpperCase()}</span>
        <span className="font-medium">{c.userName ?? "Deleted user"}</span>
        <span className="text-xs text-faint" title={new Date(c.createdAt).toLocaleString()}>
          {relativeTime(c.createdAt)}
          {c.editedAt && " (edited)"}
        </span>
        <span className="ml-auto flex opacity-0 focus-within:opacity-100 group-hover:opacity-100">
          {children}
          {c.userId === ws.me.id && (
            <button
              className="icon-btn h-6 w-6"
              title="Delete"
              aria-label={thread ? "Delete thread" : "Delete comment"}
              onClick={async () => {
                if (thread && !(await confirm({ title: "Delete this thread?", message: "All replies are deleted too.", danger: true, confirmLabel: "Delete" }))) return;
                await api.del(`${key}/${c.id}`).catch((e) => toast(errorMessage(e), "error"));
                mutate(key);
              }}
            >
              <Trash2 size={13} />
            </button>
          )}
        </span>
      </div>
      <CommentBody body={c.body} />
    </div>
  );
}

/** Comment text with `@[Name](user:id)` mentions shown as chips. */
export function CommentBody({ body }: { body: string }) {
  const parts: React.ReactNode[] = [];
  let last = 0;
  for (const m of body.matchAll(COMMENT_MENTION_RE)) {
    parts.push(body.slice(last, m.index));
    parts.push(
      <span key={m.index} className="mention">
        @{m[1]}
      </span>,
    );
    last = m.index! + m[0].length;
  }
  parts.push(body.slice(last));
  return (
    <p className="whitespace-pre-wrap break-words">
      {parts.map((p, i) => (
        <Fragment key={i}>{p}</Fragment>
      ))}
    </p>
  );
}

function relativeTime(iso: string) {
  const s = (Date.now() - new Date(iso).getTime()) / 1000;
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return new Date(iso).toLocaleDateString();
}

/**
 * Comment input with @-mentions of workspace members. Mentions show as "@Name" while typing and
 * are sent as `@[Name](user:id)` tokens.
 */
function Composer({
  placeholder,
  submitLabel,
  onSubmit,
  onCancel,
  autoFocus,
}: {
  placeholder: string;
  submitLabel: string;
  onSubmit: (body: string) => Promise<boolean>;
  onCancel?: () => void;
  autoFocus?: boolean;
}) {
  const ws = useWorkspace();
  const { data: members } = useMembers(ws.workspace.id);
  const [text, setText] = useState("");
  const [picked, setPicked] = useState<Map<string, string>>(new Map()); // name → user id
  const [query, setQuery] = useState<{ start: number; q: string } | null>(null);
  const [index, setIndex] = useState(0);
  const [busy, setBusy] = useState(false);
  const ref = useRef<HTMLTextAreaElement>(null);
  const caretAfterPick = useRef<number | null>(null);

  const matches = useMemo(() => {
    if (!query || !members) return [];
    const q = query.q.toLowerCase();
    return members.members.filter((m) => m.name.toLowerCase().includes(q) || m.email.toLowerCase().startsWith(q)).slice(0, 6);
  }, [query, members]);

  const detect = (value: string, caret: number) => {
    const m = /(^|\s)@([^\s@]{0,30})$/.exec(value.slice(0, caret));
    setQuery(m ? { start: caret - m[2].length - 1, q: m[2] } : null);
    setIndex(0);
  };

  const pick = (m: { id: string; name: string }) => {
    if (!query) return;
    const caret = query.start + 1 + query.q.length;
    const next = `${text.slice(0, query.start)}@${m.name} ${text.slice(caret)}`;
    setText(next);
    setPicked(new Map(picked).set(m.name, m.id));
    setQuery(null);
    // Place the cursor right after the inserted name as soon as the new text renders (before the
    // next keystroke; a later frame would move it after fast typing had already continued).
    caretAfterPick.current = query.start + m.name.length + 2;
  };
  useLayoutEffect(() => {
    const pos = caretAfterPick.current;
    if (pos == null || !ref.current) return;
    caretAfterPick.current = null;
    ref.current.focus();
    ref.current.setSelectionRange(pos, pos);
  });

  const submit = async () => {
    const trimmed = text.trim();
    if (!trimmed || busy) return;
    let body = trimmed;
    // Longest names first so "@Ann Lee" wins over "@Ann".
    for (const [name, id] of [...picked].sort((a, b) => b[0].length - a[0].length)) body = body.split(`@${name}`).join(commentMentionToken(name, id));
    setBusy(true);
    const ok = await onSubmit(body);
    setBusy(false);
    if (ok) {
      setText("");
      setPicked(new Map());
    }
  };

  return (
    <form
      className="relative"
      onSubmit={(e) => {
        e.preventDefault();
        submit();
      }}
    >
      <textarea
        ref={ref}
        autoFocus={autoFocus}
        className="input h-20 w-full resize-none"
        placeholder={placeholder}
        aria-label={placeholder}
        value={text}
        onChange={(e) => {
          setText(e.target.value);
          detect(e.target.value, e.target.selectionStart);
        }}
        onKeyDown={(e) => {
          if (query && matches.length) {
            if (e.key === "ArrowDown" || e.key === "ArrowUp") {
              e.preventDefault();
              setIndex((i) => (i + (e.key === "ArrowDown" ? 1 : matches.length - 1)) % matches.length);
              return;
            }
            if (e.key === "Enter" || e.key === "Tab") {
              e.preventDefault();
              pick(matches[index]);
              return;
            }
          }
          if (e.key === "Escape") {
            if (query) setQuery(null);
            else onCancel?.();
          }
          if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
            e.preventDefault();
            submit();
          }
        }}
      />
      {query && matches.length > 0 && (
        <div role="listbox" aria-label="Mention someone" className="absolute bottom-full left-0 z-10 mb-1 w-64 rounded-lg border border-line bg-elevated py-1 text-sm" style={{ boxShadow: "var(--shadow)" }}>
          {matches.map((m, i) => (
            <button
              key={m.id}
              type="button"
              role="option"
              aria-selected={i === index}
              className={cx("mx-1 flex w-[calc(100%-8px)] items-center gap-2 rounded px-2 py-1.5 text-left", i === index && "bg-hover")}
              onMouseDown={(e) => {
                e.preventDefault();
                pick(m);
              }}
            >
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-subtle text-[10px] font-medium">{m.name.slice(0, 1).toUpperCase()}</span>
              <span className="truncate">{m.name}</span>
              <span className="ml-auto truncate text-xs text-faint">{m.email}</span>
            </button>
          ))}
        </div>
      )}
      <div className="mt-2 flex gap-2">
        <button className="btn btn-primary btn-sm" disabled={!text.trim() || busy}>
          {submitLabel}
        </button>
        {onCancel && (
          <button type="button" className="btn btn-sm" onClick={onCancel}>
            Cancel
          </button>
        )}
      </div>
    </form>
  );
}
