"use client";
import { useState } from "react";
import { uploadFile, pickFile } from "@/client/upload";
import { Popover, useUi, cx } from "@/client/ui";
import { errorMessage } from "@/client/api";

export const GRADIENTS = [
  "linear-gradient(135deg,#f6d365 0%,#fda085 100%)",
  "linear-gradient(135deg,#a1c4fd 0%,#c2e9fb 100%)",
  "linear-gradient(135deg,#d4fc79 0%,#96e6a1 100%)",
  "linear-gradient(135deg,#fbc2eb 0%,#a6c1ee 100%)",
  "linear-gradient(135deg,#84fab0 0%,#8fd3f4 100%)",
  "linear-gradient(135deg,#ffecd2 0%,#fcb69f 100%)",
  "linear-gradient(135deg,#667eea 0%,#764ba2 100%)",
  "linear-gradient(135deg,#30cfd0 0%,#330867 100%)",
  "linear-gradient(135deg,#434343 0%,#000000 100%)",
  "linear-gradient(135deg,#e0c3fc 0%,#8ec5fc 100%)",
  "linear-gradient(135deg,#f093fb 0%,#f5576c 100%)",
  "linear-gradient(135deg,#5ee7df 0%,#b490ca 100%)",
];
const SOLIDS = ["#e3e2e0", "#eee0da", "#fadec9", "#fdecc8", "#dbeddb", "#d3e5ef", "#e8deee", "#f5e0e9", "#ffe2dd", "#37352f"];

/** Cover values: "gradient:N", "color:#hex", or an image URL (optionally "#y=NN" for vertical position). */
export function parseCover(cover: string | null | undefined): { style: React.CSSProperties; isImage: boolean; y: number; url: string | null } {
  if (!cover) return { style: {}, isImage: false, y: 50, url: null };
  if (cover.startsWith("gradient:")) return { style: { background: GRADIENTS[Number(cover.slice(9))] ?? GRADIENTS[0] }, isImage: false, y: 50, url: null };
  if (cover.startsWith("color:")) return { style: { background: cover.slice(6) }, isImage: false, y: 50, url: null };
  const [url, frag] = cover.split("#y=");
  const y = frag ? Number(frag) : 50;
  return { style: { backgroundImage: `url("${url.replace(/"/g, "%22")}")`, backgroundSize: "cover", backgroundPosition: `center ${y}%` }, isImage: true, y, url };
}

export function withShare(url: string, share?: string | null) {
  return share && url.startsWith("/api/files/") ? `${url}?share=${encodeURIComponent(share)}` : url;
}

export function Cover({
  cover,
  editable,
  workspaceId,
  onChange,
  shareToken,
}: {
  cover: string;
  editable: boolean;
  workspaceId: string;
  onChange: (c: string | null) => void;
  shareToken?: string | null;
}) {
  const [picker, setPicker] = useState<HTMLElement | null>(null);
  const [reposition, setReposition] = useState<number | null>(null);
  const parsed = parseCover(cover);
  const style = parsed.isImage && parsed.url ? { ...parsed.style, backgroundImage: `url("${withShare(parsed.url, shareToken)}")`, backgroundPosition: `center ${reposition ?? parsed.y}%` } : parsed.style;
  return (
    <div
      className={cx("group relative h-[30vh] max-h-[280px] min-h-[140px] w-full", reposition != null && "cursor-ns-resize")}
      style={style}
      onMouseDown={(e) => {
        if (reposition == null) return;
        e.preventDefault();
        const startY = e.clientY;
        const start = reposition;
        const onMove = (ev: MouseEvent) => setReposition(Math.max(0, Math.min(100, start - (ev.clientY - startY) / 3)));
        const onUp = () => {
          window.removeEventListener("mousemove", onMove);
          window.removeEventListener("mouseup", onUp);
        };
        window.addEventListener("mousemove", onMove);
        window.addEventListener("mouseup", onUp);
      }}
    >
      {editable && (
        <div className={cx("absolute bottom-3 right-4 flex gap-1 text-xs", reposition != null ? "opacity-100" : "opacity-0 group-hover:opacity-100")}>
          {reposition != null ? (
            <>
              <span className="rounded bg-black/50 px-2 py-1 text-white">Drag the image to reposition</span>
              <button
                className="rounded bg-white/90 px-2 py-1 text-black hover:bg-white"
                onClick={() => {
                  onChange(`${parsed.url}#y=${Math.round(reposition)}`);
                  setReposition(null);
                }}
              >
                Save position
              </button>
              <button className="rounded bg-white/90 px-2 py-1 text-black hover:bg-white" onClick={() => setReposition(null)}>
                Cancel
              </button>
            </>
          ) : (
            <>
              <button className="rounded bg-white/90 px-2 py-1 text-black hover:bg-white" onClick={(e) => setPicker(e.currentTarget)}>
                Change cover
              </button>
              {parsed.isImage && (
                <button className="rounded bg-white/90 px-2 py-1 text-black hover:bg-white" onClick={() => setReposition(parsed.y)}>
                  Reposition
                </button>
              )}
            </>
          )}
        </div>
      )}
      <CoverPicker anchor={picker} onClose={() => setPicker(null)} workspaceId={workspaceId} onChange={onChange} />
    </div>
  );
}

export function CoverPicker({ anchor, onClose, workspaceId, onChange }: { anchor: HTMLElement | null; onClose: () => void; workspaceId: string; onChange: (c: string | null) => void }) {
  const { toast } = useUi();
  const [url, setUrl] = useState("");
  return (
    <Popover anchor={anchor} open={!!anchor} onClose={onClose} placement="bottom-end">
      <div className="w-[360px] p-3">
        <div className="mb-2 flex items-center justify-between text-xs font-medium text-muted">
          <span>Gradients</span>
          <button
            className="link-btn"
            onClick={() => {
              onChange(null);
              onClose();
            }}
          >
            Remove
          </button>
        </div>
        <div className="grid grid-cols-6 gap-1.5">
          {GRADIENTS.map((g, i) => (
            <button key={i} className="h-10 rounded" style={{ background: g }} onClick={() => (onChange(`gradient:${i}`), onClose())} aria-label={`Gradient ${i + 1}`} />
          ))}
        </div>
        <div className="mb-2 mt-3 text-xs font-medium text-muted">Colors</div>
        <div className="grid grid-cols-10 gap-1.5">
          {SOLIDS.map((c) => (
            <button key={c} className="h-6 rounded border border-line" style={{ background: c }} onClick={() => (onChange(`color:${c}`), onClose())} aria-label={c} />
          ))}
        </div>
        <div className="mb-2 mt-3 text-xs font-medium text-muted">Image</div>
        <div className="flex gap-2">
          <button
            className="btn btn-sm"
            onClick={async () => {
              const f = await pickFile("image/*");
              if (!f) return;
              try {
                const u = await uploadFile(workspaceId, f);
                onChange(u.url);
                onClose();
              } catch (e) {
                toast(errorMessage(e), "error");
              }
            }}
          >
            Upload
          </button>
          <form
            className="flex flex-1 gap-1"
            onSubmit={(e) => {
              e.preventDefault();
              if (/^https?:\/\//.test(url)) {
                onChange(url);
                onClose();
              }
            }}
          >
            <input className="input h-7 flex-1" placeholder="Paste an image link…" value={url} onChange={(e) => setUrl(e.target.value)} />
          </form>
        </div>
      </div>
    </Popover>
  );
}
