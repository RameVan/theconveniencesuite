"use client";
import { useState } from "react";
import useSWR, { mutate } from "swr";
import { api, errorMessage } from "@/client/api";
import { Dialog, useUi, Spinner, cx } from "@/client/ui";
import { ReadOnlyBlocks } from "../read-only-blocks";
import type { PMNode } from "@/lib/blocks";

interface Rev {
  id: string;
  createdAt: string;
  reason: string;
  userName: string | null;
}

const REASONS: Record<string, string> = {
  autosave: "Edited",
  restore: "Restored a version",
  "before-restore": "Before restore",
  conflict: "Conflicting edit (saved for you)",
  manual: "Saved",
};

export function HistoryDialog({ open, onClose, pageId, canRestore, onRestored }: { open: boolean; onClose: () => void; pageId: string; canRestore: boolean; onRestored?: () => void }) {
  const { toast, confirm } = useUi();
  const { data } = useSWR<{ revisions: Rev[] }>(open ? `/api/pages/${pageId}/revisions` : null);
  const [picked, setPicked] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  // Default to the newest revision until the user picks one.
  const selected = picked && data?.revisions.some((r) => r.id === picked) ? picked : (data?.revisions[0]?.id ?? null);
  const { data: rev, error } = useSWR<{ revision: { snapshot: { title: string; blocks: PMNode[] } } }>(open && selected ? `/api/pages/${pageId}/revisions/${selected}` : null, {
    revalidateOnFocus: false,
  });
  const snap = rev?.revision.snapshot;

  return (
    <Dialog open={open} onClose={onClose} title="Page history" width={1000}>
      <div className="flex h-[70vh] flex-col-reverse sm:flex-row">
        <div className="min-h-0 flex-1 overflow-y-auto p-8">
          {error ? (
            <p className="text-sm text-danger">{errorMessage(error)}</p>
          ) : !snap ? (
            data?.revisions.length === 0 ? null : (
              <div className="flex justify-center p-10">
                <Spinner />
              </div>
            )
          ) : (
            <>
              <h1 className="mb-4 text-3xl font-bold">{snap.title || "Untitled"}</h1>
              <ReadOnlyBlocks blocks={snap.blocks} />
            </>
          )}
        </div>
        <div className="flex max-h-[40%] flex-none flex-col border-b border-line sm:max-h-none sm:w-72 sm:border-b-0 sm:border-l">
          <div className="flex-1 overflow-y-auto p-2">
            {!data && <Spinner />}
            {data?.revisions.length === 0 && <p className="p-3 text-sm text-muted">No history yet. Versions are saved automatically as you edit.</p>}
            {data?.revisions.map((r) => (
              <button key={r.id} onClick={() => setPicked(r.id)} className={cx("w-full rounded-md px-3 py-2 text-left text-sm", selected === r.id ? "bg-active" : "hover:bg-hover")}>
                <div className="font-medium">{new Date(r.createdAt).toLocaleString()}</div>
                <div className="text-xs text-muted">
                  {REASONS[r.reason] ?? r.reason}
                  {r.userName ? ` · ${r.userName}` : ""}
                </div>
              </button>
            ))}
          </div>
          {canRestore && (
            <div className="border-t border-line p-3">
              <button
                className="btn btn-primary w-full"
                disabled={!selected || busy}
                onClick={async () => {
                  if (!(await confirm({ title: "Restore this version?", message: "The current version is saved to history first, so you can undo this.", confirmLabel: "Restore" }))) return;
                  setBusy(true);
                  try {
                    await api.post(`/api/pages/${pageId}/revisions/${selected}`);
                    mutate(`/api/pages/${pageId}/revisions`);
                    onRestored?.();
                    toast("Version restored");
                    onClose();
                  } catch (e) {
                    toast(errorMessage(e), "error");
                  } finally {
                    setBusy(false);
                  }
                }}
              >
                Restore version
              </button>
            </div>
          )}
        </div>
      </div>
    </Dialog>
  );
}
