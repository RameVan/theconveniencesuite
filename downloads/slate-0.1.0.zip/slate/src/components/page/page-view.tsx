"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { mutate } from "swr";
import { Smile, ImageIcon, MessageSquare, Trash2, Undo2 } from "lucide-react";
import { usePage, useTree, refreshTree, useMe } from "@/client/hooks";
import { useCollab, usePeers } from "../editor/use-collab";
import { yDocToProsemirrorJSON } from "@tiptap/y-tiptap";
import { YDOC_FIELD } from "@/lib/editor-schema";
import { useWorkspace } from "@/client/workspace-context";
import { api, errorMessage } from "@/client/api";
import { uploadFile, pickFile } from "@/client/upload";
import { Popover, useUi, cx } from "@/client/ui";
import { BlockEditor, type EditorHandle, type SaveStatus } from "../editor/editor";
import { EditorEnvContext, type EditorEnv } from "../editor/context";
import { PageLookupContext, type PageInfo } from "../editor/lookup";
import { slashHooks } from "../editor/slash-menu";
import { mentionScope } from "../editor/mention";
import { EmojiPicker, randomEmoji } from "../emoji-picker";
import { PageIcon } from "../page-icon";
import { Cover, CoverPicker } from "./cover";
import { TopBar } from "./top-bar";
import { CommentsPanel, useThreads, type Draft } from "./comments";
import { removeCommentMark, revealCommentMark, threadIdsAt } from "../editor/comment-marks";
import { RecordProperties } from "../database/record-properties";
import { DatabaseView } from "../database/database-view";
import type { PageResponse } from "@/client/types";

export function PageView({ pageId }: { pageId: string }) {
  const ws = useWorkspace();
  const router = useRouter();
  const search = useSearchParams();
  const { toast, confirm } = useUi();
  const { data, error, mutate: mutatePage } = usePage(pageId);
  const { data: tree } = useTree(ws.workspace.id);
  const [status, setStatus] = useState<SaveStatus>("saved");
  const [commentsOpen, setCommentsOpen] = useState(false);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [activeThread, setActiveThread] = useState<string | null>(null);
  const editorRef = useRef<EditorHandle>(null);
  const threads = useThreads(pageId);
  // Highlight anchors of open threads (and the one being written); thread ids are [A-Za-z0-9_-].
  const anchorCss = useMemo(() => {
    const open = (threads?.threads ?? []).filter((t) => t.root.quote && !t.root.resolved).map((t) => t.root.id);
    if (draft) open.push(draft.threadId);
    const sel = (ids: string[]) => ids.filter((id) => /^[A-Za-z0-9_-]+$/.test(id)).map((id) => `.slate-editor span[data-thread="${id}"]`).join(",");
    const all = sel(open);
    const active = activeThread && open.includes(activeThread) ? sel([activeThread]) : "";
    return (all ? `${all}{background:rgba(255,212,0,.22);border-bottom:2px solid rgba(230,180,0,.75);cursor:pointer}` : "") + (active ? `${active}{background:rgba(255,212,0,.5)}` : "");
  }, [threads, draft, activeThread]);

  // Deep link from a notification: ?thread=<comment id> opens that thread.
  const threadParam = search.get("thread");
  const [handledThread, setHandledThread] = useState<string | null>(null);
  if (threadParam && handledThread !== threadParam && threads) {
    setHandledThread(threadParam);
    const c = threads.byId.get(threadParam);
    if (c) {
      setCommentsOpen(true);
      setActiveThread(c.parentId ?? c.id);
    }
  }
  useEffect(() => {
    // Scroll to the linked thread's anchor once the editor has rendered.
    if (!handledThread || !activeThread) return;
    const t = setTimeout(() => {
      const ed = editorRef.current?.editor;
      if (ed) revealCommentMark(ed, activeThread);
    }, 300);
    return () => clearTimeout(t);
  }, [handledThread]); // eslint-disable-line react-hooks/exhaustive-deps

  const finishDraft = (d: Draft, saved: boolean) => {
    setDraft(null);
    if (!saved) {
      const ed = editorRef.current?.editor;
      if (ed) removeCommentMark(ed, d.threadId);
    }
  };

  useEffect(() => {
    api.post(`/api/pages/${pageId}/visit`).catch(() => {});
  }, [pageId]);

  const page = data?.page;
  const editable = !!data && (data.access === "edit" || data.access === "full") && !page?.archivedAt;
  const { data: me } = useMe();
  // Realtime co-editing for regular pages; falls back to versioned REST saves if unavailable.
  const collab = useCollab(pageId, {
    enabled: !!page && page.kind === "page" && !page.archivedAt && !!me?.realtime,
    realtime: me?.realtime ?? null,
    user: { id: ws.me.id, name: ws.me.name },
  });
  const peers = usePeers(collab.session);
  // The page is editable immediately with REST saves; it switches to the realtime document once
  // that has synced and contains everything typed so far (or a save conflicted with live edits).
  const [liveMode, setLiveMode] = useState(false);
  const [pendingSelection, setPendingSelection] = useState<{ from: number; to: number; focused: boolean } | null>(null);
  useEffect(() => {
    if (collab.status !== "ready" || liveMode) return;
    const session = collab.session;
    // Never swap editors under the user's hands: wait for a short pause in typing / pointer use.
    let lastActivity = Date.now();
    let pointerDown = false;
    const touch = () => (lastActivity = Date.now());
    const down = () => ((pointerDown = true), touch());
    const up = () => ((pointerDown = false), touch());
    document.addEventListener("keydown", touch, true);
    document.addEventListener("pointerdown", down, true);
    document.addEventListener("pointerup", up, true);
    document.addEventListener("dragstart", down, true);
    document.addEventListener("dragend", up, true);
    const check = () => {
      const ed = editorRef.current?.editor;
      if (!ed) return;
      if (pointerDown || Date.now() - lastActivity < 1500) return;
      if (status === "conflict") {
        setLiveMode(true);
        return;
      }
      if (status !== "saved") {
        if (status === "unsaved") editorRef.current?.saveNow();
        return;
      }
      // Compare through the schema so default/omitted attributes serialise the same way.
      let live: string;
      try {
        live = JSON.stringify(ed.schema.nodeFromJSON(yDocToProsemirrorJSON(session.doc, YDOC_FIELD)).toJSON().content ?? []);
      } catch {
        return;
      }
      const local = JSON.stringify(ed.state.doc.toJSON().content ?? []);
      if (live !== local) return;
      const { from, to } = ed.state.selection;
      setPendingSelection({ from, to, focused: ed.isFocused });
      setLiveMode(true);
    };
    const t = setInterval(check, 150);
    return () => {
      clearInterval(t);
      document.removeEventListener("keydown", touch, true);
      document.removeEventListener("pointerdown", down, true);
      document.removeEventListener("pointerup", up, true);
      document.removeEventListener("dragstart", down, true);
      document.removeEventListener("dragend", up, true);
    };
  }, [collab, liveMode, status]);
  const liveSession = liveMode ? collab.session : null;

  // Hooks used by the slash menu and @-mentions.
  useEffect(() => {
    mentionScope.workspaceId = ws.workspace.id;
    slashHooks.createChildPage = async (kind, inline) => {
      try {
        const r = await api.post<{ page: { id: string } }>("/api/pages", {
          workspaceId: ws.workspace.id,
          parentId: pageId,
          kind,
          isInline: inline,
          title: kind === "database" ? "" : "",
        });
        await refreshTree(ws.workspace.id);
        mutatePage();
        return r.page.id;
      } catch (e) {
        toast(errorMessage(e), "error");
        return null;
      }
    };
  }, [ws.workspace.id, pageId, toast, mutatePage]);

  const lookup = useMemo(() => {
    const m = new Map<string, PageInfo>();
    for (const n of tree?.nodes ?? []) m.set(n.id, { title: n.title, icon: n.icon, kind: n.kind });
    for (const c of data?.children ?? []) m.set(c.id, { title: c.title, icon: c.icon, kind: c.kind });
    return { pages: m };
  }, [tree, data?.children]);

  const env = useMemo<EditorEnv | null>(
    () =>
      data
        ? {
            workspaceId: ws.workspace.id,
            pageId,
            editable,
            breadcrumbs: data.breadcrumbs,
            pageTitle: data.page.title,
            navigate: ws.navigate,
            hrefFor: (id) => `/w/${ws.workspace.id}/p/${id}`,
            onComment: (d) => {
              setDraft((prev) => {
                // Starting another draft drops the unsent one's anchor.
                const ed = editorRef.current?.editor;
                if (prev && ed) removeCommentMark(ed, prev.threadId);
                return d;
              });
              setActiveThread(d.threadId);
              setCommentsOpen(true);
            },
          }
        : null,
    [data, ws, pageId, editable],
  );

  const patchPage = useCallback(
    async (patch: Partial<PageResponse["page"]>) => {
      mutatePage((d) => (d ? { ...d, page: { ...d.page, ...patch } } : d), { revalidate: false });
      try {
        await api.patch(`/api/pages/${pageId}`, patch);
        if ("title" in patch || "icon" in patch) refreshTree(ws.workspace.id);
      } catch (e) {
        toast(errorMessage(e), "error");
        mutatePage();
      }
    },
    [pageId, mutatePage, ws.workspace.id, toast],
  );

  const onChildPagesRemoved = useCallback(
    async (ids: string[]) => {
      for (const id of ids) {
        try {
          await api.post(`/api/pages/${id}/archive`);
        } catch {
          /* may already be archived */
        }
      }
      refreshTree(ws.workspace.id);
      toast(ids.length === 1 ? "Sub-page moved to Trash" : `${ids.length} sub-pages moved to Trash`, "info", {
        label: "Undo",
        run: () => {
          editorRef.current?.editor?.commands.undo();
        },
      });
    },
    [ws.workspace.id, toast],
  );
  const onChildPagesRestored = useCallback(
    async (ids: string[]) => {
      for (const id of ids) await api.post(`/api/pages/${id}/restore`).catch(() => {});
      refreshTree(ws.workspace.id);
    },
    [ws.workspace.id],
  );

  if (error)
    return (
      <div className="flex flex-1 flex-col">
        <TopBar data={null} status="saved" />
        <div className="flex flex-1 flex-col items-center justify-center gap-2 p-6 text-center">
          <h1 className="text-lg font-semibold">{error.status === 404 ? "This page doesn’t exist or you don’t have access" : "Could not load this page"}</h1>
          <p className="text-sm text-muted">{errorMessage(error)}</p>
          <button className="btn mt-2" onClick={() => router.push(`/w/${ws.workspace.id}`)}>
            Go to workspace home
          </button>
        </div>
      </div>
    );
  if (!data || !env)
    return (
      <div className="flex flex-1 flex-col">
        <TopBar data={null} status="saved" />
        <div className="mx-auto w-full max-w-[760px] px-6 pt-24">
          <div className="skeleton mb-6 h-10 w-2/3" />
          <div className="skeleton mb-3 h-4 w-full" />
          <div className="skeleton mb-3 h-4 w-5/6" />
          <div className="skeleton h-4 w-2/3" />
        </div>
      </div>
    );

  const isDatabase = data.page.kind === "database";
  const wide = data.page.fullWidth || isDatabase;

  return (
    <EditorEnvContext.Provider value={env}>
      <PageLookupContext.Provider value={lookup}>
        <TopBar
          data={data}
          status={status}
          onToggleComments={() => setCommentsOpen((v) => !v)}
          onPatch={patchPage}
          onSaveNow={() => editorRef.current?.saveNow()}
          onRestored={() => mutatePage()}
          peers={peers}
          live={!!liveSession}
        />
        <div className="flex min-h-0 flex-1">
          <div className="min-w-0 flex-1 overflow-y-auto" id="page-scroll">
            {data.page.archivedAt && (
              <div className="flex flex-wrap items-center justify-center gap-3 bg-danger px-4 py-2 text-sm text-white">
                This page is in the Trash.
                {(data.access === "edit" || data.access === "full") && (
                  <button
                    className="flex items-center gap-1 rounded border border-white/60 px-2 py-0.5 hover:bg-white/10"
                    onClick={async () => {
                      try {
                        await api.post(`/api/pages/${pageId}/restore`);
                        mutatePage();
                        refreshTree(ws.workspace.id);
                      } catch (e) {
                        toast(errorMessage(e), "error");
                      }
                    }}
                  >
                    <Undo2 size={13} /> Restore page
                  </button>
                )}
                {data.access === "full" && (
                  <button
                    className="flex items-center gap-1 rounded border border-white/60 px-2 py-0.5 hover:bg-white/10"
                    onClick={async () => {
                      if (!(await confirm({ title: "Delete permanently?", message: "This cannot be undone.", danger: true, confirmLabel: "Delete" }))) return;
                      await api.del(`/api/pages/${pageId}`).catch((e) => toast(errorMessage(e), "error"));
                      router.push(`/w/${ws.workspace.id}`);
                    }}
                  >
                    <Trash2 size={13} /> Delete permanently
                  </button>
                )}
              </div>
            )}
            {data.page.cover && <Cover cover={data.page.cover} editable={editable} workspaceId={ws.workspace.id} onChange={(c) => patchPage({ cover: c })} />}
            <div className={cx("mx-auto w-full", isDatabase ? "px-4 sm:px-8 lg:px-12" : "px-6 sm:px-12 lg:px-24", wide ? "max-w-none" : "max-w-[900px]")}>
              <PageHeader data={data} editable={editable} onPatch={patchPage} autoFocus={search.get("new") === "1"} onEnter={() => editorRef.current?.focusStart()} onOpenComments={() => setCommentsOpen(true)} />
              {data.record && <RecordProperties pageId={pageId} record={data.record} editable={editable} onChanged={() => mutatePage()} />}
            </div>
            {isDatabase ? (
              <div className="px-4 pb-24 sm:px-8 lg:px-12">
                <DatabaseView databaseId={pageId} full />
              </div>
            ) : (
              <div
                className={cx("mx-auto w-full px-6 pb-16 sm:px-12 lg:px-24", wide ? "max-w-none" : "max-w-[900px]")}
                onClick={(e) => {
                  // Clicking highlighted text opens its comment thread.
                  const known = threadIdsAt(e.target).filter((id) => threads?.byId.get(id)?.quote && !threads.byId.get(id)?.resolved);
                  if (!known.length) return;
                  setActiveThread(known[0]);
                  setCommentsOpen(true);
                }}
              >
                {anchorCss && <style>{anchorCss}</style>}
                <BlockEditor
                  key={liveSession ? "live" : "rest"}
                  collab={liveSession}
                  restoreSelection={liveSession ? pendingSelection : null}
                  ref={editorRef}
                  pageId={pageId}
                  workspaceId={ws.workspace.id}
                  content={data.content}
                  version={data.page.version}
                  editable={editable}
                  smallText={data.page.smallText}
                  onStatus={setStatus}
                  onRemoteChange={() => mutatePage()}
                  onChildPagesRemoved={onChildPagesRemoved}
                  onChildPagesRestored={onChildPagesRestored}
                />
                {status === "conflict" && (
                  <div className="fixed bottom-6 left-1/2 z-30 flex -translate-x-1/2 items-center gap-3 rounded-lg bg-[#2f2d29] px-4 py-3 text-sm text-white shadow-lg">
                    Someone else changed this page. Your latest edits were kept in page history.
                    <button
                      className="rounded bg-white px-2 py-1 text-black"
                      onClick={async () => {
                        await mutatePage();
                        setStatus("saved");
                        mutate(`/api/pages/${pageId}/revisions`);
                      }}
                    >
                      Load latest
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
          {commentsOpen && (
            <CommentsPanel
              pageId={pageId}
              onClose={() => {
                if (draft) finishDraft(draft, false);
                setCommentsOpen(false);
                setActiveThread(null);
              }}
              draft={draft}
              onDraftDone={finishDraft}
              activeThread={activeThread}
              onSelectThread={(id) => {
                setActiveThread(id);
                const ed = editorRef.current?.editor;
                if (id && ed) revealCommentMark(ed, id);
              }}
            />
          )}
        </div>
      </PageLookupContext.Provider>
    </EditorEnvContext.Provider>
  );
}

function PageHeader({ data, editable, onPatch, autoFocus, onEnter, onOpenComments }: { data: PageResponse; editable: boolean; onPatch: (p: Partial<PageResponse["page"]>) => void; autoFocus: boolean; onEnter: () => void; onOpenComments: () => void }) {
  const ws = useWorkspace();
  const { toast } = useUi();
  const page = data.page;
  const [title, setTitle] = useState(page.title);
  const [iconAnchor, setIconAnchor] = useState<HTMLElement | null>(null);
  const [coverAnchor, setCoverAnchor] = useState<HTMLElement | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const ref = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (document.activeElement !== ref.current) setTitle(page.title);
  }, [page.title]);
  useEffect(() => {
    if (autoFocus && editable) ref.current?.focus();
  }, [autoFocus, editable]);
  // Auto-size the title to its content, including when the column width changes.
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const fit = () => {
      el.style.height = "auto";
      el.style.height = `${el.scrollHeight}px`;
    };
    fit();
    let width = el.clientWidth;
    const ro = new ResizeObserver(() => {
      if (el.clientWidth === width) return; // only react to width changes, not our own height updates
      width = el.clientWidth;
      fit();
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, [title]);
  useEffect(() => {
    document.title = `${page.title || "Untitled"} · Slate`;
  }, [page.title]);

  const commit = (t: string) => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => onPatch({ title: t }), 400);
  };

  return (
    <div className={cx("group", page.cover ? "pt-4" : "pt-16 sm:pt-20")}>
      {page.icon && (
        <button
          className={cx("mb-2 flex h-[78px] w-[78px] items-center justify-center rounded-lg text-[64px] leading-none", editable && "hover:bg-hover", page.cover && "-mt-12 relative z-10")}
          onClick={(e) => editable && setIconAnchor(e.currentTarget)}
          aria-label="Change icon"
        >
          <PageIcon icon={page.icon} size={68} />
        </button>
      )}
      {editable && (
        <div className="mb-1 flex h-7 gap-1 text-sm text-muted opacity-0 transition-opacity group-hover:opacity-100 focus-within:opacity-100">
          {!page.icon && (
            <button className="link-btn flex items-center gap-1" onClick={() => onPatch({ icon: randomEmoji() })}>
              <Smile size={14} /> Add icon
            </button>
          )}
          {!page.cover && (
            <button className="link-btn flex items-center gap-1" onClick={(e) => setCoverAnchor(e.currentTarget)}>
              <ImageIcon size={14} /> Add cover
            </button>
          )}
          {!data.record && (
            <button className="link-btn flex items-center gap-1" onClick={onOpenComments}>
              <MessageSquare size={14} /> Add comment
            </button>
          )}
        </div>
      )}
      <textarea
        ref={ref}
        rows={1}
        value={title}
        readOnly={!editable}
        placeholder={page.kind === "database" ? "Untitled database" : "Untitled"}
        aria-label="Page title"
        onChange={(e) => {
          setTitle(e.target.value);
          commit(e.target.value);
        }}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            onPatch({ title });
            if (page.kind === "page") onEnter();
          }
        }}
        className={cx("w-full resize-none overflow-hidden bg-transparent font-bold leading-tight outline-none placeholder:text-faint", page.kind === "database" ? "text-3xl" : "text-[40px]")}
      />
      <Popover anchor={iconAnchor} open={!!iconAnchor} onClose={() => setIconAnchor(null)}>
        <EmojiPicker
          onSelect={(e) => {
            onPatch({ icon: e });
            setIconAnchor(null);
          }}
          onRemove={() => {
            onPatch({ icon: null });
            setIconAnchor(null);
          }}
          onUpload={async () => {
            const f = await pickFile("image/*");
            if (!f) return;
            try {
              const u = await uploadFile(ws.workspace.id, f);
              onPatch({ icon: u.url });
              setIconAnchor(null);
            } catch (e) {
              toast(errorMessage(e), "error");
            }
          }}
        />
      </Popover>
      <CoverPicker anchor={coverAnchor} onClose={() => setCoverAnchor(null)} workspaceId={ws.workspace.id} onChange={(c) => onPatch({ cover: c })} />
    </div>
  );
}

