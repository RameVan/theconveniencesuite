"use client";
import { useState } from "react";
import useSWR, { mutate } from "swr";
import { Globe, Lock, Users, Copy, X } from "lucide-react";
import { api, errorMessage } from "@/client/api";
import { useUi, Spinner, cx } from "@/client/ui";
import { useWorkspace } from "@/client/workspace-context";
import { refreshTree } from "@/client/hooks";

interface Sharing {
  access: "view" | "edit" | "full";
  isPrivate: boolean;
  canChangeVisibility: boolean;
  grants: { userId: string; name: string; email: string; access: "none" | "view" | "edit" | "full" }[];
  publicSharingEnabled: boolean;
  publicToken: string | null;
}

const ACCESS_LABEL = { full: "Full access", edit: "Can edit", view: "Can view", none: "No access" } as const;

export function SharePanel({ pageId }: { pageId: string }) {
  const ws = useWorkspace();
  const { toast } = useUi();
  const key = `/api/pages/${pageId}/sharing`;
  const { data } = useSWR<Sharing>(key);
  const [email, setEmail] = useState("");
  const [access, setAccess] = useState<"view" | "edit" | "full">("edit");
  if (!data)
    return (
      <div className="flex w-[420px] justify-center p-6">
        <Spinner />
      </div>
    );
  const isFull = data.access === "full";
  const publicUrl = data.publicToken ? `${location.origin}/share/${data.publicToken}` : null;

  const grant = async (em: string, acc: Sharing["grants"][number]["access"] | null) => {
    try {
      await api.put(key, { email: em, access: acc });
      mutate(key);
    } catch (e) {
      toast(errorMessage(e), "error");
    }
  };

  return (
    <div className="w-[min(440px,92vw)] p-4 text-sm">
      {isFull && (
        <form
          className="mb-4 flex gap-2"
          onSubmit={async (e) => {
            e.preventDefault();
            if (!email.trim()) return;
            await grant(email.trim(), access);
            setEmail("");
          }}
        >
          <input className="input min-w-0 flex-1" type="email" placeholder="Add people by email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <select className="input" value={access} onChange={(e) => setAccess(e.target.value as "view")}>
            <option value="full">Full access</option>
            <option value="edit">Can edit</option>
            <option value="view">Can view</option>
          </select>
          <button className="btn btn-primary">Invite</button>
        </form>
      )}
      <div className="space-y-2">
        <div className="flex items-center gap-3">
          {data.isPrivate ? <Lock size={18} className="text-muted" /> : <Users size={18} className="text-muted" />}
          <div className="flex-1">
            <div className="font-medium">{data.isPrivate ? "Private" : `Everyone at ${ws.workspace.name}`}</div>
            <div className="text-xs text-muted">{data.isPrivate ? "Only you and people you invite" : "Access follows each member's workspace role"}</div>
          </div>
          {data.canChangeVisibility && (
            <button
              className="btn btn-sm"
              onClick={async () => {
                try {
                  await api.patch(`/api/pages/${pageId}`, { visibility: data.isPrivate ? "workspace" : "private" });
                  mutate(key);
                  mutate(`/api/pages/${pageId}`);
                  refreshTree(ws.workspace.id);
                } catch (e) {
                  toast(errorMessage(e), "error");
                }
              }}
            >
              {data.isPrivate ? "Share with workspace" : "Make private"}
            </button>
          )}
        </div>
        {data.grants.map((g) => (
          <div key={g.userId} className="flex items-center gap-3">
            <span className="flex h-[18px] w-[18px] items-center justify-center rounded-full bg-subtle text-[10px] font-medium">{g.name.slice(0, 1).toUpperCase()}</span>
            <div className="min-w-0 flex-1">
              <div className="truncate">{g.name}</div>
              <div className="truncate text-xs text-muted">{g.email}</div>
            </div>
            {isFull ? (
              <>
                <select className="input h-7 text-xs" value={g.access} onChange={(e) => grant(g.email, e.target.value as "view")}>
                  {(["full", "edit", "view", "none"] as const).map((a) => (
                    <option key={a} value={a}>
                      {ACCESS_LABEL[a]}
                    </option>
                  ))}
                </select>
                <button className="icon-btn" title="Remove" onClick={() => grant(g.email, null)}>
                  <X size={14} />
                </button>
              </>
            ) : (
              <span className="text-xs text-muted">{ACCESS_LABEL[g.access]}</span>
            )}
          </div>
        ))}
      </div>
      <div className="mt-4 border-t border-line pt-4">
        <div className="flex items-center gap-3">
          <Globe size={18} className={cx(publicUrl ? "text-accent" : "text-muted")} />
          <div className="flex-1">
            <div className="font-medium">Publish to web</div>
            <div className="text-xs text-muted">{data.publicSharingEnabled ? "Anyone with the link can view this page and its sub-pages" : "Disabled by the server administrator"}</div>
          </div>
          {isFull && data.publicSharingEnabled && (
            <button
              role="switch"
              aria-checked={!!publicUrl}
              className={cx("relative h-5 w-9 rounded-full transition-colors", publicUrl ? "bg-accent" : "bg-line-strong")}
              onClick={async () => {
                try {
                  await api.put(`/api/pages/${pageId}/public`, { enabled: !publicUrl });
                  mutate(key);
                } catch (e) {
                  toast(errorMessage(e), "error");
                }
              }}
            >
              <span className={cx("absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all", publicUrl ? "left-[18px]" : "left-0.5")} />
            </button>
          )}
        </div>
        {publicUrl && (
          <div className="mt-2 flex gap-2">
            <input className="input h-7 flex-1 text-xs" readOnly value={publicUrl} onFocus={(e) => e.target.select()} />
            <button className="btn btn-sm" onClick={() => navigator.clipboard?.writeText(publicUrl).then(() => toast("Link copied"))}>
              <Copy size={13} /> Copy
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
