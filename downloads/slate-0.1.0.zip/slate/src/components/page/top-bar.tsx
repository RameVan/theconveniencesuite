"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { mutate } from "swr";
import { Menu as MenuIcon, Star, MessageSquare, Clock, MoreHorizontal, Link2, Copy, Trash2, Download, Maximize2, Type, Check, Cloud, CloudOff, AlertTriangle, Loader2, Keyboard } from "lucide-react";
import { useWorkspace } from "@/client/workspace-context";
import { refreshTree } from "@/client/hooks";
import { api, errorMessage } from "@/client/api";
import { MenuButton, Popover, useUi, cx, modKey, downloadUrl } from "@/client/ui";
import { PageIcon, pageTitle } from "../page-icon";
import { SharePanel } from "./share";
import { HistoryDialog } from "./history";
import { ShortcutsDialog } from "../search-dialog";
import type { PageResponse } from "@/client/types";
import type { SaveStatus } from "../editor/editor";

export function TopBar({
  data,
  status,
  onToggleComments,
  onPatch,
  onSaveNow,
  onRestored,
  peers = [],
  live = false,
}: {
  data: PageResponse | null;
  status: SaveStatus;
  onToggleComments?: () => void;
  onPatch?: (p: Partial<PageResponse["page"]>) => void;
  onSaveNow?: () => void;
  onRestored?: () => void;
  peers?: { clientId: number; name: string; color: string }[];
  live?: boolean;
}) {
  const ws = useWorkspace();
  const router = useRouter();
  const { toast } = useUi();
  const [shareAnchor, setShareAnchor] = useState<HTMLElement | null>(null);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [shortcuts, setShortcuts] = useState(false);
  const page = data?.page;
  const canEdit = data?.access === "edit" || data?.access === "full";

  const toggleFavorite = async () => {
    if (!page) return;
    try {
      await (data!.favorite ? api.del(`/api/pages/${page.id}/favorite`) : api.put(`/api/pages/${page.id}/favorite`));
      mutate(`/api/pages/${page.id}`);
      refreshTree(ws.workspace.id);
    } catch (e) {
      toast(errorMessage(e), "error");
    }
  };

  return (
    <header className="flex h-11 flex-none items-center gap-1 px-2 text-sm">
      {!ws.sidebarOpen && (
        <button className="icon-btn" onClick={ws.toggleSidebar} aria-label="Open sidebar" title={`Open sidebar (${modKey()}+\\)`}>
          <MenuIcon size={18} />
        </button>
      )}
      <nav aria-label="Breadcrumb" className="flex min-w-0 flex-1 items-center gap-0.5 overflow-hidden">
        {data?.breadcrumbs.map((b, i) => (
          <span key={b.id} className={cx("flex min-w-0 items-center gap-0.5", i < data.breadcrumbs.length - 2 && "hidden md:flex")}>
            <Link href={`/w/${ws.workspace.id}/p/${b.id}`} className="flex min-w-0 items-center gap-1.5 rounded px-1.5 py-0.5 hover:bg-hover">
              <PageIcon icon={b.icon} kind={b.kind} size={14} />
              <span className="max-w-[160px] truncate">{pageTitle(b.title)}</span>
            </Link>
            <span className="text-faint">/</span>
          </span>
        ))}
        {page && (
          <span className="flex min-w-0 items-center gap-1.5 px-1.5">
            <PageIcon icon={page.icon} kind={page.kind} size={14} />
            <span className="truncate">{pageTitle(page.title)}</span>
            {page.visibility === "private" && !page.parentId && <span className="rounded bg-subtle px-1.5 text-[11px] text-muted">Private</span>}
          </span>
        )}
      </nav>
      {peers.length > 0 && (
        <div className="mr-1 flex -space-x-1.5" aria-label={`Also here: ${peers.map((p) => p.name).join(", ")}`}>
          {peers.slice(0, 5).map((p) => (
            <span key={p.clientId} title={p.name} className="flex h-6 w-6 items-center justify-center rounded-full border-2 border-bg text-[11px] font-semibold text-white" style={{ background: p.color }}>
              {p.name.slice(0, 1).toUpperCase()}
            </span>
          ))}
          {peers.length > 5 && <span className="flex h-6 items-center pl-2 text-xs text-muted">+{peers.length - 5}</span>}
        </div>
      )}
      {page && <SaveIndicator status={status} canEdit={canEdit} updatedAt={page.updatedAt} live={live} />}
      {page && (
        <>
          <button className="btn btn-ghost btn-sm" onClick={(e) => setShareAnchor(e.currentTarget)}>
            Share
          </button>
          <button className="icon-btn" title="Comments" aria-label="Comments" onClick={onToggleComments}>
            <MessageSquare size={16} />
          </button>
          <button className="icon-btn hidden sm:inline-flex" title="Page history" aria-label="Page history" onClick={() => setHistoryOpen(true)}>
            <Clock size={16} />
          </button>
          <button className="icon-btn" title={data!.favorite ? "Remove from Favorites" : "Add to Favorites"} aria-label="Favorite" aria-pressed={data!.favorite} onClick={toggleFavorite}>
            <Star size={16} className={data!.favorite ? "fill-[#e9b730] text-[#e9b730]" : ""} />
          </button>
          <MenuButton
            className="icon-btn"
            title="More actions"
            placement="bottom-end"
            width={250}
            items={() => [
              ...(canEdit && page.kind === "page"
                ? [
                    { label: "Small text", icon: <Type size={15} />, checked: page.smallText, onSelect: () => onPatch?.({ smallText: !page.smallText }) },
                    { label: "Full width", icon: <Maximize2 size={15} />, checked: page.fullWidth, onSelect: () => onPatch?.({ fullWidth: !page.fullWidth }) },
                    { divider: true, label: "" },
                  ]
                : []),
              {
                label: "Copy link",
                icon: <Link2 size={15} />,
                onSelect: () => {
                  navigator.clipboard?.writeText(`${location.origin}/w/${ws.workspace.id}/p/${page.id}`);
                  toast("Link copied");
                },
              },
              {
                label: "Duplicate",
                icon: <Copy size={15} />,
                onSelect: async () => {
                  try {
                    const r = await api.post<{ page: { id: string } }>(`/api/pages/${page.id}/duplicate`);
                    await refreshTree(ws.workspace.id);
                    router.push(`/w/${ws.workspace.id}/p/${r.page.id}`);
                  } catch (e) {
                    toast(errorMessage(e), "error");
                  }
                },
              },
              { label: "Page history", icon: <Clock size={15} />, onSelect: () => setHistoryOpen(true) },
              {
                label: "Export",
                icon: <Download size={15} />,
                submenu: [
                  { label: "Markdown (.md)", onSelect: () => downloadUrl(`/api/pages/${page.id}/export?format=md`) },
                  { label: "HTML (.html)", onSelect: () => downloadUrl(`/api/pages/${page.id}/export?format=html`) },
                  { label: "With sub-pages (.zip)", onSelect: () => downloadUrl(`/api/pages/${page.id}/export?format=md&subpages=1`) },
                  ...(page.kind === "database" ? [{ label: "Database as CSV", onSelect: () => downloadUrl(`/api/databases/${page.id}/export`) }] : []),
                ],
              },
              ...(canEdit && status !== "saved" ? [{ label: "Save now", icon: <Check size={15} />, hint: `${modKey()}S`, onSelect: () => onSaveNow?.() }] : []),
              { label: "Keyboard shortcuts", icon: <Keyboard size={15} />, onSelect: () => setShortcuts(true) },
              ...(canEdit && !page.archivedAt
                ? [
                    { divider: true, label: "" },
                    {
                      label: "Move to Trash",
                      icon: <Trash2 size={15} />,
                      danger: true,
                      onSelect: async () => {
                        try {
                          await api.post(`/api/pages/${page.id}/archive`);
                          refreshTree(ws.workspace.id);
                          mutate(`/api/pages/${page.id}`);
                          toast("Moved to Trash", "info", {
                            label: "Undo",
                            run: async () => {
                              await api.post(`/api/pages/${page.id}/restore`);
                              refreshTree(ws.workspace.id);
                              mutate(`/api/pages/${page.id}`);
                            },
                          });
                        } catch (e) {
                          toast(errorMessage(e), "error");
                        }
                      },
                    },
                  ]
                : []),
              { divider: true, label: "" },
              { label: `Last edited ${new Date(page.updatedAt).toLocaleString()}`, heading: true },
            ]}
          >
            <MoreHorizontal size={16} />
          </MenuButton>
          <Popover anchor={shareAnchor} open={!!shareAnchor} onClose={() => setShareAnchor(null)} placement="bottom-end">
            <SharePanel pageId={page.id} />
          </Popover>
          <HistoryDialog open={historyOpen} onClose={() => setHistoryOpen(false)} pageId={page.id} canRestore={canEdit} onRestored={onRestored} />
          <ShortcutsDialog open={shortcuts} onClose={() => setShortcuts(false)} />
        </>
      )}
    </header>
  );
}

function SaveIndicator({ status, canEdit, updatedAt, live }: { status: SaveStatus; canEdit: boolean; updatedAt: string; live: boolean }) {
  if (!canEdit) return <span className="mr-2 hidden text-xs text-faint sm:inline">View only</span>;
  const map: Record<SaveStatus, [React.ReactNode, string]> = {
    saved: [<Cloud key="i" size={13} />, live ? "Live" : "Saved"],
    saving: [<Loader2 key="i" size={13} className="animate-spin" />, "Saving…"],
    unsaved: [<Loader2 key="i" size={13} />, "Editing"],
    offline: [<CloudOff key="i" size={13} />, "Offline – will retry"],
    conflict: [<AlertTriangle key="i" size={13} />, "Changed elsewhere"],
    error: [<AlertTriangle key="i" size={13} />, "Not saved"],
  };
  const [icon, label] = map[status];
  return (
    <span className={cx("mr-1 hidden items-center gap-1 text-xs sm:flex", status === "error" || status === "conflict" ? "text-danger" : "text-faint")} title={`Last saved ${new Date(updatedAt).toLocaleString()}`} aria-live="polite">
      {icon} {label}
    </span>
  );
}
