"use client";
import { useMemo } from "react";
import { useEditor, EditorContent } from "@tiptap/react";
import { buildExtensions } from "./editor/extensions";
import type { PMNode } from "@/lib/blocks";

/** Renders blocks with the same schema as the editor, without editing. */
export function ReadOnlyBlocks({ blocks, smallText }: { blocks: PMNode[]; smallText?: boolean }) {
  const extensions = useMemo(() => buildExtensions({ onSave: () => {}, editable: false }), []);
  const editor = useEditor(
    {
      extensions,
      editable: false,
      immediatelyRender: false,
      content: { type: "doc", content: blocks.length ? blocks : [{ type: "paragraph" }] },
    },
    [JSON.stringify(blocks)],
  );
  return (
    <div className={`slate-editor ${smallText ? "small-text" : ""}`}>
      <EditorContent editor={editor} />
    </div>
  );
}
