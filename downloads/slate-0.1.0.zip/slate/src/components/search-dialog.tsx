"use client";
import { useEffect, useMemo, useState } from "react";
import useSWR from "swr";
import { Command } from "cmdk";
import { useRouter } from "next/navigation";
import { Database, Plus, Moon, Settings, Trash2, LayoutTemplate, Upload, Download, PanelLeft, Keyboard, Clock } from "lucide-react";
import { useWorkspace } from "@/client/workspace-context";
import { api } from "@/client/api";
import { Dialog, cx, Kbd, modKey, downloadUrl } from "@/client/ui";
import { applyTheme } from "@/client/providers";
import { PageIcon, pageTitle } from "./page-icon";

interface Result {
  id: string;
  title: string;
  icon: string | null;
  kind: "page" | "database";
  type: "page" | "database" | "record";
  snippet: string | null;
  path: string[];
  matchedIn: string;
}

const TYPES = [
  { key: null, label: "All" },
  { key: "page", label: "Pages" },
  { key: "database", label: "Databases" },
  { key: "record", label: "Records" },
] as const;

export function SearchDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [showShortcuts, setShowShortcuts] = useState(false);
  return (
    <>
      <Dialog open={open} onClose={onClose} width={640} bare align="top" title="Search">
        {open && <SearchBody onClose={onClose} onShortcuts={() => setShowShortcuts(true)} />}
      </Dialog>
      <ShortcutsDialog open={showShortcuts} onClose={() => setShowShortcuts(false)} />
    </>
  );
}

function useDebounced<T>(value: T, ms: number): T {
  const [v, setV] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setV(value), ms);
    return () => clearTimeout(t);
  }, [value, ms]);
  return v;
}

interface Cmd {
  label: string;
  icon: typeof Plus;
  hint?: string;
  run: () => void;
}

function SearchBody({ onClose, onShortcuts }: { onClose: () => void; onShortcuts: () => void }) {
  const ws = useWorkspace();
  const router = useRouter();
  const [q, setQ] = useState("");
  const [type, setType] = useState<string | null>(null);
  const dq = useDebounced(q, 140);
  const params = new URLSearchParams({ q: dq, workspaceId: ws.workspace.id, limit: "40" });
  if (type) params.set("type", type);
  const { data, isLoading } = useSWR<{ results: Result[] }>(`/api/search?${params}`, (url: string) => api.get<{ results: Result[] }>(url), {
    keepPreviousData: true,
    revalidateOnFocus: false,
  });
  const results = data?.results ?? null;
  const loading = isLoading || dq !== q;

  const go = (id: string) => {
    onClose();
    router.push(`/w/${ws.workspace.id}/p/${id}`);
  };

  const commands = useMemo<Cmd[]>(
    () => [
      { label: "New page", icon: Plus, run: () => ws.createPage() },
      { label: "New database", icon: Database, run: () => ws.createPage({ kind: "database", title: "Untitled database" }) },
      { label: "Browse templates", icon: LayoutTemplate, run: () => ws.openTemplates(null) },
      { label: "Toggle dark mode", icon: Moon, hint: `${modKey()}⇧L`, run: () => applyTheme(document.documentElement.dataset.theme === "dark" ? "light" : "dark") },
      { label: "Toggle sidebar", icon: PanelLeft, hint: `${modKey()}\\`, run: () => ws.toggleSidebar() },
      { label: "Open settings", icon: Settings, run: () => ws.openSettings() },
      { label: "Import", icon: Upload, run: () => ws.openSettings("import") },
      { label: "Export workspace", icon: Download, run: () => downloadUrl(`/api/workspaces/${ws.workspace.id}/export`) },
      { label: "Open trash", icon: Trash2, run: () => ws.openTrash() },
      { label: "Keyboard shortcuts", icon: Keyboard, run: () => onShortcuts() },
    ],
    [ws, onShortcuts],
  );
  const shownCommands = q ? commands.filter((c) => c.label.toLowerCase().includes(q.toLowerCase())) : commands.slice(0, 4);
  // The first entry stays selected as results arrive, until the user moves the selection.
  const values = [...(results ?? []).map((r) => r.id), ...shownCommands.map((c) => `cmd-${c.label}`)];
  const [picked, setPicked] = useState("");
  const selected = values.includes(picked) ? picked : (values[0] ?? "");

  return (
    <Command shouldFilter={false} loop value={selected} onValueChange={setPicked} className="flex max-h-[70vh] flex-col" label="Search">
      <div className="flex items-center border-b border-line px-4">
        <Command.Input autoFocus value={q} onValueChange={setQ} placeholder={`Search ${ws.workspace.name}… or type a command`} className="h-12 flex-1 bg-transparent text-[15px] outline-none placeholder:text-faint" />
      </div>
      <div className="flex gap-1 border-b border-line px-3 py-2">
        {TYPES.map((t) => (
          <button key={String(t.key)} className={cx("rounded-full px-2.5 py-0.5 text-xs", type === t.key ? "bg-fg text-bg" : "bg-subtle text-muted hover:text-fg")} onClick={() => setType(t.key)}>
            {t.label}
          </button>
        ))}
      </div>
      <Command.List className="flex-1 overflow-y-auto p-2">
        {!q && results && results.length > 0 && <div className="px-2 pb-1 pt-1 text-xs font-medium text-muted">Recent</div>}
        {results?.map((r) => (
          <Command.Item key={r.id} value={r.id} onSelect={() => go(r.id)} className="flex cursor-pointer items-start gap-3 rounded-md px-2 py-2 data-[selected=true]:bg-hover">
            <span className="mt-0.5">{q ? <PageIcon icon={r.icon} kind={r.kind} size={18} /> : <Clock size={16} className="text-faint" />}</span>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                {!q && <PageIcon icon={r.icon} kind={r.kind} size={14} />}
                <span className="truncate text-sm font-medium">{pageTitle(r.title)}</span>
                {r.type !== "page" && <span className="rounded bg-subtle px-1.5 text-[10px] uppercase tracking-wide text-muted">{r.type}</span>}
              </div>
              {r.path.length > 0 && <div className="truncate text-xs text-faint">{r.path.join(" / ")}</div>}
              {r.snippet && <div className="mt-0.5 line-clamp-2 text-xs text-muted">{r.snippet}</div>}
            </div>
          </Command.Item>
        ))}
        {shownCommands.length > 0 && (
          <Command.Group heading="Commands" className="mt-1 [&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:pb-1 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:text-muted">
            {shownCommands.map((c) => (
              <Command.Item
                key={c.label}
                value={`cmd-${c.label}`}
                onSelect={() => {
                  onClose();
                  c.run();
                }}
                className="flex cursor-pointer items-center gap-3 rounded-md px-2 py-2 text-sm data-[selected=true]:bg-hover"
              >
                <c.icon size={16} className="text-muted" />
                <span className="flex-1">{c.label}</span>
                {c.hint && <span className="text-xs text-faint">{c.hint}</span>}
              </Command.Item>
            ))}
          </Command.Group>
        )}
        {q && !loading && results?.length === 0 && shownCommands.length === 0 && <div className="px-3 py-8 text-center text-sm text-muted">No results for “{q}”</div>}
      </Command.List>
      <div className="flex items-center gap-3 border-t border-line px-4 py-2 text-xs text-faint">
        <span>
          <Kbd>↑</Kbd> <Kbd>↓</Kbd> to navigate
        </span>
        <span>
          <Kbd>↵</Kbd> to open
        </span>
        <span>
          <Kbd>esc</Kbd> to close
        </span>
        {loading && <span className="ml-auto">Searching…</span>}
      </div>
    </Command>
  );
}

export function ShortcutsDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const m = modKey();
  const rows: [string, string][] = [
    [`${m} K / ${m} P`, "Search and commands"],
    [`${m} ⇧ N`, "New page"],
    [`${m} \\`, "Toggle sidebar"],
    [`${m} ⇧ L`, "Toggle dark mode"],
    [`${m} S`, "Save now"],
    ["/", "Insert a block"],
    ["@", "Link to a page"],
    [`${m} B / I / U`, "Bold / italic / underline"],
    [`${m} ⇧ S`, "Strikethrough"],
    [`${m} E`, "Inline code"],
    [`${m} Z / ${m} ⇧ Z`, "Undo / redo"],
    ["# + space", "Heading"],
    ["- or * + space", "Bulleted list"],
    ["1. + space", "Numbered list"],
    ["[] + space", "To-do list"],
    ["> + space", "Quote"],
    ["```", "Code block"],
    ["---", "Divider"],
    ["$x$", "Inline equation"],
    ["Tab / ⇧ Tab", "Indent / outdent list item"],
  ];
  return (
    <Dialog open={open} onClose={onClose} title="Keyboard shortcuts" width={460}>
      <div className="max-h-[60vh] overflow-y-auto p-4">
        {rows.map(([k, v]) => (
          <div key={k} className="flex items-center justify-between border-b border-line py-2 text-sm last:border-0">
            <span>{v}</span>
            <Kbd>{k}</Kbd>
          </div>
        ))}
      </div>
    </Dialog>
  );
}
