"use client";
import { useRef, useState } from "react";
import useSWR, { mutate } from "swr";
import { useRouter } from "next/navigation";
import { User, Shield, KeyRound, Building2, Users, ArrowDownUp, HardDrive, Trash2, Copy, Monitor, Sun, Moon } from "lucide-react";
import { useWorkspace } from "@/client/workspace-context";
import { useMembers, refreshTree, useMe } from "@/client/hooks";
import { PasswordInput } from "./password-input";
import { api, errorMessage } from "@/client/api";
import { Dialog, useUi, cx, Spinner } from "@/client/ui";
import { applyTheme, getThemePref, type ThemePref } from "@/client/providers";
import type { Role } from "@/client/types";

const TABS = [
  { key: "account", label: "My account", icon: User },
  { key: "security", label: "Sessions", icon: Shield },
  { key: "tokens", label: "API tokens", icon: KeyRound },
  { key: "workspace", label: "Workspace", icon: Building2 },
  { key: "members", label: "Members", icon: Users },
  { key: "import", label: "Import & export", icon: ArrowDownUp },
  { key: "storage", label: "Storage", icon: HardDrive },
];

export function SettingsDialog({ tab, onTab }: { tab: string | null; onTab: (t: string | null) => void }) {
  return (
    <Dialog open={!!tab} onClose={() => onTab(null)} width={920} bare title="Settings">
      <div className="flex h-[min(680px,85vh)] flex-col sm:flex-row">
        <div className="flex flex-none gap-1 overflow-x-auto border-b border-line bg-sidebar p-2 sm:w-52 sm:flex-col sm:border-b-0 sm:border-r">
          {TABS.map((t) => (
            <button key={t.key} onClick={() => onTab(t.key)} className={cx("flex flex-none items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm", tab === t.key ? "bg-active font-medium" : "text-muted hover:bg-hover")}>
              <t.icon size={15} /> {t.label}
            </button>
          ))}
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto p-6">
          {tab === "account" && <AccountTab />}
          {tab === "security" && <SessionsTab />}
          {tab === "tokens" && <TokensTab />}
          {tab === "workspace" && <WorkspaceTab />}
          {tab === "members" && <MembersTab />}
          {tab === "import" && <ImportExportTab onDone={() => onTab(null)} />}
          {tab === "storage" && <StorageTab />}
        </div>
      </div>
    </Dialog>
  );
}

function H({ children, sub }: { children: React.ReactNode; sub?: string }) {
  return (
    <div className="mb-4 border-b border-line pb-3">
      <h3 className="text-base font-semibold">{children}</h3>
      {sub && <p className="mt-0.5 text-sm text-muted">{sub}</p>}
    </div>
  );
}

function AccountTab() {
  const ws = useWorkspace();
  const me = ws.me;
  const refreshMe = () => mutate("/api/auth/me");
  const { data: serverMail } = useMe();
  const { toast, confirm } = useUi();
  const [name, setName] = useState(ws.me.name);
  const [pw, setPw] = useState({ currentPassword: "", newPassword: "" });
  const [theme, setTheme] = useState<ThemePref>(getThemePref());
  return (
    <div className="max-w-lg space-y-8">
      <section>
        <H>Profile</H>
        <label htmlFor="profile-name" className="mb-1 block text-xs text-muted">Name</label>
        <div className="flex gap-2">
          <input id="profile-name" className="input flex-1" value={name} onChange={(e) => setName(e.target.value)} />
          <button
            className="btn"
            onClick={async () => {
              try {
                await api.patch("/api/auth/me", { name });
                mutate("/api/auth/me");
                toast("Saved");
              } catch (e) {
                toast(errorMessage(e), "error");
              }
            }}
          >
            Save
          </button>
        </div>
        <p className="mt-2 text-sm text-muted">{ws.me.email}</p>
      </section>
      {serverMail?.email && (
        <section>
          <H sub="About mentions of you and replies to your comments. They also appear in your Inbox.">Email notifications</H>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={me.emailNotifications}
              onChange={async (e) => {
                try {
                  await api.patch("/api/auth/me", { emailNotifications: e.target.checked });
                  refreshMe();
                } catch (err) {
                  toast(errorMessage(err), "error");
                }
              }}
            />
            Email me about mentions and replies
          </label>
        </section>
      )}
      <section>
        <H>Appearance</H>
        <div className="flex gap-2">
          {(
            [
              ["light", Sun, "Light"],
              ["dark", Moon, "Dark"],
              ["system", Monitor, "System"],
            ] as const
          ).map(([k, Icon, label]) => (
            <button
              key={k}
              className={cx("btn", theme === k && "border-accent ring-2 ring-accent-soft")}
              onClick={() => {
                setTheme(k);
                applyTheme(k);
              }}
            >
              <Icon size={15} /> {label}
            </button>
          ))}
        </div>
      </section>
      <section>
        <H sub={me.hasPassword ? "Changing your password signs out your other sessions." : "You sign in with single sign-on. Set a password to also sign in with your email."}>Password</H>
        <form
          className="space-y-2"
          onSubmit={async (e) => {
            e.preventDefault();
            try {
              await api.post("/api/auth/password", me.hasPassword ? pw : { newPassword: pw.newPassword });
              setPw({ currentPassword: "", newPassword: "" });
              toast(me.hasPassword ? "Password changed" : "Password set");
              refreshMe();
            } catch (err) {
              toast(errorMessage(err), "error");
            }
          }}
        >
          {me.hasPassword && <PasswordInput autoComplete="current-password" placeholder="Current password" aria-label="Current password" value={pw.currentPassword} onChange={(e) => setPw({ ...pw, currentPassword: e.target.value })} />}
          <PasswordInput autoComplete="new-password" placeholder="New password (8+ characters)" aria-label="New password" minLength={8} value={pw.newPassword} onChange={(e) => setPw({ ...pw, newPassword: e.target.value })} />
          <button className="btn" disabled={(me.hasPassword && !pw.currentPassword) || pw.newPassword.length < 8}>
            {me.hasPassword ? "Change password" : "Set password"}
          </button>
        </form>
      </section>
      <section>
        <H sub="Deletes your account. Workspaces where you are the only member are deleted too.">Delete account</H>
        <button
          className="btn btn-danger"
          onClick={async () => {
            const ok = await confirm({ title: "Delete your account?", message: "This cannot be undone. Export anything you want to keep first.", confirmLabel: "Continue", danger: true });
            if (!ok) return;
            const answer = prompt(me.hasPassword ? "Enter your password to confirm" : "Type your email address to confirm");
            if (!answer) return;
            try {
              await api.del("/api/auth/account", me.hasPassword ? { password: answer } : { email: answer });
              window.location.replace("/signup");
            } catch (e) {
              toast(errorMessage(e), "error");
            }
          }}
        >
          Delete my account
        </button>
      </section>
    </div>
  );
}

function SessionsTab() {
  const { toast } = useUi();
  const { data } = useSWR<{ sessions: { id: string; current: boolean; userAgent: string | null; lastSeenAt: string; createdAt: string }[] }>("/api/auth/sessions");
  return (
    <div className="max-w-xl">
      <H sub="Devices currently signed in to your account.">Active sessions</H>
      {!data && <Spinner />}
      {data?.sessions.map((s) => (
        <div key={s.id} className="flex items-center gap-3 border-b border-line py-3 text-sm">
          <Monitor size={16} className="text-muted" />
          <div className="min-w-0 flex-1">
            <div className="truncate">{describeAgent(s.userAgent)}</div>
            <div className="text-xs text-muted">
              Last active {new Date(s.lastSeenAt).toLocaleString()} {s.current && <span className="ml-1 rounded bg-accent-soft px-1.5 text-accent">This device</span>}
            </div>
          </div>
          {!s.current && (
            <button
              className="btn btn-sm"
              onClick={async () => {
                await api.del(`/api/auth/sessions/${s.id}`).catch((e) => toast(errorMessage(e), "error"));
                mutate("/api/auth/sessions");
              }}
            >
              Sign out
            </button>
          )}
        </div>
      ))}
      <button
        className="btn mt-4"
        onClick={async () => {
          await api.del("/api/auth/sessions");
          mutate("/api/auth/sessions");
          toast("Signed out of all other sessions");
        }}
      >
        Sign out of all other sessions
      </button>
    </div>
  );
}

function describeAgent(ua: string | null) {
  if (!ua) return "Unknown device";
  const browser = /Edg\//.test(ua) ? "Edge" : /Firefox\//.test(ua) ? "Firefox" : /Chrome\//.test(ua) ? "Chrome" : /Safari\//.test(ua) ? "Safari" : "Browser";
  const os = /Windows/.test(ua) ? "Windows" : /Mac OS X/.test(ua) ? "macOS" : /Android/.test(ua) ? "Android" : /iPhone|iPad/.test(ua) ? "iOS" : /Linux/.test(ua) ? "Linux" : "";
  return `${browser}${os ? " on " + os : ""}`;
}

function TokensTab() {
  const { toast, confirm } = useUi();
  const { data } = useSWR<{ tokens: { id: string; name: string; createdAt: string; lastUsedAt: string | null }[] }>("/api/auth/tokens");
  const [name, setName] = useState("");
  const [created, setCreated] = useState<string | null>(null);
  return (
    <div className="max-w-xl">
      <H sub="Use personal API tokens with the REST API (Authorization: Bearer …). Tokens act with your permissions. See docs/api.md.">API tokens</H>
      <form
        className="mb-4 flex gap-2"
        onSubmit={async (e) => {
          e.preventDefault();
          try {
            const r = await api.post<{ token: string }>("/api/auth/tokens", { name });
            setCreated(r.token);
            setName("");
            mutate("/api/auth/tokens");
          } catch (err) {
            toast(errorMessage(err), "error");
          }
        }}
      >
        <input className="input flex-1" placeholder="Token name, e.g. Backup script" aria-label="Token name" value={name} onChange={(e) => setName(e.target.value)} />
        <button className="btn btn-primary" disabled={!name.trim()}>
          Create token
        </button>
      </form>
      {created && (
        <div className="mb-4 rounded-lg border border-line bg-subtle p-3 text-sm">
          <p className="mb-2 font-medium">Copy your token now. It will not be shown again.</p>
          <div className="flex gap-2">
            <code className="flex-1 overflow-x-auto rounded bg-bg px-2 py-1 font-mono text-xs">{created}</code>
            <button className="btn btn-sm" onClick={() => navigator.clipboard?.writeText(created).then(() => toast("Copied"))}>
              <Copy size={13} />
            </button>
          </div>
        </div>
      )}
      {data?.tokens.map((t) => (
        <div key={t.id} className="flex items-center gap-3 border-b border-line py-2.5 text-sm">
          <KeyRound size={15} className="text-muted" />
          <div className="flex-1">
            <div>{t.name}</div>
            <div className="text-xs text-muted">
              Created {new Date(t.createdAt).toLocaleDateString()} · {t.lastUsedAt ? `last used ${new Date(t.lastUsedAt).toLocaleString()}` : "never used"}
            </div>
          </div>
          <button
            className="btn btn-sm"
            onClick={async () => {
              if (!(await confirm({ title: `Revoke “${t.name}”?`, message: "Scripts using this token will stop working.", danger: true, confirmLabel: "Revoke" }))) return;
              await api.del(`/api/auth/tokens/${t.id}`);
              mutate("/api/auth/tokens");
            }}
          >
            Revoke
          </button>
        </div>
      ))}
      {data?.tokens.length === 0 && <p className="text-sm text-muted">No tokens yet.</p>}
    </div>
  );
}

function WorkspaceTab() {
  const ws = useWorkspace();
  const router = useRouter();
  const { toast, confirm } = useUi();
  const [name, setName] = useState(ws.workspace.name);
  const [icon, setIcon] = useState(ws.workspace.icon ?? "");
  const isAdmin = ws.workspace.role === "owner" || ws.workspace.role === "admin";
  return (
    <div className="max-w-lg space-y-8">
      <section>
        <H>Workspace</H>
        <div className="flex gap-2">
          <input className="input w-14 text-center" maxLength={4} placeholder="🙂" value={icon} disabled={!isAdmin} onChange={(e) => setIcon(e.target.value)} aria-label="Icon" />
          <input className="input flex-1" value={name} disabled={!isAdmin} onChange={(e) => setName(e.target.value)} aria-label="Name" />
          <button
            className="btn"
            disabled={!isAdmin}
            onClick={async () => {
              try {
                await api.patch(`/api/workspaces/${ws.workspace.id}`, { name, icon: icon || null });
                mutate("/api/workspaces");
                toast("Saved");
              } catch (e) {
                toast(errorMessage(e), "error");
              }
            }}
          >
            Save
          </button>
        </div>
        {!isAdmin && <p className="mt-2 text-xs text-muted">Only owners and admins can change workspace settings.</p>}
      </section>
      <section>
        <H sub="Leave this workspace. You will lose access to its pages unless they were shared with you directly.">Leave workspace</H>
        <button
          className="btn"
          onClick={async () => {
            if (!(await confirm({ title: `Leave ${ws.workspace.name}?`, danger: true, confirmLabel: "Leave" }))) return;
            try {
              await api.del(`/api/workspaces/${ws.workspace.id}/members/${ws.me.id}`);
              await mutate("/api/workspaces");
              router.push("/");
            } catch (e) {
              toast(errorMessage(e), "error");
            }
          }}
        >
          Leave workspace
        </button>
      </section>
      {ws.workspace.role === "owner" && (
        <section>
          <H sub="Permanently deletes every page, database and file in this workspace.">Delete workspace</H>
          <button
            className="btn btn-danger"
            onClick={async () => {
              const ok = await confirm({ title: "Delete this workspace?", message: "Export it first if you want a backup. This cannot be undone.", requireText: ws.workspace.name, danger: true, confirmLabel: "Delete workspace" });
              if (!ok) return;
              try {
                await api.del(`/api/workspaces/${ws.workspace.id}`, { confirmName: ws.workspace.name });
                await mutate("/api/workspaces");
                router.push("/");
              } catch (e) {
                toast(errorMessage(e), "error");
              }
            }}
          >
            <Trash2 size={14} /> Delete workspace
          </button>
        </section>
      )}
    </div>
  );
}

function MembersTab() {
  const ws = useWorkspace();
  const { toast, confirm } = useUi();
  const { data } = useMembers(ws.workspace.id);
  const isAdmin = ws.workspace.role === "owner" || ws.workspace.role === "admin";
  const invKey = isAdmin ? `/api/workspaces/${ws.workspace.id}/invitations` : null;
  const { data: invs } = useSWR<{ invitations: { id: string; email: string; role: Role; expiresAt: string }[] }>(invKey);
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<Role>("editor");
  const [link, setLink] = useState<string | null>(null);
  return (
    <div className="max-w-2xl">
      <H sub="Every member gets every feature. Roles only control what they can change.">Members</H>
      {isAdmin && (
        <form
          className="mb-5 flex flex-wrap gap-2"
          onSubmit={async (e) => {
            e.preventDefault();
            try {
              const r = await api.post<{ path: string }>(`/api/workspaces/${ws.workspace.id}/invitations`, { email, role });
              setLink(location.origin + r.path);
              setEmail("");
              mutate(invKey);
            } catch (err) {
              toast(errorMessage(err), "error");
            }
          }}
        >
          <input className="input min-w-0 flex-1" type="email" required placeholder="Email address to invite" value={email} onChange={(e) => setEmail(e.target.value)} />
          <select className="input" value={role} onChange={(e) => setRole(e.target.value as Role)}>
            <option value="admin">Admin</option>
            <option value="editor">Editor</option>
            <option value="viewer">Viewer</option>
          </select>
          <button className="btn btn-primary">Create invite link</button>
        </form>
      )}
      {link && (
        <div className="mb-5 rounded-lg border border-line bg-subtle p-3 text-sm">
          <p className="mb-2">Send this link to the person you invited (valid for 14 days, only for that email address):</p>
          <div className="flex gap-2">
            <code className="flex-1 overflow-x-auto rounded bg-bg px-2 py-1 font-mono text-xs">{link}</code>
            <button className="btn btn-sm" onClick={() => navigator.clipboard?.writeText(link).then(() => toast("Copied"))}>
              <Copy size={13} />
            </button>
          </div>
        </div>
      )}
      {data?.members.map((m) => (
        <div key={m.id} className="flex items-center gap-3 border-b border-line py-2.5 text-sm">
          <span className="flex h-7 w-7 items-center justify-center rounded-full bg-subtle text-xs font-medium">{m.name.slice(0, 1).toUpperCase()}</span>
          <div className="min-w-0 flex-1">
            <div className="truncate">
              {m.name} {m.id === ws.me.id && <span className="text-muted">(you)</span>}
            </div>
            <div className="truncate text-xs text-muted">{m.email}</div>
          </div>
          {isAdmin && m.id !== ws.me.id ? (
            <>
              <select
                className="input h-7"
                value={m.role}
                onChange={async (e) => {
                  try {
                    await api.patch(`/api/workspaces/${ws.workspace.id}/members/${m.id}`, { role: e.target.value });
                    mutate(`/api/workspaces/${ws.workspace.id}/members`);
                  } catch (err) {
                    toast(errorMessage(err), "error");
                  }
                }}
              >
                {ws.workspace.role === "owner" && <option value="owner">Owner</option>}
                <option value="admin">Admin</option>
                <option value="editor">Editor</option>
                <option value="viewer">Viewer</option>
              </select>
              <button
                className="icon-btn hover:text-danger"
                title="Remove member"
                onClick={async () => {
                  if (!(await confirm({ title: `Remove ${m.name}?`, danger: true, confirmLabel: "Remove" }))) return;
                  try {
                    await api.del(`/api/workspaces/${ws.workspace.id}/members/${m.id}`);
                    mutate(`/api/workspaces/${ws.workspace.id}/members`);
                  } catch (err) {
                    toast(errorMessage(err), "error");
                  }
                }}
              >
                <Trash2 size={14} />
              </button>
            </>
          ) : (
            <span className="text-xs capitalize text-muted">{m.role}</span>
          )}
        </div>
      ))}
      {!!invs?.invitations.length && (
        <>
          <h4 className="mb-2 mt-6 text-sm font-medium">Pending invitations</h4>
          {invs.invitations.map((i) => (
            <div key={i.id} className="flex items-center gap-3 border-b border-line py-2 text-sm">
              <span className="flex-1 truncate">{i.email}</span>
              <span className="text-xs capitalize text-muted">{i.role}</span>
              <button
                className="btn btn-sm"
                onClick={async () => {
                  await api.del(`/api/workspaces/${ws.workspace.id}/invitations/${i.id}`);
                  mutate(invKey);
                }}
              >
                Revoke
              </button>
            </div>
          ))}
        </>
      )}
    </div>
  );
}

function ImportExportTab({ onDone }: { onDone: () => void }) {
  const ws = useWorkspace();
  const { toast } = useUi();
  const fileRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [report, setReport] = useState<{ kind: string; pages?: number; databases?: number; records?: number; files?: number; warnings?: string[]; rootIds?: string[] } | null>(null);
  const upload = async (file: File) => {
    setBusy(true);
    setReport(null);
    try {
      const form = new FormData();
      form.set("file", file);
      const r = await api.upload<typeof report>(`/api/workspaces/${ws.workspace.id}/import`, form);
      setReport(r);
      await refreshTree(ws.workspace.id);
    } catch (e) {
      toast(errorMessage(e), "error");
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="max-w-xl space-y-8">
      <section>
        <H sub="Markdown (.md or a .zip of folders), CSV (becomes a database), a Notion export (“Markdown &amp; CSV” .zip), or a Slate export (.zip/.json). Imports always create new pages; nothing is overwritten.">Import</H>
        <div
          className="flex flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed border-line p-8 text-center text-sm text-muted"
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault();
            const f = e.dataTransfer.files[0];
            if (f) upload(f);
          }}
        >
          {busy ? <Spinner /> : <ArrowDownUp size={20} />}
          <span>Drop a file here, or</span>
          <button className="btn" disabled={busy} onClick={() => fileRef.current?.click()}>
            Choose file
          </button>
          <input ref={fileRef} type="file" hidden accept=".md,.markdown,.txt,.csv,.json,.zip" onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])} />
        </div>
        {report && (
          <div className="mt-3 rounded-lg border border-line bg-subtle p-3 text-sm">
            <p className="font-medium">Import complete</p>
            <p className="text-muted">
              {[report.pages && `${report.pages} pages`, report.databases && `${report.databases} databases`, report.records && `${report.records} records`, report.files && `${report.files} files`].filter(Boolean).join(", ") || "Done"}
            </p>
            {!!report.warnings?.length && (
              <ul className="mt-2 list-disc pl-5 text-xs text-muted">
                {report.warnings.map((w, i) => (
                  <li key={i}>{w}</li>
                ))}
              </ul>
            )}
            {report.rootIds?.[0] && (
              <button
                className="btn btn-sm mt-2"
                onClick={() => {
                  onDone();
                  ws.navigate(report.rootIds![0]);
                }}
              >
                Open imported content
              </button>
            )}
          </div>
        )}
      </section>
      <section>
        <H sub="Download everything you can access: full-fidelity JSON (re-importable), Markdown, CSV for databases, attachments, and a report of anything Markdown cannot represent.">Export workspace</H>
        <a className="btn btn-primary" href={`/api/workspaces/${ws.workspace.id}/export`}>
          Export all content (.zip)
        </a>
        <p className="mt-3 text-xs text-muted">Individual pages can be exported as Markdown, HTML or ZIP from the page’s ••• menu.</p>
      </section>
    </div>
  );
}

function StorageTab() {
  const ws = useWorkspace();
  const { data } = useSWR<{ bytes: number; count: number; warnBytes: number | null }>(`/api/workspaces/${ws.workspace.id}/storage`);
  const fmt = (b: number) => (b > 1e9 ? `${(b / 1e9).toFixed(2)} GB` : b > 1e6 ? `${(b / 1e6).toFixed(1)} MB` : `${Math.round(b / 1e3)} KB`);
  return (
    <div className="max-w-lg">
      <H sub="Slate has no storage quotas. Capacity depends only on your server's disk or object storage.">Storage</H>
      {!data ? (
        <Spinner />
      ) : (
        <div className="space-y-2 text-sm">
          <p>
            <span className="text-2xl font-semibold">{fmt(data.bytes)}</span> <span className="text-muted">in {data.count} files</span>
          </p>
          {data.warnBytes && data.bytes > data.warnBytes && (
            <p className="rounded-md bg-c-yellow p-2">Storage use is above the administrator’s warning threshold ({fmt(data.warnBytes)}). Nothing has been removed; ask your administrator to add capacity.</p>
          )}
        </div>
      )}
    </div>
  );
}
