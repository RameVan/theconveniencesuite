"use client";
import { useMemo, useRef, useState, useEffect } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { mutate } from "swr";
import {
  ChevronRight,
  ChevronsUpDown,
  Plus,
  Search,
  Settings,
  Trash2,
  MoreHorizontal,
  Star,
  StarOff,
  Copy,
  Link2,
  PenLine,
  LayoutTemplate,
  Upload,
  ChevronsLeft,
  LogOut,
  Database,
  Lock,
  ArrowUpRight,
  ArrowUp,
  ArrowDown,
} from "lucide-react";
import { useTree, refreshTree, useLocalStorage } from "@/client/hooks";
import { useWorkspace } from "@/client/workspace-context";
import { api, errorMessage } from "@/client/api";
import { Menu, Popover, cx, useUi, modKey, type MenuItem } from "@/client/ui";
import { PageIcon, pageTitle } from "./page-icon";
import { InboxButton } from "./inbox";
import type { TreeNode, PageSummary } from "@/client/types";

type DropZone = "before" | "after" | "inside";

export function Sidebar({ onNavigate }: { onNavigate?: () => void }) {
  const ws = useWorkspace();
  const router = useRouter();
  const { toast } = useUi();
  const params = useParams<{ pageId?: string }>();
  const currentId = params.pageId ?? null;
  const { data: tree } = useTree(ws.workspace.id);
  const [expanded, setExpanded] = useLocalStorage<Record<string, boolean>>(`slate-expanded-${ws.workspace.id}`, {});
  const [switcher, setSwitcher] = useState<HTMLElement | null>(null);
  const [renaming, setRenaming] = useState<string | null>(null);
  const [drag, setDrag] = useState<{ id: string; over: string | null; zone: DropZone | null }>({ id: "", over: null, zone: null });

  const nodes = useMemo(() => tree?.nodes ?? [], [tree]);
  const byParent = useMemo(() => {
    const m = new Map<string | null, TreeNode[]>();
    for (const n of nodes) {
      const list = m.get(n.parentId) ?? [];
      list.push(n);
      m.set(n.parentId, list);
    }
    for (const list of m.values()) list.sort((a, b) => a.position - b.position);
    return m;
  }, [nodes]);
  const byId = useMemo(() => new Map(nodes.map((n) => [n.id, n])), [nodes]);
  const roots = byParent.get(null) ?? [];
  const sections = {
    workspace: roots.filter((r) => r.section === "workspace"),
    private: roots.filter((r) => r.section === "private"),
    shared: roots.filter((r) => r.section === "shared"),
  };

  // Expand ancestors of the current page.
  useEffect(() => {
    if (!currentId || !byId.size) return;
    let cur = byId.get(currentId);
    const add: Record<string, boolean> = {};
    while (cur?.parentId) {
      if (!expanded[cur.parentId]) add[cur.parentId] = true;
      cur = byId.get(cur.parentId);
    }
    if (Object.keys(add).length) setExpanded({ ...expanded, ...add });
  }, [currentId, byId]); // eslint-disable-line react-hooks/exhaustive-deps

  const isDescendant = (id: string, ancestor: string) => {
    let cur = byId.get(id);
    while (cur) {
      if (cur.parentId === ancestor) return true;
      cur = cur.parentId ? byId.get(cur.parentId) : undefined;
    }
    return false;
  };

  const move = async (id: string, body: { parentId: string | null; beforeId?: string; afterId?: string; visibility?: "workspace" | "private" }) => {
    try {
      await api.post(`/api/pages/${id}/move`, body);
      if (body.parentId) setExpanded({ ...expanded, [body.parentId]: true });
      await refreshTree(ws.workspace.id);
      mutate(`/api/pages/${id}`);
    } catch (e) {
      toast(errorMessage(e), "error");
    }
  };

  const onDrop = (target: TreeNode, zone: DropZone) => {
    const id = drag.id;
    setDrag({ id: "", over: null, zone: null });
    if (!id || id === target.id || isDescendant(target.id, id)) return;
    if (zone === "inside") {
      if (target.kind === "database") return;
      move(id, { parentId: target.id });
    } else {
      const visibility = target.parentId ? undefined : target.section === "private" ? "private" : "workspace";
      move(id, { parentId: target.parentId, [zone === "before" ? "beforeId" : "afterId"]: target.id, visibility });
    }
  };

  const [favDrag, setFavDrag] = useState<string | null>(null);
  const moveFav = async (id: string, beforeId: string | null) => {
    if (id === beforeId) return;
    try {
      await api.patch(`/api/pages/${id}/favorite`, { beforeId });
    } catch (e) {
      toast(errorMessage(e), "error");
    }
    refreshTree(ws.workspace.id);
  };
  const itemMenu = (n: TreeNode | PageSummary, isFav: boolean): MenuItem[] => [
    { label: isFav ? "Remove from Favorites" : "Add to Favorites", icon: isFav ? <StarOff size={15} /> : <Star size={15} />, onSelect: () => toggleFavorite(n.id, !isFav) },
    { label: "Duplicate", icon: <Copy size={15} />, hint: `${modKey()}+D`, onSelect: () => duplicate(n.id) },
    { label: "Copy link", icon: <Link2 size={15} />, onSelect: () => copyLink(n.id) },
    { label: "Rename", icon: <PenLine size={15} />, onSelect: () => setRenaming(n.id) },
    { label: "Open in new tab", icon: <ArrowUpRight size={15} />, onSelect: () => window.open(`/w/${ws.workspace.id}/p/${n.id}`, "_blank") },
    { divider: true, label: "" },
    { label: "Move to Trash", icon: <Trash2 size={15} />, danger: true, onSelect: () => archive(n.id) },
  ];

  const toggleFavorite = async (id: string, on: boolean) => {
    try {
      await (on ? api.put(`/api/pages/${id}/favorite`) : api.del(`/api/pages/${id}/favorite`));
      refreshTree(ws.workspace.id);
      mutate(`/api/pages/${id}`);
    } catch (e) {
      toast(errorMessage(e), "error");
    }
  };
  const duplicate = async (id: string) => {
    try {
      const r = await api.post<{ page: { id: string } }>(`/api/pages/${id}/duplicate`);
      await refreshTree(ws.workspace.id);
      ws.navigate(r.page.id);
    } catch (e) {
      toast(errorMessage(e), "error");
    }
  };
  const copyLink = (id: string) => {
    navigator.clipboard?.writeText(`${location.origin}/w/${ws.workspace.id}/p/${id}`);
    toast("Link copied");
  };
  const archive = async (id: string) => {
    try {
      await api.post(`/api/pages/${id}/archive`);
      await refreshTree(ws.workspace.id);
      mutate(`/api/pages/${id}`);
      toast("Moved to Trash", "info", {
        label: "Undo",
        run: async () => {
          await api.post(`/api/pages/${id}/restore`);
          refreshTree(ws.workspace.id);
          mutate(`/api/pages/${id}`);
        },
      });
      if (id === currentId) router.push(`/w/${ws.workspace.id}`);
    } catch (e) {
      toast(errorMessage(e), "error");
    }
  };
  const rename = async (id: string, title: string) => {
    setRenaming(null);
    try {
      await api.patch(`/api/pages/${id}`, { title });
      refreshTree(ws.workspace.id);
      mutate(`/api/pages/${id}`);
    } catch (e) {
      toast(errorMessage(e), "error");
    }
  };

  const renderNode = (n: TreeNode, depth: number) => {
    const children = byParent.get(n.id) ?? [];
    const open = !!expanded[n.id];
    const active = n.id === currentId;
    const isOver = drag.over === n.id;
    return (
      <div key={n.id} role="treeitem" aria-expanded={children.length ? open : undefined} aria-selected={active}>
        <TreeRow
          node={n}
          depth={depth}
          active={active}
          open={open}
          hasChildren={children.length > 0 || n.kind === "database"}
          renaming={renaming === n.id}
          dropZone={isOver ? drag.zone : null}
          onToggle={() => setExpanded({ ...expanded, [n.id]: !open })}
          onRename={(t) => rename(n.id, t)}
          onCancelRename={() => setRenaming(null)}
          onAddChild={async () => {
            setExpanded({ ...expanded, [n.id]: true });
            await ws.createPage({ parentId: n.id });
            onNavigate?.();
          }}
          menu={() => itemMenu(n, !!tree?.favorites.some((f) => f.id === n.id))}
          href={`/w/${ws.workspace.id}/p/${n.id}`}
          onClick={onNavigate}
          dragProps={{
            draggable: ws.canEdit && renaming !== n.id,
            onDragStart: (e) => {
              e.dataTransfer.setData("application/x-slate-page", n.id);
              e.dataTransfer.effectAllowed = "move";
              setDrag({ id: n.id, over: null, zone: null });
            },
            onDragOver: (e) => {
              if (!drag.id || drag.id === n.id) return;
              e.preventDefault();
              const r = e.currentTarget.getBoundingClientRect();
              const y = (e.clientY - r.top) / r.height;
              const zone: DropZone = y < 0.28 ? "before" : y > 0.72 ? "after" : n.kind === "database" ? "after" : "inside";
              if (drag.over !== n.id || drag.zone !== zone) setDrag({ ...drag, over: n.id, zone });
            },
            onDragLeave: () => drag.over === n.id && setDrag({ ...drag, over: null, zone: null }),
            onDrop: (e) => {
              e.preventDefault();
              if (drag.zone) onDrop(n, drag.zone);
            },
            onDragEnd: () => setDrag({ id: "", over: null, zone: null }),
          }}
        />
        {open && (
          <div role="group">
            {children.map((c) => renderNode(c, depth + 1))}
            {!children.length && n.kind === "page" && (
              <div className="py-1 text-xs text-faint" style={{ paddingLeft: 28 + (depth + 1) * 14 }}>
                No pages inside
              </div>
            )}
            {n.kind === "database" && <DatabaseRecordsInTree databaseId={n.id} depth={depth + 1} currentId={currentId} onNavigate={onNavigate} />}
          </div>
        )}
      </div>
    );
  };

  const section = (title: string, list: TreeNode[], visibility: "workspace" | "private" | null) => (
    <div className="mt-3">
      <div
        className="group flex h-6 items-center justify-between px-3 text-xs font-medium text-muted"
        onDragOver={(e) => visibility && drag.id && e.preventDefault()}
        onDrop={(e) => {
          e.preventDefault();
          if (!visibility || !drag.id) return;
          const id = drag.id;
          setDrag({ id: "", over: null, zone: null });
          move(id, { parentId: null, visibility, ...(list[0] ? { beforeId: list[0].id } : {}) });
        }}
      >
        <span>{title}</span>
        {visibility && (ws.canEdit || visibility === "private") && (
          <button className="icon-btn h-5 w-5 opacity-0 group-hover:opacity-100" title={`New ${visibility} page`} onClick={() => ws.createPage({ visibility })}>
            <Plus size={14} />
          </button>
        )}
      </div>
      {!!list.length && (
        <div role="tree" aria-label={title}>
          {list.map((n) => renderNode(n, 0))}
        </div>
      )}
      <div>
        {!list.length && visibility && (
          <button className="mx-1 flex w-[calc(100%-8px)] items-center gap-2 rounded px-2 py-1 text-sm text-faint hover:bg-hover" onClick={() => ws.createPage({ visibility })}>
            <Plus size={14} /> Add a page
          </button>
        )}
      </div>
    </div>
  );

  return (
    <nav className="flex h-full flex-col bg-sidebar text-sm text-fg" aria-label="Sidebar">
      <div className="flex items-center gap-1 p-2">
        <button className="flex min-w-0 flex-1 items-center gap-2 rounded-md px-2 py-1.5 hover:bg-hover" onClick={(e) => setSwitcher(e.currentTarget)} aria-haspopup="menu">
          <span className="flex h-6 w-6 flex-none items-center justify-center rounded bg-fg text-xs font-semibold text-bg">{ws.workspace.icon || ws.workspace.name.slice(0, 1).toUpperCase()}</span>
          <span className="truncate font-medium">{ws.workspace.name}</span>
          <ChevronsUpDown size={14} className="flex-none text-faint" />
        </button>
        <button className="icon-btn" title={`Close sidebar (${modKey()}+\\)`} onClick={ws.toggleSidebar}>
          <ChevronsLeft size={16} />
        </button>
      </div>
      <Popover anchor={switcher} open={!!switcher} onClose={() => setSwitcher(null)}>
        <Menu
          width={260}
          onClose={() => setSwitcher(null)}
          items={[
            { label: ws.me.email, heading: true },
            ...ws.workspaces.map((w) => ({
              label: w.name,
              icon: <span className="text-xs">{w.icon || w.name.slice(0, 1).toUpperCase()}</span>,
              checked: w.id === ws.workspace.id,
              hint: w.role ?? "guest",
              onSelect: () => router.push(`/w/${w.id}`),
            })),
            { divider: true, label: "" },
            {
              label: "Create workspace",
              icon: <Plus size={15} />,
              onSelect: async () => {
                const name = prompt("Workspace name");
                if (!name?.trim()) return;
                try {
                  const r = await api.post<{ workspace: { id: string } }>("/api/workspaces", { name });
                  await mutate("/api/workspaces");
                  router.push(`/w/${r.workspace.id}`);
                } catch (e) {
                  toast(errorMessage(e), "error");
                }
              },
            },
            {
              label: "Log out",
              icon: <LogOut size={15} />,
              onSelect: async () => {
                await api.post("/api/auth/logout");
                await mutate(() => true, undefined, { revalidate: false });
                window.location.replace("/login");
              },
            },
          ]}
        />
      </Popover>

      <div className="px-1">
        <SideAction icon={<Search size={16} />} label="Search" hint={`${modKey()}K`} onClick={ws.openSearch} />
        <InboxButton />
        <SideAction icon={<Settings size={16} />} label="Settings" onClick={() => ws.openSettings()} />
        {<SideAction icon={<Plus size={16} />} label="New page" hint={`${modKey()}⇧N`} onClick={() => ws.createPage({ visibility: ws.canEdit ? "workspace" : "private" })} />}
      </div>

      <div className="mt-1 flex-1 overflow-y-auto px-1 pb-4">
        {!!tree?.favorites.length && (
          <div className="mt-3" role="group" aria-labelledby="sidebar-favorites">
            <div id="sidebar-favorites" className="flex h-6 items-center px-3 text-xs font-medium text-muted">Favorites</div>
            {tree.favorites.map((f, i) => (
              <FavRow
                key={f.id}
                page={f}
                active={f.id === currentId}
                href={`/w/${ws.workspace.id}/p/${f.id}`}
                onClick={onNavigate}
                dragging={favDrag}
                onDragState={setFavDrag}
                onDropBefore={(dragged, before) => moveFav(dragged, before)}
                nextId={tree.favorites[i + 1]?.id ?? null}
                menu={() => [
                  ...(i > 0 ? [{ label: "Move up", icon: <ArrowUp size={15} />, onSelect: () => moveFav(f.id, tree.favorites[i - 1].id) }] : []),
                  ...(i < tree.favorites.length - 1 ? [{ label: "Move down", icon: <ArrowDown size={15} />, onSelect: () => moveFav(f.id, tree.favorites[i + 2]?.id ?? null) }] : []),
                  ...itemMenu(f, true),
                ]}
              />
            ))}
          </div>
        )}
        {!tree &&
          Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="skeleton mx-3 my-2 h-4" style={{ width: `${50 + ((i * 37) % 40)}%` }} />
          ))}
        {tree && (sections.workspace.length > 0 || ws.canEdit) && section("Workspace", sections.workspace, "workspace")}
        {tree && section("Private", sections.private, "private")}
        {tree && sections.shared.length > 0 && section("Shared with me", sections.shared, null)}
      </div>

      <div className="border-t border-line p-1">
        <SideAction icon={<LayoutTemplate size={16} />} label="Templates" onClick={() => ws.openTemplates(null)} />
        <SideAction icon={<Upload size={16} />} label="Import" onClick={() => ws.openSettings("import")} />
        <SideAction icon={<Trash2 size={16} />} label="Trash" onClick={ws.openTrash} />
      </div>
    </nav>
  );
}

function SideAction({ icon, label, hint, onClick }: { icon: React.ReactNode; label: string; hint?: string; onClick: () => void }) {
  return (
    <button className="flex w-full items-center gap-2 rounded-md px-2 py-1 text-left text-muted hover:bg-hover hover:text-fg" onClick={onClick}>
      <span className="flex w-5 justify-center">{icon}</span>
      <span className="flex-1">{label}</span>
      {hint && <span className="kbd-hint text-[11px] text-faint">{hint}</span>}
    </button>
  );
}

function TreeRow({
  node,
  depth,
  active,
  open,
  hasChildren,
  renaming,
  dropZone,
  onToggle,
  onRename,
  onCancelRename,
  onAddChild,
  menu,
  href,
  onClick,
  dragProps,
}: {
  node: TreeNode;
  depth: number;
  active: boolean;
  open: boolean;
  hasChildren: boolean;
  renaming: boolean;
  dropZone: DropZone | null;
  onToggle: () => void;
  onRename: (t: string) => void;
  onCancelRename: () => void;
  onAddChild: () => void;
  menu: () => MenuItem[];
  href: string;
  onClick?: () => void;
  dragProps: React.HTMLAttributes<HTMLDivElement> & { draggable: boolean };
}) {
  const [menuAnchor, setMenuAnchor] = useState<HTMLElement | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  useEffect(() => {
    if (renaming) inputRef.current?.select();
  }, [renaming]);
  return (
    <div
      {...dragProps}
      className={cx(
        "group relative mx-1 flex h-[28px] items-center rounded-md pr-1",
        active ? "bg-active font-medium" : "hover:bg-hover",
        dropZone === "inside" && "ring-2 ring-accent ring-inset",
      )}
      style={{ paddingLeft: 4 + depth * 14 }}
      onContextMenu={(e) => {
        e.preventDefault();
        setMenuAnchor(e.currentTarget);
      }}
    >
      {dropZone === "before" && <div className="absolute left-2 right-2 top-0 h-0.5 rounded bg-accent" />}
      {dropZone === "after" && <div className="absolute bottom-0 left-2 right-2 h-0.5 rounded bg-accent" />}
      <button className="icon-btn h-5 w-5" onClick={onToggle} aria-label={open ? "Collapse" : "Expand"} tabIndex={-1}>
        <ChevronRight size={14} className={cx("transition-transform", open && "rotate-90", !hasChildren && "opacity-40")} />
      </button>
      {renaming ? (
        <input
          ref={inputRef}
          className="input ml-1 h-6 flex-1 px-1"
          defaultValue={node.title}
          onBlur={(e) => onRename(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") onRename((e.target as HTMLInputElement).value);
            if (e.key === "Escape") onCancelRename();
          }}
        />
      ) : (
        <Link href={href} onClick={onClick} className="flex min-w-0 flex-1 items-center gap-2 px-1" draggable={false}>
          <PageIcon icon={node.icon} kind={node.kind} />
          <span className="truncate">{pageTitle(node.title)}</span>
          {node.visibility === "private" && node.section === "shared" && <Lock size={11} className="flex-none text-faint" />}
        </Link>
      )}
      <div className={cx("flex items-center", menuAnchor ? "opacity-100" : "opacity-0 group-hover:opacity-100 focus-within:opacity-100")}>
        <button className="icon-btn h-6 w-6" title="Delete, duplicate, and more…" onClick={(e) => setMenuAnchor(e.currentTarget)}>
          <MoreHorizontal size={15} />
        </button>
        {node.kind === "page" && (
          <button className="icon-btn h-6 w-6" title="Add a page inside" onClick={onAddChild}>
            <Plus size={15} />
          </button>
        )}
      </div>
      <Popover anchor={menuAnchor} open={!!menuAnchor} onClose={() => setMenuAnchor(null)}>
        <Menu items={menu()} onClose={() => setMenuAnchor(null)} />
      </Popover>
    </div>
  );
}

function FavRow({
  page,
  active,
  href,
  onClick,
  menu,
  dragging,
  onDragState,
  onDropBefore,
  nextId,
}: {
  page: PageSummary;
  active: boolean;
  href: string;
  onClick?: () => void;
  menu: () => MenuItem[];
  dragging: string | null;
  onDragState: (id: string | null) => void;
  onDropBefore: (dragged: string, beforeId: string | null) => void;
  nextId: string | null;
}) {
  const [menuAnchor, setMenuAnchor] = useState<HTMLElement | null>(null);
  const [zone, setZone] = useState<"before" | "after" | null>(null);
  return (
    <div
      data-fav={page.id}
      draggable
      onDragStart={(e) => {
        onDragState(page.id);
        e.dataTransfer.effectAllowed = "move";
        e.dataTransfer.setData("text/plain", page.title || "Untitled");
      }}
      onDragEnd={() => onDragState(null)}
      onDragOver={(e) => {
        if (!dragging || dragging === page.id) return;
        e.preventDefault();
        const r = e.currentTarget.getBoundingClientRect();
        setZone(e.clientY < r.top + r.height / 2 ? "before" : "after");
      }}
      onDragLeave={() => setZone(null)}
      onDrop={(e) => {
        e.preventDefault();
        if (dragging && dragging !== page.id) onDropBefore(dragging, zone === "after" ? nextId : page.id);
        setZone(null);
        onDragState(null);
      }}
      className={cx(
        "group mx-1 flex h-[28px] items-center rounded-md pl-2 pr-1",
        active ? "bg-active font-medium" : "hover:bg-hover",
        zone === "before" && "shadow-[inset_0_2px_0_var(--accent)]",
        zone === "after" && "shadow-[inset_0_-2px_0_var(--accent)]",
      )}
    >
      <Link href={href} onClick={onClick} className="flex min-w-0 flex-1 items-center gap-2 px-1">
        <PageIcon icon={page.icon} kind={page.kind} />
        <span className="truncate">{pageTitle(page.title)}</span>
      </Link>
      <button
        className="icon-btn h-6 w-6 opacity-0 group-hover:opacity-100 focus-visible:opacity-100 [@media(hover:none)]:opacity-100"
        onClick={(e) => setMenuAnchor(e.currentTarget)}
        title="More"
        aria-label={`More actions for ${pageTitle(page.title)}`}
        aria-haspopup="menu"
      >
        <MoreHorizontal size={15} />
      </button>
      <Popover anchor={menuAnchor} open={!!menuAnchor} onClose={() => setMenuAnchor(null)}>
        <Menu items={menu()} onClose={() => setMenuAnchor(null)} />
      </Popover>
    </div>
  );
}

function DatabaseRecordsInTree({ databaseId, depth, currentId, onNavigate }: { databaseId: string; depth: number; currentId: string | null; onNavigate?: () => void }) {
  const ws = useWorkspace();
  const [records, setRecords] = useState<{ id: string; title: string; icon: string | null }[] | null>(null);
  useEffect(() => {
    let alive = true;
    api
      .get<{ records: { id: string; title: string; icon: string | null }[] }>(`/api/databases/${databaseId}/records?q=`)
      .then((r) => alive && setRecords(r.records))
      .catch(() => alive && setRecords([]));
    return () => {
      alive = false;
    };
  }, [databaseId]);
  if (!records) return <div className="skeleton mx-6 my-1 h-3 w-24" />;
  return (
    <>
      {records.slice(0, 50).map((r) => (
        <Link
          key={r.id}
          href={`/w/${ws.workspace.id}/p/${r.id}`}
          onClick={onNavigate}
          className={cx("mx-1 flex h-[28px] items-center gap-2 rounded-md pr-2", r.id === currentId ? "bg-active font-medium" : "hover:bg-hover")}
          style={{ paddingLeft: 26 + depth * 14 }}
        >
          <PageIcon icon={r.icon} />
          <span className="truncate">{pageTitle(r.title)}</span>
        </Link>
      ))}
      {!records.length && (
        <div className="flex items-center gap-1 py-1 text-xs text-faint" style={{ paddingLeft: 28 + depth * 14 }}>
          <Database size={12} /> No records
        </div>
      )}
    </>
  );
}

