"use client";
import { useState } from "react";
import useSWR, { mutate } from "swr";
import { useWorkspace } from "@/client/workspace-context";
import { api, errorMessage } from "@/client/api";
import { Dialog, useUi, cx, Spinner } from "@/client/ui";
import { refreshTree } from "@/client/hooks";

interface Template {
  key: string;
  kind: "page" | "database";
  title: string;
  icon: string;
  description: string;
  category: string;
}

export function TemplatesDialog({ parentId, onClose }: { parentId: string | null | undefined; onClose: () => void }) {
  const ws = useWorkspace();
  const { toast } = useUi();
  const open = parentId !== undefined;
  const { data } = useSWR<{ templates: Template[] }>(open ? "/api/templates" : null);
  const [busy, setBusy] = useState<string | null>(null);
  const [filter, setFilter] = useState<string>("All");
  const cats = ["All", ...new Set((data?.templates ?? []).map((t) => t.category))];

  const apply = async (t: Template) => {
    setBusy(t.key);
    try {
      const r = await api.post<{ page: { id: string } }>("/api/templates", {
        key: t.key,
        workspaceId: ws.workspace.id,
        parentId: parentId ?? null,
        visibility: ws.canEdit ? "workspace" : "private",
      });
      await refreshTree(ws.workspace.id);
      if (parentId) mutate(`/api/pages/${parentId}`);
      onClose();
      ws.navigate(r.page.id);
    } catch (e) {
      toast(errorMessage(e), "error");
    } finally {
      setBusy(null);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} title="Templates" width={760}>
      <div className="flex gap-1 border-b border-line px-4 py-2">
        {cats.map((c) => (
          <button key={c} className={cx("rounded-full px-3 py-1 text-xs", filter === c ? "bg-fg text-bg" : "text-muted hover:bg-hover")} onClick={() => setFilter(c)}>
            {c}
          </button>
        ))}
      </div>
      <div className="grid max-h-[60vh] grid-cols-1 gap-3 overflow-y-auto p-4 sm:grid-cols-2">
        {!data && (
          <div className="col-span-2 flex justify-center p-8">
            <Spinner />
          </div>
        )}
        {data?.templates
          .filter((t) => filter === "All" || t.category === filter)
          .map((t) => (
            <button key={t.key} disabled={!!busy} onClick={() => apply(t)} className="flex items-start gap-3 rounded-lg border border-line p-4 text-left hover:bg-hover disabled:opacity-60">
              <span className="text-2xl">{t.icon}</span>
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-2 font-medium">
                  {t.title}
                  <span className="rounded bg-subtle px-1.5 text-[10px] uppercase tracking-wide text-muted">{t.kind}</span>
                </span>
                <span className="mt-1 block text-sm text-muted">{t.description}</span>
              </span>
              {busy === t.key && <Spinner />}
            </button>
          ))}
      </div>
    </Dialog>
  );
}
