"use client";
import { useState } from "react";
import useSWR, { mutate } from "swr";
import { Undo2, Trash2 } from "lucide-react";
import { useWorkspace } from "@/client/workspace-context";
import { api, errorMessage } from "@/client/api";
import { Dialog, useUi, Spinner } from "@/client/ui";
import { refreshTree } from "@/client/hooks";
import { PageIcon, pageTitle } from "./page-icon";

interface TrashItem {
  id: string;
  title: string;
  icon: string | null;
  kind: "page" | "database";
  databaseId: string | null;
  archivedAt: string;
}

export function TrashDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const ws = useWorkspace();
  const { toast, confirm } = useUi();
  const [q, setQ] = useState("");
  const key = open ? `/api/workspaces/${ws.workspace.id}/trash?q=${encodeURIComponent(q)}` : null;
  const { data, isLoading } = useSWR<{ pages: TrashItem[] }>(key);

  const restore = async (id: string) => {
    try {
      await api.post(`/api/pages/${id}/restore`);
      mutate(key);
      refreshTree(ws.workspace.id);
      mutate(`/api/pages/${id}`);
      toast("Restored");
    } catch (e) {
      toast(errorMessage(e), "error");
    }
  };
  const remove = async (item: TrashItem) => {
    const ok = await confirm({
      title: `Delete “${pageTitle(item.title)}” permanently?`,
      message: "This deletes the page, its sub-pages, records and history. It cannot be undone.",
      confirmLabel: "Delete permanently",
      danger: true,
    });
    if (!ok) return;
    try {
      await api.del(`/api/pages/${item.id}`);
      mutate(key);
      toast("Deleted permanently");
    } catch (e) {
      toast(errorMessage(e), "error");
    }
  };

  return (
    <Dialog open={open} onClose={onClose} title="Trash" width={520}>
      <div className="p-3">
        <input className="input w-full" placeholder="Filter by page title…" value={q} onChange={(e) => setQ(e.target.value)} autoFocus />
      </div>
      <div className="max-h-[55vh] overflow-y-auto px-2 pb-3">
        {isLoading && (
          <div className="flex justify-center p-6">
            <Spinner />
          </div>
        )}
        {data?.pages.length === 0 && <p className="p-6 text-center text-sm text-muted">The trash is empty.</p>}
        {data?.pages.map((p) => (
          <div key={p.id} className="group flex items-center gap-2 rounded-md px-2 py-1.5 hover:bg-hover">
            <PageIcon icon={p.icon} kind={p.kind} />
            <a className="min-w-0 flex-1" href={`/w/${ws.workspace.id}/p/${p.id}`} onClick={onClose}>
              <div className="truncate text-sm">{pageTitle(p.title)}</div>
              <div className="text-xs text-faint">
                {p.databaseId ? "Database record · " : ""}Deleted {new Date(p.archivedAt).toLocaleString()}
              </div>
            </a>
            <button className="icon-btn" title="Restore" onClick={() => restore(p.id)}>
              <Undo2 size={15} />
            </button>
            <button className="icon-btn hover:text-danger" title="Delete permanently" onClick={() => remove(p)}>
              <Trash2 size={15} />
            </button>
          </div>
        ))}
      </div>
      <p className="border-t border-line px-4 py-2 text-xs text-muted">Pages stay in the trash until you delete them{" "}(an administrator can configure automatic cleanup).</p>
    </Dialog>
  );
}
