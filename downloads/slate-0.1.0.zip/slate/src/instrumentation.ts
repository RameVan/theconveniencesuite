// Runs once when the server starts: apply migrations and schedule housekeeping.
export async function register() {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;
  const { getDb } = await import("./server/db");
  const { config } = await import("./server/config");
  const { purgeExpiredTrash } = await import("./server/services/pages");
  const { cleanupUnreferencedFiles } = await import("./server/services/files");
  try {
    // Opening the database applies pending migrations before the first request.
    await getDb();
    console.log(`[slate] database ready (${config.databaseUrl ? "PostgreSQL" : "embedded PGlite in " + config.dataDir})`);
  } catch (err) {
    console.error("[slate] database initialisation failed:", err instanceof Error ? err.message : err);
    return;
  }
  if (config.realtimeEnabled) {
    const { startCollabServer } = await import("./server/collab");
    await startCollabServer();
  }
  const housekeeping = async () => {
    try {
      const db = await getDb();
      const purged = await purgeExpiredTrash(db, config.trashRetentionDays);
      if (purged) console.log(`[slate] purged ${purged} trashed page(s) older than ${config.trashRetentionDays} days`);
      if (process.env.FILE_CLEANUP_ON_SCHEDULE === "true") {
        const removed = await cleanupUnreferencedFiles(db);
        if (removed) console.log(`[slate] removed ${removed} unreferenced file(s)`);
      }
    } catch (err) {
      console.error("[slate] housekeeping failed:", err instanceof Error ? err.message : err);
    }
  };
  const timer = setInterval(housekeeping, 6 * 3_600_000);
  timer.unref?.();
  setTimeout(housekeeping, 60_000).unref?.();
}
