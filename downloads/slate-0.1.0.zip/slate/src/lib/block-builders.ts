// Small helpers for building block JSON in code (templates, starter content, tests).
import type { PMNode, PMMark } from "./blocks";
import { uid } from "./uid";

const rid = () => uid();

export function text(t: string, marks?: PMMark[]): PMNode {
  return marks?.length ? { type: "text", text: t, marks } : { type: "text", text: t };
}

/** Inline content from a string with **bold**, *italic* and `code` shorthand. */
export function inline(s: string): PMNode[] {
  if (!s) return [];
  const out: PMNode[] = [];
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)/g;
  let last = 0;
  for (const m of s.matchAll(re)) {
    if (m.index! > last) out.push(text(s.slice(last, m.index)));
    const tok = m[0];
    if (tok.startsWith("**")) out.push(text(tok.slice(2, -2), [{ type: "bold" }]));
    else if (tok.startsWith("`")) out.push(text(tok.slice(1, -1), [{ type: "code" }]));
    else out.push(text(tok.slice(1, -1), [{ type: "italic" }]));
    last = m.index! + tok.length;
  }
  if (last < s.length) out.push(text(s.slice(last)));
  return out;
}

const withId = (n: PMNode): PMNode => ({ ...n, attrs: { id: rid(), ...(n.attrs ?? {}) } });

export const p = (s = ""): PMNode => withId({ type: "paragraph", content: inline(s) });
export const h = (level: 1 | 2 | 3, s: string): PMNode => withId({ type: "heading", attrs: { level }, content: inline(s) });
export const bullets = (items: string[]): PMNode =>
  withId({ type: "bulletList", content: items.map((i) => ({ type: "listItem", content: [{ type: "paragraph", content: inline(i) }] })) });
export const numbered = (items: string[]): PMNode =>
  withId({ type: "orderedList", attrs: { start: 1 }, content: items.map((i) => ({ type: "listItem", content: [{ type: "paragraph", content: inline(i) }] })) });
export const todos = (items: [string, boolean?][]): PMNode =>
  withId({
    type: "taskList",
    content: items.map(([t, checked]) => ({ type: "taskItem", attrs: { checked: !!checked }, content: [{ type: "paragraph", content: inline(t) }] })),
  });
export const quote = (s: string): PMNode => withId({ type: "blockquote", content: [{ type: "paragraph", content: inline(s) }] });
export const callout = (icon: string, s: string, color = "gray"): PMNode =>
  withId({ type: "callout", attrs: { icon, color }, content: [{ type: "paragraph", content: inline(s) }] });
export const divider = (): PMNode => withId({ type: "horizontalRule" });
export const code = (language: string, src: string): PMNode => withId({ type: "codeBlock", attrs: { language }, content: src ? [text(src)] : [] });
export const toggle = (summary: string, children: PMNode[]): PMNode =>
  withId({ type: "toggle", attrs: { open: false }, content: [{ type: "paragraph", content: inline(summary) }, ...children.map(({ attrs, ...rest }) => { void attrs; return rest as PMNode; })] });
export const equation = (latex: string): PMNode => withId({ type: "equation", attrs: { latex } });
export const toc = (): PMNode => withId({ type: "toc" });
export const childPage = (pageId: string): PMNode => withId({ type: "childPage", attrs: { pageId } });
export const databaseView = (databaseId: string, viewId?: string): PMNode => withId({ type: "databaseView", attrs: { databaseId, viewId: viewId ?? null } });
