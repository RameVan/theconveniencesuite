// Block document model shared by the editor, the server and the import/export converters.
// A page's content is a list of top-level blocks; each block is a ProseMirror node JSON object
// carrying a stable `attrs.id`.

export interface PMMark {
  type: string;
  attrs?: Record<string, unknown>;
}
export interface PMNode {
  type: string;
  attrs?: Record<string, unknown>;
  content?: PMNode[];
  text?: string;
  marks?: PMMark[];
}

export interface BlockInput {
  id: string;
  content: PMNode;
}

export const TOP_LEVEL_TYPES = [
  "paragraph",
  "heading",
  "bulletList",
  "orderedList",
  "taskList",
  "blockquote",
  "codeBlock",
  "horizontalRule",
  "table",
  "image",
  "video",
  "audio",
  "fileBlock",
  "bookmark",
  "embed",
  "callout",
  "toggle",
  "equation",
  "toc",
  "breadcrumb",
  "childPage",
  "databaseView",
] as const;

export const NESTED_TYPES = ["listItem", "taskItem", "tableRow", "tableCell", "tableHeader", "text", "hardBreak", "inlineMath", "pageLink", "mention"] as const;

export const MARK_TYPES = ["bold", "italic", "underline", "strike", "code", "link", "textStyle", "highlight", "comment"] as const;

const NODE_SET = new Set<string>([...TOP_LEVEL_TYPES, ...NESTED_TYPES]);
const TOP_SET = new Set<string>(TOP_LEVEL_TYPES);
const MARK_SET = new Set<string>(MARK_TYPES);

export class BlockValidationError extends Error {}

const SAFE_URL = /^(https?:|mailto:|tel:|\/|#|\.\/|\.\.\/)/i;

/** Returns the URL if safe to render as a link/src, otherwise null. */
export function safeUrl(url: unknown): string | null {
  if (typeof url !== "string") return null;
  const trimmed = url.trim();
  if (!trimmed) return null;
  // Reject control characters that browsers strip before scheme parsing ("java\tscript:").
  if (/[\u0000-\u001F\u007F]/.test(trimmed)) return null;
  if (SAFE_URL.test(trimmed)) return trimmed;
  // Scheme-less "example.com" is treated as https.
  if (/^[a-z0-9.-]+\.[a-z]{2,}(\/|$)/i.test(trimmed)) return `https://${trimmed}`;
  return null;
}

const ID_RE = /^[A-Za-z0-9_-]{1,64}$/;
const URL_ATTRS = new Set(["href", "src", "url"]);
const MAX_DEPTH = 100;
const MAX_ATTR_STRING = 100_000;

function cleanAttrs(attrs: unknown): Record<string, unknown> | undefined {
  if (attrs == null) return undefined;
  if (typeof attrs !== "object" || Array.isArray(attrs)) throw new BlockValidationError("attrs must be an object");
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(attrs as Record<string, unknown>)) {
    if (k === "__proto__" || k === "constructor" || k === "prototype") continue;
    if (v === undefined) continue;
    if (typeof v === "string") {
      if (v.length > MAX_ATTR_STRING) throw new BlockValidationError(`attribute ${k} is too long`);
      out[k] = URL_ATTRS.has(k) ? (v === "" ? "" : safeUrl(v)) : v;
    } else if (v === null || typeof v === "number" || typeof v === "boolean") {
      out[k] = v;
    } else {
      // Nested JSON attrs (e.g. database view config) — size-bounded by the request limit.
      out[k] = JSON.parse(JSON.stringify(v));
    }
  }
  return out;
}

function cleanNode(node: unknown, depth: number): PMNode {
  if (depth > MAX_DEPTH) throw new BlockValidationError("Block content is nested too deeply");
  if (!node || typeof node !== "object" || Array.isArray(node)) throw new BlockValidationError("node must be an object");
  const n = node as Record<string, unknown>;
  if (typeof n.type !== "string" || !NODE_SET.has(n.type)) throw new BlockValidationError(`Unsupported block type: ${String(n.type)}`);
  const out: PMNode = { type: n.type };
  const attrs = cleanAttrs(n.attrs);
  if (attrs && Object.keys(attrs).length) out.attrs = attrs;
  if (n.type === "text") {
    if (typeof n.text !== "string" || !n.text) throw new BlockValidationError("text node needs text");
    out.text = n.text;
  }
  if (n.marks != null) {
    if (!Array.isArray(n.marks)) throw new BlockValidationError("marks must be an array");
    const marks: PMMark[] = [];
    for (const m of n.marks as unknown[]) {
      if (!m || typeof m !== "object") continue;
      const mm = m as Record<string, unknown>;
      if (typeof mm.type !== "string" || !MARK_SET.has(mm.type)) continue; // drop unknown marks
      const mAttrs = cleanAttrs(mm.attrs);
      if (mm.type === "link" && !mAttrs?.href) continue; // drop unsafe links
      if (mm.type === "comment" && !ID_RE.test(String(mAttrs?.threadId ?? ""))) continue; // comment anchors need a thread id
      marks.push(mAttrs && Object.keys(mAttrs).length ? { type: mm.type, attrs: mAttrs } : { type: mm.type });
    }
    if (marks.length) out.marks = marks;
  }
  if (n.content != null) {
    if (!Array.isArray(n.content)) throw new BlockValidationError("content must be an array");
    out.content = (n.content as unknown[]).map((c) => cleanNode(c, depth + 1));
  }
  return out;
}


/** Validate and sanitise a list of top-level blocks. Throws BlockValidationError. */
export function validateBlocks(input: unknown): { id: string; type: string; content: PMNode }[] {
  if (!Array.isArray(input)) throw new BlockValidationError("blocks must be an array");
  const seen = new Set<string>();
  return input.map((raw, i) => {
    if (!raw || typeof raw !== "object") throw new BlockValidationError(`block ${i} is invalid`);
    const r = raw as Record<string, unknown>;
    const content = cleanNode(r.content, 0);
    if (!TOP_SET.has(content.type)) throw new BlockValidationError(`"${content.type}" cannot be a top-level block`);
    const id = String(r.id ?? content.attrs?.id ?? "");
    if (!ID_RE.test(id)) throw new BlockValidationError(`block ${i} has an invalid id`);
    if (seen.has(id)) throw new BlockValidationError(`duplicate block id ${id}`);
    seen.add(id);
    content.attrs = { ...(content.attrs ?? {}), id };
    return { id, type: content.type, content };
  });
}

/** Plain text of a node, for search indexing and previews. */
export function nodeText(node: PMNode): string {
  const parts: string[] = [];
  const walk = (n: PMNode) => {
    if (n.type === "text" && n.text) parts.push(n.text);
    else if (n.type === "hardBreak") parts.push("\n");
    else if (n.type === "equation" || n.type === "inlineMath") parts.push(String(n.attrs?.latex ?? ""));
    else if (n.type === "mention") parts.push(`@${String(n.attrs?.label ?? "")}`);
    else if (n.type === "bookmark") parts.push([n.attrs?.title, n.attrs?.description, n.attrs?.url].filter(Boolean).join(" "));
    else if (n.type === "fileBlock" || n.type === "image" || n.type === "video" || n.type === "audio")
      parts.push(String(n.attrs?.name ?? n.attrs?.caption ?? n.attrs?.alt ?? ""));
    if (n.content) {
      const before = parts.length;
      for (const c of n.content) walk(c);
      if (n.type !== "paragraph" && n.type !== "heading" && parts.length > before) parts.push(" ");
    }
  };
  walk(node);
  return parts.join("").replace(/[ \t]+/g, " ").trim();
}

export function blocksText(blocks: { content: PMNode }[]): string {
  return blocks.map((b) => nodeText(b.content)).join("\n");
}

/** Replace all block ids (used when duplicating or importing). */
export function withFreshIds(blocks: PMNode[], newId: () => string): PMNode[] {
  return blocks.map((b) => ({ ...b, attrs: { ...(b.attrs ?? {}), id: newId() } }));
}

/** Visit every node (depth-first). */
export function visitNodes(node: PMNode, fn: (n: PMNode) => void) {
  fn(node);
  node.content?.forEach((c) => visitNodes(c, fn));
}

/**
 * JSON with object keys sorted, for comparing content regardless of key order (PostgreSQL `jsonb`
 * reorders keys, so stored blocks never stringify like freshly built ones).
 */
export function canonicalJson(value: unknown): string {
  return JSON.stringify(value, (_k, v) =>
    v && typeof v === "object" && !Array.isArray(v) ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, (v as Record<string, unknown>)[k]])) : v,
  );
}
