// RFC 4180 CSV parsing and formatting.

const BOM = String.fromCharCode(0xfeff);

export function parseCsv(input: string, delimiter?: string): string[][] {
  const text = input.startsWith(BOM) ? input.slice(1) : input;
  const delim = delimiter ?? detectDelimiter(text);
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i++;
        } else inQuotes = false;
      } else field += c;
      continue;
    }
    if (c === '"' && field === "") inQuotes = true;
    else if (c === delim) {
      row.push(field);
      field = "";
    } else if (c === "\n" || c === "\r") {
      if (c === "\r" && text[i + 1] === "\n") i++;
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else field += c;
  }
  if (field !== "" || row.length) {
    row.push(field);
    rows.push(row);
  }
  return rows.filter((r) => !(r.length === 1 && r[0] === ""));
}

function detectDelimiter(text: string): string {
  const firstLine = text.split(/\r?\n/, 1)[0] ?? "";
  const counts = [",", ";", "\t"].map((d) => [d, firstLine.split(d).length] as const);
  return counts.sort((a, b) => b[1] - a[1])[0][0];
}

/** Values a spreadsheet would interpret as a formula get a leading apostrophe. */
function isRisky(v: string): boolean {
  if (/^[=+@\t\r]/.test(v)) return true;
  return v.startsWith("-") && Number.isNaN(Number(v));
}

export function csvField(v: string): string {
  const safe = isRisky(v) ? `'${v}` : v;
  return /[",\n\r]/.test(safe) ? `"${safe.replace(/"/g, '""')}"` : safe;
}

/** Undo the formula-injection guard added by csvField. */
export function unguard(v: string): string {
  return v.startsWith("'") && isRisky(v.slice(1)) ? v.slice(1) : v;
}

export function toCsv(rows: string[][]): string {
  return BOM + rows.map((r) => r.map(csvField).join(",")).join("\r\n") + "\r\n";
}
