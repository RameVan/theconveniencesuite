// Types shared by the server and the client for databases, properties, views and filters.

export const PROPERTY_TYPES = [
  "title",
  "rich_text",
  "number",
  "select",
  "multi_select",
  "status",
  "date",
  "checkbox",
  "url",
  "email",
  "phone",
  "person",
  "files",
  "relation",
  "rollup",
  "formula",
  "created_time",
  "created_by",
  "last_edited_time",
  "last_edited_by",
  "unique_id",
] as const;
export type PropertyType = (typeof PROPERTY_TYPES)[number];

export const PROPERTY_TYPE_LABELS: Record<PropertyType, string> = {
  title: "Title",
  rich_text: "Text",
  number: "Number",
  select: "Select",
  multi_select: "Multi-select",
  status: "Status",
  date: "Date",
  checkbox: "Checkbox",
  url: "URL",
  email: "Email",
  phone: "Phone",
  person: "Person",
  files: "Files & media",
  relation: "Relation",
  rollup: "Rollup",
  formula: "Formula",
  created_time: "Created time",
  created_by: "Created by",
  last_edited_time: "Last edited time",
  last_edited_by: "Last edited by",
  unique_id: "ID",
};

/** Computed / system properties whose values cannot be written directly. */
export const READONLY_TYPES: ReadonlySet<PropertyType> = new Set([
  "rollup",
  "formula",
  "created_time",
  "created_by",
  "last_edited_time",
  "last_edited_by",
  "unique_id",
]);

export const COLORS = ["default", "gray", "brown", "orange", "yellow", "green", "blue", "purple", "pink", "red"] as const;
export type Color = (typeof COLORS)[number];

export interface SelectOption {
  id: string;
  name: string;
  color: Color;
}

export interface StatusGroup {
  id: string;
  name: string;
  color: Color;
  optionIds: string[];
}

export type NumberFormat = "number" | "number_commas" | "percent" | "dollar" | "euro" | "pound" | "yen" | "rupee";

export const ROLLUP_FUNCTIONS = [
  "show_original",
  "count",
  "count_values",
  "unique",
  "empty",
  "not_empty",
  "percent_empty",
  "percent_not_empty",
  "sum",
  "average",
  "median",
  "min",
  "max",
  "range",
  "earliest",
  "latest",
  "date_range",
  "checked",
  "unchecked",
  "percent_checked",
] as const;
export type RollupFunction = (typeof ROLLUP_FUNCTIONS)[number];

export interface PropertyConfig {
  options?: SelectOption[]; // select, multi_select, status
  groups?: StatusGroup[]; // status
  format?: NumberFormat; // number
  precision?: number; // number
  includeTime?: boolean; // date
  dateFormat?: "relative" | "full" | "short" | "iso";
  targetDatabaseId?: string; // relation
  syncedPropertyId?: string | null; // relation (two-way)
  limit?: number | null; // relation: 1 = single record
  relationPropertyId?: string; // rollup
  targetPropertyId?: string; // rollup ("title" for record title)
  function?: RollupFunction; // rollup
  expression?: string; // formula
  prefix?: string; // unique_id
  nextId?: number; // unique_id
}

export interface PropertyDef {
  id: string;
  databaseId: string;
  name: string;
  type: PropertyType;
  config: PropertyConfig;
  position: number;
}

export interface DateValue {
  start: string; // YYYY-MM-DD or ISO datetime
  end?: string | null;
  includeTime?: boolean;
}

export interface FileValue {
  name: string;
  url: string;
  fileId?: string;
}

/** Display-ready value of a property for one record (after computing formulas/rollups). */
export type CellValue =
  | null
  | string
  | number
  | boolean
  | string[]
  | DateValue
  | FileValue[]
  | { type: "list"; items: CellValue[] }
  | { type: "error"; message: string };

// ---------------- Filters ----------------

export type FilterOperator =
  | "equals"
  | "not_equals"
  | "contains"
  | "not_contains"
  | "starts_with"
  | "ends_with"
  | "is_empty"
  | "is_not_empty"
  | "gt"
  | "lt"
  | "gte"
  | "lte"
  | "before"
  | "after"
  | "on_or_before"
  | "on_or_after"
  | "is_relative"
  | "is_checked"
  | "is_not_checked";

export type RelativeDate =
  | "today"
  | "tomorrow"
  | "yesterday"
  | "this_week"
  | "past_week"
  | "next_week"
  | "this_month"
  | "past_month"
  | "next_month"
  | "past_year"
  | "next_year";

export interface FilterCondition {
  kind: "condition";
  id: string;
  propertyId: string;
  operator: FilterOperator;
  value?: unknown;
}

export interface FilterGroup {
  kind: "group";
  id: string;
  op: "and" | "or";
  filters: (FilterCondition | FilterGroup)[];
}

export interface SortSpec {
  propertyId: string;
  direction: "asc" | "desc";
}

export const AGGREGATIONS = [
  "none",
  "count",
  "count_values",
  "unique",
  "empty",
  "not_empty",
  "percent_empty",
  "percent_not_empty",
  "sum",
  "average",
  "median",
  "min",
  "max",
  "range",
  "earliest",
  "latest",
  "checked",
  "unchecked",
  "percent_checked",
] as const;
export type Aggregation = (typeof AGGREGATIONS)[number];

export const VIEW_TYPES = ["table", "board", "list", "gallery", "calendar", "timeline", "chart"] as const;
export type ViewType = (typeof VIEW_TYPES)[number];

export interface ViewConfig {
  filter?: FilterGroup | null;
  sorts?: SortSpec[];
  groupBy?: string | null;
  hiddenGroups?: string[];
  hideEmptyGroups?: boolean;
  visibleProperties?: string[]; // ordered property ids shown in this view
  propertyWidths?: Record<string, number>;
  aggregations?: Record<string, Aggregation>;
  wrapCells?: boolean;
  manualOrder?: string[]; // record ids, when no sorts are set
  // calendar / timeline
  dateProperty?: string | null;
  endDateProperty?: string | null;
  timelineScale?: "day" | "week" | "month";
  // gallery
  cardCover?: "none" | "page_cover" | "page_content" | string; // or a files property id
  cardSize?: "small" | "medium" | "large";
  // chart
  chartType?: "bar" | "column" | "line" | "donut";
  chartAggregate?: Aggregation;
  chartValueProperty?: string | null;
  // board
  cardPreview?: "none" | "page_cover";
}

export interface ViewDef {
  id: string;
  databaseId: string;
  name: string;
  type: ViewType;
  config: ViewConfig;
  position: number;
}

export interface QueryRow {
  id: string;
  title: string;
  icon: string | null;
  cover: string | null;
  values: Record<string, CellValue>;
  createdAt: string;
  updatedAt: string;
  createdBy: string | null;
  updatedBy: string | null;
}

export interface QueryGroup {
  key: string; // option id / value key; "__empty__" for no value
  label: string;
  color: Color;
  /** Ids of the returned rows of this group (all of them unless the query was paged). */
  rowIds: string[];
  /** Number of records in the group. */
  count: number;
  aggregations: Record<string, CellValue>;
}

export interface QueryResult {
  rows: QueryRow[];
  total: number; // records before filtering
  /** Records matching filters and search (rows may hold only a page of them). */
  matched: number;
  /** Position of rows[0] in the full result; hasMore when rows after this page exist. */
  offset: number;
  hasMore: boolean;
  groups: QueryGroup[] | null;
  aggregations: Record<string, CellValue>;
  formulaErrors: Record<string, string>;
}

export const OPERATORS_BY_TYPE: Record<string, FilterOperator[]> = {
  text: ["contains", "not_contains", "equals", "not_equals", "starts_with", "ends_with", "is_empty", "is_not_empty"],
  number: ["equals", "not_equals", "gt", "lt", "gte", "lte", "is_empty", "is_not_empty"],
  select: ["equals", "not_equals", "is_empty", "is_not_empty"],
  multi: ["contains", "not_contains", "is_empty", "is_not_empty"],
  date: ["equals", "before", "after", "on_or_before", "on_or_after", "is_relative", "is_empty", "is_not_empty"],
  checkbox: ["is_checked", "is_not_checked"],
  boolean: ["is_checked", "is_not_checked"],
};

export const OPERATOR_LABELS: Record<FilterOperator, string> = {
  equals: "is",
  not_equals: "is not",
  contains: "contains",
  not_contains: "does not contain",
  starts_with: "starts with",
  ends_with: "ends with",
  is_empty: "is empty",
  is_not_empty: "is not empty",
  gt: ">",
  lt: "<",
  gte: "≥",
  lte: "≤",
  before: "is before",
  after: "is after",
  on_or_before: "is on or before",
  on_or_after: "is on or after",
  is_relative: "is within",
  is_checked: "is checked",
  is_not_checked: "is not checked",
};

/** Which operator family applies to a property type (formula/rollup resolved by result type). */
export function filterFamily(type: PropertyType): keyof typeof OPERATORS_BY_TYPE {
  switch (type) {
    case "number":
    case "unique_id":
      return "number";
    case "select":
    case "status":
      return "select";
    case "multi_select":
    case "person":
    case "relation":
    case "files":
    case "created_by":
    case "last_edited_by":
      return "multi";
    case "date":
    case "created_time":
    case "last_edited_time":
      return "date";
    case "checkbox":
      return "checkbox";
    default:
      return "text";
  }
}

/** Starting configuration of a new view of the given layout. */
export function defaultViewConfig(type: ViewDef["type"], props: PropertyDef[]): ViewConfig {
  const cfg: ViewConfig = { filter: null, sorts: [], visibleProperties: props.map((p) => p.id) };
  if (type === "board") {
    const g = props.find((p) => p.type === "status") ?? props.find((p) => p.type === "select") ?? props.find((p) => p.type === "multi_select");
    cfg.groupBy = g?.id ?? null;
  }
  if (type === "calendar" || type === "timeline") {
    cfg.dateProperty = props.find((p) => p.type === "date")?.id ?? null;
    cfg.timelineScale = "week";
  }
  if (type === "gallery") {
    cfg.cardCover = "page_cover";
    cfg.cardSize = "medium";
  }
  if (type === "chart") {
    const g = props.find((p) => p.type === "status") ?? props.find((p) => p.type === "select") ?? props.find((p) => p.type === "checkbox");
    cfg.groupBy = g?.id ?? null;
    cfg.chartType = "column";
    cfg.chartAggregate = "count";
  }
  if (type === "list" || type === "gallery" || type === "board") {
    cfg.visibleProperties = props.filter((p) => p.type !== "title").slice(0, 3).map((p) => p.id);
  }
  return cfg;
}
