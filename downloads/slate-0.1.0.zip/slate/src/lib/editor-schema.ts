// Editor schema shared by the browser editor and the server (realtime persistence).
// No React here: the client adds node views on top of these definitions, so both sides
// produce exactly the same ProseMirror schema.
import { Extension, Mark, Node, mergeAttributes, InputRule, getSchema, type AnyExtension } from "@tiptap/core";
import { Plugin, PluginKey } from "@tiptap/pm/state";
import StarterKit from "@tiptap/starter-kit";
import { TaskList, TaskItem } from "@tiptap/extension-list";
import { CodeBlockLowlight } from "@tiptap/extension-code-block-lowlight";
import { TextStyle, Color } from "@tiptap/extension-text-style";
import { Highlight } from "@tiptap/extension-highlight";
import { TableKit } from "@tiptap/extension-table";
import Image from "@tiptap/extension-image";
import { common, createLowlight } from "lowlight";
import type { Schema } from "@tiptap/pm/model";
import { TOP_LEVEL_TYPES } from "./blocks";
import { uid } from "./uid";

export const lowlight = createLowlight(common);

/** Yjs fragment that holds a page's document (same name on client and server). */
export const YDOC_FIELD = "default";

const newId = () => uid();

/** Gives every top-level block a stable, unique `id` attribute. */
export const BlockId = Extension.create({
  name: "blockId",
  addGlobalAttributes() {
    return [
      {
        types: [...TOP_LEVEL_TYPES],
        attributes: {
          id: {
            default: null,
            keepOnSplit: false,
            parseHTML: (el: HTMLElement) => el.getAttribute("data-block-id"),
            renderHTML: (attrs: Record<string, unknown>) => (attrs.id ? { "data-block-id": attrs.id } : {}),
          },
        },
      },
    ];
  },
  addProseMirrorPlugins() {
    return [
      new Plugin({
        key: new PluginKey("blockId"),
        appendTransaction: (trs, _old, state) => {
          if (!trs.some((t) => t.docChanged) && !trs.some((t) => t.getMeta("blockIdInit"))) return null;
          const tr = state.tr;
          const seen = new Set<string>();
          let changed = false;
          state.doc.forEach((node, offset) => {
            if (!("id" in node.attrs)) return;
            let id = node.attrs.id as string | null;
            if (!id || seen.has(id)) {
              id = newId();
              tr.setNodeMarkup(offset, undefined, { ...node.attrs, id });
              changed = true;
            }
            seen.add(id);
          });
          if (!changed) return null;
          tr.setMeta("addToHistory", false);
          return tr;
        },
      }),
    ];
  },
});

export const atomBlock = (name: string, attrs: Record<string, unknown>) =>
  Node.create({
    name,
    group: "block",
    atom: true,
    draggable: true,
    selectable: true,
    addAttributes() {
      return Object.fromEntries(Object.entries(attrs).map(([k, d]) => [k, { default: d }]));
    },
    parseHTML() {
      return [{ tag: `div[data-type="${name}"]` }];
    },
    renderHTML({ HTMLAttributes }) {
      return ["div", mergeAttributes(HTMLAttributes, { "data-type": name })];
    },
  });

export const Callout = Node.create({
  name: "callout",
  group: "block",
  content: "block+",
  defining: true,
  addAttributes() {
    return { icon: { default: "💡" }, color: { default: "gray" } };
  },
  parseHTML() {
    return [{ tag: 'div[data-type="callout"]' }, { tag: "aside" }];
  },
  renderHTML({ HTMLAttributes }) {
    return ["div", mergeAttributes(HTMLAttributes, { "data-type": "callout" }), 0];
  },
});

export const Toggle = Node.create({
  name: "toggle",
  group: "block",
  content: "paragraph block*",
  defining: true,
  addAttributes() {
    return { open: { default: true } };
  },
  parseHTML() {
    return [{ tag: 'div[data-type="toggle"]' }, { tag: "details" }];
  },
  renderHTML({ HTMLAttributes }) {
    return ["div", mergeAttributes(HTMLAttributes, { "data-type": "toggle" }), 0];
  },
  addKeyboardShortcuts() {
    return {
      // Enter at the end of a toggle's summary opens it and starts the first child line.
      Enter: ({ editor }) => {
        const { $from, empty } = editor.state.selection;
        if (!empty) return false;
        const toggleDepth = $from.depth - 1;
        if (toggleDepth < 0) return false;
        const node = $from.node(toggleDepth);
        if (node?.type.name !== "toggle" || $from.index(toggleDepth) !== 0 || $from.parentOffset !== $from.parent.content.size) return false;
        const pos = $from.after();
        const togglePos = $from.before(toggleDepth);
        return editor
          .chain()
          .command(({ tr }) => {
            tr.setNodeMarkup(togglePos, undefined, { ...node.attrs, open: true });
            return true;
          })
          .insertContentAt(pos, { type: "paragraph" })
          .setTextSelection(pos + 1)
          .run();
      },
    };
  },
});

export const Equation = atomBlock("equation", { latex: "" });
export const Bookmark = atomBlock("bookmark", { url: null, title: null, description: null, image: null, icon: null });
export const Embed = atomBlock("embed", { url: null });
export const Video = atomBlock("video", { src: null, name: null });
export const Audio = atomBlock("audio", { src: null, name: null });
export const FileBlock = atomBlock("fileBlock", { src: null, name: null, size: null, mime: null });
export const Toc = atomBlock("toc", {});
export const BreadcrumbBlock = atomBlock("breadcrumb", {});
export const ChildPage = atomBlock("childPage", { pageId: null });
/** An inline or linked database. Linked blocks may carry their own views (`views`), separate from the database's. */
export const DatabaseBlock = atomBlock("databaseView", { databaseId: null, viewId: null, views: null });

export const InlineMath = Node.create({
  name: "inlineMath",
  group: "inline",
  inline: true,
  atom: true,
  selectable: true,
  addAttributes() {
    return { latex: { default: "" } };
  },
  parseHTML() {
    return [{ tag: 'span[data-type="inlineMath"]' }];
  },
  renderHTML({ HTMLAttributes }) {
    return ["span", mergeAttributes(HTMLAttributes, { "data-type": "inlineMath" })];
  },
  addInputRules() {
    return [
      new InputRule({
        find: /(?:^|\s)\$([^$\s][^$]*?)\$$/,
        handler: ({ state, range, match }) => {
          const latex = match[1];
          const start = range.from + (match[0].startsWith("$") ? 0 : 1);
          state.tr.replaceWith(start, range.to, this.type.create({ latex }));
        },
      }),
    ];
  },
});

export const PageLink = Node.create({
  name: "pageLink",
  group: "inline",
  inline: true,
  atom: true,
  selectable: true,
  addAttributes() {
    return { pageId: { default: null }, title: { default: null } };
  },
  parseHTML() {
    return [{ tag: 'span[data-type="pageLink"]' }];
  },
  renderHTML({ HTMLAttributes }) {
    return ["span", mergeAttributes(HTMLAttributes, { "data-type": "pageLink" })];
  },
});

/** A mentioned person ({ userId, label }); mentioning notifies them if they can view the page. */
export const Mention = Node.create({
  name: "mention",
  group: "inline",
  inline: true,
  atom: true,
  selectable: true,
  addAttributes() {
    return { userId: { default: null }, label: { default: null } };
  },
  parseHTML() {
    return [{ tag: 'span[data-type="mention"]' }];
  },
  renderHTML({ node, HTMLAttributes }) {
    return ["span", mergeAttributes(HTMLAttributes, { "data-type": "mention", class: "mention" }), `@${node.attrs.label ?? ""}`];
  },
  renderText({ node }) {
    return `@${node.attrs.label ?? ""}`;
  },
});

/** Anchor of an inline comment thread; `threadId` is the thread's first comment id. Threads may overlap. */
export const CommentMark = Mark.create({
  name: "comment",
  inclusive: false,
  excludes: "",
  addAttributes() {
    return {
      threadId: {
        default: null,
        parseHTML: (el) => el.getAttribute("data-thread"),
        renderHTML: (attrs) => ({ "data-thread": attrs.threadId }),
      },
    };
  },
  parseHTML() {
    return [{ tag: "span[data-thread]" }];
  },
  renderHTML({ HTMLAttributes }) {
    return ["span", mergeAttributes(HTMLAttributes, { class: "comment-anchor" }), 0];
  },
});

export const SlateImage = Image.extend({
  draggable: true,
  addAttributes() {
    return {
      ...this.parent?.(),
      caption: { default: null },
      width: { default: null },
    };
  },
}).configure({ inline: false, allowBase64: false });

export const SlateCodeBlock = CodeBlockLowlight.configure({ lowlight, defaultLanguage: "plaintext" });

/** The nodes, marks and attributes of the editor, without UI plugins or node views. */
export function schemaExtensions(opts: { editable?: boolean; collaborative?: boolean } = {}): AnyExtension[] {
  return [
    StarterKit.configure({
      heading: { levels: [1, 2, 3] },
      codeBlock: false,
      // Yjs provides its own undo history in collaborative mode.
      undoRedo: opts.collaborative ? false : undefined,
      link: { openOnClick: !opts.editable, autolink: true, linkOnPaste: true, protocols: ["http", "https", "mailto", "tel"], HTMLAttributes: { rel: "noopener noreferrer nofollow", target: null } },
      dropcursor: { color: "var(--accent)", width: 3 },
    }),
    TaskList,
    TaskItem.configure({ nested: true }),
    SlateCodeBlock,
    TextStyle,
    Color,
    Highlight.configure({ multicolor: true }),
    TableKit.configure({ table: { resizable: true, cellMinWidth: 80 } }),
    SlateImage,
    Callout,
    Toggle,
    Equation,
    InlineMath,
    Bookmark,
    Embed,
    Video,
    Audio,
    FileBlock,
    Toc,
    BreadcrumbBlock,
    ChildPage,
    DatabaseBlock,
    PageLink,
    Mention,
    CommentMark,
    BlockId,
  ];
}

let cached: Schema | null = null;
/** ProseMirror schema of page content (server use). */
export function getEditorSchema(): Schema {
  cached ??= getSchema(schemaExtensions());
  return cached;
}
