// Display formatting for property values, shared by the UI and exports.
import type { CellValue, DateValue, FileValue, PropertyDef } from "./db-types";

export interface FormatCtx {
  pageTitle?: (id: string) => string;
  userName?: (id: string) => string;
  plain?: boolean;
}

const CURRENCY: Record<string, string> = { dollar: "USD", euro: "EUR", pound: "GBP", yen: "JPY", rupee: "INR" };

export function formatNumber(n: number, p?: PropertyDef): string {
  const format = p?.config.format ?? "number";
  const precision = p?.config.precision;
  const opts: Intl.NumberFormatOptions = {};
  if (precision != null) {
    opts.minimumFractionDigits = precision;
    opts.maximumFractionDigits = precision;
  } else opts.maximumFractionDigits = 10;
  switch (format) {
    case "number":
      return new Intl.NumberFormat("en-US", { ...opts, useGrouping: false }).format(n);
    case "number_commas":
      return new Intl.NumberFormat("en-US", opts).format(n);
    case "percent":
      return new Intl.NumberFormat("en-US", { ...opts, style: "percent", maximumFractionDigits: precision ?? 2 }).format(n / 100);
    default:
      return new Intl.NumberFormat("en-US", { ...opts, style: "currency", currency: CURRENCY[format] ?? "USD" }).format(n);
  }
}

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export function formatDate(d: DateValue, style: PropertyDef["config"]["dateFormat"] = "full"): string {
  const one = (s: string) => {
    const dateOnly = /^\d{4}-\d{2}-\d{2}$/.test(s);
    const dt = new Date(dateOnly ? s + "T00:00:00Z" : s);
    if (Number.isNaN(dt.getTime())) return s;
    const useUtc = dateOnly;
    const y = useUtc ? dt.getUTCFullYear() : dt.getFullYear();
    const m = useUtc ? dt.getUTCMonth() : dt.getMonth();
    const day = useUtc ? dt.getUTCDate() : dt.getDate();
    let out: string;
    if (style === "iso") out = `${y}-${String(m + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    else if (style === "short") out = `${m + 1}/${day}/${y}`;
    else if (style === "relative") {
      const today = new Date();
      const t0 = Date.UTC(today.getFullYear(), today.getMonth(), today.getDate());
      const diff = Math.round((Date.UTC(y, m, day) - t0) / 86_400_000);
      out = diff === 0 ? "Today" : diff === 1 ? "Tomorrow" : diff === -1 ? "Yesterday" : `${MONTHS[m]} ${day}, ${y}`;
    } else out = `${MONTHS[m]} ${day}, ${y}`;
    if (d.includeTime && !dateOnly) {
      out += ` ${String(dt.getHours()).padStart(2, "0")}:${String(dt.getMinutes()).padStart(2, "0")}`;
    }
    return out;
  };
  return d.end ? `${one(d.start)} → ${one(d.end)}` : one(d.start);
}

export function isDateValue(v: unknown): v is DateValue {
  return !!v && typeof v === "object" && !Array.isArray(v) && typeof (v as DateValue).start === "string";
}

export function formatCell(p: PropertyDef, v: CellValue, ctx: FormatCtx = {}): string {
  if (v === null || v === undefined) return "";
  if (typeof v === "object" && !Array.isArray(v) && "type" in v) {
    if (v.type === "error") return ctx.plain ? "" : `⚠ ${v.message}`;
    if (v.type === "list") return v.items.map((i) => formatCell({ ...p, type: "rich_text" }, i, ctx)).filter(Boolean).join(", ");
  }
  switch (p.type) {
    case "number":
      return typeof v === "number" ? formatNumber(v, p) : String(v);
    case "select":
    case "status":
      return p.config.options?.find((o) => o.id === v)?.name ?? "";
    case "multi_select":
      return Array.isArray(v) ? (v as string[]).map((id) => p.config.options?.find((o) => o.id === id)?.name ?? "").filter(Boolean).join(", ") : "";
    case "checkbox":
      return v === true ? (ctx.plain ? "true" : "✓") : ctx.plain ? "false" : "";
    case "date":
    case "created_time":
    case "last_edited_time":
      return isDateValue(v) ? (ctx.plain ? (v.end ? `${v.start} → ${v.end}` : v.start) : formatDate(v, p.config.dateFormat)) : "";
    case "person":
    case "created_by":
    case "last_edited_by":
      return Array.isArray(v) ? (v as string[]).map((id) => ctx.userName?.(id) ?? id).join(", ") : "";
    case "relation":
      return Array.isArray(v) ? (v as string[]).map((id) => ctx.pageTitle?.(id) || "Untitled").join(", ") : "";
    case "files":
      return Array.isArray(v) ? (v as unknown as FileValue[]).map((f) => (ctx.plain ? f.url : f.name)).join(", ") : "";
    default:
      if (typeof v === "number") return formatNumber(v);
      if (typeof v === "boolean") return v ? (ctx.plain ? "true" : "✓") : ctx.plain ? "false" : "";
      if (isDateValue(v)) return ctx.plain ? v.start : formatDate(v);
      if (Array.isArray(v)) return (v as unknown[]).map(String).join(", ");
      return String(v);
  }
}
