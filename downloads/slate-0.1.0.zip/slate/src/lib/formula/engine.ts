// Formula type checker and evaluator. Pure data in, pure data out — no host access, no eval.
import { FormulaError, parse, type Node } from "./parser";

export type FType = "number" | "text" | "boolean" | "date" | "list" | "empty" | "any";

export interface FDate {
  kind: "date";
  start: number; // epoch ms (UTC)
  end: number | null;
  time: boolean;
}
export type FValue = null | number | string | boolean | FDate | FValue[];

export interface PropertyBinding {
  type: FType;
  // Resolved at evaluation time for the current record.
  get?: () => FValue;
}

export interface CompileEnv {
  /** Property name → result type. */
  props: Record<string, FType>;
}

export interface Compiled {
  ast: Node;
  type: FType;
  refs: string[];
}

const MAX_STEPS = 200_000;
const MAX_TEXT = 100_000;
const MAX_LIST = 100_000;

// ------------------------------------------------------------------ helpers

function own<T>(obj: Record<string, T>, key: string): T | undefined {
  return Object.hasOwn(obj, key) ? obj[key] : undefined;
}

export function isDate(v: FValue): v is FDate {
  return typeof v === "object" && v !== null && !Array.isArray(v) && v.kind === "date";
}

export function typeOfValue(v: FValue): FType {
  if (v === null) return "empty";
  if (typeof v === "number") return "number";
  if (typeof v === "string") return "text";
  if (typeof v === "boolean") return "boolean";
  if (Array.isArray(v)) return "list";
  return "date";
}

export function isEmpty(v: FValue): boolean {
  return v === null || v === "" || (typeof v === "number" && Number.isNaN(v)) || (Array.isArray(v) && v.length === 0);
}

export function makeDate(start: number, end: number | null = null, time = false): FDate {
  return { kind: "date", start, end, time };
}

/** Parse "YYYY-MM-DD" or an ISO date-time into a date value. */
export function parseDateString(s: string): FDate | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s.trim());
  if (m) return makeDate(Date.UTC(+m[1], +m[2] - 1, +m[3]), null, false);
  const t = Date.parse(s);
  if (Number.isNaN(t)) return null;
  return makeDate(t, null, true);
}

const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const pad = (n: number, w = 2) => String(n).padStart(w, "0");

export function formatDateValue(d: FDate, fmt?: string): string {
  const one = (ms: number) => {
    const x = new Date(ms);
    if (!fmt) {
      const base = `${MONTHS[x.getUTCMonth()].slice(0, 3)} ${x.getUTCDate()}, ${x.getUTCFullYear()}`;
      return d.time ? `${base} ${pad(x.getUTCHours())}:${pad(x.getUTCMinutes())}` : base;
    }
    return fmt.replace(/YYYY|YY|MMMM|MMM|MM|M|DD|D|dddd|ddd|HH|H|hh|h|mm|ss|A/g, (tok) => {
      const h = x.getUTCHours();
      switch (tok) {
        case "YYYY":
          return String(x.getUTCFullYear());
        case "YY":
          return pad(x.getUTCFullYear() % 100);
        case "MMMM":
          return MONTHS[x.getUTCMonth()];
        case "MMM":
          return MONTHS[x.getUTCMonth()].slice(0, 3);
        case "MM":
          return pad(x.getUTCMonth() + 1);
        case "M":
          return String(x.getUTCMonth() + 1);
        case "DD":
          return pad(x.getUTCDate());
        case "D":
          return String(x.getUTCDate());
        case "dddd":
          return DAYS[x.getUTCDay()];
        case "ddd":
          return DAYS[x.getUTCDay()].slice(0, 3);
        case "HH":
          return pad(h);
        case "H":
          return String(h);
        case "hh":
          return pad(h % 12 || 12);
        case "h":
          return String(h % 12 || 12);
        case "mm":
          return pad(x.getUTCMinutes());
        case "ss":
          return pad(x.getUTCSeconds());
        case "A":
          return h < 12 ? "AM" : "PM";
      }
      return tok;
    });
  };
  return d.end != null ? `${one(d.start)} → ${one(d.end)}` : one(d.start);
}

export function formatNumber(n: number): string {
  if (!Number.isFinite(n)) return Number.isNaN(n) ? "NaN" : n > 0 ? "Infinity" : "-Infinity";
  if (Number.isInteger(n)) return String(n);
  return String(Number(n.toPrecision(12)));
}

export function toText(v: FValue): string {
  if (v === null) return "";
  if (typeof v === "string") return v;
  if (typeof v === "number") return formatNumber(v);
  if (typeof v === "boolean") return v ? "true" : "false";
  if (Array.isArray(v)) return v.map(toText).join(", ");
  return formatDateValue(v);
}

function equalValues(a: FValue, b: FValue): boolean {
  if (a === b) return true;
  if (isEmpty(a) && isEmpty(b)) return true;
  if (Array.isArray(a) && Array.isArray(b)) return a.length === b.length && a.every((x, i) => equalValues(x, b[i]));
  if (isDate(a) && isDate(b)) return a.start === b.start && a.end === b.end;
  if (typeof a === "number" && typeof b === "number") return a === b;
  return false;
}

function compareValues(a: FValue, b: FValue, pos: number): number {
  if (typeof a === "number" && typeof b === "number") return a - b;
  if (typeof a === "string" && typeof b === "string") return a < b ? -1 : a > b ? 1 : 0;
  if (isDate(a) && isDate(b)) return a.start - b.start;
  if (typeof a === "boolean" && typeof b === "boolean") return Number(a) - Number(b);
  throw new FormulaError(`Cannot compare ${typeOfValue(a)} with ${typeOfValue(b)}`, pos);
}

const UNIT_ALIASES: Record<string, string> = {
  year: "years",
  years: "years",
  quarter: "quarters",
  quarters: "quarters",
  month: "months",
  months: "months",
  week: "weeks",
  weeks: "weeks",
  day: "days",
  days: "days",
  hour: "hours",
  hours: "hours",
  minute: "minutes",
  minutes: "minutes",
  second: "seconds",
  seconds: "seconds",
  millisecond: "milliseconds",
  milliseconds: "milliseconds",
};

function unitOf(u: FValue, pos: number): string {
  const s = typeof u === "string" ? own(UNIT_ALIASES, u.toLowerCase()) : undefined;
  if (!s) throw new FormulaError(`Unknown date unit "${toText(u)}". Use years, quarters, months, weeks, days, hours, minutes, seconds or milliseconds.`, pos);
  return s;
}

function addToMs(ms: number, amount: number, unit: string): number {
  const d = new Date(ms);
  switch (unit) {
    case "years":
      d.setUTCFullYear(d.getUTCFullYear() + amount);
      return d.getTime();
    case "quarters":
      d.setUTCMonth(d.getUTCMonth() + amount * 3);
      return d.getTime();
    case "months":
      d.setUTCMonth(d.getUTCMonth() + amount);
      return d.getTime();
    case "weeks":
      return ms + amount * 7 * 86_400_000;
    case "days":
      return ms + amount * 86_400_000;
    case "hours":
      return ms + amount * 3_600_000;
    case "minutes":
      return ms + amount * 60_000;
    case "seconds":
      return ms + amount * 1000;
    default:
      return ms + amount;
  }
}

function diffIn(a: number, b: number, unit: string): number {
  const da = new Date(a),
    db = new Date(b);
  const months = (da.getUTCFullYear() - db.getUTCFullYear()) * 12 + (da.getUTCMonth() - db.getUTCMonth());
  const adjust = (m: number) => {
    // Whole months only when the day/time has passed.
    const shifted = addToMs(b, m, "months");
    if (m > 0 && shifted > a) return m - 1;
    if (m < 0 && shifted < a) return m + 1;
    return m;
  };
  switch (unit) {
    case "years":
      return Math.trunc(adjust(months) / 12);
    case "quarters":
      return Math.trunc(adjust(months) / 3);
    case "months":
      return adjust(months);
    case "weeks":
      return Math.trunc((a - b) / (7 * 86_400_000));
    case "days":
      return Math.trunc((a - b) / 86_400_000);
    case "hours":
      return Math.trunc((a - b) / 3_600_000);
    case "minutes":
      return Math.trunc((a - b) / 60_000);
    case "seconds":
      return Math.trunc((a - b) / 1000);
    default:
      return a - b;
  }
}

function flattenNumbers(args: FValue[]): number[] {
  const out: number[] = [];
  const walk = (v: FValue) => {
    if (Array.isArray(v)) v.forEach(walk);
    else if (typeof v === "number" && !Number.isNaN(v)) out.push(v);
  };
  args.forEach(walk);
  return out;
}

// ------------------------------------------------------------------ function table

type Fn = {
  min: number;
  max: number; // Infinity for variadic
  args?: FType[]; // expected types (last repeats for variadic); "any" accepts all
  ret: FType | ((argTypes: FType[]) => FType);
  impl: (args: FValue[], pos: number, ctx: EvalCtx) => FValue;
  doc: string;
};

function num(v: FValue, pos: number, fn: string): number {
  if (typeof v === "number") return v;
  if (v === null) return 0;
  if (typeof v === "boolean") return v ? 1 : 0;
  throw new FormulaError(`${fn}() expects a number but got ${typeOfValue(v)}`, pos);
}
function txt(v: FValue): string {
  return toText(v);
}
function date(v: FValue, pos: number, fn: string): FDate {
  if (isDate(v)) return v;
  throw new FormulaError(`${fn}() expects a date but got ${typeOfValue(v)}`, pos);
}
function list(v: FValue, pos: number, fn: string): FValue[] {
  if (Array.isArray(v)) return v;
  if (v === null) return [];
  throw new FormulaError(`${fn}() expects a list but got ${typeOfValue(v)}`, pos);
}
function cap(s: string, pos: number): string {
  if (s.length > MAX_TEXT) throw new FormulaError(`Text result is longer than ${MAX_TEXT} characters`, pos);
  return s;
}
const round = (x: number, d = 0) => {
  const f = Math.pow(10, d);
  return Math.round(x * f) / f;
};
const median = (xs: number[]) => {
  if (!xs.length) return null;
  const s = [...xs].sort((a, b) => a - b);
  const m = s.length >> 1;
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
};

export const FUNCTIONS: Record<string, Fn> = {
  // ---- math
  abs: { min: 1, max: 1, args: ["number"], ret: "number", impl: ([a], p) => Math.abs(num(a, p, "abs")), doc: "abs(n) — absolute value" },
  ceil: { min: 1, max: 1, args: ["number"], ret: "number", impl: ([a], p) => Math.ceil(num(a, p, "ceil")), doc: "ceil(n) — round up" },
  floor: { min: 1, max: 1, args: ["number"], ret: "number", impl: ([a], p) => Math.floor(num(a, p, "floor")), doc: "floor(n) — round down" },
  round: {
    min: 1,
    max: 2,
    args: ["number", "number"],
    ret: "number",
    impl: ([a, d], p) => round(num(a, p, "round"), d == null ? 0 : num(d, p, "round")),
    doc: "round(n, digits?) — round to digits",
  },
  sqrt: { min: 1, max: 1, args: ["number"], ret: "number", impl: ([a], p) => Math.sqrt(num(a, p, "sqrt")), doc: "sqrt(n)" },
  cbrt: { min: 1, max: 1, args: ["number"], ret: "number", impl: ([a], p) => Math.cbrt(num(a, p, "cbrt")), doc: "cbrt(n)" },
  exp: { min: 1, max: 1, args: ["number"], ret: "number", impl: ([a], p) => Math.exp(num(a, p, "exp")), doc: "exp(n)" },
  ln: { min: 1, max: 1, args: ["number"], ret: "number", impl: ([a], p) => Math.log(num(a, p, "ln")), doc: "ln(n)" },
  log10: { min: 1, max: 1, args: ["number"], ret: "number", impl: ([a], p) => Math.log10(num(a, p, "log10")), doc: "log10(n)" },
  log2: { min: 1, max: 1, args: ["number"], ret: "number", impl: ([a], p) => Math.log2(num(a, p, "log2")), doc: "log2(n)" },
  pow: {
    min: 2,
    max: 2,
    args: ["number", "number"],
    ret: "number",
    impl: ([a, b], p) => Math.pow(num(a, p, "pow"), num(b, p, "pow")),
    doc: "pow(base, exponent)",
  },
  mod: {
    min: 2,
    max: 2,
    args: ["number", "number"],
    ret: "number",
    impl: ([a, b], p) => num(a, p, "mod") % num(b, p, "mod"),
    doc: "mod(a, b) — remainder",
  },
  sign: { min: 1, max: 1, args: ["number"], ret: "number", impl: ([a], p) => Math.sign(num(a, p, "sign")), doc: "sign(n)" },
  pi: { min: 0, max: 0, ret: "number", impl: () => Math.PI, doc: "pi()" },
  e: { min: 0, max: 0, ret: "number", impl: () => Math.E, doc: "e()" },
  min: {
    min: 1,
    max: Infinity,
    args: ["any"],
    ret: "number",
    impl: (a) => {
      const xs = flattenNumbers(a);
      return xs.length ? Math.min(...xs) : null;
    },
    doc: "min(a, b, …) — smallest number (lists are flattened)",
  },
  max: {
    min: 1,
    max: Infinity,
    args: ["any"],
    ret: "number",
    impl: (a) => {
      const xs = flattenNumbers(a);
      return xs.length ? Math.max(...xs) : null;
    },
    doc: "max(a, b, …) — largest number",
  },
  sum: { min: 1, max: Infinity, args: ["any"], ret: "number", impl: (a) => flattenNumbers(a).reduce((s, x) => s + x, 0), doc: "sum(a, b, …)" },
  mean: {
    min: 1,
    max: Infinity,
    args: ["any"],
    ret: "number",
    impl: (a) => {
      const xs = flattenNumbers(a);
      return xs.length ? xs.reduce((s, x) => s + x, 0) / xs.length : null;
    },
    doc: "mean(a, b, …) — average (alias: average)",
  },
  median: { min: 1, max: Infinity, args: ["any"], ret: "number", impl: (a) => median(flattenNumbers(a)), doc: "median(a, b, …)" },

  // ---- text
  concat: {
    min: 1,
    max: Infinity,
    args: ["any"],
    ret: (ts) => (ts.every((t) => t === "list") ? "list" : "text"),
    impl: (a, p) => {
      if (a.every((x) => Array.isArray(x))) {
        const out = (a as FValue[][]).flat();
        if (out.length > MAX_LIST) throw new FormulaError("List is too long", p);
        return out;
      }
      return cap(a.map(txt).join(""), p);
    },
    doc: "concat(a, b, …) — join text, or concatenate lists",
  },
  length: {
    min: 1,
    max: 1,
    args: ["any"],
    ret: "number",
    impl: ([a]) => (Array.isArray(a) ? a.length : txt(a).length),
    doc: "length(text or list)",
  },
  lower: { min: 1, max: 1, args: ["any"], ret: "text", impl: ([a]) => txt(a).toLowerCase(), doc: "lower(text)" },
  upper: { min: 1, max: 1, args: ["any"], ret: "text", impl: ([a]) => txt(a).toUpperCase(), doc: "upper(text)" },
  trim: { min: 1, max: 1, args: ["any"], ret: "text", impl: ([a]) => txt(a).trim(), doc: "trim(text)" },
  contains: {
    min: 2,
    max: 2,
    args: ["any", "any"],
    ret: "boolean",
    impl: ([a, b]) => (Array.isArray(a) ? a.some((x) => equalValues(x, b) || txt(x) === txt(b)) : txt(a).includes(txt(b))),
    doc: "contains(text, search) — or list contains value",
  },
  startsWith: { min: 2, max: 2, args: ["any", "any"], ret: "boolean", impl: ([a, b]) => txt(a).startsWith(txt(b)), doc: "startsWith(text, prefix)" },
  endsWith: { min: 2, max: 2, args: ["any", "any"], ret: "boolean", impl: ([a, b]) => txt(a).endsWith(txt(b)), doc: "endsWith(text, suffix)" },
  indexOf: { min: 2, max: 2, args: ["any", "any"], ret: "number", impl: ([a, b]) => txt(a).indexOf(txt(b)), doc: "indexOf(text, search) — -1 if missing" },
  replace: {
    min: 3,
    max: 3,
    args: ["any", "any", "any"],
    ret: "text",
    impl: ([a, b, c], p) => cap(txt(a).replace(txt(b), txt(c)), p),
    doc: "replace(text, find, replacement) — first occurrence",
  },
  replaceAll: {
    min: 3,
    max: 3,
    args: ["any", "any", "any"],
    ret: "text",
    impl: ([a, b, c], p) => (txt(b) === "" ? txt(a) : cap(txt(a).split(txt(b)).join(txt(c)), p)),
    doc: "replaceAll(text, find, replacement)",
  },
  substring: {
    min: 2,
    max: 3,
    args: ["any", "number", "number"],
    ret: "text",
    impl: ([a, s, e], p) => txt(a).substring(num(s, p, "substring"), e == null ? undefined : num(e, p, "substring")),
    doc: "substring(text, start, end?)",
  },
  split: {
    min: 2,
    max: 2,
    args: ["any", "any"],
    ret: "list",
    impl: ([a, b], p) => {
      const parts = txt(a).split(txt(b));
      if (parts.length > MAX_LIST) throw new FormulaError("List is too long", p);
      return parts;
    },
    doc: "split(text, separator) — list of text",
  },
  join: {
    min: 2,
    max: 2,
    args: ["list", "any"],
    ret: "text",
    impl: ([a, b], p) => cap(list(a, p, "join").map(txt).join(txt(b)), p),
    doc: "join(list, separator)",
  },
  repeat: {
    min: 2,
    max: 2,
    args: ["any", "number"],
    ret: "text",
    impl: ([a, n], p) => {
      const s = txt(a);
      const k = Math.max(0, Math.floor(num(n, p, "repeat")));
      if (s.length * k > MAX_TEXT) throw new FormulaError("Text result is too long", p);
      return s.repeat(k);
    },
    doc: "repeat(text, times)",
  },
  padStart: {
    min: 3,
    max: 3,
    args: ["any", "number", "any"],
    ret: "text",
    impl: ([a, n, c], p) => txt(a).padStart(Math.min(MAX_TEXT, num(n, p, "padStart")), txt(c)),
    doc: "padStart(text, length, fill)",
  },
  padEnd: {
    min: 3,
    max: 3,
    args: ["any", "number", "any"],
    ret: "text",
    impl: ([a, n, c], p) => txt(a).padEnd(Math.min(MAX_TEXT, num(n, p, "padEnd")), txt(c)),
    doc: "padEnd(text, length, fill)",
  },
  format: { min: 1, max: 1, args: ["any"], ret: "text", impl: ([a]) => txt(a), doc: "format(value) — convert to text" },
  toNumber: {
    min: 1,
    max: 1,
    args: ["any"],
    ret: "number",
    impl: ([a]) => {
      if (typeof a === "number") return a;
      if (typeof a === "boolean") return a ? 1 : 0;
      if (isDate(a)) return a.start;
      if (a === null) return null;
      const n = Number(txt(a).replace(/[, ]/g, ""));
      return Number.isNaN(n) ? null : n;
    },
    doc: "toNumber(value) — empty if not numeric",
  },

  // ---- logic
  not: { min: 1, max: 1, args: ["any"], ret: "boolean", impl: ([a]) => !truthy(a), doc: "not(value)" },
  empty: { min: 1, max: 1, args: ["any"], ret: "boolean", impl: ([a]) => isEmpty(a), doc: "empty(value) — true for empty text/list/no value" },
  equal: { min: 2, max: 2, args: ["any", "any"], ret: "boolean", impl: ([a, b]) => equalValues(a, b), doc: "equal(a, b)" },

  // ---- dates
  now: { min: 0, max: 0, ret: "date", impl: (_a, _p, ctx) => makeDate(ctx.now, null, true), doc: "now() — current date and time" },
  today: {
    min: 0,
    max: 0,
    ret: "date",
    impl: (_a, _p, ctx) => {
      const d = new Date(ctx.now);
      return makeDate(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
    },
    doc: "today() — current date",
  },
  dateAdd: {
    min: 3,
    max: 3,
    args: ["date", "number", "text"],
    ret: "date",
    impl: ([d, n, u], p) => {
      const dd = date(d, p, "dateAdd");
      const unit = unitOf(u, p);
      const k = num(n, p, "dateAdd");
      return makeDate(addToMs(dd.start, k, unit), dd.end == null ? null : addToMs(dd.end, k, unit), dd.time);
    },
    doc: 'dateAdd(date, amount, "days") — units: years, quarters, months, weeks, days, hours, minutes, seconds',
  },
  dateSubtract: {
    min: 3,
    max: 3,
    args: ["date", "number", "text"],
    ret: "date",
    impl: ([d, n, u], p) => {
      const dd = date(d, p, "dateSubtract");
      const unit = unitOf(u, p);
      const k = -num(n, p, "dateSubtract");
      return makeDate(addToMs(dd.start, k, unit), dd.end == null ? null : addToMs(dd.end, k, unit), dd.time);
    },
    doc: 'dateSubtract(date, amount, "days")',
  },
  dateBetween: {
    min: 3,
    max: 3,
    args: ["date", "date", "text"],
    ret: "number",
    impl: ([a, b, u], p) => diffIn(date(a, p, "dateBetween").start, date(b, p, "dateBetween").start, unitOf(u, p)),
    doc: 'dateBetween(a, b, "days") — whole units from b to a',
  },
  dateStart: { min: 1, max: 1, args: ["date"], ret: "date", impl: ([d], p) => makeDate(date(d, p, "dateStart").start, null, (d as FDate).time), doc: "dateStart(date range)" },
  dateEnd: {
    min: 1,
    max: 1,
    args: ["date"],
    ret: "date",
    impl: ([d], p) => {
      const dd = date(d, p, "dateEnd");
      return makeDate(dd.end ?? dd.start, null, dd.time);
    },
    doc: "dateEnd(date range)",
  },
  dateRange: {
    min: 2,
    max: 2,
    args: ["date", "date"],
    ret: "date",
    impl: ([a, b], p) => {
      const s = date(a, p, "dateRange"),
        e = date(b, p, "dateRange");
      return makeDate(s.start, e.start, s.time || e.time);
    },
    doc: "dateRange(start, end)",
  },
  parseDate: {
    min: 1,
    max: 1,
    args: ["any"],
    ret: "date",
    impl: ([a]) => (isDate(a) ? a : parseDateString(txt(a))),
    doc: 'parseDate("2026-01-31") — ISO date text to date',
  },
  formatDate: {
    min: 1,
    max: 2,
    args: ["date", "text"],
    ret: "text",
    impl: ([d, f], p) => formatDateValue(date(d, p, "formatDate"), f == null ? undefined : txt(f)),
    doc: 'formatDate(date, "YYYY-MM-DD") — tokens: YYYY YY MMMM MMM MM M DD D dddd ddd HH H hh h mm ss A',
  },
  timestamp: { min: 1, max: 1, args: ["date"], ret: "number", impl: ([d], p) => date(d, p, "timestamp").start, doc: "timestamp(date) — milliseconds since 1970" },
  fromTimestamp: { min: 1, max: 1, args: ["number"], ret: "date", impl: ([n], p) => makeDate(num(n, p, "fromTimestamp"), null, true), doc: "fromTimestamp(ms)" },
  year: { min: 1, max: 1, args: ["date"], ret: "number", impl: ([d], p) => new Date(date(d, p, "year").start).getUTCFullYear(), doc: "year(date)" },
  month: { min: 1, max: 1, args: ["date"], ret: "number", impl: ([d], p) => new Date(date(d, p, "month").start).getUTCMonth() + 1, doc: "month(date) — 1–12" },
  date: { min: 1, max: 1, args: ["date"], ret: "number", impl: ([d], p) => new Date(date(d, p, "date").start).getUTCDate(), doc: "date(date) — day of month 1–31" },
  weekday: {
    min: 1,
    max: 1,
    args: ["date"],
    ret: "number",
    impl: ([d], p) => new Date(date(d, p, "weekday").start).getUTCDay() || 7,
    doc: "weekday(date) — 1 (Monday) … 7 (Sunday)",
  },
  hour: { min: 1, max: 1, args: ["date"], ret: "number", impl: ([d], p) => new Date(date(d, p, "hour").start).getUTCHours(), doc: "hour(date)" },
  minute: { min: 1, max: 1, args: ["date"], ret: "number", impl: ([d], p) => new Date(date(d, p, "minute").start).getUTCMinutes(), doc: "minute(date)" },
  week: {
    min: 1,
    max: 1,
    args: ["date"],
    ret: "number",
    impl: ([d], p) => {
      const x = new Date(date(d, p, "week").start);
      const t = new Date(Date.UTC(x.getUTCFullYear(), x.getUTCMonth(), x.getUTCDate()));
      const dayNum = t.getUTCDay() || 7;
      t.setUTCDate(t.getUTCDate() + 4 - dayNum);
      const yearStart = Date.UTC(t.getUTCFullYear(), 0, 1);
      return Math.ceil(((t.getTime() - yearStart) / 86_400_000 + 1) / 7);
    },
    doc: "week(date) — ISO week number",
  },

  // ---- lists
  at: {
    min: 2,
    max: 2,
    args: ["list", "number"],
    ret: "any",
    impl: ([l, i], p) => {
      const xs = list(l, p, "at");
      const k = num(i, p, "at");
      return xs[k < 0 ? xs.length + k : k] ?? null;
    },
    doc: "at(list, index) — 0-based, negative from end",
  },
  first: { min: 1, max: 1, args: ["list"], ret: "any", impl: ([l], p) => list(l, p, "first")[0] ?? null, doc: "first(list)" },
  last: {
    min: 1,
    max: 1,
    args: ["list"],
    ret: "any",
    impl: ([l], p) => {
      const xs = list(l, p, "last");
      return xs[xs.length - 1] ?? null;
    },
    doc: "last(list)",
  },
  slice: {
    min: 2,
    max: 3,
    args: ["any", "number", "number"],
    ret: (ts) => (ts[0] === "list" ? "list" : "text"),
    impl: ([l, s, e], p) => {
      const a = num(s, p, "slice");
      const b = e == null ? undefined : num(e, p, "slice");
      return Array.isArray(l) ? l.slice(a, b) : txt(l).slice(a, b);
    },
    doc: "slice(list or text, start, end?)",
  },
  sort: {
    min: 1,
    max: 1,
    args: ["list"],
    ret: "list",
    impl: ([l], p) =>
      [...list(l, p, "sort")].sort((a, b) => {
        try {
          return compareValues(a, b, p);
        } catch {
          return toText(a).localeCompare(toText(b));
        }
      }),
    doc: "sort(list) — ascending",
  },
  reverse: { min: 1, max: 1, args: ["list"], ret: "list", impl: ([l], p) => [...list(l, p, "reverse")].reverse(), doc: "reverse(list)" },
  unique: {
    min: 1,
    max: 1,
    args: ["list"],
    ret: "list",
    impl: ([l], p) => {
      const out: FValue[] = [];
      for (const x of list(l, p, "unique")) if (!out.some((y) => equalValues(x, y))) out.push(x);
      return out;
    },
    doc: "unique(list)",
  },
  includes: {
    min: 2,
    max: 2,
    args: ["list", "any"],
    ret: "boolean",
    impl: ([l, v], p) => list(l, p, "includes").some((x) => equalValues(x, v)),
    doc: "includes(list, value)",
  },
  flat: { min: 1, max: 1, args: ["list"], ret: "list", impl: ([l], p) => list(l, p, "flat").flat() as FValue[], doc: "flat(list)" },
  count: { min: 1, max: 1, args: ["list"], ret: "number", impl: ([l], p) => list(l, p, "count").filter((x) => !isEmpty(x)).length, doc: "count(list) — non-empty items" },
};
FUNCTIONS.average = { ...FUNCTIONS.mean, doc: "average(a, b, …)" };
FUNCTIONS.isEmpty = FUNCTIONS.empty;
FUNCTIONS.toText = FUNCTIONS.format;

// Special forms: arguments are evaluated lazily or bind variables.
const SPECIAL_FORMS: Record<string, { doc: string; min: number; max: number }> = {
  if: { doc: "if(condition, then, else)", min: 3, max: 3 },
  ifs: { doc: "ifs(cond1, value1, cond2, value2, …, else)", min: 3, max: Infinity },
  and: { doc: "and(a, b, …)", min: 1, max: Infinity },
  or: { doc: "or(a, b, …)", min: 1, max: Infinity },
  let: { doc: "let(name, value, expression)", min: 3, max: 3 },
  map: { doc: "map(list, expression using current and index)", min: 2, max: 2 },
  filter: { doc: "filter(list, condition using current)", min: 2, max: 2 },
  find: { doc: "find(list, condition using current)", min: 2, max: 2 },
  findIndex: { doc: "findIndex(list, condition using current)", min: 2, max: 2 },
  some: { doc: "some(list, condition using current)", min: 2, max: 2 },
  every: { doc: "every(list, condition using current)", min: 2, max: 2 },
  id: { doc: "id() — this record's ID", min: 0, max: 0 },
};

export const FUNCTION_DOCS: { name: string; doc: string }[] = [
  ...Object.entries(SPECIAL_FORMS).map(([name, f]) => ({ name, doc: f.doc })),
  ...Object.entries(FUNCTIONS).map(([name, f]) => ({ name, doc: f.doc })),
].sort((a, b) => a.name.localeCompare(b.name));

function truthy(v: FValue): boolean {
  if (typeof v === "boolean") return v;
  if (typeof v === "number") return v !== 0 && !Number.isNaN(v);
  return !isEmpty(v);
}

// ------------------------------------------------------------------ type checking

const compatible = (actual: FType, expected: FType) =>
  expected === "any" || actual === "any" || actual === "empty" || actual === expected;

export function compile(src: string, env: CompileEnv): Compiled {
  const ast = parse(src);
  const refs = new Set<string>();
  const check = (n: Node, scope: Record<string, FType>): FType => {
    switch (n.k) {
      case "num":
        return "number";
      case "str":
        return "text";
      case "bool":
        return "boolean";
      case "list":
        n.items.forEach((i) => check(i, scope));
        return "list";
      case "prop": {
        const name = resolvePropName(n.name, env.props);
        if (name == null) throw new FormulaError(`Unknown property "${n.name}"`, n.pos);
        refs.add(name);
        return env.props[name];
      }
      case "var":
        if (Object.hasOwn(scope, n.name)) return scope[n.name];
        if (n.name === "current" || n.name === "index")
          throw new FormulaError(`"${n.name}" can only be used inside map, filter, find, some or every`, n.pos);
        throw new FormulaError(`Unknown name "${n.name}". Use prop("Name") to reference a property.`, n.pos);
      case "unary": {
        const t = check(n.arg, scope);
        if (n.op === "-" && !compatible(t, "number")) throw new FormulaError(`Cannot negate ${t}`, n.pos);
        return n.op === "-" ? "number" : "boolean";
      }
      case "cond": {
        check(n.test, scope);
        const a = check(n.then, scope),
          b = check(n.else, scope);
        return unify(a, b);
      }
      case "bin": {
        const l = check(n.left, scope),
          r = check(n.right, scope);
        switch (n.op) {
          case "+":
            if (l === "text" || r === "text") return "text";
            if (l === "list" && r === "list") return "list";
            if (compatible(l, "number") && compatible(r, "number")) return l === "any" || r === "any" ? "any" : "number";
            throw new FormulaError(`Cannot add ${l} and ${r}`, n.pos);
          case "-":
          case "*":
          case "/":
          case "%":
          case "^":
            if (!compatible(l, "number") || !compatible(r, "number"))
              throw new FormulaError(`Operator "${n.op}" needs numbers, got ${l} and ${r}`, n.pos);
            return "number";
          case "==":
          case "!=":
            return "boolean";
          case "<":
          case ">":
          case "<=":
          case ">=":
            if (l !== "any" && r !== "any" && l !== "empty" && r !== "empty" && l !== r)
              throw new FormulaError(`Cannot compare ${l} with ${r}`, n.pos);
            return "boolean";
          case "and":
          case "or":
            return "boolean";
        }
        throw new FormulaError(`Unknown operator ${n.op}`, n.pos);
      }
      case "call": {
        const special = own(SPECIAL_FORMS, n.name);
        const fn = own(FUNCTIONS, n.name);
        const spec = special ?? fn;
        if (!spec) throw new FormulaError(`Unknown function "${n.name}"`, n.pos);
        if (n.args.length < spec.min || n.args.length > spec.max) {
          const range = spec.min === spec.max ? `${spec.min}` : spec.max === Infinity ? `at least ${spec.min}` : `${spec.min}–${spec.max}`;
          throw new FormulaError(`${n.name}() takes ${range} argument${spec.min === 1 && spec.max === 1 ? "" : "s"}, got ${n.args.length}`, n.pos);
        }
        if (special) {
          switch (n.name) {
            case "if":
              check(n.args[0], scope);
              return unify(check(n.args[1], scope), check(n.args[2], scope));
            case "ifs": {
              let t: FType | null = null;
              for (let i = 0; i < n.args.length; i++) {
                const isCond = i % 2 === 0 && i !== n.args.length - 1;
                const at = check(n.args[i], scope);
                if (!isCond) t = t == null ? at : unify(t, at);
              }
              return t ?? "any";
            }
            case "and":
            case "or":
              n.args.forEach((a) => check(a, scope));
              return "boolean";
            case "let": {
              const nameNode = n.args[0];
              if (nameNode.k !== "var") throw new FormulaError("let() expects a variable name as its first argument", nameNode.pos);
              const vt = check(n.args[1], scope);
              return check(n.args[2], { ...scope, [nameNode.name]: vt });
            }
            case "id":
              return "text";
            default: {
              const lt = check(n.args[0], scope);
              if (!compatible(lt, "list")) throw new FormulaError(`${n.name}() expects a list but got ${lt}`, n.args[0].pos);
              const bt = check(n.args[1], { ...scope, current: "any", index: "number" });
              if (n.name === "map" || n.name === "filter") return "list";
              if (n.name === "findIndex") return "number";
              if (n.name === "find") return "any";
              void bt;
              return "boolean";
            }
          }
        }
        const argTypes = n.args.map((a) => check(a, scope));
        const f = fn!;
        if (f.args) {
          argTypes.forEach((t, i) => {
            const exp = f.args![Math.min(i, f.args!.length - 1)];
            if (!compatible(t, exp)) throw new FormulaError(`${n.name}() argument ${i + 1} should be ${exp}, got ${t}`, n.args[i].pos);
          });
        }
        return typeof f.ret === "function" ? f.ret(argTypes) : f.ret;
      }
    }
  };
  const type = check(ast, {});
  return { ast, type, refs: [...refs] };
}

function unify(a: FType, b: FType): FType {
  if (a === b) return a;
  if (a === "empty") return b;
  if (b === "empty") return a;
  return "any";
}

export function resolvePropName(name: string, props: Record<string, unknown>): string | null {
  if (Object.hasOwn(props, name)) return name;
  const lower = name.toLowerCase();
  return Object.keys(props).find((k) => k.toLowerCase() === lower) ?? null;
}

// ------------------------------------------------------------------ evaluation

export interface EvalCtx {
  now: number;
  recordId: string;
  getProp: (name: string) => FValue;
  steps: number;
}

export function evaluate(compiled: Compiled, ctx: Omit<EvalCtx, "steps">): FValue {
  const c: EvalCtx = { ...ctx, steps: 0 };
  const result = evalNode(compiled.ast, c, {});
  return typeof result === "number" && !Number.isFinite(result) && !Number.isNaN(result) ? result : result;
}

function evalNode(n: Node, ctx: EvalCtx, scope: Record<string, FValue>): FValue {
  if (++ctx.steps > MAX_STEPS) throw new FormulaError("Formula is too expensive to evaluate (step limit reached)", n.pos);
  switch (n.k) {
    case "num":
      return n.v;
    case "str":
      return n.v;
    case "bool":
      return n.v;
    case "list":
      return n.items.map((i) => evalNode(i, ctx, scope));
    case "prop":
      return ctx.getProp(n.name);
    case "var":
      if (Object.hasOwn(scope, n.name)) return scope[n.name];
      throw new FormulaError(`Unknown name "${n.name}"`, n.pos);
    case "unary": {
      const v = evalNode(n.arg, ctx, scope);
      if (n.op === "not") return !truthy(v);
      return -num(v, n.pos, "negation");
    }
    case "cond":
      return truthy(evalNode(n.test, ctx, scope)) ? evalNode(n.then, ctx, scope) : evalNode(n.else, ctx, scope);
    case "bin": {
      if (n.op === "and") return truthy(evalNode(n.left, ctx, scope)) && truthy(evalNode(n.right, ctx, scope));
      if (n.op === "or") return truthy(evalNode(n.left, ctx, scope)) || truthy(evalNode(n.right, ctx, scope));
      const l = evalNode(n.left, ctx, scope);
      const r = evalNode(n.right, ctx, scope);
      switch (n.op) {
        case "+":
          if (typeof l === "string" || typeof r === "string") return cap(toText(l) + toText(r), n.pos);
          if (Array.isArray(l) && Array.isArray(r)) return [...l, ...r];
          if (l === null && r === null) return null;
          return num(l, n.pos, "+") + num(r, n.pos, "+");
        case "-":
          if (l === null && r === null) return null;
          return num(l, n.pos, "-") - num(r, n.pos, "-");
        case "*":
          if (l === null && r === null) return null;
          return num(l, n.pos, "*") * num(r, n.pos, "*");
        case "/": {
          if (l === null && r === null) return null;
          const d = num(r, n.pos, "/");
          if (d === 0) throw new FormulaError("Division by zero", n.pos);
          return num(l, n.pos, "/") / d;
        }
        case "%":
          return num(l, n.pos, "%") % num(r, n.pos, "%");
        case "^":
          return Math.pow(num(l, n.pos, "^"), num(r, n.pos, "^"));
        case "==":
          return equalValues(l, r);
        case "!=":
          return !equalValues(l, r);
        case "<":
          return l !== null && r !== null && compareValues(l, r, n.pos) < 0;
        case ">":
          return l !== null && r !== null && compareValues(l, r, n.pos) > 0;
        case "<=":
          return l !== null && r !== null && compareValues(l, r, n.pos) <= 0;
        case ">=":
          return l !== null && r !== null && compareValues(l, r, n.pos) >= 0;
      }
      throw new FormulaError(`Unknown operator ${n.op}`, n.pos);
    }
    case "call": {
      switch (n.name) {
        case "if":
          return truthy(evalNode(n.args[0], ctx, scope)) ? evalNode(n.args[1], ctx, scope) : evalNode(n.args[2], ctx, scope);
        case "ifs": {
          const a = n.args;
          for (let i = 0; i + 1 < a.length; i += 2) if (truthy(evalNode(a[i], ctx, scope))) return evalNode(a[i + 1], ctx, scope);
          return a.length % 2 === 1 ? evalNode(a[a.length - 1], ctx, scope) : null;
        }
        case "and":
          return n.args.every((a) => truthy(evalNode(a, ctx, scope)));
        case "or":
          return n.args.some((a) => truthy(evalNode(a, ctx, scope)));
        case "let": {
          const nameNode = n.args[0] as Extract<Node, { k: "var" }>;
          const v = evalNode(n.args[1], ctx, scope);
          return evalNode(n.args[2], ctx, { ...scope, [nameNode.name]: v });
        }
        case "id":
          return ctx.recordId;
        case "map":
        case "filter":
        case "find":
        case "findIndex":
        case "some":
        case "every": {
          const xs = list(evalNode(n.args[0], ctx, scope), n.pos, n.name);
          const body = n.args[1];
          const run = (x: FValue, i: number) => evalNode(body, ctx, { ...scope, current: x, index: i });
          switch (n.name) {
            case "map":
              return xs.map(run);
            case "filter":
              return xs.filter((x, i) => truthy(run(x, i)));
            case "find":
              return xs.find((x, i) => truthy(run(x, i))) ?? null;
            case "findIndex":
              return xs.findIndex((x, i) => truthy(run(x, i)));
            case "some":
              return xs.some((x, i) => truthy(run(x, i)));
            default:
              return xs.every((x, i) => truthy(run(x, i)));
          }
        }
      }
      const fn = own(FUNCTIONS, n.name);
      if (!fn) throw new FormulaError(`Unknown function "${n.name}"`, n.pos);
      const args = n.args.map((a) => evalNode(a, ctx, scope));
      const out = fn.impl(args, n.pos, ctx);
      return typeof out === "number" && Number.isNaN(out) ? null : out;
    }
  }
}

/** Convenience: compile + evaluate in one go (used by tests and previews). */
export function run(src: string, props: Record<string, { type: FType; value: FValue }> = {}, now = Date.now()): FValue {
  const types = Object.fromEntries(Object.entries(props).map(([k, v]) => [k, v.type]));
  const compiled = compile(src, { props: types });
  return evaluate(compiled, {
    now,
    recordId: "record",
    getProp: (name) => {
      const key = resolvePropName(name, props);
      return key ? props[key].value : null;
    },
  });
}

export { FormulaError };
