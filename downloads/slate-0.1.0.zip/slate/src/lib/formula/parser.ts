// Formula tokenizer and Pratt parser. Produces an AST; never evaluates code.

export class FormulaError extends Error {
  constructor(
    message: string,
    public pos: number = -1,
  ) {
    super(message);
    this.name = "FormulaError";
  }
}

export type Token =
  | { t: "num"; v: number; pos: number }
  | { t: "str"; v: string; pos: number }
  | { t: "ident"; v: string; pos: number }
  | { t: "op"; v: string; pos: number }
  | { t: "eof"; pos: number };

export type Node =
  | { k: "num"; v: number; pos: number }
  | { k: "str"; v: string; pos: number }
  | { k: "bool"; v: boolean; pos: number }
  | { k: "list"; items: Node[]; pos: number }
  | { k: "prop"; name: string; pos: number }
  | { k: "var"; name: string; pos: number }
  | { k: "call"; name: string; args: Node[]; pos: number }
  | { k: "unary"; op: "-" | "not"; arg: Node; pos: number }
  | { k: "bin"; op: string; left: Node; right: Node; pos: number }
  | { k: "cond"; test: Node; then: Node; else: Node; pos: number };

export const MAX_FORMULA_LENGTH = 20_000;
const MAX_DEPTH = 200;

const OPERATORS = ["==", "!=", "<=", ">=", "&&", "||", "+", "-", "*", "/", "%", "^", "<", ">", "!", "(", ")", "[", "]", ",", ".", "?", ":", "="];

export function tokenize(src: string): Token[] {
  if (src.length > MAX_FORMULA_LENGTH) throw new FormulaError(`Formula is longer than ${MAX_FORMULA_LENGTH} characters`, 0);
  const out: Token[] = [];
  let i = 0;
  while (i < src.length) {
    const c = src[i];
    if (c === " " || c === "\t" || c === "\n" || c === "\r") {
      i++;
      continue;
    }
    // Comments: /* ... */ and // ...
    if (c === "/" && src[i + 1] === "*") {
      const end = src.indexOf("*/", i + 2);
      if (end < 0) throw new FormulaError("Unterminated comment", i);
      i = end + 2;
      continue;
    }
    if (c === "/" && src[i + 1] === "/") {
      while (i < src.length && src[i] !== "\n") i++;
      continue;
    }
    if (/[0-9]/.test(c) || (c === "." && /[0-9]/.test(src[i + 1] ?? ""))) {
      const start = i;
      while (i < src.length && /[0-9_]/.test(src[i])) i++;
      if (src[i] === "." && /[0-9]/.test(src[i + 1] ?? "")) {
        i++;
        while (i < src.length && /[0-9_]/.test(src[i])) i++;
      }
      if ((src[i] === "e" || src[i] === "E") && /[-+0-9]/.test(src[i + 1] ?? "")) {
        i++;
        if (src[i] === "-" || src[i] === "+") i++;
        while (i < src.length && /[0-9]/.test(src[i])) i++;
      }
      out.push({ t: "num", v: Number(src.slice(start, i).replace(/_/g, "")), pos: start });
      continue;
    }
    if (c === '"' || c === "'") {
      const start = i;
      const quote = c;
      i++;
      let s = "";
      while (i < src.length && src[i] !== quote) {
        if (src[i] === "\\") {
          const n = src[i + 1];
          s += n === "n" ? "\n" : n === "t" ? "\t" : (n ?? "");
          i += 2;
        } else {
          s += src[i++];
        }
      }
      if (i >= src.length) throw new FormulaError("Unterminated text literal", start);
      i++;
      out.push({ t: "str", v: s, pos: start });
      continue;
    }
    if (/[A-Za-z_À-￿]/.test(c)) {
      const start = i;
      while (i < src.length && /[A-Za-z0-9_À-￿]/.test(src[i])) i++;
      out.push({ t: "ident", v: src.slice(start, i), pos: start });
      continue;
    }
    const op = OPERATORS.find((o) => src.startsWith(o, i));
    if (op) {
      out.push({ t: "op", v: op, pos: i });
      i += op.length;
      continue;
    }
    throw new FormulaError(`Unexpected character "${c}"`, i);
  }
  out.push({ t: "eof", pos: src.length });
  return out;
}

const BINARY_PRECEDENCE: Record<string, number> = {
  or: 1,
  "||": 1,
  and: 2,
  "&&": 2,
  "==": 3,
  "!=": 3,
  "=": 3,
  "<": 4,
  ">": 4,
  "<=": 4,
  ">=": 4,
  "+": 5,
  "-": 5,
  "*": 6,
  "/": 6,
  "%": 6,
  "^": 8,
};

class Parser {
  i = 0;
  depth = 0;
  constructor(private toks: Token[]) {}

  peek() {
    return this.toks[this.i];
  }
  next() {
    return this.toks[this.i++];
  }
  isOp(v: string) {
    const t = this.peek();
    return t.t === "op" && t.v === v;
  }
  expectOp(v: string) {
    const t = this.next();
    if (t.t !== "op" || t.v !== v) throw new FormulaError(`Expected "${v}"`, t.pos);
  }

  parseExpression(minPrec = 0): Node {
    if (++this.depth > MAX_DEPTH) throw new FormulaError("Formula is nested too deeply", this.peek().pos);
    let left = this.parseUnary();
    for (;;) {
      const t = this.peek();
      let op: string | null = null;
      if (t.t === "op" && Object.hasOwn(BINARY_PRECEDENCE, t.v)) op = t.v;
      else if (t.t === "ident" && (t.v === "and" || t.v === "or")) op = t.v;
      if (op) {
        const prec = BINARY_PRECEDENCE[op];
        if (prec < minPrec) break;
        this.next();
        // ^ is right associative
        const right = this.parseExpression(op === "^" ? prec : prec + 1);
        const norm = op === "&&" ? "and" : op === "||" ? "or" : op === "=" ? "==" : op;
        left = { k: "bin", op: norm, left, right, pos: t.pos };
        continue;
      }
      if (t.t === "op" && t.v === "?" && minPrec === 0) {
        this.next();
        const thenN = this.parseExpression(0);
        this.expectOp(":");
        const elseN = this.parseExpression(0);
        left = { k: "cond", test: left, then: thenN, else: elseN, pos: t.pos };
        continue;
      }
      break;
    }
    this.depth--;
    return left;
  }

  parseUnary(): Node {
    const t = this.peek();
    if (t.t === "op" && t.v === "-") {
      this.next();
      return { k: "unary", op: "-", arg: this.parseExpression(7), pos: t.pos };
    }
    if (t.t === "op" && t.v === "+") {
      this.next();
      return this.parseExpression(7);
    }
    if ((t.t === "op" && t.v === "!") || (t.t === "ident" && t.v === "not")) {
      this.next();
      return { k: "unary", op: "not", arg: this.parseExpression(3), pos: t.pos };
    }
    return this.parsePostfix(this.parsePrimary());
  }

  parsePostfix(node: Node): Node {
    // Method-call sugar: x.f(a) → f(x, a)
    while (this.isOp(".")) {
      this.next();
      const name = this.next();
      if (name.t !== "ident") throw new FormulaError("Expected a function name after '.'", name.pos);
      const args = this.isOp("(") ? this.parseArgs() : [];
      node = { k: "call", name: name.v, args: [node, ...args], pos: name.pos };
    }
    return node;
  }

  parseArgs(): Node[] {
    this.expectOp("(");
    const args: Node[] = [];
    if (!this.isOp(")")) {
      for (;;) {
        args.push(this.parseExpression(0));
        if (this.isOp(",")) {
          this.next();
          continue;
        }
        break;
      }
    }
    this.expectOp(")");
    return args;
  }

  parsePrimary(): Node {
    const t = this.next();
    switch (t.t) {
      case "num":
        return { k: "num", v: t.v, pos: t.pos };
      case "str":
        return { k: "str", v: t.v, pos: t.pos };
      case "ident": {
        if (t.v === "true" || t.v === "false") return { k: "bool", v: t.v === "true", pos: t.pos };
        if (this.isOp("(")) {
          if (t.v === "prop") {
            this.next();
            const name = this.next();
            if (name.t !== "str") throw new FormulaError('prop() expects a property name in quotes, e.g. prop("Status")', name.pos);
            this.expectOp(")");
            return { k: "prop", name: name.v, pos: t.pos };
          }
          return { k: "call", name: t.v, args: this.parseArgs(), pos: t.pos };
        }
        return { k: "var", name: t.v, pos: t.pos };
      }
      case "op":
        if (t.v === "(") {
          const e = this.parseExpression(0);
          this.expectOp(")");
          return e;
        }
        if (t.v === "[") {
          const items: Node[] = [];
          if (!this.isOp("]")) {
            for (;;) {
              items.push(this.parseExpression(0));
              if (this.isOp(",")) {
                this.next();
                continue;
              }
              break;
            }
          }
          this.expectOp("]");
          return { k: "list", items, pos: t.pos };
        }
        throw new FormulaError(`Unexpected "${t.v}"`, t.pos);
      case "eof":
        throw new FormulaError("Unexpected end of formula", t.pos);
    }
  }
}

export function parse(src: string): Node {
  const toks = tokenize(src);
  if (toks.length === 1) throw new FormulaError("Formula is empty", 0);
  const p = new Parser(toks);
  const node = p.parseExpression(0);
  const rest = p.peek();
  if (rest.t !== "eof") throw new FormulaError("Unexpected input after the end of the expression", rest.pos);
  return node;
}

/** Names of properties referenced via prop("..."). */
export function collectPropRefs(node: Node, out = new Set<string>()): Set<string> {
  switch (node.k) {
    case "prop":
      out.add(node.name);
      break;
    case "list":
      node.items.forEach((n) => collectPropRefs(n, out));
      break;
    case "call":
      node.args.forEach((n) => collectPropRefs(n, out));
      break;
    case "unary":
      collectPropRefs(node.arg, out);
      break;
    case "bin":
      collectPropRefs(node.left, out);
      collectPropRefs(node.right, out);
      break;
    case "cond":
      collectPropRefs(node.test, out);
      collectPropRefs(node.then, out);
      collectPropRefs(node.else, out);
      break;
  }
  return out;
}

/** Rename prop("old") references in source text, preserving everything else. */
export function renamePropInSource(src: string, oldName: string, newName: string): string {
  let toks: Token[];
  try {
    toks = tokenize(src);
  } catch {
    return src;
  }
  let out = "";
  let last = 0;
  for (let i = 0; i < toks.length - 3; i++) {
    const a = toks[i],
      b = toks[i + 1],
      c = toks[i + 2];
    if (a.t === "ident" && a.v === "prop" && b.t === "op" && b.v === "(" && c.t === "str" && c.v === oldName) {
      const quoteEnd = findStringEnd(src, c.pos);
      out += src.slice(last, c.pos) + JSON.stringify(newName);
      last = quoteEnd;
    }
  }
  return out + src.slice(last);
}

function findStringEnd(src: string, start: number): number {
  const q = src[start];
  let i = start + 1;
  while (i < src.length && src[i] !== q) i += src[i] === "\\" ? 2 : 1;
  return i + 1;
}
