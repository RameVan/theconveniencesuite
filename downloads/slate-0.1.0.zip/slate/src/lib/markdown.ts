// Converters between Slate block JSON and Markdown / HTML.
// Each export records what the target format cannot represent in a loss report.
import { marked, type Token, type Tokens } from "marked";
import type { PMMark, PMNode } from "./blocks";
import { safeUrl } from "./blocks";
import { uid } from "./uid";

export interface ConvertContext {
  /** Title + relative link for a referenced page (child pages, links, databases). */
  pageRef?: (id: string) => { title: string; href: string } | null;
  loss?: Map<string, number>;
}

const note = (ctx: ConvertContext, what: string) => ctx.loss?.set(what, (ctx.loss.get(what) ?? 0) + 1);

// ------------------------------------------------------------------ Markdown export

function escapeMd(s: string) {
  return s.replace(/([\\`*_[\]#<>|~])/g, "\\$1");
}

export function inlineToMarkdown(nodes: PMNode[] = [], ctx: ConvertContext = {}): string {
  let out = "";
  for (const n of nodes) {
    if (n.type === "hardBreak") {
      out += "  \n";
      continue;
    }
    if (n.type === "inlineMath") {
      out += `$${n.attrs?.latex ?? ""}$`;
      continue;
    }
    if (n.type === "pageLink") {
      const ref = ctx.pageRef?.(String(n.attrs?.pageId ?? ""));
      out += ref ? `[${escapeMd(ref.title || "Untitled")}](${ref.href})` : String(n.attrs?.title ?? "Untitled page");
      continue;
    }
    if (n.type === "mention") {
      out += `@${escapeMd(String(n.attrs?.label ?? "someone"))}`;
      continue;
    }
    if (n.type !== "text") continue;
    const marks = n.marks ?? [];
    let t = marks.some((m) => m.type === "code") ? `\`${n.text}\`` : escapeMd(n.text ?? "");
    for (const m of marks) {
      switch (m.type) {
        case "bold":
          t = `**${t}**`;
          break;
        case "italic":
          t = `*${t}*`;
          break;
        case "strike":
          t = `~~${t}~~`;
          break;
        case "underline":
          t = `<u>${t}</u>`;
          break;
        case "textStyle":
          if (m.attrs?.color) note(ctx, "Text colors");
          break;
        case "highlight":
          note(ctx, "Highlights");
          break;
      }
    }
    const link = marks.find((m) => m.type === "link");
    if (link) t = `[${t}](${link.attrs?.href ?? ""})`;
    out += t;
  }
  return out;
}

function indent(s: string, prefix: string) {
  return s
    .split("\n")
    .map((l, i) => (i === 0 ? l : l ? prefix + l : l))
    .join("\n");
}

function listItemToMd(item: PMNode, marker: string, ctx: ConvertContext): string {
  const [first, ...rest] = item.content ?? [];
  const head = first?.type === "paragraph" ? inlineToMarkdown(first.content, ctx) : first ? blockToMarkdown(first, ctx) : "";
  const pad = " ".repeat(marker.length);
  const tail = rest.map((c) => pad + indent(blockToMarkdown(c, ctx), pad)).join("\n");
  return `${marker}${head}${tail ? "\n" + tail : ""}`;
}

export function blockToMarkdown(n: PMNode, ctx: ConvertContext = {}): string {
  const a = n.attrs ?? {};
  switch (n.type) {
    case "paragraph":
      return inlineToMarkdown(n.content, ctx);
    case "heading":
      return `${"#".repeat(Math.min(6, Number(a.level) || 1))} ${inlineToMarkdown(n.content, ctx)}`;
    case "bulletList":
      return (n.content ?? []).map((li) => listItemToMd(li, "- ", ctx)).join("\n");
    case "orderedList": {
      const start = Number(a.start) || 1;
      return (n.content ?? []).map((li, i) => listItemToMd(li, `${start + i}. `, ctx)).join("\n");
    }
    case "taskList":
      return (n.content ?? []).map((li) => listItemToMd(li, li.attrs?.checked ? "- [x] " : "- [ ] ", ctx)).join("\n");
    case "blockquote":
      return (n.content ?? []).map((c) => blockToMarkdown(c, ctx).split("\n").map((l) => `> ${l}`).join("\n")).join("\n>\n");
    case "codeBlock": {
      const code = (n.content ?? []).map((t) => t.text ?? "").join("");
      const fence = code.includes("```") ? "````" : "```";
      return `${fence}${a.language && a.language !== "plaintext" ? a.language : ""}\n${code}\n${fence}`;
    }
    case "horizontalRule":
      return "---";
    case "table": {
      const rows = (n.content ?? []).map((r) => (r.content ?? []).map((c) => (c.content ?? []).map((p) => inlineToMarkdown(p.content, ctx)).join(" ").replace(/\|/g, "\\|").replace(/\n/g, " ")));
      if (!rows.length) return "";
      const width = Math.max(...rows.map((r) => r.length));
      const norm = rows.map((r) => [...r, ...Array(width - r.length).fill("")]);
      const line = (r: string[]) => `| ${r.join(" | ")} |`;
      return [line(norm[0]), line(Array(width).fill("---")), ...norm.slice(1).map(line)].join("\n");
    }
    case "image":
      return `![${escapeMd(String(a.alt ?? a.caption ?? ""))}](${a.src ?? ""})${a.caption ? `\n*${escapeMd(String(a.caption))}*` : ""}`;
    case "video":
    case "audio":
    case "fileBlock":
      note(ctx, "Embedded media and files (exported as links)");
      return `[${escapeMd(String(a.name ?? a.caption ?? a.src ?? "file"))}](${a.src ?? ""})`;
    case "bookmark":
      return `[${escapeMd(String(a.title || a.url || "Bookmark"))}](${a.url ?? ""})`;
    case "embed":
      note(ctx, "Embeds (exported as links)");
      return `[${escapeMd(String(a.url ?? "Embed"))}](${a.url ?? ""})`;
    case "callout": {
      note(ctx, "Callout colors");
      const body = (n.content ?? []).map((c) => blockToMarkdown(c, ctx)).join("\n\n");
      return body
        .split("\n")
        .map((l, i) => (i === 0 ? `> ${a.icon ? a.icon + " " : ""}${l}` : `> ${l}`))
        .join("\n");
    }
    case "toggle": {
      const [summary, ...rest] = n.content ?? [];
      const body = rest.map((c) => blockToMarkdown(c, ctx)).join("\n\n");
      return `<details>\n<summary>${inlineToMarkdown(summary?.content, ctx)}</summary>\n\n${body}\n\n</details>`;
    }
    case "equation":
      return `$$\n${a.latex ?? ""}\n$$`;
    case "toc":
      note(ctx, "Table of contents blocks");
      return "";
    case "breadcrumb":
      note(ctx, "Breadcrumb blocks");
      return "";
    case "childPage": {
      const ref = ctx.pageRef?.(String(a.pageId ?? ""));
      return ref ? `[${escapeMd(ref.title || "Untitled")}](${ref.href})` : "";
    }
    case "databaseView": {
      note(ctx, "Inline database views (exported as links to CSV)");
      const ref = ctx.pageRef?.(String(a.databaseId ?? ""));
      return ref ? `[${escapeMd(ref.title || "Untitled database")}](${ref.href})` : "";
    }
    default:
      return inlineToMarkdown(n.content, ctx);
  }
}

export function blocksToMarkdown(blocks: PMNode[], ctx: ConvertContext = {}): string {
  return blocks
    .map((b) => blockToMarkdown(b, ctx))
    .filter((s, i, arr) => s !== "" || (i > 0 && arr[i - 1] !== ""))
    .join("\n\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

// ------------------------------------------------------------------ Markdown import

const genId = () => uid();

function inlineFromTokens(tokens: Token[] = [], marks: PMMark[] = []): PMNode[] {
  const out: PMNode[] = [];
  const push = (text: string, m: PMMark[]) => {
    if (!text) return;
    const last = out[out.length - 1];
    if (last?.type === "text" && JSON.stringify(last.marks ?? []) === JSON.stringify(m)) last.text += text;
    else out.push(m.length ? { type: "text", text, marks: m } : { type: "text", text });
  };
  for (const t of tokens) {
    switch (t.type) {
      case "text": {
        const tt = t as Tokens.Text;
        if (tt.tokens?.length) out.push(...inlineFromTokens(tt.tokens, marks));
        else pushWithMath(tt.text, marks, out, push);
        break;
      }
      case "escape":
        push((t as Tokens.Escape).text, marks);
        break;
      case "strong":
        out.push(...inlineFromTokens((t as Tokens.Strong).tokens, [...marks, { type: "bold" }]));
        break;
      case "em":
        out.push(...inlineFromTokens((t as Tokens.Em).tokens, [...marks, { type: "italic" }]));
        break;
      case "del":
        out.push(...inlineFromTokens((t as Tokens.Del).tokens, [...marks, { type: "strike" }]));
        break;
      case "codespan":
        push(decodeEntities((t as Tokens.Codespan).text), [...marks, { type: "code" }]);
        break;
      case "link": {
        const l = t as Tokens.Link;
        const href = refUrl(l.href);
        out.push(...inlineFromTokens(l.tokens, href ? [...marks, { type: "link", attrs: { href } }] : marks));
        break;
      }
      case "image": {
        const im = t as Tokens.Image;
        const href = refUrl(im.href);
        push(im.text || "image", href ? [...marks, { type: "link", attrs: { href } }] : marks);
        break;
      }
      case "br":
        out.push({ type: "hardBreak" });
        break;
      case "html": {
        const raw = (t as Tokens.HTML).raw;
        if (/^<u>$/i.test(raw)) marks = [...marks, { type: "underline" }];
        else if (/^<\/u>$/i.test(raw)) marks = marks.filter((m) => m.type !== "underline");
        else push(raw.replace(/<[^>]+>/g, ""), marks);
        break;
      }
      default:
        if ("text" in t && typeof t.text === "string") push(decodeEntities(t.text), marks);
    }
  }
  return out;
}

function pushWithMath(text: string, marks: PMMark[], out: PMNode[], push: (t: string, m: PMMark[]) => void) {
  const re = /\$([^$\n]+)\$/g;
  let last = 0;
  for (const m of text.matchAll(re)) {
    push(decodeEntities(text.slice(last, m.index)), marks);
    out.push({ type: "inlineMath", attrs: { latex: m[1] } });
    last = m.index! + m[0].length;
  }
  push(decodeEntities(text.slice(last)), marks);
}

function decodeEntities(s: string) {
  return s.replace(/&(amp|lt|gt|quot|#39);/g, (_, e) => ({ amp: "&", lt: "<", gt: ">", quot: '"', "#39": "'" })[e as "amp"] ?? _);
}

function paragraph(content: PMNode[]): PMNode {
  return content.length ? { type: "paragraph", content } : { type: "paragraph" };
}

function blocksFromTokens(tokens: Token[]): PMNode[] {
  const out: PMNode[] = [];
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];
    switch (t.type) {
      case "space":
        break;
      case "heading": {
        const hd = t as Tokens.Heading;
        out.push({ type: "heading", attrs: { level: Math.min(3, hd.depth) }, content: inlineFromTokens(hd.tokens) });
        break;
      }
      case "paragraph": {
        const p = t as Tokens.Paragraph;
        const txt = p.text.trim();
        const eq = /^\$\$([\s\S]+)\$\$$/.exec(txt);
        if (eq) {
          out.push({ type: "equation", attrs: { latex: eq[1].trim() } });
          break;
        }
        if (p.tokens.length === 1 && p.tokens[0].type === "image") {
          const im = p.tokens[0] as Tokens.Image;
          out.push({ type: "image", attrs: { src: refUrl(im.href) ?? "", alt: im.text || null, caption: im.title || null } });
          break;
        }
        out.push(paragraph(inlineFromTokens(p.tokens)));
        break;
      }
      case "list": {
        const l = t as Tokens.List;
        const isTask = l.items.some((it) => it.task);
        const items = l.items.map((it) => {
          const inner = blocksFromTokens(it.tokens.filter((x) => x.type !== "checkbox"));
          // Tight list items come back as "text" tokens; normalise to a paragraph first.
          const content = inner.length && inner[0].type === "paragraph" ? inner : [paragraph([]), ...inner];
          return isTask ? { type: "taskItem", attrs: { checked: !!it.checked }, content } : { type: "listItem", content };
        });
        out.push(isTask ? { type: "taskList", content: items } : l.ordered ? { type: "orderedList", attrs: { start: Number(l.start) || 1 }, content: items } : { type: "bulletList", content: items });
        break;
      }
      case "text": {
        const tx = t as Tokens.Text;
        out.push(paragraph(tx.tokens ? inlineFromTokens(tx.tokens) : inlineFromTokens([{ type: "text", raw: tx.text, text: tx.text } as Token])));
        break;
      }
      case "blockquote": {
        const bq = t as Tokens.Blockquote;
        const inner = blocksFromTokens(bq.tokens);
        // "> 💡 text" becomes a callout.
        const first = inner[0];
        const firstText = first?.type === "paragraph" ? (first.content?.[0]?.text ?? "") : "";
        const emoji = /^(\p{Extended_Pictographic}️?)\s+/u.exec(firstText);
        if (emoji && first.content) {
          first.content[0] = { ...first.content[0], text: firstText.slice(emoji[0].length) };
          if (!first.content[0].text) first.content.shift();
          out.push({ type: "callout", attrs: { icon: emoji[1], color: "gray" }, content: inner });
        } else {
          out.push({ type: "blockquote", content: inner.length ? inner : [paragraph([])] });
        }
        break;
      }
      case "code": {
        const c = t as Tokens.Code;
        if (c.lang === "math" || c.lang === "latex") out.push({ type: "equation", attrs: { latex: c.text } });
        else out.push({ type: "codeBlock", attrs: { language: c.lang || "plaintext" }, content: c.text ? [{ type: "text", text: c.text }] : [] });
        break;
      }
      case "hr":
        out.push({ type: "horizontalRule" });
        break;
      case "table": {
        const tb = t as Tokens.Table;
        const row = (cells: Tokens.TableCell[], header: boolean) => ({
          type: "tableRow",
          content: cells.map((c) => ({ type: header ? "tableHeader" : "tableCell", content: [paragraph(inlineFromTokens(c.tokens))] })),
        });
        out.push({ type: "table", content: [row(tb.header, true), ...tb.rows.map((r) => row(r, false))] });
        break;
      }
      case "html": {
        const raw = (t as Tokens.HTML).raw;
        const det = /<details>\s*<summary>([\s\S]*?)<\/summary>([\s\S]*?)<\/details>/i.exec(raw);
        if (det) {
          const inner = markdownToBlocks(det[2]);
          out.push({ type: "toggle", attrs: { open: false }, content: [paragraph(inlineFromTokens(marked.Lexer.lexInline(det[1].trim()))), ...inner.map(stripId)] });
          break;
        }
        // Multi-token <details> (summary on its own line): collect until </details>.
        if (/^<details>/i.test(raw.trim())) {
          const summary = /<summary>([\s\S]*?)<\/summary>/i.exec(raw)?.[1] ?? "";
          const body: Token[] = [];
          let j = i + 1;
          while (j < tokens.length && !(tokens[j].type === "html" && /<\/details>/i.test((tokens[j] as Tokens.HTML).raw))) body.push(tokens[j++]);
          i = j;
          out.push({ type: "toggle", attrs: { open: false }, content: [paragraph([{ type: "text", text: summary.replace(/<[^>]+>/g, "") }].filter((x) => x.text)), ...blocksFromTokens(body)] });
          break;
        }
        const text = raw.replace(/<[^>]+>/g, "").trim();
        if (text) out.push(paragraph([{ type: "text", text: decodeEntities(text) }]));
        break;
      }
      default:
        if ("text" in t && typeof t.text === "string" && t.text.trim()) out.push(paragraph([{ type: "text", text: t.text }]));
    }
  }
  return out;
}

function stripId(n: PMNode): PMNode {
  if (!n.attrs?.id) return n;
  const { id: _id, ...rest } = n.attrs;
  void _id;
  return { ...n, attrs: rest };
}

/** Parse Markdown into top-level blocks (each with a fresh id). */
// While converting files from an archive, relative references ("Other page.md", "img/a.png") are
// kept as written so the importer can resolve them; otherwise links and images must be safe URLs.
let keepRelative = false;
const isRelativeRef = (href: string) => !!href && !/^[a-z][a-z0-9+.-]*:/i.test(href) && !href.startsWith("//") && !href.startsWith("/") && !href.startsWith("#");
function refUrl(href: string): string | null {
  if (keepRelative && isRelativeRef(href.trim())) return href.trim();
  return safeUrl(href);
}

/**
 * Markdown to blocks. With `relative`, relative link/image references are left for the caller to
 * resolve (see `dropRelativeRefs` for the ones it can't).
 */
export function markdownToBlocks(md: string, opts: { relative?: boolean } = {}): PMNode[] {
  const tokens = marked.lexer(md.replace(/\r\n/g, "\n"), { gfm: true });
  keepRelative = !!opts.relative;
  try {
    return blocksFromTokens(tokens).map((b) => ({ ...b, attrs: { ...(b.attrs ?? {}), id: genId() } }));
  } finally {
    keepRelative = false;
  }
}

/** Remove relative links (keeping their text) and relative image sources that were not resolved. */
export function dropRelativeRefs(list: PMNode[]) {
  const walk = (n: PMNode) => {
    if (n.marks) n.marks = n.marks.filter((m) => !(m.type === "link" && isRelativeRef(String(m.attrs?.href ?? ""))));
    if (n.marks && !n.marks.length) delete n.marks;
    if (n.type === "image" && isRelativeRef(String(n.attrs?.src ?? ""))) n.attrs = { ...n.attrs, src: "" };
    n.content?.forEach(walk);
  };
  list.forEach(walk);
}

/** Split leading "# Title" off a Markdown document. */
export function extractTitle(md: string): { title: string | null; body: string } {
  const m = /^\s*#\s+(.+?)\s*\n/.exec(md + "\n");
  if (!m) return { title: null, body: md };
  return { title: m[1].trim(), body: md.slice(m[0].length) };
}

// ------------------------------------------------------------------ HTML export

export function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
}

const COLOR_CSS: Record<string, string> = {
  gray: "#787774",
  brown: "#9f6b53",
  orange: "#d9730d",
  yellow: "#cb912f",
  green: "#448361",
  blue: "#337ea9",
  purple: "#9065b0",
  pink: "#c14c8a",
  red: "#d44c47",
};

export function inlineToHtml(nodes: PMNode[] = [], ctx: ConvertContext = {}): string {
  return nodes
    .map((n) => {
      if (n.type === "hardBreak") return "<br>";
      if (n.type === "inlineMath") return `<code class="math">${escapeHtml(String(n.attrs?.latex ?? ""))}</code>`;
      if (n.type === "pageLink") {
        const ref = ctx.pageRef?.(String(n.attrs?.pageId ?? ""));
        return ref ? `<a href="${escapeHtml(ref.href)}">${escapeHtml(ref.title || "Untitled")}</a>` : "";
      }
      if (n.type !== "text") return "";
      let t = escapeHtml(n.text ?? "");
      for (const m of n.marks ?? []) {
        switch (m.type) {
          case "bold":
            t = `<strong>${t}</strong>`;
            break;
          case "italic":
            t = `<em>${t}</em>`;
            break;
          case "underline":
            t = `<u>${t}</u>`;
            break;
          case "strike":
            t = `<s>${t}</s>`;
            break;
          case "code":
            t = `<code>${t}</code>`;
            break;
          case "highlight":
            t = `<mark>${t}</mark>`;
            break;
          case "textStyle": {
            const c = COLOR_CSS[String(m.attrs?.color ?? "")];
            if (c) t = `<span style="color:${c}">${t}</span>`;
            break;
          }
          case "link": {
            const href = safeUrl(m.attrs?.href);
            if (href) t = `<a href="${escapeHtml(href)}" rel="noopener noreferrer">${t}</a>`;
            break;
          }
        }
      }
      return t;
    })
    .join("");
}

export function blockToHtml(n: PMNode, ctx: ConvertContext = {}): string {
  const a = n.attrs ?? {};
  const kids = () => (n.content ?? []).map((c) => blockToHtml(c, ctx)).join("\n");
  const src = (v: unknown) => escapeHtml(safeUrl(v) ?? "");
  switch (n.type) {
    case "paragraph":
      return `<p>${inlineToHtml(n.content, ctx) || "<br>"}</p>`;
    case "heading": {
      const l = Math.min(6, Number(a.level) || 1);
      return `<h${l}>${inlineToHtml(n.content, ctx)}</h${l}>`;
    }
    case "bulletList":
      return `<ul>${kids()}</ul>`;
    case "orderedList":
      return `<ol start="${Number(a.start) || 1}">${kids()}</ol>`;
    case "taskList":
      return `<ul class="tasks">${kids()}</ul>`;
    case "listItem":
      return `<li>${kids()}</li>`;
    case "taskItem":
      return `<li><input type="checkbox" disabled${a.checked ? " checked" : ""}> ${kids()}</li>`;
    case "blockquote":
      return `<blockquote>${kids()}</blockquote>`;
    case "codeBlock":
      return `<pre><code class="language-${escapeHtml(String(a.language ?? ""))}">${escapeHtml((n.content ?? []).map((t) => t.text ?? "").join(""))}</code></pre>`;
    case "horizontalRule":
      return "<hr>";
    case "table":
      return `<table>${kids()}</table>`;
    case "tableRow":
      return `<tr>${kids()}</tr>`;
    case "tableHeader":
      return `<th>${kids()}</th>`;
    case "tableCell":
      return `<td>${kids()}</td>`;
    case "image":
      return `<figure><img src="${src(a.src)}" alt="${escapeHtml(String(a.alt ?? ""))}">${a.caption ? `<figcaption>${escapeHtml(String(a.caption))}</figcaption>` : ""}</figure>`;
    case "video":
      return `<video controls src="${src(a.src)}"></video>`;
    case "audio":
      return `<audio controls src="${src(a.src)}"></audio>`;
    case "fileBlock":
      return `<p class="file"><a href="${src(a.src)}">📎 ${escapeHtml(String(a.name ?? "File"))}</a></p>`;
    case "bookmark":
      return `<p class="bookmark"><a href="${src(a.url)}">${escapeHtml(String(a.title || a.url || ""))}</a>${a.description ? `<br><small>${escapeHtml(String(a.description))}</small>` : ""}</p>`;
    case "embed":
      return `<p class="embed"><a href="${src(a.url)}">${escapeHtml(String(a.url ?? ""))}</a></p>`;
    case "callout":
      return `<aside class="callout callout-${escapeHtml(String(a.color ?? "gray"))}"><span class="icon">${escapeHtml(String(a.icon ?? "💡"))}</span><div>${kids()}</div></aside>`;
    case "toggle": {
      const [summary, ...rest] = n.content ?? [];
      return `<details${a.open ? " open" : ""}><summary>${inlineToHtml(summary?.content, ctx)}</summary>${rest.map((c) => blockToHtml(c, ctx)).join("\n")}</details>`;
    }
    case "equation":
      return `<div class="equation"><code>${escapeHtml(String(a.latex ?? ""))}</code></div>`;
    case "toc":
    case "breadcrumb":
      return "";
    case "childPage": {
      const ref = ctx.pageRef?.(String(a.pageId ?? ""));
      return ref ? `<p class="page-link"><a href="${escapeHtml(ref.href)}">📄 ${escapeHtml(ref.title || "Untitled")}</a></p>` : "";
    }
    case "databaseView": {
      const ref = ctx.pageRef?.(String(a.databaseId ?? ""));
      return ref ? `<p class="page-link"><a href="${escapeHtml(ref.href)}">🗃️ ${escapeHtml(ref.title || "Untitled database")}</a></p>` : "";
    }
    default:
      return inlineToHtml(n.content, ctx);
  }
}

export function htmlDocument(title: string, bodyHtml: string, icon?: string | null): string {
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapeHtml(title || "Untitled")}</title>
<style>
body{font:16px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif;max-width:760px;margin:40px auto;padding:0 20px;color:#37352f}
h1,h2,h3{line-height:1.25}pre{background:#f7f6f3;padding:12px;border-radius:6px;overflow:auto}code{background:#f1f1ef;padding:1px 4px;border-radius:4px}
pre code{background:none;padding:0}blockquote{border-left:3px solid #37352f;margin:0;padding-left:14px}table{border-collapse:collapse}td,th{border:1px solid #e9e9e7;padding:6px 8px}
.callout{display:flex;gap:10px;background:#f7f6f3;padding:14px;border-radius:6px}ul.tasks{list-style:none;padding-left:4px}img,video{max-width:100%}
</style>
</head>
<body>
<h1>${icon ? escapeHtml(icon) + " " : ""}${escapeHtml(title || "Untitled")}</h1>
${bodyHtml}
</body>
</html>`;
}

export function blocksToHtml(blocks: PMNode[], ctx: ConvertContext = {}) {
  return blocks.map((b) => blockToHtml(b, ctx)).join("\n");
}
