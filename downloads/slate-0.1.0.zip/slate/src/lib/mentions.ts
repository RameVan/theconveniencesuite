import type { PMNode } from "./blocks";

/**
 * People mentions. In page content they are `mention` nodes ({ userId, label }); in comment
 * bodies they are written as `@[Name](user:<id>)` tokens.
 */
export const COMMENT_MENTION_RE = /@\[([^\]\n]{1,200})\]\(user:([A-Za-z0-9_-]{1,64})\)/g;

export function commentMentionIds(body: string): string[] {
  return [...new Set([...body.matchAll(COMMENT_MENTION_RE)].map((m) => m[2]))];
}

/** Comment body as plain text ("@Name" for mention tokens), for previews and notifications. */
export function commentPlainText(body: string): string {
  return body.replace(COMMENT_MENTION_RE, (_, name: string) => `@${name}`);
}

export function commentMentionToken(name: string, userId: string): string {
  return `@[${name.replace(/[\]\n]/g, " ").slice(0, 200)}](user:${userId})`;
}

/** People mentioned in page blocks, as "userId blockId" pairs. */
export function blockMentions(blocks: { id: string; content: PMNode }[]): Set<string> {
  const out = new Set<string>();
  for (const b of blocks) {
    const walk = (n: PMNode) => {
      if (n.type === "mention") {
        const id = n.attrs?.userId;
        if (typeof id === "string" && /^[A-Za-z0-9_-]{1,64}$/.test(id)) out.add(`${id} ${b.id}`);
      }
      n.content?.forEach(walk);
    };
    walk(b.content);
  }
  return out;
}

/** Mentions present in `after` but not in `before`: each user with the first block newly mentioning them. */
export function newBlockMentions(before: Set<string>, after: Set<string>): Map<string, string> {
  const out = new Map<string, string>();
  for (const pair of after) {
    if (before.has(pair)) continue;
    const [userId, blockId] = pair.split(" ");
    if (!out.has(userId)) out.set(userId, blockId);
  }
  return out;
}
