// Realtime collaboration: a Hocuspocus (Yjs) WebSocket server sharing Slate's sessions and
// permissions. The Yjs document of a page is the live state; the block table stays the source
// for search, history and export and is written from the Yjs document (debounced).
import { Server, type Hocuspocus } from "@hocuspocus/server";
import * as Y from "yjs";
import { prosemirrorJSONToYDoc, yDocToProsemirrorJSON, updateYFragment } from "@tiptap/y-tiptap";
import { eq } from "drizzle-orm";
import { getDb } from "./db";
import { pages, pageYdocs } from "./db/schema";
import { getSessionUser, type Actor } from "./services/auth";
import { requirePage, type Access } from "./services/permissions";
import { getBlocks, saveContent } from "./services/pages";
import { getEditorSchema, YDOC_FIELD } from "@/lib/editor-schema";
import { canonicalJson, validateBlocks } from "@/lib/blocks";
import type { PMNode } from "@/lib/blocks";
import { SESSION_COOKIE, rateLimit } from "./http";
import { config } from "./config";

export interface CollabContext {
  actor: Actor;
  userName: string;
  access: Access;
}

const ORIGIN_SERVER = "slate-server";

function parseCookies(header: string | null): Record<string, string> {
  const out: Record<string, string> = {};
  for (const part of (header ?? "").split(";")) {
    const i = part.indexOf("=");
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

/** WebSockets are not covered by the same-origin policy, so the Origin header is checked here. */
function originAllowed(headers: Headers): boolean {
  const origin = headers.get("origin");
  if (!origin) return false;
  let originUrl: URL;
  try {
    originUrl = new URL(origin);
  } catch {
    return false;
  }
  const extra = (process.env.COLLAB_ALLOWED_ORIGINS ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  if (extra.includes(originUrl.origin)) return true;
  const host = ((config.trustProxy && headers.get("x-forwarded-host")) || headers.get("host") || "").split(":")[0];
  // Cookies are not port-specific, so the app and the realtime port share a host name.
  return !!host && originUrl.hostname === host;
}

function docJson(blocks: PMNode[]) {
  return { type: "doc", content: blocks.length ? blocks : [{ type: "paragraph" }] };
}

/** Make the Yjs document's content equal to the given blocks with a minimal diff. */
export function replaceYContent(doc: Y.Doc, blocks: PMNode[]) {
  const schema = getEditorSchema();
  const node = schema.nodeFromJSON(docJson(blocks));
  updateYFragment(doc, doc.getXmlFragment(YDOC_FIELD), node, { mapping: new Map(), isOMark: new Map() });
}

/** Ensure every top-level block in the Yjs document has a unique id (assigned server-side if a client did not). */
function ensureBlockIds(doc: Y.Doc) {
  const fragment = doc.getXmlFragment(YDOC_FIELD);
  const seen = new Set<string>();
  const fix: Y.XmlElement[] = [];
  for (const child of fragment.toArray()) {
    if (!(child instanceof Y.XmlElement)) continue;
    const id = child.getAttribute("id");
    if (typeof id !== "string" || !id || seen.has(id)) fix.push(child);
    else seen.add(id);
  }
  if (fix.length) doc.transact(() => fix.forEach((el) => el.setAttribute("id", crypto.randomUUID())), ORIGIN_SERVER);
}

async function storeYState(pageId: string, doc: Y.Doc, contentVersion: number) {
  const db = await getDb();
  const state = Y.encodeStateAsUpdate(doc);
  await db
    .insert(pageYdocs)
    .values({ pageId, state, contentVersion, updatedAt: new Date() })
    .onConflictDoUpdate({ target: pageYdocs.pageId, set: { state, contentVersion, updatedAt: new Date() } });
}

export function createCollabServer(opts: { port: number; host?: string; quiet?: boolean; debounce?: number }) {
  return new Server<CollabContext>({
    port: opts.port,
    address: opts.host,
    quiet: opts.quiet ?? true,
    stopOnSignals: false,
    debounce: opts.debounce ?? 1500,
    maxDebounce: 10_000,
    timeout: 30_000,
    async onConnect({ requestHeaders, documentName, connectionConfig, request }) {
      if (!originAllowed(requestHeaders)) throw new Error("Origin not allowed");
      const ip = (config.trustProxy && requestHeaders.get("x-forwarded-for")?.split(",")[0].trim()) || "local";
      await rateLimit(`ws:${ip}`, Math.max(60, config.rateLimitPerMinute));
      const token = parseCookies(requestHeaders.get("cookie"))[SESSION_COOKIE];
      const db = await getDb();
      const session = token ? await getSessionUser(db, token) : null;
      if (!session) throw new Error("Not signed in");
      const actor: Actor = { userId: session.user.id, sessionId: session.sessionId, via: "session" };
      const pa = await requirePage(db, actor, documentName, "view");
      // Viewers receive live updates but their changes are rejected by the server.
      connectionConfig.readOnly = pa.access === "view";
      void request;
      return { actor, userName: session.user.name, access: pa.access };
    },
    async onLoadDocument({ document, documentName }) {
      const db = await getDb();
      const [page] = await db.select({ version: pages.version }).from(pages).where(eq(pages.id, documentName));
      if (!page) throw new Error("Page not found");
      const blocks = await getBlocks(db, documentName);
      const [stored] = await db.select().from(pageYdocs).where(eq(pageYdocs.pageId, documentName));
      if (stored) {
        // Continue the stored history so reconnecting clients merge instead of duplicating.
        Y.applyUpdate(document, stored.state);
        if (stored.contentVersion !== page.version) document.transact(() => replaceYContent(document, blocks), ORIGIN_SERVER);
      } else {
        const initial = prosemirrorJSONToYDoc(getEditorSchema(), docJson(blocks), YDOC_FIELD);
        Y.applyUpdate(document, Y.encodeStateAsUpdate(initial));
      }
      ensureBlockIds(document);
      // Persist the history before any client builds on it. A later rebuild from blocks would create
      // new Yjs items, and a client holding the old ones would merge them in as duplicates.
      if (!stored || stored.contentVersion !== page.version) await storeYState(documentName, document, page.version);
      return document;
    },
    async onStoreDocument({ document, documentName, lastContext }) {
      const db = await getDb();
      ensureBlockIds(document);
      const json = yDocToProsemirrorJSON(document, YDOC_FIELD) as { content?: PMNode[] };
      const blocks = json.content ?? [];
      const [page] = await db.select({ version: pages.version }).from(pages).where(eq(pages.id, documentName));
      if (!page) return; // deleted meanwhile
      const current = await getBlocks(db, documentName);
      if (sameContent(current, blocks)) {
        await storeYState(documentName, document, page.version);
        return;
      }
      const actor = lastContext?.actor;
      if (!actor) return;
      try {
        const saved = await saveContent(db, actor, documentName, { blocks: blocks.map((b) => ({ id: b.attrs?.id, content: b })) });
        await storeYState(documentName, document, saved.version);
      } catch (err) {
        // Not stored (e.g. the editor lost access, or invalid content); the Yjs state is not
        // marked current, so the blocks stay authoritative.
        console.error(`[collab] could not persist page ${documentName}:`, err instanceof Error ? err.message : err);
      }
    },
  });
}

/**
 * Whether the live document holds the same content as the stored blocks. Compares in the stored
 * form (validated, key order ignored), so representation details never cause a new version.
 */
function sameContent(stored: PMNode[], live: PMNode[]) {
  try {
    const normalized = validateBlocks(live.map((b) => ({ id: b.attrs?.id, content: b }))).map((b) => b.content);
    return canonicalJson(stored) === canonicalJson(normalized);
  } catch {
    return false;
  }
}

const g = globalThis as unknown as { __slateCollab?: Hocuspocus<CollabContext>; __slateCollabServer?: Server<CollabContext> };

export async function startCollabServer() {
  if (g.__slateCollabServer) return g.__slateCollabServer;
  const server = createCollabServer({ port: config.collabPort, host: process.env.COLLAB_HOST || undefined });
  g.__slateCollabServer = server;
  try {
    await server.listen();
    g.__slateCollab = server.hocuspocus;
    console.log(`[slate] realtime server listening on port ${config.collabPort}`);
  } catch (err) {
    g.__slateCollabServer = undefined;
    const code = (err as { code?: string }).code;
    console.error(`[slate] realtime server not started${code === "EADDRINUSE" ? ` (port ${config.collabPort} in use)` : ""}:`, err instanceof Error ? err.message : err);
  }
  return server;
}

/** Use a specific instance (tests). */
export function setCollabInstance(h: Hocuspocus<CollabContext> | undefined) {
  g.__slateCollab = h;
}

/**
 * After a write that did not come through the realtime connection (restore, REST/API save,
 * import), update any open Yjs document so connected editors see it.
 */
export async function notifyContentChanged(pageId: string) {
  const instance = g.__slateCollab;
  if (!instance?.documents.has(pageId)) return;
  const db = await getDb();
  const blocks = await getBlocks(db, pageId);
  const [page] = await db.select({ version: pages.version }).from(pages).where(eq(pages.id, pageId));
  if (!page) return;
  const conn = await instance.openDirectConnection(pageId);
  try {
    let updated: Y.Doc | null = null;
    await conn.transact((doc) => {
      doc.transact(() => replaceYContent(doc, blocks), ORIGIN_SERVER);
      updated = doc;
    });
    // Store right away (the content already matches the blocks at this version).
    if (updated) await storeYState(pageId, updated, page.version);
  } finally {
    await conn.disconnect();
  }
}
