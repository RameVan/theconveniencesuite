import path from "node:path";

function num(name: string, fallback: number): number {
  const raw = process.env[name];
  if (raw === undefined || raw === "") return fallback;
  const n = Number(raw);
  return Number.isFinite(n) ? n : fallback;
}

function bool(name: string, fallback: boolean): boolean {
  const raw = process.env[name];
  if (raw === undefined || raw === "") return fallback;
  return raw === "1" || raw.toLowerCase() === "true";
}

/**
 * Runtime configuration. Every value here is an infrastructure safeguard or deployment setting;
 * none of them varies per user, role or plan.
 */
export const config = {
  get databaseUrl() {
    return process.env.DATABASE_URL || "";
  },
  get dataDir() {
    return path.resolve(/* turbopackIgnore: true */ process.env.DATA_DIR || "./data");
  },
  get allowSignup() {
    return bool("ALLOW_SIGNUP", true);
  },
  get allowPublicSharing() {
    return bool("ALLOW_PUBLIC_SHARING", true);
  },
  get sessionTtlDays() {
    return num("SESSION_TTL_DAYS", 30);
  },
  get maxUploadBytes() {
    return num("MAX_UPLOAD_BYTES", 100 * 1024 * 1024);
  },
  get maxJsonBodyBytes() {
    return num("MAX_JSON_BODY_BYTES", 20 * 1024 * 1024);
  },
  get maxImportBytes() {
    return num("MAX_IMPORT_BYTES", 500 * 1024 * 1024);
  },
  get rateLimitPerMinute() {
    return num("RATE_LIMIT_PER_MINUTE", 1200);
  },
  get authRateLimitPerMinute() {
    return num("AUTH_RATE_LIMIT_PER_MINUTE", 20);
  },
  /** "memory" (per process) or "database" (shared by every instance using the same database). */
  get rateLimitStore(): "memory" | "database" {
    return process.env.RATE_LIMIT_STORE === "database" ? "database" : "memory";
  },
  get revisionIntervalSeconds() {
    return num("REVISION_INTERVAL_SECONDS", 300);
  },
  get trashRetentionDays() {
    return num("TRASH_RETENTION_DAYS", 0);
  },
  get statementTimeoutMs() {
    return num("DB_STATEMENT_TIMEOUT_MS", 30000);
  },
  get storageDriver(): "local" | "s3" {
    return process.env.STORAGE_DRIVER === "s3" ? "s3" : "local";
  },
  get storageWarnBytes() {
    return num("STORAGE_WARN_BYTES", 0);
  },
  /** Outgoing mail for notifications, e.g. smtps://user:pass@smtp.example.com:465 (empty: no email). */
  get smtpUrl() {
    return process.env.SMTP_URL?.trim() || null;
  },
  get smtpFrom() {
    return process.env.SMTP_FROM?.trim() || "Slate <slate@localhost>";
  },
  /** Public base URL of this instance (e.g. https://slate.example.com); used for sign-in redirects. */
  get appUrl() {
    return (process.env.APP_URL || "").replace(/\/+$/, "") || null;
  },
  /** Optional single sign-on with an OpenID Connect provider; enabled when issuer and client id are set. */
  get oidc() {
    const issuer = process.env.OIDC_ISSUER?.trim();
    const clientId = process.env.OIDC_CLIENT_ID?.trim();
    if (!issuer || !clientId) return null;
    return {
      issuer,
      clientId,
      clientSecret: process.env.OIDC_CLIENT_SECRET || undefined,
      displayName: process.env.OIDC_DISPLAY_NAME?.trim() || "Single sign-on",
      scopes: process.env.OIDC_SCOPES?.trim() || "openid email profile",
      // New accounts from the provider follow ALLOW_SIGNUP unless set explicitly.
      allowSignup: bool("OIDC_ALLOW_SIGNUP", bool("ALLOW_SIGNUP", true)),
    };
  },
  get trustProxy() {
    return bool("TRUST_PROXY", false);
  },
  get isProduction() {
    return process.env.NODE_ENV === "production";
  },
  /** Realtime co-editing (Yjs WebSocket server). */
  get realtimeEnabled() {
    return bool("REALTIME", true);
  },
  get collabPort() {
    return num("COLLAB_PORT", 3001);
  },
  /** Port browsers connect to when it differs from COLLAB_PORT (e.g. Docker publishes 3001 on another host port). */
  get collabPublicPort() {
    return num("COLLAB_PUBLIC_PORT", num("COLLAB_PORT", 3001));
  },
  /** Public WebSocket URL when the realtime port is behind a proxy, e.g. wss://slate.example.com/collab */
  get collabPublicUrl() {
    return process.env.COLLAB_PUBLIC_URL || null;
  },
  get secureCookies() {
    return bool("SECURE_COOKIES", process.env.NODE_ENV === "production");
  },
};
