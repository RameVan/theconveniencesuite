import path from "node:path";
import fs from "node:fs";
import type { PgDatabase, PgQueryResultHKT } from "drizzle-orm/pg-core";
import type { ExtractTablesWithRelations } from "drizzle-orm";
import * as schema from "./schema";
import { config } from "../config";

export type Schema = typeof schema;
// Both the node-postgres and PGlite drivers implement this interface.
export type DB = PgDatabase<PgQueryResultHKT, Schema, ExtractTablesWithRelations<Schema>>;
export type Tx = Parameters<Parameters<DB["transaction"]>[0]>[0];
export type DBorTx = DB | Tx;

export interface DbHandle {
  db: DB;
  driver: "pg" | "pglite";
  close: () => Promise<void>;
}

function migrationsFolder() {
  const candidates = [path.join(/* turbopackIgnore: true */ process.cwd(), "drizzle")];
  return candidates.find((p) => fs.existsSync(path.join(p, "meta", "_journal.json"))) ?? candidates[0];
}

/**
 * Create a database handle.
 * - `url` starting with postgres:// → node-postgres pool.
 * - `url` = "memory://" → in-memory PGlite (tests).
 * - otherwise PGlite persisted in DATA_DIR/pglite.
 */
export async function createDb(url = config.databaseUrl, opts: { migrate?: boolean } = {}): Promise<DbHandle> {
  const doMigrate = opts.migrate ?? true;
  if (url.startsWith("postgres://") || url.startsWith("postgresql://")) {
    const { Pool } = await import("pg");
    const { drizzle } = await import("drizzle-orm/node-postgres");
    const pool = new Pool({
      connectionString: url,
      max: Number(process.env.DB_POOL_MAX || 10),
      statement_timeout: config.statementTimeoutMs,
      connectionTimeoutMillis: 10000,
    });
    const db = drizzle(pool, { schema, casing: "snake_case" });
    // Page content contains arbitrary Unicode (emoji, CJK); a non-UTF8 database would fail on it later.
    const enc = await pool.query("SHOW server_encoding");
    if (String(enc.rows[0]?.server_encoding).toUpperCase() !== "UTF8") {
      await pool.end();
      throw new Error(`The PostgreSQL database uses the ${enc.rows[0]?.server_encoding} encoding. Slate requires UTF8 (create it with ENCODING 'UTF8').`);
    }
    if (doMigrate) {
      const { migrate } = await import("drizzle-orm/node-postgres/migrator");
      await migrate(db, { migrationsFolder: migrationsFolder() });
    }
    return { db: db as unknown as DB, driver: "pg", close: () => pool.end() };
  }
  const { PGlite } = await import("@electric-sql/pglite");
  const { drizzle } = await import("drizzle-orm/pglite");
  let client: InstanceType<typeof PGlite>;
  if (url === "memory://") {
    client = new PGlite();
  } else {
    const dir = path.join(/* turbopackIgnore: true */ config.dataDir, "pglite");
    fs.mkdirSync(dir, { recursive: true });
    client = new PGlite(dir);
  }
  const db = drizzle(client, { schema, casing: "snake_case" });
  if (doMigrate) {
    const { migrate } = await import("drizzle-orm/pglite/migrator");
    await migrate(db, { migrationsFolder: migrationsFolder() });
  }
  return { db: db as unknown as DB, driver: "pglite", close: () => client.close() };
}

const g = globalThis as unknown as { __slateDb?: Promise<DbHandle> };

/** Process-wide database handle (survives dev hot reloads). */
export function getDbHandle(): Promise<DbHandle> {
  if (!g.__slateDb) {
    g.__slateDb = createDb().catch((err) => {
      g.__slateDb = undefined;
      throw err;
    });
  }
  return g.__slateDb;
}

export async function getDb(): Promise<DB> {
  return (await getDbHandle()).db;
}

/** For tests: install a specific handle as the process-wide database. */
export function setDbHandle(handle: DbHandle) {
  g.__slateDb = Promise.resolve(handle);
}

export { schema };
