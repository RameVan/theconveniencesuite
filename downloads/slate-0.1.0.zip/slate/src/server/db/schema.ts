import { sql } from "drizzle-orm";
import {
  pgTable,
  text,
  timestamp,
  boolean,
  integer,
  doublePrecision,
  jsonb,
  primaryKey,
  index,
  uniqueIndex,
  customType,
  bigint,
  type AnyPgColumn,
} from "drizzle-orm/pg-core";

const tsvector = customType<{ data: string }>({
  dataType() {
    return "tsvector";
  },
});

const now = () => timestamp({ withTimezone: true, mode: "date" }).notNull().defaultNow();

export const users = pgTable(
  "users",
  {
    id: text().primaryKey(),
    email: text().notNull(),
    name: text().notNull(),
    passwordHash: text().notNull(),
    isAdmin: boolean().notNull().default(false),
    avatarUrl: text(),
    /** Email about mentions and replies (when the server has SMTP configured). */
    emailNotifications: boolean().notNull().default(true),
    createdAt: now(),
  },
  (t) => [uniqueIndex("users_email_idx").on(t.email)],
);

/** Password reset links: only a hash of the token is stored; single use, short-lived. */
export const passwordResets = pgTable(
  "password_resets",
  {
    tokenHash: text().primaryKey(),
    userId: text()
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp({ withTimezone: true, mode: "date" }).notNull(),
    usedAt: timestamp({ withTimezone: true, mode: "date" }),
    createdAt: now(),
  },
  (t) => [index("password_resets_user_idx").on(t.userId)],
);

/** Sign-in identities from an OpenID Connect provider (issuer + subject), linked to a user. */
export const userIdentities = pgTable(
  "user_identities",
  {
    issuer: text().notNull(),
    subject: text().notNull(),
    userId: text()
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    email: text(),
    createdAt: now(),
  },
  (t) => [primaryKey({ columns: [t.issuer, t.subject] }), index("user_identities_user_idx").on(t.userId)],
);

export const sessions = pgTable(
  "sessions",
  {
    id: text().primaryKey(), // sha256(token)
    userId: text()
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: now(),
    lastSeenAt: now(),
    expiresAt: timestamp({ withTimezone: true, mode: "date" }).notNull(),
    userAgent: text(),
  },
  (t) => [index("sessions_user_idx").on(t.userId)],
);

export const apiTokens = pgTable(
  "api_tokens",
  {
    id: text().primaryKey(),
    userId: text()
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    name: text().notNull(),
    tokenHash: text().notNull(),
    createdAt: now(),
    lastUsedAt: timestamp({ withTimezone: true, mode: "date" }),
  },
  (t) => [uniqueIndex("api_tokens_hash_idx").on(t.tokenHash)],
);

export const workspaces = pgTable("workspaces", {
  id: text().primaryKey(),
  name: text().notNull(),
  icon: text(),
  createdBy: text().references(() => users.id, { onDelete: "set null" }),
  createdAt: now(),
});

export const workspaceMembers = pgTable(
  "workspace_members",
  {
    workspaceId: text()
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    userId: text()
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    role: text({ enum: ["owner", "admin", "editor", "viewer"] }).notNull(),
    joinedAt: now(),
  },
  (t) => [primaryKey({ columns: [t.workspaceId, t.userId] }), index("members_user_idx").on(t.userId)],
);

export const invitations = pgTable(
  "invitations",
  {
    id: text().primaryKey(),
    workspaceId: text()
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    email: text().notNull(),
    role: text({ enum: ["admin", "editor", "viewer"] }).notNull(),
    tokenHash: text().notNull(),
    invitedBy: text().references(() => users.id, { onDelete: "set null" }),
    createdAt: now(),
    expiresAt: timestamp({ withTimezone: true, mode: "date" }).notNull(),
    acceptedAt: timestamp({ withTimezone: true, mode: "date" }),
  },
  (t) => [uniqueIndex("invitations_token_idx").on(t.tokenHash), index("invitations_ws_idx").on(t.workspaceId)],
);

export const pages = pgTable(
  "pages",
  {
    id: text().primaryKey(),
    workspaceId: text()
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    parentId: text().references((): AnyPgColumn => pages.id, { onDelete: "cascade" }),
    databaseId: text().references((): AnyPgColumn => pages.id, { onDelete: "cascade" }),
    kind: text({ enum: ["page", "database"] }).notNull().default("page"),
    title: text().notNull().default(""),
    icon: text(),
    cover: text(),
    position: doublePrecision().notNull().default(0),
    visibility: text({ enum: ["workspace", "private"] }).notNull().default("workspace"),
    properties: jsonb().$type<Record<string, unknown>>().notNull().default({}),
    isTemplate: boolean().notNull().default(false),
    isInline: boolean().notNull().default(false),
    fullWidth: boolean().notNull().default(false),
    smallText: boolean().notNull().default(false),
    version: integer().notNull().default(1),
    publicShareToken: text(),
    createdBy: text().references(() => users.id, { onDelete: "set null" }),
    createdAt: now(),
    updatedBy: text().references(() => users.id, { onDelete: "set null" }),
    updatedAt: now(),
    archivedAt: timestamp({ withTimezone: true, mode: "date" }),
    archivedBy: text().references(() => users.id, { onDelete: "set null" }),
    archivedRootId: text(),
    search: tsvector().generatedAlwaysAs(sql`to_tsvector('simple', coalesce("title", ''))`),
  },
  (t) => [
    index("pages_ws_parent_idx").on(t.workspaceId, t.parentId),
    index("pages_database_idx").on(t.databaseId),
    index("pages_parent_idx").on(t.parentId),
    index("pages_archived_root_idx").on(t.archivedRootId),
    uniqueIndex("pages_share_token_idx").on(t.publicShareToken),
    index("pages_search_idx").using("gin", t.search),
  ],
);

export const blocks = pgTable(
  "blocks",
  {
    pageId: text()
      .notNull()
      .references(() => pages.id, { onDelete: "cascade" }),
    id: text().notNull(),
    position: integer().notNull(),
    type: text().notNull(),
    content: jsonb().$type<Record<string, unknown>>().notNull(),
    text: text().notNull().default(""),
    updatedAt: now(),
    updatedBy: text().references(() => users.id, { onDelete: "set null" }),
    search: tsvector().generatedAlwaysAs(sql`to_tsvector('simple', coalesce("text", ''))`),
  },
  (t) => [
    primaryKey({ columns: [t.pageId, t.id] }),
    index("blocks_page_pos_idx").on(t.pageId, t.position),
    index("blocks_search_idx").using("gin", t.search),
  ],
);

export const databaseProperties = pgTable(
  "database_properties",
  {
    id: text().primaryKey(),
    databaseId: text()
      .notNull()
      .references(() => pages.id, { onDelete: "cascade" }),
    name: text().notNull(),
    type: text().notNull(),
    config: jsonb().$type<Record<string, unknown>>().notNull().default({}),
    position: doublePrecision().notNull().default(0),
    createdAt: now(),
  },
  (t) => [index("db_props_db_idx").on(t.databaseId)],
);

export const databaseViews = pgTable(
  "database_views",
  {
    id: text().primaryKey(),
    databaseId: text()
      .notNull()
      .references(() => pages.id, { onDelete: "cascade" }),
    name: text().notNull(),
    type: text().notNull(),
    config: jsonb().$type<Record<string, unknown>>().notNull().default({}),
    position: doublePrecision().notNull().default(0),
    createdAt: now(),
  },
  (t) => [index("db_views_db_idx").on(t.databaseId)],
);

export const relationLinks = pgTable(
  "relation_links",
  {
    propertyId: text()
      .notNull()
      .references(() => databaseProperties.id, { onDelete: "cascade" }),
    fromPageId: text()
      .notNull()
      .references(() => pages.id, { onDelete: "cascade" }),
    toPageId: text()
      .notNull()
      .references(() => pages.id, { onDelete: "cascade" }),
    position: doublePrecision().notNull().default(0),
  },
  (t) => [
    primaryKey({ columns: [t.propertyId, t.fromPageId, t.toPageId] }),
    index("relation_from_idx").on(t.fromPageId),
    index("relation_to_idx").on(t.toPageId),
  ],
);

export const pagePermissions = pgTable(
  "page_permissions",
  {
    pageId: text()
      .notNull()
      .references(() => pages.id, { onDelete: "cascade" }),
    userId: text()
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    access: text({ enum: ["none", "view", "edit", "full"] }).notNull(),
    grantedBy: text().references(() => users.id, { onDelete: "set null" }),
    createdAt: now(),
  },
  (t) => [primaryKey({ columns: [t.pageId, t.userId] }), index("page_perm_user_idx").on(t.userId)],
);

export const pageRevisions = pgTable(
  "page_revisions",
  {
    id: text().primaryKey(),
    pageId: text()
      .notNull()
      .references(() => pages.id, { onDelete: "cascade" }),
    createdAt: now(),
    createdBy: text().references(() => users.id, { onDelete: "set null" }),
    reason: text().notNull().default("autosave"),
    hash: text().notNull(),
    snapshot: jsonb().$type<Record<string, unknown>>().notNull(),
  },
  (t) => [index("revisions_page_idx").on(t.pageId, t.createdAt)],
);

export const favorites = pgTable(
  "favorites",
  {
    userId: text()
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    pageId: text()
      .notNull()
      .references(() => pages.id, { onDelete: "cascade" }),
    position: doublePrecision().notNull().default(0),
    createdAt: now(),
  },
  (t) => [primaryKey({ columns: [t.userId, t.pageId] })],
);

export const pageVisits = pgTable(
  "page_visits",
  {
    userId: text()
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    pageId: text()
      .notNull()
      .references(() => pages.id, { onDelete: "cascade" }),
    visitedAt: now(),
  },
  (t) => [primaryKey({ columns: [t.userId, t.pageId] }), index("visits_user_time_idx").on(t.userId, t.visitedAt)],
);

export const files = pgTable(
  "files",
  {
    id: text().primaryKey(),
    workspaceId: text()
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    uploadedBy: text().references(() => users.id, { onDelete: "set null" }),
    name: text().notNull(),
    mime: text().notNull(),
    size: bigint({ mode: "number" }).notNull(),
    storageKey: text().notNull(),
    sha256: text().notNull(),
    createdAt: now(),
  },
  (t) => [index("files_ws_idx").on(t.workspaceId)],
);

export const comments = pgTable(
  "comments",
  {
    id: text().primaryKey(),
    pageId: text()
      .notNull()
      .references(() => pages.id, { onDelete: "cascade" }),
    userId: text().references(() => users.id, { onDelete: "set null" }),
    /** Replies point at the thread's first comment; null for a thread root. */
    parentId: text().references((): AnyPgColumn => comments.id, { onDelete: "cascade" }),
    /** Inline threads: the block holding the `comment` mark (whose threadId is the root id) and the quoted text. */
    blockId: text(),
    quote: text(),
    body: text().notNull(),
    resolved: boolean().notNull().default(false),
    createdAt: now(),
    editedAt: timestamp({ withTimezone: true, mode: "date" }),
  },
  (t) => [index("comments_page_idx").on(t.pageId, t.createdAt), index("comments_parent_idx").on(t.parentId)],
);

/** Fixed-window request counters shared by all app instances (RATE_LIMIT_STORE=database). */
export const rateLimits = pgTable(
  "rate_limits",
  {
    key: text().primaryKey(),
    count: integer().notNull(),
    resetAt: timestamp({ withTimezone: true, mode: "date" }).notNull(),
  },
  (t) => [index("rate_limits_reset_idx").on(t.resetAt)],
);

/** In-app notifications (mentions and replies). Listing re-checks page access, so revoked access hides them. */
export const notifications = pgTable(
  "notifications",
  {
    id: text().primaryKey(),
    userId: text()
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    workspaceId: text()
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    pageId: text()
      .notNull()
      .references(() => pages.id, { onDelete: "cascade" }),
    actorId: text().references(() => users.id, { onDelete: "set null" }),
    /** "page_mention" | "comment_mention" | "reply" */
    kind: text().notNull(),
    commentId: text().references(() => comments.id, { onDelete: "cascade" }),
    blockId: text(),
    excerpt: text().notNull().default(""),
    createdAt: now(),
    readAt: timestamp({ withTimezone: true, mode: "date" }),
  },
  (t) => [index("notifications_user_idx").on(t.userId, t.createdAt)],
);

export const auditEvents = pgTable(
  "audit_events",
  {
    id: text().primaryKey(),
    workspaceId: text().references(() => workspaces.id, { onDelete: "cascade" }),
    userId: text().references(() => users.id, { onDelete: "set null" }),
    action: text().notNull(),
    targetId: text(),
    meta: jsonb().$type<Record<string, unknown>>().notNull().default({}),
    createdAt: now(),
  },
  (t) => [index("audit_ws_time_idx").on(t.workspaceId, t.createdAt)],
);

const bytea = customType<{ data: Uint8Array; driverData: Uint8Array | Buffer }>({
  dataType() {
    return "bytea";
  },
  fromDriver(v) {
    return v instanceof Uint8Array ? v : new Uint8Array(v);
  },
  toDriver(v) {
    return Buffer.from(v);
  },
});

/**
 * Realtime (Yjs) state of a page. It is only reused while `contentVersion` matches
 * `pages.version`; any other write to the blocks makes it stale and it is rebuilt from blocks.
 */
export const pageYdocs = pgTable("page_ydocs", {
  pageId: text()
    .primaryKey()
    .references(() => pages.id, { onDelete: "cascade" }),
  state: bytea().notNull(),
  contentVersion: integer().notNull(),
  updatedAt: now(),
});
