export class AppError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public details?: unknown,
  ) {
    super(message);
    this.name = "AppError";
  }
}

export const badRequest = (msg: string, details?: unknown) => new AppError(400, "bad_request", msg, details);
export const unauthorized = (msg = "Sign in required") => new AppError(401, "unauthorized", msg);
export const forbidden = (msg = "You do not have access to this") => new AppError(403, "forbidden", msg);
// Not-found is also used when the caller lacks access, so IDs cannot be probed.
export const notFound = (msg = "Not found") => new AppError(404, "not_found", msg);
export const conflict = (msg: string, details?: unknown) => new AppError(409, "conflict", msg, details);
export const tooLarge = (msg: string) => new AppError(413, "too_large", msg);
export const tooMany = (msg = "Too many requests, slow down") => new AppError(429, "rate_limited", msg);
