import type { NextRequest } from "next/server";
import { ZodError, type ZodType } from "zod";
import { sql } from "drizzle-orm";
import { getDb, type DB } from "./db";
import { AppError, tooLarge, tooMany, unauthorized, forbidden } from "./errors";
import { getSessionUser, getTokenUser, type Actor, type PublicUser } from "./services/auth";
import { config } from "./config";
import { FormulaError } from "@/lib/formula";

export const SESSION_COOKIE = "slate_session";

// ---------------------------------------------------------------- rate limiting
// Fixed-window counters per client IP: in process memory by default, or in the database
// (RATE_LIMIT_STORE=database) so several app instances share one limit.
const buckets = new Map<string, { count: number; reset: number }>();

export async function rateLimit(key: string, limit: number, windowMs = 60_000) {
  if (limit <= 0) return;
  if (config.rateLimitStore === "database") return rateLimitShared(key, limit, windowMs);
  const now = Date.now();
  let b = buckets.get(key);
  if (!b || b.reset <= now) {
    b = { count: 0, reset: now + windowMs };
    buckets.set(key, b);
    if (buckets.size > 50_000) for (const [k, v] of buckets) if (v.reset <= now) buckets.delete(k);
  }
  b.count++;
  if (b.count > limit) throw tooMany();
}

export function resetRateLimits() {
  buckets.clear();
}

let lastPrune = 0;
async function rateLimitShared(key: string, limit: number, windowMs: number) {
  const db = await getDb();
  // One atomic statement on the database clock, so every instance agrees on windows.
  const res = await db.execute(sql`
    insert into rate_limits (key, count, reset_at) values (${key}, 1, now() + ${windowMs} * interval '1 millisecond')
    on conflict (key) do update set
      count = case when rate_limits.reset_at <= now() then 1 else rate_limits.count + 1 end,
      reset_at = case when rate_limits.reset_at <= now() then excluded.reset_at else rate_limits.reset_at end
    returning count`);
  const rows = ((res as unknown as { rows?: { count: number }[] }).rows ?? res) as { count: number }[];
  if (Date.now() - lastPrune > 60_000) {
    lastPrune = Date.now();
    await db.execute(sql`delete from rate_limits where reset_at < now() - interval '1 minute'`);
  }
  if (Number(rows[0]?.count ?? 0) > limit) throw tooMany();
}

/**
 * The origin the browser used (APP_URL when set). Uses the Host header (the URL Next.js reports can
 * differ from it in standalone mode), and X-Forwarded-Proto/-Host only behind a trusted proxy.
 */
export function requestOrigin(req: Request): string {
  if (config.appUrl) return config.appUrl;
  const url = new URL(req.url);
  const fwdHost = config.trustProxy ? req.headers.get("x-forwarded-host")?.split(",")[0].trim() : null;
  const fwdProto = config.trustProxy ? req.headers.get("x-forwarded-proto")?.split(",")[0].trim() : null;
  const host = fwdHost || req.headers.get("host") || url.host;
  const proto = fwdProto === "https" || fwdProto === "http" ? fwdProto : url.protocol.replace(":", "");
  return `${proto}://${host}`;
}

export function clientIp(req: Request): string {
  if (config.trustProxy) {
    const fwd = req.headers.get("x-forwarded-for");
    if (fwd) return fwd.split(",")[0].trim();
    const real = req.headers.get("x-real-ip");
    if (real) return real;
  }
  return "local";
}

// ---------------------------------------------------------------- CSRF

function checkOrigin(req: Request) {
  const origin = req.headers.get("origin");
  const host = (config.trustProxy && req.headers.get("x-forwarded-host")) || req.headers.get("host");
  if (origin) {
    try {
      if (new URL(origin).host === host) return;
    } catch {
      /* fall through */
    }
    throw forbidden("Cross-origin request blocked");
  }
  const site = req.headers.get("sec-fetch-site");
  if (site === "same-origin" || site === "none") return;
  throw forbidden("Cross-origin request blocked");
}

// ---------------------------------------------------------------- handler wrapper

export interface ApiCtx {
  req: NextRequest;
  db: DB;
  ip: string;
  user: PublicUser | null;
  actor: Actor | null;
  /** Parse and validate a JSON body (size-limited). */
  body<T>(schema: ZodType<T>): Promise<T>;
  query(name: string): string | null;
}

export interface AuthedCtx extends ApiCtx {
  user: PublicUser;
  actor: Actor;
}

type Opts = { auth?: "required" | "optional"; limit?: "auth" | "default" };

async function readJson(req: NextRequest): Promise<unknown> {
  const len = Number(req.headers.get("content-length") || 0);
  if (len > config.maxJsonBodyBytes) throw tooLarge("Request body is too large");
  const text = await req.text();
  if (text.length > config.maxJsonBodyBytes) throw tooLarge("Request body is too large");
  if (!text) return {};
  try {
    return JSON.parse(text);
  } catch {
    throw new AppError(400, "bad_json", "Request body is not valid JSON");
  }
}

export function errorResponse(err: unknown): Response {
  if (err instanceof AppError) {
    return Response.json({ error: { code: err.code, message: err.message, details: err.details } }, { status: err.status });
  }
  if (err instanceof ZodError) {
    const first = err.issues[0];
    const where = first?.path?.length ? `${first.path.join(".")}: ` : "";
    return Response.json(
      { error: { code: "invalid_input", message: `${where}${first?.message ?? "Invalid input"}`, details: err.issues } },
      { status: 400 },
    );
  }
  if (err instanceof FormulaError) {
    return Response.json({ error: { code: "formula_error", message: err.message, details: { pos: err.pos } } }, { status: 400 });
  }
  console.error("[api] unhandled error:", err instanceof Error ? `${err.name}: ${err.message}\n${err.stack}` : err);
  return Response.json({ error: { code: "internal", message: "Something went wrong on the server" } }, { status: 500 });
}

export function api<P = unknown>(
  handler: (ctx: AuthedCtx, params: P) => Promise<unknown>,
  opts?: Opts & { auth?: "required" },
): (req: NextRequest, routeCtx: { params: Promise<P> }) => Promise<Response>;
export function api<P = unknown>(
  handler: (ctx: ApiCtx, params: P) => Promise<unknown>,
  opts: Opts & { auth: "optional" },
): (req: NextRequest, routeCtx: { params: Promise<P> }) => Promise<Response>;
export function api<P = unknown>(handler: (ctx: AuthedCtx, params: P) => Promise<unknown>, opts: Opts = {}) {
  return async (req: NextRequest, routeCtx: { params: Promise<P> }) => {
    const started = Date.now();
    let status = 200;
    try {
      const ip = clientIp(req);
      await rateLimit(`all:${ip}`, config.rateLimitPerMinute);
      if (opts.limit === "auth") await rateLimit(`auth:${ip}`, config.authRateLimitPerMinute);
      const db = await getDb();
      let user: PublicUser | null = null;
      let actor: Actor | null = null;
      const authz = req.headers.get("authorization");
      if (authz?.startsWith("Bearer ")) {
        user = await getTokenUser(db, authz.slice(7).trim());
        if (!user) throw unauthorized("Invalid API token");
        actor = { userId: user.id, via: "token" };
      } else {
        const token = req.cookies.get(SESSION_COOKIE)?.value;
        if (token) {
          const s = await getSessionUser(db, token);
          if (s) {
            user = s.user;
            actor = { userId: s.user.id, sessionId: s.sessionId, via: "session" };
          }
        }
        if (req.method !== "GET" && req.method !== "HEAD") checkOrigin(req);
      }
      if ((opts.auth ?? "required") === "required" && !actor) throw unauthorized();
      const ctx: ApiCtx = {
        req,
        db,
        ip,
        user,
        actor,
        body: async (schema) => schema.parse(await readJson(req)),
        query: (name) => req.nextUrl.searchParams.get(name),
      };
      const params = (await routeCtx?.params) ?? ({} as P);
      const out = await handler(ctx as AuthedCtx, params);
      if (out instanceof Response) {
        status = out.status;
        return out;
      }
      return Response.json(out ?? { ok: true });
    } catch (err) {
      const res = errorResponse(err);
      status = res.status;
      return res;
    } finally {
      if (process.env.SLATE_LOG_REQUESTS !== "0" && process.env.NODE_ENV !== "test") {
        // Never log bodies, query strings or headers: they can contain content or secrets.
        console.log(`[api] ${req.method} ${req.nextUrl.pathname} ${status} ${Date.now() - started}ms`);
      }
    }
  };
}

export function sessionCookie(token: string, expires: Date) {
  return {
    name: SESSION_COOKIE,
    value: token,
    httpOnly: true,
    sameSite: "lax" as const,
    secure: config.secureCookies,
    path: "/",
    expires,
  };
}
