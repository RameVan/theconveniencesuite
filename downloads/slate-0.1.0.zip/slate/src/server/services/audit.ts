import type { DBorTx } from "../db";
import { auditEvents } from "../db/schema";
import { newId } from "../crypto";

/** Record a security-relevant action. `meta` must never contain page content or secrets. */
export async function audit(
  db: DBorTx,
  e: { workspaceId?: string | null; userId?: string | null; action: string; targetId?: string | null; meta?: Record<string, unknown> },
) {
  await db.insert(auditEvents).values({
    id: newId(),
    workspaceId: e.workspaceId ?? null,
    userId: e.userId ?? null,
    action: e.action,
    targetId: e.targetId ?? null,
    meta: e.meta ?? {},
  });
}
