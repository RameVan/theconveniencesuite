import { and, eq, gt, sql, desc } from "drizzle-orm";
import { z } from "zod";
import type { DB } from "../db";
import { users, sessions, apiTokens, workspaceMembers, workspaces } from "../db/schema";
import { hashPassword, verifyPassword, getDummyHash, newId, randomToken, sha256 } from "../crypto";
import { badRequest, conflict, forbidden, notFound, unauthorized } from "../errors";
import { config } from "../config";

export interface Actor {
  userId: string;
  sessionId?: string;
  via: "session" | "token";
}

export interface PublicUser {
  id: string;
  email: string;
  name: string;
  isAdmin: boolean;
  avatarUrl: string | null;
  /** False for accounts created through single sign-on that never set a password. */
  hasPassword: boolean;
  emailNotifications: boolean;
}

/** Stored password hashes are scrypt strings; anything else (e.g. SSO-only accounts) has no password. */
export const hasPassword = (passwordHash: string) => passwordHash.startsWith("scrypt$");

export const emailSchema = z
  .string()
  .trim()
  .toLowerCase()
  .max(254)
  .regex(/^[^\s@]+@[^\s@]+\.[^\s@]+$/, "Enter a valid email address");
export const passwordSchema = z.string().min(8, "Use at least 8 characters").max(256);
export const nameSchema = z.string().trim().min(1, "Enter your name").max(100);

export const toPublicUser = (u: typeof users.$inferSelect): PublicUser => ({
  hasPassword: hasPassword(u.passwordHash),
  emailNotifications: u.emailNotifications,
  id: u.id,
  email: u.email,
  name: u.name,
  isAdmin: u.isAdmin,
  avatarUrl: u.avatarUrl,
});

export async function countUsers(db: DB) {
  const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(users);
  return n;
}

export async function signup(
  db: DB,
  input: { email: string; password: string; name: string },
  opts: { bypassSignupSwitch?: boolean } = {},
): Promise<PublicUser> {
  const email = emailSchema.parse(input.email);
  const password = passwordSchema.parse(input.password);
  const name = nameSchema.parse(input.name);
  const isFirst = (await countUsers(db)) === 0;
  if (!isFirst && !config.allowSignup && !opts.bypassSignupSwitch) {
    throw forbidden("Sign-up is disabled on this server. Ask an administrator for an invitation.");
  }
  const existing = await db.query.users.findFirst({ where: eq(users.email, email) });
  if (existing) throw conflict("An account with this email already exists");
  const passwordHash = await hashPassword(password);
  const [user] = await db.insert(users).values({ id: newId(), email, name, passwordHash, isAdmin: isFirst }).returning();
  return toPublicUser(user);
}

export async function login(db: DB, input: { email: string; password: string }) {
  const email = emailSchema.safeParse(input.email);
  const user = email.success ? await db.query.users.findFirst({ where: eq(users.email, email.data) }) : undefined;
  // Unknown emails and single-sign-on-only accounts take as long as a wrong password.
  if (!user || !hasPassword(user.passwordHash)) {
    await verifyPassword(String(input.password ?? ""), await getDummyHash());
    throw unauthorized("Incorrect email or password");
  }
  const ok = await verifyPassword(String(input.password ?? ""), user.passwordHash);
  if (!ok) throw unauthorized("Incorrect email or password");
  return toPublicUser(user);
}

export async function createSession(db: DB, userId: string, userAgent?: string | null) {
  const token = randomToken(32);
  const id = sha256(token);
  const expiresAt = new Date(Date.now() + config.sessionTtlDays * 86_400_000);
  await db.insert(sessions).values({ id, userId, expiresAt, userAgent: userAgent?.slice(0, 300) ?? null });
  return { token, expiresAt, sessionId: id };
}

/** Validate a session token; extends the expiry (sliding) at most once per hour. */
export async function getSessionUser(db: DB, token: string): Promise<{ user: PublicUser; sessionId: string } | null> {
  if (!token || token.length > 200) return null;
  const id = sha256(token);
  const row = await db
    .select({ s: sessions, u: users })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(and(eq(sessions.id, id), gt(sessions.expiresAt, new Date())))
    .limit(1);
  if (!row.length) return null;
  const { s, u } = row[0];
  if (Date.now() - s.lastSeenAt.getTime() > 3_600_000) {
    await db
      .update(sessions)
      .set({ lastSeenAt: new Date(), expiresAt: new Date(Date.now() + config.sessionTtlDays * 86_400_000) })
      .where(eq(sessions.id, id));
  }
  return { user: toPublicUser(u), sessionId: id };
}

export async function deleteSession(db: DB, sessionId: string) {
  await db.delete(sessions).where(eq(sessions.id, sessionId));
}

export async function listSessions(db: DB, actor: Actor) {
  const rows = await db
    .select()
    .from(sessions)
    .where(and(eq(sessions.userId, actor.userId), gt(sessions.expiresAt, new Date())))
    .orderBy(desc(sessions.lastSeenAt));
  return rows.map((s) => ({
    // Expose a short, non-secret handle derived from the stored hash.
    id: s.id.slice(0, 16),
    current: s.id === actor.sessionId,
    createdAt: s.createdAt,
    lastSeenAt: s.lastSeenAt,
    expiresAt: s.expiresAt,
    userAgent: s.userAgent,
  }));
}

export async function revokeSession(db: DB, actor: Actor, handle: string) {
  const rows = await db.select({ id: sessions.id }).from(sessions).where(eq(sessions.userId, actor.userId));
  const match = rows.find((r) => r.id.startsWith(handle) && handle.length >= 16);
  if (!match) throw notFound("Session not found");
  await db.delete(sessions).where(eq(sessions.id, match.id));
}

export async function revokeOtherSessions(db: DB, actor: Actor) {
  const rows = await db.select({ id: sessions.id }).from(sessions).where(eq(sessions.userId, actor.userId));
  for (const r of rows) if (r.id !== actor.sessionId) await db.delete(sessions).where(eq(sessions.id, r.id));
}

// ---------------------------------------------------------------- API tokens

export async function createApiToken(db: DB, actor: Actor, name: string) {
  const clean = z.string().trim().min(1).max(100).parse(name);
  const token = `slt_${randomToken(32)}`;
  const id = newId();
  await db.insert(apiTokens).values({ id, userId: actor.userId, name: clean, tokenHash: sha256(token) });
  return { id, name: clean, token };
}

export async function listApiTokens(db: DB, actor: Actor) {
  const rows = await db.select().from(apiTokens).where(eq(apiTokens.userId, actor.userId)).orderBy(desc(apiTokens.createdAt));
  return rows.map((t) => ({ id: t.id, name: t.name, createdAt: t.createdAt, lastUsedAt: t.lastUsedAt }));
}

export async function revokeApiToken(db: DB, actor: Actor, id: string) {
  const res = await db
    .delete(apiTokens)
    .where(and(eq(apiTokens.id, id), eq(apiTokens.userId, actor.userId)))
    .returning({ id: apiTokens.id });
  if (!res.length) throw notFound("Token not found");
}

export async function getTokenUser(db: DB, token: string): Promise<PublicUser | null> {
  if (!token.startsWith("slt_") || token.length > 200) return null;
  const hash = sha256(token);
  const row = await db.select({ t: apiTokens, u: users }).from(apiTokens).innerJoin(users, eq(users.id, apiTokens.userId)).where(eq(apiTokens.tokenHash, hash)).limit(1);
  if (!row.length) return null;
  const last = row[0].t.lastUsedAt;
  if (!last || Date.now() - last.getTime() > 60_000) {
    await db.update(apiTokens).set({ lastUsedAt: new Date() }).where(eq(apiTokens.id, row[0].t.id));
  }
  return toPublicUser(row[0].u);
}

// ---------------------------------------------------------------- profile

export async function getUser(db: DB, userId: string) {
  const u = await db.query.users.findFirst({ where: eq(users.id, userId) });
  if (!u) throw unauthorized();
  return toPublicUser(u);
}

export async function updateProfile(db: DB, actor: Actor, input: { name?: string; avatarUrl?: string | null; emailNotifications?: boolean }) {
  const patch: Partial<typeof users.$inferInsert> = {};
  if (input.emailNotifications !== undefined) patch.emailNotifications = z.boolean().parse(input.emailNotifications);
  if (input.name !== undefined) patch.name = nameSchema.parse(input.name);
  if (input.avatarUrl !== undefined) patch.avatarUrl = input.avatarUrl ? z.string().max(2000).parse(input.avatarUrl) : null;
  if (Object.keys(patch).length) await db.update(users).set(patch).where(eq(users.id, actor.userId));
  return getUser(db, actor.userId);
}

/**
 * Change the password. Accounts without one (created through single sign-on) can set a first
 * password from a signed-in browser session; API tokens can't.
 */
export async function changePassword(db: DB, actor: Actor, input: { currentPassword?: string; newPassword: string }) {
  const u = await db.query.users.findFirst({ where: eq(users.id, actor.userId) });
  if (!u) throw unauthorized();
  if (hasPassword(u.passwordHash)) {
    if (!(await verifyPassword(String(input.currentPassword ?? ""), u.passwordHash))) throw badRequest("Current password is incorrect");
  } else if (actor.via !== "session") throw forbidden("Set a first password from the app, not with an API token");
  const passwordHash = await hashPassword(passwordSchema.parse(input.newPassword));
  await db.update(users).set({ passwordHash }).where(eq(users.id, actor.userId));
  // Sign out every other session after a password change.
  await revokeOtherSessions(db, actor);
}

/**
 * Delete the account. Refused while the user is the only owner of a workspace with other
 * members (ownership must be transferred first). Workspaces where the user is the only member
 * are deleted with the account.
 */
export async function deleteAccount(db: DB, actor: Actor, confirmation: { password?: string; email?: string }) {
  const u = await db.query.users.findFirst({ where: eq(users.id, actor.userId) });
  if (!u) throw unauthorized();
  if (hasPassword(u.passwordHash)) {
    if (!(await verifyPassword(String(confirmation.password ?? ""), u.passwordHash))) throw badRequest("Password is incorrect");
  } else {
    // Accounts without a password confirm with their email, from a browser session.
    if (actor.via !== "session") throw forbidden("Delete this account from the app");
    if (String(confirmation.email ?? "").trim().toLowerCase() !== u.email) throw badRequest("Type your email address to confirm");
  }
  const memberships = await db.select().from(workspaceMembers).where(eq(workspaceMembers.userId, actor.userId));
  const soloWorkspaces: string[] = [];
  for (const m of memberships) {
    const all = await db.select().from(workspaceMembers).where(eq(workspaceMembers.workspaceId, m.workspaceId));
    if (all.length === 1) {
      soloWorkspaces.push(m.workspaceId);
      continue;
    }
    if (m.role === "owner" && !all.some((o) => o.userId !== actor.userId && o.role === "owner")) {
      throw conflict("Transfer ownership of your shared workspaces before deleting your account");
    }
  }
  await db.transaction(async (tx) => {
    for (const id of soloWorkspaces) await tx.delete(workspaces).where(eq(workspaces.id, id));
    await tx.delete(users).where(eq(users.id, actor.userId));
  });
}
