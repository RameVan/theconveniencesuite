import { and, asc, eq, or } from "drizzle-orm";
import { z } from "zod";
import type { DB } from "../db";
import { comments, users } from "../db/schema";
import { newId } from "../crypto";
import { badRequest, conflict, forbidden, notFound } from "../errors";
import { commentMentionIds, commentPlainText } from "@/lib/mentions";
import type { Actor } from "./auth";
import { requirePage } from "./permissions";
import { notify } from "./notifications";

export async function listComments(db: DB, actor: Actor, pageId: string) {
  await requirePage(db, actor, pageId, "view");
  return db
    .select({
      id: comments.id,
      parentId: comments.parentId,
      blockId: comments.blockId,
      quote: comments.quote,
      body: comments.body,
      resolved: comments.resolved,
      createdAt: comments.createdAt,
      editedAt: comments.editedAt,
      userId: comments.userId,
      userName: users.name,
    })
    .from(comments)
    .leftJoin(users, eq(users.id, comments.userId))
    .where(eq(comments.pageId, pageId))
    .orderBy(asc(comments.createdAt));
}

const ID = z.string().regex(/^[A-Za-z0-9_-]{1,64}$/, "Invalid id");

export const commentInput = z.object({
  body: z.string().trim().min(1).max(10_000),
  /** Optional client-chosen id, so an inline thread's editor mark can be applied before the request. */
  id: ID.optional(),
  /** Reply to this thread (the root comment's id). */
  parentId: ID.optional(),
  /** Inline thread: the block that holds the anchored text, and the quoted text. */
  blockId: ID.optional(),
  quote: z.string().max(1_000).optional(),
});

/** Anyone who can view a page (as a signed-in user) can comment on it. */
export async function addComment(db: DB, actor: Actor, pageId: string, input: z.infer<typeof commentInput>) {
  await requirePage(db, actor, pageId, "view");
  const data = commentInput.parse(input);
  let root: typeof comments.$inferSelect | undefined;
  if (data.parentId) {
    [root] = await db.select().from(comments).where(and(eq(comments.id, data.parentId), eq(comments.pageId, pageId)));
    if (!root) throw notFound("Thread not found");
    if (root.parentId) throw badRequest("Reply to the first comment of the thread");
    if (data.blockId || data.quote) throw badRequest("Replies cannot have their own anchor");
  }
  const id = data.id ?? newId();
  if (data.id) {
    const [taken] = await db.select({ id: comments.id }).from(comments).where(eq(comments.id, id));
    if (taken) throw conflict("A comment with this id already exists");
  }
  await db.insert(comments).values({
    id,
    pageId,
    userId: actor.userId,
    parentId: root?.id ?? null,
    blockId: root ? null : (data.blockId ?? null),
    quote: root ? null : (data.quote?.trim() || null),
    body: data.body,
  });

  const text = commentPlainText(data.body);
  const mentioned = commentMentionIds(data.body);
  await notify(db, actor, { pageId, userIds: mentioned, kind: "comment_mention", commentId: id, excerpt: text });
  if (root) {
    // Everyone already in the thread hears about replies (mentioned users got a mention instead).
    const participants = await db
      .select({ userId: comments.userId })
      .from(comments)
      .where(and(eq(comments.pageId, pageId), or(eq(comments.id, root.id), eq(comments.parentId, root.id))));
    const ids = participants.map((p) => p.userId).filter((u): u is string => !!u && !mentioned.includes(u));
    await notify(db, actor, { pageId, userIds: ids, kind: "reply", commentId: id, excerpt: text });
  }
  return { id };
}

export async function updateComment(db: DB, actor: Actor, pageId: string, commentId: string, input: { resolved?: boolean; body?: string }) {
  const pa = await requirePage(db, actor, pageId, "view");
  const [c] = await db.select().from(comments).where(and(eq(comments.id, commentId), eq(comments.pageId, pageId)));
  if (!c) throw notFound("Comment not found");
  const patch: Partial<typeof comments.$inferInsert> = {};
  let newMentions: string[] = [];
  if (input.body !== undefined) {
    if (c.userId !== actor.userId) throw forbidden("You can only edit your own comments");
    patch.body = z.string().trim().min(1).max(10_000).parse(input.body);
    patch.editedAt = new Date();
    const before = new Set(commentMentionIds(c.body));
    newMentions = commentMentionIds(patch.body).filter((u) => !before.has(u));
  }
  if (input.resolved !== undefined) {
    if (c.parentId) throw badRequest("Resolve the thread, not a reply");
    if (pa.access === "view" && c.userId !== actor.userId) throw forbidden();
    patch.resolved = input.resolved;
  }
  if (!Object.keys(patch).length) return;
  await db.update(comments).set(patch).where(eq(comments.id, commentId));
  if (newMentions.length) await notify(db, actor, { pageId, userIds: newMentions, kind: "comment_mention", commentId, excerpt: commentPlainText(patch.body!) });
}

/** Deleting a thread's first comment deletes its replies. */
export async function deleteComment(db: DB, actor: Actor, pageId: string, commentId: string) {
  const pa = await requirePage(db, actor, pageId, "view");
  const [c] = await db.select().from(comments).where(and(eq(comments.id, commentId), eq(comments.pageId, pageId)));
  if (!c) throw notFound("Comment not found");
  if (c.userId !== actor.userId && pa.access !== "full") throw forbidden("You can only delete your own comments");
  await db.delete(comments).where(eq(comments.id, commentId));
}
