// Computes display values, formulas and rollups for database records, and runs view queries
// (filter, sort, group, aggregate). Values are computed in TypeScript so formulas and rollups
// behave identically everywhere.
import { and, asc, eq, inArray, isNull } from "drizzle-orm";
import type { DBorTx } from "../db";
import { pages, databaseProperties, relationLinks, users } from "../db/schema";
import {
  compile,
  evaluate,
  FormulaError,
  isDate,
  makeDate,
  parseDateString,
  toText,
  type Compiled,
  type FType,
  type FValue,
  type FDate,
} from "@/lib/formula";
import type {
  CellValue,
  DateValue,
  FilterCondition,
  FilterGroup,
  PropertyDef,
  PropertyType,
  QueryGroup,
  QueryRow,
  SelectOption,
  SortSpec,
  ViewConfig,
  Aggregation,
  Color,
  RelativeDate,
} from "@/lib/db-types";

export type RecordRow = {
  id: string;
  title: string;
  icon: string | null;
  cover: string | null;
  properties: Record<string, unknown>;
  position: number;
  createdAt: Date;
  updatedAt: Date;
  createdBy: string | null;
  updatedBy: string | null;
  databaseId: string | null;
  archivedAt: Date | null;
};

export function toPropertyDef(p: typeof databaseProperties.$inferSelect): PropertyDef {
  return { id: p.id, databaseId: p.databaseId, name: p.name, type: p.type as PropertyType, config: (p.config ?? {}) as PropertyDef["config"], position: p.position };
}

export const recordColumns = {
  id: pages.id,
  title: pages.title,
  icon: pages.icon,
  cover: pages.cover,
  properties: pages.properties,
  position: pages.position,
  createdAt: pages.createdAt,
  updatedAt: pages.updatedAt,
  createdBy: pages.createdBy,
  updatedBy: pages.updatedBy,
  databaseId: pages.databaseId,
  archivedAt: pages.archivedAt,
};

/** Type of a property as seen by formulas. */
export function formulaTypeOf(p: PropertyDef): FType {
  switch (p.type) {
    case "number":
      return "number";
    case "unique_id":
      return p.config.prefix ? "text" : "number";
    case "checkbox":
      return "boolean";
    case "date":
    case "created_time":
    case "last_edited_time":
      return "date";
    case "multi_select":
    case "person":
    case "relation":
    case "files":
      return "list";
    case "rollup":
    case "formula":
      return "any";
    default:
      return "text";
  }
}

export function dateValueToF(v: unknown): FDate | null {
  if (!v || typeof v !== "object") return typeof v === "string" ? parseDateString(v) : null;
  const d = v as DateValue;
  const s = parseDateString(d.start);
  if (!s) return null;
  const e = d.end ? parseDateString(d.end) : null;
  return makeDate(s.start, e ? e.start : null, !!d.includeTime);
}

export function fToDateValue(d: FDate): DateValue {
  const fmt = (ms: number) => (d.time ? new Date(ms).toISOString() : new Date(ms).toISOString().slice(0, 10));
  return { start: fmt(d.start), end: d.end != null ? fmt(d.end) : null, includeTime: d.time };
}

export function fToCell(v: FValue): CellValue {
  if (v === null || typeof v === "string" || typeof v === "number" || typeof v === "boolean") return v;
  if (Array.isArray(v)) return { type: "list", items: v.map(fToCell) };
  if (isDate(v)) return fToDateValue(v);
  return null;
}

/**
 * Lazily loads databases and records and computes values with memoisation and cycle detection.
 * One instance per request.
 */
export class Computer {
  private props = new Map<string, PropertyDef[]>(); // databaseId → properties
  private records = new Map<string, RecordRow>();
  private links = new Map<string, Map<string, string[]>>(); // propertyId → fromId → toIds
  private compiled = new Map<string, Compiled | FormulaError>();
  private fmemo = new Map<string, FValue | FormulaError>();
  private inProgress = new Set<string>();
  private userNames = new Map<string, string>();
  now = Date.now();
  /** Optional visibility filter for related records (rollups / relation titles). */
  canView: (id: string) => boolean = () => true;

  constructor(private db: DBorTx) {}

  async loadProps(databaseId: string): Promise<PropertyDef[]> {
    let p = this.props.get(databaseId);
    if (!p) {
      const rows = await this.db.select().from(databaseProperties).where(eq(databaseProperties.databaseId, databaseId)).orderBy(asc(databaseProperties.position));
      p = rows.map(toPropertyDef);
      this.props.set(databaseId, p);
    }
    return p;
  }

  propsOf(databaseId: string) {
    return this.props.get(databaseId) ?? [];
  }

  async loadRecords(databaseId: string, opts: { includeTemplates?: boolean } = {}): Promise<RecordRow[]> {
    const rows = await this.db
      .select(recordColumns)
      .from(pages)
      .where(and(eq(pages.databaseId, databaseId), isNull(pages.archivedAt), eq(pages.isTemplate, opts.includeTemplates ?? false)))
      .orderBy(asc(pages.position), asc(pages.createdAt), asc(pages.id));
    for (const r of rows) this.records.set(r.id, r);
    return rows;
  }

  /** Make records loaded elsewhere (e.g. one page of a SQL query) known to the computer. */
  addRecords(rows: RecordRow[]) {
    for (const r of rows) this.records.set(r.id, r);
  }

  async loadRecordsById(ids: string[]) {
    const missing = ids.filter((id) => !this.records.has(id));
    for (let i = 0; i < missing.length; i += 1000) {
      const rows = await this.db.select(recordColumns).from(pages).where(inArray(pages.id, missing.slice(i, i + 1000)));
      for (const r of rows) this.records.set(r.id, r);
    }
  }

  record(id: string) {
    return this.records.get(id);
  }

  async loadLinks(propertyId: string, fromIds?: string[]) {
    let m = this.links.get(propertyId);
    if (!m) {
      m = new Map();
      this.links.set(propertyId, m);
    }
    const where = fromIds ? and(eq(relationLinks.propertyId, propertyId), inArray(relationLinks.fromPageId, fromIds)) : eq(relationLinks.propertyId, propertyId);
    const chunks = fromIds ? Array.from({ length: Math.ceil(fromIds.length / 1000) }, (_, i) => fromIds.slice(i * 1000, i * 1000 + 1000)) : [null];
    for (const chunk of chunks) {
      const rows = await this.db
        .select({ from: relationLinks.fromPageId, to: relationLinks.toPageId, pos: relationLinks.position })
        .from(relationLinks)
        .where(chunk ? and(eq(relationLinks.propertyId, propertyId), inArray(relationLinks.fromPageId, chunk)) : where)
        .orderBy(asc(relationLinks.position));
      for (const r of rows) {
        const list = m.get(r.from) ?? [];
        list.push(r.to);
        m.set(r.from, list);
      }
    }
    // Mark loaded sources without links.
    for (const id of fromIds ?? []) if (!m.has(id)) m.set(id, []);
  }

  linksOf(propertyId: string, fromId: string): string[] {
    return this.links.get(propertyId)?.get(fromId) ?? [];
  }

  async loadUsers(ids: string[]) {
    const missing = [...new Set(ids)].filter((id) => id && !this.userNames.has(id));
    if (!missing.length) return;
    const rows = await this.db.select({ id: users.id, name: users.name }).from(users).where(inArray(users.id, missing));
    for (const r of rows) this.userNames.set(r.id, r.name);
  }

  userName(id: string | null) {
    return id ? (this.userNames.get(id) ?? "Unknown") : "";
  }

  /**
   * Preload everything needed to compute the given properties for the given records,
   * following relations for rollups (recursively, bounded by depth).
   */
  async prepare(databaseId: string, recordIds: string[], depth = 0, seen = new Set<string>()) {
    const key = `${databaseId}:${depth}`;
    if (seen.has(key) || depth > 4) return;
    seen.add(key);
    const props = await this.loadProps(databaseId);
    const userIds: string[] = [];
    for (const id of recordIds) {
      const r = this.records.get(id);
      if (!r) continue;
      if (r.createdBy) userIds.push(r.createdBy);
      if (r.updatedBy) userIds.push(r.updatedBy);
      for (const p of props) if (p.type === "person" && Array.isArray(r.properties[p.id])) userIds.push(...(r.properties[p.id] as string[]));
    }
    await this.loadUsers(userIds);
    for (const p of props.filter((x) => x.type === "relation")) {
      await this.loadLinks(p.id, recordIds);
      const targets = [...new Set(recordIds.flatMap((id) => this.linksOf(p.id, id)))];
      await this.loadRecordsById(targets);
      const targetDb = p.config.targetDatabaseId;
      if (targetDb) {
        await this.loadProps(targetDb);
        // Recurse only when a rollup reads through this relation.
        const usedByRollup = props.some((r) => r.type === "rollup" && r.config.relationPropertyId === p.id);
        if (usedByRollup) await this.prepare(targetDb, targets, depth + 1, seen);
      }
    }
  }

  private compiledFormula(dbId: string, p: PropertyDef): Compiled | FormulaError {
    const hit = this.compiled.get(p.id);
    if (hit) return hit;
    let result: Compiled | FormulaError;
    try {
      const env: Record<string, FType> = {};
      for (const q of this.propsOf(dbId)) env[q.name] = q.id === p.id ? "any" : formulaTypeOf(q);
      result = compile(p.config.expression ?? "", { props: env });
    } catch (e) {
      result = e instanceof FormulaError ? e : new FormulaError(String((e as Error).message));
    }
    this.compiled.set(p.id, result);
    return result;
  }

  /** Formula-typed value of a property for a record. */
  fvalue(record: RecordRow, p: PropertyDef): FValue {
    const raw = record.properties?.[p.id];
    switch (p.type) {
      case "title":
        return record.title || null;
      case "rich_text":
      case "url":
      case "email":
      case "phone":
        return typeof raw === "string" && raw !== "" ? raw : null;
      case "number":
        return typeof raw === "number" ? raw : null;
      case "select":
      case "status":
        return optionName(p, raw as string) ?? null;
      case "multi_select":
        return Array.isArray(raw) ? (raw as string[]).map((id) => optionName(p, id)).filter((x): x is string => !!x) : [];
      case "date":
        return dateValueToF(raw);
      case "checkbox":
        return raw === true;
      case "person":
        return Array.isArray(raw) ? (raw as string[]).map((u) => this.userName(u)) : [];
      case "files":
        return Array.isArray(raw) ? (raw as { name: string }[]).map((f) => f.name) : [];
      case "relation":
        return this.linksOf(p.id, record.id)
          .filter((id) => this.canView(id))
          .map((id) => this.records.get(id))
          .filter((r): r is RecordRow => !!r && !r.archivedAt)
          .map((r) => r.title);
      case "created_time":
        return makeDate(record.createdAt.getTime(), null, true);
      case "last_edited_time":
        return makeDate(record.updatedAt.getTime(), null, true);
      case "created_by":
        return this.userName(record.createdBy) || null;
      case "last_edited_by":
        return this.userName(record.updatedBy) || null;
      case "unique_id":
        return typeof raw === "number" ? (p.config.prefix ? `${p.config.prefix}-${raw}` : raw) : null;
      case "formula":
      case "rollup": {
        const v = this.computed(record, p);
        if (v instanceof FormulaError) return null;
        return v;
      }
    }
    return null;
  }

  /** Computed value (formula / rollup) with memoisation and cycle detection. */
  computed(record: RecordRow, p: PropertyDef): FValue | FormulaError {
    const key = `${p.id}:${record.id}`;
    const memo = this.fmemo.get(key);
    if (memo !== undefined) return memo;
    if (this.inProgress.has(key)) return new FormulaError("Circular reference between formulas or rollups");
    this.inProgress.add(key);
    let out: FValue | FormulaError;
    try {
      out = p.type === "formula" ? this.evalFormula(record, p) : this.evalRollup(record, p);
    } catch (e) {
      out = e instanceof FormulaError ? e : new FormulaError(String((e as Error).message));
    } finally {
      this.inProgress.delete(key);
    }
    this.fmemo.set(key, out);
    return out;
  }

  private evalFormula(record: RecordRow, p: PropertyDef): FValue | FormulaError {
    if (!(p.config.expression ?? "").trim()) return null;
    const dbId = record.databaseId ?? p.databaseId;
    const c = this.compiledFormula(dbId, p);
    if (c instanceof FormulaError) return c;
    const props = this.propsOf(dbId);
    return evaluate(c, {
      now: this.now,
      recordId: record.id,
      getProp: (name) => {
        const q = props.find((x) => x.name === name) ?? props.find((x) => x.name.toLowerCase() === name.toLowerCase());
        if (!q) return null;
        if (q.type === "formula" || q.type === "rollup") {
          const v = this.computed(record, q);
          if (v instanceof FormulaError) throw new FormulaError(`${q.name}: ${v.message}`);
          return v;
        }
        return this.fvalue(record, q);
      },
    });
  }

  private evalRollup(record: RecordRow, p: PropertyDef): FValue | FormulaError {
    const dbId = record.databaseId ?? p.databaseId;
    const rel = this.propsOf(dbId).find((x) => x.id === p.config.relationPropertyId);
    if (!rel || rel.type !== "relation") return new FormulaError("Rollup relation property is missing");
    const targetDb = rel.config.targetDatabaseId;
    if (!targetDb) return new FormulaError("Rollup relation has no target");
    const targets = this.linksOf(rel.id, record.id)
      .filter((id) => this.canView(id))
      .map((id) => this.records.get(id))
      .filter((r): r is RecordRow => !!r && !r.archivedAt);
    const tp = p.config.targetPropertyId === "title" ? null : this.propsOf(targetDb).find((x) => x.id === p.config.targetPropertyId);
    const values: FValue[] = targets.map((t) => {
      if (!tp) return t.title || null;
      if (tp.type === "formula" || tp.type === "rollup") {
        const v = this.computed(t, tp);
        if (v instanceof FormulaError) throw new FormulaError(`${tp.name}: ${v.message}`);
        return v;
      }
      return this.fvalue(t, tp);
    });
    return applyRollup(p.config.function ?? "show_original", values, targets.length);
  }

  /** Display value of a property for a record. */
  cell(record: RecordRow, p: PropertyDef): CellValue {
    const raw = record.properties?.[p.id];
    switch (p.type) {
      case "title":
        return record.title;
      case "relation":
        return this.linksOf(p.id, record.id).filter((id) => {
          const r = this.records.get(id);
          return !!r && !r.archivedAt && this.canView(id);
        });
      case "created_time":
        return { start: record.createdAt.toISOString(), includeTime: true };
      case "last_edited_time":
        return { start: record.updatedAt.toISOString(), includeTime: true };
      case "created_by":
        return record.createdBy ? [record.createdBy] : [];
      case "last_edited_by":
        return record.updatedBy ? [record.updatedBy] : [];
      case "formula":
      case "rollup": {
        const v = this.computed(record, p);
        if (v instanceof FormulaError) return { type: "error", message: v.message };
        return fToCell(v);
      }
      case "unique_id":
        return typeof raw === "number" ? (p.config.prefix ? `${p.config.prefix}-${raw}` : raw) : null;
      default:
        return (raw ?? null) as CellValue;
    }
  }
}

function optionName(p: PropertyDef, id: unknown): string | undefined {
  if (typeof id !== "string") return undefined;
  return p.config.options?.find((o) => o.id === id)?.name;
}

function nums(values: FValue[]): number[] {
  const out: number[] = [];
  const walk = (v: FValue) => {
    if (Array.isArray(v)) v.forEach(walk);
    else if (typeof v === "number" && Number.isFinite(v)) out.push(v);
  };
  values.forEach(walk);
  return out;
}

function dates(values: FValue[]): FDate[] {
  const out: FDate[] = [];
  const walk = (v: FValue) => {
    if (Array.isArray(v)) v.forEach(walk);
    else if (isDate(v)) out.push(v);
  };
  values.forEach(walk);
  return out;
}

const isEmptyF = (v: FValue) => v === null || v === "" || v === false || (Array.isArray(v) && v.length === 0);

export function applyRollup(fn: string, values: FValue[], count: number): FValue {
  const flat = values.flatMap((v) => (Array.isArray(v) ? v : [v]));
  const ns = nums(values);
  const ds = dates(values);
  switch (fn) {
    case "show_original":
      return flat.filter((v) => v !== null);
    case "count":
      return count;
    case "count_values":
      return flat.filter((v) => !isEmptyF(v)).length;
    case "unique":
      return new Set(flat.filter((v) => !isEmptyF(v)).map((v) => toText(v))).size;
    case "empty":
      return values.filter(isEmptyF).length;
    case "not_empty":
      return values.filter((v) => !isEmptyF(v)).length;
    case "percent_empty":
      return values.length ? Math.round((values.filter(isEmptyF).length / values.length) * 1000) / 10 : 0;
    case "percent_not_empty":
      return values.length ? Math.round((values.filter((v) => !isEmptyF(v)).length / values.length) * 1000) / 10 : 0;
    case "sum":
      return ns.reduce((a, b) => a + b, 0);
    case "average":
      return ns.length ? ns.reduce((a, b) => a + b, 0) / ns.length : null;
    case "median": {
      if (!ns.length) return null;
      const s = [...ns].sort((a, b) => a - b);
      const m = s.length >> 1;
      return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
    }
    case "min":
      return ns.length ? Math.min(...ns) : null;
    case "max":
      return ns.length ? Math.max(...ns) : null;
    case "range":
      return ns.length ? Math.max(...ns) - Math.min(...ns) : null;
    case "earliest":
      return ds.length ? ds.reduce((a, b) => (b.start < a.start ? b : a)) : null;
    case "latest":
      return ds.length ? ds.reduce((a, b) => ((b.end ?? b.start) > (a.end ?? a.start) ? b : a)) : null;
    case "date_range": {
      if (!ds.length) return null;
      const s = Math.min(...ds.map((d) => d.start));
      const e = Math.max(...ds.map((d) => d.end ?? d.start));
      return makeDate(s, e, ds.some((d) => d.time));
    }
    case "checked":
      return flat.filter((v) => v === true).length;
    case "unchecked":
      return flat.filter((v) => v === false).length;
    case "percent_checked":
      return flat.length ? Math.round((flat.filter((v) => v === true).length / flat.length) * 1000) / 10 : 0;
  }
  return null;
}

// ---------------------------------------------------------------- filtering

export function startOfDayUTC(ms: number) {
  const d = new Date(ms);
  return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
}

export function relativeRange(rel: RelativeDate, now: number): [number, number] {
  const day = 86_400_000;
  const today = startOfDayUTC(now);
  const dow = (new Date(today).getUTCDay() + 6) % 7; // Monday = 0
  const d = new Date(today);
  const monthStart = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1);
  const nextMonthStart = Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 1);
  switch (rel) {
    case "today":
      return [today, today + day];
    case "tomorrow":
      return [today + day, today + 2 * day];
    case "yesterday":
      return [today - day, today];
    case "this_week":
      return [today - dow * day, today - dow * day + 7 * day];
    case "past_week":
      return [today - 7 * day, today + day];
    case "next_week":
      return [today, today + 8 * day];
    case "this_month":
      return [monthStart, nextMonthStart];
    case "past_month":
      return [Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - 1, d.getUTCDate()), today + day];
    case "next_month":
      return [today, Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate()) + day];
    case "past_year":
      return [Date.UTC(d.getUTCFullYear() - 1, d.getUTCMonth(), d.getUTCDate()), today + day];
    case "next_year":
      return [today, Date.UTC(d.getUTCFullYear() + 1, d.getUTCMonth(), d.getUTCDate()) + day];
  }
  return [today, today + day];
}

type Accessor = { p: PropertyDef; fv: FValue; cell: CellValue };

function rawIds(cell: CellValue): string[] {
  if (Array.isArray(cell)) return (cell as unknown[]).map((x) => (typeof x === "string" ? x : (x as { name?: string })?.name ?? "")).filter(Boolean);
  if (typeof cell === "string") return [cell];
  return [];
}

export function matchCondition(c: FilterCondition, a: Accessor, now: number): boolean {
  const { p, fv, cell } = a;
  const op = c.operator;
  const empty = fv === null || fv === "" || (Array.isArray(fv) && fv.length === 0);
  if (op === "is_empty") return p.type === "checkbox" ? fv !== true : empty;
  if (op === "is_not_empty") return p.type === "checkbox" ? fv === true : !empty;
  if (op === "is_checked") return fv === true;
  if (op === "is_not_checked") return fv !== true;
  const value = c.value;
  if (value === undefined || value === null || value === "") return true; // incomplete filter matches everything

  // Option-based: compare by option id.
  if (p.type === "select" || p.type === "status") {
    const id = typeof cell === "string" ? cell : null;
    if (op === "equals") return id === value || (Array.isArray(value) && value.includes(id));
    if (op === "not_equals") return id !== value && !(Array.isArray(value) && value.includes(id));
  }
  if (p.type === "multi_select" || p.type === "person" || p.type === "relation" || p.type === "created_by" || p.type === "last_edited_by") {
    const ids = rawIds(cell);
    const wanted = Array.isArray(value) ? (value as string[]) : [String(value)];
    if (op === "contains") return wanted.some((w) => ids.includes(w));
    if (op === "not_contains") return !wanted.some((w) => ids.includes(w));
  }

  if (isDate(fv) || p.type === "date" || p.type === "created_time" || p.type === "last_edited_time" || op === "is_relative" || op === "before" || op === "after" || op === "on_or_before" || op === "on_or_after") {
    if (!isDate(fv)) return false;
    const day = startOfDayUTC(fv.start);
    if (op === "is_relative") {
      const [s, e] = relativeRange(value as RelativeDate, now);
      const end = startOfDayUTC(fv.end ?? fv.start);
      return end >= s && day < e;
    }
    const target = typeof value === "string" ? (Object.hasOwn(RELATIVE_SHORTCUTS, value) ? relativeRange(value as RelativeDate, now)[0] : parseDateString(value)?.start) : undefined;
    if (target == null) return true;
    const t = startOfDayUTC(target);
    switch (op) {
      case "equals":
        return day === t;
      case "not_equals":
        return day !== t;
      case "before":
        return day < t;
      case "after":
        return day > t;
      case "on_or_before":
        return day <= t;
      case "on_or_after":
        return day >= t;
    }
    return true;
  }

  if (typeof fv === "number" || p.type === "number") {
    const n = Number(value);
    if (Number.isNaN(n)) return true;
    if (typeof fv !== "number") return op === "not_equals";
    switch (op) {
      case "equals":
        return fv === n;
      case "not_equals":
        return fv !== n;
      case "gt":
        return fv > n;
      case "lt":
        return fv < n;
      case "gte":
        return fv >= n;
      case "lte":
        return fv <= n;
    }
  }

  const text = toText(fv).toLowerCase();
  const v = String(value).toLowerCase();
  switch (op) {
    case "equals":
      return text === v;
    case "not_equals":
      return text !== v;
    case "contains":
      return text.includes(v);
    case "not_contains":
      return !text.includes(v);
    case "starts_with":
      return text.startsWith(v);
    case "ends_with":
      return text.endsWith(v);
  }
  return true;
}

export const RELATIVE_SHORTCUTS: Record<string, true> = { today: true, tomorrow: true, yesterday: true };

export function matchFilter(f: FilterGroup | FilterCondition, get: (propertyId: string) => Accessor | null, now: number, depth = 0): boolean {
  if (depth > 20) return true;
  if (f.kind === "condition") {
    const a = get(f.propertyId);
    return a ? matchCondition(f, a, now) : true;
  }
  if (!f.filters?.length) return true;
  return f.op === "or" ? f.filters.some((x) => matchFilter(x, get, now, depth + 1)) : f.filters.every((x) => matchFilter(x, get, now, depth + 1));
}

// ---------------------------------------------------------------- sorting

export function sortKey(a: Accessor): number | string | null {
  const { p, fv, cell } = a;
  if (p.type === "select" || p.type === "status") {
    const idx = p.config.options?.findIndex((o) => o.id === cell) ?? -1;
    return idx < 0 ? null : idx;
  }
  if (p.type === "multi_select") {
    const ids = rawIds(cell);
    if (!ids.length) return null;
    return Math.min(...ids.map((id) => p.config.options?.findIndex((o) => o.id === id) ?? 999));
  }
  if (fv === null || fv === "" || (Array.isArray(fv) && !fv.length)) return null;
  if (typeof fv === "number") return fv;
  if (typeof fv === "boolean") return fv ? 1 : 0;
  if (isDate(fv)) return fv.start;
  return toText(fv).toLowerCase();
}

export function compareKeys(x: number | string | null, y: number | string | null): number {
  if (x === null && y === null) return 0;
  if (x === null) return 1; // empty values last regardless of direction
  if (y === null) return -1;
  if (typeof x === "number" && typeof y === "number") return x - y;
  return String(x).localeCompare(String(y), undefined, { numeric: true, sensitivity: "base" });
}

// ---------------------------------------------------------------- aggregation

export function aggregate(kind: Aggregation, accessors: Accessor[]): CellValue {
  const fvs = accessors.map((a) => a.fv);
  const isEmpty = (v: FValue) => v === null || v === "" || (Array.isArray(v) && !v.length);
  const n = accessors.length;
  switch (kind) {
    case "none":
      return null;
    case "count":
      return n;
    case "count_values":
      return fvs.flatMap((v) => (Array.isArray(v) ? v : [v])).filter((v) => !isEmpty(v)).length;
    case "unique":
      return new Set(fvs.filter((v) => !isEmpty(v)).map((v) => toText(v))).size;
    case "empty":
      return fvs.filter(isEmpty).length;
    case "not_empty":
      return fvs.filter((v) => !isEmpty(v)).length;
    case "percent_empty":
      return n ? Math.round((fvs.filter(isEmpty).length / n) * 1000) / 10 : 0;
    case "percent_not_empty":
      return n ? Math.round((fvs.filter((v) => !isEmpty(v)).length / n) * 1000) / 10 : 0;
    case "checked":
      return fvs.filter((v) => v === true).length;
    case "unchecked":
      return fvs.filter((v) => v !== true).length;
    case "percent_checked":
      return n ? Math.round((fvs.filter((v) => v === true).length / n) * 1000) / 10 : 0;
    default: {
      const r = applyRollup(kind, fvs, n);
      return fToCell(r);
    }
  }
}

// ---------------------------------------------------------------- grouping

const NO_VALUE = "__empty__";

export function groupKeys(a: Accessor): { key: string; label: string; color: Color }[] {
  const { p, fv, cell } = a;
  switch (p.type) {
    case "select":
    case "status": {
      const opt = p.config.options?.find((o) => o.id === cell);
      return opt ? [{ key: opt.id, label: opt.name, color: opt.color }] : [{ key: NO_VALUE, label: `No ${p.name}`, color: "default" }];
    }
    case "multi_select": {
      const ids = rawIds(cell);
      const opts = ids.map((id) => p.config.options?.find((o) => o.id === id)).filter((o): o is SelectOption => !!o);
      return opts.length ? opts.map((o) => ({ key: o.id, label: o.name, color: o.color })) : [{ key: NO_VALUE, label: `No ${p.name}`, color: "default" }];
    }
    case "checkbox":
      return [fv === true ? { key: "true", label: "Checked", color: "green" } : { key: "false", label: "Unchecked", color: "default" }];
    case "person":
    case "relation":
    case "created_by":
    case "last_edited_by": {
      const ids = rawIds(cell);
      return ids.length ? ids.map((id) => ({ key: id, label: id, color: "default" as Color })) : [{ key: NO_VALUE, label: `No ${p.name}`, color: "default" }];
    }
    default: {
      if (isDate(fv)) {
        const d = new Date(fv.start);
        const key = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
        return [{ key, label: d.toLocaleString("en", { month: "long", year: "numeric", timeZone: "UTC" }), color: "default" }];
      }
      const t = toText(fv);
      return t ? [{ key: t, label: t, color: "default" }] : [{ key: NO_VALUE, label: `No ${p.name}`, color: "default" }];
    }
  }
}

export function groupOrder(p: PropertyDef, keys: string[]): string[] {
  if (p.type === "select" || p.type === "status" || p.type === "multi_select") {
    const order = (p.config.options ?? []).map((o) => o.id);
    return [NO_VALUE, ...order, ...keys.filter((k) => k !== NO_VALUE && !order.includes(k))];
  }
  if (p.type === "checkbox") return ["false", "true"];
  return [...keys].sort((a, b) => (a === NO_VALUE ? -1 : b === NO_VALUE ? 1 : a.localeCompare(b, undefined, { numeric: true })));
}

// ---------------------------------------------------------------- query

/** Which rows to return: a slice of the result, or of one group (rows of other groups omitted). */
export interface QueryWindow {
  offset: number;
  limit: number;
  /** For grouped views: rows returned per group (first page of every group). */
  groupLimit?: number;
  /** Load more rows of this group only (uses offset/limit within the group). */
  groupKey?: string;
}

export interface RunQueryInput {
  props: PropertyDef[];
  records: RecordRow[];
  computer: Computer;
  config: ViewConfig;
  search?: string | null;
  now?: number;
  window?: QueryWindow;
}

/** A query's complete outcome: every matching id in order, full groups and aggregations. */
export interface EvaluatedQuery {
  total: number;
  matched: number;
  ids: string[];
  groups: QueryGroup[] | null;
  aggregations: Record<string, CellValue>;
}

/** The ids (and groups) of one window of an evaluated query. */
export function pageOf(q: EvaluatedQuery, window?: QueryWindow): { ids: string[]; groups: QueryGroup[] | null; offset: number; hasMore: boolean } {
  if (!window) return { ids: q.ids, groups: q.groups, offset: 0, hasMore: false };
  if (q.groups) {
    // The first rows of every group, or more rows of one group.
    const visible = new Set<string>();
    const groups = (window.groupKey != null ? q.groups.filter((g) => g.key === window.groupKey) : q.groups).map((g) => {
      const rowIds = window.groupKey != null ? g.rowIds.slice(window.offset, window.offset + window.limit) : g.rowIds.slice(0, window.groupLimit ?? window.limit);
      rowIds.forEach((id) => visible.add(id));
      return { ...g, rowIds };
    });
    return { ids: [...visible], groups, offset: window.offset, hasMore: false };
  }
  const ids = q.ids.slice(window.offset, window.offset + window.limit);
  return { ids, groups: null, offset: window.offset, hasMore: window.offset + ids.length < q.ids.length };
}

export function runQuery(input: RunQueryInput) {
  const { evaluated, rowFor } = evaluateQuery(input);
  const page = pageOf(evaluated, input.window);
  return { rows: page.ids.map(rowFor), total: evaluated.total, matched: evaluated.matched, offset: page.offset, hasMore: page.hasMore, groups: page.groups, aggregations: evaluated.aggregations };
}

/** Filter, search, sort, group and aggregate; rowFor() builds a row's cells on demand. */
export function evaluateQuery({ props, records, computer, config, search, now = Date.now() }: RunQueryInput) {
  const byId = new Map(props.map((p) => [p.id, p]));
  const accessorCache = new Map<string, Accessor>();
  const acc = (r: RecordRow, propertyId: string): Accessor | null => {
    const key = `${r.id}:${propertyId}`;
    const hit = accessorCache.get(key);
    if (hit) return hit;
    const p = propertyId === "title" ? props.find((x) => x.type === "title") : byId.get(propertyId);
    if (!p) return null;
    const a = { p, fv: computer.fvalue(r, p), cell: computer.cell(r, p) };
    accessorCache.set(key, a);
    return a;
  };

  let rows = records;
  if (config.filter) rows = rows.filter((r) => matchFilter(config.filter!, (pid) => acc(r, pid), now));
  const needle = search?.trim().toLowerCase();
  if (needle) {
    const textProps = props.filter((p) => ["title", "rich_text", "url", "email", "phone", "select", "multi_select", "status", "formula", "unique_id"].includes(p.type));
    rows = rows.filter((r) => textProps.some((p) => toText(acc(r, p.id)!.fv).toLowerCase().includes(needle)));
  }

  const sorts = (config.sorts ?? []).filter((s) => s.propertyId === "title" || byId.has(s.propertyId));
  if (sorts.length) {
    rows = [...rows].sort((a, b) => {
      for (const s of sorts) {
        const ka = sortKey(acc(a, s.propertyId)!);
        const kb = sortKey(acc(b, s.propertyId)!);
        if (ka === null || kb === null) {
          const c = compareKeys(ka, kb);
          if (c) return c;
          continue;
        }
        const c = compareKeys(ka, kb) * (s.direction === "desc" ? -1 : 1);
        if (c) return c;
      }
      return a.position - b.position;
    });
  } else if (config.manualOrder?.length) {
    const idx = new Map(config.manualOrder.map((id, i) => [id, i]));
    rows = [...rows].sort((a, b) => (idx.get(a.id) ?? Infinity) - (idx.get(b.id) ?? Infinity) || a.position - b.position);
  }

  const toRow = (r: RecordRow): QueryRow => ({
    id: r.id,
    title: r.title,
    icon: r.icon,
    cover: r.cover,
    values: Object.fromEntries(shown.map((p) => [p.id, acc(r, p.id)!.cell])),
    createdAt: r.createdAt.toISOString(),
    updatedAt: r.updatedAt.toISOString(),
    createdBy: r.createdBy,
    updatedBy: r.updatedBy,
  });
  const shown = props;

  const aggs = config.aggregations ?? {};
  const aggregateRows = (list: RecordRow[]) =>
    Object.fromEntries(
      Object.entries(aggs)
        .filter(([pid, kind]) => kind !== "none" && (pid === "title" || byId.has(pid)))
        .map(([pid, kind]) => [pid, aggregate(kind, list.map((r) => acc(r, pid)!))]),
    );

  let groups: QueryGroup[] | null = null;
  const gp = config.groupBy ? (config.groupBy === "title" ? props.find((p) => p.type === "title") : byId.get(config.groupBy)) : null;
  if (gp) {
    const map = new Map<string, { label: string; color: Color; rows: RecordRow[] }>();
    for (const r of rows) {
      for (const k of groupKeys(acc(r, gp.id)!)) {
        const g = map.get(k.key) ?? { label: k.label, color: k.color, rows: [] };
        g.rows.push(r);
        map.set(k.key, g);
      }
    }
    // Option-based properties show every option as a column even when empty (boards).
    if (gp.type === "select" || gp.type === "status" || gp.type === "multi_select") {
      for (const o of gp.config.options ?? []) if (!map.has(o.id)) map.set(o.id, { label: o.name, color: o.color, rows: [] });
      if (!map.has(NO_VALUE)) map.set(NO_VALUE, { label: `No ${gp.name}`, color: "default", rows: [] });
    }
    if (gp.type === "checkbox") {
      if (!map.has("true")) map.set("true", { label: "Checked", color: "green", rows: [] });
      if (!map.has("false")) map.set("false", { label: "Unchecked", color: "default", rows: [] });
    }
    const order = groupOrder(gp, [...map.keys()]).filter((k, i, arr) => map.has(k) && arr.indexOf(k) === i);
    groups = order
      .map((key) => {
        const g = map.get(key)!;
        return { key, label: g.label, color: g.color, rowIds: g.rows.map((r) => r.id), count: g.rows.length, aggregations: aggregateRows(g.rows) };
      })
      .filter((g) => !(config.hideEmptyGroups && g.rowIds.length === 0));
  }

  const byRecord = new Map(records.map((r) => [r.id, r]));
  const evaluated: EvaluatedQuery = { total: records.length, matched: rows.length, ids: rows.map((r) => r.id), groups, aggregations: aggregateRows(rows) };
  return { evaluated, rowFor: (id: string) => toRow(byRecord.get(id)!) };
}

export type { SortSpec };
