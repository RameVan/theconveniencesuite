import { and, asc, eq, inArray, isNull, max, sql, desc } from "drizzle-orm";
import { z } from "zod";
import type { DB, DBorTx } from "../db";
import { pages, databaseProperties, databaseViews, relationLinks, workspaceMembers, users, pagePermissions } from "../db/schema";
import { newId } from "../crypto";
import { badRequest, notFound } from "../errors";
import type { Actor } from "./auth";
import { AccessResolver, requirePage } from "./permissions";
import { Computer, runQuery, evaluateQuery, pageOf, toPropertyDef, formulaTypeOf, recordColumns, type RecordRow, type QueryWindow, type EvaluatedQuery } from "./compute";
import { queryCacheKey, recordsFingerprint, getCachedQuery, setCachedQuery } from "./query-cache";
import { sqlPlan, dateValueCanonical } from "./query-sql";
import { defaultViewConfig } from "@/lib/db-types";
export { defaultViewConfig };
import { maybeSnapshot } from "./revisions";
import { compile, FormulaError, renamePropInSource, parseDateString, toText, type FType } from "@/lib/formula";
import {
  PROPERTY_TYPES,
  READONLY_TYPES,
  VIEW_TYPES,
  COLORS,
  ROLLUP_FUNCTIONS,
  type PropertyDef,
  type PropertyType,
  type SelectOption,
  type ViewConfig,
  type ViewDef,
  type QueryResult,
  type QueryRow,
  type CellValue,
  type Color,
  type DateValue,
} from "@/lib/db-types";
import { safeUrl } from "@/lib/blocks";

// ---------------------------------------------------------------- helpers

const DEFAULT_STATUS_OPTIONS = (): { options: SelectOption[]; groups: { id: string; name: string; color: Color; optionIds: string[] }[] } => {
  const todo = { id: newId(), name: "Not started", color: "gray" as Color };
  const doing = { id: newId(), name: "In progress", color: "blue" as Color };
  const done = { id: newId(), name: "Done", color: "green" as Color };
  return {
    options: [todo, doing, done],
    groups: [
      { id: newId(), name: "To-do", color: "gray", optionIds: [todo.id] },
      { id: newId(), name: "In progress", color: "blue", optionIds: [doing.id] },
      { id: newId(), name: "Complete", color: "green", optionIds: [done.id] },
    ],
  };
};


/** Create the default schema of a new database. */
export async function initDatabase(t: DBorTx, databaseId: string, opts: { withStatus?: boolean } = {}) {
  const titleProp = { id: newId(), databaseId, name: "Name", type: "title", config: {}, position: 0 };
  const tags = { id: newId(), databaseId, name: "Tags", type: "multi_select", config: { options: [] }, position: 1 };
  const props = [titleProp, tags];
  if (opts.withStatus) props.push({ id: newId(), databaseId, name: "Status", type: "status", config: DEFAULT_STATUS_OPTIONS(), position: 2 });
  await t.insert(databaseProperties).values(props);
  const defs = props.map((p) => ({ ...p, type: p.type as PropertyType, config: p.config as PropertyDef["config"] }));
  await t.insert(databaseViews).values({ id: newId(), databaseId, name: "Table", type: "table", config: defaultViewConfig("table", defs) as Record<string, unknown>, position: 0 });
}

export async function loadDatabaseMeta(db: DBorTx, databaseId: string) {
  const props = await db.select().from(databaseProperties).where(eq(databaseProperties.databaseId, databaseId)).orderBy(asc(databaseProperties.position));
  const views = await db.select().from(databaseViews).where(eq(databaseViews.databaseId, databaseId)).orderBy(asc(databaseViews.position));
  const templates = await db
    .select({ id: pages.id, title: pages.title, icon: pages.icon })
    .from(pages)
    .where(and(eq(pages.databaseId, databaseId), eq(pages.isTemplate, true), isNull(pages.archivedAt)))
    .orderBy(asc(pages.position));
  const [dbPage] = await db.select({ properties: pages.properties, title: pages.title, icon: pages.icon, workspaceId: pages.workspaceId, parentId: pages.parentId }).from(pages).where(eq(pages.id, databaseId));
  return {
    id: databaseId,
    title: dbPage?.title ?? "",
    icon: dbPage?.icon ?? null,
    workspaceId: dbPage?.workspaceId,
    parentId: dbPage?.parentId ?? null,
    properties: props.map(toPropertyDef),
    views: views.map((v) => ({ id: v.id, databaseId: v.databaseId, name: v.name, type: v.type as ViewDef["type"], config: v.config as ViewConfig, position: v.position })),
    templates,
    defaultTemplateId: ((dbPage?.properties ?? {}) as Record<string, unknown>).defaultTemplateId ?? null,
  };
}

async function requireDatabase(db: DBorTx, actor: Actor, databaseId: string, min: "view" | "edit" | "full") {
  const pa = await requirePage(db, actor, databaseId, min);
  if (pa.node.kind !== "database") throw notFound("Database not found");
  return pa;
}

export async function getDatabase(db: DB, actor: Actor, databaseId: string) {
  const pa = await requireDatabase(db, actor, databaseId, "view");
  return { ...(await loadDatabaseMeta(db, databaseId)), access: pa.access };
}

async function getPropertyRow(db: DBorTx, propertyId: string) {
  const [p] = await db.select().from(databaseProperties).where(eq(databaseProperties.id, propertyId));
  if (!p) throw notFound("Property not found");
  return toPropertyDef(p);
}

const optionSchema = z.object({ id: z.string().min(1).max(100), name: z.string().trim().min(1).max(200), color: z.enum(COLORS) });
const configSchema = z
  .object({
    options: z.array(optionSchema).max(10_000).optional(),
    groups: z.array(z.object({ id: z.string().max(100), name: z.string().max(200), color: z.enum(COLORS), optionIds: z.array(z.string().max(100)) })).optional(),
    format: z.enum(["number", "number_commas", "percent", "dollar", "euro", "pound", "yen", "rupee"]).optional(),
    precision: z.number().int().min(0).max(10).optional(),
    includeTime: z.boolean().optional(),
    dateFormat: z.enum(["relative", "full", "short", "iso"]).optional(),
    targetDatabaseId: z.string().max(100).optional(),
    syncedPropertyId: z.string().max(100).nullable().optional(),
    limit: z.number().int().min(1).nullable().optional(),
    relationPropertyId: z.string().max(100).optional(),
    targetPropertyId: z.string().max(100).optional(),
    function: z.enum(ROLLUP_FUNCTIONS).optional(),
    expression: z.string().max(20_000).optional(),
    prefix: z.string().max(20).optional(),
  })
  .strict();

// ---------------------------------------------------------------- formula validation

function checkFormulas(props: PropertyDef[]) {
  // Compile every formula against the schema and detect dependency cycles.
  const env: Record<string, FType> = {};
  for (const p of props) env[p.name] = formulaTypeOf(p);
  const deps = new Map<string, string[]>();
  for (const p of props.filter((x) => x.type === "formula")) {
    // An empty formula is allowed (new properties start empty) and yields empty values.
    if (!(p.config.expression ?? "").trim()) continue;
    const c = compile(p.config.expression ?? "", { props: { ...env, [p.name]: "any" } });
    deps.set(
      p.name,
      c.refs.filter((r) => props.find((q) => q.name === r)?.type === "formula"),
    );
  }
  const state = new Map<string, 1 | 2>();
  const visit = (name: string, path: string[]) => {
    if (state.get(name) === 2) return;
    if (state.get(name) === 1) throw new FormulaError(`Circular reference: ${[...path, name].join(" → ")}`);
    state.set(name, 1);
    for (const d of deps.get(name) ?? []) visit(d, [...path, name]);
    state.set(name, 2);
  };
  for (const name of deps.keys()) visit(name, []);
}

// ---------------------------------------------------------------- properties

export const addPropertyInput = z.object({
  name: z.string().trim().min(1).max(200),
  type: z.enum(PROPERTY_TYPES),
  config: z.record(z.string(), z.unknown()).optional(),
  twoWay: z.boolean().optional(),
  syncedName: z.string().trim().min(1).max(200).optional(),
  index: z.number().int().min(0).optional(),
});

export async function addProperty(db: DB, actor: Actor, databaseId: string, input: z.infer<typeof addPropertyInput>) {
  const data = addPropertyInput.parse(input);
  const pa = await requireDatabase(db, actor, databaseId, "edit");
  if (data.type === "title") throw badRequest("A database has exactly one title property");
  const config: PropertyDef["config"] = configSchema.parse(data.config ?? {});
  return db.transaction(async (tx) => {
    const existing = (await tx.select().from(databaseProperties).where(eq(databaseProperties.databaseId, databaseId)).orderBy(asc(databaseProperties.position))).map(toPropertyDef);
    const name = uniqueName(data.name, existing.map((p) => p.name));
    const id = newId();
    if (data.type === "status" && !config.options) Object.assign(config, DEFAULT_STATUS_OPTIONS());
    if ((data.type === "select" || data.type === "multi_select") && !config.options) config.options = [];
    if (data.type === "formula") config.expression ??= "";
    if (data.type === "rollup") {
      config.function ??= "show_original";
      await validateRollup(tx, existing, config);
    }
    if (data.type === "relation") {
      if (!config.targetDatabaseId) throw badRequest("Choose the database to relate to");
      const target = await requireDatabase(tx, actor, config.targetDatabaseId, "view");
      if (target.node.workspaceId !== pa.node.workspaceId) throw badRequest("Relations must stay within one workspace");
      config.syncedPropertyId = null;
    }
    if (data.type === "unique_id") config.nextId = 1;
    const position = data.index != null && data.index < existing.length ? (data.index === 0 ? existing[0].position - 1 : (existing[data.index - 1].position + existing[data.index].position) / 2) : (existing.at(-1)?.position ?? 0) + 1;
    const def: PropertyDef = { id, databaseId, name, type: data.type, config, position };
    if (data.type === "formula") checkFormulas([...existing, def]);
    await tx.insert(databaseProperties).values({ id, databaseId, name, type: data.type, config: config as Record<string, unknown>, position });

    if (data.type === "relation" && data.twoWay && config.targetDatabaseId) {
      const syncedId = newId();
      const targetProps = await tx.select({ name: databaseProperties.name, position: databaseProperties.position }).from(databaseProperties).where(eq(databaseProperties.databaseId, config.targetDatabaseId));
      const [src] = await tx.select({ title: pages.title }).from(pages).where(eq(pages.id, databaseId));
      const syncedName = uniqueName(data.syncedName ?? `Related to ${src?.title || "Untitled"}`, [...targetProps.map((p) => p.name), ...(config.targetDatabaseId === databaseId ? [name] : [])]);
      await tx.insert(databaseProperties).values({
        id: syncedId,
        databaseId: config.targetDatabaseId,
        name: syncedName,
        type: "relation",
        config: { targetDatabaseId: databaseId, syncedPropertyId: id },
        position: Math.max(0, ...targetProps.map((p) => p.position)) + 1,
      });
      await tx.update(databaseProperties).set({ config: { ...config, syncedPropertyId: syncedId } }).where(eq(databaseProperties.id, id));
      await addToViews(tx, config.targetDatabaseId, syncedId);
    }
    if (data.type === "unique_id") {
      // Number existing records in creation order.
      const recs = await tx.select({ id: pages.id }).from(pages).where(eq(pages.databaseId, databaseId)).orderBy(asc(pages.createdAt), asc(pages.position));
      for (let i = 0; i < recs.length; i++) {
        await tx.update(pages).set({ properties: sql`jsonb_set(${pages.properties}, ${`{${id}}`}::text[], ${String(i + 1)}::jsonb)` }).where(eq(pages.id, recs[i].id));
      }
      await tx.update(databaseProperties).set({ config: { ...config, nextId: recs.length + 1 } }).where(eq(databaseProperties.id, id));
    }
    await addToViews(tx, databaseId, id);
    return getPropertyRow(tx, id);
  });
}

async function addToViews(tx: DBorTx, databaseId: string, propertyId: string) {
  const views = await tx.select().from(databaseViews).where(eq(databaseViews.databaseId, databaseId));
  for (const v of views) {
    const cfg = v.config as ViewConfig;
    if (v.type === "table" && cfg.visibleProperties && !cfg.visibleProperties.includes(propertyId)) {
      await tx.update(databaseViews).set({ config: { ...cfg, visibleProperties: [...cfg.visibleProperties, propertyId] } }).where(eq(databaseViews.id, v.id));
    }
  }
}

function uniqueName(name: string, taken: string[]) {
  const lower = new Set(taken.map((t) => t.toLowerCase()));
  if (!lower.has(name.toLowerCase())) return name;
  for (let i = 2; ; i++) if (!lower.has(`${name} ${i}`.toLowerCase())) return `${name} ${i}`;
}

async function validateRollup(tx: DBorTx, props: PropertyDef[], config: PropertyDef["config"]) {
  if (!config.relationPropertyId) return; // configured later in the UI
  const rel = props.find((p) => p.id === config.relationPropertyId);
  if (!rel || rel.type !== "relation") throw badRequest("Rollups must use a relation property of this database");
  if (config.targetPropertyId && config.targetPropertyId !== "title") {
    const [tp] = await tx.select({ id: databaseProperties.id }).from(databaseProperties).where(and(eq(databaseProperties.id, config.targetPropertyId), eq(databaseProperties.databaseId, rel.config.targetDatabaseId ?? "")));
    if (!tp) throw badRequest("The rollup property does not belong to the related database");
  }
}

export const updatePropertyInput = z.object({
  name: z.string().trim().min(1).max(200).optional(),
  type: z.enum(PROPERTY_TYPES).optional(),
  config: z.record(z.string(), z.unknown()).optional(),
  position: z.number().optional(),
});

export async function updateProperty(db: DB, actor: Actor, propertyId: string, input: z.infer<typeof updatePropertyInput>) {
  const data = updatePropertyInput.parse(input);
  const prop = await getPropertyRow(db, propertyId);
  await requireDatabase(db, actor, prop.databaseId, "edit");
  return db.transaction(async (tx) => {
    const all = (await tx.select().from(databaseProperties).where(eq(databaseProperties.databaseId, prop.databaseId))).map(toPropertyDef);
    const next: PropertyDef = { ...prop };
    if (data.name && data.name !== prop.name) {
      next.name = uniqueName(data.name, all.filter((p) => p.id !== prop.id).map((p) => p.name));
      // Keep formulas working: rewrite prop("Old") references.
      for (const f of all.filter((p) => p.type === "formula" && p.id !== prop.id)) {
        const expr = renamePropInSource(f.config.expression ?? "", prop.name, next.name);
        if (expr !== f.config.expression) await tx.update(databaseProperties).set({ config: { ...f.config, expression: expr } }).where(eq(databaseProperties.id, f.id));
      }
    }
    if (data.config) {
      const patch = configSchema.partial().parse(data.config);
      next.config = { ...prop.config, ...patch };
      if (prop.type === "relation" && patch.targetDatabaseId && patch.targetDatabaseId !== prop.config.targetDatabaseId) {
        throw badRequest("Create a new relation property to relate to a different database");
      }
      if (prop.type === "rollup" || data.type === "rollup") await validateRollup(tx, all, next.config);
      if ((prop.type === "select" || prop.type === "multi_select" || prop.type === "status") && patch.options) {
        // Values referring to deleted options are removed.
        const keep = new Set(patch.options.map((o) => o.id));
        const removed = (prop.config.options ?? []).filter((o) => !keep.has(o.id)).map((o) => o.id);
        if (removed.length) await removeOptionValues(tx, prop, removed);
        if (prop.type === "status" && next.config.groups) {
          const known = new Set(patch.options.map((o) => o.id));
          next.config.groups = next.config.groups.map((g) => ({ ...g, optionIds: g.optionIds.filter((id) => known.has(id)) }));
          const grouped = new Set(next.config.groups.flatMap((g) => g.optionIds));
          const orphan = patch.options.filter((o) => !grouped.has(o.id)).map((o) => o.id);
          if (orphan.length && next.config.groups[0]) next.config.groups[0].optionIds.push(...orphan);
        }
      }
    }
    if (data.type && data.type !== prop.type) {
      if (prop.type === "title" || data.type === "title") throw badRequest("The title property cannot change type");
      next.type = data.type;
      await convertType(tx, actor, prop, next);
    }
    if (data.position !== undefined) next.position = data.position;
    if (next.type === "formula") checkFormulas(all.map((p) => (p.id === next.id ? next : p)));
    await tx.update(databaseProperties).set({ name: next.name, type: next.type, config: next.config as Record<string, unknown>, position: next.position }).where(eq(databaseProperties.id, propertyId));
    return getPropertyRow(tx, propertyId);
  });
}

async function removeOptionValues(tx: DBorTx, prop: PropertyDef, removed: string[]) {
  const recs = await tx.select({ id: pages.id, properties: pages.properties }).from(pages).where(and(eq(pages.databaseId, prop.databaseId), sql`${pages.properties} ? ${prop.id}`));
  for (const r of recs) {
    const v = r.properties[prop.id];
    let nv: unknown = v;
    if (Array.isArray(v)) nv = v.filter((x) => !removed.includes(x as string));
    else if (typeof v === "string" && removed.includes(v)) nv = null;
    if (nv !== v) await tx.update(pages).set({ properties: { ...r.properties, [prop.id]: nv } }).where(eq(pages.id, r.id));
  }
}

/** Convert stored values when a property changes type. Nothing is lost silently: old values are converted through their text form. */
async function convertType(tx: DBorTx, actor: Actor, from: PropertyDef, to: PropertyDef) {
  const computer = new Computer(tx);
  await computer.loadProps(from.databaseId);
  const recs = await computer.loadRecords(from.databaseId, { includeTemplates: false });
  const tmpl = await tx.select({ id: pages.id }).from(pages).where(and(eq(pages.databaseId, from.databaseId), eq(pages.isTemplate, true)));
  await computer.loadRecordsById(tmpl.map((t) => t.id));
  const all = [...recs, ...tmpl.map((t) => computer.record(t.id)!).filter(Boolean)];
  await computer.prepare(from.databaseId, all.map((r) => r.id));
  if (to.type === "select" || to.type === "multi_select" || to.type === "status") {
    if (!(from.type === "select" || from.type === "multi_select" || from.type === "status")) to.config.options = [];
    if (to.type === "status" && !to.config.groups) {
      const d = DEFAULT_STATUS_OPTIONS();
      to.config.options = to.config.options?.length ? to.config.options : d.options;
      to.config.groups = d.groups.map((g, i) => (i === 0 ? { ...g, optionIds: [...g.optionIds, ...(to.config.options ?? []).map((o) => o.id).filter((id) => !d.options.some((o) => o.id === id))] } : g));
    }
  }
  if (to.type === "formula") to.config.expression ??= "";
  if (to.type === "rollup") to.config.function ??= "show_original";
  if (to.type === "relation") {
    if (!to.config.targetDatabaseId) throw badRequest("Choose the database to relate to");
    to.config.syncedPropertyId = null;
  }
  if (from.type === "relation") {
    // Converting away from a relation drops its links (titles are kept as text where possible).
    if (from.config.syncedPropertyId) await tx.update(databaseProperties).set({ config: sql`${databaseProperties.config} || '{"syncedPropertyId": null}'::jsonb` }).where(eq(databaseProperties.id, from.config.syncedPropertyId));
  }
  const readonly = READONLY_TYPES.has(to.type);
  for (const r of all) {
    const fv = computer.fvalue(r, from);
    const text = toText(fv);
    const props = { ...r.properties };
    delete props[from.id];
    if (!readonly && fv !== null && text !== "") {
      const v = await normalizeValue(tx, to, convertFrom(from, to, fv, text), { workspaceId: null, actor, recordId: r.id, convert: true });
      if (v !== undefined && to.type !== "relation") props[to.id] = v;
    }
    await tx.update(pages).set({ properties: props }).where(eq(pages.id, r.id));
  }
  if (from.type === "relation") await tx.delete(relationLinks).where(eq(relationLinks.propertyId, from.id));
}

function convertFrom(from: PropertyDef, to: PropertyDef, fv: unknown, text: string): unknown {
  if (to.type === "multi_select" && Array.isArray(fv)) return fv.map((x) => toText(x as never));
  if (to.type === "multi_select") return text.split(",").map((s) => s.trim()).filter(Boolean);
  if (to.type === "date" && fv && typeof fv === "object" && (fv as { kind?: string }).kind === "date") {
    const d = fv as { start: number; end: number | null; time: boolean };
    return { start: new Date(d.start).toISOString().slice(0, d.time ? undefined : 10), end: d.end ? new Date(d.end).toISOString().slice(0, d.time ? undefined : 10) : null, includeTime: d.time };
  }
  if (to.type === "checkbox") return typeof fv === "boolean" ? fv : ["true", "yes", "1", "checked", "x", "✓"].includes(text.toLowerCase());
  if (to.type === "number") return typeof fv === "number" ? fv : text;
  if (Array.isArray(fv) && (to.type === "select" || to.type === "status")) return toText(fv[0] as never);
  void from;
  return text;
}

export async function deleteProperty(db: DB, actor: Actor, propertyId: string) {
  const prop = await getPropertyRow(db, propertyId);
  await requireDatabase(db, actor, prop.databaseId, "edit");
  if (prop.type === "title") throw badRequest("The title property cannot be deleted");
  await db.transaction(async (tx) => {
    if (prop.type === "relation" && prop.config.syncedPropertyId) {
      await tx.update(databaseProperties).set({ config: sql`${databaseProperties.config} || '{"syncedPropertyId": null}'::jsonb` }).where(eq(databaseProperties.id, prop.config.syncedPropertyId));
    }
    await tx.delete(databaseProperties).where(eq(databaseProperties.id, propertyId)); // cascades relation links
    await tx.update(pages).set({ properties: sql`${pages.properties} - ${propertyId}` }).where(and(eq(pages.databaseId, prop.databaseId), sql`${pages.properties} ? ${propertyId}`));
    const views = await tx.select().from(databaseViews).where(eq(databaseViews.databaseId, prop.databaseId));
    for (const v of views) {
      const cfg = scrubViewConfig(v.config as ViewConfig, propertyId);
      await tx.update(databaseViews).set({ config: cfg as Record<string, unknown> }).where(eq(databaseViews.id, v.id));
    }
  });
  return { deleted: true };
}

function scrubViewConfig(cfg: ViewConfig, propertyId: string): ViewConfig {
  const out = { ...cfg };
  out.visibleProperties = cfg.visibleProperties?.filter((p) => p !== propertyId);
  out.sorts = cfg.sorts?.filter((s) => s.propertyId !== propertyId);
  if (out.groupBy === propertyId) out.groupBy = null;
  if (out.dateProperty === propertyId) out.dateProperty = null;
  if (out.endDateProperty === propertyId) out.endDateProperty = null;
  if (cfg.aggregations) out.aggregations = Object.fromEntries(Object.entries(cfg.aggregations).filter(([k]) => k !== propertyId));
  const strip = (g: NonNullable<ViewConfig["filter"]>): NonNullable<ViewConfig["filter"]> => ({
    ...g,
    filters: g.filters.filter((f) => f.kind === "group" || f.propertyId !== propertyId).map((f) => (f.kind === "group" ? strip(f) : f)),
  });
  if (cfg.filter) out.filter = strip(cfg.filter);
  return out;
}

// ---------------------------------------------------------------- values

interface NormalizeCtx {
  workspaceId: string | null;
  actor: Actor;
  recordId: string;
  convert?: boolean;
}

/**
 * Validate a value for a property. Returns the value to store (null clears it).
 * Select-like properties accept option ids or names; unknown names create new options.
 */
export async function normalizeValue(tx: DBorTx, prop: PropertyDef, value: unknown, ctx: NormalizeCtx): Promise<unknown> {
  if (value === null || value === undefined) return null;
  const fail = (msg: string): never => {
    throw badRequest(`${prop.name}: ${msg}`);
  };
  switch (prop.type) {
    case "rich_text":
    case "phone":
      if (typeof value !== "string" && typeof value !== "number") fail("expected text");
      return String(value).slice(0, 200_000) || null;
    case "url": {
      const s = String(value).trim();
      if (!s) return null;
      if (!safeUrl(s)) return ctx.convert ? null : fail("enter a valid http(s) URL");
      return s.slice(0, 2000);
    }
    case "email": {
      const s = String(value).trim();
      if (!s) return null;
      if (!/^[^\s@]+@[^\s@]+$/.test(s)) return ctx.convert ? null : fail("enter a valid email address");
      return s.slice(0, 320);
    }
    case "number": {
      if (value === "") return null;
      const n = typeof value === "number" ? value : Number(String(value).replace(/[,\s$€£¥₹%]/g, ""));
      if (!Number.isFinite(n)) return ctx.convert ? null : fail("expected a number");
      return n;
    }
    case "checkbox":
      if (typeof value === "boolean") return value;
      if (ctx.convert) return ["true", "yes", "1", "checked"].includes(String(value).toLowerCase());
      return fail("expected true or false");
    case "date": {
      let d: DateValue;
      if (typeof value === "string") d = { start: value };
      else if (typeof value === "object" && value) d = value as DateValue;
      else return fail("expected a date");
      if (!d.start) return null;
      const s = parseDateString(String(d.start));
      if (!s) return ctx.convert ? null : fail("invalid date");
      const e = d.end ? parseDateString(String(d.end)) : null;
      if (d.end && !e) fail("invalid end date");
      const fmt = (ms: number, time: boolean) => (time ? new Date(ms).toISOString() : new Date(ms).toISOString().slice(0, 10));
      const includeTime = !!d.includeTime;
      return { start: fmt(s.start, includeTime), end: e ? fmt(e.start, includeTime) : null, includeTime };
    }
    case "select":
    case "status": {
      const v = Array.isArray(value) ? value[0] : value;
      if (v === null || v === undefined || v === "") return null;
      return resolveOption(tx, prop, String(v), prop.type === "select" || !!ctx.convert);
    }
    case "multi_select": {
      const list = Array.isArray(value) ? value : String(value).split(",");
      const out: string[] = [];
      for (const v of list) {
        const s = String(v).trim();
        if (!s) continue;
        const id = await resolveOption(tx, prop, s, true);
        if (id && !out.includes(id)) out.push(id);
      }
      return out;
    }
    case "person": {
      const list = (Array.isArray(value) ? value : [value]).map(String);
      if (!list.length) return [];
      const [rec] = await tx.select({ ws: pages.workspaceId }).from(pages).where(eq(pages.id, ctx.recordId));
      const ws = ctx.workspaceId ?? rec?.ws;
      const members = ws ? await tx.select({ id: workspaceMembers.userId }).from(workspaceMembers).where(and(eq(workspaceMembers.workspaceId, ws), inArray(workspaceMembers.userId, list))) : [];
      const ok = new Set(members.map((m) => m.id));
      if (!ctx.convert && list.some((id) => !ok.has(id))) fail("people must be members of this workspace");
      return list.filter((id) => ok.has(id));
    }
    case "files": {
      const list = Array.isArray(value) ? value : [value];
      return z
        .array(z.object({ name: z.string().max(500), url: z.string().max(2000), fileId: z.string().max(100).optional() }))
        .max(500)
        .parse(list)
        .map((f) => ({ ...f, url: safeUrl(f.url) ?? "" }))
        .filter((f) => f.url);
    }
    case "relation":
      return undefined; // stored in relation_links
    default:
      return fail("this property is computed and cannot be edited");
  }
}

async function resolveOption(tx: DBorTx, prop: PropertyDef, v: string, create: boolean): Promise<string | null> {
  const opts = prop.config.options ?? [];
  const byId = opts.find((o) => o.id === v);
  if (byId) return byId.id;
  const byName = opts.find((o) => o.name.toLowerCase() === v.toLowerCase());
  if (byName) return byName.id;
  if (!create) throw badRequest(`${prop.name}: unknown option "${v}"`);
  const color = COLORS[(opts.length % (COLORS.length - 1)) + 1];
  const opt: SelectOption = { id: newId(), name: v.slice(0, 200), color };
  prop.config.options = [...opts, opt];
  if (prop.type === "status" && prop.config.groups?.length) prop.config.groups[0].optionIds.push(opt.id);
  await tx.update(databaseProperties).set({ config: prop.config as Record<string, unknown> }).where(eq(databaseProperties.id, prop.id));
  return opt.id;
}

/** Replace the links of a relation property for one record, keeping a two-way partner in sync. */
export async function setRelationLinksRaw(tx: DBorTx, propertyId: string, fromId: string, toIds: string[]) {
  const prop = await getPropertyRow(tx, propertyId);
  const ids = [...new Set(toIds)];
  const limited = prop.config.limit === 1 ? ids.slice(-1) : ids;
  const old = await tx.select({ to: relationLinks.toPageId }).from(relationLinks).where(and(eq(relationLinks.propertyId, propertyId), eq(relationLinks.fromPageId, fromId)));
  const oldSet = new Set(old.map((o) => o.to));
  const newSet = new Set(limited);
  await tx.delete(relationLinks).where(and(eq(relationLinks.propertyId, propertyId), eq(relationLinks.fromPageId, fromId)));
  for (let i = 0; i < limited.length; i++) await tx.insert(relationLinks).values({ propertyId, fromPageId: fromId, toPageId: limited[i], position: i });
  const synced = prop.config.syncedPropertyId;
  if (synced) {
    for (const removed of [...oldSet].filter((x) => !newSet.has(x))) {
      await tx.delete(relationLinks).where(and(eq(relationLinks.propertyId, synced), eq(relationLinks.fromPageId, removed), eq(relationLinks.toPageId, fromId)));
    }
    for (const added of limited.filter((x) => !oldSet.has(x))) {
      const [{ m }] = await tx.select({ m: max(relationLinks.position) }).from(relationLinks).where(and(eq(relationLinks.propertyId, synced), eq(relationLinks.fromPageId, added)));
      await tx.insert(relationLinks).values({ propertyId: synced, fromPageId: added, toPageId: fromId, position: (m ?? -1) + 1 }).onConflictDoNothing();
    }
  }
}

async function setRelation(tx: DBorTx, actor: Actor, prop: PropertyDef, fromId: string, value: unknown) {
  const ids = (Array.isArray(value) ? value : value ? [value] : []).map(String).slice(0, 10_000);
  const target = prop.config.targetDatabaseId;
  if (ids.length) {
    const rows = await tx.select({ id: pages.id, databaseId: pages.databaseId, ws: pages.workspaceId }).from(pages).where(inArray(pages.id, ids));
    const valid = new Set(rows.filter((r) => r.databaseId === target).map((r) => r.id));
    const bad = ids.find((id) => !valid.has(id));
    if (bad) throw badRequest(`${prop.name}: related records must belong to the target database`);
    // The editor must be able to see the records they link to.
    const resolver = await AccessResolver.load(tx, rows[0].ws, actor.userId);
    if (ids.some((id) => !resolver.canView(id))) throw badRequest(`${prop.name}: record not found`);
  }
  await setRelationLinksRaw(tx, prop.id, fromId, ids);
}

// ---------------------------------------------------------------- records

export const createRecordInput = z.object({
  title: z.string().max(2000).optional(),
  icon: z.string().max(2000).nullable().optional(),
  values: z.record(z.string(), z.unknown()).optional(),
  templateId: z.string().max(100).nullable().optional(),
  isTemplate: z.boolean().optional(),
  afterId: z.string().max(100).nullable().optional(),
});

export async function createRecord(db: DB, actor: Actor, databaseId: string, input: z.infer<typeof createRecordInput>) {
  const data = createRecordInput.parse(input);
  const pa = await requireDatabase(db, actor, databaseId, "edit");
  let recordId: string;
  if (data.templateId) {
    const tmpl = await db.query.pages.findFirst({ where: and(eq(pages.id, data.templateId), eq(pages.databaseId, databaseId)) });
    if (!tmpl?.isTemplate) throw badRequest("Template not found");
    const { duplicatePage } = await import("./pages");
    const copy = await duplicatePage(db, actor, data.templateId, { asTemplateInstance: true, title: data.title ?? tmpl.title });
    recordId = copy.id;
    await db.update(pages).set({ isTemplate: false, position: await nextRecordPosition(db, databaseId) }).where(eq(pages.id, recordId));
    // Copy the template's relation links.
    const links = await db.select().from(relationLinks).where(eq(relationLinks.fromPageId, data.templateId));
    await db.transaction(async (tx) => {
      for (const prop of [...new Set(links.map((l) => l.propertyId))]) {
        await setRelationLinksRaw(tx, prop, recordId, links.filter((l) => l.propertyId === prop).map((l) => l.toPageId));
      }
    });
  } else {
    recordId = newId();
    const position = await nextRecordPosition(db, databaseId);
    await db.insert(pages).values({
      id: recordId,
      workspaceId: pa.node.workspaceId,
      databaseId,
      parentId: null,
      kind: "page",
      title: data.title ?? "",
      icon: data.icon ?? null,
      isTemplate: data.isTemplate ?? false,
      position,
      properties: {},
      createdBy: actor.userId,
      updatedBy: actor.userId,
    });
  }
  await db.transaction(async (tx) => {
    // Unique IDs: atomic counter on the property config.
    const uniq = await tx.select().from(databaseProperties).where(and(eq(databaseProperties.databaseId, databaseId), eq(databaseProperties.type, "unique_id")));
    for (const u of uniq) {
      if (data.isTemplate) continue;
      const res = await tx.execute(sql`UPDATE database_properties SET config = jsonb_set(config, '{nextId}', to_jsonb(coalesce((config->>'nextId')::int, 1) + 1)) WHERE id = ${u.id} RETURNING (config->>'nextId')::int - 1 AS n`);
      const rows = ((res as unknown as { rows: { n: number }[] }).rows ?? res) as { n: number }[];
      await tx.update(pages).set({ properties: sql`jsonb_set(${pages.properties}, ${`{${u.id}}`}::text[], to_jsonb(${rows[0].n}::int))` }).where(eq(pages.id, recordId));
    }
  });
  if (data.values && Object.keys(data.values).length) await updateRecord(db, actor, recordId, { values: data.values });
  return getRecordRow(db, actor, recordId);
}

async function nextRecordPosition(db: DBorTx, databaseId: string) {
  const [{ m }] = await db.select({ m: max(pages.position) }).from(pages).where(eq(pages.databaseId, databaseId));
  return (m ?? 0) + 1;
}

export const updateRecordInput = z.object({
  title: z.string().max(2000).optional(),
  values: z.record(z.string(), z.unknown()).optional(),
});

export async function updateRecord(db: DB, actor: Actor, recordId: string, input: z.infer<typeof updateRecordInput>) {
  const data = updateRecordInput.parse(input);
  const pa = await requirePage(db, actor, recordId, "edit");
  if (!pa.node.databaseId) throw badRequest("This page is not a database record");
  const databaseId = pa.node.databaseId;
  await db.transaction(async (tx) => {
    const [rec] = await tx.select().from(pages).where(eq(pages.id, recordId)).for("update");
    const props = (await tx.select().from(databaseProperties).where(eq(databaseProperties.databaseId, databaseId))).map(toPropertyDef);
    const values = { ...rec.properties };
    let title = rec.title;
    if (data.title !== undefined) title = data.title;
    for (const [key, value] of Object.entries(data.values ?? {})) {
      const prop = props.find((p) => p.id === key) ?? props.find((p) => p.name === key);
      if (!prop) throw badRequest(`Unknown property: ${key}`);
      if (prop.type === "title") {
        title = String(value ?? "").slice(0, 2000);
        continue;
      }
      if (READONLY_TYPES.has(prop.type)) throw badRequest(`${prop.name} is computed and cannot be edited`);
      if (prop.type === "relation") {
        await setRelation(tx, actor, prop, recordId, value);
        continue;
      }
      const v = await normalizeValue(tx, prop, value, { workspaceId: pa.node.workspaceId, actor, recordId });
      if (v === null || (Array.isArray(v) && v.length === 0)) delete values[prop.id];
      else values[prop.id] = v;
    }
    await tx
      .update(pages)
      .set({ title, properties: values, updatedAt: new Date(), updatedBy: actor.userId })
      .where(eq(pages.id, recordId));
  });
  await maybeSnapshot(db, recordId, actor.userId);
  return getRecordRow(db, actor, recordId);
}

/** One record with computed values, as a query row. */
export async function getRecordRow(db: DB, actor: Actor, recordId: string) {
  const pa = await requirePage(db, actor, recordId, "view", { allowArchived: true });
  const databaseId = pa.node.databaseId!;
  const computer = new Computer(db);
  const resolver = await AccessResolver.load(db, pa.node.workspaceId, actor.userId);
  computer.canView = (id) => resolver.canView(id);
  const props = await computer.loadProps(databaseId);
  await computer.loadRecordsById([recordId]);
  await computer.prepare(databaseId, [recordId]);
  const rec = computer.record(recordId)!;
  const result = runQuery({ props, records: [rec], computer, config: {} });
  return { row: result.rows[0], refs: await buildRefs(db, computer, result.rows, props) };
}

export async function recordDetail(db: DB, actor: Actor, page: { id: string; databaseId: string | null }) {
  if (!page.databaseId) return null;
  const meta = await loadDatabaseMeta(db, page.databaseId);
  const dbAccess = await requirePage(db, actor, page.databaseId, "view", { allowArchived: true }).catch(() => null);
  const { row, refs } = await getRecordRow(db, actor, page.id);
  return {
    database: { id: meta.id, title: dbAccess ? meta.title : "Database", icon: meta.icon },
    properties: meta.properties,
    values: row?.values ?? {},
    refs,
  };
}

async function buildRefs(db: DBorTx, computer: Computer, rows: { values: Record<string, CellValue> }[], props: PropertyDef[]) {
  const pageIds = new Set<string>();
  const userIds = new Set<string>();
  for (const r of rows) {
    for (const p of props) {
      const v = r.values[p.id];
      if (!Array.isArray(v)) continue;
      if (p.type === "relation") (v as string[]).forEach((id) => pageIds.add(id));
      if (p.type === "person" || p.type === "created_by" || p.type === "last_edited_by") (v as string[]).forEach((id) => userIds.add(id));
    }
  }
  const pagesMap: Record<string, { title: string; icon: string | null }> = {};
  for (const id of pageIds) {
    const rec = computer.record(id);
    if (rec) pagesMap[id] = { title: rec.title, icon: rec.icon };
  }
  const usersMap: Record<string, { name: string; avatarUrl: string | null }> = {};
  if (userIds.size) {
    const rows2 = await db.select({ id: users.id, name: users.name, avatarUrl: users.avatarUrl }).from(users).where(inArray(users.id, [...userIds]));
    for (const u of rows2) usersMap[u.id] = { name: u.name, avatarUrl: u.avatarUrl };
  }
  return { pages: pagesMap, users: usersMap };
}

/**
 * Move one record before another (or to the end with beforeId = null) in the database's manual
 * order. Only the moved record changes position (between its new neighbours); positions are
 * renumbered only when neighbours share a position.
 */
export async function moveRecord(db: DB, actor: Actor, databaseId: string, recordId: string, beforeId: string | null) {
  await requireDatabase(db, actor, databaseId, "edit");
  if (recordId === beforeId) return;
  await db.transaction(async (tx) => {
    const rec = await tx.query.pages.findFirst({ where: and(eq(pages.id, recordId), eq(pages.databaseId, databaseId)) });
    if (!rec) throw notFound("Record not found");
    const others = and(eq(pages.databaseId, databaseId), sql`${pages.id} <> ${recordId}`);
    let position: number;
    if (!beforeId) {
      const [m] = await tx.select({ m: max(pages.position) }).from(pages).where(others);
      position = (m?.m ?? 0) + 1;
    } else {
      const before = await tx.query.pages.findFirst({ where: and(eq(pages.id, beforeId), eq(pages.databaseId, databaseId)) });
      if (!before) throw notFound("Record not found");
      // The record currently just before "before" in (position, created_at, id) order.
      const [prev] = await tx
        .select({ position: pages.position })
        .from(pages)
        .where(and(others, sql`(${pages.position}, ${pages.createdAt}, ${pages.id}) < (${before.position}, ${before.createdAt}, ${before.id})`))
        .orderBy(desc(pages.position), desc(pages.createdAt), desc(pages.id))
        .limit(1);
      position = prev ? (prev.position + before.position) / 2 : before.position - 1;
      if (prev && !(prev.position < position && position < before.position)) {
        // Neighbours share a position: renumber the whole order once, then place the record.
        const all = await tx.select({ id: pages.id }).from(pages).where(others).orderBy(asc(pages.position), asc(pages.createdAt), asc(pages.id));
        const order = all.map((r) => r.id);
        order.splice(order.indexOf(beforeId), 0, recordId);
        for (let i = 0; i < order.length; i++) await tx.update(pages).set({ position: i + 1 }).where(eq(pages.id, order[i]));
        return;
      }
    }
    await tx.update(pages).set({ position }).where(eq(pages.id, recordId));
  });
}

export async function reorderRecords(db: DB, actor: Actor, databaseId: string, orderedIds: string[]) {
  await requireDatabase(db, actor, databaseId, "edit");
  const ids = z.array(z.string().max(100)).max(100_000).parse(orderedIds);
  await db.transaction(async (tx) => {
    for (let i = 0; i < ids.length; i++) await tx.update(pages).set({ position: i + 1 }).where(and(eq(pages.id, ids[i]), eq(pages.databaseId, databaseId)));
  });
}

// ---------------------------------------------------------------- query

export const queryInput = z.object({
  viewId: z.string().max(100).nullable().optional(),
  config: z.record(z.string(), z.unknown()).nullable().optional(),
  search: z.string().max(500).nullable().optional(),
  includeTemplates: z.boolean().optional(),
  /** Paging: rows [offset, offset + limit) of the result. Without limit, all rows are returned. */
  offset: z.number().int().min(0).max(10_000_000).optional(),
  limit: z.number().int().min(1).max(5_000).optional(),
  /** Grouped views: rows per group in the first page; groupKey loads more of one group. */
  groupLimit: z.number().int().min(1).max(5_000).optional(),
  groupKey: z.string().max(200).optional(),
});

let supportsInputValidation: boolean | null = null;
/**
 * Date conditions run in SQL only when every stored value of those properties has a canonical form
 * (and the server has pg_input_is_valid, PostgreSQL 16+); otherwise the in-memory engine decides.
 */
async function dateValuesCanonical(db: DBorTx, databaseId: string, props: PropertyDef[]) {
  if (!props.length) return true;
  if (supportsInputValidation === null) {
    const res = await db.execute(sql`select current_setting('server_version_num')::int >= 160000 as ok`);
    const rows = ((res as unknown as { rows?: { ok: boolean }[] }).rows ?? res) as { ok: boolean }[];
    supportsInputValidation = !!rows[0]?.ok;
  }
  if (!supportsInputValidation) return false;
  const [row] = await db
    .select({ ok: sql<boolean>`coalesce(bool_and(${sql.join(props.map(dateValueCanonical), sql` and `)}), true)` })
    .from(pages)
    .where(eq(pages.databaseId, databaseId));
  return !!row?.ok;
}

/** True when every record of the database has the database's own access for this user. */
async function uniformRecordAccess(db: DBorTx, actor: Actor, databaseId: string) {
  const [priv] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(pages)
    .where(and(eq(pages.databaseId, databaseId), eq(pages.visibility, "private")));
  if (priv.n > 0) return false;
  const [grants] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(pagePermissions)
    .innerJoin(pages, eq(pages.id, pagePermissions.pageId))
    .where(and(eq(pages.databaseId, databaseId), eq(pagePermissions.userId, actor.userId)));
  return grants.n === 0;
}

export async function queryDatabase(
  db: DB,
  actor: Actor,
  databaseId: string,
  input: z.infer<typeof queryInput>,
  /** "memory" forces the in-memory engine; "sql" fails unless the SQL path is used (tests compare them). */
  opts: { engine?: "auto" | "memory" | "sql" } = {},
): Promise<QueryResult & { refs: Awaited<ReturnType<typeof buildRefs>> }> {
  const data = queryInput.parse(input);
  const pa = await requireDatabase(db, actor, databaseId, "view");
  let config: ViewConfig = {};
  if (data.viewId) {
    const [v] = await db.select().from(databaseViews).where(and(eq(databaseViews.id, data.viewId), eq(databaseViews.databaseId, databaseId)));
    if (!v) throw notFound("View not found");
    config = v.config as ViewConfig;
  }
  if (data.config) config = { ...config, ...(data.config as ViewConfig) };
  const computer = new Computer(db);
  const props = await computer.loadProps(databaseId);
  const window: QueryWindow | undefined = data.limit != null ? { offset: data.offset ?? 0, limit: data.limit, groupLimit: data.groupLimit, groupKey: data.groupKey } : undefined;
  // Relation cells (and formulas or rollups reading through them) hide records the actor can't see,
  // which needs the workspace structure. Without relations, records never reach other pages.
  const needsResolver = props.some((p) => p.type === "relation" || p.type === "rollup");
  const loadResolver = async () => {
    const resolver = await AccessResolver.load(db, pa.node.workspaceId, actor.userId);
    computer.canView = (id) => resolver.canView(id);
    return resolver;
  };

  let result: QueryResult;
  const plan = opts.engine === "memory" ? null : sqlPlan(config, props, data.search);
  const useSql = !!plan && (await uniformRecordAccess(db, actor, databaseId)) && (await dateValuesCanonical(db, databaseId, plan.dateProps));
  if (opts.engine === "sql" && !useSql) throw new Error("This query cannot run in SQL");
  if (plan && useSql) {
    // Filter, sort and page in PostgreSQL; compute cells only for the returned rows.
    if (needsResolver) await loadResolver();
    else computer.canView = () => true;
    const base = and(eq(pages.databaseId, databaseId), isNull(pages.archivedAt), eq(pages.isTemplate, data.includeTemplates ?? false));
    const [counts] = await db
      .select({ total: sql<number>`count(*)::int`, matched: sql<number>`(count(*) filter (where ${plan.where}))::int` })
      .from(pages)
      .where(base);
    const offset = window?.offset ?? 0;
    let q = db.select(recordColumns).from(pages).where(and(base, plan.where)).orderBy(...plan.order).$dynamic();
    if (window) q = q.limit(window.limit).offset(offset);
    const rows = (await q) as RecordRow[];
    computer.addRecords(rows);
    await computer.prepare(databaseId, rows.map((r) => r.id));
    const page = runQuery({ props, records: rows, computer, config: {} });
    result = { rows: page.rows, total: counts.total, matched: counts.matched, offset, hasMore: offset + rows.length < counts.matched, groups: null, aggregations: {}, formulaErrors: {} };
  } else {
    // In memory. Paged requests reuse the evaluated order while the records are unchanged
    // (not for relations/rollups, whose values depend on other databases).
    const uniform = !needsResolver && (await uniformRecordAccess(db, actor, databaseId));
    // Only when every record shares the database access (re-checked per request), so a cached
    // order never outlives a change in who may see which record.
    const cacheKey = window && uniform ? queryCacheKey([databaseId, actor.userId, config, data.search ?? "", !!data.includeTemplates, props]) : null;
    const fingerprint = cacheKey ? await recordsFingerprint(db, databaseId) : "";
    let evaluated: EvaluatedQuery | null = cacheKey ? getCachedQuery(cacheKey, fingerprint) : null;
    let rowFor: ((id: string) => QueryRow) | null = null;
    if (!evaluated) {
      let records: RecordRow[];
      if (uniform) {
        computer.canView = () => true;
        records = await computer.loadRecords(databaseId, { includeTemplates: data.includeTemplates });
      } else {
        const resolver = await loadResolver();
        records = (await computer.loadRecords(databaseId, { includeTemplates: data.includeTemplates })).filter((r) => resolver.canView(r.id));
      }
      await computer.prepare(databaseId, records.map((r) => r.id));
      ({ evaluated, rowFor } = evaluateQuery({ props, records, computer, config, search: data.search }));
      if (cacheKey) setCachedQuery(cacheKey, fingerprint, evaluated);
    }
    const page = pageOf(evaluated, window);
    if (!rowFor) {
      // Cache hit: load and compute only the rows of this page.
      if (uniform) computer.canView = () => true;
      else await loadResolver();
      await computer.loadRecordsById(page.ids);
      await computer.prepare(databaseId, page.ids);
      const pageRecords = page.ids.map((id) => computer.record(id)).filter((r): r is RecordRow => !!r);
      ({ rowFor } = evaluateQuery({ props, records: pageRecords, computer, config: {} }));
    }
    result = { rows: page.ids.map(rowFor!), total: evaluated.total, matched: evaluated.matched, offset: page.offset, hasMore: page.hasMore, groups: page.groups, aggregations: evaluated.aggregations, formulaErrors: {} };
  }
  const refs = await buildRefs(db, computer, result.rows, props);
  // Group labels for person/relation groups.
  if (result.groups) {
    for (const g of result.groups) {
      if (refs.pages[g.key]) g.label = refs.pages[g.key].title || "Untitled";
      else if (refs.users[g.key]) g.label = refs.users[g.key].name;
    }
  }
  return { ...result, refs };
}

/** Records of a database for relation pickers (title search), visible to the actor. */
export async function searchRecords(db: DB, actor: Actor, databaseId: string, q: string, limit = 50) {
  const pa = await requireDatabase(db, actor, databaseId, "view");
  const resolver = await AccessResolver.load(db, pa.node.workspaceId, actor.userId);
  const needle = q.trim();
  const rows = await db
    .select({ id: pages.id, title: pages.title, icon: pages.icon })
    .from(pages)
    .where(and(eq(pages.databaseId, databaseId), isNull(pages.archivedAt), eq(pages.isTemplate, false), needle ? sql`${pages.title} ILIKE ${"%" + needle.replace(/[%_\\]/g, "\\$&") + "%"}` : undefined))
    .orderBy(desc(pages.updatedAt))
    .limit(limit * 3);
  return rows.filter((r) => resolver.canView(r.id)).slice(0, limit);
}

// ---------------------------------------------------------------- views

export const viewInput = z.object({
  name: z.string().trim().min(1).max(200).optional(),
  type: z.enum(VIEW_TYPES).optional(),
  config: z.record(z.string(), z.unknown()).optional(),
  position: z.number().optional(),
});

export async function createView(db: DB, actor: Actor, databaseId: string, input: z.infer<typeof viewInput>) {
  const data = viewInput.parse(input);
  await requireDatabase(db, actor, databaseId, "edit");
  const props = (await db.select().from(databaseProperties).where(eq(databaseProperties.databaseId, databaseId)).orderBy(asc(databaseProperties.position))).map(toPropertyDef);
  const type = data.type ?? "table";
  const [{ m }] = await db.select({ m: max(databaseViews.position) }).from(databaseViews).where(eq(databaseViews.databaseId, databaseId));
  const id = newId();
  const config = { ...defaultViewConfig(type, props), ...((data.config as ViewConfig) ?? {}) };
  const name = data.name ?? type[0].toUpperCase() + type.slice(1);
  await db.insert(databaseViews).values({ id, databaseId, name, type, config: config as Record<string, unknown>, position: data.position ?? (m ?? 0) + 1 });
  return { id, databaseId, name, type, config, position: data.position ?? (m ?? 0) + 1 };
}

async function getViewRow(db: DBorTx, viewId: string) {
  const [v] = await db.select().from(databaseViews).where(eq(databaseViews.id, viewId));
  if (!v) throw notFound("View not found");
  return v;
}

export async function updateView(db: DB, actor: Actor, viewId: string, input: z.infer<typeof viewInput>) {
  const data = viewInput.parse(input);
  const v = await getViewRow(db, viewId);
  await requireDatabase(db, actor, v.databaseId, "edit");
  const patch: Partial<typeof databaseViews.$inferInsert> = {};
  if (data.name) patch.name = data.name;
  if (data.position !== undefined) patch.position = data.position;
  if (data.type && data.type !== v.type) {
    const props = (await db.select().from(databaseProperties).where(eq(databaseProperties.databaseId, v.databaseId))).map(toPropertyDef);
    const defaults = defaultViewConfig(data.type, props);
    const cur = v.config as ViewConfig;
    patch.type = data.type;
    patch.config = { ...defaults, filter: cur.filter, sorts: cur.sorts, ...(data.type === "table" ? { visibleProperties: cur.visibleProperties ?? defaults.visibleProperties } : {}) } as Record<string, unknown>;
  }
  if (data.config) patch.config = { ...((patch.config ?? v.config) as Record<string, unknown>), ...data.config };
  if (JSON.stringify(patch.config ?? {}).length > 1_000_000) throw badRequest("View configuration is too large");
  const [row] = await db.update(databaseViews).set(patch).where(eq(databaseViews.id, viewId)).returning();
  return { id: row.id, databaseId: row.databaseId, name: row.name, type: row.type, config: row.config, position: row.position };
}

export async function deleteView(db: DB, actor: Actor, viewId: string) {
  const v = await getViewRow(db, viewId);
  await requireDatabase(db, actor, v.databaseId, "edit");
  const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(databaseViews).where(eq(databaseViews.databaseId, v.databaseId));
  if (n <= 1) throw badRequest("A database needs at least one view");
  await db.delete(databaseViews).where(eq(databaseViews.id, viewId));
  return { deleted: true };
}

export async function duplicateView(db: DB, actor: Actor, viewId: string) {
  const v = await getViewRow(db, viewId);
  await requireDatabase(db, actor, v.databaseId, "edit");
  const id = newId();
  await db.insert(databaseViews).values({ ...v, id, name: `${v.name} (copy)`, position: v.position + 0.5, createdAt: new Date() });
  return { id };
}

export async function setDefaultTemplate(db: DB, actor: Actor, databaseId: string, templateId: string | null) {
  await requireDatabase(db, actor, databaseId, "edit");
  if (templateId) {
    const t = await db.query.pages.findFirst({ where: and(eq(pages.id, templateId), eq(pages.databaseId, databaseId), eq(pages.isTemplate, true)) });
    if (!t) throw badRequest("Template not found");
  }
  await db.update(pages).set({ properties: sql`jsonb_set(${pages.properties}, '{defaultTemplateId}', ${JSON.stringify(templateId)}::jsonb)` }).where(eq(pages.id, databaseId));
}

export type { RecordRow };
