// Outgoing email (notifications). Optional: without SMTP_URL nothing is sent. Sending happens in
// the background after the in-app notification is stored; failures are logged without content.
import nodemailer, { type Transporter } from "nodemailer";
import { config } from "../config";

let transport: { url: string; t: Transporter } | null = null;
const pending = new Set<Promise<void>>();

export function emailEnabled() {
  return !!config.smtpUrl;
}

function transporter(): Transporter | null {
  const url = config.smtpUrl;
  if (!url) return null;
  if (transport?.url !== url) transport = { url, t: nodemailer.createTransport(url) };
  return transport.t;
}

/** Queue a message; returns immediately. */
export function sendEmail(msg: { to: string; subject: string; text: string; html?: string }) {
  const t = transporter();
  if (!t) return;
  const p = t
    .sendMail({ from: config.smtpFrom, ...msg })
    .then(() => undefined)
    .catch((err: { code?: string; responseCode?: number }) => {
      console.error(`[email] could not send a notification email (${err?.code ?? err?.responseCode ?? "error"})`);
    })
    .finally(() => pending.delete(p));
  pending.add(p);
}

/** Wait until queued messages are handed to the mail server (tests, shutdown). */
export async function flushEmails() {
  while (pending.size) await Promise.all([...pending]);
}
