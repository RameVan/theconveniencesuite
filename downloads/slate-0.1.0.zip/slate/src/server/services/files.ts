import fs from "node:fs";
import path from "node:path";
import { and, eq, inArray, lt, sql } from "drizzle-orm";
import type { DB } from "../db";
import { files, pages, workspaceMembers, pagePermissions } from "../db/schema";
import { newId, sha256 } from "../crypto";
import { config } from "../config";
import { badRequest, notFound, tooLarge } from "../errors";
import type { Actor } from "./auth";
import { getRole, roleAtLeast } from "./permissions";

export interface StorageAdapter {
  put(key: string, data: Buffer, contentType: string): Promise<void>;
  get(key: string): Promise<Buffer>;
  delete(key: string): Promise<void>;
}

class LocalStorage implements StorageAdapter {
  constructor(private root: string) {}
  private resolve(key: string) {
    if (!/^[A-Za-z0-9/_-]+$/.test(key) || key.includes("..")) throw new Error("Invalid storage key");
    const p = path.join(this.root, key);
    if (!p.startsWith(this.root)) throw new Error("Invalid storage key");
    return p;
  }
  async put(key: string, data: Buffer) {
    const p = this.resolve(key);
    await fs.promises.mkdir(path.dirname(p), { recursive: true });
    const tmp = `${p}.tmp-${process.pid}`;
    await fs.promises.writeFile(tmp, data);
    await fs.promises.rename(tmp, p);
  }
  async get(key: string) {
    return fs.promises.readFile(this.resolve(key));
  }
  async delete(key: string) {
    await fs.promises.rm(this.resolve(key), { force: true });
  }
}

class S3Storage implements StorageAdapter {
  private clientPromise: Promise<{ client: import("@aws-sdk/client-s3").S3Client; mod: typeof import("@aws-sdk/client-s3") }>;
  private bucket = process.env.S3_BUCKET || "";
  constructor() {
    if (!this.bucket) throw new Error("STORAGE_DRIVER=s3 requires S3_BUCKET");
    this.clientPromise = import("@aws-sdk/client-s3").then((mod) => ({
      mod,
      client: new mod.S3Client({
        region: process.env.S3_REGION || "us-east-1",
        endpoint: process.env.S3_ENDPOINT || undefined,
        forcePathStyle: process.env.S3_FORCE_PATH_STYLE !== "false",
        credentials: process.env.S3_ACCESS_KEY_ID
          ? { accessKeyId: process.env.S3_ACCESS_KEY_ID, secretAccessKey: process.env.S3_SECRET_ACCESS_KEY || "" }
          : undefined,
      }),
    }));
  }
  async put(key: string, data: Buffer, contentType: string) {
    const { client, mod } = await this.clientPromise;
    await client.send(new mod.PutObjectCommand({ Bucket: this.bucket, Key: key, Body: data, ContentType: contentType }));
  }
  async get(key: string) {
    const { client, mod } = await this.clientPromise;
    const res = await client.send(new mod.GetObjectCommand({ Bucket: this.bucket, Key: key }));
    const bytes = await res.Body!.transformToByteArray();
    return Buffer.from(bytes);
  }
  async delete(key: string) {
    const { client, mod } = await this.clientPromise;
    await client.send(new mod.DeleteObjectCommand({ Bucket: this.bucket, Key: key }));
  }
}

const g = globalThis as unknown as { __slateStorage?: StorageAdapter };
export async function getStorage(): Promise<StorageAdapter> {
  if (!g.__slateStorage) {
    g.__slateStorage = config.storageDriver === "s3" ? new S3Storage() : new LocalStorage(path.join(/* turbopackIgnore: true */ config.dataDir, "uploads"));
  }
  return g.__slateStorage;
}
export function setStorage(s: StorageAdapter) {
  g.__slateStorage = s;
}

/** Detect the real type of common formats from magic bytes; never trust the client's type for rendering. */
export function sniffMime(data: Buffer, claimed: string, name: string): string {
  const b = data;
  if (b.length >= 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return "image/png";
  if (b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "image/jpeg";
  if (b.length >= 6 && b.subarray(0, 6).toString("ascii").startsWith("GIF8")) return "image/gif";
  if (b.length >= 12 && b.subarray(0, 4).toString("ascii") === "RIFF" && b.subarray(8, 12).toString("ascii") === "WEBP") return "image/webp";
  if (b.length >= 5 && b.subarray(0, 5).toString("ascii") === "%PDF-") return "application/pdf";
  if (b.length >= 12 && b.subarray(4, 8).toString("ascii") === "ftyp") return name.toLowerCase().endsWith(".m4a") ? "audio/mp4" : "video/mp4";
  if (b.length >= 4 && b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3) return "video/webm";
  if (b.length >= 3 && b.subarray(0, 3).toString("ascii") === "ID3") return "audio/mpeg";
  if (b.length >= 4 && b.subarray(0, 4).toString("ascii") === "OggS") return "audio/ogg";
  if (b.length >= 12 && b.subarray(0, 4).toString("ascii") === "RIFF" && b.subarray(8, 12).toString("ascii") === "WAVE") return "audio/wav";
  // Everything else is stored with a generic type unless it is plainly harmless text.
  const lower = name.toLowerCase();
  if (/\.(txt|md|csv|log)$/.test(lower)) return "text/plain";
  if (/^[\w.+-]+\/[\w.+-]+$/.test(claimed) && !/html|xml|svg|javascript/i.test(claimed)) return claimed;
  return "application/octet-stream";
}

/** Types that may be displayed inline in the browser. Everything else is downloaded. */
export const INLINE_TYPES = new Set(["image/png", "image/jpeg", "image/gif", "image/webp", "application/pdf", "video/mp4", "video/webm", "audio/mpeg", "audio/ogg", "audio/wav", "audio/mp4", "text/plain"]);

export async function uploadFile(db: DB, actor: Actor, workspaceId: string, file: { name: string; type: string; data: Buffer }) {
  const role = await getRole(db, workspaceId, actor.userId);
  if (!role) {
    // Guests with edit access somewhere in the workspace may upload.
    const [g2] = await db
      .select({ n: sql<number>`count(*)::int` })
      .from(pagePermissions)
      .innerJoin(pages, eq(pages.id, pagePermissions.pageId))
      .where(and(eq(pagePermissions.userId, actor.userId), eq(pages.workspaceId, workspaceId), inArray(pagePermissions.access, ["edit", "full"])));
    if (!g2.n) throw notFound("Workspace not found");
  } else if (!roleAtLeast(role, "viewer")) {
    throw notFound("Workspace not found");
  }
  if (file.data.length > config.maxUploadBytes) throw tooLarge(`Files can be at most ${Math.round(config.maxUploadBytes / 1048576)} MB on this server (MAX_UPLOAD_BYTES)`);
  if (!file.data.length) throw badRequest("The file is empty");
  const name = (file.name || "file").replace(/[\u0000-\u001f\\/]/g, "_").slice(0, 255);
  const mime = sniffMime(file.data, file.type, name);
  const id = newId();
  const key = `${workspaceId}/${id}`;
  const storage = await getStorage();
  await storage.put(key, file.data, mime);
  await db.insert(files).values({ id, workspaceId, uploadedBy: actor.userId, name, mime, size: file.data.length, storageKey: key, sha256: sha256(file.data) });
  return { id, name, mime, size: file.data.length, url: `/api/files/${id}` };
}

async function fileReferencedInShare(db: DB, fileId: string, shareToken: string): Promise<boolean> {
  const { getPublicPage } = await import("./sharing");
  const shared = await getPublicPage(db, shareToken).catch(() => null);
  if (!shared) return false;
  const { subtreeIds } = await import("./pages");
  const ids = await subtreeIds(db, shared.rootId);
  const needle = `%${fileId}%`;
  const res = await db.execute(sql`
    SELECT 1 FROM blocks WHERE page_id IN ${ids} AND content::text LIKE ${needle}
    UNION ALL SELECT 1 FROM pages WHERE id IN ${ids} AND (coalesce(cover,'') LIKE ${needle} OR coalesce(icon,'') LIKE ${needle} OR properties::text LIKE ${needle})
    LIMIT 1`);
  const rows = ((res as unknown as { rows: unknown[] }).rows ?? res) as unknown[];
  return rows.length > 0;
}

export async function readFile(db: DB, actor: Actor | null, fileId: string, shareToken?: string | null) {
  if (!/^[0-9a-f-]{36}$/.test(fileId)) throw notFound();
  const [f] = await db.select().from(files).where(eq(files.id, fileId));
  if (!f) throw notFound();
  let allowed = false;
  if (actor) {
    const role = await getRole(db, f.workspaceId, actor.userId);
    if (role) allowed = true;
    else {
      const [g2] = await db
        .select({ n: sql<number>`count(*)::int` })
        .from(pagePermissions)
        .innerJoin(pages, eq(pages.id, pagePermissions.pageId))
        .where(and(eq(pagePermissions.userId, actor.userId), eq(pages.workspaceId, f.workspaceId), sql`${pagePermissions.access} <> 'none'`));
      allowed = g2.n > 0;
    }
  }
  if (!allowed && shareToken) allowed = await fileReferencedInShare(db, fileId, shareToken);
  if (!allowed) throw notFound();
  const storage = await getStorage();
  const data = await storage.get(f.storageKey);
  return { meta: f, data };
}

export async function storageUsage(db: DB, actor: Actor, workspaceId: string) {
  const role = await getRole(db, workspaceId, actor.userId);
  if (!role) throw notFound("Workspace not found");
  const [r] = await db.select({ bytes: sql<number>`coalesce(sum(${files.size}), 0)::bigint`, count: sql<number>`count(*)::int` }).from(files).where(eq(files.workspaceId, workspaceId));
  return { bytes: Number(r.bytes), count: r.count, warnBytes: config.storageWarnBytes || null };
}

/**
 * Delete files that no block, page icon/cover or property references and that are older than
 * `minAgeHours` (so in-progress uploads are never removed). Returns the number deleted.
 */
export async function cleanupUnreferencedFiles(db: DB, minAgeHours = 24) {
  const cutoff = new Date(Date.now() - minAgeHours * 3_600_000);
  const candidates = await db.select().from(files).where(lt(files.createdAt, cutoff));
  const storage = await getStorage();
  let deleted = 0;
  for (const f of candidates) {
    const needle = `%${f.id}%`;
    const res = await db.execute(sql`
      SELECT 1 FROM blocks b JOIN pages p ON p.id = b.page_id WHERE p.workspace_id = ${f.workspaceId} AND b.content::text LIKE ${needle}
      UNION ALL SELECT 1 FROM pages WHERE workspace_id = ${f.workspaceId} AND (coalesce(cover,'') LIKE ${needle} OR coalesce(icon,'') LIKE ${needle} OR properties::text LIKE ${needle})
      UNION ALL SELECT 1 FROM page_revisions r JOIN pages p ON p.id = r.page_id WHERE p.workspace_id = ${f.workspaceId} AND r.snapshot::text LIKE ${needle}
      UNION ALL SELECT 1 FROM workspaces WHERE id = ${f.workspaceId} AND coalesce(icon,'') LIKE ${needle}
      UNION ALL SELECT 1 FROM users WHERE coalesce(avatar_url,'') LIKE ${needle}
      LIMIT 1`);
    const rows = ((res as unknown as { rows: unknown[] }).rows ?? res) as unknown[];
    if (rows.length) continue;
    await storage.delete(f.storageKey).catch(() => {});
    await db.delete(files).where(eq(files.id, f.id));
    deleted++;
  }
  return deleted;
}

export { workspaceMembers };
