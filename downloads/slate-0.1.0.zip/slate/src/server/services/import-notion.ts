// Import of Notion's own "Markdown & CSV" export (a ZIP). File and folder names carry a 32-hex id:
//   Page <id>.md              a page; its sub-pages live in the folder "Page <id>/"
//   Tasks <id>.csv            a database (newer exports add "Tasks <id>_all.csv" with every row)
//   Tasks <id>/Row <id>.md    the page of one record: "# Row", property lines, then the content
// Large exports wrap everything in nested ZIPs. Links between files are URL-encoded relative paths
// and become links to the imported pages. Nothing existing is changed: everything is created new.
import { and, asc, eq } from "drizzle-orm";
import { unzipSync, strFromU8 } from "fflate";
import type { DB } from "../db";
import { pages } from "../db/schema";
import { badRequest, notFound, tooLarge } from "../errors";
import { config } from "../config";
import type { Actor } from "./auth";
import { getRole, requirePage, roleAtLeast } from "./permissions";
import { createPage, saveContent } from "./pages";
import { importCsv, uploadRelativeImages, resolveArchivePath, type ImportReport } from "./transfer";
import { markdownToBlocks, extractTitle, dropRelativeRefs } from "@/lib/markdown";
import { parseCsv } from "@/lib/csv";
import { validateBlocks, visitNodes, type PMNode } from "@/lib/blocks";

const ID_SUFFIX = /\s+[0-9a-f]{32}$/i;

/** Whether a set of archive paths looks like a Notion export (names ending in a 32-hex id). */
export function looksLikeNotionExport(paths: string[]): boolean {
  return paths.some((p) => p.split("/").some((seg) => ID_SUFFIX.test(seg.replace(/(_all)?\.(md|csv)$/i, ""))));
}

const stripId = (name: string) => name.replace(ID_SUFFIX, "").trim() || "Untitled";
/** "dir/Name <id>.md" and "dir/Name <id>_all.csv" → "dir/Name <id>": the key shared with its folder. */
const keyOf = (path: string) => path.replace(/\.(md|csv)$/i, "").replace(/_all$/i, "");
const dirOf = (path: string) => path.split("/").slice(0, -1).join("/");
const baseOf = (key: string) => key.split("/").pop()!;

/** Unpack ZIPs inside the ZIP (Notion splits large exports into "Part-N.zip" files). */
function unwrapNested(entries: Map<string, Uint8Array>): Map<string, Uint8Array> {
  const out = new Map<string, Uint8Array>();
  let total = 0;
  for (const [path, data] of entries) {
    if (!/\.zip$/i.test(path)) {
      out.set(path, data);
      continue;
    }
    let inner: Record<string, Uint8Array>;
    try {
      inner = unzipSync(data);
    } catch {
      throw badRequest(`${path} could not be read`);
    }
    for (const [p, d] of Object.entries(inner)) {
      if (p.endsWith("/")) continue;
      total += d.length;
      if (total > config.maxImportBytes * 4) throw tooLarge("The ZIP expands to more than the import limit allows");
      out.set(p, d);
    }
  }
  return out;
}

export async function importNotion(db: DB, actor: Actor, workspaceId: string, raw: Map<string, Uint8Array>, parentId: string | null): Promise<ImportReport> {
  if (parentId) await requirePage(db, actor, parentId, "edit");
  else if (!roleAtLeast(await getRole(db, workspaceId, actor.userId), "editor")) throw notFound("Workspace not found");
  const entries = new Map([...unwrapNested(raw)].filter(([p]) => !p.startsWith("__MACOSX") && !p.split("/").pop()!.startsWith(".")));
  const warnings: string[] = [];

  // Databases: one CSV per key, preferring the "_all" variant.
  const csvByKey = new Map<string, string>();
  for (const p of entries.keys()) {
    if (!/\.csv$/i.test(p)) continue;
    const k = keyOf(p);
    if (!csvByKey.has(k) || /_all\.csv$/i.test(p)) csvByKey.set(k, p);
  }
  const mdPaths = [...entries.keys()].filter((p) => /\.md$/i.test(p));
  if (!mdPaths.length && !csvByKey.size) throw badRequest("No pages or databases found in the export");

  // Everything that becomes a page or database, shallowest first.
  type Item = { key: string; kind: "page" | "database" | "record"; path: string };
  const items: Item[] = [
    ...mdPaths.map((p): Item => ({ key: keyOf(p), kind: csvByKey.has(dirOf(p)) ? "record" : "page", path: p })),
    ...[...csvByKey].map(([key, path]): Item => ({ key, kind: "database", path })),
  ].sort((a, b) => a.key.split("/").length - b.key.split("/").length || a.key.localeCompare(b.key));

  const idByKey = new Map<string, string>(); // export key → page / database / record id
  const rootIds: string[] = [];
  /** The created page or database for the nearest enclosing folder ("transparent" folders are skipped). */
  const parentFor = (key: string): string | null => {
    const segs = key.split("/").slice(0, -1);
    while (segs.length) {
      const id = idByKey.get(segs.join("/"));
      if (id) return id;
      segs.pop();
    }
    return parentId;
  };
  const recordsByDb = new Map<string, Map<string, string[]>>(); // database key → title → record ids
  const columnsByDb = new Map<string, Set<string>>(); // database key → CSV column names
  let databases = 0;
  let records = 0;

  // Pass 1: create pages and databases (so links can point at them), and match record pages.
  for (const it of items) {
    if (idByKey.has(it.key)) continue;
    if (it.kind === "database") {
      const csvText = strFromU8(entries.get(it.path)!);
      columnsByDb.set(it.key, new Set((parseCsv(csvText)[0] ?? []).map((h) => h.trim())));
      const r = await importCsv(db, actor, workspaceId, csvText, { title: stripId(baseOf(it.key)), parentId: parentFor(it.key) });
      idByKey.set(it.key, r.databaseId);
      warnings.push(...r.warnings);
      databases++;
      records += r.records;
      if (parentFor(it.key) === parentId) rootIds.push(r.databaseId);
      const rows = await db.select({ id: pages.id, title: pages.title }).from(pages).where(and(eq(pages.databaseId, r.databaseId))).orderBy(asc(pages.position));
      const byTitle = new Map<string, string[]>();
      for (const row of rows) byTitle.set(row.title, [...(byTitle.get(row.title) ?? []), row.id]);
      recordsByDb.set(it.key, byTitle);
      continue;
    }
    if (it.kind === "record") {
      const { title } = extractTitle(strFromU8(entries.get(it.path)!));
      const name = title ?? stripId(baseOf(it.key));
      const queue = recordsByDb.get(dirOf(it.path))?.get(name);
      const id = queue?.shift();
      if (id) {
        idByKey.set(it.key, id);
        continue;
      }
      warnings.push(`${it.path}: no matching row in the database CSV; imported as a page`);
    }
    const { title } = extractTitle(strFromU8(entries.get(it.path)!));
    const parent = parentFor(it.key);
    const pg = await createPage(db, actor, { workspaceId, parentId: parent, title: title ?? stripId(baseOf(it.key)) });
    idByKey.set(it.key, pg.id);
    if (parent === parentId) rootIds.push(pg.id);
  }

  // Pass 2: content, with links to other exported files pointing at the imported pages.
  const uploaded = new Map<string, string>();
  let pageCount = 0;
  for (const it of items) {
    if (it.kind === "database") continue;
    const id = idByKey.get(it.key)!;
    let { body } = extractTitle(strFromU8(entries.get(it.path)!));
    if (it.kind === "record" && recordsByDb.has(dirOf(it.path))) body = stripPropertyLines(body, columnsByDb.get(dirOf(it.path)) ?? new Set());
    else pageCount++;
    const dir = dirOf(it.path);
    let list = markdownToBlocks(body, { relative: true });
    for (const b of list) {
      visitNodes(b, (n) => {
        for (const m of n.marks ?? []) {
          if (m.type !== "link") continue;
          const href = String(m.attrs?.href ?? "");
          if (!href || /^[a-z][a-z0-9+.-]*:/i.test(href) || href.startsWith("/") || href.startsWith("#")) continue;
          const target = resolveArchivePath(dir, href);
          const targetId = target ? idByKey.get(keyOf(target)) : undefined;
          if (targetId) m.attrs = { ...m.attrs, href: `/w/${workspaceId}/p/${targetId}` };
        }
      });
    }
    await uploadRelativeImages(db, actor, workspaceId, list, dir, entries, uploaded);
    dropRelativeRefs(list); // references to files that are not in the export
    try {
      list = validateBlocks(list.map((b) => ({ id: b.attrs!.id, content: b }))).map((b) => b.content);
    } catch (e) {
      warnings.push(`${it.path}: ${(e as Error).message}`);
      continue;
    }
    if (list.length) await saveContent(db, actor, id, { blocks: list.map((b) => ({ id: String(b.attrs!.id), content: b as PMNode })) });
  }
  return { pages: pageCount, databases, records, files: uploaded.size, rootIds, warnings };
}

/** Record pages repeat the row's properties as "Column: value" lines under the title; drop them. */
export function stripPropertyLines(body: string, columns: Set<string>): string {
  const lines = body.replace(/^\s*\n/, "").split("\n");
  let i = 0;
  while (i < lines.length) {
    const m = /^([^:\n]{1,200}):(\s.*)?$/.exec(lines[i]);
    if (!m || !columns.has(m[1].trim())) break;
    i++;
  }
  return i ? lines.slice(i).join("\n").replace(/^\s*\n/, "") : body;
}
