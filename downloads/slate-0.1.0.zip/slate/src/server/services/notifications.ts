import { and, desc, eq, inArray, isNull, sql } from "drizzle-orm";
import { z } from "zod";
import type { DB, DBorTx } from "../db";
import { notifications, pages, users } from "../db/schema";
import { config } from "../config";
import { emailEnabled, sendEmail } from "./email";
import { newId } from "../crypto";
import type { Actor } from "./auth";
import { requirePage } from "./permissions";

export type NotificationKind = "page_mention" | "comment_mention" | "reply";

const MAX_EXCERPT = 300;

/**
 * Notify users about something on a page. Recipients who cannot view the page (or are the actor)
 * are skipped silently, so a mention never reveals a page to someone without access.
 * `dedupeByBlock` skips users already notified about the same block (re-saves, restores, undo).
 */
const VERB: Record<NotificationKind, string> = { page_mention: "mentioned you in", comment_mention: "mentioned you in a comment on", reply: "replied to a comment on" };
const escapeHtml = (s: string) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);

/** Subject and body of a notification email (links need APP_URL). */
export function notificationEmail(n: { kind: NotificationKind; actorName: string; pageTitle: string; excerpt: string; workspaceId: string; pageId: string; commentId: string | null; blockId: string | null }) {
  const title = n.pageTitle.trim() || "Untitled";
  const line = `${n.actorName} ${VERB[n.kind]} ${title}`;
  const excerpt = n.excerpt.trim().slice(0, MAX_EXCERPT);
  const base = config.appUrl;
  const link = base ? `${base}/w/${n.workspaceId}/p/${n.pageId}${n.commentId ? `?thread=${n.commentId}` : n.blockId ? `#block-${n.blockId}` : ""}` : null;
  const text = [line, ...(excerpt ? [`"${excerpt}"`] : []), link ? `Open: ${link}` : "Open Slate to see it.", "You can turn these emails off in Slate: Settings → My account."].join("\n\n");
  const html = `<p>${escapeHtml(line)}</p>${excerpt ? `<blockquote style="border-left:3px solid #ccc;margin:0;padding-left:10px;color:#555">${escapeHtml(excerpt)}</blockquote>` : ""}<p>${link ? `<a href="${escapeHtml(link)}">Open in Slate</a>` : "Open Slate to see it."}</p><p style="color:#888;font-size:12px">You can turn these emails off in Slate: Settings → My account.</p>`;
  return { subject: line.slice(0, 200), text, html };
}

export async function notify(
  db: DB,
  actor: Actor,
  input: { pageId: string; userIds: Iterable<string>; kind: NotificationKind; commentId?: string | null; blockIds?: Map<string, string>; excerpt: string; dedupeByBlock?: boolean },
) {
  const [page] = await db.select({ workspaceId: pages.workspaceId, title: pages.title }).from(pages).where(eq(pages.id, input.pageId));
  if (!page) return 0;
  const actorName = emailEnabled() ? ((await db.query.users.findFirst({ where: eq(users.id, actor.userId), columns: { name: true } }))?.name ?? "Someone") : "";
  let sent = 0;
  for (const userId of new Set(input.userIds)) {
    if (userId === actor.userId) continue;
    const canView = await requirePage(db, { userId, via: "session" }, input.pageId, "view").then(
      () => true,
      () => false,
    );
    if (!canView) continue;
    const blockId = input.blockIds?.get(userId) ?? null;
    if (input.dedupeByBlock) {
      const [dup] = await db
        .select({ id: notifications.id })
        .from(notifications)
        .where(
          and(
            eq(notifications.userId, userId),
            eq(notifications.pageId, input.pageId),
            eq(notifications.kind, input.kind),
            blockId ? eq(notifications.blockId, blockId) : isNull(notifications.blockId),
          ),
        )
        .limit(1);
      if (dup) continue;
    }
    await db.insert(notifications).values({
      id: newId(),
      userId,
      workspaceId: page.workspaceId,
      pageId: input.pageId,
      actorId: actor.userId,
      kind: input.kind,
      commentId: input.commentId ?? null,
      blockId,
      excerpt: input.excerpt.slice(0, MAX_EXCERPT),
    });
    sent++;
    if (emailEnabled()) {
      const to = await db.query.users.findFirst({ where: eq(users.id, userId), columns: { email: true, emailNotifications: true } });
      if (to?.emailNotifications) sendEmail({ to: to.email, ...notificationEmail({ kind: input.kind, actorName, pageTitle: page.title, excerpt: input.excerpt, workspaceId: page.workspaceId, pageId: input.pageId, commentId: input.commentId ?? null, blockId }) });
    }
  }
  return sent;
}

/** The actor's notifications, newest first, limited to pages they can still view. */
export async function listNotifications(db: DB, actor: Actor, opts: { workspaceId?: string; limit?: number } = {}) {
  const limit = Math.min(Math.max(opts.limit ?? 50, 1), 200);
  const where = opts.workspaceId ? and(eq(notifications.userId, actor.userId), eq(notifications.workspaceId, opts.workspaceId)) : eq(notifications.userId, actor.userId);
  const rows = await db
    .select({
      id: notifications.id,
      kind: notifications.kind,
      workspaceId: notifications.workspaceId,
      pageId: notifications.pageId,
      pageTitle: pages.title,
      pageIcon: pages.icon,
      commentId: notifications.commentId,
      blockId: notifications.blockId,
      excerpt: notifications.excerpt,
      createdAt: notifications.createdAt,
      readAt: notifications.readAt,
      actorId: notifications.actorId,
      actorName: users.name,
    })
    .from(notifications)
    .innerJoin(pages, eq(pages.id, notifications.pageId))
    .leftJoin(users, eq(users.id, notifications.actorId))
    .where(where)
    .orderBy(desc(notifications.createdAt))
    .limit(limit * 2);
  const visible = new Map<string, boolean>();
  const out = [];
  for (const r of rows) {
    if (!visible.has(r.pageId))
      visible.set(
        r.pageId,
        await requirePage(db, actor, r.pageId, "view").then(
          () => true,
          () => false,
        ),
      );
    if (visible.get(r.pageId)) out.push(r);
    if (out.length >= limit) break;
  }
  return { notifications: out, unread: await unreadCount(db, actor, opts.workspaceId) };
}

/** Unread count (cheap; may include notifications for pages whose access was revoked since). */
export async function unreadCount(db: DBorTx, actor: Actor, workspaceId?: string) {
  const conds = [eq(notifications.userId, actor.userId), isNull(notifications.readAt)];
  if (workspaceId) conds.push(eq(notifications.workspaceId, workspaceId));
  const [row] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(notifications)
    .innerJoin(pages, eq(pages.id, notifications.pageId))
    .where(and(...conds, isNull(pages.archivedAt)));
  return row?.n ?? 0;
}

export const markReadInput = z.union([z.object({ ids: z.array(z.string().max(100)).min(1).max(500) }), z.object({ all: z.literal(true), workspaceId: z.string().max(100).optional() })]);

export async function markRead(db: DB, actor: Actor, input: z.infer<typeof markReadInput>) {
  const data = markReadInput.parse(input);
  const conds = [eq(notifications.userId, actor.userId), isNull(notifications.readAt)];
  if ("ids" in data) conds.push(inArray(notifications.id, data.ids));
  else if (data.workspaceId) conds.push(eq(notifications.workspaceId, data.workspaceId));
  await db.update(notifications).set({ readAt: new Date() }).where(and(...conds));
  return { unread: await unreadCount(db, actor, "workspaceId" in data ? data.workspaceId : undefined) };
}
