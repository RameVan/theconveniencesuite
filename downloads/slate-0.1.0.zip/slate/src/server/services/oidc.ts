// Optional single sign-on with an OpenID Connect provider (authorization code flow with PKCE).
// Users are matched by (issuer, subject); on first sign-in an existing account is linked only
// through an email address the provider marks as verified. No feature is gated on SSO.
import * as client from "openid-client";
import { and, eq } from "drizzle-orm";
import type { DB } from "../db";
import { users, userIdentities } from "../db/schema";
import { newId } from "../crypto";
import { config } from "../config";
import { badRequest, forbidden } from "../errors";
import { countUsers, toPublicUser, type PublicUser } from "./auth";

/** Password hash of accounts created through SSO: never matches a password. */
export const NO_PASSWORD = "sso-only";

export const OIDC_COOKIE = "slate_oidc";
const FLOW_TTL_SECONDS = 600;

let cached: { key: string; config: client.Configuration } | null = null;

async function oidcClient(): Promise<client.Configuration> {
  const o = config.oidc;
  if (!o) throw badRequest("Single sign-on is not configured");
  const key = `${o.issuer}|${o.clientId}|${o.clientSecret ?? ""}`;
  if (cached?.key === key) return cached.config;
  const issuer = new URL(o.issuer);
  // Plain http only for a provider on this machine (development and tests).
  const loopback = ["localhost", "127.0.0.1", "[::1]"].includes(issuer.hostname);
  const options = issuer.protocol === "http:" && loopback ? { execute: [client.allowInsecureRequests] } : undefined;
  const cfg = o.clientSecret ? await client.discovery(issuer, o.clientId, o.clientSecret, undefined, options) : await client.discovery(issuer, o.clientId, undefined, client.None(), options);
  cached = { key, config: cfg };
  return cfg;
}

/** For tests: forget the discovered provider configuration. */
export function resetOidcClient() {
  cached = null;
}

export function oidcRedirectUri(origin: string) {
  return `${origin}/api/auth/oidc/callback`;
}

/** Start sign-in: the provider URL to redirect to, and the flow secrets to keep in a cookie. */
export async function startOidc(redirectUri: string, next: string | null) {
  const cfg = await oidcClient();
  const verifier = client.randomPKCECodeVerifier();
  const flow = { state: client.randomState(), nonce: client.randomNonce(), verifier, next: safeNext(next) };
  const url = client.buildAuthorizationUrl(cfg, {
    redirect_uri: redirectUri,
    scope: config.oidc!.scopes,
    state: flow.state,
    nonce: flow.nonce,
    code_challenge: await client.calculatePKCECodeChallenge(verifier),
    code_challenge_method: "S256",
  });
  return { url: url.href, cookie: Buffer.from(JSON.stringify(flow)).toString("base64url"), maxAge: FLOW_TTL_SECONDS };
}

function safeNext(next: string | null): string | null {
  // Only same-site paths ("/w/..."), never "//host" or absolute URLs.
  return next && /^\/(?!\/)[^\s\\]*$/.test(next) ? next : null;
}

function readFlow(cookie: string | undefined) {
  if (!cookie) throw badRequest("The sign-in attempt expired. Please try again.");
  try {
    const f = JSON.parse(Buffer.from(cookie, "base64url").toString("utf8")) as { state: string; nonce: string; verifier: string; next: string | null };
    if (typeof f.state === "string" && typeof f.nonce === "string" && typeof f.verifier === "string") return f;
  } catch {
    /* fall through */
  }
  throw badRequest("The sign-in attempt expired. Please try again.");
}

/**
 * Finish sign-in: exchange the code (checking state, nonce and PKCE), then find, link or create the
 * user. Returns the user, whether the account is new, and where to go next.
 */
export async function finishOidc(db: DB, callbackUrl: URL, cookie: string | undefined): Promise<{ user: PublicUser; created: boolean; next: string | null }> {
  const flow = readFlow(cookie);
  const cfg = await oidcClient();
  let claims: (client.IDToken & Record<string, unknown>) | undefined;
  try {
    const tokens = await client.authorizationCodeGrant(cfg, callbackUrl, { pkceCodeVerifier: flow.verifier, expectedState: flow.state, expectedNonce: flow.nonce, idTokenExpected: true });
    claims = tokens.claims();
    // Many providers put email/profile claims only in UserInfo (its subject must match the ID token's).
    if (claims && (claims.email === undefined || claims.email_verified === undefined) && tokens.access_token) {
      const info = await client.fetchUserInfo(cfg, tokens.access_token, claims.sub);
      claims = { ...info, ...claims, email: claims.email ?? info.email, email_verified: claims.email_verified ?? info.email_verified, name: claims.name ?? info.name };
    }
  } catch {
    throw badRequest("Sign-in with your identity provider failed. Please try again.");
  }
  if (!claims?.sub) throw badRequest("Sign-in with your identity provider failed. Please try again.");
  const issuer = claims.iss;
  const email = typeof claims.email === "string" ? claims.email.trim().toLowerCase() : null;
  const verified = claims.email_verified === true;
  const name = (typeof claims.name === "string" && claims.name.trim()) || (typeof claims.preferred_username === "string" && claims.preferred_username) || email?.split("@")[0] || "User";

  const [linked] = await db.select().from(userIdentities).where(and(eq(userIdentities.issuer, issuer), eq(userIdentities.subject, claims.sub)));
  if (linked) {
    const user = await db.query.users.findFirst({ where: eq(users.id, linked.userId) });
    if (user) return { user: toPublic(user), created: false, next: flow.next };
  }
  if (!email || !verified) throw forbidden("Your identity provider did not share a verified email address, so no Slate account can be matched or created.");
  let user = await db.query.users.findFirst({ where: eq(users.email, email) });
  let created = false;
  if (!user) {
    const isFirst = (await countUsers(db)) === 0;
    if (!isFirst && !config.oidc!.allowSignup) throw forbidden("No Slate account uses this email, and new accounts are disabled on this server.");
    [user] = await db.insert(users).values({ id: newId(), email, name: name.slice(0, 100), passwordHash: NO_PASSWORD, isAdmin: isFirst }).returning();
    created = true;
  }
  await db.insert(userIdentities).values({ issuer, subject: claims.sub, userId: user.id, email }).onConflictDoNothing();
  return { user: toPublic(user), created, next: flow.next };
}

function toPublic(u: typeof users.$inferSelect): PublicUser {
  return toPublicUser(u);
}
