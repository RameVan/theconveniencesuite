import { and, asc, desc, eq, inArray, isNull, sql, max } from "drizzle-orm";
import { z } from "zod";
import type { DB, DBorTx, Tx } from "../db";
import { pages, blocks, favorites, pageVisits, databaseProperties, databaseViews, relationLinks } from "../db/schema";
import { newId } from "../crypto";
import { badRequest, conflict, notFound, forbidden } from "../errors";
import type { Actor } from "./auth";
import { AccessResolver, requirePage, getPageAccess, roleAtLeast, getRole, type Access } from "./permissions";
import { validateBlocks, nodeText, BlockValidationError, canonicalJson, type PMNode, visitNodes } from "@/lib/blocks";
import { maybeSnapshot, snapshotPage } from "./revisions";
import { loadDatabaseMeta, recordDetail } from "./databases";
import { audit } from "./audit";
import { notify } from "./notifications";
import { blockMentions, newBlockMentions } from "@/lib/mentions";

export type PageRow = typeof pages.$inferSelect;

export const iconSchema = z.string().max(2000).nullable();
export const coverSchema = z.string().max(2000).nullable();
export const titleSchema = z.string().max(2000);

export function pageSummary(p: Pick<PageRow, "id" | "title" | "icon" | "kind" | "databaseId" | "parentId">) {
  return { id: p.id, title: p.title, icon: p.icon, kind: p.kind, databaseId: p.databaseId, parentId: p.parentId };
}

// ---------------------------------------------------------------- positions

async function siblingPositions(db: DBorTx, workspaceId: string, parentId: string | null, excludeId?: string) {
  const rows = await db
    .select({ id: pages.id, position: pages.position })
    .from(pages)
    .where(
      and(
        eq(pages.workspaceId, workspaceId),
        parentId ? eq(pages.parentId, parentId) : isNull(pages.parentId),
        isNull(pages.databaseId),
        isNull(pages.archivedAt),
      ),
    )
    .orderBy(asc(pages.position));
  return rows.filter((r) => r.id !== excludeId);
}

/** Position for inserting at `index` among siblings (end when undefined). Rebalances if needed. */
async function positionAt(db: DBorTx, workspaceId: string, parentId: string | null, index?: number, excludeId?: string) {
  const sibs = await siblingPositions(db, workspaceId, parentId, excludeId);
  const i = index == null || index > sibs.length ? sibs.length : Math.max(0, index);
  const before = i > 0 ? sibs[i - 1].position : null;
  const after = i < sibs.length ? sibs[i].position : null;
  if (before == null && after == null) return 1;
  if (before == null) return after! - 1;
  if (after == null) return before + 1;
  if (after - before > 1e-9) return (before + after) / 2;
  // Gap exhausted: renumber siblings and retry.
  for (let k = 0; k < sibs.length; k++) await db.update(pages).set({ position: k + 1 }).where(eq(pages.id, sibs[k].id));
  return i + 0.5;
}

// ---------------------------------------------------------------- create

export const createPageInput = z.object({
  workspaceId: z.string().min(1).max(100),
  parentId: z.string().max(100).nullable().optional(),
  title: titleSchema.optional(),
  icon: iconSchema.optional(),
  cover: coverSchema.optional(),
  kind: z.enum(["page", "database"]).optional(),
  visibility: z.enum(["workspace", "private"]).optional(),
  index: z.number().int().min(0).optional(),
  isInline: z.boolean().optional(),
  blocks: z.array(z.unknown()).optional(),
});

export async function createPage(db: DB, actor: Actor, input: z.infer<typeof createPageInput>, tx?: Tx): Promise<PageRow> {
  const data = createPageInput.parse(input);
  const run = async (t: DBorTx) => {
    let workspaceId = data.workspaceId;
    let visibility = data.visibility ?? "workspace";
    if (data.parentId) {
      const parent = await requirePage(t, actor, data.parentId, "edit");
      if (parent.node.workspaceId !== workspaceId) workspaceId = parent.node.workspaceId;
      visibility = "workspace"; // children inherit privacy from their ancestors
    } else {
      const role = await getRole(t, workspaceId, actor.userId);
      if (!role) throw notFound("Workspace not found");
      // Viewers may still create private pages of their own.
      if (!roleAtLeast(role, "editor") && visibility !== "private") throw forbidden("Viewers can only create private pages");
    }
    const position = await positionAt(t, workspaceId, data.parentId ?? null, data.index);
    const id = newId();
    const [row] = await t
      .insert(pages)
      .values({
        id,
        workspaceId,
        parentId: data.parentId ?? null,
        kind: data.kind ?? "page",
        title: data.title ?? "",
        icon: data.icon ?? null,
        cover: data.cover ?? null,
        visibility,
        position,
        isInline: data.isInline ?? false,
        createdBy: actor.userId,
        updatedBy: actor.userId,
      })
      .returning();
    if (data.blocks?.length) await writeBlocks(t, id, data.blocks, actor.userId);
    if (row.kind === "database") {
      const { initDatabase } = await import("./databases");
      await initDatabase(t, id);
    }
    return row;
  };
  return tx ? run(tx) : db.transaction(run);
}

// ---------------------------------------------------------------- read

export async function getBlocks(db: DBorTx, pageId: string): Promise<PMNode[]> {
  const rows = await db.select({ content: blocks.content }).from(blocks).where(eq(blocks.pageId, pageId)).orderBy(asc(blocks.position));
  return rows.map((r) => r.content as unknown as PMNode);
}

export async function getPage(db: DB, actor: Actor, pageId: string, opts: { allowArchived?: boolean } = {}) {
  const pa = await requirePage(db, actor, pageId, "view", { allowArchived: opts.allowArchived ?? true });
  const page = await db.query.pages.findFirst({ where: eq(pages.id, pageId) });
  if (!page) throw notFound("Page not found");
  const content = await getBlocks(db, pageId);

  // Breadcrumbs: visible ancestors, root first.
  const ancestorIds = pa.chain.slice(1).map((n) => n.id);
  const ancestorRows = ancestorIds.length
    ? await db.select({ id: pages.id, title: pages.title, icon: pages.icon, kind: pages.kind, databaseId: pages.databaseId, parentId: pages.parentId }).from(pages).where(inArray(pages.id, ancestorIds))
    : [];
  const resolver = ancestorIds.length ? await AccessResolver.load(db, page.workspaceId, actor.userId) : null;
  const breadcrumbs = ancestorIds
    .map((id) => ancestorRows.find((r) => r.id === id)!)
    .filter((r) => r && resolver!.canView(r.id))
    .reverse()
    .map(pageSummary);

  const children = await db
    .select({ id: pages.id, title: pages.title, icon: pages.icon, kind: pages.kind, databaseId: pages.databaseId, parentId: pages.parentId })
    .from(pages)
    .where(and(eq(pages.parentId, pageId), isNull(pages.archivedAt)))
    .orderBy(asc(pages.position));
  const visibleChildren = resolver ? children.filter((c) => resolver.canView(c.id)) : children;

  const fav = await db.select().from(favorites).where(and(eq(favorites.userId, actor.userId), eq(favorites.pageId, pageId))).limit(1);

  const database = page.kind === "database" ? await loadDatabaseMeta(db, page.id) : null;
  const record = page.databaseId ? await recordDetail(db, actor, page) : null;

  return {
    page: serializePage(page, pa.access),
    access: pa.access,
    role: pa.role,
    breadcrumbs,
    content,
    children: visibleChildren.map(pageSummary),
    favorite: fav.length > 0,
    database,
    record,
  };
}

export function serializePage(p: PageRow, access: Access) {
  return {
    id: p.id,
    workspaceId: p.workspaceId,
    parentId: p.parentId,
    databaseId: p.databaseId,
    kind: p.kind,
    title: p.title,
    icon: p.icon,
    cover: p.cover,
    visibility: p.visibility,
    isTemplate: p.isTemplate,
    isInline: p.isInline,
    fullWidth: p.fullWidth,
    smallText: p.smallText,
    version: p.version,
    createdAt: p.createdAt,
    createdBy: p.createdBy,
    updatedAt: p.updatedAt,
    updatedBy: p.updatedBy,
    archivedAt: p.archivedAt,
    publicShareToken: access === "full" ? p.publicShareToken : null,
  };
}

// ---------------------------------------------------------------- update

export const updatePageInput = z.object({
  title: titleSchema.optional(),
  icon: iconSchema.optional(),
  cover: coverSchema.optional(),
  fullWidth: z.boolean().optional(),
  smallText: z.boolean().optional(),
  visibility: z.enum(["workspace", "private"]).optional(),
  isTemplate: z.boolean().optional(),
});

export async function updatePage(db: DB, actor: Actor, pageId: string, input: z.infer<typeof updatePageInput>) {
  const data = updatePageInput.parse(input);
  const pa = await requirePage(db, actor, pageId, "edit");
  if (data.visibility !== undefined) {
    if (pa.node.parentId || pa.node.databaseId) throw badRequest("Only top-level pages can be moved between Private and Workspace");
    if (pa.access !== "full" && pa.node.createdBy !== actor.userId) throw forbidden("Only the page owner can change its visibility");
    if (data.visibility === "workspace" && !roleAtLeast(pa.role, "editor")) throw forbidden("Viewers cannot publish pages to the workspace");
  }
  const [row] = await db
    .update(pages)
    .set({ ...data, updatedAt: new Date(), updatedBy: actor.userId })
    .where(eq(pages.id, pageId))
    .returning();
  if (data.title !== undefined || data.icon !== undefined || data.cover !== undefined) {
    await maybeSnapshot(db, pageId, actor.userId);
  }
  return serializePage(row, pa.access);
}

// ---------------------------------------------------------------- content

async function writeBlocks(t: DBorTx, pageId: string, raw: unknown[], userId: string) {
  let list;
  try {
    list = validateBlocks(raw);
  } catch (e) {
    if (e instanceof BlockValidationError) throw badRequest(e.message);
    throw e;
  }
  const existing = await t.select({ id: blocks.id, content: blocks.content, position: blocks.position }).from(blocks).where(eq(blocks.pageId, pageId));
  // People newly mentioned by this write (notified by the caller after commit).
  const before = blockMentions(existing.map((b) => ({ id: b.id, content: b.content as unknown as PMNode })));
  const newMentions = newBlockMentions(before, blockMentions(list));
  const byId = new Map(existing.map((b) => [b.id, b]));
  const incoming = new Set(list.map((b) => b.id));
  const toDelete = existing.filter((b) => !incoming.has(b.id)).map((b) => b.id);
  if (toDelete.length) {
    for (let i = 0; i < toDelete.length; i += 500)
      await t.delete(blocks).where(and(eq(blocks.pageId, pageId), inArray(blocks.id, toDelete.slice(i, i + 500))));
  }
  const now = new Date();
  for (let i = 0; i < list.length; i++) {
    const b = list[i];
    const prev = byId.get(b.id);
    if (prev && prev.position === i && canonicalJson(prev.content) === canonicalJson(b.content)) continue; // unchanged
    const values = { pageId, id: b.id, position: i, type: b.type, content: b.content as unknown as Record<string, unknown>, text: nodeText(b.content), updatedAt: now, updatedBy: userId };
    if (prev) {
      await t.update(blocks).set(values).where(and(eq(blocks.pageId, pageId), eq(blocks.id, b.id)));
    } else {
      await t.insert(blocks).values(values);
    }
  }
  return { list, newMentions };
}

export const saveContentInput = z.object({
  baseVersion: z.number().int().nullable().optional(),
  blocks: z.array(z.unknown()),
});

/**
 * Replace a page's blocks. With `baseVersion`, refuses (409) when someone else saved first and
 * keeps the rejected content as a "conflict" revision so no edit is ever lost.
 */
export async function saveContent(db: DB, actor: Actor, pageId: string, input: z.infer<typeof saveContentInput>) {
  const data = saveContentInput.parse(input);
  await requirePage(db, actor, pageId, "edit");
  let written: { list: { id: string; content: PMNode }[]; newMentions: Map<string, string> } | null = null;
  const result = await db.transaction(async (tx) => {
    const [cur] = await tx.select({ version: pages.version }).from(pages).where(eq(pages.id, pageId)).for("update");
    if (!cur) throw notFound("Page not found");
    if (data.baseVersion != null && data.baseVersion !== cur.version) {
      return { conflict: true as const, version: cur.version };
    }
    const { list, newMentions } = await writeBlocks(tx, pageId, data.blocks, actor.userId);
    written = { list, newMentions };
    const [row] = await tx
      .update(pages)
      .set({ version: sql`${pages.version} + 1`, updatedAt: new Date(), updatedBy: actor.userId })
      .where(eq(pages.id, pageId))
      .returning({ version: pages.version, updatedAt: pages.updatedAt });
    return { conflict: false as const, version: row.version, updatedAt: row.updatedAt };
  });
  if (result.conflict) {
    let valid: PMNode[] = [];
    try {
      valid = validateBlocks(data.blocks).map((b) => b.content);
    } catch {
      /* invalid content is not stored */
    }
    const revisionId = await snapshotPage(db, pageId, actor.userId, "conflict", { blocks: valid });
    throw conflict("This page was changed by someone else. Your version was saved in page history.", {
      version: result.version,
      revisionId,
    });
  }
  await maybeSnapshot(db, pageId, actor.userId);
  const w = written as { list: { id: string; content: PMNode }[]; newMentions: Map<string, string> } | null; // assigned inside the transaction
  if (w?.newMentions.size) await notifyPageMentions(db, actor, pageId, w.list, w.newMentions);
  return { version: result.version, updatedAt: result.updatedAt };
}

async function notifyPageMentions(db: DB, actor: Actor, pageId: string, list: { id: string; content: PMNode }[], mentions: Map<string, string>) {
  const text = new Map(list.map((b) => [b.id, nodeText(b.content)]));
  for (const [userId, blockId] of mentions)
    await notify(db, actor, { pageId, userIds: [userId], kind: "page_mention", blockIds: mentions, excerpt: text.get(blockId) ?? "", dedupeByBlock: true });
}

/** Lightweight version check used by clients polling for remote changes. */
export async function getPageVersion(db: DB, actor: Actor, pageId: string) {
  await requirePage(db, actor, pageId, "view", { allowArchived: true });
  const [row] = await db.select({ version: pages.version, updatedAt: pages.updatedAt, updatedBy: pages.updatedBy, archivedAt: pages.archivedAt }).from(pages).where(eq(pages.id, pageId));
  return row;
}

// ---------------------------------------------------------------- move

export const moveInput = z.object({
  parentId: z.string().max(100).nullable(),
  index: z.number().int().min(0).optional(),
  /** Place directly before / after this sibling (preferred over index). */
  beforeId: z.string().max(100).nullable().optional(),
  afterId: z.string().max(100).nullable().optional(),
  visibility: z.enum(["workspace", "private"]).optional(),
});

export async function movePage(db: DB, actor: Actor, pageId: string, input: z.infer<typeof moveInput>) {
  const data = moveInput.parse(input);
  const pa = await requirePage(db, actor, pageId, "edit");
  if (pa.node.databaseId) throw badRequest("Database records are moved by changing their database view");
  const ws = pa.node.workspaceId;
  return db.transaction(async (tx) => {
    let visibility = pa.node.visibility;
    if (data.parentId) {
      if (data.parentId === pageId) throw badRequest("A page cannot be moved into itself");
      const target = await requirePage(tx, actor, data.parentId, "edit");
      if (target.node.workspaceId !== ws) throw badRequest("Moving pages between workspaces is done with export/import");
      if (target.chain.some((n) => n.id === pageId)) throw badRequest("A page cannot be moved into one of its own sub-pages");
      if (target.node.kind === "database") throw badRequest("Pages cannot be nested directly under a database; add a record instead");
      visibility = "workspace";
    } else {
      // Moving to the top level: keep the effective privacy it had.
      const wasPrivate = pa.chain.some((n) => n.visibility === "private");
      visibility = data.visibility ?? (wasPrivate ? "private" : "workspace");
      if (visibility === "workspace" && !roleAtLeast(pa.role, "editor")) throw forbidden("Viewers cannot publish pages to the workspace");
    }
    let index = data.index;
    if (data.beforeId || data.afterId) {
      const sibs = await siblingPositions(tx, ws, data.parentId, pageId);
      const i = sibs.findIndex((x) => x.id === (data.beforeId ?? data.afterId));
      if (i >= 0) index = data.beforeId ? i : i + 1;
    }
    const position = await positionAt(tx, ws, data.parentId, index, pageId);
    const [row] = await tx
      .update(pages)
      .set({ parentId: data.parentId, position, visibility, updatedAt: new Date(), updatedBy: actor.userId })
      .where(eq(pages.id, pageId))
      .returning();
    return serializePage(row, pa.access);
  });
}

// ---------------------------------------------------------------- subtree helpers

/** All descendant ids (sub-pages and database records, recursively), including the root. */
export async function subtreeIds(db: DBorTx, rootId: string, opts: { includeArchived?: boolean } = {}): Promise<string[]> {
  const res = await db.execute(sql`
    WITH RECURSIVE t AS (
      SELECT id FROM pages WHERE id = ${rootId}
      UNION
      SELECT p.id FROM pages p JOIN t ON (p.parent_id = t.id OR p.database_id = t.id)
       ${opts.includeArchived ? sql`` : sql`WHERE p.archived_at IS NULL`}
    ) SELECT id FROM t`);
  const rows = ((res as unknown as { rows: { id: string }[] }).rows ?? res) as { id: string }[];
  return rows.map((r) => r.id);
}

// ---------------------------------------------------------------- trash

export async function archivePage(db: DB, actor: Actor, pageId: string) {
  const pa = await requirePage(db, actor, pageId, "edit");
  const ids = await subtreeIds(db, pageId);
  const now = new Date();
  await db.transaction(async (tx) => {
    for (let i = 0; i < ids.length; i += 1000) {
      await tx
        .update(pages)
        .set({ archivedAt: now, archivedBy: actor.userId, archivedRootId: pageId })
        .where(and(inArray(pages.id, ids.slice(i, i + 1000)), isNull(pages.archivedAt)));
    }
  });
  await audit(db, { workspaceId: pa.node.workspaceId, userId: actor.userId, action: "page.archive", targetId: pageId, meta: { count: ids.length } });
  return { archived: ids.length };
}

export async function restorePage(db: DB, actor: Actor, pageId: string) {
  const pa = await requirePage(db, actor, pageId, "edit", { allowArchived: true });
  const page = await db.query.pages.findFirst({ where: eq(pages.id, pageId) });
  if (!page?.archivedAt) throw badRequest("This page is not in the trash");
  // Restoring a child whose ancestor is still in the trash restores it to the top level instead.
  const rootId = page.archivedRootId ?? pageId;
  await db.transaction(async (tx) => {
    if (rootId !== pageId) {
      // Detach this subtree from the archived ancestor's batch.
      const ids = await subtreeIds(tx, pageId, { includeArchived: true });
      for (let i = 0; i < ids.length; i += 1000)
        await tx.update(pages).set({ archivedRootId: pageId }).where(and(inArray(pages.id, ids.slice(i, i + 1000)), eq(pages.archivedRootId, rootId)));
    }
    if (page.databaseId) {
      const dbPage = await tx.query.pages.findFirst({ where: eq(pages.id, page.databaseId) });
      if (dbPage?.archivedAt) throw badRequest("Restore the database this record belongs to first");
    } else if (page.parentId) {
      const parent = await tx.query.pages.findFirst({ where: eq(pages.id, page.parentId) });
      if (!parent || parent.archivedAt) {
        const wasPrivate = pa.chain.some((n) => n.visibility === "private");
        const position = await positionAt(tx, page.workspaceId, null);
        await tx.update(pages).set({ parentId: null, position, visibility: wasPrivate ? "private" : "workspace" }).where(eq(pages.id, pageId));
      }
    }
    await tx.update(pages).set({ archivedAt: null, archivedBy: null, archivedRootId: null }).where(eq(pages.archivedRootId, pageId));
    await tx.update(pages).set({ archivedAt: null, archivedBy: null, archivedRootId: null }).where(eq(pages.id, pageId));
  });
  await audit(db, { workspaceId: page.workspaceId, userId: actor.userId, action: "page.restore", targetId: pageId });
  return { restored: true };
}

export async function deletePermanently(db: DB, actor: Actor, pageId: string) {
  const pa = await requirePage(db, actor, pageId, "full", { allowArchived: true });
  const page = await db.query.pages.findFirst({ where: eq(pages.id, pageId) });
  if (!page?.archivedAt) throw badRequest("Move the page to the trash before deleting it permanently");
  await db.delete(pages).where(eq(pages.id, pageId)); // cascades to sub-pages, records, blocks, links, history
  await audit(db, { workspaceId: pa.node.workspaceId, userId: actor.userId, action: "page.delete", targetId: pageId });
  return { deleted: true };
}

export async function listTrash(db: DB, actor: Actor, workspaceId: string, q?: string) {
  const role = await getRole(db, workspaceId, actor.userId);
  const resolver = await AccessResolver.load(db, workspaceId, actor.userId);
  if (!role && ![...resolver.allNodes()].some((n) => resolver.canView(n.id))) throw notFound("Workspace not found");
  const rows = await db
    .select({ id: pages.id, title: pages.title, icon: pages.icon, kind: pages.kind, databaseId: pages.databaseId, parentId: pages.parentId, archivedAt: pages.archivedAt, archivedBy: pages.archivedBy })
    .from(pages)
    .where(and(eq(pages.workspaceId, workspaceId), sql`${pages.archivedRootId} = ${pages.id}`))
    .orderBy(desc(pages.archivedAt))
    .limit(1000);
  const needle = q?.trim().toLowerCase();
  return rows.filter((r) => resolver.access(r.id) !== "none" && (!needle || r.title.toLowerCase().includes(needle)));
}

/** Delete trash older than TRASH_RETENTION_DAYS (0 disables). */
export async function purgeExpiredTrash(db: DB, retentionDays: number) {
  if (retentionDays <= 0) return 0;
  const cutoff = new Date(Date.now() - retentionDays * 86_400_000);
  const res = await db
    .delete(pages)
    .where(and(sql`${pages.archivedRootId} = ${pages.id}`, sql`${pages.archivedAt} < ${cutoff}`))
    .returning({ id: pages.id });
  return res.length;
}

// ---------------------------------------------------------------- duplicate

/**
 * Deep-copy a page subtree (sub-pages, databases with their schema, views, records and relation
 * links). IDs are regenerated; references inside the copy are remapped.
 */
export async function duplicatePage(db: DB, actor: Actor, pageId: string, opts: { targetParentId?: string | null; asTemplateInstance?: boolean; title?: string } = {}) {
  const pa = await requirePage(db, actor, pageId, "view");
  const src = await db.query.pages.findFirst({ where: eq(pages.id, pageId) });
  if (!src) throw notFound();
  const ids = await subtreeIds(db, pageId);
  return db.transaction(async (tx) => {
    const idMap = new Map<string, string>();
    for (const id of ids) idMap.set(id, newId());
    const rows = await tx.select().from(pages).where(inArray(pages.id, ids));
    // Copy only what the actor can see.
    const resolver = await AccessResolver.load(tx, src.workspaceId, actor.userId);
    const visibleRows = rows.filter((r) => resolver.canView(r.id));
    const visible = new Set(visibleRows.map((r) => r.id));

    // Properties and views of databases in the subtree.
    const dbIds = visibleRows.filter((r) => r.kind === "database").map((r) => r.id);
    const props = dbIds.length ? await tx.select().from(databaseProperties).where(inArray(databaseProperties.databaseId, dbIds)) : [];
    const views = dbIds.length ? await tx.select().from(databaseViews).where(inArray(databaseViews.databaseId, dbIds)) : [];
    const propMap = new Map(props.map((p) => [p.id, newId()]));
    const viewMap = new Map(views.map((v) => [v.id, newId()]));
    const remap = (id: string | null | undefined) => (id ? (idMap.get(id) ?? propMap.get(id) ?? viewMap.get(id) ?? id) : id);

    let targetParent: string | null;
    let index: number | undefined;
    if (opts.targetParentId !== undefined) {
      targetParent = opts.targetParentId;
      if (targetParent) await requirePage(tx, actor, targetParent, "edit");
    } else {
      targetParent = src.parentId;
      const sibs = await siblingPositions(tx, src.workspaceId, src.parentId);
      index = sibs.findIndex((s) => s.id === src.id) + 1;
      if (src.parentId) await requirePage(tx, actor, src.parentId, "edit");
      else if (!src.databaseId && !roleAtLeast(pa.role, "editor") && src.visibility !== "private") throw forbidden();
    }
    if (src.databaseId) await requirePage(tx, actor, src.databaseId, "edit");

    const now = new Date();
    const rootPosition = src.databaseId ? src.position + 0.5 : await positionAt(tx, src.workspaceId, targetParent, index);
    // Insert parents before children: order by depth.
    const depth = new Map<string, number>();
    const getDepth = (r: PageRow): number => {
      if (r.id === pageId) return 0;
      const known = depth.get(r.id);
      if (known != null) return known;
      const parent = rows.find((x) => x.id === (r.parentId ?? r.databaseId));
      const d = parent ? getDepth(parent) + 1 : 0;
      depth.set(r.id, d);
      return d;
    };
    const ordered = [...visibleRows].sort((a, b) => getDepth(a) - getDepth(b));
    for (const r of ordered) {
      const isRoot = r.id === pageId;
      if (!isRoot && !visible.has(r.parentId ?? r.databaseId ?? "")) continue;
      const props2 = remapProperties(r.properties, propMap);
      const { search: _s, ...rest } = r;
      void _s;
      await tx.insert(pages).values({
        ...rest,
        id: idMap.get(r.id)!,
        parentId: isRoot ? (src.databaseId ? null : targetParent) : remap(r.parentId) ?? null,
        databaseId: isRoot ? r.databaseId : remap(r.databaseId) ?? null,
        title: isRoot ? (opts.title ?? (opts.asTemplateInstance ? r.title : r.title ? `${r.title} (copy)` : "")) : r.title,
        isTemplate: isRoot && opts.asTemplateInstance ? false : r.isTemplate,
        position: isRoot ? rootPosition : r.position,
        visibility: isRoot ? (targetParent ? "workspace" : r.visibility) : r.visibility,
        properties: props2,
        version: 1,
        publicShareToken: null,
        createdBy: actor.userId,
        createdAt: now,
        updatedBy: actor.userId,
        updatedAt: now,
        archivedAt: null,
        archivedBy: null,
        archivedRootId: null,
      } as typeof pages.$inferInsert);
    }
    for (const p of props) {
      const cfg = { ...(p.config as Record<string, unknown>) };
      if (p.type === "relation") {
        const target = cfg.targetDatabaseId as string | undefined;
        if (target && idMap.has(target) && visible.has(target)) {
          cfg.targetDatabaseId = idMap.get(target);
          if (cfg.syncedPropertyId) cfg.syncedPropertyId = propMap.get(cfg.syncedPropertyId as string) ?? null;
        } else {
          cfg.syncedPropertyId = null; // the copy's relation to an outside database is one-way
        }
      }
      if (p.type === "rollup") {
        if (cfg.relationPropertyId) cfg.relationPropertyId = propMap.get(cfg.relationPropertyId as string) ?? cfg.relationPropertyId;
        if (cfg.targetPropertyId && propMap.has(cfg.targetPropertyId as string)) cfg.targetPropertyId = propMap.get(cfg.targetPropertyId as string);
      }
      await tx.insert(databaseProperties).values({ ...p, id: propMap.get(p.id)!, databaseId: idMap.get(p.databaseId)!, config: cfg, createdAt: now });
    }
    for (const v of views) {
      const cfg = JSON.parse(JSON.stringify(v.config), (_k, val) => (typeof val === "string" ? (propMap.get(val) ?? idMap.get(val) ?? val) : val));
      await tx.insert(databaseViews).values({ ...v, id: viewMap.get(v.id)!, databaseId: idMap.get(v.databaseId)!, config: cfg, createdAt: now });
    }
    // Relation links whose source is inside the copy.
    if (props.length) {
      const links = await tx.select().from(relationLinks).where(inArray(relationLinks.propertyId, props.map((p) => p.id)));
      for (const l of links) {
        if (!visible.has(l.fromPageId)) continue;
        const prop = props.find((p) => p.id === l.propertyId)!;
        const targetInside = idMap.has(l.toPageId) && visible.has(l.toPageId);
        const cfg = prop.config as Record<string, unknown>;
        const targetDbInside = !!cfg.targetDatabaseId && idMap.has(cfg.targetDatabaseId as string);
        if (targetDbInside && !targetInside) continue;
        await tx
          .insert(relationLinks)
          .values({ propertyId: propMap.get(l.propertyId)!, fromPageId: idMap.get(l.fromPageId)!, toPageId: targetInside ? idMap.get(l.toPageId)! : l.toPageId, position: l.position })
          .onConflictDoNothing();
      }
    }
    // Blocks (with remapped child-page / database references).
    const blockRows = await tx.select().from(blocks).where(inArray(blocks.pageId, [...visible]));
    for (const b of blockRows) {
      const content = remapBlockRefs(b.content as unknown as PMNode, (id) => (visible.has(id) ? idMap.get(id) : undefined), viewMap);
      const { search: _s, ...rest } = b;
      void _s;
      await tx.insert(blocks).values({ ...rest, pageId: idMap.get(b.pageId)!, content: content as unknown as Record<string, unknown>, updatedAt: now, updatedBy: actor.userId });
    }
    // Records keep unique IDs unique: renumber unique_id values in copied databases.
    const [newRoot] = await tx.select().from(pages).where(eq(pages.id, idMap.get(pageId)!));
    return serializePage(newRoot, "full");
  });
}

function remapProperties(props: Record<string, unknown>, propMap: Map<string, string>) {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(props ?? {})) out[propMap.get(k) ?? k] = v;
  return out;
}

export function remapBlockRefs(node: PMNode, mapPage: (id: string) => string | undefined, viewMap?: Map<string, string>): PMNode {
  const copy: PMNode = JSON.parse(JSON.stringify(node));
  visitNodes(copy, (n) => {
    if (!n.attrs) return;
    for (const key of ["pageId", "databaseId"]) {
      const v = n.attrs[key];
      if (typeof v === "string") {
        const m = mapPage(v);
        if (m) n.attrs[key] = m;
      }
    }
    if (viewMap && typeof n.attrs.viewId === "string" && viewMap.has(n.attrs.viewId)) n.attrs.viewId = viewMap.get(n.attrs.viewId);
  });
  return copy;
}

// ---------------------------------------------------------------- sidebar tree

export interface TreeNode {
  id: string;
  parentId: string | null;
  title: string;
  icon: string | null;
  kind: "page" | "database";
  position: number;
  visibility: "workspace" | "private";
  section: "workspace" | "private" | "shared";
  isInline: boolean;
}

export async function getTree(db: DB, actor: Actor, workspaceId: string) {
  const resolver = await AccessResolver.load(db, workspaceId, actor.userId);
  if (!resolver.role && ![...resolver.allNodes()].some((n) => resolver.canView(n.id))) throw notFound("Workspace not found");
  const rows = await db
    .select({ id: pages.id, parentId: pages.parentId, title: pages.title, icon: pages.icon, kind: pages.kind, position: pages.position, visibility: pages.visibility, isInline: pages.isInline, createdBy: pages.createdBy })
    .from(pages)
    .where(and(eq(pages.workspaceId, workspaceId), isNull(pages.databaseId), isNull(pages.archivedAt), eq(pages.isTemplate, false)))
    .orderBy(asc(pages.position));
  const ids = new Set(rows.map((r) => r.id));
  const nodes: TreeNode[] = [];
  for (const r of rows) {
    if (!resolver.canView(r.id)) continue;
    // Sub-pages of database records are reached through the record, not the sidebar.
    if (r.parentId && !ids.has(r.parentId)) continue;
    const parentVisible = r.parentId ? resolver.canView(r.parentId) : false;
    let section: TreeNode["section"];
    if (r.parentId && parentVisible) section = "workspace"; // resolved from the root on the client
    else if (r.parentId) section = "shared";
    else if (r.visibility === "private") section = r.createdBy === actor.userId ? "private" : "shared";
    else section = resolver.role ? "workspace" : "shared";
    nodes.push({
      id: r.id,
      parentId: r.parentId && parentVisible ? r.parentId : null,
      title: r.title,
      icon: r.icon,
      kind: r.kind,
      position: r.position,
      visibility: r.visibility,
      section,
      isInline: r.isInline,
    });
  }
  const favRows = await db
    .select({ pageId: favorites.pageId })
    .from(favorites)
    .innerJoin(pages, eq(pages.id, favorites.pageId))
    .where(and(eq(favorites.userId, actor.userId), eq(pages.workspaceId, workspaceId), isNull(pages.archivedAt)))
    .orderBy(asc(favorites.position));
  const favoriteIds = favRows.map((f) => f.pageId).filter((id) => resolver.canView(id) && !resolver.isArchived(id));
  const favPages = favoriteIds.length
    ? await db.select({ id: pages.id, title: pages.title, icon: pages.icon, kind: pages.kind, databaseId: pages.databaseId, parentId: pages.parentId }).from(pages).where(inArray(pages.id, favoriteIds))
    : [];
  return {
    nodes,
    favorites: favoriteIds.map((id) => favPages.find((p) => p.id === id)!).filter(Boolean).map(pageSummary),
    role: resolver.role,
  };
}

// ---------------------------------------------------------------- favourites & recents

export async function setFavorite(db: DB, actor: Actor, pageId: string, on: boolean) {
  await requirePage(db, actor, pageId, "view");
  if (on) {
    const [{ m }] = await db.select({ m: max(favorites.position) }).from(favorites).where(eq(favorites.userId, actor.userId));
    await db.insert(favorites).values({ userId: actor.userId, pageId, position: (m ?? 0) + 1 }).onConflictDoNothing();
  } else {
    await db.delete(favorites).where(and(eq(favorites.userId, actor.userId), eq(favorites.pageId, pageId)));
  }
  return { favorite: on };
}

/** Reorder the actor's own favourites: put `pageId` before `beforeId` (or last, with null). */
export async function moveFavorite(db: DB, actor: Actor, pageId: string, beforeId: string | null) {
  return db.transaction(async (tx) => {
    const list = await tx.select({ pageId: favorites.pageId, position: favorites.position }).from(favorites).where(eq(favorites.userId, actor.userId)).orderBy(asc(favorites.position), asc(favorites.createdAt));
    if (!list.some((f) => f.pageId === pageId)) throw notFound("Not in your favorites");
    if (beforeId && !list.some((f) => f.pageId === beforeId)) throw notFound("Not in your favorites");
    const rest = list.filter((f) => f.pageId !== pageId);
    const at = beforeId ? rest.findIndex((f) => f.pageId === beforeId) : rest.length;
    const prev = rest[at - 1]?.position;
    const next = rest[at]?.position;
    const set = (id: string, position: number) => tx.update(favorites).set({ position }).where(and(eq(favorites.userId, actor.userId), eq(favorites.pageId, id)));
    if (prev !== undefined && next !== undefined && !(next - prev > 1e-9)) {
      // Neighbours share a position: renumber the whole list once.
      const order = [...rest.slice(0, at).map((f) => f.pageId), pageId, ...rest.slice(at).map((f) => f.pageId)];
      for (let i = 0; i < order.length; i++) await set(order[i], i + 1);
    } else {
      await set(pageId, prev === undefined ? (next ?? 1) - 1 : next === undefined ? prev + 1 : (prev + next) / 2);
    }
    return { ok: true };
  });
}

export async function recordVisit(db: DB, actor: Actor, pageId: string) {
  const pa = await getPageAccess(db, actor.userId, pageId);
  if (!pa || pa.access === "none") return;
  await db
    .insert(pageVisits)
    .values({ userId: actor.userId, pageId, visitedAt: new Date() })
    .onConflictDoUpdate({ target: [pageVisits.userId, pageVisits.pageId], set: { visitedAt: new Date() } });
}

export async function recentPages(db: DB, actor: Actor, workspaceId: string, limit = 20) {
  const rows = await db
    .select({ id: pages.id, title: pages.title, icon: pages.icon, kind: pages.kind, databaseId: pages.databaseId, parentId: pages.parentId, visitedAt: pageVisits.visitedAt })
    .from(pageVisits)
    .innerJoin(pages, eq(pages.id, pageVisits.pageId))
    .where(and(eq(pageVisits.userId, actor.userId), eq(pages.workspaceId, workspaceId), isNull(pages.archivedAt)))
    .orderBy(desc(pageVisits.visitedAt))
    .limit(limit * 2);
  if (!rows.length) return [];
  const resolver = await AccessResolver.load(db, workspaceId, actor.userId);
  return rows
    .filter((r) => resolver.canView(r.id) && !resolver.isArchived(r.id))
    .slice(0, limit)
    .map((r) => ({ ...pageSummary(r), visitedAt: r.visitedAt }));
}
