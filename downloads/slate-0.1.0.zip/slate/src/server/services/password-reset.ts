// "Forgot password": a single-use link by email, valid for one hour. Responses never reveal
// whether an account exists. Links are built from APP_URL only: taking the host from the request
// would let anyone ask for a reset of someone else's account with a link pointing at their own site.
import { and, eq, gt, isNull } from "drizzle-orm";
import { z } from "zod";
import type { DB } from "../db";
import { users, passwordResets, sessions } from "../db/schema";
import { randomToken, sha256, hashPassword } from "../crypto";
import { config } from "../config";
import { badRequest } from "../errors";
import { emailEnabled, sendEmail } from "./email";
import { emailSchema, passwordSchema } from "./auth";

const TTL_MS = 60 * 60_000;

/** Whether reset emails can be sent (mail server and public URL configured). */
export function passwordResetAvailable() {
  return emailEnabled() && !!config.appUrl;
}

export async function requestPasswordReset(db: DB, input: { email: string }) {
  if (!passwordResetAvailable()) return { ok: true, emailAvailable: false };
  const parsed = emailSchema.safeParse(input.email);
  const user = parsed.success ? await db.query.users.findFirst({ where: eq(users.email, parsed.data) }) : undefined;
  if (user) {
    const token = randomToken(32);
    await db.insert(passwordResets).values({ tokenHash: sha256(token), userId: user.id, expiresAt: new Date(Date.now() + TTL_MS) });
    const link = `${config.appUrl}/reset-password?token=${encodeURIComponent(token)}`;
    sendEmail({
      to: user.email,
      subject: "Reset your Slate password",
      text: `Someone asked to reset the password of your Slate account (${user.email}).\n\nChoose a new password: ${link}\n\nThe link works once, for one hour. If you didn't ask for this, ignore this email; your password stays the same.`,
      html: `<p>Someone asked to reset the password of your Slate account (${escapeHtml(user.email)}).</p><p><a href="${escapeHtml(link)}">Choose a new password</a></p><p style="color:#888;font-size:12px">The link works once, for one hour. If you didn't ask for this, ignore this email; your password stays the same.</p>`,
    });
  }
  // Same answer whether or not the account exists.
  return { ok: true, emailAvailable: true };
}

export const resetInput = z.object({ token: z.string().min(10).max(200), password: z.string() });

export async function resetPassword(db: DB, input: z.infer<typeof resetInput>) {
  const { token, password } = resetInput.parse(input);
  const passwordHash = await hashPassword(passwordSchema.parse(password));
  return db.transaction(async (tx) => {
    const [row] = await tx
      .select()
      .from(passwordResets)
      .where(and(eq(passwordResets.tokenHash, sha256(token)), isNull(passwordResets.usedAt), gt(passwordResets.expiresAt, new Date())))
      .for("update");
    if (!row) throw badRequest("This link is invalid, was already used, or has expired. Ask for a new one.");
    await tx.update(users).set({ passwordHash }).where(eq(users.id, row.userId));
    // The link is spent, other links stop working, and every session is signed out.
    await tx.update(passwordResets).set({ usedAt: new Date() }).where(and(eq(passwordResets.userId, row.userId), isNull(passwordResets.usedAt)));
    await tx.delete(sessions).where(eq(sessions.userId, row.userId));
    return { ok: true };
  });
}

const escapeHtml = (s: string) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
