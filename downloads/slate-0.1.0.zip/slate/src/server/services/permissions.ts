import { and, eq, sql, inArray } from "drizzle-orm";
import type { DBorTx } from "../db";
import { pages, pagePermissions, workspaceMembers } from "../db/schema";
import { forbidden, notFound } from "../errors";
import type { Actor } from "./auth";

export type Access = "none" | "view" | "edit" | "full";
export type WorkspaceRole = "owner" | "admin" | "editor" | "viewer";

const RANK: Record<Access, number> = { none: 0, view: 1, edit: 2, full: 3 };
export const atLeast = (a: Access, b: Access) => RANK[a] >= RANK[b];

export function roleToAccess(role: WorkspaceRole | null | undefined): Access {
  switch (role) {
    case "owner":
    case "admin":
      return "full";
    case "editor":
      return "edit";
    case "viewer":
      return "view";
    default:
      return "none";
  }
}

const ROLE_RANK: Record<WorkspaceRole, number> = { viewer: 1, editor: 2, admin: 3, owner: 4 };
export const roleAtLeast = (r: WorkspaceRole | null | undefined, min: WorkspaceRole) => !!r && ROLE_RANK[r] >= ROLE_RANK[min];

export async function getRole(db: DBorTx, workspaceId: string, userId: string): Promise<WorkspaceRole | null> {
  const m = await db
    .select({ role: workspaceMembers.role })
    .from(workspaceMembers)
    .where(and(eq(workspaceMembers.workspaceId, workspaceId), eq(workspaceMembers.userId, userId)))
    .limit(1);
  return m[0]?.role ?? null;
}

export async function requireRole(db: DBorTx, actor: Actor, workspaceId: string, min: WorkspaceRole): Promise<WorkspaceRole> {
  const role = await getRole(db, workspaceId, actor.userId);
  if (!role) throw notFound("Workspace not found");
  if (!roleAtLeast(role, min)) throw forbidden(`This action requires the ${min} role`);
  return role;
}

export interface StructNode {
  id: string;
  parentId: string | null;
  databaseId: string | null;
  visibility: "workspace" | "private";
  createdBy: string | null;
  workspaceId: string;
  archivedAt: Date | null;
  kind: "page" | "database";
}

/** Pure resolution over an ancestor chain (nearest first). Exported for tests. */
export function resolveAccess(
  chain: (StructNode & { grant?: Access | null })[],
  userId: string,
  role: WorkspaceRole | null,
): Access {
  for (const node of chain) {
    if (node.grant) return node.grant;
    if (node.visibility === "private") return node.createdBy === userId ? "full" : "none";
  }
  return roleToAccess(role);
}

export interface PageAccess {
  access: Access;
  node: StructNode;
  role: WorkspaceRole | null;
  chain: StructNode[];
}

/** Effective access of a user to one page, walking up parents / databases with a recursive CTE. */
export async function getPageAccess(db: DBorTx, userId: string, pageId: string): Promise<PageAccess | null> {
  const res = await db.execute(sql`
    WITH RECURSIVE chain AS (
      SELECT id, parent_id, database_id, visibility, created_by, workspace_id, archived_at, kind, 0 AS depth
        FROM pages WHERE id = ${pageId}
      UNION ALL
      SELECT p.id, p.parent_id, p.database_id, p.visibility, p.created_by, p.workspace_id, p.archived_at, p.kind, c.depth + 1
        FROM pages p JOIN chain c ON p.id = coalesce(c.parent_id, c.database_id)
       WHERE c.depth < 10000
    )
    SELECT c.*, pp.access AS grant FROM chain c
      LEFT JOIN page_permissions pp ON pp.page_id = c.id AND pp.user_id = ${userId}
     ORDER BY c.depth`);
  const rows = ((res as unknown as { rows: Record<string, unknown>[] }).rows ?? (res as unknown as Record<string, unknown>[])) as Record<
    string,
    unknown
  >[];
  if (!rows.length) return null;
  const chain = rows.map((r) => ({
    id: r.id as string,
    parentId: (r.parent_id as string) ?? null,
    databaseId: (r.database_id as string) ?? null,
    visibility: r.visibility as "workspace" | "private",
    createdBy: (r.created_by as string) ?? null,
    workspaceId: r.workspace_id as string,
    archivedAt: r.archived_at ? new Date(r.archived_at as string) : null,
    kind: r.kind as "page" | "database",
    grant: (r.grant as Access) ?? null,
  }));
  const role = await getRole(db, chain[0].workspaceId, userId);
  return { access: resolveAccess(chain, userId, role), node: chain[0], role, chain };
}

/**
 * Require at least `min` access. Missing pages and pages the user cannot see both yield 404,
 * so IDs cannot be probed. Archived pages are refused unless `allowArchived`.
 */
export async function requirePage(
  db: DBorTx,
  actor: Actor,
  pageId: string,
  min: Access,
  opts: { allowArchived?: boolean } = {},
): Promise<PageAccess> {
  if (typeof pageId !== "string" || pageId.length > 100) throw notFound("Page not found");
  const pa = await getPageAccess(db, actor.userId, pageId);
  if (!pa || pa.access === "none") throw notFound("Page not found");
  if (pa.node.archivedAt && !opts.allowArchived) throw notFound("This page is in the trash");
  if (!atLeast(pa.access, min)) throw forbidden(min === "view" ? "You cannot view this page" : "You do not have permission to edit this page");
  return pa;
}

/**
 * Bulk resolver for list endpoints: loads the structure of a workspace once and answers many
 * access questions in memory.
 */
export class AccessResolver {
  private nodes = new Map<string, StructNode>();
  private grants = new Map<string, Access>();
  private memo = new Map<string, Access>();
  role: WorkspaceRole | null = null;

  private constructor(
    public workspaceId: string,
    public userId: string,
  ) {}

  static async load(db: DBorTx, workspaceId: string, userId: string, opts: { includeRecords?: boolean } = {}) {
    const r = new AccessResolver(workspaceId, userId);
    r.role = await getRole(db, workspaceId, userId);
    const where = opts.includeRecords === false ? and(eq(pages.workspaceId, workspaceId), sql`${pages.databaseId} is null`) : eq(pages.workspaceId, workspaceId);
    const rows = await db
      .select({
        id: pages.id,
        parentId: pages.parentId,
        databaseId: pages.databaseId,
        visibility: pages.visibility,
        createdBy: pages.createdBy,
        workspaceId: pages.workspaceId,
        archivedAt: pages.archivedAt,
        kind: pages.kind,
      })
      .from(pages)
      .where(where);
    for (const n of rows) r.nodes.set(n.id, n);
    const grants = await db
      .select({ pageId: pagePermissions.pageId, access: pagePermissions.access })
      .from(pagePermissions)
      .innerJoin(pages, eq(pages.id, pagePermissions.pageId))
      .where(and(eq(pagePermissions.userId, userId), eq(pages.workspaceId, workspaceId)));
    for (const g of grants) r.grants.set(g.pageId, g.access);
    return r;
  }

  node(id: string) {
    return this.nodes.get(id);
  }

  allNodes() {
    return this.nodes.values();
  }

  access(id: string): Access {
    const cached = this.memo.get(id);
    if (cached) return cached;
    const path: string[] = [];
    let cur: string | null = id;
    let result: Access | null = null;
    const seen = new Set<string>();
    while (cur && !seen.has(cur)) {
      seen.add(cur);
      const memo = this.memo.get(cur);
      if (memo) {
        result = memo;
        break;
      }
      const n = this.nodes.get(cur);
      if (!n) {
        result = "none";
        break;
      }
      path.push(cur);
      const g = this.grants.get(cur);
      if (g) {
        result = g;
        break;
      }
      if (n.visibility === "private") {
        result = n.createdBy === this.userId ? "full" : "none";
        break;
      }
      cur = n.parentId ?? n.databaseId;
    }
    if (result == null) result = roleToAccess(this.role);
    for (const p of path) this.memo.set(p, result);
    return result;
  }

  canView(id: string) {
    return this.access(id) !== "none";
  }

  /** True if the page or any ancestor is archived. */
  isArchived(id: string) {
    let cur: string | null = id;
    const seen = new Set<string>();
    while (cur && !seen.has(cur)) {
      seen.add(cur);
      const n = this.nodes.get(cur);
      if (!n) return false;
      if (n.archivedAt) return true;
      cur = n.parentId ?? n.databaseId;
    }
    return false;
  }
}

/** Pages visible to a user among a set of ids (any workspaces). */
export async function filterVisible(db: DBorTx, userId: string, ids: string[]): Promise<Set<string>> {
  const out = new Set<string>();
  if (!ids.length) return out;
  const rows = await db.select({ id: pages.id, ws: pages.workspaceId }).from(pages).where(inArray(pages.id, ids));
  const byWs = new Map<string, string[]>();
  for (const r of rows) byWs.set(r.ws, [...(byWs.get(r.ws) ?? []), r.id]);
  for (const [ws, list] of byWs) {
    const res = await AccessResolver.load(db, ws, userId);
    for (const id of list) if (res.canView(id) && !res.isArchived(id)) out.add(id);
  }
  return out;
}
