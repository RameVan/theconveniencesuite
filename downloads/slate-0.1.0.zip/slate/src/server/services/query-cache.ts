// Cache of evaluated in-memory queries, so paging through a large text-sorted, searched or grouped
// view doesn't re-evaluate every record per page. Entries are keyed by everything the result
// depends on and validated by a fingerprint of the database's records before every use.
import { createHash } from "node:crypto";
import { sql } from "drizzle-orm";
import type { DBorTx } from "../db";
import { canonicalJson } from "@/lib/blocks";
import type { EvaluatedQuery } from "./compute";

const MAX_ENTRIES = 50;
const TTL_MS = 5 * 60_000;
const cache = new Map<string, { fingerprint: string; at: number; value: EvaluatedQuery }>();

export function queryCacheKey(parts: unknown[]) {
  // The UTC date is part of the key: relative date filters ("past week") change at midnight.
  return createHash("sha256").update(canonicalJson([...parts, new Date().toISOString().slice(0, 10)])).digest("hex");
}

/** Changes whenever a record of the database is added, edited, moved, archived or restored. */
export async function recordsFingerprint(db: DBorTx, databaseId: string): Promise<string> {
  const res = await db.execute(
    sql`select md5(coalesce(string_agg(id || ':' || position || ':' || updated_at::text || ':' || coalesce(archived_at::text, '') || ':' || is_template::text, ',' order by id), '')) as v from pages where database_id = ${databaseId}`,
  );
  const rows = ((res as unknown as { rows?: { v: string }[] }).rows ?? res) as { v: string }[];
  return rows[0]?.v ?? "";
}

export function getCachedQuery(key: string, fingerprint: string): EvaluatedQuery | null {
  const hit = cache.get(key);
  if (!hit || hit.fingerprint !== fingerprint || Date.now() - hit.at > TTL_MS) {
    if (hit) cache.delete(key);
    return null;
  }
  // Refresh LRU position.
  cache.delete(key);
  cache.set(key, hit);
  return hit.value;
}

export function setCachedQuery(key: string, fingerprint: string, value: EvaluatedQuery) {
  cache.set(key, { fingerprint, at: Date.now(), value });
  while (cache.size > MAX_ENTRIES) cache.delete(cache.keys().next().value!);
}
