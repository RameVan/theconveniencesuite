// SQL push-down for database queries. Only filters and sorts whose SQL meaning is identical to the
// in-memory engine (compute.ts: matchCondition / sortKey / compareKeys) are translated; anything
// else returns null and the query runs in memory. tests/query-pushdown.test.ts compares both.
import { sql, type SQL } from "drizzle-orm";
import { pages } from "../db/schema";
import type { FilterCondition, FilterGroup, PropertyDef, RelativeDate, ViewConfig } from "@/lib/db-types";
import { parseDateString } from "@/lib/formula";
import { relativeRange, startOfDayUTC, RELATIVE_SHORTCUTS } from "./compute";

/** Per-query state: the evaluation time, and date properties whose stored values must be canonical. */
interface Ctx {
  now: number;
  dateProps: Map<string, PropertyDef>;
}

const ymd = (ms: number) => new Date(startOfDayUTC(ms)).toISOString().slice(0, 10);

// Dates. Writes store "YYYY-MM-DD" or a UTC ISO timestamp; for those, the first 10 characters are
// the UTC day the in-memory engine compares, and string order is date order. dateValuesCanonical()
// checks that every stored value of the property has one of these forms before SQL is used.
const dateStart = (p: PropertyDef) =>
  sql`(case jsonb_typeof(${val(p)}) when 'string' then ${val(p)} #>> '{}' when 'object' then (case jsonb_typeof(${val(p)} -> 'start') when 'string' then ${val(p)} ->> 'start' end) end)`;
const hasDate = (p: PropertyDef) => sql`coalesce(length(${dateStart(p)}) >= 10, false)`;
const dayOf = (p: PropertyDef) => sql`left(${dateStart(p)}, 10)`;
const endDayOf = (p: PropertyDef) =>
  sql`(case when jsonb_typeof(${val(p)}) = 'object' and jsonb_typeof(${val(p)} -> 'end') = 'string' and ${val(p)} ->> 'end' <> '' then left(${val(p)} ->> 'end', 10) else left(${dateStart(p)}, 10) end)`;

function validDate(x: SQL) {
  return sql`((${x} ~ '^[1-9][0-9]{3}-[0-9]{2}-[0-9]{2}$' and pg_input_is_valid(${x}, 'date')) or (${x} ~ '^[1-9][0-9]{3}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-5][0-9](\\.[0-9]{1,3})?Z$' and pg_input_is_valid(${x}, 'timestamptz')))`;
}

/** SQL that is true when a record's stored date value has a form the SQL date conditions understand. */
export function dateValueCanonical(p: PropertyDef): SQL {
  const v = val(p);
  const str = sql`(${v} #>> '{}')`;
  const start = sql`(${v} ->> 'start')`;
  const end = sql`(${v} ->> 'end')`;
  return sql`(${v} is null or jsonb_typeof(${v}) = 'null'
    or (jsonb_typeof(${v}) = 'string' and (${str} = '' or ${validDate(str)}))
    or (jsonb_typeof(${v}) = 'object' and jsonb_typeof(${v} -> 'start') = 'string' and ${validDate(start)}
        and (${v} -> 'end' is null or jsonb_typeof(${v} -> 'end') = 'null' or (jsonb_typeof(${v} -> 'end') = 'string' and (${end} = '' or ${validDate(end)})))))`;
}

function dateConditionSql(c: FilterCondition, p: PropertyDef, ctx: Ctx): SQL | null {
  const op = c.operator;
  const value = c.value;
  if (op === "is_empty") return sql`(not ${hasDate(p)})`;
  if (op === "is_not_empty") return hasDate(p);
  if (op === "is_checked") return FALSE;
  if (op === "is_not_checked") return TRUE;
  if (value === undefined || value === null || value === "") return TRUE;
  ctx.dateProps.set(p.id, p);
  if (op === "is_relative") {
    if (typeof value !== "string") return null;
    const [s, e] = relativeRange(value as RelativeDate, ctx.now);
    if (!Number.isFinite(s) || !Number.isFinite(e)) return null;
    return sql`(${hasDate(p)} and ${endDayOf(p)} >= ${ymd(s)} and ${dayOf(p)} < ${ymd(e)})`;
  }
  const cmp: Record<string, string> = { equals: "=", not_equals: "<>", before: "<", after: ">", on_or_before: "<=", on_or_after: ">=" };
  if (!cmp[op]) return null;
  // Without a usable target the condition only requires a date (as in matchCondition).
  if (typeof value !== "string") return hasDate(p);
  const target = Object.hasOwn(RELATIVE_SHORTCUTS, value) ? relativeRange(value as RelativeDate, ctx.now)[0] : parseDateString(value)?.start;
  if (target == null) return hasDate(p);
  if (!Number.isFinite(target)) return null;
  return sql`(${hasDate(p)} and ${dayOf(p)} ${sql.raw(cmp[op])} ${ymd(target)})`;
}

const TRUE = sql`true`;
const FALSE = sql`false`;

/** The stored JSON value of a property. */
const val = (p: PropertyDef) => sql`(${pages.properties} -> ${p.id})`;
const isNumber = (p: PropertyDef) => sql`jsonb_typeof(${val(p)}) = 'number'`;
const isString = (p: PropertyDef) => sql`jsonb_typeof(${val(p)}) = 'string'`;
const str = (p: PropertyDef) => sql`(${val(p)} #>> '{}')`;
const textArray = (items: string[]) => sql`ARRAY[${sql.join(items.map((i) => sql`${i}`), sql`, `)}]::text[]`;

function optionIds(p: PropertyDef) {
  return (p.config.options ?? []).map((o) => o.id);
}

function conditionSql(c: FilterCondition, p: PropertyDef | undefined, ctx: Ctx): SQL | null {
  if (!p) return TRUE; // unknown property: the condition is ignored
  if (p.type === "date") return dateConditionSql(c, p, ctx);
  const op = c.operator;
  const value = c.value;
  const incomplete = value === undefined || value === null || value === "";

  if (p.type === "checkbox") {
    const checked = sql`(${val(p)} = 'true'::jsonb)`;
    if (op === "is_checked" || op === "is_not_empty") return checked;
    if (op === "is_not_checked" || op === "is_empty") return sql`(not coalesce(${checked}, false))`;
    return null;
  }

  if (p.type === "select" || p.type === "status") {
    // fv is the option's name (empty when the id is unknown or the name is empty); the cell is the raw id.
    const named = (p.config.options ?? []).filter((o) => o.name !== "").map((o) => o.id);
    const hasName = named.length ? sql`(${isString(p)} and ${str(p)} = any(${textArray(named)}))` : FALSE;
    if (op === "is_empty") return sql`(not coalesce(${hasName}, false))`;
    if (op === "is_not_empty") return sql`coalesce(${hasName}, false)`;
    if (op === "is_checked") return FALSE;
    if (op === "is_not_checked") return TRUE;
    if (incomplete) return TRUE;
    const wanted = Array.isArray(value) ? value.filter((v): v is string => typeof v === "string") : typeof value === "string" ? [value] : null;
    if (!wanted) return null;
    if (Array.isArray(value) && wanted.length !== value.length) return null;
    const equal = wanted.length ? sql`coalesce(${isString(p)} and ${str(p)} = any(${textArray(wanted)}), false)` : FALSE;
    if (op === "equals") return equal;
    if (op === "not_equals") return sql`(not ${equal})`;
    return null;
  }

  if (p.type === "number") {
    if (op === "is_empty") return sql`(not coalesce(${isNumber(p)}, false))`;
    if (op === "is_not_empty") return sql`coalesce(${isNumber(p)}, false)`;
    if (op === "is_checked") return FALSE;
    if (op === "is_not_checked") return TRUE;
    if (incomplete) return TRUE;
    const n = Number(value);
    if (Number.isNaN(n)) return TRUE;
    if (!Number.isFinite(n)) return null;
    const num = sql`(case when ${isNumber(p)} then (${val(p)})::text::double precision end)`;
    const target = sql`${n}::double precision`;
    const cmp = (o: string) => sql`coalesce(${num} ${sql.raw(o)} ${target}, false)`;
    switch (op) {
      case "equals":
        return cmp("=");
      case "not_equals":
        return sql`coalesce(${num} <> ${target}, true)`;
      case "gt":
        return cmp(">");
      case "lt":
        return cmp("<");
      case "gte":
        return cmp(">=");
      case "lte":
        return cmp("<=");
    }
    return null;
  }
  return null;
}

export function filterSql(f: FilterGroup | FilterCondition, props: Map<string, PropertyDef>, ctx: Ctx, depth = 0): SQL | null {
  if (depth > 20) return TRUE;
  if (f.kind === "condition") {
    if (f.propertyId === "title") return null; // the title is text: compared in memory
    return conditionSql(f, props.get(f.propertyId), ctx);
  }
  if (!f.filters?.length) return TRUE;
  const parts: SQL[] = [];
  for (const x of f.filters) {
    const s = filterSql(x, props, ctx, depth + 1);
    if (!s) return null;
    parts.push(s);
  }
  return sql`(${sql.join(parts, f.op === "or" ? sql` or ` : sql` and `)})`;
}

/** ORDER BY terms equal to the in-memory sort (empty values last in both directions). */
export function orderSql(config: ViewConfig, props: Map<string, PropertyDef>): SQL[] | null {
  const tail = [sql`${pages.position} asc`, sql`${pages.createdAt} asc`, sql`${pages.id} asc`];
  const sorts = (config.sorts ?? []).filter((s) => s.propertyId === "title" || props.has(s.propertyId));
  if (!sorts.length) {
    const manual = config.manualOrder ?? [];
    if (!manual.length) return tail;
    // Duplicated ids order by their last position in memory: leave those to the in-memory engine.
    if (manual.some((id) => typeof id !== "string") || new Set(manual).size !== manual.length) return null;
    return [sql`array_position(${textArray(manual)}, ${pages.id}) asc nulls last`, ...tail];
  }
  const out: SQL[] = [];
  for (const s of sorts) {
    if (s.propertyId === "title") return null; // text order uses locale-aware comparison in memory
    const p = props.get(s.propertyId)!;
    const dir = sql.raw(s.direction === "desc" ? "desc" : "asc");
    let key: SQL;
    if (p.type === "number") key = sql`(case when ${isNumber(p)} then (${val(p)})::text::double precision end)`;
    else if (p.type === "checkbox") key = sql`(case when ${val(p)} = 'true'::jsonb then 1 else 0 end)`;
    else if (p.type === "select" || p.type === "status") {
      const ids = optionIds(p);
      key = ids.length ? sql`(case when ${isString(p)} then array_position(${textArray(ids)}, ${str(p)}) end)` : sql`(null::int)`;
    } else return null;
    out.push(sql`(${key}) is null asc`, sql`${key} ${dir}`);
  }
  return [...out, ...tail];
}

/**
 * WHERE and ORDER BY for a view, or null if it must run in memory. `dateProps`: date properties the
 * WHERE relies on; the caller must check their stored values with dateValueCanonical() first.
 */
export function sqlPlan(config: ViewConfig, props: PropertyDef[], search: string | null | undefined, now = Date.now()) {
  if (search?.trim()) return null;
  if (config.groupBy) return null;
  if (Object.values(config.aggregations ?? {}).some((a) => a && a !== "none")) return null;
  const byId = new Map(props.map((p) => [p.id, p]));
  const ctx: Ctx = { now, dateProps: new Map() };
  const where = config.filter ? filterSql(config.filter, byId, ctx) : TRUE;
  if (!where) return null;
  const order = orderSql(config, byId);
  if (!order) return null;
  return { where, order, dateProps: [...ctx.dateProps.values()] };
}
