import { and, asc, desc, eq, inArray } from "drizzle-orm";
import type { DB, DBorTx } from "../db";
import { pages, blocks, pageRevisions, relationLinks, users, databaseProperties } from "../db/schema";
import { newId, sha256 } from "../crypto";
import { config } from "../config";
import { notFound, badRequest } from "../errors";
import type { Actor } from "./auth";
import { requirePage } from "./permissions";
import { validateBlocks, nodeText, type PMNode } from "@/lib/blocks";

export interface Snapshot {
  title: string;
  icon: string | null;
  cover: string | null;
  properties: Record<string, unknown>;
  relations: { propertyId: string; toPageId: string; position: number }[];
  blocks: PMNode[];
}

async function currentSnapshot(db: DBorTx, pageId: string): Promise<Snapshot | null> {
  const page = await db.query.pages.findFirst({ where: eq(pages.id, pageId) });
  if (!page) return null;
  const rows = await db.select({ content: blocks.content }).from(blocks).where(eq(blocks.pageId, pageId)).orderBy(asc(blocks.position));
  const rel = page.databaseId
    ? await db.select({ propertyId: relationLinks.propertyId, toPageId: relationLinks.toPageId, position: relationLinks.position }).from(relationLinks).where(eq(relationLinks.fromPageId, pageId))
    : [];
  return {
    title: page.title,
    icon: page.icon,
    cover: page.cover,
    properties: page.properties ?? {},
    relations: rel,
    blocks: rows.map((r) => r.content as unknown as PMNode),
  };
}

const hashOf = (s: Snapshot) => sha256(JSON.stringify([s.title, s.icon, s.cover, s.properties, s.relations, s.blocks]));

/** Write a snapshot unconditionally (deduplicated against the latest one). Returns the revision id. */
export async function snapshotPage(db: DBorTx, pageId: string, userId: string | null, reason: string, override?: Partial<Snapshot>) {
  const cur = await currentSnapshot(db, pageId);
  if (!cur) return null;
  const snap = { ...cur, ...override };
  const hash = hashOf(snap);
  const [latest] = await db.select({ id: pageRevisions.id, hash: pageRevisions.hash }).from(pageRevisions).where(eq(pageRevisions.pageId, pageId)).orderBy(desc(pageRevisions.createdAt)).limit(1);
  if (latest?.hash === hash && reason !== "conflict") return latest.id;
  const id = newId();
  await db.insert(pageRevisions).values({ id, pageId, createdBy: userId, reason, hash, snapshot: snap as unknown as Record<string, unknown> });
  return id;
}

/**
 * Called after saves. Writes a snapshot when the newest one is older than the configured interval
 * (or there is none), so history has at most one automatic entry per interval while editing.
 */
export async function maybeSnapshot(db: DBorTx, pageId: string, userId: string | null) {
  const [latest] = await db
    .select({ createdAt: pageRevisions.createdAt, reason: pageRevisions.reason })
    .from(pageRevisions)
    .where(eq(pageRevisions.pageId, pageId))
    .orderBy(desc(pageRevisions.createdAt))
    .limit(1);
  const interval = config.revisionIntervalSeconds * 1000;
  if (latest && latest.reason !== "conflict" && Date.now() - latest.createdAt.getTime() < interval) return null;
  return snapshotPage(db, pageId, userId, "autosave");
}

export async function listRevisions(db: DB, actor: Actor, pageId: string) {
  await requirePage(db, actor, pageId, "view", { allowArchived: true });
  const rows = await db
    .select({ id: pageRevisions.id, createdAt: pageRevisions.createdAt, reason: pageRevisions.reason, userId: pageRevisions.createdBy, userName: users.name })
    .from(pageRevisions)
    .leftJoin(users, eq(users.id, pageRevisions.createdBy))
    .where(eq(pageRevisions.pageId, pageId))
    .orderBy(desc(pageRevisions.createdAt))
    .limit(500);
  return rows;
}

export async function getRevision(db: DB, actor: Actor, pageId: string, revisionId: string) {
  await requirePage(db, actor, pageId, "view", { allowArchived: true });
  const [row] = await db.select().from(pageRevisions).where(and(eq(pageRevisions.id, revisionId), eq(pageRevisions.pageId, pageId)));
  if (!row) throw notFound("Revision not found");
  return { id: row.id, createdAt: row.createdAt, reason: row.reason, snapshot: row.snapshot as unknown as Snapshot };
}

/**
 * Restore a revision. The current state is snapshotted first so the restore can be undone.
 * Property values referring to deleted properties are dropped; relation links are restored only
 * to records that still exist and are not in the trash.
 */
export async function restoreRevision(db: DB, actor: Actor, pageId: string, revisionId: string) {
  await requirePage(db, actor, pageId, "edit");
  const rev = await getRevision(db, actor, pageId, revisionId);
  const snap = rev.snapshot;
  let valid;
  try {
    valid = validateBlocks((snap.blocks ?? []).map((b) => ({ id: b.attrs?.id, content: b })));
  } catch (e) {
    throw badRequest(`This revision cannot be restored: ${(e as Error).message}`);
  }
  return db.transaction(async (tx) => {
    await snapshotPage(tx, pageId, actor.userId, "before-restore");
    const page = await tx.query.pages.findFirst({ where: eq(pages.id, pageId) });
    if (!page) throw notFound();
    let properties = page.properties;
    if (page.databaseId) {
      const props = await tx.select({ id: databaseProperties.id, type: databaseProperties.type }).from(databaseProperties).where(eq(databaseProperties.databaseId, page.databaseId));
      const known = new Set(props.map((p) => p.id));
      properties = Object.fromEntries(Object.entries(snap.properties ?? {}).filter(([k]) => known.has(k)));
      // Keep unique IDs stable: they are identity, not content.
      for (const p of props) if (p.type === "unique_id" && page.properties[p.id] != null) properties[p.id] = page.properties[p.id];
      const relProps = props.filter((p) => p.type === "relation").map((p) => p.id);
      if (relProps.length) {
        await tx.delete(relationLinks).where(and(eq(relationLinks.fromPageId, pageId), inArray(relationLinks.propertyId, relProps)));
        const wanted = (snap.relations ?? []).filter((r) => relProps.includes(r.propertyId));
        const targets = wanted.length ? await tx.select({ id: pages.id, archivedAt: pages.archivedAt }).from(pages).where(inArray(pages.id, wanted.map((w) => w.toPageId))) : [];
        const alive = new Set(targets.filter((t) => !t.archivedAt).map((t) => t.id));
        const { setRelationLinksRaw } = await import("./databases");
        for (const propId of relProps) {
          const ids = wanted.filter((w) => w.propertyId === propId && alive.has(w.toPageId)).map((w) => w.toPageId);
          await setRelationLinksRaw(tx, propId, pageId, ids);
        }
      }
    }
    await tx.delete(blocks).where(eq(blocks.pageId, pageId));
    const now = new Date();
    for (let i = 0; i < valid.length; i++) {
      const b = valid[i];
      await tx.insert(blocks).values({ pageId, id: b.id, position: i, type: b.type, content: b.content as unknown as Record<string, unknown>, text: nodeText(b.content), updatedAt: now, updatedBy: actor.userId });
    }
    const [row] = await tx
      .update(pages)
      .set({ title: snap.title ?? page.title, icon: snap.icon ?? null, cover: snap.cover ?? null, properties, version: page.version + 1, updatedAt: now, updatedBy: actor.userId })
      .where(eq(pages.id, pageId))
      .returning({ version: pages.version });
    await snapshotPage(tx, pageId, actor.userId, "restore");
    return { version: row.version };
  });
}
