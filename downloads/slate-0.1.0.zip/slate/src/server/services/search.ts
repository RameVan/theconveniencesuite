import { and, eq, isNull, sql, inArray, desc } from "drizzle-orm";
import { z } from "zod";
import type { DB } from "../db";
import { pages, blocks } from "../db/schema";
import type { Actor } from "./auth";
import { AccessResolver } from "./permissions";
import { listWorkspaces } from "./workspaces";
import { recentPages } from "./pages";

export const searchInput = z.object({
  q: z.string().max(500).default(""),
  workspaceId: z.string().max(100).nullable().optional(),
  type: z.enum(["page", "database", "record"]).nullable().optional(),
  limit: z.number().int().min(1).max(100).default(30),
});

export interface SearchResult {
  id: string;
  workspaceId: string;
  title: string;
  icon: string | null;
  kind: "page" | "database";
  databaseId: string | null;
  type: "page" | "database" | "record";
  snippet: string | null;
  matchedIn: "title" | "content" | "property";
  path: string[];
  updatedAt: string;
  score: number;
}

function toTsQuery(q: string): string | null {
  const terms = q
    .toLowerCase()
    .split(/[^\p{L}\p{N}]+/u)
    .filter((t) => t.length > 0)
    .slice(0, 12);
  if (!terms.length) return null;
  return terms.map((t) => `${t}:*`).join(" & ");
}

const likeEscape = (s: string) => s.replace(/[%_\\]/g, "\\$&");

function snippetOf(text: string, q: string, width = 140): string {
  const lower = text.toLowerCase();
  const terms = q.toLowerCase().split(/\s+/).filter(Boolean);
  let idx = -1;
  for (const t of terms) {
    idx = lower.indexOf(t);
    if (idx >= 0) break;
  }
  if (idx < 0) return text.slice(0, width);
  const start = Math.max(0, idx - Math.floor(width / 3));
  return (start > 0 ? "…" : "") + text.slice(start, start + width).replace(/\s+/g, " ") + (start + width < text.length ? "…" : "");
}

/**
 * Permission-aware search across titles, block text and text-like record properties.
 * Results the actor cannot see are filtered out before anything is returned.
 */
export async function search(db: DB, actor: Actor, input: z.input<typeof searchInput>): Promise<SearchResult[]> {
  const data = searchInput.parse(input);
  const q = data.q.trim();
  const wsIds = data.workspaceId ? [data.workspaceId] : (await listWorkspaces(db, actor)).map((w) => w.id);
  if (!wsIds.length) return [];

  if (!q) {
    if (!data.workspaceId) return [];
    const recent = await recentPages(db, actor, data.workspaceId, data.limit);
    return recent.map((r) => ({
      id: r.id,
      workspaceId: data.workspaceId!,
      title: r.title,
      icon: r.icon,
      kind: r.kind,
      databaseId: r.databaseId,
      type: r.kind === "database" ? "database" : r.databaseId ? "record" : "page",
      snippet: null,
      matchedIn: "title",
      path: [],
      updatedAt: r.visitedAt.toISOString(),
      score: 0,
    }));
  }

  const tsq = toTsQuery(q);
  const like = `%${likeEscape(q)}%`;
  const titleMatch = tsq ? sql`(${pages.search} @@ to_tsquery('simple', ${tsq}) OR ${pages.title} ILIKE ${like})` : sql`${pages.title} ILIKE ${like}`;
  const typeFilter =
    data.type === "database" ? sql`${pages.kind} = 'database'` : data.type === "record" ? sql`${pages.databaseId} IS NOT NULL` : data.type === "page" ? sql`${pages.kind} = 'page' AND ${pages.databaseId} IS NULL` : sql`true`;
  const base = and(inArray(pages.workspaceId, wsIds), isNull(pages.archivedAt), eq(pages.isTemplate, false), typeFilter);

  const cols = { id: pages.id, workspaceId: pages.workspaceId, title: pages.title, icon: pages.icon, kind: pages.kind, databaseId: pages.databaseId, updatedAt: pages.updatedAt };
  const titleRows = await db.select(cols).from(pages).where(and(base, titleMatch)).orderBy(desc(pages.updatedAt)).limit(300);
  const contentMatch = tsq ? sql`(${blocks.search} @@ to_tsquery('simple', ${tsq}) OR ${blocks.text} ILIKE ${like})` : sql`${blocks.text} ILIKE ${like}`;
  const contentRows = await db
    .select({ ...cols, text: blocks.text })
    .from(blocks)
    .innerJoin(pages, eq(pages.id, blocks.pageId))
    .where(and(base, contentMatch))
    .orderBy(desc(pages.updatedAt))
    .limit(300);
  const propRows =
    data.type === "page" || data.type === "database"
      ? []
      : await db
          .select({ ...cols, props: pages.properties })
          .from(pages)
          .where(and(base, sql`${pages.databaseId} IS NOT NULL`, sql`${pages.properties}::text ILIKE ${like}`))
          .limit(200);

  const results = new Map<string, SearchResult>();
  const lowerQ = q.toLowerCase();
  const add = (r: (typeof titleRows)[number], matchedIn: SearchResult["matchedIn"], snippet: string | null, score: number) => {
    const prev = results.get(r.id);
    if (prev && prev.score >= score) {
      if (!prev.snippet && snippet) prev.snippet = snippet;
      return;
    }
    results.set(r.id, {
      id: r.id,
      workspaceId: r.workspaceId,
      title: r.title,
      icon: r.icon,
      kind: r.kind,
      databaseId: r.databaseId,
      type: r.kind === "database" ? "database" : r.databaseId ? "record" : "page",
      snippet: snippet ?? prev?.snippet ?? null,
      matchedIn,
      path: [],
      updatedAt: r.updatedAt.toISOString(),
      score,
    });
  };
  for (const r of titleRows) {
    const t = r.title.toLowerCase();
    add(r, "title", null, t === lowerQ ? 100 : t.startsWith(lowerQ) ? 80 : t.includes(lowerQ) ? 60 : 50);
  }
  for (const r of contentRows) add(r, "content", snippetOf(r.text, q), r.text.toLowerCase().includes(lowerQ) ? 40 : 30);
  for (const r of propRows) {
    const texts = Object.values(r.props ?? {}).filter((v): v is string => typeof v === "string" && v.toLowerCase().includes(lowerQ));
    if (texts.length) add(r, "property", snippetOf(texts[0], q), 35);
  }

  // Permission filtering and breadcrumb paths, per workspace.
  const out: SearchResult[] = [];
  const byWs = new Map<string, SearchResult[]>();
  for (const r of results.values()) byWs.set(r.workspaceId, [...(byWs.get(r.workspaceId) ?? []), r]);
  for (const [ws, list] of byWs) {
    const resolver = await AccessResolver.load(db, ws, actor.userId);
    const visible = list.filter((r) => resolver.canView(r.id) && !resolver.isArchived(r.id));
    const ancestorIds = new Set<string>();
    for (const r of visible) {
      let cur = resolver.node(r.id);
      let guard = 0;
      while (cur && guard++ < 50) {
        const parent: string | null = cur.parentId ?? cur.databaseId;
        if (!parent) break;
        ancestorIds.add(parent);
        cur = resolver.node(parent);
      }
    }
    const titles = ancestorIds.size
      ? new Map((await db.select({ id: pages.id, title: pages.title }).from(pages).where(inArray(pages.id, [...ancestorIds]))).map((x) => [x.id, x.title]))
      : new Map<string, string>();
    for (const r of visible) {
      const path: string[] = [];
      let cur = resolver.node(r.id);
      let guard = 0;
      while (cur && guard++ < 50) {
        const parent: string | null = cur.parentId ?? cur.databaseId;
        if (!parent || !resolver.canView(parent)) break;
        path.unshift(titles.get(parent) || "Untitled");
        cur = resolver.node(parent);
      }
      r.path = path;
      out.push(r);
    }
  }
  return out.sort((a, b) => b.score - a.score || b.updatedAt.localeCompare(a.updatedAt)).slice(0, data.limit);
}
