import { and, eq, isNull, asc, inArray } from "drizzle-orm";
import { z } from "zod";
import type { DB } from "../db";
import { pages, pagePermissions, users, blocks } from "../db/schema";
import { randomToken } from "../crypto";
import { badRequest, forbidden, notFound } from "../errors";
import { config } from "../config";
import type { Actor } from "./auth";
import { emailSchema } from "./auth";
import { requirePage, getRole } from "./permissions";
import { getBlocks, pageSummary } from "./pages";
import { audit } from "./audit";
import { loadDatabaseMeta } from "./databases";
import { Computer, runQuery } from "./compute";
import type { ViewConfig, ViewDef } from "@/lib/db-types";

export async function getSharing(db: DB, actor: Actor, pageId: string) {
  const pa = await requirePage(db, actor, pageId, "view");
  const grants = await db
    .select({ userId: users.id, name: users.name, email: users.email, access: pagePermissions.access })
    .from(pagePermissions)
    .innerJoin(users, eq(users.id, pagePermissions.userId))
    .where(eq(pagePermissions.pageId, pageId));
  const [page] = await db.select({ token: pages.publicShareToken, visibility: pages.visibility }).from(pages).where(eq(pages.id, pageId));
  const isPrivate = pa.chain.some((n) => n.visibility === "private");
  return {
    access: pa.access,
    isPrivate,
    canChangeVisibility: !pa.node.parentId && !pa.node.databaseId && (pa.access === "full" || pa.node.createdBy === actor.userId),
    grants,
    publicSharingEnabled: config.allowPublicSharing,
    publicToken: pa.access === "full" ? page.token : null,
    inheritedFrom: pa.chain.find((n, i) => i > 0 && n.visibility === "private")?.id ?? null,
  };
}

export const grantInput = z.object({ email: emailSchema, access: z.enum(["none", "view", "edit", "full"]).nullable() });

/** Give (or remove, with access=null) a user's explicit access to a page and its sub-pages. */
export async function setUserAccess(db: DB, actor: Actor, pageId: string, input: z.input<typeof grantInput>) {
  const pa = await requirePage(db, actor, pageId, "full");
  const data = grantInput.parse(input);
  const user = await db.query.users.findFirst({ where: eq(users.email, data.email) });
  if (!user) throw notFound("No account uses that email. Invite them to the workspace first.");
  if (user.id === actor.userId && data.access !== "full" && data.access !== null) throw badRequest("You cannot lower your own access");
  if (data.access === null) {
    await db.delete(pagePermissions).where(and(eq(pagePermissions.pageId, pageId), eq(pagePermissions.userId, user.id)));
  } else {
    await db
      .insert(pagePermissions)
      .values({ pageId, userId: user.id, access: data.access, grantedBy: actor.userId })
      .onConflictDoUpdate({ target: [pagePermissions.pageId, pagePermissions.userId], set: { access: data.access, grantedBy: actor.userId } });
  }
  await audit(db, { workspaceId: pa.node.workspaceId, userId: actor.userId, action: "page.share", targetId: pageId, meta: { user: user.id, access: data.access } });
  return getSharing(db, actor, pageId);
}

export async function setPublicShare(db: DB, actor: Actor, pageId: string, enabled: boolean) {
  const pa = await requirePage(db, actor, pageId, "full");
  if (enabled && !config.allowPublicSharing) throw forbidden("Public links are disabled by the server administrator");
  const token = enabled ? randomToken(24) : null;
  const [cur] = await db.select({ token: pages.publicShareToken }).from(pages).where(eq(pages.id, pageId));
  if (enabled && cur.token) return { token: cur.token };
  await db.update(pages).set({ publicShareToken: token }).where(eq(pages.id, pageId));
  await audit(db, { workspaceId: pa.node.workspaceId, userId: actor.userId, action: enabled ? "page.publish" : "page.unpublish", targetId: pageId });
  return { token };
}

// ---------------------------------------------------------------- public (anonymous) access

/** Resolve a public share token and check that `pageId` is the shared page or inside it. */
async function resolveShare(db: DB, token: string, pageId?: string) {
  if (!config.allowPublicSharing) throw notFound("Public links are disabled on this server");
  if (!token || token.length > 100) throw notFound();
  const [root] = await db.select().from(pages).where(eq(pages.publicShareToken, token));
  if (!root || root.archivedAt) throw notFound("This link is no longer active");
  const target = pageId ?? root.id;
  if (target !== root.id) {
    // Walk up from the target to make sure it lives under the shared root, unarchived.
    let cur: string | null = target;
    let found = false;
    const seen = new Set<string>();
    while (cur && !seen.has(cur)) {
      seen.add(cur);
      const [n] = await db.select({ id: pages.id, parentId: pages.parentId, databaseId: pages.databaseId, archivedAt: pages.archivedAt, visibility: pages.visibility }).from(pages).where(eq(pages.id, cur));
      if (!n || n.archivedAt) break;
      if (n.id === root.id) {
        found = true;
        break;
      }
      // A private sub-page is never exposed through a parent's public link.
      if (n.visibility === "private") break;
      cur = n.parentId ?? n.databaseId;
    }
    if (!found) throw notFound();
  }
  return { root, targetId: target };
}

export async function getPublicPage(db: DB, token: string, pageId?: string) {
  const { root, targetId } = await resolveShare(db, token, pageId);
  const [page] = await db.select().from(pages).where(eq(pages.id, targetId));
  const content = await getBlocks(db, targetId);
  const children = await db
    .select({ id: pages.id, title: pages.title, icon: pages.icon, kind: pages.kind, databaseId: pages.databaseId, parentId: pages.parentId, visibility: pages.visibility })
    .from(pages)
    .where(and(eq(pages.parentId, targetId), isNull(pages.archivedAt)))
    .orderBy(asc(pages.position));
  const database = page.kind === "database" ? await loadDatabaseMeta(db, page.id) : null;
  let record = null;
  if (page.databaseId) {
    const meta = await loadDatabaseMeta(db, page.databaseId);
    const computer = new Computer(db);
    await computer.loadProps(page.databaseId);
    await computer.loadRecordsById([page.id]);
    await computer.prepare(page.databaseId, [page.id]);
    const res = runQuery({ props: meta.properties, records: [computer.record(page.id)!], computer, config: {} });
    record = { database: { id: meta.id, title: meta.title, icon: meta.icon }, properties: meta.properties, values: res.rows[0].values, refs: { pages: {}, users: {} } };
  }
  return {
    rootId: root.id,
    page: { id: page.id, title: page.title, icon: page.icon, cover: page.cover, kind: page.kind, fullWidth: page.fullWidth, smallText: page.smallText, databaseId: page.databaseId, updatedAt: page.updatedAt },
    content,
    children: children.filter((c) => c.visibility !== "private").map(pageSummary),
    database,
    record,
  };
}

export async function queryPublicDatabase(db: DB, token: string, databaseId: string, viewId?: string | null, block?: { pageId: string; blockId: string } | null) {
  await resolveShare(db, token, databaseId);
  const meta = await loadDatabaseMeta(db, databaseId);
  if (!meta.properties.length) throw notFound();
  let views = meta.views;
  if (block) {
    // A linked block with its own views: read them from the block on the shared page.
    await resolveShare(db, token, block.pageId);
    const [row] = await db.select({ content: blocks.content }).from(blocks).where(and(eq(blocks.pageId, block.pageId), eq(blocks.id, block.blockId)));
    const node = row?.content as { type?: string; attrs?: { databaseId?: string; views?: unknown } } | undefined;
    if (!node || node.type !== "databaseView" || node.attrs?.databaseId !== databaseId) throw notFound();
    const own = Array.isArray(node.attrs.views) ? (node.attrs.views as ViewDef[]).filter((v) => v && typeof v.id === "string" && typeof v.type === "string") : [];
    if (own.length) views = own.map((v, i) => ({ id: v.id, databaseId, name: String(v.name ?? "View"), type: v.type, config: (v.config ?? {}) as ViewConfig, position: i }));
  }
  const view = views.find((v) => v.id === viewId) ?? views[0];
  const computer = new Computer(db);
  const props = await computer.loadProps(databaseId);
  const records = await computer.loadRecords(databaseId);
  // Records that are private-by-grant are still records of the shared database; relation targets
  // outside the share are shown by title only when they are inside the shared tree.
  const shareRoot = await resolveShare(db, token);
  const inside = new Set<string>(records.map((r) => r.id));
  computer.canView = (id) => inside.has(id) || id === shareRoot.root.id;
  await computer.prepare(databaseId, records.map((r) => r.id));
  const result = runQuery({ props, records, computer, config: (view?.config ?? {}) as ViewConfig });
  return { ...result, refs: { pages: {}, users: {} }, views, properties: meta.properties };
}

export async function canManageSharing(db: DB, actor: Actor, workspaceId: string) {
  return !!(await getRole(db, workspaceId, actor.userId));
}

export { inArray };
