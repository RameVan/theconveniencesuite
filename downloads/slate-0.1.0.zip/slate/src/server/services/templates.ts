import { eq, asc } from "drizzle-orm";
import { z } from "zod";
import type { DB } from "../db";
import { databaseProperties, databaseViews } from "../db/schema";
import { badRequest } from "../errors";
import type { Actor } from "./auth";
import { createPage, saveContent } from "./pages";
import { addProperty, createRecord, createView, updateProperty, deleteProperty, updateView, loadDatabaseMeta } from "./databases";
import * as B from "@/lib/block-builders";
import type { PMNode } from "@/lib/blocks";
import type { PropertyType, ViewType, ViewConfig, PropertyConfig } from "@/lib/db-types";

interface DbSpec {
  properties: { name: string; type: PropertyType; config?: PropertyConfig; options?: string[] }[];
  views: { name: string; type: ViewType; groupBy?: string; dateProperty?: string; sorts?: { prop: string; direction: "asc" | "desc" }[]; visible?: string[] }[];
  records: { title: string; icon?: string; values?: Record<string, unknown> }[];
  titleName?: string;
}

interface TemplateSpec {
  key: string;
  kind: "page" | "database";
  title: string;
  icon: string;
  description: string;
  category: string;
  blocks?: () => PMNode[];
  database?: DbSpec;
}

const today = () => new Date().toISOString().slice(0, 10);
const inDays = (n: number) => new Date(Date.now() + n * 86_400_000).toISOString().slice(0, 10);

export const TEMPLATES: TemplateSpec[] = [
  {
    key: "meeting-notes",
    kind: "page",
    title: "Meeting notes",
    icon: "🗓️",
    category: "Work",
    description: "Agenda, notes and action items for a meeting.",
    blocks: () => [
      B.callout("💡", "Date: " + today() + " · Attendees: "),
      B.h(2, "Agenda"),
      B.numbered(["", ""]),
      B.h(2, "Notes"),
      B.p(""),
      B.h(2, "Action items"),
      B.todos([["", false]]),
    ],
  },
  {
    key: "project-brief",
    kind: "page",
    title: "Project brief",
    icon: "🚀",
    category: "Work",
    description: "Problem, goals, scope and milestones for a new project.",
    blocks: () => [
      B.toc(),
      B.h(2, "Problem"),
      B.p("What problem are we solving, and for whom?"),
      B.h(2, "Goals"),
      B.bullets(["", ""]),
      B.h(2, "Non-goals"),
      B.bullets([""]),
      B.h(2, "Milestones"),
      B.todos([["Kick-off", false], ["First prototype", false], ["Launch", false]]),
      B.h(2, "Risks"),
      B.toggle("Open questions", [B.p("")]),
    ],
  },
  {
    key: "weekly-journal",
    kind: "page",
    title: "Weekly journal",
    icon: "📓",
    category: "Personal",
    description: "Reflect on the week: wins, lessons and next steps.",
    blocks: () => [B.h(2, "Wins"), B.bullets([""]), B.h(2, "Lessons"), B.bullets([""]), B.h(2, "Next week"), B.todos([["", false]]), B.quote("What would make next week great?")],
  },
  {
    key: "product-spec",
    kind: "page",
    title: "Product spec",
    icon: "📐",
    category: "Engineering",
    description: "Requirements, design and rollout plan for a feature.",
    blocks: () => [
      B.callout("📌", "Status: Draft · Owner: · Reviewers:", "blue"),
      B.toc(),
      B.h(2, "Summary"),
      B.p(""),
      B.h(2, "Requirements"),
      B.todos([["", false]]),
      B.h(2, "Design"),
      B.p(""),
      B.code("typescript", "// API sketch"),
      B.h(2, "Rollout"),
      B.numbered(["Internal testing", "Beta", "General availability"]),
    ],
  },
  {
    key: "task-tracker",
    kind: "database",
    title: "Tasks",
    icon: "✅",
    category: "Work",
    description: "Track tasks by status, priority, assignee and due date.",
    database: {
      titleName: "Task",
      properties: [
        { name: "Status", type: "status" },
        { name: "Priority", type: "select", options: ["High", "Medium", "Low"] },
        { name: "Due", type: "date" },
        { name: "Assignee", type: "person" },
        { name: "Estimate (h)", type: "number" },
        { name: "Overdue", type: "formula", config: { expression: 'if(empty(prop("Due")), false, prop("Due") < today() and prop("Status") != "Done")' } },
      ],
      views: [
        { name: "All tasks", type: "table" },
        { name: "Board", type: "board", groupBy: "Status" },
        { name: "Calendar", type: "calendar", dateProperty: "Due" },
        { name: "By priority", type: "chart", groupBy: "Priority" },
      ],
      records: [
        { title: "Write the project brief", values: { Status: "Done", Priority: "High", Due: today(), "Estimate (h)": 2 } },
        { title: "Review designs", values: { Status: "In progress", Priority: "Medium", Due: inDays(2), "Estimate (h)": 3 } },
        { title: "Plan the launch", values: { Status: "Not started", Priority: "Low", Due: inDays(7), "Estimate (h)": 5 } },
      ],
    },
  },
  {
    key: "crm",
    kind: "database",
    title: "Contacts",
    icon: "🤝",
    category: "Sales",
    description: "Companies and people with stage, value and next follow-up.",
    database: {
      titleName: "Name",
      properties: [
        { name: "Company", type: "rich_text" },
        { name: "Stage", type: "select", options: ["Lead", "Contacted", "Proposal", "Won", "Lost"] },
        { name: "Deal value", type: "number", config: { format: "dollar" } },
        { name: "Email", type: "email" },
        { name: "Next follow-up", type: "date" },
      ],
      views: [
        { name: "Pipeline", type: "board", groupBy: "Stage" },
        { name: "All contacts", type: "table" },
      ],
      records: [{ title: "Ada Example", values: { Company: "Example Co.", Stage: "Lead", "Deal value": 5000, Email: "ada@example.com" } }],
    },
  },
  {
    key: "reading-list",
    kind: "database",
    title: "Reading list",
    icon: "📚",
    category: "Personal",
    description: "Books and articles with type, rating and status.",
    database: {
      titleName: "Title",
      properties: [
        { name: "Author", type: "rich_text" },
        { name: "Type", type: "select", options: ["Book", "Article", "Paper", "Podcast"] },
        { name: "Status", type: "status" },
        { name: "Rating", type: "select", options: ["★★★★★", "★★★★", "★★★", "★★", "★"] },
        { name: "Link", type: "url" },
      ],
      views: [
        { name: "Gallery", type: "gallery" },
        { name: "Table", type: "table" },
      ],
      records: [{ title: "The Design of Everyday Things", values: { Author: "Don Norman", Type: "Book", Status: "Not started" } }],
    },
  },
  {
    key: "roadmap",
    kind: "database",
    title: "Roadmap",
    icon: "🗺️",
    category: "Engineering",
    description: "Projects on a timeline with team and quarter.",
    database: {
      titleName: "Project",
      properties: [
        { name: "Timeline", type: "date" },
        { name: "Team", type: "multi_select", options: ["Design", "Engineering", "Marketing"] },
        { name: "Status", type: "status" },
        { name: "Key", type: "unique_id", config: { prefix: "PRJ" } },
      ],
      views: [
        { name: "Timeline", type: "timeline", dateProperty: "Timeline" },
        { name: "Table", type: "table" },
      ],
      records: [
        { title: "Onboarding revamp", values: { Timeline: { start: today(), end: inDays(21) }, Team: ["Design", "Engineering"], Status: "In progress" } },
        { title: "Pricing page", values: { Timeline: { start: inDays(14), end: inDays(35) }, Team: ["Marketing"], Status: "Not started" } },
      ],
    },
  },
];

export function listTemplates() {
  return TEMPLATES.map(({ key, kind, title, icon, description, category }) => ({ key, kind, title, icon, description, category }));
}

export const applyTemplateInput = z.object({
  key: z.string().max(100),
  workspaceId: z.string().max(100),
  parentId: z.string().max(100).nullable().optional(),
  visibility: z.enum(["workspace", "private"]).optional(),
});

/** Create a new page (or database) from a built-in template. */
export async function applyTemplate(db: DB, actor: Actor, input: z.infer<typeof applyTemplateInput>) {
  const data = applyTemplateInput.parse(input);
  const spec = TEMPLATES.find((t) => t.key === data.key);
  if (!spec) throw badRequest("Unknown template");
  if (spec.kind === "page") {
    const page = await createPage(db, actor, {
      workspaceId: data.workspaceId,
      parentId: data.parentId ?? null,
      title: spec.title,
      icon: spec.icon,
      visibility: data.visibility,
      blocks: spec.blocks!().map((b) => ({ id: b.attrs!.id, content: b })),
    });
    return page;
  }
  return createDatabaseFromSpec(db, actor, data.workspaceId, data.parentId ?? null, spec, data.visibility);
}

async function createDatabaseFromSpec(db: DB, actor: Actor, workspaceId: string, parentId: string | null, spec: TemplateSpec, visibility?: "workspace" | "private") {
  const d = spec.database!;
  const page = await createPage(db, actor, { workspaceId, parentId, title: spec.title, icon: spec.icon, kind: "database", visibility });
  const meta = await loadDatabaseMeta(db, page.id);
  const titleProp = meta.properties.find((p) => p.type === "title")!;
  if (d.titleName) await updateProperty(db, actor, titleProp.id, { name: d.titleName });
  const tags = meta.properties.find((p) => p.type === "multi_select" && p.name === "Tags");
  if (tags && !d.properties.some((p) => p.name === "Tags")) await deleteProperty(db, actor, tags.id);
  const ids: Record<string, string> = { [d.titleName ?? "Name"]: titleProp.id };
  for (const p of d.properties) {
    const config: PropertyConfig = { ...(p.config ?? {}) };
    if (p.options) config.options = p.options.map((name, i) => ({ id: crypto.randomUUID(), name, color: (["red", "yellow", "blue", "green", "purple", "pink", "orange", "brown"] as const)[i % 8] }));
    const created = await addProperty(db, actor, page.id, { name: p.name, type: p.type, config: config as Record<string, unknown> });
    ids[p.name] = created.id;
  }
  const existingViews = await db.select().from(databaseViews).where(eq(databaseViews.databaseId, page.id)).orderBy(asc(databaseViews.position));
  for (let i = 0; i < d.views.length; i++) {
    const v = d.views[i];
    const config: ViewConfig = {};
    if (v.groupBy) config.groupBy = ids[v.groupBy];
    if (v.dateProperty) config.dateProperty = ids[v.dateProperty];
    if (v.sorts) config.sorts = v.sorts.map((s) => ({ propertyId: ids[s.prop], direction: s.direction }));
    if (i === 0 && existingViews[0]) {
      await updateView(db, actor, existingViews[0].id, { name: v.name, type: v.type });
      if (Object.keys(config).length) await updateView(db, actor, existingViews[0].id, { config: config as Record<string, unknown> });
      if (v.type === "table") {
        const props = await db.select({ id: databaseProperties.id }).from(databaseProperties).where(eq(databaseProperties.databaseId, page.id)).orderBy(asc(databaseProperties.position));
        await updateView(db, actor, existingViews[0].id, { config: { visibleProperties: props.map((p) => p.id) } });
      }
    } else {
      await createView(db, actor, page.id, { name: v.name, type: v.type, config: config as Record<string, unknown> });
    }
  }
  for (const r of d.records) {
    const values: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(r.values ?? {})) if (ids[k]) values[ids[k]] = v;
    await createRecord(db, actor, page.id, { title: r.title, icon: r.icon ?? null, values });
  }
  return page;
}

/** Content for a brand-new workspace. */
export async function seedStarterContent(db: DB, actor: Actor, workspaceId: string) {
  const welcome = await createPage(db, actor, { workspaceId, title: "Getting started", icon: "👋" });
  const tasks = await createDatabaseFromSpec(db, actor, workspaceId, null, TEMPLATES.find((t) => t.key === "task-tracker")!);
  const blocks: PMNode[] = [
    B.callout("👋", "Welcome to **Slate** — your self-hosted workspace. Every feature is available to everyone: no plans, no limits on pages, blocks, databases or history.", "blue"),
    B.toc(),
    B.h(2, "The basics"),
    B.todos([
      ["Click anywhere and start typing", true],
      ["Type **/** to insert headings, lists, tables, databases, equations and more", false],
      ["Drag the **⋮⋮** handle to move blocks", false],
      ["Press **Ctrl/⌘ + K** to search everything", false],
      ["Write Markdown: `# `, `- `, `[] `, `> `, ``` ``` ```", false],
    ]),
    B.h(2, "Databases"),
    B.p("Databases hold records that are full pages. Switch views, filter, sort, group, and add relations, rollups and formulas."),
    B.databaseView(tasks.id),
    B.h(2, "More blocks"),
    B.toggle("Toggle me", [B.p("Toggles hide content until you need it.")]),
    B.quote("Simple things should be simple, complex things should be possible."),
    B.code("typescript", 'const greeting = "Hello from Slate";\nconsole.log(greeting);'),
    B.equation("e^{i\\pi} + 1 = 0"),
    B.divider(),
    B.p("Your data lives in your database. Export everything at any time from **Settings → Import & export**."),
  ];
  await saveContent(db, actor, welcome.id, { blocks: blocks.map((b) => ({ id: b.attrs!.id, content: b })) });
  return { welcomeId: welcome.id, tasksId: tasks.id };
}
