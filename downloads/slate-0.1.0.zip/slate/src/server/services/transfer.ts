// Import and export: Markdown, HTML, CSV, and the full-fidelity Slate JSON/ZIP format.
import { and, asc, eq, inArray, isNull, max } from "drizzle-orm";
import { z } from "zod";
import { zipSync, unzipSync, strToU8, strFromU8 } from "fflate";
import type { DB } from "../db";
import { pages, blocks, databaseProperties, databaseViews, relationLinks, files } from "../db/schema";
import { newId } from "../crypto";
import { badRequest, notFound, tooLarge } from "../errors";
import { config } from "../config";
import type { Actor } from "./auth";
import { AccessResolver, getRole, requirePage, roleAtLeast } from "./permissions";
import { getBlocks, subtreeIds, createPage } from "./pages";
import { loadDatabaseMeta, queryDatabase, initDatabase } from "./databases";
import { getStorage, uploadFile } from "./files";
import { audit } from "./audit";
import { blocksToMarkdown, blocksToHtml, htmlDocument, markdownToBlocks, extractTitle, dropRelativeRefs, type ConvertContext } from "@/lib/markdown";
import { parseCsv, toCsv, unguard } from "@/lib/csv";
import { validateBlocks, nodeText, visitNodes, type PMNode } from "@/lib/blocks";
import { formatCell } from "@/lib/format";
import type { PropertyDef, CellValue, SelectOption, Color } from "@/lib/db-types";
import { COLORS } from "@/lib/db-types";

// ---------------------------------------------------------------- helpers

function safeName(title: string, fallback = "Untitled") {
  const base = (title || fallback).replace(/[\\/:*?"<>|\u0000-\u001f]/g, "-").replace(/\s+/g, " ").trim().slice(0, 80);
  return base || fallback;
}

function lossReport(loss: Map<string, number>, extra: string[] = []) {
  const lines = ["# Export notes", "", "The following could not be represented exactly in Markdown/CSV. The `slate.json` file (when present) keeps everything.", ""];
  if (!loss.size && !extra.length) lines.push("- Nothing was lost.");
  for (const [k, v] of loss) lines.push(`- ${k}: ${v} occurrence${v === 1 ? "" : "s"}`);
  for (const e of extra) lines.push(`- ${e}`);
  return lines.join("\n") + "\n";
}

/** Text value of a cell for CSV/Markdown export. */
export function cellText(p: PropertyDef, v: CellValue, refs: { pages: Record<string, { title: string }>; users: Record<string, { name: string }> }): string {
  return formatCell(p, v, {
    pageTitle: (id) => refs.pages[id]?.title ?? "",
    userName: (id) => refs.users[id]?.name ?? "",
    plain: true,
  });
}

// ---------------------------------------------------------------- single page export

export async function exportPage(db: DB, actor: Actor, pageId: string, format: "md" | "html" | "json", opts: { subpages?: boolean } = {}) {
  await requirePage(db, actor, pageId, "view");
  if (opts.subpages || format === "json") {
    const zip = await buildExportZip(db, actor, [pageId], { json: true });
    return { filename: `${safeName((await db.query.pages.findFirst({ where: eq(pages.id, pageId) }))?.title ?? "")}.zip`, contentType: "application/zip", body: zip };
  }
  const page = (await db.query.pages.findFirst({ where: eq(pages.id, pageId) }))!;
  const content = await getBlocks(db, pageId);
  const titles = await refTitles(db, actor, page.workspaceId);
  const ctx: ConvertContext = { loss: new Map(), pageRef: (id) => (titles.has(id) ? { title: titles.get(id)!, href: `#${id}` } : null) };
  let header = "";
  if (page.databaseId) {
    const { getRecordRow } = await import("./databases");
    const meta = await loadDatabaseMeta(db, page.databaseId);
    const { row, refs } = await getRecordRow(db, actor, pageId);
    const lines = meta.properties.filter((p) => p.type !== "title").map((p) => [p.name, cellText(p, row.values[p.id], refs)] as const).filter(([, v]) => v);
    header = format === "md" ? lines.map(([k, v]) => `**${k}:** ${v}`).join("  \n") : `<table class="properties">${lines.map(([k, v]) => `<tr><th>${escape(k)}</th><td>${escape(v)}</td></tr>`).join("")}</table>`;
  }
  if (format === "md") {
    const md = `# ${page.title || "Untitled"}\n\n${header ? header + "\n\n" : ""}${blocksToMarkdown(content, ctx)}\n`;
    return { filename: `${safeName(page.title)}.md`, contentType: "text/markdown; charset=utf-8", body: Buffer.from(md, "utf8") };
  }
  const html = htmlDocument(page.title, header + blocksToHtml(content, ctx), page.icon && !page.icon.startsWith("/") ? page.icon : null);
  return { filename: `${safeName(page.title)}.html`, contentType: "text/html; charset=utf-8", body: Buffer.from(html, "utf8") };
}

const escape = (s: string) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);

async function refTitles(db: DB, actor: Actor, workspaceId: string) {
  const resolver = await AccessResolver.load(db, workspaceId, actor.userId);
  const rows = await db.select({ id: pages.id, title: pages.title }).from(pages).where(and(eq(pages.workspaceId, workspaceId), isNull(pages.archivedAt)));
  return new Map(rows.filter((r) => resolver.canView(r.id)).map((r) => [r.id, r.title || "Untitled"]));
}

export async function exportDatabaseCsv(db: DB, actor: Actor, databaseId: string, viewId?: string | null) {
  const meta = await loadDatabaseMeta(db, databaseId);
  const result = await queryDatabase(db, actor, databaseId, { viewId: viewId ?? null });
  const props = meta.properties;
  const rows = [props.map((p) => p.name), ...result.rows.map((r) => props.map((p) => cellText(p, r.values[p.id], result.refs)))];
  return { filename: `${safeName(meta.title, "Database")}.csv`, contentType: "text/csv; charset=utf-8", body: Buffer.from(toCsv(rows), "utf8") };
}

// ---------------------------------------------------------------- full export (ZIP)

export interface SlateExport {
  format: "slate-export";
  version: 1;
  exportedAt: string;
  pages: {
    id: string;
    parentId: string | null;
    databaseId: string | null;
    kind: "page" | "database";
    title: string;
    icon: string | null;
    cover: string | null;
    position: number;
    visibility: "workspace" | "private";
    properties: Record<string, unknown>;
    isTemplate: boolean;
    isInline: boolean;
    fullWidth: boolean;
    smallText: boolean;
    createdAt: string;
    updatedAt: string;
  }[];
  blocks: { pageId: string; id: string; position: number; content: PMNode }[];
  properties: { id: string; databaseId: string; name: string; type: string; config: Record<string, unknown>; position: number }[];
  views: { id: string; databaseId: string; name: string; type: string; config: Record<string, unknown>; position: number }[];
  relations: { propertyId: string; fromPageId: string; toPageId: string; position: number }[];
  files: { id: string; name: string; mime: string; size: number; path: string }[];
}

async function collectExport(db: DB, actor: Actor, rootIds: string[], workspaceId: string) {
  const resolver = await AccessResolver.load(db, workspaceId, actor.userId);
  const ids = new Set<string>();
  for (const r of rootIds) for (const id of await subtreeIds(db, r)) if (resolver.canView(id)) ids.add(id);
  const idList = [...ids];
  const chunk = <T,>(arr: T[], n = 1000) => Array.from({ length: Math.ceil(arr.length / n) }, (_, i) => arr.slice(i * n, i * n + n));
  const pageRows = (await Promise.all(chunk(idList).map((c) => db.select().from(pages).where(inArray(pages.id, c))))).flat();
  const blockRows = (await Promise.all(chunk(idList).map((c) => db.select().from(blocks).where(inArray(blocks.pageId, c)).orderBy(asc(blocks.position))))).flat();
  const dbIds = pageRows.filter((p) => p.kind === "database").map((p) => p.id);
  const propRows = dbIds.length ? await db.select().from(databaseProperties).where(inArray(databaseProperties.databaseId, dbIds)) : [];
  const viewRows = dbIds.length ? await db.select().from(databaseViews).where(inArray(databaseViews.databaseId, dbIds)) : [];
  const relRows = propRows.length ? (await db.select().from(relationLinks).where(inArray(relationLinks.propertyId, propRows.map((p) => p.id)))).filter((l) => ids.has(l.fromPageId)) : [];
  // Files referenced anywhere in the exported content.
  const blob = JSON.stringify([pageRows.map((p) => [p.icon, p.cover, p.properties]), blockRows.map((b) => b.content)]);
  const fileIds = [...new Set([...blob.matchAll(/\/api\/files\/([0-9a-f-]{36})/g)].map((m) => m[1]))];
  const fileRows = fileIds.length ? await db.select().from(files).where(and(inArray(files.id, fileIds), eq(files.workspaceId, workspaceId))) : [];
  const exp: SlateExport = {
    format: "slate-export",
    version: 1,
    exportedAt: new Date().toISOString(),
    pages: pageRows.map((p) => ({
      id: p.id,
      parentId: p.parentId && ids.has(p.parentId) ? p.parentId : null,
      databaseId: p.databaseId,
      kind: p.kind,
      title: p.title,
      icon: p.icon,
      cover: p.cover,
      position: p.position,
      visibility: p.visibility,
      properties: p.properties,
      isTemplate: p.isTemplate,
      isInline: p.isInline,
      fullWidth: p.fullWidth,
      smallText: p.smallText,
      createdAt: p.createdAt.toISOString(),
      updatedAt: p.updatedAt.toISOString(),
    })),
    blocks: blockRows.map((b) => ({ pageId: b.pageId, id: b.id, position: b.position, content: b.content as unknown as PMNode })),
    properties: propRows.map((p) => ({ id: p.id, databaseId: p.databaseId, name: p.name, type: p.type, config: p.config, position: p.position })),
    views: viewRows.map((v) => ({ id: v.id, databaseId: v.databaseId, name: v.name, type: v.type, config: v.config, position: v.position })),
    relations: relRows.map((r) => ({ propertyId: r.propertyId, fromPageId: r.fromPageId, toPageId: r.toPageId, position: r.position })),
    files: fileRows.map((f) => ({ id: f.id, name: f.name, mime: f.mime, size: f.size, path: `files/${f.id}` })),
  };
  return { exp, fileRows, resolver };
}

export async function buildExportZip(db: DB, actor: Actor, rootIds: string[], opts: { json?: boolean; workspaceId?: string } = {}) {
  const first = rootIds.length ? await db.query.pages.findFirst({ where: eq(pages.id, rootIds[0]) }) : null;
  const workspaceId = opts.workspaceId ?? first?.workspaceId;
  if (!workspaceId) throw notFound();
  const { exp, fileRows } = await collectExport(db, actor, rootIds, workspaceId);
  const out: Record<string, Uint8Array> = {};
  const loss = new Map<string, number>();
  const byId = new Map(exp.pages.map((p) => [p.id, p]));
  // Folder path per page: Parent/Child/...
  const pathOf = new Map<string, string>();
  const used = new Set<string>();
  const folder = (id: string): string => {
    const cached = pathOf.get(id);
    if (cached) return cached;
    const p = byId.get(id)!;
    const parent = p.parentId ?? p.databaseId;
    const base = parent && byId.has(parent) ? folder(parent) + "/" : "";
    let name = safeName(p.title);
    let candidate = base + name;
    for (let i = 2; used.has(candidate.toLowerCase()); i++) candidate = `${base}${name} (${i})`;
    used.add(candidate.toLowerCase());
    name = candidate;
    pathOf.set(id, name);
    return name;
  };
  for (const p of exp.pages) {
    if (p.isTemplate) continue;
    const dir = folder(p.id);
    const fileName = dir.split("/").pop()!;
    const relTo = (target: string) => {
      const t = byId.get(target);
      if (!t) return null;
      const from = dir.split("/").slice(0, -1);
      const to = folder(target).split("/");
      let i = 0;
      while (i < from.length && i < to.length - 1 && from[i] === to[i]) i++;
      const up = from.slice(i).map(() => "..");
      const ext = t.kind === "database" ? ".csv" : ".md";
      return { title: t.title, href: encodeURI([...up, ...to.slice(i)].join("/") + ext) };
    };
    const ctx: ConvertContext = { loss, pageRef: relTo };
    if (p.kind === "database") {
      // Same computed values (formulas, rollups, relation titles) as the single-database CSV export.
      out[`${dir}.csv`] = new Uint8Array((await exportDatabaseCsv(db, actor, p.id)).body);
    }
    const content = exp.blocks.filter((b) => b.pageId === p.id).sort((a, b) => a.position - b.position).map((b) => b.content);
    if (content.length || p.kind === "page") {
      out[`${dir}${p.kind === "database" ? "/" + fileName + " (page)" : ""}.md`] = strToU8(`# ${p.title || "Untitled"}\n\n${blocksToMarkdown(content, ctx)}\n`);
    }
  }
  const storage = await getStorage();
  for (const f of fileRows) {
    try {
      out[`files/${f.id}`] = new Uint8Array(await storage.get(f.storageKey));
    } catch {
      loss.set("Files missing from storage", (loss.get("Files missing from storage") ?? 0) + 1);
    }
  }
  if (opts.json !== false) out["slate.json"] = strToU8(JSON.stringify(exp));
  out["loss-report.md"] = strToU8(lossReport(loss, ["Permissions, members, comments and page history are not included in exports."]));
  return Buffer.from(zipSync(out, { level: 6 }));
}

export async function exportWorkspace(db: DB, actor: Actor, workspaceId: string) {
  const role = await getRole(db, workspaceId, actor.userId);
  if (!role) throw notFound("Workspace not found");
  const roots = await db
    .select({ id: pages.id })
    .from(pages)
    .where(and(eq(pages.workspaceId, workspaceId), isNull(pages.parentId), isNull(pages.databaseId), isNull(pages.archivedAt)))
    .orderBy(asc(pages.position));
  const zip = await buildExportZip(db, actor, roots.map((r) => r.id), { json: true, workspaceId });
  await audit(db, { workspaceId, userId: actor.userId, action: "workspace.export" });
  return zip;
}

// ---------------------------------------------------------------- import (Slate JSON / ZIP)

const nodeSchema: z.ZodType<PMNode> = z.lazy(() =>
  z.object({ type: z.string(), attrs: z.record(z.string(), z.unknown()).optional(), content: z.array(nodeSchema).optional(), text: z.string().optional(), marks: z.array(z.object({ type: z.string(), attrs: z.record(z.string(), z.unknown()).optional() })).optional() }),
);
const idS = z.string().min(1).max(100);
const exportSchema = z.object({
  format: z.literal("slate-export"),
  version: z.literal(1),
  pages: z.array(
    z.object({
      id: idS,
      parentId: idS.nullable(),
      databaseId: idS.nullable(),
      kind: z.enum(["page", "database"]),
      title: z.string().max(2000),
      icon: z.string().max(2000).nullable(),
      cover: z.string().max(2000).nullable(),
      position: z.number(),
      visibility: z.enum(["workspace", "private"]).default("workspace"),
      properties: z.record(z.string(), z.unknown()).default({}),
      isTemplate: z.boolean().default(false),
      isInline: z.boolean().default(false),
      fullWidth: z.boolean().default(false),
      smallText: z.boolean().default(false),
    }),
  ),
  blocks: z.array(z.object({ pageId: idS, id: idS, position: z.number().int(), content: nodeSchema })),
  properties: z.array(z.object({ id: idS, databaseId: idS, name: z.string().max(200), type: z.string(), config: z.record(z.string(), z.unknown()), position: z.number() })),
  views: z.array(z.object({ id: idS, databaseId: idS, name: z.string().max(200), type: z.string(), config: z.record(z.string(), z.unknown()), position: z.number() })),
  relations: z.array(z.object({ propertyId: idS, fromPageId: idS, toPageId: idS, position: z.number() })),
  files: z.array(z.object({ id: idS, name: z.string(), mime: z.string(), size: z.number(), path: z.string() })).default([]),
});

export interface ImportReport {
  pages: number;
  databases: number;
  records: number;
  files: number;
  rootIds: string[];
  warnings: string[];
}

/**
 * Import a Slate export into a workspace. Everything gets new IDs, so importing never overwrites
 * existing data (importing twice creates two copies).
 */
export async function importSlate(db: DB, actor: Actor, workspaceId: string, raw: unknown, fileData: Map<string, Uint8Array>, parentId: string | null): Promise<ImportReport> {
  const role = await getRole(db, workspaceId, actor.userId);
  if (parentId) {
    const pa = await requirePage(db, actor, parentId, "edit");
    if (pa.node.workspaceId !== workspaceId) throw badRequest("The target page is in another workspace");
  } else if (!roleAtLeast(role, "editor")) throw notFound("Workspace not found");
  const parsed = exportSchema.safeParse(raw);
  if (!parsed.success) throw badRequest(`This is not a valid Slate export: ${parsed.error.issues[0]?.path.join(".")} ${parsed.error.issues[0]?.message}`);
  const exp = parsed.data;
  const warnings: string[] = [];
  // Duplicate ids inside the file are rejected.
  const dup = (arr: { id: string }[], what: string) => {
    const s = new Set<string>();
    for (const x of arr) {
      if (s.has(x.id)) throw badRequest(`The export contains a duplicate ${what} id (${x.id})`);
      s.add(x.id);
    }
  };
  dup(exp.pages, "page");
  dup(exp.properties, "property");
  dup(exp.views, "view");

  const pageIds = new Map(exp.pages.map((p) => [p.id, newId()]));
  const propIds = new Map(exp.properties.map((p) => [p.id, newId()]));
  const viewIds = new Map(exp.views.map((v) => [v.id, newId()]));
  const fileIds = new Map<string, string>();

  // Re-upload files first (outside the transaction: storage is not transactional).
  for (const f of exp.files) {
    const data = fileData.get(f.path);
    if (!data) {
      warnings.push(`File "${f.name}" was missing from the archive`);
      continue;
    }
    const up = await uploadFile(db, actor, workspaceId, { name: f.name, type: f.mime, data: Buffer.from(data) });
    fileIds.set(f.id, up.id);
  }
  const remapString = (s: string) =>
    s
      .replace(/\/api\/files\/([0-9a-f-]{36})/g, (m, id) => (fileIds.has(id) ? `/api/files/${fileIds.get(id)}` : m))
      .replace(/^[0-9a-f-]{36}$/, (id) => pageIds.get(id) ?? propIds.get(id) ?? viewIds.get(id) ?? id);
  const remapDeep = <T,>(v: T): T => JSON.parse(JSON.stringify(v), (_k, val) => (typeof val === "string" ? remapString(val) : val));

  const known = new Set(exp.pages.map((p) => p.id));
  const isRoot = (p: (typeof exp.pages)[number]) => (!p.parentId || !known.has(p.parentId)) && (!p.databaseId || !known.has(p.databaseId));
  const orphanRecords = exp.pages.filter((p) => p.databaseId && !known.has(p.databaseId));
  if (orphanRecords.length) warnings.push(`${orphanRecords.length} database record(s) without their database were imported as pages`);

  return db.transaction(async (tx) => {
    const [{ m }] = await tx
      .select({ m: max(pages.position) })
      .from(pages)
      .where(and(eq(pages.workspaceId, workspaceId), parentId ? eq(pages.parentId, parentId) : isNull(pages.parentId), isNull(pages.databaseId)));
    let nextPos = (m ?? 0) + 1;
    // Parents before children.
    const depth = (p: (typeof exp.pages)[number], guard = 0): number => {
      if (guard > 10_000) throw badRequest("The export contains a cycle in the page hierarchy");
      const parent = exp.pages.find((x) => x.id === (p.parentId ?? p.databaseId));
      return parent && !isRoot(p) ? depth(parent, guard + 1) + 1 : 0;
    };
    const ordered = [...exp.pages].map((p) => [depth(p), p] as const).sort((a, b) => a[0] - b[0]).map(([, p]) => p);
    const rootIds: string[] = [];
    for (const p of ordered) {
      const root = isRoot(p);
      const props: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(p.properties)) props[propIds.get(k) ?? k] = remapDeep(v);
      const id = pageIds.get(p.id)!;
      await tx.insert(pages).values({
        id,
        workspaceId,
        parentId: root ? parentId : p.parentId ? pageIds.get(p.parentId)! : null,
        databaseId: p.databaseId && known.has(p.databaseId) ? pageIds.get(p.databaseId)! : null,
        kind: p.kind,
        title: p.title,
        icon: p.icon ? remapString(p.icon) : null,
        cover: p.cover ? remapString(p.cover) : null,
        position: root ? nextPos++ : p.position,
        visibility: root && !parentId ? p.visibility : "workspace",
        properties: props,
        isTemplate: p.isTemplate,
        isInline: p.isInline,
        fullWidth: p.fullWidth,
        smallText: p.smallText,
        createdBy: actor.userId,
        updatedBy: actor.userId,
      });
      if (root) rootIds.push(id);
    }
    for (const pr of exp.properties) {
      if (!pageIds.has(pr.databaseId)) continue;
      const cfg = remapDeep(pr.config) as PropertyDef["config"];
      if (pr.type === "relation") {
        if (!cfg.targetDatabaseId || !known.has(pr.config.targetDatabaseId as string)) {
          warnings.push(`Relation "${pr.name}" pointed to a database outside the export; its links were dropped`);
          cfg.targetDatabaseId = pageIds.get(pr.databaseId);
          cfg.syncedPropertyId = null;
        } else if (pr.config.syncedPropertyId && !propIds.has(pr.config.syncedPropertyId as string)) cfg.syncedPropertyId = null;
      }
      await tx.insert(databaseProperties).values({ id: propIds.get(pr.id)!, databaseId: pageIds.get(pr.databaseId)!, name: pr.name, type: pr.type, config: cfg as Record<string, unknown>, position: pr.position });
    }
    for (const db2 of exp.pages.filter((p) => p.kind === "database")) {
      if (!exp.properties.some((pr) => pr.databaseId === db2.id)) await initDatabase(tx, pageIds.get(db2.id)!);
    }
    for (const v of exp.views) {
      if (!pageIds.has(v.databaseId)) continue;
      await tx.insert(databaseViews).values({ id: viewIds.get(v.id)!, databaseId: pageIds.get(v.databaseId)!, name: v.name, type: v.type, config: remapDeep(v.config), position: v.position });
    }
    for (const r of exp.relations) {
      if (!propIds.has(r.propertyId) || !pageIds.has(r.fromPageId) || !pageIds.has(r.toPageId)) continue;
      await tx.insert(relationLinks).values({ propertyId: propIds.get(r.propertyId)!, fromPageId: pageIds.get(r.fromPageId)!, toPageId: pageIds.get(r.toPageId)!, position: r.position }).onConflictDoNothing();
    }
    const byPage = new Map<string, { id: string; content: PMNode }[]>();
    for (const b of exp.blocks) {
      if (!pageIds.has(b.pageId)) continue;
      const list = byPage.get(b.pageId) ?? [];
      list[b.position] = { id: b.id, content: remapDeep(b.content) };
      byPage.set(b.pageId, list);
    }
    for (const [oldPage, list] of byPage) {
      let valid;
      try {
        valid = validateBlocks(list.filter(Boolean));
      } catch (e) {
        warnings.push(`Skipped invalid content on page ${oldPage}: ${(e as Error).message}`);
        continue;
      }
      const pid = pageIds.get(oldPage)!;
      for (let i = 0; i < valid.length; i++) {
        await tx.insert(blocks).values({ pageId: pid, id: valid[i].id, position: i, type: valid[i].type, content: valid[i].content as unknown as Record<string, unknown>, text: nodeText(valid[i].content), updatedBy: actor.userId });
      }
    }
    await audit(tx, { workspaceId, userId: actor.userId, action: "workspace.import", meta: { pages: exp.pages.length } });
    return {
      pages: exp.pages.filter((p) => p.kind === "page" && !p.databaseId).length,
      databases: exp.pages.filter((p) => p.kind === "database").length,
      records: exp.pages.filter((p) => p.databaseId).length,
      files: fileIds.size,
      rootIds,
      warnings,
    };
  });
}

// ---------------------------------------------------------------- import (Markdown)

/**
 * Import Markdown files as pages. Folder structure becomes page nesting
 * ("A.md" + "A/B.md" → B is a sub-page of A). Relative images inside a ZIP are uploaded.
 */
export async function importMarkdown(db: DB, actor: Actor, workspaceId: string, entries: Map<string, Uint8Array>, parentId: string | null): Promise<ImportReport> {
  if (parentId) await requirePage(db, actor, parentId, "edit");
  else if (!roleAtLeast(await getRole(db, workspaceId, actor.userId), "editor")) throw notFound("Workspace not found");
  const mdPaths = [...entries.keys()].filter((p) => /\.(md|markdown|txt)$/i.test(p) && !p.startsWith("__MACOSX")).sort((a, b) => a.split("/").length - b.split("/").length || a.localeCompare(b));
  if (!mdPaths.length) throw badRequest("No Markdown files found");
  const warnings: string[] = [];
  const created = new Map<string, string>(); // path without extension → page id
  const rootIds: string[] = [];
  const stripHash = (s: string) => s.replace(/\s+[0-9a-f]{32}$/i, "");
  const uploaded = new Map<string, string>();
  for (const path of mdPaths) {
    const noExt = path.replace(/\.(md|markdown|txt)$/i, "");
    const parts = noExt.split("/");
    const name = stripHash(parts[parts.length - 1]);
    // Parent: the page created for the containing folder, if any.
    const parentKey = parts.slice(0, -1).join("/");
    let parent = parentKey ? created.get(parentKey) : undefined;
    if (parentKey && !parent) {
      // Create intermediate folder pages.
      let acc = "";
      let up: string | null = parentId;
      for (const seg of parts.slice(0, -1)) {
        acc = acc ? `${acc}/${seg}` : seg;
        if (!created.has(acc)) {
          const pg = await createPage(db, actor, { workspaceId, parentId: up, title: stripHash(seg) });
          created.set(acc, pg.id);
          if (!up || up === parentId) rootIds.push(pg.id);
        }
        up = created.get(acc)!;
      }
      parent = up!;
    }
    const raw = strFromU8(entries.get(path)!);
    const { title, body } = extractTitle(raw);
    let blocks2 = markdownToBlocks(body, { relative: true });
    await uploadRelativeImages(db, actor, workspaceId, blocks2, parts.slice(0, -1).join("/"), entries, uploaded);
    dropRelativeRefs(blocks2);
    try {
      blocks2 = validateBlocks(blocks2.map((b) => ({ id: b.attrs!.id, content: b }))).map((b) => b.content);
    } catch (e) {
      warnings.push(`${path}: ${(e as Error).message}`);
      blocks2 = [];
    }
    const existing = created.get(noExt);
    if (existing) {
      // A folder page was created first; fill it in.
      const { saveContent, updatePage } = await import("./pages");
      await updatePage(db, actor, existing, { title: title ?? name });
      await saveContent(db, actor, existing, { blocks: blocks2.map((b) => ({ id: b.attrs!.id, content: b })) });
      continue;
    }
    const pg = await createPage(db, actor, { workspaceId, parentId: parent ?? parentId, title: title ?? name, blocks: blocks2.map((b) => ({ id: b.attrs!.id, content: b })) });
    created.set(noExt, pg.id);
    if (!parent) rootIds.push(pg.id);
  }
  return { pages: created.size, databases: 0, records: 0, files: uploaded.size, rootIds, warnings };
}

/** Upload images referenced by relative paths inside an archive and point the blocks at them. */
export async function uploadRelativeImages(db: DB, actor: Actor, workspaceId: string, list: PMNode[], dir: string, entries: Map<string, Uint8Array>, uploaded: Map<string, string>) {
  for (const b of list) {
    for (const n of collect(b)) {
      if (n.type !== "image") continue;
      const src = String(n.attrs?.src ?? "");
      if (!src || /^(https?:|\/|data:)/.test(src)) continue;
      const resolved = resolveArchivePath(dir, src);
      const data = resolved ? entries.get(resolved) : undefined;
      if (!resolved || !data) continue;
      let url = uploaded.get(resolved);
      if (!url) {
        const up = await uploadFile(db, actor, workspaceId, { name: resolved.split("/").pop()!, type: "", data: Buffer.from(data) });
        url = up.url;
        uploaded.set(resolved, url);
      }
      n.attrs!.src = url;
    }
  }
}

/** A relative (URL-encoded) reference from a file in `dir`, as an archive path; null if it leaves the archive. */
export function resolveArchivePath(dir: string, ref: string): string | null {
  let decoded: string;
  try {
    decoded = decodeURIComponent(ref.split("#")[0].split("?")[0]);
  } catch {
    decoded = ref;
  }
  const out: string[] = dir ? dir.split("/") : [];
  for (const seg of decoded.split("/")) {
    if (seg === "" || seg === ".") continue;
    if (seg === "..") {
      if (!out.length) return null;
      out.pop();
    } else out.push(seg);
  }
  return out.join("/");
}

function collect(n: PMNode): PMNode[] {
  const out: PMNode[] = [];
  visitNodes(n, (x) => out.push(x));
  return out;
}

// ---------------------------------------------------------------- import (CSV)

function inferType(values: string[]): PropertyDef["type"] {
  const vals = values.map((v) => v.trim()).filter(Boolean);
  if (!vals.length) return "rich_text";
  if (vals.every((v) => /^-?[\d,]*\.?\d+(e[+-]?\d+)?$/i.test(v.replace(/[$€£¥₹%\s]/g, "")))) return "number";
  if (vals.every((v) => /^(true|false|yes|no|checked|unchecked|x|✓|✔)$/i.test(v))) return "checkbox";
  if (vals.every((v) => /^\d{4}-\d{2}-\d{2}(T[\d:.]+Z?)?$/.test(v) || (/[a-z]{3,}\s+\d{1,2},\s+\d{4}/i.test(v) && !Number.isNaN(Date.parse(v))))) return "date";
  if (vals.every((v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v))) return "email";
  if (vals.every((v) => /^https?:\/\//i.test(v))) return "url";
  const distinct = new Set(vals.flatMap((v) => v.split(",").map((s) => s.trim())));
  const short = vals.every((v) => v.length <= 60);
  if (short && distinct.size <= Math.max(12, vals.length / 3)) return vals.some((v) => v.includes(",")) ? "multi_select" : "select";
  return "rich_text";
}

/**
 * Import CSV rows. With `databaseId`, rows are appended to that database (columns matched by
 * property name, unknown columns become new text properties). Otherwise a new database is created
 * with inferred column types. Uses batched inserts so large files import quickly.
 */
export async function importCsv(db: DB, actor: Actor, workspaceId: string, csvText: string, opts: { title?: string; parentId?: string | null; databaseId?: string | null }) {
  const rows = parseCsv(csvText).map((r) => r.map(unguard));
  if (rows.length < 1) throw badRequest("The CSV file is empty");
  const header = rows[0].map((h, i) => h.trim() || `Column ${i + 1}`);
  const data = rows.slice(1);
  let databaseId = opts.databaseId ?? null;
  const warnings: string[] = [];
  if (!databaseId) {
    const pg = await createPage(db, actor, { workspaceId, parentId: opts.parentId ?? null, title: opts.title ?? "Imported database", kind: "database" });
    databaseId = pg.id;
    // Replace the default schema: first column is the title, the rest are inferred.
    await db.delete(databaseProperties).where(and(eq(databaseProperties.databaseId, databaseId), eq(databaseProperties.type, "multi_select")));
    const titleProp = (await loadDatabaseMeta(db, databaseId)).properties.find((p) => p.type === "title")!;
    await db.update(databaseProperties).set({ name: header[0] }).where(eq(databaseProperties.id, titleProp.id));
    for (let c = 1; c < header.length; c++) {
      const type = inferType(data.map((r) => r[c] ?? ""));
      const cfg: PropertyDef["config"] = {};
      if (type === "select" || type === "multi_select") {
        const names = [...new Set(data.flatMap((r) => (type === "multi_select" ? (r[c] ?? "").split(",") : [r[c] ?? ""]).map((s) => s.trim()).filter(Boolean)))];
        cfg.options = names.map((name, i) => ({ id: newId(), name: name.slice(0, 200), color: COLORS[(i % (COLORS.length - 1)) + 1] as Color }));
      }
      await db.insert(databaseProperties).values({ id: newId(), databaseId, name: header[c], type, config: cfg as Record<string, unknown>, position: c });
    }
    const all = (await loadDatabaseMeta(db, databaseId)).properties;
    const view = (await db.select().from(databaseViews).where(eq(databaseViews.databaseId, databaseId)))[0];
    await db.update(databaseViews).set({ config: { ...(view.config as object), visibleProperties: all.map((p) => p.id) } }).where(eq(databaseViews.id, view.id));
  } else {
    const pa = await requirePage(db, actor, databaseId, "edit");
    if (pa.node.kind !== "database") throw badRequest("Not a database");
    workspaceId = pa.node.workspaceId;
  }
  const meta = await loadDatabaseMeta(db, databaseId);
  const colProps: (PropertyDef | null)[] = [];
  for (const name of header) {
    let p = meta.properties.find((x) => x.name.toLowerCase() === name.toLowerCase()) ?? null;
    if (!p && opts.databaseId) {
      const id = newId();
      await db.insert(databaseProperties).values({ id, databaseId, name, type: "rich_text", config: {}, position: meta.properties.length + colProps.length });
      p = { id, databaseId, name, type: "rich_text", config: {}, position: 0 };
      warnings.push(`Added a text property for the new column "${name}"`);
    }
    colProps.push(p);
  }
  const titleCol = colProps.findIndex((p) => p?.type === "title");
  const optionMaps = new Map<string, Map<string, string>>();
  const pendingOptions = new Map<string, SelectOption[]>();
  const optId = (p: PropertyDef, name: string) => {
    let m = optionMaps.get(p.id);
    if (!m) {
      m = new Map((p.config.options ?? []).map((o) => [o.name.toLowerCase(), o.id]));
      optionMaps.set(p.id, m);
    }
    const key = name.toLowerCase();
    let id = m.get(key);
    if (!id) {
      id = newId();
      m.set(key, id);
      const list = pendingOptions.get(p.id) ?? [...(p.config.options ?? [])];
      list.push({ id, name: name.slice(0, 200), color: COLORS[(list.length % (COLORS.length - 1)) + 1] as Color });
      pendingOptions.set(p.id, list);
    }
    return id;
  };
  const convert = (p: PropertyDef, raw: string): unknown => {
    const v = raw.trim();
    if (!v) return undefined;
    switch (p.type) {
      case "number": {
        const n = Number(v.replace(/[,$€£¥₹%\s]/g, ""));
        return Number.isFinite(n) ? n : undefined;
      }
      case "checkbox":
        return /^(true|yes|checked|x|✓|✔|1)$/i.test(v);
      case "date": {
        const t = /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : Number.isNaN(Date.parse(v)) ? null : new Date(Date.parse(v)).toISOString().slice(0, 10);
        return t ? { start: t, end: null, includeTime: false } : undefined;
      }
      case "select":
      case "status":
        return optId(p, v);
      case "multi_select":
        return v.split(",").map((s) => s.trim()).filter(Boolean).map((s) => optId(p, s));
      case "rich_text":
      case "url":
      case "email":
      case "phone":
        return v.slice(0, 200_000);
      default:
        return undefined;
    }
  };
  const [{ m }] = await db.select({ m: max(pages.position) }).from(pages).where(eq(pages.databaseId, databaseId));
  let pos = m ?? 0;
  const now = new Date();
  const values = data.map((r) => {
    const props: Record<string, unknown> = {};
    colProps.forEach((p, c) => {
      if (!p || p.type === "title") return;
      const v = convert(p, r[c] ?? "");
      if (v !== undefined) props[p.id] = v;
    });
    return {
      id: newId(),
      workspaceId,
      databaseId,
      kind: "page" as const,
      title: titleCol >= 0 ? (r[titleCol] ?? "").slice(0, 2000) : "",
      position: ++pos,
      properties: props,
      createdBy: actor.userId,
      updatedBy: actor.userId,
      createdAt: now,
      updatedAt: now,
    };
  });
  await db.transaction(async (tx) => {
    for (const [pid, opts2] of pendingOptions) {
      const p = colProps.find((x) => x?.id === pid)!;
      const cfg = { ...p.config, options: opts2 };
      if (p.type === "status" && cfg.groups?.length) cfg.groups[0].optionIds.push(...opts2.filter((o) => !(p.config.options ?? []).some((x) => x.id === o.id)).map((o) => o.id));
      await tx.update(databaseProperties).set({ config: cfg as Record<string, unknown> }).where(eq(databaseProperties.id, pid));
    }
    for (let i = 0; i < values.length; i += 500) await tx.insert(pages).values(values.slice(i, i + 500));
  });
  return { databaseId, records: values.length, warnings };
}

// ---------------------------------------------------------------- entry point for uploads

export async function importUpload(db: DB, actor: Actor, workspaceId: string, file: { name: string; data: Buffer }, opts: { parentId?: string | null; databaseId?: string | null }) {
  if (file.data.length > config.maxImportBytes) throw tooLarge("This import is larger than MAX_IMPORT_BYTES");
  const lower = file.name.toLowerCase();
  if (lower.endsWith(".csv")) {
    const r = await importCsv(db, actor, workspaceId, file.data.toString("utf8"), { title: file.name.replace(/\.csv$/i, ""), parentId: opts.parentId, databaseId: opts.databaseId });
    return { kind: "csv" as const, ...r, rootIds: [r.databaseId] };
  }
  if (lower.endsWith(".json")) {
    let json: unknown;
    try {
      json = JSON.parse(file.data.toString("utf8"));
    } catch {
      throw badRequest("The JSON file could not be parsed");
    }
    return { kind: "slate" as const, ...(await importSlate(db, actor, workspaceId, json, new Map(), opts.parentId ?? null)) };
  }
  if (lower.endsWith(".zip")) {
    let entries: Record<string, Uint8Array>;
    try {
      entries = unzipSync(new Uint8Array(file.data));
    } catch {
      throw badRequest("The ZIP file could not be read");
    }
    const total = Object.values(entries).reduce((s, v) => s + v.length, 0);
    if (total > config.maxImportBytes * 4) throw tooLarge("The ZIP expands to more than the import limit allows");
    const map = new Map(Object.entries(entries).filter(([k]) => !k.endsWith("/")));
    const names = [...map.keys()];
    if (!map.has("slate.json")) {
      const { importNotion, looksLikeNotionExport } = await import("./import-notion");
      // Notion's export: names with 32-hex ids, sometimes only ZIPs inside the ZIP.
      if (looksLikeNotionExport(names) || (names.length > 0 && names.every((k) => /\.zip$/i.test(k))))
        return { kind: "notion" as const, ...(await importNotion(db, actor, workspaceId, map, opts.parentId ?? null)) };
    }
    if (map.has("slate.json")) {
      const json = JSON.parse(strFromU8(map.get("slate.json")!));
      return { kind: "slate" as const, ...(await importSlate(db, actor, workspaceId, json, map, opts.parentId ?? null)) };
    }
    const csvs = [...map.keys()].filter((k) => k.toLowerCase().endsWith(".csv"));
    const report = [...map.keys()].some((k) => /\.(md|markdown)$/i.test(k)) ? await importMarkdown(db, actor, workspaceId, map, opts.parentId ?? null) : { pages: 0, databases: 0, records: 0, files: 0, rootIds: [] as string[], warnings: [] as string[] };
    for (const c of csvs) {
      const r = await importCsv(db, actor, workspaceId, strFromU8(map.get(c)!), { title: c.split("/").pop()!.replace(/\.csv$/i, ""), parentId: opts.parentId ?? null });
      report.databases++;
      report.records += r.records;
      report.rootIds.push(r.databaseId);
    }
    return { kind: "markdown" as const, ...report };
  }
  if (/\.(md|markdown|txt)$/i.test(lower)) {
    return { kind: "markdown" as const, ...(await importMarkdown(db, actor, workspaceId, new Map([[file.name, new Uint8Array(file.data)]]), opts.parentId ?? null)) };
  }
  throw badRequest("Unsupported file type. Import .md, .csv, .json or .zip files.");
}
