// Fetch title/description/image of a URL for bookmark blocks, with SSRF protection.
import dns from "node:dns/promises";
import net from "node:net";
import { badRequest } from "../errors";

function isPrivateIp(ip: string): boolean {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split(".").map(Number);
    return (
      a === 0 ||
      a === 10 ||
      a === 127 ||
      (a === 100 && b >= 64 && b <= 127) ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      (a === 198 && (b === 18 || b === 19)) ||
      a >= 224
    );
  }
  const v6 = ip.toLowerCase();
  if (v6.startsWith("::ffff:")) return isPrivateIp(v6.slice(7));
  return v6 === "::" || v6 === "::1" || v6.startsWith("fc") || v6.startsWith("fd") || v6.startsWith("fe8") || v6.startsWith("fe9") || v6.startsWith("fea") || v6.startsWith("feb");
}

async function assertPublic(url: URL) {
  if (url.protocol !== "http:" && url.protocol !== "https:") throw badRequest("Only http(s) links can be previewed");
  if (url.username || url.password) throw badRequest("Links with credentials cannot be previewed");
  const host = url.hostname.replace(/^\[|\]$/g, "");
  const addrs = net.isIP(host) ? [{ address: host }] : await dns.lookup(host, { all: true }).catch(() => []);
  if (!addrs.length) throw badRequest("Could not resolve that address");
  if (addrs.some((a) => isPrivateIp(a.address))) throw badRequest("Links to private network addresses cannot be previewed");
}

const decode = (s: string) =>
  s
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&#x27;/g, "'")
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .trim();

function meta(html: string, names: string[]): string | null {
  for (const n of names) {
    const re = new RegExp(`<meta[^>]+(?:property|name)=["']${n}["'][^>]*>`, "i");
    const tag = re.exec(html)?.[0];
    const content = tag && /content=["']([^"']*)["']/i.exec(tag)?.[1];
    if (content) return decode(content).slice(0, 500);
  }
  return null;
}

export async function unfurl(rawUrl: string) {
  let url: URL;
  try {
    url = new URL(rawUrl);
  } catch {
    throw badRequest("That is not a valid URL");
  }
  // Follow up to 3 redirects manually, re-checking each hop.
  let res: Response | null = null;
  for (let hop = 0; hop < 4; hop++) {
    await assertPublic(url);
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 5000);
    try {
      res = await fetch(url, { redirect: "manual", signal: ctrl.signal, headers: { "user-agent": "SlateBot/1.0 (+link preview)", accept: "text/html,*/*;q=0.5" } });
    } catch {
      throw badRequest("The page could not be reached");
    } finally {
      clearTimeout(timer);
    }
    if (res.status >= 300 && res.status < 400 && res.headers.get("location")) {
      url = new URL(res.headers.get("location")!, url);
      continue;
    }
    break;
  }
  const fallback = { url: url.toString(), title: url.hostname, description: null as string | null, image: null as string | null, icon: `${url.origin}/favicon.ico` };
  if (!res || !res.ok || !(res.headers.get("content-type") ?? "").includes("html")) return fallback;
  // Read until </head>, at most 2 MB (some sites, e.g. YouTube, put ~800 KB of scripts before their meta tags).
  const reader = res.body?.getReader();
  let html = "";
  if (reader) {
    const dec = new TextDecoder();
    let total = 0;
    while (total < 2 * 1024 * 1024) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.length;
      html += dec.decode(value, { stream: true });
      if (html.includes("</head>")) break;
    }
    reader.cancel().catch(() => {});
  }
  const title = meta(html, ["og:title", "twitter:title"]) ?? (/<title[^>]*>([^<]*)<\/title>/i.exec(html)?.[1] ? decode(/<title[^>]*>([^<]*)<\/title>/i.exec(html)![1]).slice(0, 300) : null);
  const image = meta(html, ["og:image", "twitter:image"]);
  const iconHref = /<link[^>]+rel=["'][^"']*icon[^"']*["'][^>]*>/i.exec(html)?.[0];
  const iconUrl = iconHref && /href=["']([^"']+)["']/i.exec(iconHref)?.[1];
  const abs = (u: string | null | undefined) => {
    if (!u) return null;
    try {
      const x = new URL(u, url);
      return x.protocol === "http:" || x.protocol === "https:" ? x.toString() : null;
    } catch {
      return null;
    }
  };
  return {
    url: url.toString(),
    title: title || fallback.title,
    description: meta(html, ["og:description", "description", "twitter:description"]),
    image: abs(image),
    icon: abs(iconUrl) ?? fallback.icon,
  };
}

export { isPrivateIp };
