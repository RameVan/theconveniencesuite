import { and, asc, eq, gt, isNull, sql } from "drizzle-orm";
import { z } from "zod";
import type { DB } from "../db";
import { workspaces, workspaceMembers, users, invitations, pages, pagePermissions, files } from "../db/schema";
import { newId, randomToken, sha256 } from "../crypto";
import { badRequest, conflict, forbidden, notFound } from "../errors";
import type { Actor } from "./auth";
import { emailSchema } from "./auth";
import { getRole, requireRole, roleAtLeast, type WorkspaceRole } from "./permissions";
import { audit } from "./audit";

export const workspaceInput = z.object({
  name: z.string().trim().min(1, "Give the workspace a name").max(200),
  icon: z.string().max(2000).nullable().optional(),
  starter: z.boolean().optional(),
});

export async function createWorkspace(db: DB, actor: Actor, input: z.infer<typeof workspaceInput>) {
  const data = workspaceInput.parse(input);
  const id = newId();
  await db.transaction(async (tx) => {
    await tx.insert(workspaces).values({ id, name: data.name, icon: data.icon ?? null, createdBy: actor.userId });
    await tx.insert(workspaceMembers).values({ workspaceId: id, userId: actor.userId, role: "owner" });
  });
  if (data.starter !== false) {
    const { seedStarterContent } = await import("./templates");
    await seedStarterContent(db, actor, id);
  }
  await audit(db, { workspaceId: id, userId: actor.userId, action: "workspace.create", targetId: id });
  return getWorkspace(db, actor, id);
}

export async function getWorkspace(db: DB, actor: Actor, workspaceId: string) {
  const [ws] = await db.select().from(workspaces).where(eq(workspaces.id, workspaceId));
  if (!ws) throw notFound("Workspace not found");
  const role = await getRole(db, workspaceId, actor.userId);
  if (!role) {
    // Guests (explicit page grants only) see the workspace name.
    const [g] = await db
      .select({ n: sql<number>`count(*)::int` })
      .from(pagePermissions)
      .innerJoin(pages, eq(pages.id, pagePermissions.pageId))
      .where(and(eq(pagePermissions.userId, actor.userId), eq(pages.workspaceId, workspaceId), sql`${pagePermissions.access} <> 'none'`));
    if (!g.n) throw notFound("Workspace not found");
  }
  return { id: ws.id, name: ws.name, icon: ws.icon, createdAt: ws.createdAt, role };
}

export async function listWorkspaces(db: DB, actor: Actor) {
  const member = await db
    .select({ id: workspaces.id, name: workspaces.name, icon: workspaces.icon, role: workspaceMembers.role })
    .from(workspaceMembers)
    .innerJoin(workspaces, eq(workspaces.id, workspaceMembers.workspaceId))
    .where(eq(workspaceMembers.userId, actor.userId))
    .orderBy(asc(workspaces.createdAt));
  const guest = await db
    .selectDistinct({ id: workspaces.id, name: workspaces.name, icon: workspaces.icon })
    .from(pagePermissions)
    .innerJoin(pages, eq(pages.id, pagePermissions.pageId))
    .innerJoin(workspaces, eq(workspaces.id, pages.workspaceId))
    .where(and(eq(pagePermissions.userId, actor.userId), sql`${pagePermissions.access} <> 'none'`));
  const ids = new Set(member.map((m) => m.id));
  return [...member, ...guest.filter((g) => !ids.has(g.id)).map((g) => ({ ...g, role: null as WorkspaceRole | null }))];
}

export async function updateWorkspace(db: DB, actor: Actor, workspaceId: string, input: Partial<z.infer<typeof workspaceInput>>) {
  await requireRole(db, actor, workspaceId, "admin");
  const data = workspaceInput.partial().parse(input);
  const patch: Partial<typeof workspaces.$inferInsert> = {};
  if (data.name !== undefined) patch.name = data.name;
  if (data.icon !== undefined) patch.icon = data.icon;
  if (Object.keys(patch).length) await db.update(workspaces).set(patch).where(eq(workspaces.id, workspaceId));
  return getWorkspace(db, actor, workspaceId);
}

export async function deleteWorkspace(db: DB, actor: Actor, workspaceId: string, confirmName: string) {
  await requireRole(db, actor, workspaceId, "owner");
  const [ws] = await db.select().from(workspaces).where(eq(workspaces.id, workspaceId));
  if (!ws) throw notFound();
  if (confirmName !== ws.name) throw badRequest("Type the workspace name exactly to confirm deletion");
  const fileRows = await db.select({ key: files.storageKey }).from(files).where(eq(files.workspaceId, workspaceId));
  await db.delete(workspaces).where(eq(workspaces.id, workspaceId));
  const { getStorage } = await import("./files");
  const storage = await getStorage();
  for (const f of fileRows) await storage.delete(f.key).catch(() => {});
  await audit(db, { userId: actor.userId, action: "workspace.delete", targetId: workspaceId });
}

// ---------------------------------------------------------------- members

export async function listMembers(db: DB, actor: Actor, workspaceId: string) {
  const role = await getRole(db, workspaceId, actor.userId);
  if (!role) throw notFound("Workspace not found");
  return db
    .select({ id: users.id, name: users.name, email: users.email, avatarUrl: users.avatarUrl, role: workspaceMembers.role, joinedAt: workspaceMembers.joinedAt })
    .from(workspaceMembers)
    .innerJoin(users, eq(users.id, workspaceMembers.userId))
    .where(eq(workspaceMembers.workspaceId, workspaceId))
    .orderBy(asc(workspaceMembers.joinedAt));
}

export async function updateMemberRole(db: DB, actor: Actor, workspaceId: string, userId: string, role: WorkspaceRole) {
  const myRole = await requireRole(db, actor, workspaceId, "admin");
  z.enum(["owner", "admin", "editor", "viewer"]).parse(role);
  const target = await getRole(db, workspaceId, userId);
  if (!target) throw notFound("Member not found");
  if ((target === "owner" || role === "owner") && myRole !== "owner") throw forbidden("Only owners can change ownership");
  if (target === "owner" && role !== "owner") await ensureAnotherOwner(db, workspaceId, userId);
  await db.update(workspaceMembers).set({ role }).where(and(eq(workspaceMembers.workspaceId, workspaceId), eq(workspaceMembers.userId, userId)));
  await audit(db, { workspaceId, userId: actor.userId, action: "member.role", targetId: userId, meta: { role } });
}

async function ensureAnotherOwner(db: DB, workspaceId: string, exceptUserId: string) {
  const owners = await db.select({ id: workspaceMembers.userId }).from(workspaceMembers).where(and(eq(workspaceMembers.workspaceId, workspaceId), eq(workspaceMembers.role, "owner")));
  if (!owners.some((o) => o.id !== exceptUserId)) throw conflict("A workspace needs at least one owner");
}

export async function removeMember(db: DB, actor: Actor, workspaceId: string, userId: string) {
  const self = userId === actor.userId;
  const myRole = self ? await getRole(db, workspaceId, actor.userId) : await requireRole(db, actor, workspaceId, "admin");
  if (!myRole) throw notFound("Workspace not found");
  const target = await getRole(db, workspaceId, userId);
  if (!target) throw notFound("Member not found");
  if (target === "owner") {
    if (!self && myRole !== "owner") throw forbidden("Only owners can remove an owner");
    await ensureAnotherOwner(db, workspaceId, userId);
  }
  await db.transaction(async (tx) => {
    await tx.delete(workspaceMembers).where(and(eq(workspaceMembers.workspaceId, workspaceId), eq(workspaceMembers.userId, userId)));
    // Drop their explicit page grants in this workspace too.
    await tx.execute(sql`DELETE FROM page_permissions pp USING pages p WHERE pp.page_id = p.id AND p.workspace_id = ${workspaceId} AND pp.user_id = ${userId}`);
  });
  await audit(db, { workspaceId, userId: actor.userId, action: self ? "member.leave" : "member.remove", targetId: userId });
}

// ---------------------------------------------------------------- invitations

export const inviteInput = z.object({ email: emailSchema, role: z.enum(["admin", "editor", "viewer"]).default("editor") });

export async function createInvitation(db: DB, actor: Actor, workspaceId: string, input: z.input<typeof inviteInput>) {
  const myRole = await requireRole(db, actor, workspaceId, "admin");
  const data = inviteInput.parse(input);
  if (data.role === "admin" && !roleAtLeast(myRole, "admin")) throw forbidden();
  const existingUser = await db.query.users.findFirst({ where: eq(users.email, data.email) });
  if (existingUser && (await getRole(db, workspaceId, existingUser.id))) throw conflict("This person is already a member");
  const token = randomToken(24);
  const id = newId();
  await db.insert(invitations).values({ id, workspaceId, email: data.email, role: data.role, tokenHash: sha256(token), invitedBy: actor.userId, expiresAt: new Date(Date.now() + 14 * 86_400_000) });
  await audit(db, { workspaceId, userId: actor.userId, action: "invite.create", targetId: id, meta: { role: data.role } });
  return { id, email: data.email, role: data.role, token, path: `/invite/${token}` };
}

export async function listInvitations(db: DB, actor: Actor, workspaceId: string) {
  await requireRole(db, actor, workspaceId, "admin");
  return db
    .select({ id: invitations.id, email: invitations.email, role: invitations.role, createdAt: invitations.createdAt, expiresAt: invitations.expiresAt })
    .from(invitations)
    .where(and(eq(invitations.workspaceId, workspaceId), isNull(invitations.acceptedAt), gt(invitations.expiresAt, new Date())));
}

export async function revokeInvitation(db: DB, actor: Actor, workspaceId: string, id: string) {
  await requireRole(db, actor, workspaceId, "admin");
  await db.delete(invitations).where(and(eq(invitations.id, id), eq(invitations.workspaceId, workspaceId)));
}

/** Public preview of an invitation (no auth): workspace name, email and role. */
export async function previewInvitation(db: DB, token: string) {
  const [inv] = await db
    .select({ inv: invitations, wsName: workspaces.name })
    .from(invitations)
    .innerJoin(workspaces, eq(workspaces.id, invitations.workspaceId))
    .where(and(eq(invitations.tokenHash, sha256(token)), isNull(invitations.acceptedAt), gt(invitations.expiresAt, new Date())));
  if (!inv) throw notFound("This invitation is invalid or has expired");
  return { workspaceName: inv.wsName, email: inv.inv.email, role: inv.inv.role };
}

export async function acceptInvitation(db: DB, actor: Actor, token: string) {
  const [inv] = await db.select().from(invitations).where(and(eq(invitations.tokenHash, sha256(token)), isNull(invitations.acceptedAt), gt(invitations.expiresAt, new Date())));
  if (!inv) throw notFound("This invitation is invalid or has expired");
  const me = await db.query.users.findFirst({ where: eq(users.id, actor.userId) });
  if (!me || me.email !== inv.email) throw forbidden(`This invitation was sent to ${inv.email}. Sign in with that account to accept it.`);
  await db.transaction(async (tx) => {
    await tx.insert(workspaceMembers).values({ workspaceId: inv.workspaceId, userId: actor.userId, role: inv.role }).onConflictDoNothing();
    await tx.update(invitations).set({ acceptedAt: new Date() }).where(eq(invitations.id, inv.id));
  });
  await audit(db, { workspaceId: inv.workspaceId, userId: actor.userId, action: "invite.accept", targetId: inv.id });
  return { workspaceId: inv.workspaceId };
}
