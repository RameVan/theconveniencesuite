// Exercises the real route handlers (authentication, CSRF, authorization, errors).
import { describe, it, expect, beforeAll, afterAll, beforeEach } from "vitest";
import { NextRequest } from "next/server";
import type { DbHandle } from "@/server/db";
import { setupDb } from "./helpers";
import { resetRateLimits } from "@/server/http";
import * as signupRoute from "@/app/api/auth/signup/route";
import * as loginRoute from "@/app/api/auth/login/route";
import * as meRoute from "@/app/api/auth/me/route";
import * as pagesRoute from "@/app/api/pages/route";
import * as pageRoute from "@/app/api/pages/[id]/route";
import * as contentRoute from "@/app/api/pages/[id]/content/route";
import * as searchRoute from "@/app/api/search/route";
import * as treeRoute from "@/app/api/workspaces/[id]/tree/route";
import * as filesRoute from "@/app/api/files/route";
import * as fileRoute from "@/app/api/files/[id]/route";
import * as tokensRoute from "@/app/api/auth/tokens/route";
import * as exportRoute from "@/app/api/workspaces/[id]/export/route";
import * as recordsRoute from "@/app/api/databases/[id]/records/route";
import { pages } from "@/server/db/schema";
import { eq } from "drizzle-orm";

let h: DbHandle;
beforeAll(async () => {
  h = await setupDb();
});
afterAll(async () => {
  await h.close();
});
beforeEach(() => resetRateLimits());

const ORIGIN = "http://localhost:3000";

function req(method: string, path: string, opts: { body?: unknown; cookie?: string; bearer?: string; origin?: string | null; form?: FormData } = {}) {
  const headers = new Headers({ host: "localhost:3000" });
  if (opts.cookie) headers.set("cookie", opts.cookie);
  if (opts.bearer) headers.set("authorization", `Bearer ${opts.bearer}`);
  if (opts.origin !== null && method !== "GET") headers.set("origin", opts.origin ?? ORIGIN);
  let body: BodyInit | undefined;
  if (opts.form) body = opts.form;
  else if (opts.body !== undefined) {
    headers.set("content-type", "application/json");
    body = JSON.stringify(opts.body);
  }
  return new NextRequest(`${ORIGIN}${path}`, { method, headers, body });
}
const ctx = <P,>(params: P) => ({ params: Promise.resolve(params) });
async function json(res: Response) {
  return { status: res.status, body: (await res.json().catch(() => null)) as Record<string, unknown> };
}

async function signUp(name: string) {
  const email = `${name.toLowerCase()}-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`;
  const res = await signupRoute.POST(req("POST", "/api/auth/signup", { body: { name, email, password: "password123" } }), ctx({}));
  expect(res.status).toBe(200);
  const cookie = res.headers.get("set-cookie")!.split(";")[0];
  const body = (await res.json()) as { workspaceId: string };
  return { cookie, workspaceId: body.workspaceId, email };
}

describe("auth endpoints", () => {
  it("signs up with an HttpOnly session cookie and reports the user", async () => {
    const res = await signupRoute.POST(req("POST", "/api/auth/signup", { body: { name: "Zed", email: `zed-${Date.now()}@example.com`, password: "password123" } }), ctx({}));
    const setCookie = res.headers.get("set-cookie")!;
    expect(setCookie).toMatch(/slate_session=/);
    expect(setCookie).toMatch(/HttpOnly/i);
    expect(setCookie).toMatch(/SameSite=lax/i);
    const cookie = setCookie.split(";")[0];
    const me = await json(await meRoute.GET(req("GET", "/api/auth/me", { cookie }), ctx({})));
    expect((me.body.user as { name: string }).name).toBe("Zed");
  });

  it("rejects bad logins with a generic message", async () => {
    const { email } = await signUp("Lou");
    const bad = await json(await loginRoute.POST(req("POST", "/api/auth/login", { body: { email, password: "nope-nope" } }), ctx({})));
    expect(bad.status).toBe(401);
    const unknown = await json(await loginRoute.POST(req("POST", "/api/auth/login", { body: { email: "missing@example.com", password: "nope-nope" } }), ctx({})));
    expect(unknown.status).toBe(401);
    expect((bad.body.error as { message: string }).message).toBe((unknown.body.error as { message: string }).message);
  });

  it("requires authentication for private endpoints", async () => {
    const r = await json(await pagesRoute.POST(req("POST", "/api/pages", { body: { workspaceId: "x" } }), ctx({})));
    expect(r.status).toBe(401);
  });

  it("rate limits login attempts", async () => {
    let last = 0;
    for (let i = 0; i < 25; i++) last = (await loginRoute.POST(req("POST", "/api/auth/login", { body: { email: "a@b.co", password: "x" } }), ctx({}))).status;
    expect(last).toBe(429);
  });
});

describe("CSRF and tokens", () => {
  it("blocks cross-origin cookie requests but allows bearer tokens", async () => {
    const { cookie, workspaceId } = await signUp("Csrf");
    const evil = await json(await pagesRoute.POST(req("POST", "/api/pages", { cookie, origin: "https://evil.example", body: { workspaceId } }), ctx({})));
    expect(evil.status).toBe(403);
    const noOrigin = await json(await pagesRoute.POST(req("POST", "/api/pages", { cookie, origin: null, body: { workspaceId } }), ctx({})));
    expect(noOrigin.status).toBe(403);
    const ok = await json(await pagesRoute.POST(req("POST", "/api/pages", { cookie, body: { workspaceId, title: "Fine" } }), ctx({})));
    expect(ok.status).toBe(200);

    const tok = await json(await tokensRoute.POST(req("POST", "/api/auth/tokens", { cookie, body: { name: "script" } }), ctx({})));
    const token = tok.body.token as string;
    expect(token).toMatch(/^slt_/);
    const viaToken = await json(await pagesRoute.POST(req("POST", "/api/pages", { bearer: token, origin: null, body: { workspaceId, title: "From API" } }), ctx({})));
    expect(viaToken.status).toBe(200);
    const badToken = await json(await pagesRoute.POST(req("POST", "/api/pages", { bearer: "slt_wrong", origin: null, body: { workspaceId } }), ctx({})));
    expect(badToken.status).toBe(401);
  });
});

describe("authorization through the API (IDOR)", () => {
  it("never exposes another user's content", async () => {
    const alice = await signUp("Alice");
    const eve = await signUp("Eve");
    const created = await json(await pagesRoute.POST(req("POST", "/api/pages", { cookie: alice.cookie, body: { workspaceId: alice.workspaceId, title: "Alice secret plans" } }), ctx({})));
    const pageId = (created.body.page as { id: string }).id;
    await contentRoute.PUT(req("PUT", `/api/pages/${pageId}/content`, { cookie: alice.cookie, body: { blocks: [{ id: "b1", content: { type: "paragraph", content: [{ type: "text", text: "classified zebra" }] } }] } }), ctx({ id: pageId }));

    expect((await pageRoute.GET(req("GET", `/api/pages/${pageId}`, { cookie: eve.cookie }), ctx({ id: pageId }))).status).toBe(404);
    expect((await contentRoute.PUT(req("PUT", `/api/pages/${pageId}/content`, { cookie: eve.cookie, body: { blocks: [] } }), ctx({ id: pageId }))).status).toBe(404);
    expect((await pageRoute.PATCH(req("PATCH", `/api/pages/${pageId}`, { cookie: eve.cookie, body: { title: "pwned" } }), ctx({ id: pageId }))).status).toBe(404);
    expect((await treeRoute.GET(req("GET", `/api/workspaces/${alice.workspaceId}/tree`, { cookie: eve.cookie }), ctx({ id: alice.workspaceId }))).status).toBe(404);
    expect((await exportRoute.GET(req("GET", `/api/workspaces/${alice.workspaceId}/export`, { cookie: eve.cookie }), ctx({ id: alice.workspaceId }))).status).toBe(404);
    // Eve cannot create pages in Alice's workspace or attach to her pages.
    expect((await pagesRoute.POST(req("POST", "/api/pages", { cookie: eve.cookie, body: { workspaceId: alice.workspaceId } }), ctx({}))).status).toBe(404);
    expect((await pagesRoute.POST(req("POST", "/api/pages", { cookie: eve.cookie, body: { workspaceId: eve.workspaceId, parentId: pageId } }), ctx({}))).status).toBe(404);
    // Search returns nothing from Alice's workspace, even when targeted directly.
    const s1 = await json(await searchRoute.GET(req("GET", `/api/search?q=zebra`, { cookie: eve.cookie }), ctx({})));
    expect(s1.body.results).toEqual([]);
    const s2 = await json(await searchRoute.GET(req("GET", `/api/search?q=zebra&workspaceId=${alice.workspaceId}`, { cookie: eve.cookie }), ctx({})));
    expect(s2.body.results).toEqual([]);
    const s3 = await json(await searchRoute.GET(req("GET", `/api/search?q=zebra`, { cookie: alice.cookie }), ctx({})));
    expect((s3.body.results as { id: string }[]).map((r) => r.id)).toContain(pageId);
    // Records of Alice's databases cannot be listed.
    const dbRes = await json(await pagesRoute.POST(req("POST", "/api/pages", { cookie: alice.cookie, body: { workspaceId: alice.workspaceId, kind: "database", title: "CRM" } }), ctx({})));
    const dbId = (dbRes.body.page as { id: string }).id;
    expect((await recordsRoute.GET(req("GET", `/api/databases/${dbId}/records?q=`, { cookie: eve.cookie }), ctx({ id: dbId }))).status).toBe(404);
    expect((await recordsRoute.POST(req("POST", `/api/databases/${dbId}/records`, { cookie: eve.cookie, body: { title: "x" } }), ctx({ id: dbId }))).status).toBe(404);
  });

  it("protects uploaded files", async () => {
    const alice = await signUp("Fil");
    const eve = await signUp("Eav");
    const form = new FormData();
    form.set("file", new File([new Uint8Array([0x25, 0x50, 0x44, 0x46, 0x2d, 0x31])], "doc.pdf", { type: "application/pdf" }));
    form.set("workspaceId", alice.workspaceId);
    const up = await json(await filesRoute.POST(req("POST", "/api/files", { cookie: alice.cookie, form }), ctx({})));
    expect(up.status).toBe(200);
    const id = up.body.id as string;
    const mine = await fileRoute.GET(req("GET", `/api/files/${id}`, { cookie: alice.cookie }), ctx({ id }));
    expect(mine.status).toBe(200);
    expect(mine.headers.get("content-type")).toBe("application/pdf");
    expect(mine.headers.get("x-content-type-options")).toBe("nosniff");
    expect(mine.headers.get("content-security-policy")).toContain("sandbox");
    expect((await fileRoute.GET(req("GET", `/api/files/${id}`, { cookie: eve.cookie }), ctx({ id }))).status).toBe(404);
    expect((await fileRoute.GET(req("GET", `/api/files/${id}`), ctx({ id }))).status).toBe(404);

    // HTML uploads are never served as HTML.
    const form2 = new FormData();
    form2.set("file", new File(["<script>alert(1)</script>"], "x.html", { type: "text/html" }));
    form2.set("workspaceId", alice.workspaceId);
    const up2 = await json(await filesRoute.POST(req("POST", "/api/files", { cookie: alice.cookie, form: form2 }), ctx({})));
    const res2 = await fileRoute.GET(req("GET", `/api/files/${up2.body.id}`, { cookie: alice.cookie }), ctx({ id: up2.body.id as string }));
    expect(res2.headers.get("content-type")).toBe("application/octet-stream");
    expect(res2.headers.get("content-disposition")).toMatch(/^attachment/);
  });

  it("returns validation errors instead of crashing", async () => {
    const u = await signUp("Val");
    const r = await json(await pagesRoute.POST(req("POST", "/api/pages", { cookie: u.cookie, body: { workspaceId: 123 } }), ctx({})));
    expect(r.status).toBe(400);
    const bad = await pagesRoute.POST(
      new NextRequest(`${ORIGIN}/api/pages`, { method: "POST", headers: { host: "localhost:3000", origin: ORIGIN, cookie: u.cookie, "content-type": "application/json" }, body: "{not json" }),
      ctx({}),
    );
    expect(bad.status).toBe(400);
  });
});

describe("atomicity", () => {
  it("rolls back a failed content save completely", async () => {
    const u = await signUp("Atom");
    const created = await json(await pagesRoute.POST(req("POST", "/api/pages", { cookie: u.cookie, body: { workspaceId: u.workspaceId, title: "Atomic" } }), ctx({})));
    const id = (created.body.page as { id: string }).id;
    const good = { id: "a1", content: { type: "paragraph", content: [{ type: "text", text: "keep me" }] } };
    expect((await contentRoute.PUT(req("PUT", `/api/pages/${id}/content`, { cookie: u.cookie, body: { blocks: [good] } }), ctx({ id }))).status).toBe(200);
    // A batch where the last block is invalid must not partially apply.
    const r = await contentRoute.PUT(
      req("PUT", `/api/pages/${id}/content`, { cookie: u.cookie, body: { blocks: [{ id: "a2", content: { type: "paragraph", content: [{ type: "text", text: "new" }] } }, { id: "a3", content: { type: "evil" } }] } }),
      ctx({ id }),
    );
    expect(r.status).toBe(400);
    const page = await json(await pageRoute.GET(req("GET", `/api/pages/${id}`, { cookie: u.cookie }), ctx({ id })));
    expect(JSON.stringify(page.body.content)).toContain("keep me");
    expect(JSON.stringify(page.body.content)).not.toContain("new");
    const [row] = await h.db.select({ version: pages.version }).from(pages).where(eq(pages.id, id));
    expect(row.version).toBe(2);
  });
});
