// Reproduction: a client keeps its document across a server restart and reconnects.
import { it, expect } from "vitest";
import WebSocket from "ws";
import * as Y from "yjs";
import { HocuspocusProvider, HocuspocusProviderWebsocket } from "@hocuspocus/provider";
import { yDocToProsemirrorJSON } from "@tiptap/y-tiptap";
import { setupDb, makeUser, makeWorkspace } from "./helpers";
import { createPage, saveContent, getBlocks } from "@/server/services/pages";
import { createCollabServer, setCollabInstance, notifyContentChanged } from "@/server/collab";
import { YDOC_FIELD } from "@/lib/editor-schema";
import * as B from "@/lib/block-builders";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const text = (doc: Y.Doc) => JSON.stringify(yDocToProsemirrorJSON(doc, YDOC_FIELD));

it("does not duplicate content when a client reconnects after a server restart", async () => {
  const h = await setupDb();
  const u = await makeUser(h, "restart");
  const ws = await makeWorkspace(h, u.actor);
  const page = await createPage(h.db, u.actor, { workspaceId: ws.id, title: "r" });
  await saveContent(h.db, u.actor, page.id, { blocks: [B.p("start")].map((b) => ({ id: b.attrs!.id as string, content: b })) });

  const connect = (port: number, doc: Y.Doc) => {
    class CookieWS extends WebSocket {
      constructor(address: string, protocols?: string | string[]) {
        super(address, protocols, { headers: { cookie: `slate_session=${u.token}`, origin: "http://127.0.0.1:3000" } });
      }
    }
    const wsp = new HocuspocusProviderWebsocket({ url: `ws://127.0.0.1:${port}`, WebSocketPolyfill: CookieWS });
    const p = new HocuspocusProvider({ name: page.id, document: doc, websocketProvider: wsp });
    p.attach();
    const synced = new Promise<boolean>((res) => {
      p.on("synced", () => res(true));
      setTimeout(() => res(false), 3000);
    });
    return { p, wsp, synced };
  };

  // Server 1: client edits, then a REST write is pushed into the live document.
  let s1 = createCollabServer({ port: 0, host: "127.0.0.1", debounce: 50 });
  await s1.listen(0);
  setCollabInstance(s1.hocuspocus);
  const doc = new Y.Doc();
  let c = connect(s1.address.port, doc);
  expect(await c.synced).toBe(true);
  await saveContent(h.db, u.actor, page.id, { blocks: [B.p("Body text")].map((b) => ({ id: b.attrs!.id as string, content: b })) });
  await notifyContentChanged(page.id);
  await sleep(300);
  expect(text(doc)).toContain("Body text");
  c.p.destroy();
  c.wsp.destroy();
  // Process dies (no graceful store).
  await s1.destroy();

  // Server 2 (new process, same database); the client reconnects with its old document.
  const s2 = createCollabServer({ port: 0, host: "127.0.0.1", debounce: 50 });
  await s2.listen(0);
  setCollabInstance(s2.hocuspocus);
  c = connect(s2.address.port, doc);
  expect(await c.synced).toBe(true);
  await sleep(300);
  s2.hocuspocus.flushPendingStores();
  await sleep(300);
  const t = text(doc);
  const db = JSON.stringify(await getBlocks(h.db, page.id));
  c.p.destroy();
  c.wsp.destroy();
  await s2.destroy();
  setCollabInstance(undefined);
  await h.close();
  expect(t.match(/Body text/g)?.length).toBe(1);
  expect(db.match(/Body text/g)?.length).toBe(1);
  void s1;
  s1 = undefined as never;
});

it("does not duplicate content when a viewer-only session spans a server restart", async () => {
  const h = await setupDb();
  const u = await makeUser(h, "restart2");
  const ws = await makeWorkspace(h, u.actor);
  const page = await createPage(h.db, u.actor, { workspaceId: ws.id, title: "r2" });
  await saveContent(h.db, u.actor, page.id, { blocks: [B.p("Only once")].map((b) => ({ id: b.attrs!.id as string, content: b })) });
  class CookieWS extends WebSocket {
    constructor(address: string, protocols?: string | string[]) {
      super(address, protocols, { headers: { cookie: `slate_session=${u.token}`, origin: "http://127.0.0.1:3000" } });
    }
  }
  const doc = new Y.Doc();
  const open = async (port: number) => {
    const wsp = new HocuspocusProviderWebsocket({ url: `ws://127.0.0.1:${port}`, WebSocketPolyfill: CookieWS });
    const p = new HocuspocusProvider({ name: page.id, document: doc, websocketProvider: wsp });
    p.attach();
    const ok = await new Promise<boolean>((res) => {
      p.on("synced", () => res(true));
      setTimeout(() => res(false), 3000);
    });
    return { ok, close: () => (p.destroy(), wsp.destroy()) };
  };
  const s1 = createCollabServer({ port: 0, host: "127.0.0.1", debounce: 50 });
  await s1.listen(0);
  const a = await open(s1.address.port);
  expect(a.ok).toBe(true);
  a.close();
  await s1.destroy(); // no edits were made, so nothing was stored by onStoreDocument
  const s2 = createCollabServer({ port: 0, host: "127.0.0.1", debounce: 50 });
  await s2.listen(0);
  const b = await open(s2.address.port);
  expect(b.ok).toBe(true);
  await sleep(300);
  const t = text(doc);
  b.close();
  await s2.destroy();
  await h.close();
  expect(t.match(/Only once/g)?.length).toBe(1);
});
