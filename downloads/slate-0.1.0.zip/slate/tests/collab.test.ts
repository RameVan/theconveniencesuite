// Realtime collaboration through the real Hocuspocus server and WebSocket clients.
import { describe, it, expect, beforeAll, afterAll } from "vitest";
import WebSocket from "ws";
import * as Y from "yjs";
import { HocuspocusProvider, HocuspocusProviderWebsocket } from "@hocuspocus/provider";
import { yDocToProsemirrorJSON } from "@tiptap/y-tiptap";
import { eq } from "drizzle-orm";
import type { Server } from "@hocuspocus/server";
import type { DbHandle } from "@/server/db";
import { pageYdocs, pages } from "@/server/db/schema";
import { setupDb, makeUser, makeWorkspace } from "./helpers";
import { createPage, saveContent, getBlocks } from "@/server/services/pages";
import { createInvitation, acceptInvitation } from "@/server/services/workspaces";
import { createCollabServer, setCollabInstance, notifyContentChanged, type CollabContext } from "@/server/collab";
import { YDOC_FIELD } from "@/lib/editor-schema";
import * as B from "@/lib/block-builders";

let h: DbHandle;
let server: Server<CollabContext>;
let url = "";
const ORIGIN = "http://127.0.0.1:3000";
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

beforeAll(async () => {
  h = await setupDb();
  server = createCollabServer({ port: 0, host: "127.0.0.1", debounce: 50 });
  await server.listen(0);
  setCollabInstance(server.hocuspocus);
  url = `ws://127.0.0.1:${server.address.port}`;
});
afterAll(async () => {
  setCollabInstance(undefined);
  await server.destroy();
  await h.close();
});

function connect(pageId: string, token: string | null, origin = ORIGIN) {
  class CookieWS extends WebSocket {
    constructor(address: string, protocols?: string | string[]) {
      super(address, protocols, { headers: { ...(token ? { cookie: `slate_session=${token}` } : {}), origin } });
    }
  }
  const doc = new Y.Doc();
  const websocketProvider = new HocuspocusProviderWebsocket({ url, WebSocketPolyfill: CookieWS, maxAttempts: 1 });
  const provider = new HocuspocusProvider({ name: pageId, document: doc, websocketProvider });
  provider.attach();
  const synced = new Promise<boolean>((resolve) => {
    provider.on("synced", () => resolve(true));
    setTimeout(() => resolve(false), 3000);
  });
  return {
    doc,
    synced,
    destroy: () => {
      provider.destroy();
      websocketProvider.destroy();
    },
  };
}

const text = (doc: Y.Doc) => JSON.stringify(yDocToProsemirrorJSON(doc, YDOC_FIELD));

function addParagraph(doc: Y.Doc, at: "start" | "end", s: string) {
  const fragment = doc.getXmlFragment(YDOC_FIELD);
  const el = new Y.XmlElement("paragraph");
  el.insert(0, [new Y.XmlText(s)]);
  fragment.insert(at === "start" ? 0 : fragment.length, [el]);
}

async function waitFor(check: () => boolean, ms = 3000) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    if (check()) return true;
    await sleep(25);
  }
  return check();
}

describe("realtime collaboration", () => {
  it("merges concurrent edits, persists them to blocks, and enforces permissions", async () => {
    const owner = await makeUser(h, "Collab Owner");
    const viewer = await makeUser(h, "Collab Viewer");
    const outsider = await makeUser(h, "Collab Outsider");
    const ws = await makeWorkspace(h, owner.actor);
    const inv = await createInvitation(h.db, owner.actor, ws.id, { email: viewer.email, role: "viewer" });
    await acceptInvitation(h.db, viewer.actor, inv.token);
    const page = await createPage(h.db, owner.actor, { workspaceId: ws.id, title: "Live doc" });
    await saveContent(h.db, owner.actor, page.id, { blocks: [B.p("original text")].map((b) => ({ id: b.attrs!.id as string, content: b })) });

    // Two editors on the same document (two sessions of the owner).
    const a = connect(page.id, owner.token);
    const { createSession } = await import("@/server/services/auth");
    const second = await createSession(h.db, owner.user.id);
    const b = connect(page.id, second.token);
    expect(await a.synced).toBe(true);
    expect(await b.synced).toBe(true);
    expect(text(a.doc)).toContain("original text");

    // Concurrent edits converge on both sides.
    addParagraph(a.doc, "start", "from A");
    addParagraph(b.doc, "end", "from B");
    expect(await waitFor(() => text(a.doc).includes("from B") && text(b.doc).includes("from A"))).toBe(true);
    expect(text(a.doc)).toBe(text(b.doc));

    // Viewers get updates but cannot write.
    const v = connect(page.id, viewer.token);
    expect(await v.synced).toBe(true);
    expect(text(v.doc)).toContain("from A");
    addParagraph(v.doc, "end", "viewer was here");
    await sleep(400);
    expect(text(a.doc)).not.toContain("viewer was here");

    // Outsiders, anonymous users and foreign origins are rejected.
    const o = connect(page.id, outsider.token);
    const anon = connect(page.id, null);
    const evil = connect(page.id, owner.token, "https://evil.example");
    expect(await o.synced).toBe(false);
    expect(await anon.synced).toBe(false);
    expect(await evil.synced).toBe(false);
    [o, anon, evil].forEach((c) => c.destroy());

    // Edits are written to the block table (search, history and export use it).
    server.hocuspocus.flushPendingStores();
    expect(
      await waitFor(() => false, 0).then(async () => {
        for (let i = 0; i < 60; i++) {
          const s = JSON.stringify(await getBlocks(h.db, page.id));
          if (s.includes("from A") && s.includes("from B")) return true;
          await sleep(50);
        }
        return false;
      }),
    ).toBe(true);
    const blocks = await getBlocks(h.db, page.id);
    expect(blocks.map((x) => x.attrs?.id).every((id) => typeof id === "string" && id.length > 0)).toBe(true);
    expect(new Set(blocks.map((x) => x.attrs?.id)).size).toBe(blocks.length);
    expect(JSON.stringify(blocks)).not.toContain("viewer was here");
    const [row] = await h.db.select().from(pageYdocs).where(eq(pageYdocs.pageId, page.id));
    const [pg] = await h.db.select({ version: pages.version }).from(pages).where(eq(pages.id, page.id));
    expect(row.contentVersion).toBe(pg.version);

    // A REST save (e.g. restore or API) reaches connected editors.
    await saveContent(h.db, owner.actor, page.id, { blocks: [B.p("replaced over REST")].map((x) => ({ id: x.attrs!.id as string, content: x })) });
    await notifyContentChanged(page.id);
    expect(await waitFor(() => text(a.doc).includes("replaced over REST") && !text(a.doc).includes("from A"))).toBe(true);
    expect(await waitFor(() => text(b.doc) === text(a.doc))).toBe(true);

    [a, b, v].forEach((c) => c.destroy());
    await sleep(300);

    // After everyone leaves, a new session loads the persisted state.
    const c = connect(page.id, owner.token);
    expect(await c.synced).toBe(true);
    expect(text(c.doc)).toContain("replaced over REST");
    expect(text(c.doc)).not.toContain("from A");
    c.destroy();
  });

  it("does not duplicate content when a stale client reconnects after a REST write", async () => {
    const owner = await makeUser(h, "Stale Owner");
    const ws = await makeWorkspace(h, owner.actor);
    const page = await createPage(h.db, owner.actor, { workspaceId: ws.id, title: "Stale" });
    await saveContent(h.db, owner.actor, page.id, { blocks: [B.p("first version")].map((b) => ({ id: b.attrs!.id as string, content: b })) });
    const a = connect(page.id, owner.token);
    expect(await a.synced).toBe(true);
    addParagraph(a.doc, "end", "live edit");
    await sleep(300);
    server.hocuspocus.flushPendingStores();
    await sleep(500);
    // Keep the client's (now stale) document, close its connection.
    const staleState = Y.encodeStateAsUpdate(a.doc);
    a.destroy();
    await sleep(400);
    // Content changes while nobody is connected.
    await saveContent(h.db, owner.actor, page.id, { blocks: [B.p("second version")].map((b) => ({ id: b.attrs!.id as string, content: b })) });
    // The stale client comes back and syncs its old state.
    const b = connect(page.id, owner.token);
    Y.applyUpdate(b.doc, staleState);
    expect(await b.synced).toBe(true);
    await sleep(300);
    const t = text(b.doc);
    expect(t).toContain("second version");
    expect(t).not.toContain("first version");
    expect(t).not.toContain("live edit");
    b.destroy();
  });
});

describe("realtime edits with mentions and comment anchors", () => {
  it("persists mentions and comment marks typed in a live document and notifies the mentioned member", async () => {
    const owner = await makeUser(h, "Mention Owner");
    const mate = await makeUser(h, "Mention Mate");
    const ws = await makeWorkspace(h, owner.actor);
    const inv = await createInvitation(h.db, owner.actor, ws.id, { email: mate.email, role: "editor" });
    await acceptInvitation(h.db, mate.actor, inv.token);
    const page = await createPage(h.db, owner.actor, { workspaceId: ws.id, title: "Live mentions" });
    const a = connect(page.id, owner.token);
    expect(await a.synced).toBe(true);
    a.doc.transact(() => {
      const fragment = a.doc.getXmlFragment(YDOC_FIELD);
      const el = new Y.XmlElement("paragraph");
      el.setAttribute("id", "m-block");
      const t = new Y.XmlText();
      t.insert(0, "Thanks ");
      t.insert(7, "team", { comment: { threadId: "thread-x" } });
      const mention = new Y.XmlElement("mention");
      mention.setAttribute("userId", mate.user.id);
      mention.setAttribute("label", "Mention Mate");
      el.insert(0, [t, mention]);
      fragment.insert(fragment.length, [el]);
    });
    server.hocuspocus.flushPendingStores();
    let stored = "";
    for (let i = 0; i < 60 && !stored.includes('"mention"'); i++) {
      await sleep(50);
      stored = JSON.stringify(await getBlocks(h.db, page.id));
    }
    expect(stored).toContain(`"userId":"${mate.user.id}"`);
    expect(stored).toContain('"threadId":"thread-x"');
    const { listNotifications } = await import("@/server/services/notifications");
    const n = await listNotifications(h.db, mate.actor, { workspaceId: ws.id });
    expect(n.notifications.map((x) => [x.kind, x.blockId])).toEqual([["page_mention", "m-block"]]);
    a.destroy();
  });
});

describe("no spurious versions", () => {
  it("a realtime store of unchanged content keeps the page version, so REST editors don't conflict", async () => {
    const owner = await makeUser(h, "Steady Owner");
    const ws = await makeWorkspace(h, owner.actor);
    const page = await createPage(h.db, owner.actor, { workspaceId: ws.id, title: "Steady" });
    const blocks = [B.p("one"), B.p("two")].map((b) => ({ id: b.attrs!.id as string, content: b }));
    const v1 = await saveContent(h.db, owner.actor, page.id, { blocks });
    const a = connect(page.id, owner.token);
    expect(await a.synced).toBe(true);

    // A REST save is pushed into the open document; the server then stores that document.
    const v2 = await saveContent(h.db, owner.actor, page.id, { baseVersion: v1.version, blocks: [...blocks, { id: "c3", content: { type: "paragraph", attrs: { id: "c3" }, content: [{ type: "text", text: "three", marks: [{ type: "bold" }] }] } }] });
    await notifyContentChanged(page.id);
    await waitFor(() => text(a.doc).includes("three"));
    // A live edit that ends with the same content still makes the server store the document.
    a.doc.transact(() => {
      addParagraph(a.doc, "end", "temporary");
      const fragment = a.doc.getXmlFragment(YDOC_FIELD);
      fragment.delete(fragment.length - 1, 1);
    });
    await sleep(200);
    server.hocuspocus.flushPendingStores();
    await sleep(300);
    expect(text(a.doc)).not.toContain("temporary");
    const [pg] = await h.db.select({ version: pages.version }).from(pages).where(eq(pages.id, page.id));
    expect(pg.version).toBe(v2.version);
    // The REST editor's next save (based on v2) succeeds.
    await expect(saveContent(h.db, owner.actor, page.id, { baseVersion: v2.version, blocks })).resolves.toMatchObject({ version: v2.version + 1 });
    a.destroy();
  });
});
