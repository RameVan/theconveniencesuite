import { describe, it, expect, beforeAll, afterAll } from "vitest";
import type { DbHandle } from "@/server/db";
import { setupDb, makeUser, makeWorkspace } from "./helpers";
import { createPage, saveContent, getPage } from "@/server/services/pages";
import { createInvitation, acceptInvitation, removeMember } from "@/server/services/workspaces";
import { addComment, listComments, updateComment, deleteComment } from "@/server/services/comments";
import { listNotifications, markRead } from "@/server/services/notifications";
import { setUserAccess } from "@/server/services/sharing";
import { restoreRevision, listRevisions } from "@/server/services/revisions";
import { commentMentionToken } from "@/lib/mentions";
import { validateBlocks } from "@/lib/blocks";
import { blocksToMarkdown } from "@/lib/markdown";
import { AppError } from "@/server/errors";
import type { Actor } from "@/server/services/auth";

let h: DbHandle;
type U = Awaited<ReturnType<typeof makeUser>>;
let owner: U, member: U, outsider: U;
let wsId: string;

async function join(user: U, role: "editor" | "viewer" = "editor") {
  const inv = await createInvitation(h.db, owner.actor, wsId, { email: user.email, role });
  await acceptInvitation(h.db, user.actor, inv.token);
}

const para = (id: string, ...content: unknown[]) => ({ id, content: { type: "paragraph", attrs: { id }, content } });
const mention = (u: U) => ({ type: "mention", attrs: { userId: u.user.id, label: u.user.name } });
const text = (t: string, marks?: unknown[]) => (marks ? { type: "text", text: t, marks } : { type: "text", text: t });
const inbox = async (a: Actor) => (await listNotifications(h.db, a, { workspaceId: wsId })).notifications;

beforeAll(async () => {
  h = await setupDb();
  owner = await makeUser(h, "Owner");
  member = await makeUser(h, "Member");
  outsider = await makeUser(h, "Outsider");
  wsId = (await makeWorkspace(h, owner.actor)).id;
  await join(member);
});
afterAll(async () => h.close());

describe("mentions in page content", () => {
  it("validates mention nodes and comment marks", () => {
    const [b] = validateBlocks([para("b1", mention(member), text(" hi", [{ type: "comment", attrs: { threadId: "t1" } }, { type: "comment", attrs: { threadId: "bad id!" } }]))]);
    const inline = b.content.content!;
    expect(inline[0]).toEqual({ type: "mention", attrs: { userId: member.user.id, label: "Member" } });
    expect(inline[1].marks).toEqual([{ type: "comment", attrs: { threadId: "t1" } }]); // invalid anchor dropped
    expect(blocksToMarkdown([b.content], {})).toContain("@Member");
  });

  it("notifies a newly mentioned member once, with the block and an excerpt", async () => {
    const page = await createPage(h.db, owner.actor, { workspaceId: wsId, title: "Plan" });
    const v1 = await saveContent(h.db, owner.actor, page.id, { blocks: [para("b1", text("Ask "), mention(member), text(" about the budget"))] });
    let list = await inbox(member.actor);
    expect(list).toHaveLength(1);
    expect(list[0]).toMatchObject({ kind: "page_mention", pageId: page.id, blockId: "b1", actorName: "Owner", excerpt: "Ask @Member about the budget" });
    expect((await listNotifications(h.db, member.actor, { workspaceId: wsId })).unread).toBe(1);

    // Re-saving, editing elsewhere, or removing and re-adding the mention does not notify again.
    const v2 = await saveContent(h.db, owner.actor, page.id, { baseVersion: v1.version, blocks: [para("b1", text("Ask "), mention(member), text(" about the budget!")), para("b2", text("more"))] });
    const v3 = await saveContent(h.db, owner.actor, page.id, { baseVersion: v2.version, blocks: [para("b1", text("Ask about the budget"))] });
    await saveContent(h.db, owner.actor, page.id, { baseVersion: v3.version, blocks: [para("b1", text("Ask "), mention(member))] });
    list = await inbox(member.actor);
    expect(list).toHaveLength(1);

    // Mentioning yourself never notifies.
    const own = await createPage(h.db, member.actor, { workspaceId: wsId, title: "Mine" });
    await saveContent(h.db, member.actor, own.id, { blocks: [para("m1", mention(member))] });
    expect(await inbox(member.actor)).toHaveLength(1);
  });

  it("never notifies people who cannot view the page", async () => {
    const priv = await createPage(h.db, owner.actor, { workspaceId: wsId, title: "Secret", visibility: "private" });
    await saveContent(h.db, owner.actor, priv.id, { blocks: [para("s1", text("Salary review for "), mention(member), text(" and "), mention(outsider))] });
    const titles = (await inbox(member.actor)).map((n) => n.pageTitle);
    expect(titles).not.toContain("Secret");
    expect((await listNotifications(h.db, outsider.actor)).notifications).toHaveLength(0);

    // Once the page is shared with them, a new mention reaches them.
    await setUserAccess(h.db, owner.actor, priv.id, { email: member.email, access: "view" });
    const cur = await getPage(h.db, owner.actor, priv.id);
    await saveContent(h.db, owner.actor, priv.id, { baseVersion: cur.page.version, blocks: [para("s2", mention(member))] });
    expect((await inbox(member.actor)).map((n) => n.pageTitle)).toContain("Secret");

    // Revoking access hides the notification (and its excerpt) again.
    await setUserAccess(h.db, owner.actor, priv.id, { email: member.email, access: null });
    expect((await inbox(member.actor)).map((n) => n.pageTitle)).not.toContain("Secret");
  });

  it("restoring an old version does not re-notify", async () => {
    const page = await createPage(h.db, owner.actor, { workspaceId: wsId, title: "Restore me" });
    const v1 = await saveContent(h.db, owner.actor, page.id, { blocks: [para("r1", mention(member))] });
    await saveContent(h.db, owner.actor, page.id, { baseVersion: v1.version, blocks: [para("r1", text("gone"))] });
    const before = (await inbox(member.actor)).length;
    const revs = await listRevisions(h.db, owner.actor, page.id);
    const withMention = revs.find((r) => r.reason !== "conflict") ?? revs[revs.length - 1];
    await restoreRevision(h.db, owner.actor, page.id, withMention.id);
    expect((await inbox(member.actor)).length).toBe(before);
  });
});

describe("comment threads", () => {
  it("creates inline threads with replies, mentions and reply notifications", async () => {
    const page = await createPage(h.db, owner.actor, { workspaceId: wsId, title: "Spec" });
    const readAll = () => markRead(h.db, member.actor, { all: true, workspaceId: wsId });
    await readAll();
    await markRead(h.db, owner.actor, { all: true });

    // Owner opens an inline thread (client-chosen id) and mentions Member.
    const body = `Can ${commentMentionToken("Member", member.user.id)} check this?`;
    const { id: threadId } = await addComment(h.db, owner.actor, page.id, { id: "thread-1", body, blockId: "b1", quote: "the budget" });
    expect(threadId).toBe("thread-1");
    let mine = await inbox(member.actor);
    expect(mine[0]).toMatchObject({ kind: "comment_mention", commentId: "thread-1", excerpt: "Can @Member check this?" });

    // Member replies: owner (thread author) is notified; member is not notified of their own reply.
    const reply = await addComment(h.db, member.actor, page.id, { body: "On it", parentId: threadId });
    const ownerInbox = await inbox(owner.actor);
    expect(ownerInbox[0]).toMatchObject({ kind: "reply", commentId: reply.id, actorName: "Member", excerpt: "On it" });
    mine = await inbox(member.actor);
    expect(mine.filter((n) => n.kind === "reply")).toHaveLength(0);

    const list = await listComments(h.db, owner.actor, page.id);
    expect(list.map((c) => [c.id, c.parentId, c.blockId, c.quote])).toEqual([
      ["thread-1", null, "b1", "the budget"],
      [reply.id, "thread-1", null, null],
    ]);

    // Replies can't be nested or carry anchors; ids can't be reused.
    await expect(addComment(h.db, owner.actor, page.id, { body: "x", parentId: reply.id })).rejects.toMatchObject({ status: 400 });
    await expect(addComment(h.db, owner.actor, page.id, { body: "x", parentId: threadId, quote: "q" })).rejects.toMatchObject({ status: 400 });
    await expect(addComment(h.db, owner.actor, page.id, { body: "x", id: "thread-1" })).rejects.toMatchObject({ status: 409 });
    await expect(addComment(h.db, owner.actor, page.id, { body: "x", id: "bad id" })).rejects.toBeInstanceOf(Error);

    // Resolving applies to threads; deleting the root removes replies.
    await updateComment(h.db, member.actor, page.id, threadId, { resolved: true });
    await expect(updateComment(h.db, owner.actor, page.id, reply.id, { resolved: true })).rejects.toMatchObject({ status: 400 });
    expect((await listComments(h.db, owner.actor, page.id))[0].resolved).toBe(true);
    await deleteComment(h.db, owner.actor, page.id, threadId);
    expect(await listComments(h.db, owner.actor, page.id)).toHaveLength(0);
  });

  it("editing a comment notifies only newly mentioned people", async () => {
    const page = await createPage(h.db, owner.actor, { workspaceId: wsId, title: "Edits" });
    await markRead(h.db, member.actor, { all: true });
    const { id } = await addComment(h.db, owner.actor, page.id, { body: "Draft" });
    const count = async () => (await inbox(member.actor)).filter((n) => n.commentId === id).length;
    await updateComment(h.db, owner.actor, page.id, id, { body: `Draft for ${commentMentionToken("Member", member.user.id)}` });
    expect(await count()).toBe(1);
    await updateComment(h.db, owner.actor, page.id, id, { body: `Final for ${commentMentionToken("Member", member.user.id)}` });
    expect(await count()).toBe(1);
    await expect(updateComment(h.db, member.actor, page.id, id, { body: "hijack" })).rejects.toMatchObject({ status: 403 });
  });

  it("outsiders can't comment, list comments or mention-probe pages", async () => {
    const page = await createPage(h.db, owner.actor, { workspaceId: wsId, title: "Closed" });
    await expect(addComment(h.db, outsider.actor, page.id, { body: "hi" })).rejects.toMatchObject({ status: 404 });
    await expect(listComments(h.db, outsider.actor, page.id)).rejects.toMatchObject({ status: 404 });
    // A member mentioning an outsider in a comment does not notify them.
    await addComment(h.db, member.actor, page.id, { body: commentMentionToken("Outsider", outsider.user.id) });
    expect((await listNotifications(h.db, outsider.actor)).notifications).toHaveLength(0);
  });

  it("removed members lose their notifications for the workspace", async () => {
    const extra = await makeUser(h, "Temp");
    await join(extra);
    const page = await createPage(h.db, owner.actor, { workspaceId: wsId, title: "Team" });
    await addComment(h.db, owner.actor, page.id, { body: commentMentionToken("Temp", extra.user.id) });
    expect(await inbox(extra.actor)).toHaveLength(1);
    await removeMember(h.db, owner.actor, wsId, extra.user.id);
    expect(await inbox(extra.actor)).toHaveLength(0);
  });

  it("marks notifications read by id or all at once, only your own", async () => {
    const page = await createPage(h.db, owner.actor, { workspaceId: wsId, title: "Reads" });
    await addComment(h.db, owner.actor, page.id, { body: `1 ${commentMentionToken("Member", member.user.id)}` });
    await addComment(h.db, owner.actor, page.id, { body: `2 ${commentMentionToken("Member", member.user.id)}` });
    const [n1] = await inbox(member.actor);
    // Someone else's ids are ignored.
    await markRead(h.db, owner.actor, { ids: [n1.id] });
    expect((await inbox(member.actor))[0].readAt).toBeNull();
    const r = await markRead(h.db, member.actor, { ids: [n1.id] });
    expect((await inbox(member.actor))[0].readAt).not.toBeNull();
    expect(r.unread).toBeGreaterThan(0);
    expect((await markRead(h.db, member.actor, { all: true, workspaceId: wsId })).unread).toBe(0);
  });
});

void AppError;

describe("saving unchanged content", () => {
  it("does not rewrite blocks whose content is unchanged (jsonb key order is ignored)", async () => {
    const { blocks: blocksTable } = await import("@/server/db/schema");
    const { eq } = await import("drizzle-orm");
    const page = await createPage(h.db, owner.actor, { workspaceId: wsId, title: "Stable" });
    const content = [para("k1", text("bold", [{ type: "bold" }]), mention(member))];
    const v1 = await saveContent(h.db, owner.actor, page.id, { blocks: content });
    const [before] = await h.db.select({ updatedAt: blocksTable.updatedAt }).from(blocksTable).where(eq(blocksTable.pageId, page.id));
    await new Promise((r) => setTimeout(r, 20));
    await saveContent(h.db, owner.actor, page.id, { baseVersion: v1.version, blocks: content });
    const [after] = await h.db.select({ updatedAt: blocksTable.updatedAt }).from(blocksTable).where(eq(blocksTable.pageId, page.id));
    expect(after.updatedAt.getTime()).toBe(before.updatedAt.getTime());
  });
});
