import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { eq } from "drizzle-orm";
import type { DbHandle } from "@/server/db";
import { pages as pagesTable, favorites } from "@/server/db/schema";
import { setupDb, makeUser, makeWorkspace } from "./helpers";
import { login, getSessionUser, deleteSession, createApiToken, getTokenUser, revokeApiToken, changePassword, signup } from "@/server/services/auth";
import {
  createPage,
  getPage,
  updatePage,
  saveContent,
  movePage,
  archivePage,
  restorePage,
  deletePermanently,
  listTrash,
  duplicatePage,
  getTree,
  setFavorite,
  moveFavorite,
  recordVisit,
  recentPages,
} from "@/server/services/pages";
import { listRevisions, restoreRevision, getRevision } from "@/server/services/revisions";
import { createInvitation, acceptInvitation, listMembers, updateMemberRole, removeMember } from "@/server/services/workspaces";
import { setUserAccess, setPublicShare, getPublicPage } from "@/server/services/sharing";
import { AppError } from "@/server/errors";
import * as B from "@/lib/block-builders";

let h: DbHandle;
beforeAll(async () => {
  h = await setupDb();
});
afterAll(async () => {
  await h.close();
});

const blk = (...nodes: ReturnType<typeof B.p>[]) => nodes.map((b) => ({ id: b.attrs!.id as string, content: b }));

async function expectError(p: Promise<unknown>, status: number) {
  try {
    await p;
  } catch (e) {
    expect(e).toBeInstanceOf(AppError);
    expect((e as AppError).status).toBe(status);
    return e as AppError;
  }
  throw new Error(`expected HTTP ${status} error`);
}

describe("auth", () => {
  it("signs up, logs in, uses sessions and API tokens", async () => {
    const { user, actor, token, email } = await makeUser(h, "Alice");
    expect(user.email).toBe(email);
    const logged = await login(h.db, { email, password: "password123" });
    expect(logged.id).toBe(user.id);
    await expectError(login(h.db, { email, password: "wrong-password" }), 401);
    await expectError(login(h.db, { email: "nobody@example.com", password: "password123" }), 401);
    const s = await getSessionUser(h.db, token);
    expect(s?.user.id).toBe(user.id);
    const api = await createApiToken(h.db, actor, "CLI");
    expect((await getTokenUser(h.db, api.token))?.id).toBe(user.id);
    await revokeApiToken(h.db, actor, api.id);
    expect(await getTokenUser(h.db, api.token)).toBeNull();
    await deleteSession(h.db, actor.sessionId!);
    expect(await getSessionUser(h.db, token)).toBeNull();
  });
  it("rejects duplicate emails and weak passwords", async () => {
    const { email } = await makeUser(h, "Bob");
    await expectError(signup(h.db, { email, password: "password123", name: "Bob" }, { bypassSignupSwitch: true }), 409);
    await expect(signup(h.db, { email: "short@example.com", password: "123", name: "X" }, { bypassSignupSwitch: true })).rejects.toThrow();
  });
  it("stores only password hashes and revokes other sessions on password change", async () => {
    const { actor, email, token } = await makeUser(h, "Carol");
    const u = await h.db.query.users.findFirst({ where: (t, { eq }) => eq(t.email, email) });
    expect(u!.passwordHash).toMatch(/^scrypt\$/);
    expect(u!.passwordHash).not.toContain("password123");
    const { createSession } = await import("@/server/services/auth");
    const other = await createSession(h.db, actor.userId);
    await changePassword(h.db, actor, { currentPassword: "password123", newPassword: "newpassword456" });
    expect(await getSessionUser(h.db, other.token)).toBeNull();
    expect(await getSessionUser(h.db, token)).not.toBeNull();
  });
});

describe("pages and hierarchy", () => {
  it("creates nested pages, saves content and reloads it intact", async () => {
    const { actor } = await makeUser(h);
    const ws = await makeWorkspace(h, actor);
    const root = await createPage(h.db, actor, { workspaceId: ws.id, title: "Root" });
    const child = await createPage(h.db, actor, { workspaceId: ws.id, parentId: root.id, title: "Child" });
    const blocks = blk(B.h(1, "Hello"), B.p("Some **bold** text"), B.todos([["Do it", true]]));
    const saved = await saveContent(h.db, actor, child.id, { baseVersion: child.version, blocks });
    expect(saved.version).toBe(child.version + 1);
    const loaded = await getPage(h.db, actor, child.id);
    expect(loaded.content.map((b) => b.type)).toEqual(["heading", "paragraph", "taskList"]);
    expect(loaded.content[1].content?.find((n) => n.marks)?.marks?.[0].type).toBe("bold");
    expect(loaded.breadcrumbs.map((b) => b.title)).toEqual(["Root"]);
    const parent = await getPage(h.db, actor, root.id);
    expect(parent.children.map((c) => c.title)).toEqual(["Child"]);
  });

  it("detects concurrent edits and keeps the losing version in history", async () => {
    const { actor } = await makeUser(h);
    const ws = await makeWorkspace(h, actor);
    const page = await createPage(h.db, actor, { workspaceId: ws.id, title: "Shared" });
    await saveContent(h.db, actor, page.id, { baseVersion: page.version, blocks: blk(B.p("first writer")) });
    const err = await expectError(saveContent(h.db, actor, page.id, { baseVersion: page.version, blocks: blk(B.p("second writer")) }), 409);
    const revId = (err.details as { revisionId: string }).revisionId;
    const rev = await getRevision(h.db, actor, page.id, revId);
    expect(JSON.stringify(rev.snapshot.blocks)).toContain("second writer");
    const cur = await getPage(h.db, actor, page.id);
    expect(JSON.stringify(cur.content)).toContain("first writer");
  });

  it("rejects invalid blocks and unsafe links", async () => {
    const { actor } = await makeUser(h);
    const ws = await makeWorkspace(h, actor);
    const page = await createPage(h.db, actor, { workspaceId: ws.id });
    await expectError(saveContent(h.db, actor, page.id, { blocks: [{ id: "x1", content: { type: "script" } }] }), 400);
    await expectError(saveContent(h.db, actor, page.id, { blocks: [{ id: "bad id!", content: { type: "paragraph" } }] }), 400);
    const evil = { type: "paragraph", attrs: { id: "p1" }, content: [{ type: "text", text: "click", marks: [{ type: "link", attrs: { href: "javascript:alert(1)" } }] }] };
    await saveContent(h.db, actor, page.id, { blocks: [{ id: "p1", content: evil }] });
    const loaded = await getPage(h.db, actor, page.id);
    expect(JSON.stringify(loaded.content)).not.toContain("javascript:");
  });

  it("moves pages, prevents cycles, and supports deep nesting", async () => {
    const { actor } = await makeUser(h);
    const ws = await makeWorkspace(h, actor);
    let parent: string | null = null;
    const ids: string[] = [];
    for (let i = 0; i < 60; i++) {
      const p = await createPage(h.db, actor, { workspaceId: ws.id, parentId: parent, title: `Level ${i}` });
      ids.push(p.id);
      parent = p.id;
    }
    const deepest = await getPage(h.db, actor, ids[59]);
    expect(deepest.breadcrumbs).toHaveLength(59);
    await expectError(movePage(h.db, actor, ids[0], { parentId: ids[30] }), 400);
    await movePage(h.db, actor, ids[30], { parentId: null });
    const moved = await getPage(h.db, actor, ids[59]);
    expect(moved.breadcrumbs).toHaveLength(29);
  });

  it("archives subtrees to the trash, restores and deletes permanently", async () => {
    const { actor } = await makeUser(h);
    const ws = await makeWorkspace(h, actor);
    const a = await createPage(h.db, actor, { workspaceId: ws.id, title: "A" });
    const b = await createPage(h.db, actor, { workspaceId: ws.id, parentId: a.id, title: "B" });
    await archivePage(h.db, actor, a.id);
    const tree = await getTree(h.db, actor, ws.id);
    expect(tree.nodes.find((n) => n.id === a.id || n.id === b.id)).toBeUndefined();
    const trash = await listTrash(h.db, actor, ws.id);
    expect(trash.map((t) => t.id)).toEqual([a.id]);
    await restorePage(h.db, actor, a.id);
    const tree2 = await getTree(h.db, actor, ws.id);
    expect(tree2.nodes.map((n) => n.id).sort()).toEqual([a.id, b.id].sort());
    await expectError(deletePermanently(h.db, actor, a.id), 400); // must be in trash first
    await archivePage(h.db, actor, a.id);
    await deletePermanently(h.db, actor, a.id);
    const gone = await h.db.select().from(pagesTable).where(eq(pagesTable.id, b.id));
    expect(gone).toHaveLength(0);
  });

  it("restores a child whose parent is still in the trash to the top level", async () => {
    const { actor } = await makeUser(h);
    const ws = await makeWorkspace(h, actor);
    const a = await createPage(h.db, actor, { workspaceId: ws.id, title: "A" });
    const b = await createPage(h.db, actor, { workspaceId: ws.id, parentId: a.id, title: "B" });
    await archivePage(h.db, actor, a.id);
    await restorePage(h.db, actor, b.id);
    const page = await getPage(h.db, actor, b.id);
    expect(page.page.parentId).toBeNull();
    expect(page.page.archivedAt).toBeNull();
  });

  it("duplicates a page tree with new ids", async () => {
    const { actor } = await makeUser(h);
    const ws = await makeWorkspace(h, actor);
    const a = await createPage(h.db, actor, { workspaceId: ws.id, title: "Doc" });
    const c = await createPage(h.db, actor, { workspaceId: ws.id, parentId: a.id, title: "Sub" });
    await saveContent(h.db, actor, a.id, { blocks: blk(B.p("text"), B.childPage(c.id)) });
    const copy = await duplicatePage(h.db, actor, a.id);
    expect(copy.title).toBe("Doc (copy)");
    const loaded = await getPage(h.db, actor, copy.id);
    expect(loaded.children).toHaveLength(1);
    expect(loaded.children[0].id).not.toBe(c.id);
    const childRef = loaded.content.find((n) => n.type === "childPage")!;
    expect(childRef.attrs!.pageId).toBe(loaded.children[0].id);
  });

  it("tracks favorites and recent pages", async () => {
    const { actor } = await makeUser(h);
    const ws = await makeWorkspace(h, actor);
    const a = await createPage(h.db, actor, { workspaceId: ws.id, title: "Fav" });
    await setFavorite(h.db, actor, a.id, true);
    expect((await getTree(h.db, actor, ws.id)).favorites.map((f) => f.id)).toEqual([a.id]);
    await recordVisit(h.db, actor, a.id);
    expect((await recentPages(h.db, actor, ws.id)).map((r) => r.id)).toEqual([a.id]);
  });

  it("reorders a user's own favorites", async () => {
    const { actor } = await makeUser(h);
    const other = await makeUser(h);
    const ws = await makeWorkspace(h, actor);
    const [a, b, c] = await Promise.all(["A", "B", "C"].map((title) => createPage(h.db, actor, { workspaceId: ws.id, title })));
    for (const p of [a, b, c]) await setFavorite(h.db, actor, p.id, true);
    const order = async () => (await getTree(h.db, actor, ws.id)).favorites.map((f) => f.title);
    expect(await order()).toEqual(["A", "B", "C"]);
    await moveFavorite(h.db, actor, c.id, a.id);
    expect(await order()).toEqual(["C", "A", "B"]);
    await moveFavorite(h.db, actor, c.id, null);
    expect(await order()).toEqual(["A", "B", "C"]);
    await moveFavorite(h.db, actor, a.id, c.id);
    expect(await order()).toEqual(["B", "A", "C"]);
    // Ties (e.g. from old data) are renumbered rather than left ambiguous.
    await h.db.update(favorites).set({ position: 5 }).where(eq(favorites.userId, actor.userId));
    await moveFavorite(h.db, actor, c.id, b.id);
    expect(await order()).toEqual(["A", "C", "B"]);
    expect(new Set((await h.db.select().from(favorites).where(eq(favorites.userId, actor.userId))).map((f) => f.position)).size).toBe(3);
    // Only pages in your own favorites can be moved.
    await expect(moveFavorite(h.db, other.actor, a.id, null)).rejects.toMatchObject({ status: 404 });
    await expect(moveFavorite(h.db, actor, a.id, other.actor.userId)).rejects.toMatchObject({ status: 404 });
  });
});

describe("history", () => {
  it("lists and restores revisions", async () => {
    const { actor } = await makeUser(h);
    const ws = await makeWorkspace(h, actor);
    const page = await createPage(h.db, actor, { workspaceId: ws.id, title: "Versioned" });
    await saveContent(h.db, actor, page.id, { blocks: blk(B.p("version one")) });
    await saveContent(h.db, actor, page.id, { blocks: blk(B.p("version two")) });
    const revs = await listRevisions(h.db, actor, page.id);
    expect(revs.length).toBeGreaterThanOrEqual(2);
    const first = revs.at(-1)!;
    const r = await getRevision(h.db, actor, page.id, first.id);
    expect(JSON.stringify(r.snapshot.blocks)).toContain("version one");
    await restoreRevision(h.db, actor, page.id, first.id);
    expect(JSON.stringify((await getPage(h.db, actor, page.id)).content)).toContain("version one");
    // The pre-restore state is itself recoverable (deduplicated against the existing snapshot).
    const after = await listRevisions(h.db, actor, page.id);
    const snaps = await Promise.all(after.map((x) => getRevision(h.db, actor, page.id, x.id)));
    expect(snaps.some((s) => JSON.stringify(s.snapshot.blocks).includes("version two"))).toBe(true);
    expect(after[0].reason).toBe("restore");
  });
});

describe("permissions", () => {
  it("isolates workspaces and private pages (no IDOR)", async () => {
    const alice = await makeUser(h, "Owner");
    const mallory = await makeUser(h, "Mallory");
    const ws = await makeWorkspace(h, alice.actor);
    const page = await createPage(h.db, alice.actor, { workspaceId: ws.id, title: "Secret" });
    await expectError(getPage(h.db, mallory.actor, page.id), 404);
    await expectError(saveContent(h.db, mallory.actor, page.id, { blocks: [] }), 404);
    await expectError(updatePage(h.db, mallory.actor, page.id, { title: "pwned" }), 404);
    await expectError(archivePage(h.db, mallory.actor, page.id), 404);
    await expectError(createPage(h.db, mallory.actor, { workspaceId: ws.id, parentId: page.id }), 404);
    await expectError(getTree(h.db, mallory.actor, ws.id), 404);
    await expectError(listRevisions(h.db, mallory.actor, page.id), 404);
    await expectError(duplicatePage(h.db, mallory.actor, page.id), 404);
  });

  it("applies workspace roles, private pages and explicit grants with inheritance", async () => {
    const owner = await makeUser(h, "Owner2");
    const viewer = await makeUser(h, "Viewer");
    const ws = await makeWorkspace(h, owner.actor);
    const inv = await createInvitation(h.db, owner.actor, ws.id, { email: viewer.email, role: "viewer" });
    await acceptInvitation(h.db, viewer.actor, inv.token);
    expect((await listMembers(h.db, owner.actor, ws.id)).length).toBe(2);

    const shared = await createPage(h.db, owner.actor, { workspaceId: ws.id, title: "Team page" });
    const child = await createPage(h.db, owner.actor, { workspaceId: ws.id, parentId: shared.id, title: "Child" });
    const priv = await createPage(h.db, owner.actor, { workspaceId: ws.id, title: "Diary", visibility: "private" });
    const privChild = await createPage(h.db, owner.actor, { workspaceId: ws.id, parentId: priv.id, title: "Entry" });

    // Viewer can read workspace pages but not edit; cannot see private pages.
    expect((await getPage(h.db, viewer.actor, child.id)).access).toBe("view");
    await expectError(saveContent(h.db, viewer.actor, child.id, { blocks: [] }), 403);
    await expectError(getPage(h.db, viewer.actor, priv.id), 404);
    await expectError(getPage(h.db, viewer.actor, privChild.id), 404);
    const tree = await getTree(h.db, viewer.actor, ws.id);
    expect(tree.nodes.some((n) => n.id === priv.id || n.id === privChild.id)).toBe(false);

    // Explicit grant on the private sub-page: visible (only that subtree).
    await setUserAccess(h.db, owner.actor, privChild.id, { email: viewer.email, access: "edit" });
    expect((await getPage(h.db, viewer.actor, privChild.id)).access).toBe("edit");
    await expectError(getPage(h.db, viewer.actor, priv.id), 404);
    // Breadcrumbs never leak the private parent.
    expect((await getPage(h.db, viewer.actor, privChild.id)).breadcrumbs).toHaveLength(0);

    // Explicit "none" overrides inherited workspace access.
    await setUserAccess(h.db, owner.actor, shared.id, { email: viewer.email, access: "none" });
    await expectError(getPage(h.db, viewer.actor, child.id), 404);

    // Promote and remove.
    await updateMemberRole(h.db, owner.actor, ws.id, viewer.user.id, "editor");
    await setUserAccess(h.db, owner.actor, shared.id, { email: viewer.email, access: null });
    expect((await getPage(h.db, viewer.actor, child.id)).access).toBe("edit");
    await removeMember(h.db, owner.actor, ws.id, viewer.user.id);
    await expectError(getPage(h.db, viewer.actor, child.id), 404);
    // The last owner cannot leave.
    await expectError(removeMember(h.db, owner.actor, ws.id, owner.user.id), 409);
  });

  it("invitations only work for the invited email", async () => {
    const owner = await makeUser(h);
    const other = await makeUser(h);
    const ws = await makeWorkspace(h, owner.actor);
    const inv = await createInvitation(h.db, owner.actor, ws.id, { email: "someone-else@example.com", role: "editor" });
    await expectError(acceptInvitation(h.db, other.actor, inv.token), 403);
  });

  it("serves public links read-only and only within the shared subtree", async () => {
    const owner = await makeUser(h);
    const ws = await makeWorkspace(h, owner.actor);
    const a = await createPage(h.db, owner.actor, { workspaceId: ws.id, title: "Public" });
    const b = await createPage(h.db, owner.actor, { workspaceId: ws.id, parentId: a.id, title: "Inside" });
    const outside = await createPage(h.db, owner.actor, { workspaceId: ws.id, title: "Outside" });
    const { token } = await setPublicShare(h.db, owner.actor, a.id, true);
    expect((await getPublicPage(h.db, token!)).page.title).toBe("Public");
    expect((await getPublicPage(h.db, token!, b.id)).page.title).toBe("Inside");
    await expectError(getPublicPage(h.db, token!, outside.id), 404);
    await setPublicShare(h.db, owner.actor, a.id, false);
    await expectError(getPublicPage(h.db, token!), 404);
  });
});
