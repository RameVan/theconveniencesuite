import { describe, it, expect, beforeAll, afterAll } from "vitest";
import type { DbHandle } from "@/server/db";
import { setupDb, makeUser, makeWorkspace } from "./helpers";
import { createPage, archivePage, restorePage, duplicatePage, getPage } from "@/server/services/pages";
import {
  addProperty,
  updateProperty,
  deleteProperty,
  createRecord,
  updateRecord,
  queryDatabase,
  loadDatabaseMeta,
  createView,
  updateView,
  deleteView,
  searchRecords,
} from "@/server/services/databases";
import { listRevisions, restoreRevision } from "@/server/services/revisions";
import { AppError } from "@/server/errors";
import type { Actor } from "@/server/services/auth";
import type { FilterGroup } from "@/lib/db-types";

let h: DbHandle;
let actor: Actor;
let wsId: string;
beforeAll(async () => {
  h = await setupDb();
  actor = (await makeUser(h, "DbUser")).actor;
  wsId = (await makeWorkspace(h, actor)).id;
});
afterAll(async () => {
  await h.close();
});

async function newDb(title = "Projects") {
  const page = await createPage(h.db, actor, { workspaceId: wsId, title, kind: "database" });
  const meta = await loadDatabaseMeta(h.db, page.id);
  return { id: page.id, meta, titleId: meta.properties.find((p) => p.type === "title")!.id, viewId: meta.views[0].id };
}

const cond = (propertyId: string, operator: string, value?: unknown) => ({ kind: "condition" as const, id: Math.random().toString(), propertyId, operator: operator as never, value });
const group = (op: "and" | "or", ...filters: FilterGroup["filters"]): FilterGroup => ({ kind: "group", id: "g", op, filters });

describe("database schema and records", () => {
  it("creates a database with a default schema and view", async () => {
    const d = await newDb();
    expect(d.meta.properties.map((p) => p.type)).toEqual(["title", "multi_select"]);
    expect(d.meta.views[0].type).toBe("table");
  });

  it("validates typed values and auto-creates select options", async () => {
    const d = await newDb();
    const num = await addProperty(h.db, actor, d.id, { name: "Score", type: "number" });
    const sel = await addProperty(h.db, actor, d.id, { name: "Stage", type: "select" });
    const date = await addProperty(h.db, actor, d.id, { name: "Due", type: "date" });
    const url = await addProperty(h.db, actor, d.id, { name: "Site", type: "url" });
    const chk = await addProperty(h.db, actor, d.id, { name: "Done", type: "checkbox" });
    const r = await createRecord(h.db, actor, d.id, { title: "One", values: { [num.id]: 5, [sel.id]: "Alpha", [date.id]: "2026-10-01", [chk.id]: true } });
    expect(r.row.values[num.id]).toBe(5);
    const meta = await loadDatabaseMeta(h.db, d.id);
    const stage = meta.properties.find((p) => p.id === sel.id)!;
    expect(stage.config.options?.map((o) => o.name)).toEqual(["Alpha"]);
    expect(r.row.values[sel.id]).toBe(stage.config.options![0].id);
    expect(r.row.values[date.id]).toMatchObject({ start: "2026-10-01" });
    await expect(updateRecord(h.db, actor, r.row.id, { values: { [num.id]: "abc" } })).rejects.toThrow(/expected a number/);
    await expect(updateRecord(h.db, actor, r.row.id, { values: { [url.id]: "javascript:alert(1)" } })).rejects.toThrow(/URL/);
    await expect(updateRecord(h.db, actor, r.row.id, { values: { [date.id]: "not a date" } })).rejects.toThrow(/invalid date/);
    // Values can also be addressed by property name.
    const r2 = await updateRecord(h.db, actor, r.row.id, { values: { Score: 7 } });
    expect(r2.row.values[num.id]).toBe(7);
  });

  it("assigns unique ids atomically, including for existing records", async () => {
    const d = await newDb();
    await createRecord(h.db, actor, d.id, { title: "Before" });
    const uid = await addProperty(h.db, actor, d.id, { name: "ID", type: "unique_id", config: { prefix: "TASK" } });
    const r = await createRecord(h.db, actor, d.id, { title: "After" });
    expect(r.row.values[uid.id]).toBe("TASK-2");
    const q = await queryDatabase(h.db, actor, d.id, { config: { sorts: [{ propertyId: uid.id, direction: "asc" }] } });
    expect(q.rows.map((x) => x.values[uid.id])).toEqual(["TASK-1", "TASK-2"]);
  });

  it("converts values when a property changes type", async () => {
    const d = await newDb();
    const t = await addProperty(h.db, actor, d.id, { name: "Value", type: "rich_text" });
    const a = await createRecord(h.db, actor, d.id, { title: "a", values: { [t.id]: "42" } });
    const b = await createRecord(h.db, actor, d.id, { title: "b", values: { [t.id]: "red" } });
    await updateProperty(h.db, actor, t.id, { type: "number" });
    let q = await queryDatabase(h.db, actor, d.id, {});
    expect(q.rows.find((r) => r.id === a.row.id)!.values[t.id]).toBe(42);
    expect(q.rows.find((r) => r.id === b.row.id)!.values[t.id]).toBeNull();
    await updateProperty(h.db, actor, t.id, { type: "select" });
    q = await queryDatabase(h.db, actor, d.id, {});
    const meta = await loadDatabaseMeta(h.db, d.id);
    expect(meta.properties.find((p) => p.id === t.id)!.config.options!.map((o) => o.name)).toEqual(["42"]);
  });

  it("deletes properties and scrubs them from views", async () => {
    const d = await newDb();
    const p = await addProperty(h.db, actor, d.id, { name: "Temp", type: "number" });
    await updateView(h.db, actor, d.viewId, { config: { sorts: [{ propertyId: p.id, direction: "asc" }], groupBy: p.id } });
    await deleteProperty(h.db, actor, p.id);
    const meta = await loadDatabaseMeta(h.db, d.id);
    expect(meta.properties.find((x) => x.id === p.id)).toBeUndefined();
    expect(meta.views[0].config.sorts).toEqual([]);
    expect(meta.views[0].config.groupBy).toBeNull();
    await expect(deleteProperty(h.db, actor, d.titleId)).rejects.toThrow(/title/);
  });

  it("manages views", async () => {
    const d = await newDb();
    const v = await createView(h.db, actor, d.id, { type: "board", name: "Board" });
    expect(v.type).toBe("board");
    await deleteView(h.db, actor, v.id);
    await expect(deleteView(h.db, actor, d.viewId)).rejects.toThrow(/at least one view/);
  });
});

describe("relations, rollups and formulas", () => {
  it("keeps two-way relations in sync and computes rollups", async () => {
    const projects = await newDb("Projects");
    const tasks = await newDb("Tasks");
    const hours = await addProperty(h.db, actor, tasks.id, { name: "Hours", type: "number" });
    const done = await addProperty(h.db, actor, tasks.id, { name: "Done", type: "checkbox" });
    const rel = await addProperty(h.db, actor, projects.id, { name: "Tasks", type: "relation", config: { targetDatabaseId: tasks.id }, twoWay: true, syncedName: "Project" });
    expect(rel.config.syncedPropertyId).toBeTruthy();
    const synced = rel.config.syncedPropertyId!;

    const t1 = await createRecord(h.db, actor, tasks.id, { title: "T1", values: { [hours.id]: 3, [done.id]: true } });
    const t2 = await createRecord(h.db, actor, tasks.id, { title: "T2", values: { [hours.id]: 5 } });
    const p = await createRecord(h.db, actor, projects.id, { title: "P", values: { [rel.id]: [t1.row.id, t2.row.id] } });
    expect(p.row.values[rel.id]).toEqual([t1.row.id, t2.row.id]);
    expect(p.refs.pages[t1.row.id].title).toBe("T1");

    // Mirror side was written.
    const tq = await queryDatabase(h.db, actor, tasks.id, {});
    expect(tq.rows.find((r) => r.id === t1.row.id)!.values[synced]).toEqual([p.row.id]);

    const sum = await addProperty(h.db, actor, projects.id, { name: "Total hours", type: "rollup", config: { relationPropertyId: rel.id, targetPropertyId: hours.id, function: "sum" } });
    const pct = await addProperty(h.db, actor, projects.id, { name: "Progress", type: "rollup", config: { relationPropertyId: rel.id, targetPropertyId: done.id, function: "percent_checked" } });
    const titles = await addProperty(h.db, actor, projects.id, { name: "Task names", type: "rollup", config: { relationPropertyId: rel.id, targetPropertyId: "title", function: "show_original" } });
    const f = await addProperty(h.db, actor, projects.id, { name: "Summary", type: "formula", config: { expression: 'prop("Name") + ": " + format(prop("Total hours")) + "h"' } });
    let q = await queryDatabase(h.db, actor, projects.id, {});
    let row = q.rows[0];
    expect(row.values[sum.id]).toBe(8);
    expect(row.values[pct.id]).toBe(50);
    expect(row.values[titles.id]).toEqual({ type: "list", items: ["T1", "T2"] });
    expect(row.values[f.id]).toBe("P: 8h");

    // Removing a link on the mirror side updates the other side and the rollup.
    await updateRecord(h.db, actor, t2.row.id, { values: { [synced]: [] } });
    q = await queryDatabase(h.db, actor, projects.id, {});
    row = q.rows[0];
    expect(row.values[rel.id]).toEqual([t1.row.id]);
    expect(row.values[sum.id]).toBe(3);

    // Renaming a target record is reflected (links are by id).
    await updateRecord(h.db, actor, t1.row.id, { title: "Renamed" });
    q = await queryDatabase(h.db, actor, projects.id, {});
    expect(q.refs.pages[t1.row.id].title).toBe("Renamed");

    // Archived related records disappear from rollups and come back on restore.
    await archivePage(h.db, actor, t1.row.id);
    q = await queryDatabase(h.db, actor, projects.id, {});
    expect(q.rows[0].values[sum.id]).toBe(0);
    await restorePage(h.db, actor, t1.row.id);
    q = await queryDatabase(h.db, actor, projects.id, {});
    expect(q.rows[0].values[sum.id]).toBe(3);

    // Related records must belong to the target database.
    await expect(updateRecord(h.db, actor, p.row.id, { values: { [rel.id]: [p.row.id] } })).rejects.toThrow(/target database/);
    expect((await searchRecords(h.db, actor, tasks.id, "Ren")).map((r) => r.title)).toEqual(["Renamed"]);
  });

  it("validates formulas, updates them on rename, and rejects cycles", async () => {
    const d = await newDb();
    const price = await addProperty(h.db, actor, d.id, { name: "Price", type: "number" });
    const qty = await addProperty(h.db, actor, d.id, { name: "Qty", type: "number" });
    const total = await addProperty(h.db, actor, d.id, { name: "Total", type: "formula", config: { expression: 'prop("Price") * prop("Qty")' } });
    await createRecord(h.db, actor, d.id, { title: "x", values: { [price.id]: 2.5, [qty.id]: 4 } });
    let q = await queryDatabase(h.db, actor, d.id, {});
    expect(q.rows[0].values[total.id]).toBe(10);

    await updateProperty(h.db, actor, price.id, { name: "Unit price" });
    const meta = await loadDatabaseMeta(h.db, d.id);
    expect(meta.properties.find((p) => p.id === total.id)!.config.expression).toBe('prop("Unit price") * prop("Qty")');
    q = await queryDatabase(h.db, actor, d.id, {});
    expect(q.rows[0].values[total.id]).toBe(10);

    await expect(addProperty(h.db, actor, d.id, { name: "Bad", type: "formula", config: { expression: 'prop("Nope") + 1' } })).rejects.toThrow(/Unknown property/);
    // New formula properties start empty and show empty values.
    const blank = await addProperty(h.db, actor, d.id, { name: "Blank", type: "formula" });
    expect((await queryDatabase(h.db, actor, d.id, {})).rows[0].values[blank.id]).toBeNull();
    const a = await addProperty(h.db, actor, d.id, { name: "A", type: "formula", config: { expression: "1" } });
    await addProperty(h.db, actor, d.id, { name: "B", type: "formula", config: { expression: 'prop("A") + 1' } });
    await expect(updateProperty(h.db, actor, a.id, { config: { expression: 'prop("B") + 1' } })).rejects.toThrow(/Circular reference/);
    await expect(updateProperty(h.db, actor, a.id, { config: { expression: 'prop("A") + 1' } })).rejects.toThrow(/Circular reference/);
  });

  it("reports cross-database rollup cycles as errors instead of hanging", async () => {
    const a = await newDb("A");
    const b = await newDb("B");
    const rel = await addProperty(h.db, actor, a.id, { name: "To B", type: "relation", config: { targetDatabaseId: b.id }, twoWay: true, syncedName: "To A" });
    const back = rel.config.syncedPropertyId!;
    const fa = await addProperty(h.db, actor, a.id, { name: "FA", type: "formula", config: { expression: "1" } });
    const rb = await addProperty(h.db, actor, b.id, { name: "RB", type: "rollup", config: { relationPropertyId: back, targetPropertyId: fa.id, function: "sum" } });
    const fb = await addProperty(h.db, actor, b.id, { name: "FB", type: "formula", config: { expression: 'prop("RB")' } });
    const ra = await addProperty(h.db, actor, a.id, { name: "RA", type: "rollup", config: { relationPropertyId: rel.id, targetPropertyId: fb.id, function: "sum" } });
    await updateProperty(h.db, actor, fa.id, { config: { expression: 'prop("RA")' } });
    const rb1 = await createRecord(h.db, actor, b.id, { title: "b1" });
    await createRecord(h.db, actor, a.id, { title: "a1", values: { [rel.id]: [rb1.row.id] } });
    const q = await queryDatabase(h.db, actor, a.id, {});
    const v = q.rows[0].values[ra.id] as { type: string; message: string };
    expect(v.type).toBe("error");
    expect(v.message).toMatch(/Circular/);
    void rb;
  });
});

describe("query engine", () => {
  it("filters with nested AND/OR groups, sorts, groups and aggregates", async () => {
    const d = await newDb("Query");
    const n = await addProperty(h.db, actor, d.id, { name: "N", type: "number" });
    const s = await addProperty(h.db, actor, d.id, { name: "S", type: "select" });
    const due = await addProperty(h.db, actor, d.id, { name: "Due", type: "date" });
    const rows = [
      { title: "apple", n: 1, s: "Red", due: "2026-01-05" },
      { title: "banana", n: 5, s: "Yellow", due: "2026-02-10" },
      { title: "cherry", n: 3, s: "Red", due: null },
      { title: "date", n: null, s: null, due: "2026-03-01" },
    ];
    for (const r of rows) await createRecord(h.db, actor, d.id, { title: r.title, values: { [n.id]: r.n, [s.id]: r.s, [due.id]: r.due } });
    const meta = await loadDatabaseMeta(h.db, d.id);
    const red = meta.properties.find((p) => p.id === s.id)!.config.options!.find((o) => o.name === "Red")!.id;

    const q1 = await queryDatabase(h.db, actor, d.id, { config: { filter: group("and", cond(n.id, "gt", 2)), sorts: [{ propertyId: n.id, direction: "desc" }] } });
    expect(q1.rows.map((r) => r.title)).toEqual(["banana", "cherry"]);

    const q2 = await queryDatabase(h.db, actor, d.id, {
      config: { filter: group("or", cond(s.id, "equals", red), group("and", cond(n.id, "is_empty"), cond(d.titleId, "contains", "dat"))) },
    });
    expect(q2.rows.map((r) => r.title).sort()).toEqual(["apple", "cherry", "date"]);

    const q3 = await queryDatabase(h.db, actor, d.id, { config: { filter: group("and", cond(due.id, "before", "2026-02-01")) } });
    expect(q3.rows.map((r) => r.title)).toEqual(["apple"]);

    // Empty values sort last in both directions.
    const asc = await queryDatabase(h.db, actor, d.id, { config: { sorts: [{ propertyId: n.id, direction: "asc" }] } });
    expect(asc.rows.map((r) => r.title)).toEqual(["apple", "cherry", "banana", "date"]);
    const desc = await queryDatabase(h.db, actor, d.id, { config: { sorts: [{ propertyId: n.id, direction: "desc" }] } });
    expect(desc.rows.map((r) => r.title)).toEqual(["banana", "cherry", "apple", "date"]);

    const g = await queryDatabase(h.db, actor, d.id, { config: { groupBy: s.id, aggregations: { [n.id]: "sum" } } });
    const redGroup = g.groups!.find((x) => x.label === "Red")!;
    expect(redGroup.rowIds).toHaveLength(2);
    expect(redGroup.aggregations[n.id]).toBe(4);
    expect(g.groups!.find((x) => x.key === "__empty__")!.rowIds).toHaveLength(1);
    expect(g.aggregations[n.id]).toBe(9);

    const searched = await queryDatabase(h.db, actor, d.id, { search: "an" });
    expect(searched.rows.map((r) => r.title)).toEqual(["banana"]);
  });

  it("filters with relative dates", async () => {
    const d = await newDb("Dates");
    const due = await addProperty(h.db, actor, d.id, { name: "Due", type: "date" });
    const today = new Date().toISOString().slice(0, 10);
    const old = new Date(Date.now() - 40 * 86_400_000).toISOString().slice(0, 10);
    await createRecord(h.db, actor, d.id, { title: "today", values: { [due.id]: today } });
    await createRecord(h.db, actor, d.id, { title: "old", values: { [due.id]: old } });
    const q = await queryDatabase(h.db, actor, d.id, { config: { filter: group("and", cond(due.id, "is_relative", "past_week")) } });
    expect(q.rows.map((r) => r.title)).toEqual(["today"]);
  });
});

describe("records as pages", () => {
  it("opens records as pages with properties, history and duplication", async () => {
    const d = await newDb("Notes");
    const tag = await addProperty(h.db, actor, d.id, { name: "Kind", type: "select" });
    const r = await createRecord(h.db, actor, d.id, { title: "Record page", values: { [tag.id]: "Idea" } });
    const page = await getPage(h.db, actor, r.row.id);
    expect(page.record?.database.id).toBe(d.id);
    expect(page.breadcrumbs.map((b) => b.id)).toEqual([d.id]);
    await updateRecord(h.db, actor, r.row.id, { values: { [tag.id]: "Task" } });
    const revs = await listRevisions(h.db, actor, r.row.id);
    const first = revs.at(-1)!;
    await restoreRevision(h.db, actor, r.row.id, first.id);
    const restored = await getPage(h.db, actor, r.row.id);
    const meta = await loadDatabaseMeta(h.db, d.id);
    const idea = meta.properties.find((p) => p.id === tag.id)!.config.options!.find((o) => o.name === "Idea")!.id;
    expect(restored.record?.values[tag.id]).toBe(idea);
    const copy = await duplicatePage(h.db, actor, r.row.id);
    const q = await queryDatabase(h.db, actor, d.id, {});
    expect(q.rows.map((x) => x.id)).toContain(copy.id);
  });

  it("creates records from templates", async () => {
    const d = await newDb("Templated");
    const tmpl = await createRecord(h.db, actor, d.id, { title: "Weekly sync", isTemplate: true });
    const q0 = await queryDatabase(h.db, actor, d.id, {});
    expect(q0.rows).toHaveLength(0); // templates are not records
    const r = await createRecord(h.db, actor, d.id, { templateId: tmpl.row.id });
    expect(r.row.title).toBe("Weekly sync");
    const q = await queryDatabase(h.db, actor, d.id, {});
    expect(q.rows.map((x) => x.id)).toEqual([r.row.id]);
  });

  it("duplicates a whole database with schema, views and internal relations", async () => {
    const d = await newDb("Self");
    const rel = await addProperty(h.db, actor, d.id, { name: "Parent", type: "relation", config: { targetDatabaseId: d.id } });
    const a = await createRecord(h.db, actor, d.id, { title: "A" });
    await createRecord(h.db, actor, d.id, { title: "B", values: { [rel.id]: [a.row.id] } });
    const copy = await duplicatePage(h.db, actor, d.id);
    const meta = await loadDatabaseMeta(h.db, copy.id);
    const copyRel = meta.properties.find((p) => p.type === "relation")!;
    expect(copyRel.id).not.toBe(rel.id);
    expect(copyRel.config.targetDatabaseId).toBe(copy.id);
    const q = await queryDatabase(h.db, actor, copy.id, {});
    const b = q.rows.find((r) => r.title === "B")!;
    const aCopy = q.rows.find((r) => r.title === "A")!;
    expect(b.values[copyRel.id]).toEqual([aCopy.id]);
  });
});

describe("authorization on databases", () => {
  it("refuses access to other users' databases", async () => {
    const d = await newDb("Private db");
    const other = await makeUser(h, "Intruder");
    await expect(queryDatabase(h.db, other.actor, d.id, {})).rejects.toBeInstanceOf(AppError);
    await expect(addProperty(h.db, other.actor, d.id, { name: "x", type: "number" })).rejects.toBeInstanceOf(AppError);
    await expect(createRecord(h.db, other.actor, d.id, { title: "x" })).rejects.toBeInstanceOf(AppError);
    // Cannot point a relation at a database they cannot see.
    const ows = await makeWorkspace(h, other.actor);
    const od = await createPage(h.db, other.actor, { workspaceId: ows.id, kind: "database", title: "Mine" });
    await expect(addProperty(h.db, other.actor, od.id, { name: "Steal", type: "relation", config: { targetDatabaseId: d.id } })).rejects.toBeInstanceOf(AppError);
  });
});
