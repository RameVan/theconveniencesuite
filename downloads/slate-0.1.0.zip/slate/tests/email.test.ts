// Notification emails through a real SMTP server (smtp-server) running locally.
import { describe, it, expect, beforeAll, afterAll, afterEach, vi } from "vitest";
import { SMTPServer } from "smtp-server";
import type { AddressInfo } from "node:net";
import type { DbHandle } from "@/server/db";
import { setupDb, makeUser, makeWorkspace } from "./helpers";
import { createPage } from "@/server/services/pages";
import { createInvitation, acceptInvitation } from "@/server/services/workspaces";
import { addComment } from "@/server/services/comments";
import { listNotifications } from "@/server/services/notifications";
import { updateProfile } from "@/server/services/auth";
import { flushEmails } from "@/server/services/email";
import { commentMentionToken } from "@/lib/mentions";

type Mail = { to: string[]; raw: string };
const inbox: Mail[] = [];
let smtp: SMTPServer;
let port = 0;
let h: DbHandle;

/** Undo quoted-printable soft breaks and escapes so bodies can be searched. */
const decode = (raw: string) => raw.replace(/=\r?\n/g, "").replace(/=([0-9A-F]{2})/g, (_, x) => String.fromCharCode(parseInt(x, 16)));

beforeAll(async () => {
  h = await setupDb();
  smtp = new SMTPServer({
    authOptional: true,
    disabledCommands: ["STARTTLS"],
    logger: false,
    onData(stream, session, done) {
      let raw = "";
      stream.on("data", (c) => (raw += c.toString()));
      stream.on("end", () => {
        inbox.push({ to: session.envelope.rcptTo.map((r) => r.address), raw: decode(raw) });
        done();
      });
    },
  });
  await new Promise<void>((r) => smtp.listen(0, "127.0.0.1", () => r()));
  port = (smtp.server.address() as AddressInfo).port;
});
afterAll(async () => {
  await new Promise<void>((r) => smtp.close(() => r()));
  await h.close();
});
afterEach(() => {
  delete process.env.SMTP_URL;
  delete process.env.APP_URL;
  inbox.length = 0;
});

async function team() {
  const owner = await makeUser(h, "Olive");
  const member = await makeUser(h, "Milo");
  const ws = await makeWorkspace(h, owner.actor);
  const inv = await createInvitation(h.db, owner.actor, ws.id, { email: member.email, role: "editor" });
  await acceptInvitation(h.db, member.actor, inv.token);
  const page = await createPage(h.db, owner.actor, { workspaceId: ws.id, title: "Roadmap" });
  return { owner, member, ws, page };
}

describe("notification emails", () => {
  it("emails a mentioned member with a link, and respects their setting", async () => {
    process.env.SMTP_URL = `smtp://127.0.0.1:${port}`;
    process.env.APP_URL = "https://slate.example.com";
    const { owner, member, ws, page } = await team();
    const { id } = await addComment(h.db, owner.actor, page.id, { body: `Can ${commentMentionToken("Milo", member.user.id)} review this?` });
    await flushEmails();
    expect(inbox).toHaveLength(1);
    expect(inbox[0].to).toEqual([member.email]);
    expect(inbox[0].raw).toContain("Subject: Olive mentioned you in a comment on Roadmap");
    expect(inbox[0].raw).toContain("Can @Milo review this?");
    expect(inbox[0].raw).toContain(`https://slate.example.com/w/${ws.id}/p/${page.id}?thread=${id}`);

    await updateProfile(h.db, member.actor, { emailNotifications: false });
    await addComment(h.db, owner.actor, page.id, { body: `Again ${commentMentionToken("Milo", member.user.id)}` });
    await flushEmails();
    expect(inbox).toHaveLength(1);
    // The in-app notification still arrives.
    expect((await listNotifications(h.db, member.actor, { workspaceId: ws.id })).notifications).toHaveLength(2);
  });

  it("sends nothing without SMTP_URL, or to people who can't see the page", async () => {
    const { owner, member, page } = await team();
    await addComment(h.db, owner.actor, page.id, { body: commentMentionToken("Milo", member.user.id) });
    process.env.SMTP_URL = `smtp://127.0.0.1:${port}`;
    const outsider = await makeUser(h, "Outsider");
    await addComment(h.db, owner.actor, page.id, { body: commentMentionToken("Outsider", outsider.user.id) });
    await flushEmails();
    expect(inbox).toHaveLength(0);
  });

  it("keeps working when the mail server is unreachable, without logging content", async () => {
    process.env.SMTP_URL = "smtp://127.0.0.1:1"; // nothing listens here
    const errors = vi.spyOn(console, "error").mockImplementation(() => {});
    const { owner, member, ws, page } = await team();
    await addComment(h.db, owner.actor, page.id, { body: `Secret plan for ${commentMentionToken("Milo", member.user.id)}` });
    await flushEmails();
    expect((await listNotifications(h.db, member.actor, { workspaceId: ws.id })).notifications).toHaveLength(1);
    const logged = errors.mock.calls.flat().join(" ");
    expect(logged).toContain("[email] could not send");
    expect(logged).not.toContain("Secret plan");
    expect(logged).not.toContain(member.email);
    errors.mockRestore();
  });
});
