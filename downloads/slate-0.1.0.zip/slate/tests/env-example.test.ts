// .env.example is copied to .env and read by Docker Compose, which takes "KEY=  # note" as the
// value "# note". Comments must therefore sit on their own lines.
import { describe, it, expect } from "vitest";
import fs from "node:fs";

const example = fs.readFileSync(".env.example", "utf8").split(/\r?\n/);
const compose = fs.readFileSync("docker-compose.yml", "utf8");

describe(".env.example", () => {
  it("has no comments after values", () => {
    expect(example.filter((l) => /^[A-Z0-9_]+=.*\s#/.test(l))).toEqual([]);
  });

  it("lists every variable docker-compose.yml reads", () => {
    const keys = new Set(example.map((l) => /^#?\s*([A-Z0-9_]+)=/.exec(l)?.[1]).filter(Boolean));
    const used = [...compose.matchAll(/\$\{([A-Z0-9_]+)(?::-[^}]*)?\}/g)].map((m) => m[1]);
    expect([...new Set(used)].filter((k) => !keys.has(k))).toEqual([]);
  });
});
