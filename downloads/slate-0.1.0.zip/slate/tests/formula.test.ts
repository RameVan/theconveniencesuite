import { describe, it, expect } from "vitest";
import { run, compile, FormulaError, makeDate, renamePropInSource, toText, isDate, type FDate } from "@/lib/formula";

const NOW = Date.UTC(2026, 9, 19, 12, 30); // 2026-10-19 12:30 UTC

describe("formula: arithmetic and precedence", () => {
  it("evaluates operators with precedence", () => {
    expect(run("1 + 2 * 3")).toBe(7);
    expect(run("(1 + 2) * 3")).toBe(9);
    expect(run("2 ^ 3 ^ 2")).toBe(512); // right associative
    expect(run("-2 ^ 2")).toBe(-4);
    expect(run("10 % 4")).toBe(2);
    expect(run("7 / 2")).toBe(3.5);
  });
  it("reports division by zero as an error", () => {
    expect(() => run("1 / 0")).toThrow(FormulaError);
  });
  it("compares and combines booleans", () => {
    expect(run("1 < 2 and 3 >= 3")).toBe(true);
    expect(run("1 == 2 or not false")).toBe(true);
    expect(run("!(1 != 1)")).toBe(true);
    expect(run("true && false || true")).toBe(true);
  });
  it("supports ternary and if/ifs", () => {
    expect(run('5 > 3 ? "yes" : "no"')).toBe("yes");
    expect(run('if(false, "a", "b")')).toBe("b");
    expect(run('ifs(false, 1, true, 2, 3)')).toBe(2);
    expect(run('ifs(false, 1, false, 2, 3)')).toBe(3);
  });
});

describe("formula: text", () => {
  it("concatenates with + and concat", () => {
    expect(run('"a" + 1')).toBe("a1");
    expect(run('concat("x", "y", 3)')).toBe("xy3");
    expect(run('upper("abc") + lower("DEF")')).toBe("ABCdef");
  });
  it("manipulates strings", () => {
    expect(run('length("hello")')).toBe(5);
    expect(run('replaceAll("a-b-c", "-", "+")')).toBe("a+b+c");
    expect(run('substring("abcdef", 1, 3)')).toBe("bc");
    expect(run('contains("hello", "ell")')).toBe(true);
    expect(run('join(split("a,b,c", ","), " | ")')).toBe("a | b | c");
    expect(run('"abc".upper()')).toBe("ABC");
    expect(run('padStart("7", 3, "0")')).toBe("007");
  });
  it("rejects runaway output", () => {
    expect(() => run('repeat("abc", 1000000)')).toThrow(/too long/);
  });
});

describe("formula: properties", () => {
  const props = {
    Price: { type: "number" as const, value: 10 },
    Qty: { type: "number" as const, value: 3 },
    Name: { type: "text" as const, value: "Widget" },
    Done: { type: "boolean" as const, value: true },
    Tags: { type: "list" as const, value: ["a", "b"] },
    Empty: { type: "number" as const, value: null },
  };
  it("references properties by name", () => {
    expect(run('prop("Price") * prop("Qty")', props)).toBe(30);
    expect(run('prop("name") + "!"', props)).toBe("Widget!"); // case-insensitive fallback
    expect(run('if(prop("Done"), "✓", "")', props)).toBe("✓");
    expect(run('length(prop("Tags"))', props)).toBe(2);
    expect(run('empty(prop("Empty"))', props)).toBe(true);
  });
  it("errors on unknown properties at compile time with a position", () => {
    try {
      compile('1 + prop("Nope")', { props: {} });
      throw new Error("expected failure");
    } catch (e) {
      expect(e).toBeInstanceOf(FormulaError);
      expect((e as FormulaError).message).toMatch(/Unknown property "Nope"/);
      expect((e as FormulaError).pos).toBe(4);
    }
  });
  it("collects references", () => {
    const c = compile('prop("Price") + prop("Qty")', { props: { Price: "number", Qty: "number" } });
    expect(c.refs.sort()).toEqual(["Price", "Qty"]);
    expect(c.type).toBe("number");
  });
});

describe("formula: type checking", () => {
  it("infers result types", () => {
    expect(compile('"a" + 1', { props: {} }).type).toBe("text");
    expect(compile("1 < 2", { props: {} }).type).toBe("boolean");
    expect(compile("today()", { props: {} }).type).toBe("date");
    expect(compile("[1,2,3]", { props: {} }).type).toBe("list");
  });
  it("rejects mismatched types", () => {
    expect(() => compile('1 - "a"', { props: {} })).toThrow(/needs numbers/);
    expect(() => compile('1 < "a"', { props: {} })).toThrow(/Cannot compare/);
    expect(() => compile("abs(true)", { props: {} })).toThrow(/should be number/);
  });
  it("checks argument counts and unknown names", () => {
    expect(() => compile("abs()", { props: {} })).toThrow(/takes 1 argument/);
    expect(() => compile("foo(1)", { props: {} })).toThrow(/Unknown function/);
    expect(() => compile("x + 1", { props: {} })).toThrow(/Unknown name/);
  });
  it("reports syntax errors", () => {
    expect(() => compile("1 +", { props: {} })).toThrow(/Unexpected end/);
    expect(() => compile("(1 + 2", { props: {} })).toThrow(/Expected "\)"/);
    expect(() => compile('"unterminated', { props: {} })).toThrow(/Unterminated/);
    expect(() => compile("1 2", { props: {} })).toThrow(/Unexpected input/);
  });
});

describe("formula: dates", () => {
  const d = (s: string) => ({ type: "date" as const, value: makeDate(Date.parse(s + "T00:00:00Z")) });
  it("adds and subtracts", () => {
    const r = run('dateAdd(prop("D"), 1, "months")', { D: d("2026-01-31") }) as FDate;
    expect(new Date(r.start).toISOString().slice(0, 10)).toBe("2026-03-03"); // JS month overflow semantics
    const r2 = run('dateSubtract(prop("D"), 2, "days")', { D: d("2026-01-01") }) as FDate;
    expect(new Date(r2.start).toISOString().slice(0, 10)).toBe("2025-12-30");
  });
  it("computes differences", () => {
    expect(run('dateBetween(prop("A"), prop("B"), "days")', { A: d("2026-03-01"), B: d("2026-02-01") })).toBe(28);
    expect(run('dateBetween(prop("A"), prop("B"), "months")', { A: d("2026-03-01"), B: d("2026-01-15") })).toBe(1);
    expect(run('dateBetween(prop("A"), prop("B"), "years")', { A: d("2026-03-01"), B: d("2020-03-02") })).toBe(5);
  });
  it("formats and extracts parts", () => {
    expect(run('formatDate(prop("D"), "YYYY/MM/DD dddd")', { D: d("2026-10-19") })).toBe("2026/10/19 Monday");
    expect(run('year(prop("D")) * 100 + month(prop("D"))', { D: d("2026-10-19") })).toBe(202610);
    expect(run('weekday(prop("D"))', { D: d("2026-10-18") })).toBe(7);
    expect(run('week(parseDate("2026-01-01"))')).toBe(1);
  });
  it("uses the injected clock", () => {
    const t = run("today()", {}, NOW);
    expect(isDate(t) && new Date(t.start).toISOString()).toBe("2026-10-19T00:00:00.000Z");
    expect(toText(run('dateBetween(today(), parseDate("2026-10-01"), "days")', {}, NOW))).toBe("18");
  });
  it("rejects unknown units", () => {
    expect(() => run('dateAdd(today(), 1, "fortnights")')).toThrow(/Unknown date unit/);
  });
});

describe("formula: lists and lambdas", () => {
  it("maps and filters with current", () => {
    expect(run("map([1, 2, 3], current * 2)")).toEqual([2, 4, 6]);
    expect(run("filter([1, 2, 3, 4], current % 2 == 0)")).toEqual([2, 4]);
    expect(run("sum(map([1,2,3], current + index))")).toBe(9);
    expect(run("some([1,2], current > 1)")).toBe(true);
    expect(run("every([1,2], current > 1)")).toBe(false);
    expect(run("find([5,6,7], current > 5)")).toBe(6);
  });
  it("aggregates", () => {
    expect(run("sum([1, 2], 3)")).toBe(6);
    expect(run("mean([2, 4])")).toBe(3);
    expect(run("median([5, 1, 3])")).toBe(3);
    expect(run("max([1, 9], 4)")).toBe(9);
    expect(run("unique([1, 1, 2])")).toEqual([1, 2]);
    expect(run("sort([3, 1, 2])")).toEqual([1, 2, 3]);
    expect(run("at([1,2,3], -1)")).toBe(3);
  });
  it("supports let", () => {
    expect(run("let(x, 5, x * x)")).toBe(25);
  });
  it("rejects current outside a lambda", () => {
    expect(() => compile("current + 1", { props: {} })).toThrow(/only be used inside/);
  });
});

describe("formula: safety", () => {
  it("does not expose host objects", () => {
    expect(() => run("constructor")).toThrow(/Unknown name/);
    expect(() => run('prop("__proto__")')).toThrow(/Unknown property/);
    expect(() => run("process.exit()")).toThrow();
    expect(() => run("eval(1)")).toThrow(/Unknown function/);
  });
  it("stops expensive evaluation with a step budget", () => {
    const big = "map(split(repeat(\"a\", 90000), \"\"), map(split(repeat(\"b\", 10), \"\"), current))";
    expect(() => run(big)).toThrow(/step limit/);
  });
  it("limits nesting depth", () => {
    expect(() => run("(".repeat(500) + "1" + ")".repeat(500))).toThrow(/nested too deeply/);
  });
});

describe("formula: renaming", () => {
  it("rewrites prop references", () => {
    expect(renamePropInSource('prop("Old") + prop( "Old" ) + prop("Other")', "Old", "New")).toBe(
      'prop("New") + prop( "New" ) + prop("Other")',
    );
  });
});
