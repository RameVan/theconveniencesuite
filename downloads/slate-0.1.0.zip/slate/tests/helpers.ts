import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { createDb, setDbHandle, type DbHandle } from "@/server/db";
import { signup, createSession, type Actor } from "@/server/services/auth";
import { createWorkspace } from "@/server/services/workspaces";
import { setStorage, type StorageAdapter } from "@/server/services/files";

process.env.REVISION_INTERVAL_SECONDS ??= "0";

export async function setupDb(): Promise<DbHandle> {
  const h = await createDb("memory://");
  setDbHandle(h);
  const mem = new Map<string, Buffer>();
  const storage: StorageAdapter = {
    put: async (k, d) => void mem.set(k, d),
    get: async (k) => {
      const v = mem.get(k);
      if (!v) throw new Error("missing");
      return v;
    },
    delete: async (k) => void mem.delete(k),
  };
  setStorage(storage);
  return h;
}

let n = 0;
export async function makeUser(h: DbHandle, name = `User${++n}`) {
  const email = `${name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${n}-${Date.now()}@example.com`;
  const user = await signup(h.db, { email, password: "password123", name }, { bypassSignupSwitch: true });
  const session = await createSession(h.db, user.id);
  const actor: Actor = { userId: user.id, sessionId: session.sessionId, via: "session" };
  return { user, actor, token: session.token, email };
}

export async function makeWorkspace(h: DbHandle, actor: Actor, name = "Test workspace") {
  return createWorkspace(h.db, actor, { name, starter: false });
}

export function tmpDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), "slate-test-"));
}
