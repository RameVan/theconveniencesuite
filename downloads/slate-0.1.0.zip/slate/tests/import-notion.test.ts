// Import of a Notion "Markdown & CSV" export, built here in the export's file layout.
import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { zipSync, strToU8 } from "fflate";
import { eq } from "drizzle-orm";
import type { DbHandle } from "@/server/db";
import { pages } from "@/server/db/schema";
import { setupDb, makeUser, makeWorkspace } from "./helpers";
import { importUpload } from "@/server/services/transfer";
import { stripPropertyLines } from "@/server/services/import-notion";
import { getBlocks } from "@/server/services/pages";
import { queryDatabase, loadDatabaseMeta } from "@/server/services/databases";
import type { Actor } from "@/server/services/auth";

let h: DbHandle;
let actor: Actor;
let wsId: string;
beforeAll(async () => {
  h = await setupDb();
  actor = (await makeUser(h, "Migrator")).actor;
  wsId = (await makeWorkspace(h, actor)).id;
});
afterAll(async () => h.close());

const HOME = "Team Home 0123456789abcdef0123456789abcdef";
const PROJ = "Projects 11111111111111111111111111111111";
const SUB = "Roadmap 22222222222222222222222222222222";
const TASKS = "Tasks 33333333333333333333333333333333";
const WRITE = "Write spec 44444444444444444444444444444444";
const SHIP = "Ship it 55555555555555555555555555555555";
const enc = (s: string) => encodeURIComponent(s).replace(/%2F/g, "/");
const PNG = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 0]);

function exportFiles(): Record<string, Uint8Array> {
  return {
    [`${HOME}.md`]: strToU8(`# Team Home\n\nStart with [Projects](${enc(`${HOME}/${PROJ}.md`)}) and the [task list](${enc(`${HOME}/${TASKS}.csv`)}).\n\n![Logo](${enc(`${HOME}/logo.png`)})\n`),
    [`${HOME}/logo.png`]: PNG,
    [`${HOME}/${PROJ}.md`]: strToU8(`# Projects\n\nSee the [roadmap](${enc(`${PROJ}/${SUB}.md`)}) and go [home](${enc(`../${HOME}.md`)}).\n`),
    [`${HOME}/${PROJ}/${SUB}.md`]: strToU8(`# Roadmap\n\n- Q1: plan\n- Q2: build\n`),
    // Old CSV without the unfiltered rows, and the newer "_all" CSV with every row.
    [`${HOME}/${TASKS}.csv`]: strToU8(`﻿Name,Status,Estimate\r\nWrite spec,Done,3\r\n`),
    [`${HOME}/${TASKS}_all.csv`]: strToU8(`﻿Name,Status,Estimate\r\nWrite spec,Done,3\r\nShip it,Not started,5\r\n`),
    [`${HOME}/${TASKS}/${WRITE}.md`]: strToU8(`# Write spec\n\nStatus: Done\nEstimate: 3\n\nNote: the spec lives in [Projects](${enc(`../${PROJ}.md`)}).\n`),
    [`${HOME}/${TASKS}/${SHIP}.md`]: strToU8(`# Ship it\n\nStatus: Not started\nEstimate: 5\n`),
  };
}

const childrenOf = async (parentId: string) => db().select({ id: pages.id, title: pages.title, kind: pages.kind }).from(pages).where(eq(pages.parentId, parentId));
const db = () => h.db;
const text = (blocks: unknown) => JSON.stringify(blocks);

describe("Notion export import", () => {
  it("rebuilds pages, databases with their record pages, links and images", async () => {
    const zip = Buffer.from(zipSync(exportFiles()));
    const report = await importUpload(h.db, actor, wsId, { name: "Export-abc.zip", data: zip }, {});
    expect(report.kind).toBe("notion");
    expect(report).toMatchObject({ pages: 3, databases: 1, records: 2, files: 1 });
    expect(report.rootIds).toHaveLength(1);

    const homeId = report.rootIds[0];
    const [home] = await h.db.select().from(pages).where(eq(pages.id, homeId));
    expect(home.title).toBe("Team Home");
    const kids = await childrenOf(homeId);
    expect(kids.map((k) => [k.title, k.kind]).sort()).toEqual([
      ["Projects", "page"],
      ["Tasks", "database"],
    ]);
    const projects = kids.find((k) => k.title === "Projects")!;
    const tasks = kids.find((k) => k.title === "Tasks")!;
    expect((await childrenOf(projects.id)).map((k) => k.title)).toEqual(["Roadmap"]);

    // Links point at the imported pages; the image was uploaded.
    const homeBlocks = text(await getBlocks(h.db, homeId));
    expect(homeBlocks).toContain(`/w/${wsId}/p/${projects.id}`);
    expect(homeBlocks).toContain(`/w/${wsId}/p/${tasks.id}`);
    expect(homeBlocks).toMatch(/"src":"\/api\/files\/[^"]+"/);
    expect(text(await getBlocks(h.db, projects.id))).toContain(`/w/${wsId}/p/${homeId}`);

    // Every row (from the _all CSV), once; record pages are not duplicated as pages.
    const q = await queryDatabase(h.db, actor, tasks.id, {});
    expect(q.rows.map((r) => r.title).sort()).toEqual(["Ship it", "Write spec"]);
    const meta = await loadDatabaseMeta(h.db, tasks.id);
    expect(meta.properties.map((p) => p.name)).toEqual(expect.arrayContaining(["Name", "Status", "Estimate"]));
    expect(await childrenOf(tasks.id)).toHaveLength(0);
    // The record page holds its body without the repeated property lines.
    const write = q.rows.find((r) => r.title === "Write spec")!;
    const body = text(await getBlocks(h.db, write.id));
    expect(body).toContain("Note: the spec lives in");
    expect(body).not.toContain("Estimate: 3");
    expect(body).toContain(`/w/${wsId}/p/${projects.id}`);
  });

  it("reads exports split into nested ZIPs and imports under a page", async () => {
    const inner = zipSync(exportFiles());
    const outer = Buffer.from(zipSync({ "Export-abc-Part-1.zip": inner }));
    const host = (await importUpload(h.db, actor, wsId, { name: "host.md", data: Buffer.from("# Host\n") }, {})).rootIds[0];
    const report = await importUpload(h.db, actor, wsId, { name: "Export.zip", data: outer }, { parentId: host });
    expect(report).toMatchObject({ kind: "notion", pages: 3, databases: 1, records: 2 });
    expect((await childrenOf(host)).map((k) => k.title)).toEqual(["Team Home"]);
  });

  it("only strips lines naming the database's columns", () => {
    const cols = new Set(["Status", "Estimate"]);
    expect(stripPropertyLines("Status: Done\nEstimate: 3\n\nBody", cols)).toBe("Body");
    expect(stripPropertyLines("Note: keep me\nStatus: Done", cols)).toBe("Note: keep me\nStatus: Done");
    expect(stripPropertyLines("Body only", cols)).toBe("Body only");
  });
});

describe("Markdown ZIP imports (not from Notion)", () => {
  it("upload relative images and drop links to files that aren't in the archive", async () => {
    const zip = Buffer.from(
      zipSync({
        "notes/readme.md": strToU8("# Readme\n\n![Diagram](img/diagram.png)\n\nSee [the missing page](missing.md) and [docs](https://example.com/docs).\n"),
        "notes/img/diagram.png": PNG,
      }),
    );
    const report = await importUpload(h.db, actor, wsId, { name: "notes.zip", data: zip }, {});
    if (report.kind !== "markdown") throw new Error("expected a Markdown import, got " + report.kind);
    expect(report.files).toBe(1);
    const readme = (await h.db.select().from(pages).where(eq(pages.title, "Readme")))[0];
    const body = text(await getBlocks(h.db, readme.id));
    expect(body).toMatch(/"src":"\/api\/files\/[^"]+"/);
    expect(body).toContain("the missing page");
    expect(body).not.toContain("missing.md");
    expect(body).toContain("https://example.com/docs");
  });
});
