// Linked database blocks with their own views (stored in the block, not the database).
import { describe, it, expect, beforeAll, afterAll } from "vitest";
import type { DbHandle } from "@/server/db";
import { setupDb, makeUser, makeWorkspace } from "./helpers";
import { createPage, saveContent } from "@/server/services/pages";
import { addProperty, createRecord, loadDatabaseMeta, queryDatabase } from "@/server/services/databases";
import { setPublicShare, queryPublicDatabase } from "@/server/services/sharing";
import type { ViewDef } from "@/lib/db-types";

let h: DbHandle;
beforeAll(async () => {
  h = await setupDb();
});
afterAll(async () => h.close());

describe("linked views with their own settings", () => {
  it("queries with the block's view config and serves it on public pages through the block", async () => {
    const { actor } = await makeUser(h, "Linker");
    const ws = await makeWorkspace(h, actor);
    const host = await createPage(h.db, actor, { workspaceId: ws.id, title: "Dashboard" });
    // The database lives inside the shared page, so the share covers it.
    const dbId = (await createPage(h.db, actor, { workspaceId: ws.id, kind: "database", title: "Tasks", parentId: host.id })).id;
    const done = await addProperty(h.db, actor, dbId, { name: "Done", type: "checkbox" });
    for (const [title, d] of [["open one", false], ["finished", true], ["open two", false]] as const) await createRecord(h.db, actor, dbId, { title, values: { Done: d } });
    const meta = await loadDatabaseMeta(h.db, dbId);
    const own: ViewDef[] = [
      { id: "own-open", databaseId: dbId, name: "Open", type: "list", position: 0, config: { filter: { kind: "group", id: "g", op: "and", filters: [{ kind: "condition", id: "c", propertyId: done.id, operator: "is_not_checked" }] } } },
    ];
    await saveContent(h.db, actor, host.id, {
      blocks: [
        { id: "lv", content: { type: "databaseView", attrs: { id: "lv", databaseId: dbId, viewId: "own-open", views: own } } },
        { id: "plain", content: { type: "paragraph", attrs: { id: "plain" }, content: [{ type: "text", text: "x" }] } },
      ],
    });

    // Signed-in: the block's config is sent as the query config; the database's views are untouched.
    const live = await queryDatabase(h.db, actor, dbId, { viewId: null, config: own[0].config as Record<string, unknown> });
    expect(live.rows.map((r) => r.title).sort()).toEqual(["open one", "open two"]);
    expect((await loadDatabaseMeta(h.db, dbId)).views).toEqual(meta.views);

    // Public page: the server reads the views from the block.
    const { token } = await setPublicShare(h.db, actor, host.id, true);
    const pub = await queryPublicDatabase(h.db, token!, dbId, "own-open", { pageId: host.id, blockId: "lv" });
    expect(pub.views.map((v) => v.id)).toEqual(["own-open"]);
    expect(pub.rows.map((r) => r.title).sort()).toEqual(["open one", "open two"]);
    // Without the block, the database's own (unfiltered) view.
    expect((await queryPublicDatabase(h.db, token!, dbId, null)).rows).toHaveLength(3);
    // A block that isn't a view of this database, or a page outside the share, is not found.
    await expect(queryPublicDatabase(h.db, token!, dbId, null, { pageId: host.id, blockId: "plain" })).rejects.toMatchObject({ status: 404 });
    const outside = await createPage(h.db, actor, { workspaceId: ws.id, title: "Elsewhere" });
    await saveContent(h.db, actor, outside.id, { blocks: [{ id: "lv2", content: { type: "databaseView", attrs: { id: "lv2", databaseId: dbId, views: own } } }] });
    await expect(queryPublicDatabase(h.db, token!, dbId, null, { pageId: outside.id, blockId: "lv2" })).rejects.toMatchObject({ status: 404 });
  });
});
