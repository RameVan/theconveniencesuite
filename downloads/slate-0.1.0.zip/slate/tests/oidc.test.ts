// Single sign-on against a real OpenID Connect provider (oidc-provider) running on this machine.
import { describe, it, expect, beforeAll, afterAll, beforeEach } from "vitest";
import http from "node:http";
import type { AddressInfo } from "node:net";
import Provider from "oidc-provider";
import { eq } from "drizzle-orm";
import type { DbHandle } from "@/server/db";
import { users, userIdentities } from "@/server/db/schema";
import { setupDb, makeUser } from "./helpers";
import { startOidc, finishOidc, resetOidcClient, NO_PASSWORD } from "@/server/services/oidc";
import { login } from "@/server/services/auth";

const REDIRECT = "http://slate.test/api/auth/oidc/callback";
type Account = { email: string; email_verified: boolean; name: string };
const accounts: Record<string, Account> = {};
let loginAs = "";
let h: DbHandle;
let server: http.Server;
let issuer = "";

beforeAll(async () => {
  h = await setupDb();
  server = http.createServer();
  await new Promise<void>((r) => server.listen(0, "127.0.0.1", r));
  issuer = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  const provider = new Provider(issuer, {
    clients: [{ client_id: "slate", client_secret: "test-secret", redirect_uris: [REDIRECT], grant_types: ["authorization_code"], response_types: ["code"] }],
    findAccount: async (_ctx, id) => ({ accountId: id, claims: async () => ({ sub: id, ...accounts[id] }) }),
    claims: { openid: ["sub"], email: ["email", "email_verified"], profile: ["name"] },
    features: { devInteractions: { enabled: false } },
    interactions: { url: (_ctx, interaction) => `/interaction/${interaction.uid}` },
    cookies: { keys: ["test-cookie-key"] },
  });
  const callback = provider.callback();
  server.on("request", async (req, res) => {
    if (req.url?.startsWith("/interaction/")) {
      // The provider's login and consent screen: sign in as `loginAs` and grant the scopes.
      const details = await provider.interactionDetails(req, res);
      const grant = new provider.Grant({ accountId: loginAs, clientId: "slate" });
      grant.addOIDCScope(String(details.params.scope));
      const grantId = await grant.save();
      await provider.interactionFinished(req, res, { login: { accountId: loginAs }, consent: { grantId } }, { mergeWithLastSubmission: false });
      return;
    }
    callback(req, res);
  });
});
afterAll(async () => {
  server.close();
  await h.close();
});
beforeEach(() => {
  process.env.OIDC_ISSUER = issuer;
  process.env.OIDC_CLIENT_ID = "slate";
  process.env.OIDC_CLIENT_SECRET = "test-secret";
  delete process.env.OIDC_ALLOW_SIGNUP;
  resetOidcClient();
});

/** Run the browser side of the flow: follow redirects (with cookies) until the provider sends us back. */
async function signInWithProvider(accountId: string) {
  loginAs = accountId;
  const flow = await startOidc(REDIRECT, "/w/next-page");
  const jar = new Map<string, string>();
  let url = flow.url;
  for (let i = 0; i < 10; i++) {
    if (url.startsWith(REDIRECT)) return { callback: new URL(url), cookie: flow.cookie };
    const res = await fetch(url, { redirect: "manual", headers: { cookie: [...jar].map(([k, v]) => `${k}=${v}`).join("; ") } });
    for (const c of res.headers.getSetCookie()) {
      const [pair] = c.split(";");
      const at = pair.indexOf("=");
      jar.set(pair.slice(0, at), pair.slice(at + 1));
    }
    const next = res.headers.get("location");
    if (!next) throw new Error(`provider stopped at ${res.status}: ${await res.text()}`);
    url = new URL(next, url).href;
  }
  throw new Error("too many redirects");
}

describe("OpenID Connect sign-in", () => {
  it("creates an account, then signs the same identity in again", async () => {
    await makeUser(h, "Existing admin"); // not the first user
    accounts.ada = { email: "Ada@Example.com", email_verified: true, name: "Ada Lovelace" };
    const first = await signInWithProvider("ada");
    const a = await finishOidc(h.db, first.callback, first.cookie);
    expect(a).toMatchObject({ created: true, next: "/w/next-page", user: { email: "ada@example.com", name: "Ada Lovelace", isAdmin: false } });
    const [row] = await h.db.select().from(users).where(eq(users.id, a.user.id));
    expect(row.passwordHash).toBe(NO_PASSWORD);
    // An SSO-only account can't log in with any password.
    await expect(login(h.db, { email: "ada@example.com", password: NO_PASSWORD })).rejects.toMatchObject({ status: 401 });

    // Even if the provider later changes the email, the subject identifies the same account.
    accounts.ada = { ...accounts.ada, email: "ada.l@example.com" };
    const again = await signInWithProvider("ada");
    const b = await finishOidc(h.db, again.callback, again.cookie);
    expect(b).toMatchObject({ created: false, user: { id: a.user.id } });
  });

  it("links an existing account through a verified email only", async () => {
    const existing = await makeUser(h, "Grace");
    accounts.grace = { email: existing.email, email_verified: false, name: "Grace" };
    const unverified = await signInWithProvider("grace");
    await expect(finishOidc(h.db, unverified.callback, unverified.cookie)).rejects.toMatchObject({ status: 403 });
    expect(await h.db.select().from(userIdentities).where(eq(userIdentities.userId, existing.user.id))).toHaveLength(0);

    accounts.grace.email_verified = true;
    const verified = await signInWithProvider("grace");
    const r = await finishOidc(h.db, verified.callback, verified.cookie);
    expect(r).toMatchObject({ created: false, user: { id: existing.user.id } });
    expect(await h.db.select().from(userIdentities).where(eq(userIdentities.userId, existing.user.id))).toHaveLength(1);
    // The password still works for the linked account.
    await expect(login(h.db, { email: existing.email, password: "password123" })).resolves.toMatchObject({ id: existing.user.id });
  });

  it("respects OIDC_ALLOW_SIGNUP and rejects tampered or replayed callbacks", async () => {
    process.env.OIDC_ALLOW_SIGNUP = "false";
    accounts.eve = { email: "eve@example.com", email_verified: true, name: "Eve" };
    const blocked = await signInWithProvider("eve");
    await expect(finishOidc(h.db, blocked.callback, blocked.cookie)).rejects.toMatchObject({ status: 403 });
    delete process.env.OIDC_ALLOW_SIGNUP;

    accounts.mallory = { email: "mallory@example.com", email_verified: true, name: "Mallory" };
    const one = await signInWithProvider("mallory");
    const two = await signInWithProvider("mallory");
    // Another browser's flow cookie (state/nonce/PKCE mismatch) is refused.
    await expect(finishOidc(h.db, one.callback, two.cookie)).rejects.toMatchObject({ status: 400 });
    await expect(finishOidc(h.db, one.callback, undefined)).rejects.toMatchObject({ status: 400 });
    await finishOidc(h.db, two.callback, two.cookie);
    // A code can't be used twice.
    await expect(finishOidc(h.db, two.callback, two.cookie)).rejects.toMatchObject({ status: 400 });
  });

  it("only redirects to same-site paths afterwards", async () => {
    for (const next of ["//evil.example/x", "https://evil.example", "/\\evil"]) {
      const flow = await startOidc(REDIRECT, next);
      const decoded = JSON.parse(Buffer.from(flow.cookie, "base64url").toString("utf8"));
      expect(decoded.next).toBeNull();
    }
  });
});

describe("request origin for redirects", () => {
  it("uses the Host header, forwarded headers only behind a trusted proxy, and APP_URL first", async () => {
    const { requestOrigin } = await import("@/server/http");
    const req = (headers: Record<string, string>) => new Request("http://localhost:3000/api/auth/oidc/start", { headers });
    expect(requestOrigin(req({ host: "127.0.0.1:3200" }))).toBe("http://127.0.0.1:3200");
    expect(requestOrigin(req({ host: "a.test", "x-forwarded-host": "evil.test", "x-forwarded-proto": "https" }))).toBe("http://a.test");
    process.env.TRUST_PROXY = "true";
    expect(requestOrigin(req({ host: "a.test", "x-forwarded-host": "slate.example.com", "x-forwarded-proto": "https" }))).toBe("https://slate.example.com");
    delete process.env.TRUST_PROXY;
    process.env.APP_URL = "https://notes.example.org/";
    expect(requestOrigin(req({ host: "a.test" }))).toBe("https://notes.example.org");
    delete process.env.APP_URL;
  });
});

describe("accounts created through single sign-on", () => {
  it("can set a first password from a session, then use it", async () => {
    const { changePassword } = await import("@/server/services/auth");
    accounts.sam = { email: "sam@example.com", email_verified: true, name: "Sam" };
    const flow = await signInWithProvider("sam");
    const { user } = await finishOidc(h.db, flow.callback, flow.cookie);
    expect(user.hasPassword).toBe(false);
    // API tokens can't set the first password.
    await expect(changePassword(h.db, { userId: user.id, via: "token" }, { newPassword: "first-pass-123" })).rejects.toMatchObject({ status: 403 });
    await changePassword(h.db, { userId: user.id, via: "session" }, { newPassword: "first-pass-123" });
    await expect(login(h.db, { email: "sam@example.com", password: "first-pass-123" })).resolves.toMatchObject({ id: user.id, hasPassword: true });
    // From now on the current password is required.
    await expect(changePassword(h.db, { userId: user.id, via: "session" }, { newPassword: "second-pass-123" })).rejects.toMatchObject({ status: 400 });
  });

  it("can delete the account by typing its email", async () => {
    const { deleteAccount } = await import("@/server/services/auth");
    accounts.del = { email: "leaving@example.com", email_verified: true, name: "Leaving" };
    const flow = await signInWithProvider("del");
    const { user } = await finishOidc(h.db, flow.callback, flow.cookie);
    const actor = { userId: user.id, via: "session" as const };
    await expect(deleteAccount(h.db, actor, { email: "someone@else.com" })).rejects.toMatchObject({ status: 400 });
    await expect(deleteAccount(h.db, { ...actor, via: "token" }, { email: "leaving@example.com" })).rejects.toMatchObject({ status: 403 });
    await deleteAccount(h.db, actor, { email: "Leaving@Example.com" });
    expect(await h.db.select().from(users).where(eq(users.id, user.id))).toHaveLength(0);
  });
});
