// Link previews against real websites. Needs internet, so it's opt-in: npm run test:online
import { describe, it, expect } from "vitest";
import { unfurl } from "@/server/services/unfurl";

describe.skipIf(!process.env.SLATE_ONLINE_TESTS)("link previews (online)", () => {
  it("reads the title of a plain page", async () => {
    const r = await unfurl("https://example.com");
    expect(r.title).toBe("Example Domain");
    expect(r.url).toBe("https://example.com/");
  }, 20_000);

  it("reads Open Graph title, description and image, following redirects", async () => {
    const r = await unfurl("http://github.com"); // redirects to https
    expect(r.url.startsWith("https://github.com")).toBe(true);
    expect(r.title).toMatch(/GitHub/);
    expect(r.description?.length ?? 0).toBeGreaterThan(10);
    expect(r.image).toMatch(/^https:\/\//);
  }, 20_000);

  it("reads a YouTube video page", async () => {
    const r = await unfurl("https://www.youtube.com/watch?v=jNQXAC9IVRw"); // "Me at the zoo"
    expect(r.title.toLowerCase()).toContain("zoo");
  }, 20_000);

  it("still refuses private network addresses", async () => {
    await expect(unfurl("http://127.0.0.1:3000")).rejects.toMatchObject({ status: 400 });
    await expect(unfurl("http://192.168.1.1")).rejects.toMatchObject({ status: 400 });
  }, 20_000);
});
