// "Forgot password" through a real SMTP server (smtp-server) running locally.
import { describe, it, expect, beforeAll, afterAll, afterEach } from "vitest";
import { SMTPServer } from "smtp-server";
import type { AddressInfo } from "node:net";
import { eq } from "drizzle-orm";
import type { DbHandle } from "@/server/db";
import { passwordResets, users } from "@/server/db/schema";
import { setupDb, makeUser } from "./helpers";
import { login, getSessionUser } from "@/server/services/auth";
import { requestPasswordReset, resetPassword } from "@/server/services/password-reset";
import { flushEmails } from "@/server/services/email";

const inbox: { to: string[]; raw: string }[] = [];
let smtp: SMTPServer;
let h: DbHandle;
const decode = (raw: string) => raw.replace(/=\r?\n/g, "").replace(/=([0-9A-F]{2})/g, (_, x) => String.fromCharCode(parseInt(x, 16)));
const tokenFrom = (raw: string) => decodeURIComponent(/reset-password\?token=([A-Za-z0-9%_-]+)/.exec(raw)![1]);

beforeAll(async () => {
  h = await setupDb();
  smtp = new SMTPServer({
    authOptional: true,
    disabledCommands: ["STARTTLS"],
    logger: false,
    onData(stream, session, done) {
      let raw = "";
      stream.on("data", (c) => (raw += c.toString()));
      stream.on("end", () => {
        inbox.push({ to: session.envelope.rcptTo.map((r) => r.address), raw: decode(raw) });
        done();
      });
    },
  });
  await new Promise<void>((r) => smtp.listen(0, "127.0.0.1", () => r()));
  process.env.SMTP_URL = `smtp://127.0.0.1:${(smtp.server.address() as AddressInfo).port}`;
  process.env.APP_URL = "https://notes.example.org";
});
afterAll(async () => {
  delete process.env.SMTP_URL;
  delete process.env.APP_URL;
  await new Promise<void>((r) => smtp.close(() => r()));
  await h.close();
});
afterEach(() => {
  inbox.length = 0;
});

describe("forgot password", () => {
  it("emails a single-use link built from APP_URL, resets the password and signs out everywhere", async () => {
    const u = await makeUser(h, "Forgetful");
    const unknown = await requestPasswordReset(h.db, { email: "nobody@example.com" });
    const known = await requestPasswordReset(h.db, { email: u.email.toUpperCase() });
    expect(known).toEqual(unknown); // no way to tell whether an account exists
    await flushEmails();
    expect(inbox.map((m) => m.to)).toEqual([[u.email]]);
    expect(inbox[0].raw).toContain("Subject: Reset your Slate password");
    expect(inbox[0].raw).toContain("https://notes.example.org/reset-password?token=");
    const token = tokenFrom(inbox[0].raw);
    // Only a hash is stored.
    expect((await h.db.select().from(passwordResets)).some((r) => r.tokenHash === token)).toBe(false);

    await expect(resetPassword(h.db, { token, password: "short" })).rejects.toThrow();
    await resetPassword(h.db, { token, password: "brand-new-pass-1" });
    await expect(login(h.db, { email: u.email, password: "brand-new-pass-1" })).resolves.toMatchObject({ id: u.user.id });
    await expect(login(h.db, { email: u.email, password: "password123" })).rejects.toMatchObject({ status: 401 });
    expect(await getSessionUser(h.db, u.token)).toBeNull();
    // The link works once.
    await expect(resetPassword(h.db, { token, password: "another-pass-2" })).rejects.toMatchObject({ status: 400 });
  });

  it("cancels other outstanding links and refuses expired ones", async () => {
    const u = await makeUser(h, "Twice");
    await requestPasswordReset(h.db, { email: u.email });
    await requestPasswordReset(h.db, { email: u.email });
    await flushEmails();
    const [first, second] = inbox.map((m) => tokenFrom(m.raw));
    await resetPassword(h.db, { token: second, password: "second-pass-123" });
    await expect(resetPassword(h.db, { token: first, password: "first-pass-123" })).rejects.toMatchObject({ status: 400 });

    inbox.length = 0;
    await requestPasswordReset(h.db, { email: u.email });
    await flushEmails();
    const late = tokenFrom(inbox[0].raw);
    await h.db.update(passwordResets).set({ expiresAt: new Date(Date.now() - 1000) }).where(eq(passwordResets.userId, u.user.id));
    await expect(resetPassword(h.db, { token: late, password: "late-pass-1234" })).rejects.toMatchObject({ status: 400 });
  });

  it("gives accounts created through single sign-on a password", async () => {
    const u = await makeUser(h, "Sso Only");
    await h.db.update(users).set({ passwordHash: "sso-only" }).where(eq(users.id, u.user.id));
    await requestPasswordReset(h.db, { email: u.email });
    await flushEmails();
    await resetPassword(h.db, { token: tokenFrom(inbox[0].raw), password: "now-has-a-pass" });
    await expect(login(h.db, { email: u.email, password: "now-has-a-pass" })).resolves.toMatchObject({ hasPassword: true });
  });

  it("says when email isn't available, without sending anything", async () => {
    const u = await makeUser(h, "No Mail");
    const appUrl = process.env.APP_URL;
    delete process.env.APP_URL; // links need the public URL
    expect(await requestPasswordReset(h.db, { email: u.email })).toEqual({ ok: true, emailAvailable: false });
    process.env.APP_URL = appUrl;
    await flushEmails();
    expect(inbox).toHaveLength(0);
    expect(await h.db.select().from(passwordResets).where(eq(passwordResets.userId, u.user.id))).toHaveLength(0);
  });
});
