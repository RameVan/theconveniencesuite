// Runs core workflows against a real PostgreSQL server (node-postgres driver) instead of PGlite.
// Opt-in: `npm run test:pg` starts a throwaway PostgreSQL with the embedded-postgres dev dependency,
// or set SLATE_TEST_DATABASE_URL to use an existing empty database.
import { describe, it, expect, beforeAll, afterAll } from "vitest";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { createDb, setDbHandle, type DbHandle } from "@/server/db";
import { signup, createSession } from "@/server/services/auth";
import { createWorkspace } from "@/server/services/workspaces";
import { getTree, getPage, saveContent, archivePage, restorePage, duplicatePage } from "@/server/services/pages";
import { queryDatabase, addProperty, createRecord, loadDatabaseMeta } from "@/server/services/databases";
import { search } from "@/server/services/search";
import { buildExportZip, importUpload } from "@/server/services/transfer";
import { setStorage } from "@/server/services/files";
import * as B from "@/lib/block-builders";

const enabled = !!process.env.SLATE_PG_TESTS || !!process.env.SLATE_TEST_DATABASE_URL;

describe.skipIf(!enabled)("PostgreSQL driver", () => {
  let h: DbHandle;
  let stop: (() => Promise<void>) | null = null;

  beforeAll(async () => {
    let url = process.env.SLATE_TEST_DATABASE_URL;
    if (!url) {
      const { default: EmbeddedPostgres } = await import("embedded-postgres");
      const dir = fs.mkdtempSync(path.join(os.tmpdir(), "slate-pg-"));
      const port = 54000 + Math.floor(Math.random() * 900);
      const pg = new EmbeddedPostgres({ databaseDir: dir, user: "slate", password: "slate", port, persistent: false, initdbFlags: ["--encoding=UTF8", "--locale=C"], onLog: () => {} });
      await pg.initialise();
      await pg.start();
      await pg.createDatabase("slate_test");
      url = `postgres://slate:slate@127.0.0.1:${port}/slate_test`;
      stop = async () => {
        await pg.stop();
        fs.rmSync(dir, { recursive: true, force: true });
      };
    }
    h = await createDb(url);
    expect(h.driver).toBe("pg");
    setDbHandle(h);
    const mem = new Map<string, Buffer>();
    setStorage({ put: async (k, d) => void mem.set(k, d), get: async (k) => mem.get(k)!, delete: async (k) => void mem.delete(k) });
  }, 180_000);

  afterAll(async () => {
    await h?.close();
    await stop?.();
  }, 60_000);

  it("runs the main workflows", async () => {
    const user = await signup(h.db, { email: `pg-${Date.now()}@example.com`, password: "password123", name: "Pg User" }, { bypassSignupSwitch: true });
    const s = await createSession(h.db, user.id);
    const actor = { userId: user.id, sessionId: s.sessionId, via: "session" as const };
    const ws = await createWorkspace(h.db, actor, { name: "PG workspace" }); // seeds starter content
    const tree = await getTree(h.db, actor, ws.id);
    const welcome = tree.nodes.find((n) => n.title === "Getting started")!;
    const tasks = tree.nodes.find((n) => n.title === "Tasks")!;
    const page = await getPage(h.db, actor, welcome.id);
    expect(page.content.length).toBeGreaterThan(5);
    await saveContent(h.db, actor, welcome.id, { baseVersion: page.page.version, blocks: [B.p("Postgres works")].map((b) => ({ id: b.attrs!.id as string, content: b })) });

    const q = await queryDatabase(h.db, actor, tasks.id, {});
    expect(q.rows).toHaveLength(3);
    const meta = await loadDatabaseMeta(h.db, tasks.id);
    const status = meta.properties.find((p) => p.name === "Status")!;
    const g = await queryDatabase(h.db, actor, tasks.id, { config: { groupBy: status.id } });
    expect(g.groups!.reduce((n, x) => n + x.rowIds.length, 0)).toBe(3);
    const pts = await addProperty(h.db, actor, tasks.id, { name: "Points", type: "number" });
    await createRecord(h.db, actor, tasks.id, { title: "Extra", values: { [pts.id]: 8 } });

    const hits = await search(h.db, actor, { q: "postgres", workspaceId: ws.id });
    expect(hits.map((x) => x.id)).toContain(welcome.id);

    await archivePage(h.db, actor, welcome.id);
    await restorePage(h.db, actor, welcome.id);
    const copy = await duplicatePage(h.db, actor, tasks.id);
    expect((await queryDatabase(h.db, actor, copy.id, {})).rows).toHaveLength(4);

    const zip = await buildExportZip(h.db, actor, [welcome.id, tasks.id], { workspaceId: ws.id });
    const ws2 = await createWorkspace(h.db, actor, { name: "Restore", starter: false });
    const r = await importUpload(h.db, actor, ws2.id, { name: "backup.zip", data: zip }, {});
    expect(r.rootIds).toHaveLength(2);
  }, 120_000);
});
