// The SQL fast path (query-sql.ts) must return exactly what the in-memory engine returns.
import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { eq, sql } from "drizzle-orm";
import type { DbHandle } from "@/server/db";
import { pages } from "@/server/db/schema";
import { setupDb, makeUser, makeWorkspace } from "./helpers";
import { createPage } from "@/server/services/pages";
import { addProperty, createRecord, loadDatabaseMeta, queryDatabase } from "@/server/services/databases";
import { sqlPlan } from "@/server/services/query-sql";
import type { Actor } from "@/server/services/auth";
import type { FilterCondition, FilterGroup, PropertyDef, ViewConfig } from "@/lib/db-types";

let h: DbHandle;
let actor: Actor;
let dbId: string;
let props: PropertyDef[];
const ids: string[] = [];

// Deterministic PRNG so failures reproduce.
let seed = 12345;
const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
const pick = <T,>(a: readonly T[]): T => a[Math.floor(rnd() * a.length)];

beforeAll(async () => {
  h = await setupDb();
  const u = await makeUser(h, "Pusher");
  actor = u.actor;
  const ws = await makeWorkspace(h, actor);
  dbId = (await createPage(h.db, actor, { workspaceId: ws.id, kind: "database", title: "Diff" })).id;
  const opts = (names: string[]) => ({ options: names.map((n, i) => ({ id: `${n.toLowerCase()}-${i}`, name: n, color: "blue" as const })) });
  await addProperty(h.db, actor, dbId, { name: "Amount", type: "number" });
  await addProperty(h.db, actor, dbId, { name: "Stage", type: "select", config: opts(["Lead", "Won", "Lost"]) });
  await addProperty(h.db, actor, dbId, { name: "State", type: "status", config: opts(["Todo", "Doing", "Done"]) });
  await addProperty(h.db, actor, dbId, { name: "Done", type: "checkbox" });
  await addProperty(h.db, actor, dbId, { name: "Twice", type: "formula", config: { expression: 'prop("Amount") * 2' } });
  props = (await loadDatabaseMeta(h.db, dbId)).properties;
  const stage = props.find((p) => p.name === "Stage")!;
  const state = props.find((p) => p.name === "State")!;
  for (let i = 0; i < 150; i++) {
    const values: Record<string, unknown> = {};
    if (rnd() < 0.8) values.Amount = pick([0, 1, -3, 2.5, 7, 7, 100, 0.1 + 0.2, 1e6]);
    if (rnd() < 0.7) values.Stage = pick(stage.config.options!).id;
    if (rnd() < 0.7) values.State = pick(state.config.options!).id;
    if (rnd() < 0.5) values.Done = rnd() < 0.5;
    const r = await createRecord(h.db, actor, dbId, { title: `R${i % 40}`, values });
    ids.push(r.row.id);
  }
  // Malformed stored values the API never writes, to check both engines treat them alike.
  const raw = async (id: string, patch: Record<string, unknown>) =>
    h.db.update(pages).set({ properties: sql`${pages.properties} || ${JSON.stringify(patch)}::jsonb` }).where(eq(pages.id, id));
  const amount = props.find((p) => p.name === "Amount")!;
  const done = props.find((p) => p.name === "Done")!;
  await raw(ids[0], { [amount.id]: "5" });
  await raw(ids[1], { [stage.id]: "ghost" });
  await raw(ids[2], { [stage.id]: 3 });
  await raw(ids[3], { [done.id]: "true" });
  await raw(ids[4], { [state.id]: null });
  // Equal positions, so ties fall through to creation order and id.
  await h.db.update(pages).set({ position: 1 }).where(eq(pages.id, ids[5]));
  await h.db.update(pages).set({ position: 1 }).where(eq(pages.id, ids[6]));
});
afterAll(async () => h.close());

const byName = (n: string) => props.find((p) => p.name === n)!;

function randomCondition(): FilterCondition {
  const p = pick(["Amount", "Stage", "State", "Done"].map(byName));
  const id = `c${Math.floor(rnd() * 1e9)}`;
  if (p.type === "checkbox") return { kind: "condition", id, propertyId: p.id, operator: pick(["is_checked", "is_not_checked", "is_empty", "is_not_empty"] as const) };
  if (p.type === "number") {
    const operator = pick(["equals", "not_equals", "gt", "lt", "gte", "lte", "is_empty", "is_not_empty", "is_checked", "is_not_checked"] as const);
    return { kind: "condition", id, propertyId: p.id, operator, value: pick([0, 7, "7", 2.5, -3, "", null, "abc", 0.30000000000000004, "1e6"] as const) };
  }
  const opIds = p.config.options!.map((o) => o.id);
  const operator = pick(["equals", "not_equals", "is_empty", "is_not_empty", "is_checked", "is_not_checked"] as const);
  return { kind: "condition", id, propertyId: p.id, operator, value: pick([pick(opIds), "ghost", "", null, [pick(opIds), pick(opIds)], []] as const) as never };
}

function randomGroup(depth: number): FilterGroup {
  const n = Math.floor(rnd() * 4);
  return {
    kind: "group",
    id: `g${depth}`,
    op: pick(["and", "or"] as const),
    filters: Array.from({ length: n }, () => (depth < 2 && rnd() < 0.3 ? randomGroup(depth + 1) : randomCondition())),
  };
}

function randomConfig(): ViewConfig {
  const config: ViewConfig = {};
  if (rnd() < 0.8) config.filter = randomGroup(0);
  const nSorts = Math.floor(rnd() * 3);
  if (nSorts) config.sorts = Array.from({ length: nSorts }, () => ({ propertyId: pick(["Amount", "Stage", "State", "Done"].map(byName)).id, direction: pick(["asc", "desc"] as const) }));
  else if (rnd() < 0.4) config.manualOrder = [...ids].sort(() => rnd() - 0.5).slice(0, Math.floor(rnd() * 60));
  return config;
}

describe("SQL push-down equals the in-memory engine", () => {
  it("random filters, sorts and manual orders", async () => {
    let pushed = 0;
    for (let i = 0; i < 250; i++) {
      const config = randomConfig();
      expect(sqlPlan(config, props, null), JSON.stringify(config)).not.toBeNull();
      pushed++;
      const auto = await queryDatabase(h.db, actor, dbId, { config: config as Record<string, unknown> });
      const memory = await queryDatabase(h.db, actor, dbId, { config: config as Record<string, unknown> }, { engine: "memory" });
      const msg = JSON.stringify(config);
      expect(auto.rows.map((r) => r.id), msg).toEqual(memory.rows.map((r) => r.id));
      expect([auto.total, auto.matched], msg).toEqual([memory.total, memory.matched]);
      // Cell values for returned rows (formulas included) are the same.
      expect(auto.rows, msg).toEqual(memory.rows);
      if (i % 25 === 0) {
        const offset = Math.floor(rnd() * 40);
        const a = await queryDatabase(h.db, actor, dbId, { config: config as Record<string, unknown>, offset, limit: 17 });
        const m = await queryDatabase(h.db, actor, dbId, { config: config as Record<string, unknown>, offset, limit: 17 }, { engine: "memory" });
        expect(a.rows.map((r) => r.id), msg).toEqual(m.rows.map((r) => r.id));
        expect([a.offset, a.hasMore, a.matched], msg).toEqual([m.offset, m.hasMore, m.matched]);
      }
    }
    expect(pushed).toBe(250);
  }, 120_000);

  it("leaves text sorts, search, grouping and aggregations to the in-memory engine", () => {
    const title = props.find((p) => p.type === "title")!;
    expect(sqlPlan({ sorts: [{ propertyId: title.id, direction: "asc" }] }, props, null)).toBeNull();
    expect(sqlPlan({}, props, "R1")).toBeNull();
    expect(sqlPlan({ groupBy: byName("Stage").id }, props, null)).toBeNull();
    expect(sqlPlan({ aggregations: { [byName("Amount").id]: "sum" } }, props, null)).toBeNull();
    expect(sqlPlan({ filter: { kind: "group", id: "g", op: "and", filters: [{ kind: "condition", id: "c", propertyId: byName("Twice").id, operator: "gt", value: 3 }] } }, props, null)).toBeNull();
    expect(sqlPlan({ manualOrder: [ids[0], ids[0]] }, props, null)).toBeNull();
  });

  it("pages grouped results per group", async () => {
    const stage = byName("Stage");
    const full = await queryDatabase(h.db, actor, dbId, { config: { groupBy: stage.id } });
    const paged = await queryDatabase(h.db, actor, dbId, { config: { groupBy: stage.id }, offset: 0, limit: 50, groupLimit: 3 });
    for (const g of paged.groups!) {
      const all = full.groups!.find((x) => x.key === g.key)!;
      expect(g.count).toBe(all.rowIds.length);
      expect(g.rowIds).toEqual(all.rowIds.slice(0, 3));
    }
    const won = full.groups!.find((g) => g.rowIds.length > 3)!;
    const more = await queryDatabase(h.db, actor, dbId, { config: { groupBy: stage.id }, offset: 3, limit: 5, groupKey: won.key });
    expect(more.groups!.map((g) => g.key)).toEqual([won.key]);
    expect(more.groups![0].rowIds).toEqual(won.rowIds.slice(3, 8));
    expect(more.rows.map((r) => r.id)).toEqual(won.rowIds.slice(3, 8));
  });
});

describe("paged in-memory queries (cached evaluation)", () => {
  it("pages match the full result and follow every kind of record change", async () => {
    const { updateRecord, reorderRecords } = await import("@/server/services/databases");
    const { archivePage, restorePage } = await import("@/server/services/pages");
    const title = props.find((p) => p.type === "title")!;
    // A title sort runs in memory.
    const config = { sorts: [{ propertyId: title.id, direction: "asc" }] } as Record<string, unknown>;
    expect(sqlPlan(config as ViewConfig, props, null)).toBeNull();
    const paged = async () => {
      const out: string[] = [];
      for (let offset = 0; ; offset += 40) {
        const r = await queryDatabase(h.db, actor, dbId, { config, offset, limit: 40 });
        out.push(...r.rows.map((x) => x.id));
        if (!r.hasMore) return { ids: out, matched: r.matched, rows: r.rows };
      }
    };
    const full = async () => (await queryDatabase(h.db, actor, dbId, { config })).rows.map((r) => r.id);
    const check = async () => expect((await paged()).ids).toEqual(await full());

    await check();
    await check(); // served from the cache
    await updateRecord(h.db, actor, ids[10], { title: "AAA first" });
    await check();
    expect((await paged()).ids[0]).toBe(ids[10]);
    await archivePage(h.db, actor, ids[10]);
    await check();
    expect((await paged()).ids).not.toContain(ids[10]);
    await restorePage(h.db, actor, ids[10]);
    await check();
    expect((await paged()).ids[0]).toBe(ids[10]);
    await reorderRecords(h.db, actor, dbId, [...ids].reverse());
    await check();
    const created = await createRecord(h.db, actor, dbId, { title: "AA newest" });
    await check();
    expect((await paged()).ids[0]).toBe(created.row.id);
    // Cell values come from the current record, also on cached pages.
    await updateRecord(h.db, actor, created.row.id, { values: { Amount: 41 } });
    const first = (await queryDatabase(h.db, actor, dbId, { config, offset: 0, limit: 5 })).rows[0];
    expect(first.values[byName("Amount").id]).toBe(41);
    expect(first.values[byName("Twice").id]).toBe(82);
  }, 120_000);
});

describe("moving one record in the manual order", () => {
  it("places the record before another, at the end, and copes with tied positions", async () => {
    const { moveRecord } = await import("@/server/services/databases");
    const u = await makeUser(h, "Mover");
    const ws = await makeWorkspace(h, u.actor);
    const d = (await createPage(h.db, u.actor, { workspaceId: ws.id, kind: "database", title: "Order" })).id;
    const rec: string[] = [];
    for (const t of ["a", "b", "c", "d", "e"]) rec.push((await createRecord(h.db, u.actor, d, { title: t })).row.id);
    const order = async () => (await queryDatabase(h.db, u.actor, d, { offset: 0, limit: 100 })).rows.map((r) => r.title).join("");
    expect(await order()).toBe("abcde");
    await moveRecord(h.db, u.actor, d, rec[4], rec[1]); // e before b
    expect(await order()).toBe("aebcd");
    await moveRecord(h.db, u.actor, d, rec[0], rec[3]); // a before d (moving down)
    expect(await order()).toBe("ebcad");
    await moveRecord(h.db, u.actor, d, rec[4], null); // e to the end
    expect(await order()).toBe("bcade");
    // Tied positions force a renumbering, still exact.
    await h.db.update(pages).set({ position: 7 }).where(eq(pages.databaseId, d));
    const tied = await order(); // ties: creation order
    expect(tied).toBe("abcde");
    await moveRecord(h.db, u.actor, d, rec[0], rec[3]);
    expect(await order()).toBe("bcade");
    // Viewers can't move; records of other databases are not found.
    const viewer = await makeUser(h, "Viewer of order");
    await expect(moveRecord(h.db, viewer.actor, d, rec[0], null)).rejects.toMatchObject({ status: 404 });
    await expect(moveRecord(h.db, u.actor, d, ids[0], null)).rejects.toMatchObject({ status: 404 });
  });
});

describe("date filters in SQL", () => {
  let d: string;
  let dprops: PropertyDef[];
  let owner: Actor;
  const today = new Date();
  const iso = (offsetDays: number, time = false) => {
    const t = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate() + offsetDays, time ? 23 : 0, time ? 30 : 0));
    return time ? t.toISOString() : t.toISOString().slice(0, 10);
  };

  beforeAll(async () => {
    const u = await makeUser(h, "Dater");
    owner = u.actor;
    const ws = await makeWorkspace(h, owner);
    d = (await createPage(h.db, owner, { workspaceId: ws.id, kind: "database", title: "Dates" })).id;
    await addProperty(h.db, owner, d, { name: "When", type: "date" });
    for (let i = 0; i < 160; i++) {
      const r = rnd();
      const off = Math.floor(rnd() * 140) - 70;
      const value =
        r < 0.15 ? null : r < 0.45 ? iso(off) : r < 0.65 ? { start: iso(off, true), includeTime: true } : r < 0.85 ? { start: iso(off), end: iso(off + Math.floor(rnd() * 20)) } : { start: iso(off), end: iso(off - 3) };
      await createRecord(h.db, owner, d, { title: `D${i}`, values: value === null ? {} : { When: value } });
    }
    dprops = (await loadDatabaseMeta(h.db, d)).properties;
  });

  const ops = ["equals", "not_equals", "before", "after", "on_or_before", "on_or_after", "is_empty", "is_not_empty", "is_relative"] as const;
  const relatives = ["today", "tomorrow", "yesterday", "this_week", "past_week", "next_week", "this_month", "past_month", "next_month", "past_year", "next_year"];
  const randomDateCondition = (): FilterCondition => {
    const when = dprops.find((p) => p.name === "When")!;
    const operator = pick(ops);
    const value = operator === "is_relative" ? pick(relatives) : pick([iso(0), iso(-10), iso(25), iso(-60, true), "today", "tomorrow", "yesterday", "", "not a date", null] as const);
    return { kind: "condition", id: `c${Math.floor(rnd() * 1e9)}`, propertyId: when.id, operator, value: value as never };
  };

  it("matches the in-memory engine for random date conditions", async () => {
    for (let i = 0; i < 200; i++) {
      const n = 1 + Math.floor(rnd() * 3);
      const config = { filter: { kind: "group", id: "g", op: pick(["and", "or"] as const), filters: Array.from({ length: n }, randomDateCondition) } } as ViewConfig;
      const msg = JSON.stringify(config);
      const viaSql = await queryDatabase(h.db, owner, d, { config: config as Record<string, unknown> }, { engine: "sql" });
      const memory = await queryDatabase(h.db, owner, d, { config: config as Record<string, unknown> }, { engine: "memory" });
      expect(viaSql.rows.map((r) => r.id), msg).toEqual(memory.rows.map((r) => r.id));
      expect(viaSql.matched, msg).toBe(memory.matched);
    }
  }, 120_000);

  it("falls back to memory when a stored date isn't in a canonical form", async () => {
    const when = dprops.find((p) => p.name === "When")!;
    const config = { filter: { kind: "group", id: "g", op: "and", filters: [{ kind: "condition", id: "c", propertyId: when.id, operator: "on_or_after", value: iso(-5) }] } } as Record<string, unknown>;
    const [first] = await h.db.select({ id: pages.id }).from(pages).where(eq(pages.databaseId, d)).limit(1);
    await h.db.update(pages).set({ properties: sql`${pages.properties} || ${JSON.stringify({ [when.id]: "March 3, 2026" })}::jsonb` }).where(eq(pages.id, first.id));
    await expect(queryDatabase(h.db, owner, d, { config }, { engine: "sql" })).rejects.toThrow("cannot run in SQL");
    const auto = await queryDatabase(h.db, owner, d, { config });
    const memory = await queryDatabase(h.db, owner, d, { config }, { engine: "memory" });
    expect(auto.rows.map((r) => r.id)).toEqual(memory.rows.map((r) => r.id));
  });
});
