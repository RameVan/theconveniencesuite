import { describe, it, expect, beforeAll, afterAll, afterEach } from "vitest";
import { eq } from "drizzle-orm";
import type { DbHandle } from "@/server/db";
import { rateLimits } from "@/server/db/schema";
import { rateLimit, resetRateLimits } from "@/server/http";
import { setupDb } from "./helpers";

let h: DbHandle;
beforeAll(async () => {
  h = await setupDb();
});
afterAll(async () => h.close());
afterEach(() => {
  delete process.env.RATE_LIMIT_STORE;
  resetRateLimits();
});

const count = async (fn: () => Promise<void>, n: number) => {
  let ok = 0;
  for (let i = 0; i < n; i++) ok += await fn().then(() => 1, (e) => (e.status === 429 ? 0 : Promise.reject(e)));
  return ok;
};

describe("rate limiting", () => {
  it("in memory: allows the limit per window, then 429", async () => {
    expect(await count(() => rateLimit("mem:a", 5), 8)).toBe(5);
    expect(await count(() => rateLimit("mem:b", 5), 3)).toBe(3); // separate keys
  });

  it("in the database: shared counters with the same limits and windows", async () => {
    process.env.RATE_LIMIT_STORE = "database";
    expect(await count(() => rateLimit("db:a", 5, 400), 8)).toBe(5);
    // The counter lives in the shared table (other instances see it).
    const [row] = await h.db.select().from(rateLimits).where(eq(rateLimits.key, "db:a"));
    expect(row.count).toBe(8);
    // Clearing this process's memory doesn't reset a shared limit.
    resetRateLimits();
    expect(await count(() => rateLimit("db:a", 5, 400), 1)).toBe(0);
    // A new window starts after the old one expires.
    await new Promise((r) => setTimeout(r, 450));
    expect(await count(() => rateLimit("db:a", 5, 400), 6)).toBe(5);
    // Limits of 0 disable limiting.
    expect(await count(() => rateLimit("db:z", 0), 3)).toBe(3);
  });
});
