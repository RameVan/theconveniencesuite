// "No artificial limits" and performance checks. These use realistic volumes and assert both
// correctness (no caps) and reasonable timing on the embedded database.
import { describe, it, expect, beforeAll, afterAll } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { sql } from "drizzle-orm";
import type { DbHandle } from "@/server/db";
import { setupDb, makeUser, makeWorkspace } from "./helpers";
import { createPage, getPage, getTree, saveContent } from "@/server/services/pages";
import { addProperty, queryDatabase, createRecord } from "@/server/services/databases";
import { importCsv } from "@/server/services/transfer";
import { search } from "@/server/services/search";
import { pages } from "@/server/db/schema";
import type { Actor } from "@/server/services/auth";
import * as B from "@/lib/block-builders";

let h: DbHandle;
let actor: Actor;
let wsId: string;
beforeAll(async () => {
  h = await setupDb();
  actor = (await makeUser(h, "Scale")).actor;
  wsId = (await makeWorkspace(h, actor)).id;
});
afterAll(async () => {
  await h.close();
});

describe("no artificial limits", () => {
  it("creates hundreds of databases", async () => {
    const t0 = Date.now();
    for (let i = 0; i < 200; i++) await createPage(h.db, actor, { workspaceId: wsId, title: `DB ${i}`, kind: "database" });
    const [{ n }] = await h.db.select({ n: sql<number>`count(*)::int` }).from(pages).where(sql`${pages.kind} = 'database' AND ${pages.workspaceId} = ${wsId}`);
    expect(n).toBe(200);
    const tree = await getTree(h.db, actor, wsId);
    expect(tree.nodes.filter((x) => x.kind === "database")).toHaveLength(200);
    console.log(`[scale] 200 databases in ${Date.now() - t0} ms`);
  });

  it("holds thousands of records in one database and queries them quickly", async () => {
    const rows = ["Name,Amount,Stage,Due"];
    const stages = ["Lead", "Qualified", "Proposal", "Won", "Lost"];
    for (let i = 0; i < 5000; i++) rows.push(`Item ${i},${i % 997},${stages[i % 5]},2026-${String((i % 12) + 1).padStart(2, "0")}-15`);
    const t0 = Date.now();
    const { databaseId, records } = await importCsv(h.db, actor, wsId, rows.join("\n"), { title: "Big" });
    const tImport = Date.now() - t0;
    expect(records).toBe(5000);
    // Add one more record through the normal path: no cap is hit.
    await createRecord(h.db, actor, databaseId, { title: "Item 5000" });
    const props = (await import("@/server/services/databases")).loadDatabaseMeta;
    const meta = await props(h.db, databaseId);
    const amount = meta.properties.find((p) => p.name === "Amount")!;
    const stage = meta.properties.find((p) => p.name === "Stage")!;
    const f = await addProperty(h.db, actor, databaseId, { name: "Double", type: "formula", config: { expression: 'prop("Amount") * 2' } });
    const t1 = Date.now();
    const q = await queryDatabase(h.db, actor, databaseId, {
      config: {
        filter: { kind: "group", id: "g", op: "and", filters: [{ kind: "condition", id: "c", propertyId: amount.id, operator: "gt", value: 500 }] },
        sorts: [{ propertyId: f.id, direction: "desc" }],
        groupBy: stage.id,
        aggregations: { [amount.id]: "sum" },
      },
    });
    const tQuery = Date.now() - t1;
    expect(q.total).toBe(5001);
    expect(q.rows.length).toBeGreaterThan(2000);
    expect(q.rows[0].values[f.id]).toBe(996 * 2);
    expect(q.groups!.reduce((s, g) => s + g.rowIds.length, 0)).toBe(q.rows.length);
    console.log(`[scale] import 5000 rows ${tImport} ms; filter+sort+group+formula query ${tQuery} ms`);
    expect(tQuery).toBeLessThan(15_000);
  });

  it("supports deeply nested pages", async () => {
    let parent: string | null = null;
    let last = "";
    for (let i = 0; i < 120; i++) {
      const p = await createPage(h.db, actor, { workspaceId: wsId, parentId: parent, title: `Depth ${i}` });
      parent = p.id;
      last = p.id;
    }
    const page = await getPage(h.db, actor, last);
    expect(page.breadcrumbs).toHaveLength(119);
  });

  it("stores large pages with thousands of blocks", async () => {
    const p = await createPage(h.db, actor, { workspaceId: wsId, title: "Long page" });
    const blocks = Array.from({ length: 3000 }, (_, i) => B.p(`Paragraph number ${i} with some searchable text`));
    const t0 = Date.now();
    await saveContent(h.db, actor, p.id, { blocks: blocks.map((b) => ({ id: b.attrs!.id as string, content: b })) });
    const loaded = await getPage(h.db, actor, p.id);
    expect(loaded.content).toHaveLength(3000);
    const hits = await search(h.db, actor, { q: "Paragraph number 2999", workspaceId: wsId });
    expect(hits.some((r) => r.id === p.id)).toBe(true);
    console.log(`[scale] 3000-block page save+load+search ${Date.now() - t0} ms`);
  });
});

describe("no plan gating in the codebase", () => {
  it("has no subscription / plan / tier checks", () => {
    const root = path.resolve(__dirname, "../src");
    const offenders: string[] = [];
    const walk = (dir: string) => {
      for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
        const p = path.join(dir, e.name);
        if (e.isDirectory()) walk(p);
        else if (/\.(ts|tsx)$/.test(e.name)) {
          const src = fs.readFileSync(p, "utf8");
          if (/\b(subscription|isPro|isPremium|planTier|pricingTier|isPaid|freePlan|paidPlan|upgradeRequired|featureGate)\b/i.test(src)) offenders.push(path.relative(root, p));
        }
      }
    };
    walk(root);
    expect(offenders).toEqual([]);
  });
});
