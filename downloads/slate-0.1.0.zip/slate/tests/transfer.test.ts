import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { unzipSync, strFromU8 } from "fflate";
import type { DbHandle } from "@/server/db";
import { setupDb, makeUser, makeWorkspace } from "./helpers";
import { createPage, saveContent, getPage } from "@/server/services/pages";
import { addProperty, createRecord, queryDatabase, loadDatabaseMeta } from "@/server/services/databases";
import { buildExportZip, importUpload, importCsv, exportDatabaseCsv, exportPage } from "@/server/services/transfer";
import { uploadFile } from "@/server/services/files";
import { blocksToMarkdown, markdownToBlocks, blocksToHtml } from "@/lib/markdown";
import { parseCsv, toCsv, unguard } from "@/lib/csv";
import * as B from "@/lib/block-builders";
import type { Actor } from "@/server/services/auth";

let h: DbHandle;
let actor: Actor;
let wsId: string;
beforeAll(async () => {
  h = await setupDb();
  actor = (await makeUser(h, "Porter")).actor;
  wsId = (await makeWorkspace(h, actor)).id;
});
afterAll(async () => {
  await h.close();
});

describe("markdown conversion", () => {
  it("round-trips common blocks", () => {
    const md = [
      "# Title",
      "",
      "Some **bold**, *italic*, ~~strike~~ and `code` with a [link](https://example.com).",
      "",
      "- one",
      "- two",
      "  - nested",
      "",
      "1. first",
      "2. second",
      "",
      "- [ ] open task",
      "- [x] done task",
      "",
      "> a quote",
      "",
      "```ts",
      "const x = 1;",
      "```",
      "",
      "---",
      "",
      "| a | b |",
      "| --- | --- |",
      "| 1 | 2 |",
      "",
      "$$",
      "E = mc^2",
      "$$",
    ].join("\n");
    const blocks = markdownToBlocks(md);
    expect(blocks.map((b) => b.type)).toEqual(["heading", "paragraph", "bulletList", "orderedList", "taskList", "blockquote", "codeBlock", "horizontalRule", "table", "equation"]);
    const out = blocksToMarkdown(blocks);
    expect(out).toContain("**bold**");
    expect(out).toContain("- [x] done task");
    expect(out).toContain("  - nested");
    expect(out).toContain("```ts\nconst x = 1;\n```");
    expect(out).toContain("| a | b |");
    expect(out).toContain("$$\nE = mc^2\n$$");
    // Second round trip is stable.
    expect(blocksToMarkdown(markdownToBlocks(out))).toBe(out);
  });

  it("reports what Markdown cannot represent", () => {
    const loss = new Map<string, number>();
    blocksToMarkdown([B.callout("💡", "hi", "red"), B.toc(), { type: "paragraph", content: [{ type: "text", text: "x", marks: [{ type: "textStyle", attrs: { color: "red" } }] }] }], { loss });
    expect([...loss.keys()]).toEqual(expect.arrayContaining(["Callout colors", "Table of contents blocks", "Text colors"]));
  });

  it("escapes HTML output", () => {
    const html = blocksToHtml([{ type: "paragraph", content: [{ type: "text", text: "<script>alert(1)</script>", marks: [{ type: "link", attrs: { href: "javascript:alert(1)" } }] }] }]);
    expect(html).not.toContain("<script>");
    expect(html).not.toContain("javascript:");
  });
});

describe("csv", () => {
  it("parses quoted fields and guards formulas", () => {
    expect(parseCsv('a,b\n"x, y","He said ""hi"""\n')).toEqual([
      ["a", "b"],
      ["x, y", 'He said "hi"'],
    ]);
    const out = toCsv([["=1+1", "-5", "-x"]]);
    expect(out).toContain("'=1+1");
    expect(out).toContain(",-5,");
    expect(parseCsv(out)[0].map(unguard)).toEqual(["=1+1", "-5", "-x"]);
  });
});

describe("import and export", () => {
  it("exports a workspace and re-imports it without losing structure", async () => {
    const root = await createPage(h.db, actor, { workspaceId: wsId, title: "Handbook", icon: "📘" });
    const child = await createPage(h.db, actor, { workspaceId: wsId, parentId: root.id, title: "Onboarding" });
    const file = await uploadFile(h.db, actor, wsId, { name: "logo.png", type: "image/png", data: Buffer.from("89504e470d0a1a0a0000000d49484452", "hex") });
    const image = { type: "image", attrs: { id: "img1", src: file.url, alt: "logo" } };
    await saveContent(h.db, actor, root.id, {
      blocks: [B.h(1, "Welcome"), B.p("Read **this** first"), B.childPage(child.id), image].map((b) => ({ id: String(b.attrs!.id), content: b })),
    });
    const dbPage = await createPage(h.db, actor, { workspaceId: wsId, parentId: root.id, title: "People", kind: "database" });
    const team = await addProperty(h.db, actor, dbPage.id, { name: "Team", type: "select" });
    const mentor = await addProperty(h.db, actor, dbPage.id, { name: "Mentor", type: "relation", config: { targetDatabaseId: dbPage.id } });
    const f = await addProperty(h.db, actor, dbPage.id, { name: "Label", type: "formula", config: { expression: 'prop("Name") + " (" + prop("Team") + ")"' } });
    const ada = await createRecord(h.db, actor, dbPage.id, { title: "Ada", values: { [team.id]: "Eng" } });
    await createRecord(h.db, actor, dbPage.id, { title: "Bob", values: { [team.id]: "Ops", [mentor.id]: [ada.row.id] } });

    const zip = await buildExportZip(h.db, actor, [root.id]);
    const files = unzipSync(new Uint8Array(zip));
    const names = Object.keys(files);
    expect(names).toContain("slate.json");
    expect(names).toContain("loss-report.md");
    expect(names).toContain("Handbook.md");
    expect(names).toContain("Handbook/Onboarding.md");
    expect(names).toContain("Handbook/People.csv");
    expect(names).toContain(`files/${file.id}`);
    expect(strFromU8(files["Handbook.md"])).toContain("[Onboarding](Handbook/Onboarding.md)");
    expect(strFromU8(files["Handbook/People.csv"])).toContain("Bob,,Ops,Ada,Bob (Ops)");

    // Import into a second workspace.
    const ws2 = (await makeWorkspace(h, actor, "Restore target")).id;
    const report = await importUpload(h.db, actor, ws2, { name: "export.zip", data: zip }, {});
    expect(report.kind).toBe("slate");
    expect(report.warnings).toEqual([]);
    const newRoot = await getPage(h.db, actor, report.rootIds[0]);
    expect(newRoot.page.title).toBe("Handbook");
    expect(newRoot.page.id).not.toBe(root.id);
    expect(newRoot.children.map((c) => c.title).sort()).toEqual(["Onboarding", "People"]);
    const childRef = newRoot.content.find((b) => b.type === "childPage")!;
    expect(newRoot.children.map((c) => c.id)).toContain(childRef.attrs!.pageId);
    const img = newRoot.content.find((b) => b.type === "image")!;
    expect(img.attrs!.src).not.toBe(file.url); // re-uploaded with a new id
    expect(String(img.attrs!.src)).toMatch(/^\/api\/files\//);

    const newDb = newRoot.children.find((c) => c.title === "People")!;
    const meta = await loadDatabaseMeta(h.db, newDb.id);
    const newRel = meta.properties.find((p) => p.name === "Mentor")!;
    expect(newRel.config.targetDatabaseId).toBe(newDb.id);
    const q = await queryDatabase(h.db, actor, newDb.id, {});
    const bob = q.rows.find((r) => r.title === "Bob")!;
    const newAda = q.rows.find((r) => r.title === "Ada")!;
    expect(bob.values[newRel.id]).toEqual([newAda.id]);
    const newF = meta.properties.find((p) => p.name === "Label")!;
    expect(bob.values[newF.id]).toBe("Bob (Ops)");
    void f;

    // Importing again creates a second copy rather than overwriting.
    const again = await importUpload(h.db, actor, ws2, { name: "export.zip", data: zip }, {});
    expect(again.rootIds[0]).not.toBe(report.rootIds[0]);
  });

  it("rejects malformed and duplicate-id exports", async () => {
    await expect(importUpload(h.db, actor, wsId, { name: "x.json", data: Buffer.from("{nope") }, {})).rejects.toThrow(/could not be parsed/);
    await expect(importUpload(h.db, actor, wsId, { name: "x.json", data: Buffer.from(JSON.stringify({ format: "other" })) }, {})).rejects.toThrow(/not a valid Slate export/);
    const dup = { format: "slate-export", version: 1, pages: [1, 2].map(() => ({ id: "same", parentId: null, databaseId: null, kind: "page", title: "x", icon: null, cover: null, position: 1 })), blocks: [], properties: [], views: [], relations: [], files: [] };
    await expect(importUpload(h.db, actor, wsId, { name: "x.json", data: Buffer.from(JSON.stringify(dup)) }, {})).rejects.toThrow(/duplicate page id/);
  });

  it("imports Markdown files and folders as nested pages", async () => {
    const { zipSync, strToU8 } = await import("fflate");
    const zip = zipSync({
      "Guide.md": strToU8("# Guide\n\nIntro text"),
      "Guide/Install.md": strToU8("# Install\n\n- step one\n- step two"),
      "Notes/Ideas.md": strToU8("Some ideas"),
    });
    const report = await importUpload(h.db, actor, wsId, { name: "md.zip", data: Buffer.from(zip) }, {});
    expect(report.kind).toBe("markdown");
    const guideId = report.rootIds.find(Boolean)!;
    const pagesCreated = await Promise.all(report.rootIds.map((id) => getPage(h.db, actor, id)));
    const guide = pagesCreated.find((p) => p.page.title === "Guide")!;
    expect(guide.children.map((c) => c.title)).toEqual(["Install"]);
    const install = await getPage(h.db, actor, guide.children[0].id);
    expect(install.content[0].type).toBe("bulletList");
    expect(pagesCreated.some((p) => p.page.title === "Notes" && p.children[0]?.title === "Ideas")).toBe(true);
    void guideId;
  });

  it("imports CSV with inferred types and exports it again", async () => {
    const csv = "Name,Amount,Done,Due,Stage,Email\nAlpha,1200,yes,2026-01-05,Lead,a@example.com\nBeta,-30.5,no,2026-02-10,Won,b@example.com\nGamma,,no,,Lead,\n";
    const r = await importCsv(h.db, actor, wsId, csv, { title: "Deals" });
    expect(r.records).toBe(3);
    const meta = await loadDatabaseMeta(h.db, r.databaseId);
    expect(Object.fromEntries(meta.properties.map((p) => [p.name, p.type]))).toEqual({ Name: "title", Amount: "number", Done: "checkbox", Due: "date", Stage: "select", Email: "email" });
    const out = await exportDatabaseCsv(h.db, actor, r.databaseId);
    const rows = parseCsv(out.body.toString("utf8"));
    expect(rows[0]).toEqual(["Name", "Amount", "Done", "Due", "Stage", "Email"]);
    expect(rows.find((x) => x[0] === "Beta")).toEqual(["Beta", "-30.5", "false", "2026-02-10", "Won", "b@example.com"]);
    // Re-import of the export reproduces the same values.
    const r2 = await importCsv(h.db, actor, wsId, out.body.toString("utf8"), { title: "Deals again" });
    const out2 = await exportDatabaseCsv(h.db, actor, r2.databaseId);
    expect(parseCsv(out2.body.toString("utf8")).slice(1).sort()).toEqual(rows.slice(1).sort());
  });

  it("exports single pages as Markdown and HTML", async () => {
    const p = await createPage(h.db, actor, { workspaceId: wsId, title: "Doc <x>" });
    await saveContent(h.db, actor, p.id, { blocks: [B.p("Hello & bye")].map((b) => ({ id: b.attrs!.id as string, content: b })) });
    const md = await exportPage(h.db, actor, p.id, "md");
    expect(md.body.toString()).toBe("# Doc <x>\n\nHello & bye\n");
    const html = await exportPage(h.db, actor, p.id, "html");
    expect(html.body.toString()).toContain("<title>Doc &lt;x&gt;</title>");
    expect(html.body.toString()).toContain("Hello &amp; bye");
  });
});
