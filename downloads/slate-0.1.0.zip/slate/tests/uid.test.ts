import { describe, it, expect, vi, afterEach } from "vitest";
import { webcrypto } from "node:crypto";
import { uid } from "@/lib/uid";

const UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;

describe("uid", () => {
  afterEach(() => vi.unstubAllGlobals());

  it("returns v4 UUIDs", () => {
    expect(uid()).toMatch(UUID_V4);
  });

  it("works where browsers hide crypto.randomUUID (plain HTTP on a LAN address)", () => {
    // Insecure contexts expose getRandomValues but not randomUUID.
    vi.stubGlobal("crypto", { getRandomValues: <T extends ArrayBufferView>(a: T) => webcrypto.getRandomValues(a as never) as T });
    const ids = new Set(Array.from({ length: 1000 }, () => uid()));
    expect(ids.size).toBe(1000);
    for (const id of ids) expect(id).toMatch(UUID_V4);
  });
});
