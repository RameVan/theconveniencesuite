# Turndown

Part of The Convenience Suite. A Chrome extension (Manifest V3) that automatically rejects cookie consent banners, including the optional vendors and "legitimate interest" that many banners hide behind their settings.

## Install

1. Open `chrome://extensions`.
2. Turn on **Developer mode** (top right).
3. Click **Load unpacked** and choose this `CookieDenier` folder.
4. Pin the extension if you want to see the ✓ badge when it handles a banner.

After editing any file, press the reload icon on the extension's card and reload the page you're testing.

## How it works

The content scripts run in every page and frame for the first 30 seconds after load, rescanning whenever the DOM changes. For each banner they try, in order:

1. **Vendor and legitimate-interest banners** (thorough mode, on by default): banners that mention partners, vendors or legitimate interest (IAB TCF banners, where "Reject all" often leaves legitimate interest switched on) are opened in their settings ("More options", "Manage options", "Cookie settings", ...). Then, screen by screen, the script:
   - clicks every "Reject all", "Object all" and "Disagree to all" button;
   - switches off every purpose, vendor and legitimate-interest toggle;
   - visits each Partners / Vendors / Legitimate interest screen and does the same there, going Back when needed;
   - saves with "Save & exit", "Confirm choices", "Save preferences" or similar (never "Accept all").

   If that can't be completed, the rules below take over.
2. **Rules for specific platforms and sites**: about 1,500 rules from DuckDuckGo's [autoconsent](https://github.com/duckduckgo/autoconsent) project, covering hundreds of consent platforms and around 900 individual websites. Eleven platforms that autoconsent handles in code (OneTrust, Cookiebot, Sourcepoint, TrustArc, consentmanager, Evidon, Klaro, Admiral, Conversant, TikTok, Uniconsent) are rewritten as rules in `extra-rules.js`. `rules-engine.js` runs them.
3. **Known platforms** in `content.js` (`CMPS`), recognised by their own selectors.
4. **Unknown banners**: buttons whose text means "reject" (in English, Dutch, German, French, Spanish, Italian, Portuguese, Nordic languages and Polish), such as "Reject all", "Alleen noodzakelijke cookies" or "Alle ablehnen", are clicked, but only when the surrounding element talks about cookies or consent. Banners with no reject button get the settings treatment from step 1, as do banners with switches on the first screen. Accept buttons and links that leave the page (like "Reject and subscribe") are never clicked.
5. **Fallback**: if a banner offers no way to refuse, it is hidden after 5 seconds and page scrolling is unlocked. You can turn this off in the popup.

The scripts look inside shadow DOM (including closed shadow roots) and iframes, and stop after handling one banner per frame. "Pay or accept" walls, where refusing means subscribing, are left alone.

### How the rules run

The background script (`background.js`) loads the rule file once and tells each page which rules apply to its URL and frame type. Out of about 1,500 rules, a typical page gets around 560 and an ad iframe 2. The page first checks each rule's detection selectors in a few combined queries. Only rules whose banner is present are fetched and run, following autoconsent's [rule syntax](https://github.com/duckduckgo/autoconsent/blob/main/docs/rule-syntax.md).

About 35 rules call a small function in the page's own JavaScript, for example `Didomi.setUserDisagreeToAll()`. Those functions are in `vendor/autoconsent/snippets.js`, and the background script runs them through `chrome.scripting` by name only. That's why the extension has the `scripting` permission.

## Popup

- Turn the extension on or off everywhere, or only for the current site.
- Turn "Also refuse all vendors and legitimate interest" on or off. When it's off, banners with a "Reject all" button are only rejected on the first screen, which is faster.
- Turn the hide fallback on or off.
- See what was done on the current page and how many banners have been denied in total.

## Tools

Re-download the autoconsent rules. The script defaults to version 18.1.0; pass a newer version number to update:

```bash
node tools/update-autoconsent.mjs 18.1.0
```

Check the extension against real websites in a throwaway headless Chrome profile. It prints what was done on each site and any banner still visible, and saves screenshots:

```bash
node tools/check-sites.mjs --wait 12 https://www.example.com/ https://www.example.org/
```

For big lists, use `--file sites.txt --parallel 14` (one URL per line) and add `--resume` to continue a run that stopped. `--debug` prints every click the extension makes on each page, which shows why a banner wasn't handled.

## Adding a site that isn't handled

Add a rule to `extra-rules.js` in the [autoconsent rule format](https://github.com/duckduckgo/autoconsent/blob/main/docs/rule-syntax.md):

```js
{
  name: 'example.com',
  runContext: { urlPattern: '^https://(www\\.)?example\\.com/' },
  detectCmp: [{ exists: '#cookie-banner' }],
  detectPopup: [{ visible: '#cookie-banner' }],
  optOut: [{ waitForThenClick: '#cookie-banner .reject' }],
},
```

## Licences

`vendor/autoconsent/` (rules and snippets) and `extra-rules.js` come from or are derived from DuckDuckGo's autoconsent, and are under the Mozilla Public License 2.0 (`vendor/autoconsent/LICENSE`).
