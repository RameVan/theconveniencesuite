// Turndown content script: finds cookie consent banners and refuses everything optional.
// Runs in every frame. Known consent platforms (CMPs) are handled with exact selectors; anything
// else is recognised by button text inside an element that talks about cookies or consent.
// When a banner has no one-click reject, or lists vendors and "legitimate interest" (IAB TCF),
// the script opens its preferences and switches off every purpose, vendor and legitimate
// interest there before saving.
(() => {
  'use strict';
  if (window.__cookieDenierLoaded) return;
  window.__cookieDenierLoaded = true;

  const RUN_FOR_MS = 30000;      // stop looking for a banner after this long
  const PREFS_EXTRA_MS = 30000;  // extra time once we're working through a preferences dialog
  const THROTTLE_MS = 300;       // min gap between scans triggered by DOM changes
  const POLL_MS = 1000;          // scan at least this often
  const STEP_GAP_MS = 400;       // pause between clicks in a preferences dialog so it can re-render
  const STALL_MS = 4000;         // give up on a preferences dialog after this long with nothing to do
  const MAX_PREF_STEPS = 60;
  const MAX_VIEWS = 6;           // vendor / partner / legitimate-interest screens to visit
  const HIDE_AFTER_MS = 5000;    // how long a banner with nothing to click may stay up before we hide it
  const RULES_WAIT_MS = 1500;    // longest we wait for the rules before acting without them
  const LINGER_MS = 4000;        // keep watching this long after the last action
  const RULE_BLOCK_MS = 3000;    // longest a rule may hold up the other strategies
  // tools/check-sites.mjs --debug marks its browser's user agent so the script logs what it does.
  const DEBUG = navigator.userAgent.includes('TurndownDebug');
  const log = (...args) => DEBUG && console.debug('[Turndown]', location.hostname, ...args);

  // detect:   container that shows the CMP is on screen (defaults to the reject selectors)
  // reject:   one-click "reject all" buttons, tried in order
  // settings: opens the preferences layer
  // save:     saves choices in that layer (used alongside the generic "save" text match)
  // hide:     what to hide when nothing can be clicked (defaults to detect)
  const CMPS = [
    {
      name: 'OneTrust',
      detect: '#onetrust-banner-sdk, #onetrust-pc-sdk',
      reject: ['#onetrust-reject-all-handler', '.ot-pc-refuse-all-handler'],
      settings: '#onetrust-pc-btn-handler',
      save: '.save-preference-btn-handler',
      hide: '#onetrust-consent-sdk',
    },
    {
      name: 'Cookiebot',
      detect: '#CybotCookiebotDialog',
      reject: ['#CybotCookiebotDialogBodyButtonDecline', '#CybotCookiebotDialogBodyLevelButtonLevelOptinDeclineAll'],
      settings: '#CybotCookiebotDialogBodyLevelButtonCustomize',
      save: '#CybotCookiebotDialogBodyLevelButtonLevelOptinAllowallSelection',
      hide: '#CybotCookiebotDialog, #CybotCookiebotDialogBodyUnderlay',
    },
    {
      name: 'Didomi',
      detect: '#didomi-host',
      reject: ['#didomi-notice-disagree-button', '.didomi-continue-without-agreeing'],
      settings: '#didomi-notice-learn-more-button',
    },
    {
      name: 'Usercentrics',
      detect: '#usercentrics-root, #usercentrics-cmp-ui',
      reject: ['[data-testid="uc-deny-all-button"]', 'button#deny'],
    },
    {
      name: 'Google Funding Choices',
      detect: '.fc-consent-root',
      reject: ['.fc-cta-do-not-consent'],
      settings: '.fc-cta-manage-options',
      save: '.fc-confirm-choices',
    },
    // Quantcast's buttons have no stable ids; the text matcher handles them.
    { name: 'Quantcast Choice', detect: '.qc-cmp2-container', reject: [] },
    { name: 'TrustArc', detect: '#truste-consent-track', reject: ['#truste-consent-required'] },
    { name: 'CookieYes', detect: '.cky-consent-container, .cky-modal', reject: ['.cky-btn-reject'] },
    { name: 'CookieLawInfo', detect: '#cookie-law-info-bar', reject: ['#cookie_action_close_header_reject', '[data-cli_action="reject"]'] },
    { name: 'Complianz', detect: '#cmplz-cookiebanner-container, .cmplz-cookiebanner', reject: ['.cmplz-deny'] },
    { name: 'Osano', detect: '.osano-cm-window', reject: ['.osano-cm-denyAll'] },
    { name: 'Klaro', detect: '.klaro .cookie-notice, .klaro .cookie-modal', reject: ['.cn-decline', '.cm-btn-decline'] },
    { name: 'iubenda', detect: '#iubenda-cs-banner', reject: ['.iubenda-cs-reject-btn'] },
    { name: 'Borlabs Cookie', detect: '#BorlabsCookieBox', reject: ['[data-cookie-refuse]', '._brlbs-refuse-btn a'] },
    { name: 'Cookie Notice', detect: '#cookie-notice', reject: ['#cn-refuse-cookie'] },
    { name: 'consentmanager', detect: '#cmpbox, #cmpwrapper', reject: ['.cmpboxbtnno', '#cmpbntnotxt'] },
    { name: 'Axeptio', detect: '#axeptio_overlay', reject: ['#axeptio_btn_dismiss'] },
    // Platforms identified by their reject button alone (nothing to hide).
    { name: 'Sourcepoint', reject: ['.sp_choice_type_REJECT_ALL', '.sp_choice_type_13'] },
    { name: 'Cookie Consent', reject: ['.cc-window .cc-deny'] },
    { name: 'Termly', reject: ['[data-tid="banner-decline"]'] },
    { name: 'HubSpot', reject: ['#hs-eu-decline-button'] },
    { name: 'Shopify', reject: ['#shopify-pc__banner__btn-decline'] },
    { name: 'Wix', reject: ['[data-hook="consent-banner-decline-button"]'] },
    { name: 'Civic Cookie Control', reject: ['#ccc-notify-reject', '#ccc-reject-settings'] },
    { name: 'Cookie Script', reject: ['#cookiescript_reject'] },
    { name: 'Moove GDPR', reject: ['.moove-gdpr-infobar-reject-btn'] },
    { name: 'Evidon', reject: ['#_evidon-decline-button'] },
    { name: 'Amazon', reject: ['#sp-cc-rejectall-link'] },
    { name: 'LinkedIn', reject: ['button[action-type="DENY"]'] },
  ];

  // --- Text matching ---------------------------------------------------------

  const CANDIDATES = 'button, a, [role="button"], input[type="button"], input[type="submit"], [class*="btn" i], [class*="button" i], [id*="btn" i], [id*="button" i], [onclick]';
  const NATIVE_CLICKABLE = 'button, a, [role="button"], input';
  const TOGGLE = 'input[type="checkbox"], input[type="radio"], [role="switch"], [role="checkbox"], [role="radio"], [aria-checked]';
  const CHECKED_TOGGLES = 'input[type="checkbox"]:checked:not(:disabled), [role="switch"][aria-checked="true"]:not([aria-disabled="true"]), [role="checkbox"][aria-checked="true"]:not([aria-disabled="true"])';
  const ANY_TOGGLES = 'input[type="checkbox"]:not(:disabled), [role="switch"]:not([aria-disabled="true"]), [role="checkbox"]:not([aria-disabled="true"])';
  // Banners that aren't a cookie choice, even if they mention cookies: never hidden.
  const NOT_A_CONSENT_BANNER = /18\+|\badult|age verification|leeftijd|volwassen|\balter\b|âge|\bedad\b|\betà\b|subscri|abonn|abbon|\bpay\b|premium|€|\$\s?\d/i;

  // A banner must mention cookies/consent, so we never click "Decline" on a newsletter popup.
  const CONSENT_TEXT = /cookie|consent|gdpr|rgpd|dsgvo|tracking|toestemming|einwilligung|consentement|consentimiento|consenso|consentimento|samtycke|samtykke|куки|кукі|クッキー|쿠키|คุกกี้|ملفات تعريف الارتباط|kolačić|çerez|çərəz|piškot|sīkdat|slapuk|evästee|küpsis|souhlas|zgod|súhlas/iu;
  const CONSENT_ATTR = /cookie|consent|gdpr|\bcmp/i;
  // Banners under the IAB framework, where "Reject all" can leave vendors and legitimate interest on.
  // ("Partners" alone isn't enough: plenty of simple banners mention them.)
  const TCF_TEXT = /vendor|legitimate interest|\biab\b|\btcf\b|leverancier|gerechtvaardigd belang|legitiem belang|berechtigte[sn]? interesse|intérêt légitime|interés legítimo|legittimo interesse|uzasadnion/i;

  const EXCLUDE = /settings|preferences|manage|customi[sz]|\boptions\b|more info|learn more|details|polic|pol[ií]tica|instellingen|voorkeur|beheren|aanpassen|einstellungen|verwalten|anpassen|param[eè]tres|personnaliser|g[ée]rer|configur|ajustes|impostazioni|personali[sz]|subscri|suscri|abonn|abbon|assin|prenumer|tilaa|\bpay\b|payer|pagar|pagare|paga\b|betal|bezahl|zahlen|kaufen|acquist|compra|\bbuy\b|purchase|premium/u;

  const EXACT = new Set([
    'no thanks', 'no, thanks', 'no thank you', 'nein danke', 'nee bedankt', 'non merci', 'no gracias',
    'do not accept', "don't accept", 'i do not accept', 'do not consent', 'do not agree', 'i do not agree',
    'niet akkoord', 'ik ga niet akkoord', 'wijs alles af', 'alles afwijzen', 'wijs af', 'nicht einverstanden', 'pas d\'accord',
    'no', 'nee', 'nein', 'non', 'nej', 'nei', 'nei takk', 'ei', 'ne', 'nie', 'não', 'όχι', 'нет', 'ні', 'не', 'hayır', 'tidak', 'nem',
    'continue without accepting', 'continue without agreeing', 'continue without consent',
    'continuer sans accepter', 'weiter ohne einwilligung', 'ohne einwilligung fortfahren',
    'doorgaan zonder te accepteren', 'doorgaan zonder accepteren', 'continua senza accettare', 'continuar sin aceptar',
  ]);

  const ONLY = /(^|\s)(only|just|alleen|enkel|uitsluitend|nur|uniquement|seulement|solo|sólo|solamente|soltanto|apenas|endast|kun|bare|tylko|samo|pouze|iba|csak|doar|только|лише|само|μόνο|sadece|hanya|chỉ|vain|ainult|tik|tikai)(\s|$)/u;
  const NECESSARY = /necessar|essential|required|strictly|standa+rd|basic|basis|minimal|minimum|noodzakelijk|essenti|verplicht|vereist|functione|obligatori|wymagan|notwendig|essenziell|essentiell|erforderlich|nécessaire|essentiel|necesari|esencial|essenzial|necessári|essencia|nödvändig|nødvendig|niezbędn|neophodn|nužn|potrebn|nezbytn|nevyhnutn|szükséges|necesare|необходим|обязательн|необхідн|задължителн|απαραίτητ|zorunlu|gerekli|diperlukan|cần thiết|必要|필수|จำเป็น|ضروري|välttämättöm|vajalik|būtin|nepieciešam/u;
  const ACCEPT_NECESSARY = /^(accept|allow|use|akzeptieren|accepteren|accepter|aceptar|accetta)( only)?( the)?( strictly)? (necessary|essential|required)( cookies)?( only)?$/u;

  const REJECT_VERB = '(reject|decline|deny|refuse|disagree|object|opt[ -]?out|weiger|afwijzen|verwerp|bezwaar|ablehnen|verweigern|widersprech|refuser|opposer|rechazar|denegar|oponer|rifiut|opporre|rejeitar|recusar|odrzu|avvis|afvis|avslå|neka|hylkää|odmítn|odmietn|elutasít|reddet|tolak|từ chối|отклон|отказ|відхил|отхвърл|απόρρι|拒否|拒绝|拒絕|거부|거절|ปฏิเสธ|رفض|refuz|odbij|zavrni|atmesti|noraid|keeldu)';
  // e.g. "Reject all", "Nee, weiger cookies", "Allemaal afwijzen", "Je refuse".
  const REJECT_START = new RegExp(`^((no|nee|nein|non|nej),? )?((i|je|ich|ik) )?((all|alle|alles|allemaal|tout|todo|todas|tutto|tutti) )?${REJECT_VERB}`, 'u');
  const REJECT_END = new RegExp(`${REJECT_VERB}\\p{L}*$`, 'u');
  const ACCEPTISH = /(^|\s)(accept|agree|allow|ok\b|okay|akkoord|accepteren|toestaan|akzept|zustimm|erlauben|einverstanden|accepter|autoriser|acepto|aceptar|permitir|accett|consenti|aceitar|принять|принимаю|согла|хорошо|понятно|прийняти|погоджу|зрозуміло|приемам|съгласен|разбрах|akceptuj|zgadzam|rozumiem|přijmout|souhlasím|rozumím|prijať|súhlasím|αποδοχ|αποδέχομαι|συμφωνώ|同意|承諾|接受|동의|수락|ยอมรับ|terima|setuju|mengerti|kabul|anladım|tamam|aceito|concordo|entendi|de acuerdo|entendido|vale|ho capito|va bene|sunt de acord|am înțeles|prihvati|slažem|godkänn|acceptera|godta|aksepter|hyväksy|elfogad|قبول|موافق)/u;
  const ACCEPT_START = /^(i )?(accept|agree|allow|ok|okay|got it|akkoord|accepteer|accepteren|alles accepteren|alle akzeptieren|akzeptieren|zustimmen|einverstanden|j'accepte|accepter|tout accepter|acepto|aceptar|accetto|accetta|aceito|aceitar|принять|принимаю|согла|хорошо|понятно|прийняти|погоджу|зрозуміло|приемам|съгласен|разбрах|akceptuj|zgadzam|rozumiem|přijmout|souhlasím|rozumím|prijať|súhlasím|αποδοχ|αποδέχομαι|συμφωνώ|同意|承諾|接受|동의|수락|ยอมรับ|terima|setuju|mengerti|kabul|anladım|tamam|aceito|concordo|entendi|de acuerdo|entendido|vale|ho capito|va bene|sunt de acord|am înțeles|prihvati|slažem|godkänn|acceptera|godta|aksepter|hyväksy|elfogad|قبول|موافق)/u;
  const ALL_WORD = /(^|\s)(all|alle|alles|tout|tous|todo|todos|todas|tutti|tutto)(\s|$)/u;

  // Buttons that open the preferences layer: a short label with a settings word ("Cookie settings",
  // "Voorkeur aanpassen", "Instellingen beheren", "Ustawienia zaawansowane"), but not a save, accept
  // or reject button. Vague ones ("learn more") are only tried after the rest.
  const SETTINGS_WORDS = /settings|preferences|options|customi[sz]|manage|let me choose|purposes|instellingen|instellen|voorkeur|opties|beheren|aanpassen|zelf kiezen|doeleinden|einstellungen|optionen|anpassen|verwalten|paramètres|personnaliser|gérer|configur|opciones|personaliz|impostazioni|opzioni|gestisci|definições|gerenciar|ustawienia|zaawansowane|preferencje|inställningar|indstillinger|innstillinger|asetukset/u;
  const SETTINGS_STRONG = { test: (text) => text.length <= 40 && SETTINGS_WORDS.test(text) && !ACCEPTISH.test(text) && !isSaveText(text) && !isRejectText(text) };
  const SETTINGS_WEAK = /^(learn more|more info(rmation)?|show details|details|meer informatie|(toon |meer |bekijk )?details( tonen| bekijken)?|mehr erfahren|mehr informationen|en savoir plus|más información|maggiori informazioni|saiba mais)$/u;
  // Screens inside the preferences layer that list vendors or legitimate-interest switches.
  const VIEW = /partner|vendor|leverancier|anbieter|fournisseur|proveedor|fornitor|legitimate interest|berechtigte[sn]? interesse|gerechtvaardigd belang|legitiem belang|intérêt légitime|interés legítimo|legittimo interesse/u;
  // The save word can come anywhere: "Instellingen opslaan", "Confirm my choices", "Save & exit".
  const SAVE = /(^|\s)(save|confirm|submit|apply|opslaan|bewaren|bevestig\p{L}*|speichern|bestätigen|übernehmen|enregistrer|valider|confirmer|guardar|confirmar|salva|conferma|salvar|zapisz|zapisuję|spara|gem)(\s|$)|^done$/u;
  const SAVE_SELECTION = /^(allow|accept|akzeptieren|erlauben|toestaan|accepteren|accepter|autoriser) (the )?(current |my )?(selection|selected|choices|auswahl|selectie|keuze|sélection)|^((aktuelle|huidige) )?(auswahl|selectie|keuze|sélection|selección|selezione) (erlauben|akzeptieren|zulassen|toestaan|accepteren|bestätigen|speichern|opslaan)/u;
  const BACK = /^(back|go back|terug|zurück|retour|atrás|volver|indietro|voltar|wstecz|tillbaka|tilbage)$/u;

  const normalize = (s) => s
    .toLowerCase()
    .replace(/[‘’]/g, "'")
    .replace(/\s+/g, ' ')
    .replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, '');

  function isRejectText(raw) {
    const text = normalize(raw);
    if (!text || text.length > 60 || EXCLUDE.test(text)) return false;
    if (EXACT.has(text)) return true;
    if ((ONLY.test(text) && NECESSARY.test(text)) || ACCEPT_NECESSARY.test(text)) return true;
    return text.length <= 40 && (REJECT_START.test(text) || REJECT_END.test(text)) && !ACCEPTISH.test(text);
  }

  function isSaveText(raw) {
    const text = normalize(raw);
    if (text.length > 40) return false;
    if (SAVE_SELECTION.test(text)) return true;
    // "Save & accept (all)" may accept everything; plain "Save" / "Confirm my choices" keeps our choices.
    return SAVE.test(text) && !ACCEPTISH.test(text);
  }

  const COMPANY = /(^|\s)(llc|inc|ltd|limited|gmbh|b\.?v|s\.?a|sas|ag|corp|plc|ab|oy|srl|s\.r\.l|pty|co)\.?$/u;

  function isViewText(raw) {
    const text = normalize(raw);
    return text.length <= 50 && VIEW.test(text) && !COMPANY.test(text) && !ACCEPTISH.test(text) && !isRejectText(text) && !isSaveText(text);
  }

  // Any button a consent banner typically has; used to find banners that have no telltale ids.
  function isConsentButtonText(raw) {
    const text = normalize(raw);
    return text.length <= 50 && (isRejectText(text) || ACCEPT_START.test(text) || SETTINGS_STRONG.test(text) || isSaveText(text));
  }

  const textMatches = (pattern) => (el) => pattern.test(normalize(labelOf(el)));

  // --- DOM helpers (these look inside shadow roots too) ----------------------

  const shadowCache = new WeakMap(); // element -> { root, at }

  function shadowOf(el) {
    const cached = shadowCache.get(el);
    // Elements without a shadow root are re-checked now and then, since one can be attached later.
    if (cached && (cached.root || Date.now() - cached.at < 2000)) return cached.root;
    let root = el.shadowRoot;
    try { root = chrome.dom?.openOrClosedShadowRoot?.(el) || root; } catch { /* not a valid host */ }
    shadowCache.set(el, { root, at: Date.now() });
    return root;
  }

  function collectScopes(root) {
    const scopes = [root];
    for (let i = 0; i < scopes.length; i++) {
      const scope = scopes[i];
      if (scope.nodeType === Node.ELEMENT_NODE) {
        const own = shadowOf(scope);
        if (own) scopes.push(own);
      }
      for (const el of scope.querySelectorAll('*')) {
        const shadow = shadowOf(el);
        if (shadow) scopes.push(shadow);
      }
    }
    return scopes;
  }

  function queryAll(scopes, selector) {
    const found = [];
    for (const scope of scopes) {
      try {
        if (scope.nodeType === Node.ELEMENT_NODE && scope.matches(selector)) found.push(scope);
        found.push(...scope.querySelectorAll(selector));
      } catch { /* selector not supported */ }
    }
    return found;
  }

  const parentOf = (node) => node.parentElement || node.getRootNode().host || null;
  const isPageRoot = (el) => el === document.body || el === document.documentElement;

  function containsDeep(outer, inner) {
    for (let node = inner; node; node = parentOf(node)) {
      if (node === outer) return true;
    }
    return false;
  }

  // Visible text, including what's rendered inside shadow roots.
  function textOf(el) {
    return collectScopes(el)
      .map((scope) => (scope.nodeType === Node.ELEMENT_NODE ? scope.innerText : [...scope.children].map((c) => c.innerText).join(' ')) || '')
      .join(' ');
  }

  function isStyleVisible(el) {
    const style = getComputedStyle(el);
    return style.display !== 'none' && style.visibility !== 'hidden' && parseFloat(style.opacity) > 0;
  }

  function hasSize(el) {
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function isClickable(el) {
    return !el.disabled && hasSize(el) && isStyleVisible(el);
  }

  function isShown(el) {
    if (!isStyleVisible(el)) return false;
    if (hasSize(el)) return true;
    // Wrappers such as shadow hosts can be zero-sized while their fixed-position content shows.
    return queryAll(collectScopes(el), 'button, a, p, span, div').some((child) => hasSize(child) && isStyleVisible(child));
  }

  // Banners float over the page; inline page content that merely mentions cookies doesn't.
  function isOverlay(el) {
    let node = el;
    for (let depth = 0; node && depth < 10 && !isPageRoot(node); depth++, node = parentOf(node)) {
      const { position } = getComputedStyle(node);
      if (position === 'fixed' || position === 'sticky') return true;
    }
    return false;
  }

  // The nearest floating ancestor: the outermost one can be a whole app shell (e.g. on klm.nl).
  function nearestOverlay(el) {
    let node = el;
    for (let depth = 0; node && depth < 15 && !isPageRoot(node); depth++, node = parentOf(node)) {
      const { position } = getComputedStyle(node);
      if (position === 'fixed' || position === 'sticky') return node;
    }
    return el;
  }

  // Elements holding the page's own content are never treated as (or hidden as) a banner.
  const isPageShell = (el) => !!el.querySelector?.('main, [role="main"], article') || (el.querySelectorAll?.('a[href]').length ?? 0) > 150;

  function labelOf(el) {
    if (el.tagName === 'INPUT') return el.value || el.getAttribute('aria-label') || '';
    return (el.innerText || el.textContent || '').trim() || el.getAttribute('aria-label') || el.getAttribute('title') || '';
  }

  // Links that leave the page (e.g. "Reject and subscribe") are never clicked by the text matcher.
  function isNavigatingLink(el) {
    const link = el.closest('a[href]');
    if (!link) return false;
    const href = link.getAttribute('href').trim();
    if (!href || href.startsWith('#') || /^javascript:/i.test(href)) return false;
    try {
      const url = new URL(href, location.href);
      return url.origin !== location.origin || url.pathname !== location.pathname;
    } catch {
      return true;
    }
  }

  const inConsentFrame = () => window !== window.top && !!document.body && CONSENT_TEXT.test(document.body.innerText || '');

  // The nearest ancestor that talks about cookies, or null when the element isn't part of a banner.
  // A "Manage cookies" link in the page footer is not a banner.
  function consentRoot(el) {
    if (el.closest?.('footer, [role="contentinfo"]') && !isOverlay(el)) return null;
    let node = el;
    for (let depth = 0; node && depth < 12; depth++) {
      if (isPageRoot(node)) break;
      const attrs = `${node.id || ''} ${node.getAttribute('class') || ''} ${node.getAttribute('aria-label') || ''}`;
      if (CONSENT_ATTR.test(attrs)) return node;
      const text = node.innerText || '';
      if (text.length < 4000 && CONSENT_TEXT.test(text)) return node;
      node = parentOf(node);
    }
    // A small framed document (a CMP served from its own domain) counts as one banner.
    if (window !== window.top && document.body && (document.body.innerText || '').length < 6000 && inConsentFrame()) {
      return document.body;
    }
    return null;
  }

  // Every consent banner or preferences dialog currently on screen (outermost elements only).
  const KNOWN_CONTAINERS = CMPS.filter((cmp) => cmp.detect).map((cmp) => cmp.detect).join(', ');
  const DIALOG_HINTS = 'dialog[open], [role="dialog"], [role="alertdialog"], [aria-modal="true"]';
  const ATTR_HINTS = '[id*="cookie" i], [class*="cookie" i], [id*="consent" i], [class*="consent" i], [id*="gdpr" i], [class*="gdpr" i]';

  function findConsentDialogs() {
    const found = new Set(queryAll(scopes, KNOWN_CONTAINERS).filter(isShown));
    for (const el of queryAll(scopes, DIALOG_HINTS)) {
      if (isShown(el) && CONSENT_TEXT.test(textOf(el))) found.add(el);
    }
    for (const el of queryAll(scopes, ATTR_HINTS)) {
      if (!isPageRoot(el) && isShown(el) && isOverlay(el) && CONSENT_TEXT.test(textOf(el))) found.add(el);
    }
    for (const btn of queryAll(scopes, CANDIDATES)) {
      if ((btn.textContent || '').length > 200 || btn.matches(TOGGLE)) continue;
      if (!isConsentButtonText(labelOf(btn)) || !isClickable(btn)) continue;
      const root = consentRoot(btn);
      if (!root) continue;
      if (isPageRoot(root)) {
        found.add(root);
        continue;
      }
      // Only floating banners and dialogs count: inline page text that mentions cookies doesn't.
      const dialog = nearestOverlay(root);
      if (isOverlay(dialog) || dialog.closest?.(DIALOG_HINTS)) found.add(dialog);
    }
    return outermost([...found].filter((el) => (isPageRoot(el) ? inConsentFrame() : !isPageShell(el))));
  }

  const outermost = (els) => els.filter((el) => !els.some((other) => other !== el && containsDeep(other, el)));

  const isTcf = (el) => TCF_TEXT.test(textOf(el));

  function topHostname() {
    if (window === window.top) return location.hostname;
    const origins = location.ancestorOrigins;
    if (origins?.length) {
      try { return new URL(origins[origins.length - 1]).hostname; } catch { /* fall through */ }
    }
    try { return window.top.location.hostname; } catch { return location.hostname; }
  }

  // --- Scanning --------------------------------------------------------------

  let settings = COOKIE_DENIER_DEFAULTS;
  let scopes = [];
  let startedAt = 0;
  let finished = false;
  let observer = null;
  let pollTimer = null;
  let scanQueued = false;
  let prefs = null;            // state while working through a preferences dialog
  let deferredReject = null;   // a known CMP's reject button, held back while we try its preferences
  let rulesReady = false;      // rules for this page (rules-engine.js) have loaded
  let reported = false;        // a handled banner has been reported
  let lingerUntil = 0;         // after handling, keep watching for a follow-up layer until then
  let ruleRun = null;          // a rule currently working through its banner
  const clicked = new WeakSet();
  const seenAt = new Map();    // cmp -> first time it was on screen

  function click(el) {
    log('click', el.tagName, el.id || String(el.className).slice(0, 40), JSON.stringify(labelOf(el).slice(0, 60)), prefs ? `(preferences step ${prefs.steps})` : '');
    clicked.add(el);
    el.click();
  }

  function firstClickable(searchScopes, selectors) {
    for (const selector of selectors) {
      const el = queryAll(searchScopes, selector).find((c) => !clicked.has(c) && isClickable(c));
      if (el) return el;
    }
    return null;
  }

  // First visible, not-yet-clicked button that passes `test`. Toggles are never treated as buttons.
  function findButton(searchScopes, test, skip = null) {
    for (const el of queryAll(searchScopes, CANDIDATES)) {
      if (clicked.has(el) || skip?.has(el) || (el.textContent || '').length > 200 || el.matches(TOGGLE)) continue;
      // A styled wrapper around real buttons: let the buttons themselves be matched.
      if (!el.matches(NATIVE_CLICKABLE) && el.querySelector(NATIVE_CLICKABLE)) continue;
      if (test(el) && isClickable(el) && !isNavigatingLink(el)) return el;
    }
    return null;
  }

  // Switches off every consent and legitimate-interest toggle. Returns how many were switched.
  function untickToggles(searchScopes) {
    const done = [];
    for (const toggle of queryAll(searchScopes, CHECKED_TOGGLES)) {
      if (clicked.has(toggle)) continue;
      // A label and the checkbox inside it are one control: clicking both would switch it back on.
      const related = done.some((d) => d.contains(toggle) || toggle.contains(d) || d.control === toggle || toggle.control === d);
      const stillOn = toggle.tagName === 'INPUT' ? toggle.checked : toggle.getAttribute('aria-checked') === 'true';
      if (related || !stillOn) continue;
      click(toggle);
      done.push(toggle);
    }
    return done.length;
  }

  function findSettingsButton(searchScopes, skip) {
    return findButton(searchScopes, textMatches(SETTINGS_STRONG), skip) || findButton(searchScopes, textMatches(SETTINGS_WEAK), skip);
  }

  // Clicks `open` and starts working through the preferences it opens. The banner's own buttons
  // are noted before the click, which may re-render synchronously, and not reused there.
  function openPreferences(open, cmp, save, banners) {
    const skip = new WeakSet(queryAll(banners.flatMap(collectScopes), CANDIDATES));
    if (open) click(open);
    prefs = {
      cmp,
      save,
      skip,
      // Dialogs we've worked in stay tracked: a vendor list may not mention cookies at all.
      tracked: new Set(banners),
      lastActionAt: Date.now(),
      steps: 0,
      goneSince: 0,
      inView: false,
      views: new Set(),
      labelCounts: new Map(), // per screen, so one "Reject all" isn't clicked twice
    };
    scheduleStep();
    return true;
  }

  const scheduleStep = () => setTimeout(scan, STEP_GAP_MS + 50);

  // Generated rules are named like "auto_GB_example.com_0": show the site instead.
  const displayName = (name) => name.match(/^auto_[A-Z]{2}_(.+?)_[^_]+(_\+\d+)?$/)?.[1] ?? name;

  // Starts the first matching autoconsent-style rule (rules-engine.js). It runs asynchronously;
  // meanwhile scans pause, and if it fails the other strategies get their turn again.
  function startRules(cosmetic) {
    if (!rulesReady) return false;
    const candidates = CookieDenierRules.candidates(cosmetic);
    if (!candidates.length) return false;
    const report = (rule) => finish(displayName(rule.name), rule.cosmetic ? 'hidden' : 'reject');
    // Many sites reload while an opt-out runs: remember it, so the reloaded page can report it.
    const remember = (rule) => window === window.top && savePending({ cmp: displayName(rule.name), method: rule.cosmetic ? 'hidden' : 'reject' });
    log('trying rules', candidates.map((r) => r.name).slice(0, 5).join(', '));
    const run = CookieDenierRules.run(candidates, report, remember);
    ruleRun = run;
    setTimeout(() => {
      if (ruleRun !== run || reported) return;
      log('rules still waiting; letting the other strategies try');
      ruleRun = null;
      queueScan();
    }, RULE_BLOCK_MS);
    run.then((rule) => {
      if (ruleRun === run) ruleRun = null;
      if (rule && reported) return;
      if (rule) return report(rule);
      savePending(null);
      // No rule worked (or one left its popup up): the other strategies get their turn.
      if (reported) lingerUntil = Date.now() + LINGER_MS;
      queueScan();
    });
    return true;
  }

  // Thorough mode: on banners that list vendors or legitimate interest, go straight into the
  // preferences, where those can be switched off. Rules usually just click "Reject all".
  function openVendorPreferences() {
    for (const cmp of CMPS) {
      if (!cmp.settings || !cmp.detect) continue;
      const containers = queryAll(scopes, cmp.detect).filter(isShown);
      if (!containers.some(isTcf)) continue;
      const open = firstClickable(containers.flatMap(collectScopes), [cmp.settings]);
      if (open) return openPreferences(open, cmp.name, cmp.save, containers);
    }
    for (const dialog of findConsentDialogs()) {
      if (!isTcf(dialog)) continue;
      const open = findSettingsButton(collectScopes(dialog));
      if (open) return openPreferences(open, null, null, [dialog]);
    }
    return false;
  }

  function handleKnownCmps() {
    for (const cmp of CMPS) {
      const detect = cmp.detect || cmp.reject.join(', ');
      if (!detect) continue;
      const containers = queryAll(scopes, detect).filter(isShown);
      if (!containers.length) continue;
      if (!seenAt.has(cmp)) seenAt.set(cmp, Date.now());
      const inside = containers.flatMap(collectScopes);
      const reject = firstClickable(inside, cmp.reject);
      const wantsPreferences = !reject || (settings.thorough && containers.some(isTcf));

      if (wantsPreferences && cmp.settings && !reported) {
        const open = firstClickable(inside, [cmp.settings]);
        if (open) return openPreferences(open, cmp.name, cmp.save, containers);
      }
      if (reject && wantsPreferences && !cmp.settings) {
        // Let the generic flow look for a settings button first; fall back to this reject.
        deferredReject ||= { cmp, el: reject };
        continue;
      }
      if (reject) {
        click(reject);
        return finish(cmp.name, 'reject');
      }
    }
    return false;
  }

  function handleConsentDialogs() {
    const dialogs = findConsentDialogs();
    const reject = findButton(scopes, (el) => isRejectText(labelOf(el)) && !!consentRoot(el));

    // Follow-up layer after a handled banner: only reject or save, never open more settings.
    if (reported) {
      const next = reject || findButton(dialogs.flatMap(collectScopes), (el) => isSaveText(labelOf(el)));
      if (!next) return false;
      click(next);
      return finish(null, 'reject');
    }

    for (const dialog of dialogs) {
      const inside = collectScopes(dialog);
      // With vendors / legitimate interest in play, "Reject all" may not refuse everything: go deeper.
      const goDeeper = !reject || (settings.thorough && isTcf(dialog));
      if (!goDeeper) continue;
      const open = findSettingsButton(inside);
      if (open) return openPreferences(open, deferredReject?.cmp.name ?? null, null, [dialog]);
      // Some banners show their switches right away: switch them off and save.
      const saveSelection = !reject && findButton(inside, (el) => SAVE_SELECTION.test(normalize(labelOf(el))));
      if (!reject && (queryAll(inside, ANY_TOGGLES).length || saveSelection) && findButton(inside, (el) => isSaveText(labelOf(el)))) {
        openPreferences(null, null, null, [dialog]);
        prefs.skip = new WeakSet();
        return true;
      }
    }

    if (deferredReject) {
      click(deferredReject.el);
      return finish(deferredReject.cmp.name, 'reject');
    }
    if (reject) {
      click(reject);
      return finish(null, 'reject');
    }
    return false;
  }

  function stepPreferences() {
    const now = Date.now();
    if (now - prefs.lastActionAt < STEP_GAP_MS) return;

    const tracked = [...prefs.tracked].filter((el) => el.isConnected && isShown(el));
    const dialogs = outermost([...new Set([...findConsentDialogs(), ...tracked])]);
    if (!dialogs.length) {
      // The dialog closed itself (often its "Reject all" also saves). Wait a moment to be sure.
      prefs.goneSince ||= now;
      if (now - prefs.goneSince < 1000) return;
      if (prefs.steps) return finish(prefs.cmp, 'preferences');
      return now - prefs.lastActionAt > STALL_MS ? stop() : undefined;
    }
    prefs.goneSince = 0;
    for (const dialog of dialogs) prefs.tracked.add(dialog);

    const inside = dialogs.flatMap(collectScopes);
    const labelKey = (el) => normalize(labelOf(el));
    // "Reject all" re-renders as a new element after each click, so it counts once per screen;
    // per-purpose buttons ("Niet akkoord" next to each purpose) are separate elements, each clicked once.
    const shownWithLabel = (key) => queryAll(inside, CANDIDATES).filter((c) => labelKey(c) === key && isClickable(c)).length;
    const notClickedOnThisScreen = (el) => {
      const key = labelKey(el);
      const times = prefs.labelCounts.get(key) || 0;
      return ALL_WORD.test(key) ? times === 0 : times < shownWithLabel(key);
    };
    const act = (el, { newScreen = false } = {}) => {
      if (newScreen) prefs.labelCounts.clear();
      else prefs.labelCounts.set(labelKey(el), (prefs.labelCounts.get(labelKey(el)) || 0) + 1);
      click(el);
      prefs.lastActionAt = now;
      prefs.steps++;
      scheduleStep();
      return true;
    };

    if (prefs.steps < MAX_PREF_STEPS) {
      // 1. "Reject all", "Object all", "Disagree to all" (often one per screen)
      const reject = findButton(inside, (el) => isRejectText(labelOf(el)) && notClickedOnThisScreen(el), prefs.skip);
      if (reject) return act(reject);

      // 2. Every purpose, vendor and legitimate-interest switch
      if (untickToggles(inside)) {
        prefs.lastActionAt = now;
        prefs.steps++;
        scheduleStep();
        return;
      }

      // 3. Vendor / partner / legitimate-interest screens, once each
      if (prefs.views.size < MAX_VIEWS) {
        const view = findButton(inside, (el) => isViewText(labelOf(el)) && !prefs.views.has(labelKey(el)), prefs.skip);
        if (view) {
          prefs.views.add(labelKey(view));
          prefs.inView = true;
          return act(view, { newScreen: true });
        }
      }

      // 4. Back out of a sub-screen in case the main screen has more to switch off
      if (prefs.inView) {
        const back = findButton(inside, (el) => BACK.test(labelKey(el)), prefs.skip);
        if (back) {
          prefs.inView = false;
          return act(back, { newScreen: true });
        }
      }
    }

    // 5. Save
    const save = (prefs.save && firstClickable(inside, [prefs.save]))
      || findButton(inside, (el) => isSaveText(labelOf(el)), prefs.skip);
    if (save) {
      click(save);
      return finish(prefs.cmp, 'preferences');
    }

    // 6. Nothing new on this screen: the banner's own buttons may be the settings screen's too
    // (consentmanager re-uses one box). Save, else reject, else back out of a dead-end vendor list.
    if (now - prefs.lastActionAt > STEP_GAP_MS * 3) {
      const own = findButton(inside, (el) => isSaveText(labelOf(el)))
        || findButton(inside, (el) => isRejectText(labelOf(el)));
      if (own) {
        click(own);
        return finish(prefs.cmp, 'preferences');
      }
      if (prefs.inView && !prefs.triedBack) {
        prefs.triedBack = true;
        const back = findButton(inside, (el) => BACK.test(labelKey(el)) || /^(close|sluiten|schließen|fermer|cerrar|chiudi|zamknij|×|✕|x)$/u.test(labelKey(el)));
        if (back) {
          prefs.inView = false;
          return act(back, { newScreen: true });
        }
      }
    }

    if (now - prefs.lastActionAt > STALL_MS) giveUp(dialogs);
  }

  // The preferences dialog couldn't be completed: let a rule for this banner try, reject on the
  // first layer, or hide the banner.
  function giveUp(dialogs) {
    log('giving up on preferences');
    const { cmp } = prefs;
    prefs = null;
    if (startRules(false)) return;
    const reject = findButton(scopes, (el) => isRejectText(labelOf(el)) && !!consentRoot(el));
    if (reject) {
      click(reject);
      return finish(cmp, 'reject');
    }
    if (!settings.hideFallback || !dialogs.filter(hide).length) return stop();
    unlockScroll();
    return finish(cmp, 'hidden');
  }

  function hideStuckBanners() {
    if (!settings.hideFallback) return false;
    for (const [cmp, since] of seenAt) {
      if (!cmp.detect || Date.now() - since < HIDE_AFTER_MS) continue;
      const banners = queryAll(scopes, cmp.hide || cmp.detect).filter(isShown);
      if (!banners.filter(hide).length) continue;
      unlockScroll();
      return finish(cmp.name, 'hidden');
    }
    return false;
  }

  // Returns whether the element was hidden.
  function hide(el) {
    if (isPageRoot(el) || isPageShell(el)) return false;
    el.style.setProperty('display', 'none', 'important');
    return true;
  }

  // Banners often lock page scrolling until you answer them.
  function unlockScroll() {
    for (const el of [document.documentElement, document.body]) {
      if (!el) continue;
      const style = getComputedStyle(el);
      if (style.overflow === 'hidden' || style.overflowY === 'hidden') el.style.setProperty('overflow', 'auto', 'important');
      if (el === document.body && style.position === 'fixed') el.style.setProperty('position', 'static', 'important');
    }
  }

  // Banners that offer no way to refuse ("We use cookies [OK]", "[Accept]"): hide them, which
  // gives no consent. Age gates, pay walls and anything big enough to be part of the page are left.
  function hideBannersWithoutChoice() {
    for (const dialog of findConsentDialogs()) {
      if (isPageRoot(dialog)) continue;
      const inside = collectScopes(dialog);
      const controls = queryAll(inside, CANDIDATES).filter(isClickable);
      const text = textOf(dialog);
      if (controls.length > 6 || text.length > 1500 || NOT_A_CONSENT_BANNER.test(text)) continue;
      const hasChoice = controls.some((el) => {
        const label = labelOf(el);
        if (isNavigatingLink(el)) return false;
        return isRejectText(label) || isSaveText(label) || SETTINGS_STRONG.test(normalize(label));
      });
      if (hasChoice || !hide(dialog)) continue;
      unlockScroll();
      return finish(null, 'hidden');
    }
    return false;
  }

  function scan() {
    try {
      scanOnce();
    } catch (e) {
      log('error', e?.stack || e);
    }
  }

  function scanOnce() {
    if (finished || ruleRun) return;
    const now = Date.now();
    const elapsed = now - startedAt;
    if (elapsed > RUN_FOR_MS + (prefs ? PREFS_EXTRA_MS : 0)) return stop();
    if (reported && !prefs && now > lingerUntil) return stop();
    // Give the rules a moment to load: they know many banners better than the generic matching.
    if (!rulesReady && elapsed < RULES_WAIT_MS) return;
    scopes = collectScopes(document);
    if (prefs) return stepPreferences();
    deferredReject = null;
    (settings.thorough && !reported && openVendorPreferences())
      || startRules(false)
      || handleKnownCmps()
      || handleConsentDialogs()
      // After a banner is handled we only watch for a follow-up layer; nothing gets hidden.
      || (!reported && settings.hideFallback && elapsed > HIDE_AFTER_MS && (startRules(true) || hideStuckBanners() || hideBannersWithoutChoice()));
  }

  function queueScan() {
    if (scanQueued || finished) return;
    scanQueued = true;
    setTimeout(() => {
      scanQueued = false;
      scan();
    }, THROTTLE_MS);
  }

  // An opt-out that was running when the page reloaded, kept in the tab's session storage.
  const PENDING_KEY = '__cookieDenierPending';
  const PENDING_MAX_AGE_MS = 30000;

  function savePending(entry) {
    try {
      if (entry) sessionStorage.setItem(PENDING_KEY, JSON.stringify({ ...entry, at: Date.now() }));
      else sessionStorage.removeItem(PENDING_KEY);
    } catch { /* storage blocked */ }
  }

  function takePending() {
    try {
      const entry = JSON.parse(sessionStorage.getItem(PENDING_KEY) || 'null');
      sessionStorage.removeItem(PENDING_KEY);
      return entry && Date.now() - entry.at < PENDING_MAX_AGE_MS ? entry : null;
    } catch {
      return null;
    }
  }

  // Reports the first banner handled, then keeps watching a few seconds for a second layer
  // (an "are you sure?", a settings screen, or a banner that comes back).
  function finish(cmp, method) {
    log('finish', cmp, method);
    prefs = null;
    lingerUntil = Date.now() + LINGER_MS;
    queueScan();
    if (reported) return true;
    reported = true;
    savePending(null);
    try {
      chrome.runtime.sendMessage({ type: 'denied', cmp, method })?.catch?.(() => {});
    } catch { /* extension was reloaded; nothing to report to */ }
    return true;
  }

  function stop() {
    log('stop', reported ? '(handled)' : '(nothing handled)');
    if (DEBUG && !reported) {
      scopes = collectScopes(document);
      const dialogs = findConsentDialogs();
      log('dialogs', dialogs.map((d) => d.tagName + '#' + d.id + '.' + String(d.className).slice(0, 30)).join(' | ') || 'none');
      for (const d of dialogs) { const o = findSettingsButton(collectScopes(d)); log('  dialog tcf=' + isTcf(d), 'settings=' + (o ? JSON.stringify(labelOf(o).slice(0, 40)) + ' nav=' + isNavigatingLink(o) : 'none'), 'candidates=' + queryAll(collectScopes(d), CANDIDATES).length); }
      const labels = queryAll(scopes, CANDIDATES).filter(isClickable).map((el) => normalize(labelOf(el))).filter((t) => t && t.length < 60);
      log('buttons', JSON.stringify(labels.filter((t) => isConsentButtonText(t) || /cookie|accept|reject|refus|essent/.test(t)).slice(0, 15)));
      const rejects = queryAll(scopes, CANDIDATES).filter((el) => isRejectText(labelOf(el)));
      log('rejects', rejects.map((el) => `${el.tagName} clickable=${isClickable(el)} root=${!!consentRoot(el)} nav=${isNavigatingLink(el)}`).join(' | ') || 'none');
    }
    finished = true;
    observer?.disconnect();
    clearInterval(pollTimer);
  }

  function start() {
    startedAt = Date.now();
    // The previous page reloaded mid opt-out: report it now, then watch for a follow-up layer.
    const pending = window === window.top && takePending();
    if (pending) finish(pending.cmp, pending.method);
    observer = new MutationObserver(queueScan);
    observer.observe(document.documentElement || document, { childList: true, subtree: true });
    pollTimer = setInterval(scan, POLL_MS);
    CookieDenierRules.load().finally(() => {
      rulesReady = true;
      queueScan();
    });
    queueScan();
  }

  chrome.storage.sync.get(COOKIE_DENIER_DEFAULTS, (stored) => {
    settings = stored || COOKIE_DENIER_DEFAULTS;
    if (!settings.enabled || isSiteDisabled(topHostname(), settings.disabledSites)) return;
    start();
  });
})();
