// Rules for the consent platforms that DuckDuckGo's autoconsent handles in code rather than JSON
// (lib/cmps/*.ts, version 18.1.0), rewritten in the same rule format so one interpreter runs them all.
//
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0. If a copy of
// the MPL was not distributed with this file, You can obtain one at https://mozilla.org/MPL/2.0/.
// Derived from https://github.com/duckduckgo/autoconsent
const EXTRA_RULES = [
  {
    name: 'Onetrust',
    detectCmp: [{ any: [{ exists: '#onetrust-banner-sdk' }, { visible: '#onetrust-pc-sdk', check: 'any' }] }],
    detectPopup: [{ visible: '#onetrust-banner-sdk,#onetrust-pc-sdk', check: 'any' }],
    optOut: [
      { wait: 500 },
      // Clicks before the SDK has loaded can be lost.
      {
        if: { exists: 'script[src*="cookielaw.org"],script[src*="otSDKStub"],script[src*="otBannerSdk"]' },
        then: [{ waitFor: '#onetrust-style', timeout: 10000, optional: true }],
      },
      {
        if: { visible: '#onetrust-reject-all-handler', check: 'any' },
        then: [{ click: '#onetrust-reject-all-handler' }],
        else: [{
          if: { visible: '.ot-pc-refuse-all-handler', check: 'any' },
          then: [{ click: '.ot-pc-refuse-all-handler' }],
          else: [{
            if: { visible: '.js-reject-cookies', check: 'any' },
            then: [{ click: '.js-reject-cookies' }],
            else: [
              {
                if: { exists: '#onetrust-pc-btn-handler' },
                then: [{ click: '#onetrust-pc-btn-handler' }],
                else: [{ click: '.ot-sdk-show-settings,button.js-cookie-settings' }],
              },
              { waitFor: '#onetrust-consent-sdk', timeout: 2000, optional: true },
              { wait: 1000 },
              {
                if: { visible: '.ot-pc-refuse-all-handler', check: 'any' },
                then: [{ click: '.ot-pc-refuse-all-handler' }],
                else: [
                  { click: '#onetrust-consent-sdk input.category-switch-handler:checked,.js-editor-toggle-state:checked', all: true, optional: true },
                  { wait: 1000 },
                  { waitForThenClick: '.save-preference-btn-handler,.js-consent-save', timeout: 2000 },
                ],
              },
              { waitForVisible: '#onetrust-banner-sdk', check: 'none', timeout: 5000, optional: true },
            ],
          }],
        }],
      },
    ],
  },
  {
    name: 'Cybotcookiebot',
    detectCmp: [{ exists: '#CybotCookiebotDialog' }],
    detectPopup: [{ visible: '#CybotCookiebotDialog', check: 'any' }],
    optOut: [{
      if: { visible: '#CybotCookiebotDialogBodyLevelButtonLevelOptinDeclineAll' },
      then: [{ click: '#CybotCookiebotDialogBodyLevelButtonLevelOptinDeclineAll' }],
      else: [{
        if: { visible: '#CybotCookiebotDialogBodyButtonDecline' },
        then: [{ click: '#CybotCookiebotDialogBodyButtonDecline' }],
        else: [{ wait: 500 }, { eval: 'EVAL_COOKIEBOT_3' }, { wait: 1000 }, { eval: 'EVAL_COOKIEBOT_4' }],
      }],
    }],
  },
  {
    // The Sourcepoint notice and privacy manager run in their own iframe.
    name: 'Sourcepoint-frame',
    runContext: { main: true, frame: true, urlPattern: '/(index|privacy-manager/index|ccpa_pm/index|us_pm/index)\\.html\\?.*(message_id|requestUUID|consentUUID)=' },
    detectCmp: [{ exists: '.sp_choice_type_11,.sp_choice_type_12,.sp_choice_type_13,.sp_choice_type_ACCEPT_ALL,.sp_choice_type_SAVE_AND_EXIT,.sp_choice_type_SE,.type-modal' }],
    detectPopup: [
      { waitFor: '.sp_choice_type_11,.sp_choice_type_12,.sp_choice_type_13,.sp_choice_type_ACCEPT_ALL,.sp_choice_type_SAVE_AND_EXIT,.sp_choice_type_SE', timeout: 2000 },
      // A paywall ("accept or subscribe") can't be opted out of without breaking the site.
      { exists: '.sp_choice_type_9', negated: true },
    ],
    optOut: [
      { wait: 500 },
      {
        if: { visible: '.sp_choice_type_SE', check: 'any' },
        then: [{ click: '.sp_choice_type_SE' }],
        else: [{
          if: { visible: '.sp_choice_type_13', check: 'any' },
          then: [{ click: '.sp_choice_type_13' }],
          else: [
            { click: '.sp_choice_type_12', optional: true },
            { waitFor: '.type-modal', timeout: 20000 },
            { waitFor: '.sp_choice_type_REJECT_ALL,.reject-toggle,.pm-features', timeout: 3000, optional: true },
            {
              if: { exists: '.sp_choice_type_REJECT_ALL' },
              then: [{ waitForVisible: '.sp_choice_type_REJECT_ALL', timeout: 3000, optional: true }, { click: '.sp_choice_type_REJECT_ALL' }],
              else: [
                { click: '.reject-toggle', optional: true },
                { click: '.pm-features .checked > span', all: true, optional: true },
                { waitForThenClick: '.sp_choice_type_SAVE_AND_EXIT', timeout: 3000 },
              ],
            },
          ],
        }],
      },
    ],
  },
  {
    name: 'TrustArc-top',
    detectCmp: [{ exists: '#truste-show-consent,#truste-consent-track' }],
    detectPopup: [{ visible: '#truste-consent-content,#trustarc-banner-overlay,#truste-consent-track', check: 'any' }],
    optOut: [{
      if: { exists: '#truste-consent-required' },
      then: [{ click: '#truste-consent-required' }],
      else: [
        { hide: '.truste_popframe, .truste_overlay, .truste_box_overlay, #truste-consent-track' },
        { click: '#truste-show-consent' },
        // Newer versions render the preference centre in a shadow root; older ones in an iframe
        // (handled there by the generic rules).
        { waitForThenClick: ['.truste_popframe.trustarc_newcm_container', 'button[data-button-key="decline_all"]'], timeout: 3000, optional: true },
      ],
    }],
  },
  {
    name: 'consentmanager.net',
    detectCmp: [{ exists: '#cmpbox' }],
    detectPopup: [{ visible: '#cmpbox', check: 'any' }],
    optOut: [
      { wait: 500 },
      { eval: 'EVAL_CONSENTMANAGER_3', optional: true },
      {
        if: { exists: '.cmpboxbtnno' },
        then: [{ click: '.cmpboxbtnno' }],
        else: [{
          if: { exists: '.cmpwelcomeprpsbtn' },
          then: [{ click: '.cmpwelcomeprpsbtn > a[aria-checked=true]', all: true, optional: true }, { click: '.cmpboxbtnsave' }],
          else: [
            { click: '.cmpboxbtncustom' },
            { waitFor: '.cmptblbox', timeout: 2000 },
            { click: '.cmptdchoice > a[aria-checked=true]', all: true, optional: true },
            { click: '.cmpboxbtnyescustomchoices' },
            { hide: '#cmpwrapper,#cmpbox' },
          ],
        }],
      },
    ],
  },
  {
    name: 'Evidon',
    detectCmp: [{ exists: '#_evidon_banner, #_evidon-barrier-wrapper' }],
    detectPopup: [{ visible: '#_evidon_banner, #_evidon-barrier-wrapper #_evidon-banner', check: 'any' }],
    optOut: [{
      if: { exists: '#_evidon-decline-button, #_evidon-barrier-declinebutton, #_evidon_banner #RejectLink' },
      then: [{ click: '#_evidon-decline-button, #_evidon-barrier-declinebutton, #_evidon_banner #RejectLink' }],
      else: [
        { hide: '#evidon-prefdiag-overlay,#evidon-prefdiag-background,#_evidon-background' },
        { waitForThenClick: '#_evidon-option-button' },
        { waitFor: '#evidon-prefdiag-overlay', timeout: 5000 },
        { wait: 500 },
        { waitForThenClick: '#evidon-prefdiag-decline' },
      ],
    }],
  },
  {
    name: 'Klaro',
    detectCmp: [{ exists: '.klaro > .cookie-notice,.klaro > .cookie-modal' }],
    detectPopup: [{ visible: '.klaro > .cookie-notice,.klaro > .cookie-modal', check: 'any' }],
    optOut: [{
      any: [
        { eval: 'EVAL_KLARO_TRY_API_OPT_OUT' },
        { click: '.klaro .cn-decline' },
        {
          if: { exists: '.klaro' },
          then: [
            { eval: 'EVAL_KLARO_OPEN_POPUP', optional: true },
            { wait: 500 },
            {
              any: [
                { click: '.klaro .cn-decline' },
                {
                  if: { exists: '.cm-purpose' },
                  then: [
                    // Only switch off what's on: clicking an unchecked purpose would switch it on.
                    { click: '.cm-purpose:not(.cm-toggle-all) > input:checked:not(.half-checked,.required,.only-required),.cm-purpose:not(.cm-toggle-all) > div > input:checked:not(.half-checked,.required,.only-required)', all: true, optional: true },
                    { click: '.cm-btn-accept:not(.cm-btn-accept-all),.cm-button' },
                  ],
                },
              ],
            },
          ],
        },
      ],
    }],
  },
  {
    name: 'Uniconsent',
    detectCmp: [{ exists: '.unic .unic-box,.unic .unic-bar,.unic .unic-modal' }],
    detectPopup: [{ visible: '.unic .unic-box,.unic .unic-bar,.unic .unic-modal', check: 'any' }],
    optOut: [
      { waitFor: '.unic button', timeout: 1000 },
      { click: "xpath///*[contains(@class,'unic')]//button[contains(., 'Manage Options') or contains(., 'Optionen verwalten')]", optional: true },
      { waitFor: '.unic input[type=checkbox]', timeout: 1000 },
      { click: '.unic input[type=checkbox]:checked', all: true, optional: true },
      { waitForThenClick: "xpath///*[contains(@class,'unic')]//button[contains(., 'Confirm Choices') or contains(., 'Save Choices') or contains(., 'Auswahl speichern')]", timeout: 1000 },
      { wait: 500 },
    ],
  },
  {
    name: 'Conversant',
    detectCmp: [{ exists: '.cmp-root .cmp-receptacle' }],
    detectPopup: [{ visible: '.cmp-root .cmp-receptacle', check: 'any' }],
    optOut: [
      { waitForThenClick: '.cmp-main-button:not(.cmp-main-button--primary)' },
      { waitFor: '.cmp-view-tab-tabs' },
      { waitForThenClick: '.cmp-view-tab-tabs > :first-child' },
      { click: '.cmp-accordion-item-title', all: true, optional: true },
      { wait: 500 },
      { click: '.cmp-toggle-actions .cmp-toggle-deny:not(.cmp-toggle-deny--active)', all: true, optional: true },
      { click: '.cmp-toggle-actions .cmp-toggle-checkbox:not(.cmp-toggle-checkbox--active)', all: true, optional: true },
      { click: '.cmp-main-button:not(.cmp-main-button--primary)' },
    ],
  },
  {
    name: 'tiktok.com',
    detectCmp: [{ exists: 'tiktok-cookie-banner' }],
    detectPopup: [{ visible: ['tiktok-cookie-banner', '.tiktok-cookie-banner'] }],
    optOut: [{ click: ['tiktok-cookie-banner', '.button-wrapper button:first-child'] }],
  },
  {
    // DPG Media (nu.nl, ad.nl, volkskrant.nl, trouw.nl, tweakers.net, ...), on myprivacy.dpgmedia.*.
    // autoconsent's "dpgmedia-nl" rule still uses the old shadow host id.
    name: 'DPG Media',
    detectCmp: [{ any: [{ exists: '#pg-dom-shadow-host' }, { exists: '#pg-shadow-host-dom' }] }],
    detectPopup: [{ any: [{ visible: ['#pg-dom-shadow-host', '#pg-modal'] }, { visible: ['#pg-shadow-host-dom', '#pg-modal'] }] }],
    optOut: [{
      if: { exists: '#pg-dom-shadow-host' },
      then: [
        { waitForThenClick: ['#pg-dom-shadow-host', '#pg-configure-btn'], timeout: 3000 },
        { waitForThenClick: ['#pg-dom-shadow-host', '#pg-reject-btn'], timeout: 3000 },
      ],
      else: [
        { waitForThenClick: ['#pg-shadow-host-dom', '#pg-configure-btn'], timeout: 3000 },
        { waitForThenClick: ['#pg-shadow-host-dom', '#pg-reject-btn'], timeout: 3000 },
      ],
    }],
  },
  {
    // MediaMarkt / Saturn: purposes are accordions with the real checkboxes inside one form.
    name: 'MediaMarkt',
    detectCmp: [{ exists: '#pwa-consent-layer-accept-all-button' }],
    detectPopup: [{ visible: '#pwa-consent-layer-accept-all-button' }],
    optOut: [
      { click: '#pwa-consent-layer-form input[type=checkbox]:checked:not(:disabled)', all: true, optional: true },
      { waitForThenClick: '[data-test="pwa-consent-layer-save-settings"]', timeout: 3000 },
    ],
  },
  {
    // Sites that build their own banner on Cookiebot, often with only "Allow all" (e.g. shoeby.nl):
    // withdraw consent through Cookiebot's API instead.
    name: 'Cookiebot (custom banner)',
    detectCmp: [{ exists: '#CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll' }, { exists: '#CybotCookiebotDialog', negated: true }],
    detectPopup: [{ visible: '#CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll' }],
    optOut: [{ eval: 'EVAL_COOKIEBOT_3' }, { wait: 500 }, { eval: 'EVAL_COOKIEBOT_4', optional: true }],
  },
  {
    name: 'Admiral',
    detectCmp: [{ exists: 'div > div[class*=Card] > div[class*=Frame] > div[class*=Pills] > button[class*=Pills__StyledPill]' }],
    detectPopup: [{ visible: 'div > div[class*=Card] > div[class*=Frame] > div[class*=Pills] > button[class*=Pills__StyledPill]', check: 'any' }],
    optOut: [{
      if: { exists: "xpath///button[contains(., 'Afvis alle') or contains(., 'Reject all') or contains(., 'Odbaci sve') or contains(., 'Rechazar todo') or contains(., 'Atmesti visus') or contains(., 'Odmítnout vše') or contains(., 'Rejeitar tudo') or contains(., 'Tümünü reddet') or contains(., 'Avvisa alla') or contains(., 'Odrzuć wszystkie') or contains(., 'Alles afwijzen') or contains(., 'Rifiuta tutto') or contains(., 'Alles ablehnen') or contains(., 'Tout rejeter') or contains(., 'Hylkää kaikki')]" },
      then: [{ waitForThenClick: "xpath///button[not(@disabled)][contains(., 'Afvis alle') or contains(., 'Reject all') or contains(., 'Odbaci sve') or contains(., 'Rechazar todo') or contains(., 'Atmesti visus') or contains(., 'Odmítnout vše') or contains(., 'Rejeitar tudo') or contains(., 'Tümünü reddet') or contains(., 'Avvisa alla') or contains(., 'Odrzuć wszystkie') or contains(., 'Alles afwijzen') or contains(., 'Rifiuta tutto') or contains(., 'Alles ablehnen') or contains(., 'Tout rejeter') or contains(., 'Hylkää kaikki')]", timeout: 2000 }],
      else: [
        { waitForThenClick: "xpath///button[contains(., 'Purposes') or contains(., 'Zwecke') or contains(., 'Doeleinden') or contains(., 'Finalités') or contains(., 'Finalidades') or contains(., 'Scopi') or contains(., 'Ändamål') or contains(., 'Formål') or contains(., 'Tarkoitukset') or contains(., 'Cele')]" },
        { waitForVisible: "xpath///button[contains(., 'Save & exit') or contains(., 'Speichern & Verlassen') or contains(., 'Opslaan & afsluiten') or contains(., 'Enregistrer et quitter') or contains(., 'Guardar y salir') or contains(., 'Salva ed esci') or contains(., 'Spara & avsluta') or contains(., 'Gem & afslut') or contains(., 'Tallenna ja poistu') or contains(., 'Zapisz & zakończ')]" },
        { click: 'div[class*=Card] input[type=checkbox]:checked', all: true, optional: true },
        { click: "xpath///button[contains(., 'Save & exit') or contains(., 'Speichern & Verlassen') or contains(., 'Opslaan & afsluiten') or contains(., 'Enregistrer et quitter') or contains(., 'Guardar y salir') or contains(., 'Salva ed esci') or contains(., 'Spara & avsluta') or contains(., 'Gem & afslut') or contains(., 'Tallenna ja poistu') or contains(., 'Zapisz & zakończ')]" },
      ],
    }],
  },
];
