const $ = (id) => document.getElementById(id);

function hostOf(url) {
  try {
    const { protocol, hostname } = new URL(url);
    return /^https?:$/.test(protocol) ? normalizeHost(hostname) : null;
  } catch {
    return null;
  }
}

function describe({ cmp, method }) {
  const banner = cmp ? `the ${cmp} banner` : 'a cookie banner';
  if (method === 'preferences') return `Switched off every purpose, vendor and legitimate interest in ${banner}.`;
  if (method === 'hidden') return `Hid ${banner} (it had no reject option).`;
  return `Rejected ${banner} on this page.`;
}

async function save(changes) {
  await chrome.storage.sync.set(changes);
  $('hint').hidden = false;
}

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const host = hostOf(tab?.url);
  const settings = await chrome.storage.sync.get(COOKIE_DENIER_DEFAULTS);

  $('enabled').checked = settings.enabled;
  $('thorough').checked = settings.thorough;
  $('hideFallback').checked = settings.hideFallback;
  if (host) {
    $('site').textContent = host;
    $('siteEnabled').checked = !isSiteDisabled(host, settings.disabledSites);
  } else {
    $('siteRow').hidden = true;
  }

  $('enabled').addEventListener('change', (e) => save({ enabled: e.target.checked }));
  $('thorough').addEventListener('change', (e) => save({ thorough: e.target.checked }));
  $('hideFallback').addEventListener('change', (e) => save({ hideFallback: e.target.checked }));
  $('siteEnabled').addEventListener('change', async (e) => {
    const { disabledSites } = await chrome.storage.sync.get(COOKIE_DENIER_DEFAULTS);
    const others = disabledSites.filter((site) => !isSiteDisabled(host, [site]));
    save({ disabledSites: e.target.checked ? others : [...others, host] });
  });

  const { total } = await chrome.storage.local.get({ total: 0 });
  $('total').textContent = total;

  const key = `tab_${tab?.id}`;
  const result = (await chrome.storage.session.get(key))[key];
  if (result) $('status').textContent = describe(result);
}

init();
