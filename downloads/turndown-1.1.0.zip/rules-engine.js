// Runs consent rules written in DuckDuckGo's autoconsent format (vendor/autoconsent, extra-rules.js).
// The background script says which rules apply to this page. Here we check their cheap "probe"
// selectors, and for rules whose banner is present we wait for the popup and run the opt-out steps.
// Step semantics follow autoconsent's docs/rule-syntax.md and lib/cmps/base.ts.
const CookieDenierRules = (() => {
  'use strict';

  const isTop = window === window.top;
  const COOLDOWN_MS = 3000;      // a rule whose popup didn't show may be tried again after this long
  const MAX_ATTEMPTS = 3;
  const POPUP_CHECKS = 10;       // as autoconsent: look for the popup up to 10 times, 500 ms apart
  const POPUP_INTERVAL_MS = 500;
  const GATE_CHUNK = 60;         // probes combined per quick "is anything here?" selector
  const VERIFY_AFTER_MS = 1500;  // after an opt-out, how long the popup gets to disappear

  let pageRules = [];            // [{ id, probes, cosmetic }] in priority order
  let gates = [];                // combined CSS probes; if none match, rules made of them can be skipped
  let gated = new Set();         // probes covered by the gates
  const fullRules = new Map();   // id -> rule
  const attempts = new Map();    // id -> { count, at }

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const isXPath = (selector) => selector.startsWith('xpath/');

  async function safely(fn) {
    try {
      return await fn();
    } catch {
      return false;
    }
  }

  function isValidCss(selector) {
    try {
      document.createDocumentFragment().querySelector(selector);
      return true;
    } catch {
      return false;
    }
  }

  async function load() {
    try {
      pageRules = (await chrome.runtime.sendMessage({ type: 'rules:forPage', url: location.href, top: isTop })) || [];
    } catch {
      pageRules = [];
    }
    // A selector with an unclosed bracket works alone but breaks a combined list, so check both.
    const css = [...new Set(pageRules.flatMap((rule) => rule.probes))]
      .filter((p) => !isXPath(p) && isValidCss(p) && isValidCss(`${p}, x-cookie-denier`));
    gated = new Set(css);
    gates = [];
    for (let i = 0; i < css.length; i += GATE_CHUNK) gates.push(css.slice(i, i + GATE_CHUNK).join(', '));
    return pageRules.length;
  }

  function probeMatches(probe) {
    try {
      if (isXPath(probe)) {
        return !!document.evaluate(probe.slice(6), document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
      }
      return !!document.querySelector(probe);
    } catch {
      return false;
    }
  }

  // Rules whose banner seems to be on the page. Cosmetic rules (which only hide) are asked for separately.
  function candidates(cosmetic) {
    const now = Date.now();
    const gateHit = gates.some(probeMatches);
    return pageRules.filter((rule) => {
      if (rule.cosmetic !== cosmetic) return false;
      const tried = attempts.get(rule.id);
      if (tried && (tried.count >= MAX_ATTEMPTS || now - tried.at < COOLDOWN_MS)) return false;
      if (!rule.probes.length) return true;
      if (!gateHit && rule.probes.every((p) => gated.has(p))) return false;
      return rule.probes.some(probeMatches);
    });
  }

  async function getRules(ids) {
    const missing = ids.filter((id) => !fullRules.has(id));
    if (missing.length) {
      const rules = (await safely(() => chrome.runtime.sendMessage({ type: 'rules:get', ids: missing }))) || [];
      missing.forEach((id, i) => fullRules.set(id, rules[i] || null));
    }
    return ids.map((id) => fullRules.get(id)).filter(Boolean);
  }

  // Detects which candidate's popup is showing and opts out of it. Returns the rule, or null if no
  // rule worked. `onOptedOut(rule)` is called as soon as the opt-out steps succeed, before checking
  // that the popup went: many sites reload right after a refusal, which would lose a later report.
  async function run(list, onOptedOut = () => {}, onOptOutStart = () => {}) {
    for (const { id } of list) {
      const tried = attempts.get(id);
      attempts.set(id, { count: (tried?.count || 0) + 1, at: Date.now() });
    }
    const detected = [];
    for (const rule of await getRules(list.map((r) => r.id))) {
      if (await safely(() => runSteps(rule.detectCmp))) detected.push(rule);
    }
    for (let check = 0; detected.length && check < POPUP_CHECKS; check++) {
      for (const rule of detected) {
        if (!(await safely(() => runSteps(rule.detectPopup)))) continue;
        // Whatever happens, don't run this rule's opt-out again.
        const id = list.find((r) => fullRules.get(r.id) === rule)?.id;
        if (id !== undefined) attempts.set(id, { count: MAX_ATTEMPTS, at: Date.now() });
        onOptOutStart(rule);
        if (!(await safely(() => runSteps(rule.optOut)))) return null;
        onOptedOut(rule);
        // A rule can be out of date and "succeed" while the popup stays: then it didn't work.
        if (!rule.cosmetic) {
          await sleep(VERIFY_AFTER_MS);
          if (isVisibleNow(rule.detectPopup)) return null;
        }
        return rule;
      }
      await sleep(POPUP_INTERVAL_MS);
    }
    return null;
  }

  // Whether the popup is really still on screen, from the plain "visible" checks in its detection
  // steps. Stricter than isElementVisible(), which counts a fixed element inside a hidden parent.
  function isVisibleNow(steps) {
    const checks = (steps || []).flatMap((step) => (step.any ? step.any : [step])).filter((step) => step.visible && !step.negated);
    const rendered = (el) => {
      const rect = el.getBoundingClientRect();
      const style = (el.ownerDocument?.defaultView || window).getComputedStyle(el);
      return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && parseFloat(style.opacity) > 0;
    };
    return checks.some((step) => select(step.visible).some(rendered));
  }

  // --- Rule steps --------------------------------------------------------------

  async function runSteps(steps) {
    for (const step of steps || []) {
      if (!(await evaluate(step)) && !step.optional) return false;
    }
    return true;
  }

  async function evaluate(step) {
    const results = [];
    if (step.exists) results.push(select(step.exists).length > 0);
    if (step.visible) results.push(isVisible(step.visible, step.check));
    if (step.eval) results.push(runSnippet(step.eval));
    if (step.waitFor) results.push(waitFor(() => select(step.waitFor).length > 0, step.timeout));
    if (step.waitForVisible) results.push(waitFor(() => isVisible(step.waitForVisible, step.check || 'any'), step.timeout));
    if (step.click) results.push(click(step.click, step.all));
    if (step.waitForThenClick) results.push(waitForThenClick(step));
    if (step.wait) results.push(sleep(step.wait).then(() => true));
    if (step.hide) results.push(addCss(`${step.hide} { ${hidingStyle(step.method)} }`));
    if (step.stylesheet !== undefined) results.push(addCss(step.stylesheet, step.stylesheetId));
    if (step.removeClass !== undefined) results.push(forEachMatch(step.selector, (el) => el.classList.remove(step.removeClass)));
    if (step.setStyle !== undefined) results.push(forEachMatch(step.selector, (el) => { el.style.cssText = step.setStyle; }));
    if (step.addStyle !== undefined) results.push(forEachMatch(step.selector, (el) => { el.style.cssText += '; ' + step.addStyle; }));
    if (step.cookieContains) results.push(document.cookie.includes(step.cookieContains));
    if (step.if) {
      if ((!step.if.exists && !step.if.visible) || !step.then) return false;
      const condition = await evaluate(step.if);
      results.push(condition ? runSteps(step.then) : step.else ? runSteps(step.else) : true);
    }
    if (step.any) {
      let anyPassed = false;
      for (const option of step.any) {
        if (await evaluate(option)) {
          anyPassed = true;
          break;
        }
      }
      results.push(anyPassed);
    }
    // An unknown step type fails, and can't be negated into a pass.
    if (!results.length) return false;
    const passed = (await Promise.all(results)).every(Boolean);
    return step.negated ? !passed : passed;
  }

  function shadowRootOf(el) {
    try {
      return el.shadowRoot || chrome.dom?.openOrClosedShadowRoot?.(el) || null;
    } catch {
      return el.shadowRoot || null;
    }
  }

  // One selector, searched inside `parent` (its shadow root or same-origin iframe document if it has one).
  function querySingle(selector, parent) {
    if (/^(aria|text|pierce)\//.test(selector)) return [];
    try {
      if (isXPath(selector)) {
        const result = document.evaluate(selector.slice(6), parent, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
        return Array.from({ length: result.snapshotLength }, (_, i) => result.snapshotItem(i));
      }
      let root = parent;
      if (parent.nodeType === Node.ELEMENT_NODE) root = shadowRootOf(parent) || parent.contentDocument || parent;
      return Array.from(root.querySelectorAll(selector));
    } catch {
      return [];
    }
  }

  // A string selector, or an array where each selector searches inside the first match of the previous.
  function select(selector) {
    if (typeof selector === 'string') return querySingle(selector, document);
    let parent = document;
    let matches = [];
    for (const part of selector) {
      matches = querySingle(part, parent);
      if (!matches.length) return [];
      parent = matches[0];
    }
    return matches;
  }

  function isElementVisible(el) {
    if (!el) return false;
    if (el.offsetParent !== null && el.offsetParent !== undefined) return true;
    const style = (el.ownerDocument?.defaultView || window).getComputedStyle(el);
    // A fixed element inside a hidden parent has no boxes (autoconsent's check misses that).
    return style.position === 'fixed' && style.display !== 'none' && el.getClientRects().length > 0;
  }

  function isVisible(selector, check = 'all') {
    const results = select(selector).map(isElementVisible);
    if (check === 'none') return results.every((visible) => !visible);
    if (!results.length) return false;
    return check === 'any' ? results.some(Boolean) : results.every(Boolean);
  }

  async function waitFor(predicate, timeout = 10000, interval = 200) {
    const deadline = Date.now() + timeout;
    for (;;) {
      if (await predicate()) return true;
      if (Date.now() >= deadline) return false;
      await sleep(interval);
    }
  }

  function clickElement(el) {
    // SVG elements have no click() method.
    if (typeof el.click === 'function') el.click();
    else el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
  }

  async function click(selector, all = false) {
    const elements = select(selector);
    if (!elements.length) return false;
    if (!all) {
      clickElement(elements[0]);
      return true;
    }
    for (const el of elements) {
      clickElement(el);
      // Let the page handle each click: back-to-back clicks can overwrite each other's state.
      await sleep(0);
    }
    return true;
  }

  async function waitForThenClick(step) {
    const selector = step.waitForThenClick;
    await waitFor(() => select(selector).length > 0, step.timeout);
    let clicked = await click(selector, step.all);
    // Some banners add a button before its click handler: if it's still there, click again.
    for (let attempt = 0; clicked && attempt < (step.retry || 0); attempt++) {
      const gone = await waitFor(() => !isVisible(selector, 'any'), step.retryInterval ?? 300, 50);
      if (gone) break;
      clicked = await click(selector, step.all);
    }
    return clicked;
  }

  function forEachMatch(selector, fn) {
    if (!selector) return false;
    const elements = select(selector);
    elements.forEach(fn);
    return elements.length > 0;
  }

  const hidingStyle = (method) =>
    `${method === 'opacity' ? 'opacity: 0' : 'display: none'} !important; z-index: -1 !important; pointer-events: none !important;`;

  function addCss(css, marker) {
    if (!css) return false;
    let style = document.getElementById('cookie-denier-css');
    if (!style) {
      style = document.createElement('style');
      style.id = 'cookie-denier-css';
      (document.head || document.documentElement).appendChild(style);
    }
    const key = marker ? `/* ${marker} */` : css.trim();
    if (!style.textContent.includes(key)) style.textContent += `${marker ? key + ' ' : ''}${css}\n`;
    return true;
  }

  function runSnippet(name) {
    return chrome.runtime.sendMessage({ type: 'rules:eval', snippet: name }).then(Boolean, () => false);
  }

  return { load, candidates, run };
})();
