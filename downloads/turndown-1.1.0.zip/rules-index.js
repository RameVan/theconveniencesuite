// Indexes consent rules (autoconsent format) for the background script: which rules may run on a
// page, and the cheap "probe" selectors a page checks before asking for a rule's full steps.

const firstSelector = (selector) => (Array.isArray(selector) ? selector[0] : selector);

// Selectors from a rule's detection steps that must be on the page for the rule to apply.
function probesOf(steps, out = []) {
  for (const step of steps || []) {
    if (step.negated) continue;
    for (const key of ['exists', 'visible', 'waitFor', 'waitForVisible']) {
      if (step[key]) out.push(firstSelector(step[key]));
    }
    if (step.any) probesOf(step.any, out);
  }
  return out;
}

function buildRuleIndex(rules) {
  return rules.map((rule, id) => {
    let pattern = null;
    if (rule.runContext?.urlPattern) {
      try {
        pattern = new RegExp(rule.runContext.urlPattern);
      } catch {
        pattern = /(?!)/; // never matches
      }
    }
    return {
      id,
      rule,
      pattern,
      main: rule.runContext?.main ?? true,
      frame: rule.runContext?.frame ?? false,
      probes: [...new Set(probesOf(rule.detectCmp))],
    };
  });
}

// Rules that may run in a frame at `url`; site-specific ones first, as autoconsent does.
function rulesForPage(index, url, isTop) {
  const siteSpecific = [];
  const generic = [];
  for (const entry of index) {
    if (isTop ? !entry.main : !entry.frame) continue;
    if (!entry.pattern) generic.push(entry);
    else if (entry.pattern.test(url)) siteSpecific.push(entry);
  }
  return [...siteSpecific, ...generic].map((entry) => ({
    id: entry.id,
    probes: entry.probes,
    cosmetic: !!entry.rule.cosmetic,
  }));
}
