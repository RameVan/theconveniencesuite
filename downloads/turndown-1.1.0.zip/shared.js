// Settings shared by the content script and the popup.
const COOKIE_DENIER_DEFAULTS = {
  enabled: true,
  thorough: true,     // on vendor / "legitimate interest" banners, refuse everything in the preferences
  hideFallback: true, // hide known banners that offer no way to reject
  disabledSites: [],  // hostnames (without "www.") where the extension does nothing
};

function normalizeHost(host) {
  return (host || '').toLowerCase().replace(/^www\./, '');
}

// "example.com" in the list also covers its subdomains.
function isSiteDisabled(host, disabledSites) {
  host = normalizeHost(host);
  return disabledSites.some((site) => host === site || host.endsWith('.' + site));
}
