// Loads the extension into throwaway headless Chrome profiles, visits each site, and records what
// the extension did (from its background state) and any banner-like overlay still visible.
//
// Usage: node tools/check-sites.mjs [options] [<url> ...]
//   --file <path>         read URLs from a file (one per line), in addition to any given
//   --out <dir>           where results.jsonl, summary.txt and screenshots go
//   --wait <seconds>      time the extension gets on each page (default 12)
//   --parallel <n>        browsers visiting sites at the same time (default 1)
//   --screenshots <mode>  all | issues (default: only sites with a banner left or an error) | none
//   --no-extension        baseline run without the extension
//   --eval <expression>   evaluated in each page at the end (for investigating a banner)
//   --debug               log what the extension does on each page (its [Turndown] console messages)
//   --resume              keep the results already in --out and visit only the sites not in them
// Needs Chrome installed; set CHROME_PATH if it isn't in the default location.
import { spawn } from 'node:child_process';
import { appendFile, mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { StringDecoder } from 'node:string_decoder';
import { fileURLToPath } from 'node:url';

const args = process.argv.slice(2);
const option = (name, fallback) => {
  const i = args.indexOf(name);
  return i >= 0 ? args.splice(i, 2)[1] : fallback;
};
const flag = (name) => {
  const i = args.indexOf(name);
  return i >= 0 && !!args.splice(i, 1);
};
const outDir = resolve(option('--out', join(tmpdir(), 'cookie-denier-check')));
const waitMs = Number(option('--wait', 12)) * 1000;
const parallel = Math.max(1, Number(option('--parallel', 1)));
const screenshots = option('--screenshots', 'issues');
const inspect = option('--eval', null);
const listFile = option('--file', null);
const withExtension = !flag('--no-extension');
const resume = flag('--resume');
const debug = flag('--debug');
const urls = [...args];
if (listFile) urls.push(...(await readFile(listFile, 'utf8')).split(/\r?\n/).map((l) => l.trim()).filter(Boolean));

const extDir = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const chromePath = process.env.CHROME_PATH || 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const RESTART_EVERY = 100;           // fresh browser now and then, so one bad site can't slow the rest
const VISIT_TIMEOUT_MS = waitMs + 45000;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

if (!urls.length) {
  console.error('Usage: node tools/check-sites.mjs [--file <path>] [--parallel <n>] [--out <dir>] [--wait <seconds>] <url> ...');
  process.exit(1);
}

// --- Minimal DevTools protocol client over --remote-debugging-pipe ----------------

class Browser {
  async launch() {
    this.profile = await mkdtemp(join(tmpdir(), 'cookie-denier-profile-'));
    this.pending = new Map();
    this.logs = {};
    this.nextId = 1;
    this.proc = spawn(chromePath, [
      '--headless=new',
      '--remote-debugging-pipe',
      '--enable-unsafe-extension-debugging',
      `--user-data-dir=${this.profile}`,
      '--no-first-run',
      '--no-default-browser-check',
      '--mute-audio',
      '--window-size=1280,900',
      `--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36${debug ? ' TurndownDebug' : ''}`,
      'about:blank',
    ], { stdio: ['ignore', 'ignore', 'ignore', 'pipe', 'pipe'] });
    const decoder = new StringDecoder('utf8');
    let buffer = '';
    this.proc.stdio[4].on('data', (chunk) => {
      buffer += decoder.write(chunk);
      let end;
      while ((end = buffer.indexOf('\0')) >= 0) {
        const msg = JSON.parse(buffer.slice(0, end));
        buffer = buffer.slice(end + 1);
        if (msg.method === 'Runtime.consoleAPICalled' && msg.sessionId) {
          const text = msg.params.args.map((a) => a.value ?? a.description ?? '').join(' ');
          if (text.startsWith('[Turndown]')) (this.logs[msg.sessionId] ||= []).push(text.slice(11));
        }
        const waiter = msg.id && this.pending.get(msg.id);
        if (!waiter) continue;
        this.pending.delete(msg.id);
        msg.error ? waiter.reject(new Error(msg.error.message)) : waiter.resolve(msg.result);
      }
    });
    this.proc.stdio[3].on('error', () => {});
    this.extensionId = withExtension ? (await this.send('Extensions.loadUnpacked', { path: extDir })).id : null;
  }

  send(method, params = {}, sessionId) {
    const id = this.nextId++;
    this.proc.stdio[3].write(JSON.stringify({ id, method, params, sessionId }) + '\0');
    return new Promise((resolvePromise, reject) => {
      this.pending.set(id, { resolve: resolvePromise, reject });
      setTimeout(() => this.pending.has(id) && (this.pending.delete(id), reject(new Error(`${method} timed out`))), 30000);
    });
  }

  async evaluate(sessionId, expression) {
    const { result, exceptionDetails } = await this.send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true }, sessionId);
    if (exceptionDetails) throw new Error(exceptionDetails.exception?.description || exceptionDetails.text);
    return result.value;
  }

  async recentReports() {
    if (!this.extensionId) return [];
    const { targetInfos } = await this.send('Target.getTargets');
    const worker = targetInfos.find((t) => t.type === 'service_worker' && t.url.startsWith(`chrome-extension://${this.extensionId}/`));
    if (!worker) return [];
    const { sessionId } = await this.send('Target.attachToTarget', { targetId: worker.targetId, flatten: true });
    const { recent = [] } = await this.evaluate(sessionId, "chrome.storage.session.get('recent')");
    await this.send('Target.detachFromTarget', { sessionId }).catch(() => {});
    return recent;
  }

  async close() {
    // Killing only the main process can leave Chrome's helpers running on Windows; end the whole tree.
    if (this.proc?.pid && process.platform === 'win32') {
      await new Promise((r) => spawn('taskkill', ['/pid', String(this.proc.pid), '/T', '/F'], { stdio: 'ignore' }).on('exit', r).on('error', r));
    } else {
      this.proc?.kill();
    }
    await sleep(500);
    await rm(this.profile, { recursive: true, force: true }).catch(() => {});
  }
}

// Banner-like overlays still on screen: fixed/sticky elements (also inside open shadow roots) that
// mention cookies or consent, and large consent iframes.
const LEFTOVER_BANNERS = `(() => {
  const words = /cookie|consent|privacy|gdpr|toestemming|einwilligung|datenschutz|confidentialit|privacidad/i;
  const consentFrames = /consent|cookie|privacy|cmp|sourcepoint|privacy-mgmt|sp-prod|trustarc|didomi|onetrust|usercentrics/i;
  const found = [];
  const scopes = [document];
  for (let i = 0; i < scopes.length && found.length < 3; i++) {
    for (const el of scopes[i].querySelectorAll('*')) {
      if (el.shadowRoot) scopes.push(el.shadowRoot);
      const style = getComputedStyle(el);
      if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) continue;
      const rect = el.getBoundingClientRect();
      if (rect.width < 200 || rect.height < 40 || rect.bottom <= 0 || rect.top >= innerHeight) continue;
      if (el.tagName === 'IFRAME') {
        if (consentFrames.test(el.src + ' ' + el.id + ' ' + el.title)) found.push('iframe ' + (el.id || el.src.slice(0, 80)));
        continue;
      }
      if (style.position !== 'fixed' && style.position !== 'sticky') continue;
      const text = (el.innerText || el.textContent || '').trim();
      if (!words.test(text + ' ' + el.id + ' ' + el.className)) continue;
      found.push((el.id ? '#' + el.id : el.tagName.toLowerCase() + '.' + String(el.className).split(' ')[0]) + ': ' + text.replace(/\\s+/g, ' ').slice(0, 90));
      if (found.length >= 3) break;
    }
  }
  return found;
})()`;

// --- Run --------------------------------------------------------------------------

async function visit(browser, url) {
  const entry = { url };
  let targetId;
  try {
    ({ targetId } = await browser.send('Target.createTarget', { url: 'about:blank' }));
    const { sessionId } = await browser.send('Target.attachToTarget', { targetId, flatten: true });
    await browser.send('Page.enable', {}, sessionId);
    if (debug) await browser.send('Runtime.enable', {}, sessionId);
    const startedAt = Date.now() - 1000;
    await browser.send('Page.navigate', { url }, sessionId);
    await sleep(waitMs);
    entry.finalUrl = await browser.evaluate(sessionId, 'location.href').catch(() => null);
    entry.handled = (await browser.recentReports().catch(() => [])).find((r) => r.at >= startedAt) || null;
    entry.leftover = await browser.evaluate(sessionId, LEFTOVER_BANNERS).catch(() => ['(could not check)']);
    if (debug) entry.log = browser.logs[sessionId] || [];
    if (inspect) entry.inspected = await browser.evaluate(sessionId, inspect).catch((e) => `error: ${e.message}`);
    if (screenshots === 'all' || (screenshots === 'issues' && entry.leftover.length)) {
      const { data } = await browser.send('Page.captureScreenshot', { format: 'jpeg', quality: 50 }, sessionId);
      await writeFile(join(outDir, `${new URL(url).hostname}.jpg`), Buffer.from(data, 'base64'));
    }
  } catch (e) {
    entry.error = e.message;
  } finally {
    if (targetId) await browser.send('Target.closeTarget', { targetId }).catch(() => {});
  }
  return entry;
}

function describe(entry) {
  if (entry.error) return `ERROR ${entry.error}`;
  const what = entry.handled ? `${entry.handled.method} (${entry.handled.cmp ?? 'generic'})` : 'nothing handled';
  return what + (entry.leftover?.length ? `  | still visible: ${entry.leftover.join(' || ')}` : '');
}

await mkdir(outDir, { recursive: true });
const resultsFile = join(outDir, 'results.jsonl');
const results = [];
if (resume) {
  const done = await readFile(resultsFile, 'utf8').catch(() => '');
  results.push(...done.split('\n').filter(Boolean).map((l) => JSON.parse(l)));
  const visited = new Set(results.map((r) => r.url));
  urls.splice(0, urls.length, ...urls.filter((u) => !visited.has(u)));
} else {
  await writeFile(resultsFile, '');
}
const total = results.length + urls.length;
let next = 0;

async function worker() {
  let browser = null;
  let visits = 0;
  while (next < urls.length) {
    const url = urls[next++];
    if (!browser || visits >= RESTART_EVERY) {
      await browser?.close();
      // Under heavy load Chrome sometimes takes too long to start; try again rather than end the run.
      for (let attempt = 1; ; attempt++) {
        browser = new Browser();
        try {
          await browser.launch();
          break;
        } catch (err) {
          await browser.close();
          if (attempt >= 5) throw err;
          console.error(`Browser failed to start (${err.message}), retrying`);
          await sleep(5000 * attempt);
        }
      }
      visits = 0;
    }
    visits++;
    let entry = await Promise.race([
      visit(browser, url),
      sleep(VISIT_TIMEOUT_MS).then(() => ({ url, error: 'visit timed out' })),
    ]);
    if (entry.error === 'visit timed out' || /closed|not attached|timed out/i.test(entry.error || '')) {
      // The browser may be stuck: start a fresh one for the next site.
      await browser.close();
      browser = null;
    }
    results.push(entry);
    await appendFile(resultsFile, JSON.stringify(entry) + '\n');
    console.log(`[${results.length}/${total}] ${new URL(url).hostname.padEnd(32)} ${describe(entry)}`);
    if (debug) console.log(entry.log.map((l) => '    ' + l).join('\n'));
    if (inspect) console.log(typeof entry.inspected === 'string' ? entry.inspected : JSON.stringify(entry.inspected, null, 1));
  }
  await browser?.close();
}

await Promise.all(Array.from({ length: Math.min(parallel, urls.length) }, worker));

// --- Summary ----------------------------------------------------------------------

const count = (test) => results.filter(test).length;
const byMethod = (m) => count((r) => r.handled?.method === m);
const lines = [
  `Sites visited:                 ${results.length}`,
  `Errors / timeouts:             ${count((r) => r.error)}`,
  `Banner handled:                ${count((r) => r.handled)}  (rejected ${byMethod('reject')}, preferences ${byMethod('preferences')}, hidden ${byMethod('hidden')})`,
  `  ...but something still shown: ${count((r) => r.handled && r.leftover?.length)}`,
  `Nothing handled, banner shown: ${count((r) => !r.error && !r.handled && r.leftover?.length)}`,
  `Nothing handled, none shown:   ${count((r) => !r.error && !r.handled && !r.leftover?.length)}`,
  '',
  'Handled by:',
  ...Object.entries(results.reduce((acc, r) => {
    if (r.handled) acc[r.handled.cmp ?? 'generic'] = (acc[r.handled.cmp ?? 'generic'] || 0) + 1;
    return acc;
  }, {})).sort((a, b) => b[1] - a[1]).map(([name, n]) => `  ${String(n).padStart(4)}  ${name}`),
];
await writeFile(join(outDir, 'summary.txt'), lines.join('\n') + '\n');
console.log('\n' + lines.join('\n'));
console.log(`\nResults in ${outDir}`);
