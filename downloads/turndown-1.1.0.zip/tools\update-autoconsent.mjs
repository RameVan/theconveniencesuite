// Downloads DuckDuckGo's autoconsent rules (MPL-2.0) and saves a trimmed copy for the extension.
// Usage: node tools/update-autoconsent.mjs [version]   (defaults to the version below)
import { mkdir, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const version = process.argv[2] || '18.1.0';
const base = `https://cdn.jsdelivr.net/npm/@duckduckgo/autoconsent@${version}`;
const outDir = join(dirname(fileURLToPath(import.meta.url)), '..', 'vendor', 'autoconsent');
const SUPPORTED_STEP_VERSION = 3;

async function get(path) {
  const res = await fetch(`${base}/${path}`);
  if (!res.ok) throw new Error(`${path}: HTTP ${res.status}`);
  return res;
}

// Comments and the informational `text` field aren't used when running a rule.
function stripSteps(value) {
  if (Array.isArray(value)) return value.map(stripSteps);
  if (value && typeof value === 'object') {
    const out = {};
    for (const [key, v] of Object.entries(value)) {
      if (key !== 'comment' && key !== 'text') out[key] = stripSteps(v);
    }
    return out;
  }
  return value;
}

const { autoconsent } = await (await get('rules/rules.json')).json();
const rules = autoconsent
  .filter((rule) => (rule.minimumRuleStepVersion || 1) <= SUPPORTED_STEP_VERSION)
  .filter((rule) => !/^test(cmp| page)/i.test(rule.name))
  .map((rule) => {
    const out = { name: rule.name, detectCmp: stripSteps(rule.detectCmp), detectPopup: stripSteps(rule.detectPopup), optOut: stripSteps(rule.optOut) };
    if (rule.runContext) out.runContext = rule.runContext;
    if (rule.cosmetic) out.cosmetic = true;
    return out;
  });

await mkdir(outDir, { recursive: true });
await writeFile(join(outDir, 'rules.json'), JSON.stringify({ version, rules }));
await writeFile(join(outDir, 'LICENSE'), await (await get('LICENSE')).text());
console.log(`Saved ${rules.length} of ${autoconsent.length} rules from autoconsent ${version} to ${outDir}`);
