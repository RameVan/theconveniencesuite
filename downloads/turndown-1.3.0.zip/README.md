# Turndown

Part of The Convenience Suite. A Chrome extension (Manifest V3) that automatically rejects cookie consent banners, including the optional vendors and "legitimate interest" that many banners hide behind their settings. It also blocks the pop-ups and redirects that invisible links and layers open when you click, the trick streaming sites use to hide their play button behind an ad.

## Install

1. Open `chrome://extensions`.
2. Turn on **Developer mode** (top right).
3. Click **Load unpacked** and choose this `CookieDenier` folder.
4. Pin the extension if you want to see the ✓ badge when it handles a banner.

After editing any file, press the reload icon on the extension's card and reload the page you're testing.

## How it works

The content scripts run in every page and frame for the first 30 seconds after load, rescanning whenever the DOM changes. For each banner they try, in order:

1. **Vendor and legitimate-interest banners** (thorough mode, on by default): banners that mention partners, vendors or legitimate interest (IAB TCF banners, where "Reject all" often leaves legitimate interest switched on) are opened in their settings ("More options", "Manage options", "Cookie settings", ...). Then, screen by screen, the script:
   - clicks every "Reject all", "Object all" and "Disagree to all" button;
   - switches off every purpose, vendor and legitimate-interest toggle;
   - visits each Partners / Vendors / Legitimate interest screen and does the same there, going Back when needed;
   - saves with "Save & exit", "Confirm choices", "Save preferences" or similar (never "Accept all").

   If that can't be completed, the rules below take over.
2. **Rules for specific platforms and sites**: about 1,500 rules from DuckDuckGo's [autoconsent](https://github.com/duckduckgo/autoconsent) project, covering hundreds of consent platforms and around 900 individual websites. Eleven platforms that autoconsent handles in code (OneTrust, Cookiebot, Sourcepoint, TrustArc, consentmanager, Evidon, Klaro, Admiral, Conversant, TikTok, Uniconsent) are rewritten as rules in `extra-rules.js`. `rules-engine.js` runs them.
3. **Known platforms** in `content.js` (`CMPS`), recognised by their own selectors.
4. **Unknown banners**: buttons whose text means "reject" (in English, Dutch, German, French, Spanish, Italian, Portuguese, Nordic languages and Polish), such as "Reject all", "Alleen noodzakelijke cookies" or "Alle ablehnen", are clicked, but only when the surrounding element talks about cookies or consent. Banners with no reject button get the settings treatment from step 1, as do banners with switches on the first screen. Accept buttons and links that leave the page (like "Reject and subscribe") are never clicked.
5. **Fallback**: if a banner offers no way to refuse, it is hidden after 5 seconds and page scrolling is unlocked. You can turn this off in the popup.

The scripts look inside shadow DOM (including closed shadow roots) and iframes, and stop after handling one banner per frame. "Pay or accept" walls, where refusing means subscribing, are left alone.

### Pop-ups from invisible links

`popup-guard.js` runs in the page's own JavaScript world (`"world": "MAIN"`) in every frame, before the page's scripts. Streaming players are often nested several frames deep, with the ad layer in one of the middle ones (on cinego.co: ployan.me, then emboser.com with its `#popup-shield`, then vidsrc.sh, then the player), so it has to run in all of them.

- **Invisible layers over a player** (transparent, positioned, covering most of a `<video>` or `<iframe>`) are made click-through as soon as they appear, so the first click reaches the player. A player's own click layer (one sitting next to its `<video>`) is left alone.
- **Clicks that land on an invisible layer anyway** can't open a pop-up or follow a link to another site; the layer is then made click-through.
- **Pop-ups opened by a page-wide click handler** (on `window`, `document` or `<body>`, the "first click anywhere opens an ad" trick) to another site are blocked, unless you clicked a link to that same site. Links clicked by script (`a.click()`) and `window.open` borrowed from a fresh iframe go through the same check.
- **A blocked pop-up returns a fake window**, not `null`. Ad scripts that notice their pop-up was blocked fall back to redirecting the tab or to an "ad blocker detected" wall; the fake window stays "open" and silently accepts whatever they do to it (uBlock Origin's and AdGuard's pop-up scriptlets do the same with a hidden decoy frame).
- **Tab-unders**: for 3 seconds after a blocked pop-up, the page can't send the tab to another site. `popups.js` does this with the Navigation API from the isolated world, where the page can't remove the listener.
- **Pop-ups that get through anyway** (for example ones opened from inside an ad frame) are checked by where they go: `popup-tabs.js` (loaded by `background.js`) watches each new tab while it loads and redirects, until it has finished loading and gone quiet (at most 30 seconds), and closes it if it lands on one of about 2,700 known pop-up ad networks (`vendor/popup-domains/`, from EasyList and AdGuard Base, the same idea as uBlock Origin's `$popup` filters). A tab for the link you just clicked is never closed.
- **Pop-unders**: when a page opens a copy of itself in a new tab and then sends the original tab to a pop-up ad network, the original tab is sent back (keeping its scroll position) and the copy is closed unless you're in it.

The guard blocks nothing until `popups.js` has passed it the site's settings, so if anything in that chain fails, nothing is blocked. Invisible layers are changed by one CSS property, which is remembered and restored when you switch layer fixing off for the site; layers the page keeps putting back are left alone.

Pop-ups from a handler on a specific, visible button (share buttons), sign-in and payment windows (Google, Apple, Microsoft, PayPal, Stripe and others, even from a page-wide handler) and ordinary links still work. The wrapped functions are Proxies of the originals, so pages that check whether `window.open` is native still see native code, and the guard leaves nothing on `window`. `popups.js` passes the on/off settings to the guard and reports what it blocked.

Safety valves, so a site keeps working even when the guard gets it wrong:

- **Fail open**: every wrapper decides inside a `try`/`catch`; if the guard itself throws, the page gets the real `window.open`, click or event. Background listeners do the same: if the lists can't be read, no tab is closed.
- **Exceptions**: destinations that must always open (`vendor/popup-domains/exceptions.json`, the whole-host `@@||host^$popup` exceptions from EasyList and AdGuard, plus `popup-exceptions.json`) and sites whose own pop-ups are legitimate (`allowFrom` in `popup-exceptions.json`, where the in-page guard stays off). Add to `popup-exceptions.json` only with a test case or breakage report, and give the reason.
- **Per-site switches**: pop-up blocking and layer fixing can each be turned off for one site, separately from turning Turndown off there (cookie banners are still handled). Both apply to the open page without a reload.
- **Open it**: the popup shows the last blocked pop-up on the tab (its host, what was blocked and why, and when; never the full address) with **Open it**, **Trust this site** and **Report a mistake** (a prefilled e-mail with the host and reason only). Opening it allows that one destination from that site from then on; trusting the whole site is always your own choice, though the popup suggests it once you've opened two or more blocked pop-ups there. Only the address Turndown recorded can be reopened, and only from the popup.

`VALIDATION.md` lists every change from the original v1.2.0 design (kept unchanged outside this folder) with the test that covers it, the test results so far, and what's still open before release.

### How the rules run

The background script (`background.js`) loads the rule file once and tells each page which rules apply to its URL and frame type. Out of about 1,500 rules, a typical page gets around 560 and an ad iframe 2. The page first checks each rule's detection selectors in a few combined queries. Only rules whose banner is present are fetched and run, following autoconsent's [rule syntax](https://github.com/duckduckgo/autoconsent/blob/main/docs/rule-syntax.md).

About 35 rules call a small function in the page's own JavaScript, for example `Didomi.setUserDisagreeToAll()`. Those functions are in `vendor/autoconsent/snippets.js`, and the background script runs them through `chrome.scripting` by name only. That's why the extension has the `scripting` permission.

## Popup

- Turn the extension on or off everywhere, or only for the current site.
- Turn "Also refuse all vendors and legitimate interest" on or off. When it's off, banners with a "Reject all" button are only rejected on the first screen, which is faster.
- Turn the hide fallback on or off.
- Turn pop-up blocking on or off everywhere, and pop-up blocking or layer fixing off for only the current site (turning the extension off for a site also turns these off there).
- See the last blocked pop-up on the current tab and why it was blocked; open it anyway, trust the site, or report a mistake.
- See what was done on the current page, and how many banners have been denied and pop-ups blocked in total.
- **Save a log** when something still goes wrong: press **Cookie banner** or **Pop-ups or ads** (optionally type what happened first). Turndown saves `turndown-log-<problem>-<site>-<time>.json` to your Downloads folder and sends it nowhere. It holds, from every frame of the page:
  - **cookies**: every step the content script took, every consent-like banner still on screen with its text and buttons (and how each button was classified: reject, save, settings, accept), consent elements and frames it didn't recognise as a banner, and which site rules matched or were tried;
  - **pop-ups**: every `window.open`, scripted link click, layer fix and blocked redirect with the reason, what sits on top of the page and the player at a few points (and whether the guard counts it as an invisible layer), big transparent layers, and what happened to every tab the page opened;
  - the settings for the site and a screenshot of the visible page.

  Addresses are cut to origin and path, so query strings (which can hold sign-in or payment details) never end up in the log. `node tools/read-log.mjs` prints a summary of the newest log in Downloads and saves its screenshot as a `.jpg` next to it.

## Updates

Turndown is installed unpacked from a zip, so the browser can't update it on its own. When the popup opens (at most once an hour) it reads `https://theconveniencesuite.com/downloads/turndown-latest.json`, one small file, with no cookies and nothing sent along. If a newer version is listed, the popup shows **Update**: it downloads the new zip, and after you unzip it over the folder you loaded Turndown from, **Reload Turndown** loads the new files. Only a zip on theconveniencesuite.com is ever offered. **Reload Turndown** is always shown for an unpacked install, so it also picks up local edits.

### Releasing

```bash
node tools/publish.mjs --dry-run   # build and update the site in a temporary worktree, push nothing
node tools/publish.mjs
```

`publish.mjs` releases the version in `manifest.json`. It refuses unless the "Release gate status" in `VALIDATION.md` starts with "Releasable" and both local suites pass. Then it builds `turndown-<version>.zip` (without `tools/` and the design documents), writes `turndown-latest.json`, removes the older zip, updates the Turndown card on the homepage, and commits and pushes that to the site's `main` from a temporary worktree, so the site folder's own branch is never touched. Bump the version in `manifest.json` first; a version that is already on the site is refused.

## Tools

Re-download the autoconsent rules. The script defaults to version 18.1.0; pass a newer version number to update:

```bash
node tools/update-autoconsent.mjs 18.1.0
```

Check the extension against real websites in a throwaway headless Chrome profile. It prints what was done on each site and any banner still visible, and saves screenshots:

```bash
node tools/check-sites.mjs --wait 12 https://www.example.com/ https://www.example.org/
```

For big lists, use `--file sites.txt --parallel 14` (one URL per line) and add `--resume` to continue a run that stopped. `--debug` prints every click the extension makes on each page, which shows why a banner wasn't handled.

Check the pop-up guard against local test pages that copy what ad scripts do (invisible links over a player, page-wide click handlers, tab-unders, links clicked by script) and against pop-ups that must keep working (share buttons, ordinary links). `--no-extension` shows the same pages without it:

```bash
node tools/check-popups.mjs
```

Test it on real sites: `check-popup-sites.mjs` clicks each page the way a visitor would (the player, then the middle of the page) and records the pop-ups, redirects and script errors. Run it once without the extension and once with it, then compare: the comparison counts what still got through and looks for breakage (a visible link that stopped opening, a same-site click that stopped navigating, new script errors). Downloads are refused.

```bash
node tools/check-popup-sites.mjs --no-extension --parallel 20 --file sites.txt --out base
node tools/check-popup-sites.mjs --parallel 20 --file sites.txt --out ext
node tools/compare-popup-runs.mjs base/results.jsonl ext=ext/results.jsonl
```

Check the popup's "Save a log" on a local page with a stuck banner and pop-up tricks (`--keep <dir>` saves the log to look at), and read a saved log:

```bash
node tools/check-log.mjs
node tools/read-log.mjs                      # newest turndown-log-*.json in Downloads
node tools/read-log.mjs path/to/log.json --all
```

The tools use Chrome, or Microsoft Edge when Chrome isn't installed; set `CHROME_PATH` to use another Chromium browser.

Update the pop-up ad network list:

```bash
node tools/update-popup-domains.mjs
```

## Adding a site that isn't handled

Add a rule to `extra-rules.js` in the [autoconsent rule format](https://github.com/duckduckgo/autoconsent/blob/main/docs/rule-syntax.md):

```js
{
  name: 'example.com',
  runContext: { urlPattern: '^https://(www\\.)?example\\.com/' },
  detectCmp: [{ exists: '#cookie-banner' }],
  detectPopup: [{ visible: '#cookie-banner' }],
  optOut: [{ waitForThenClick: '#cookie-banner .reject' }],
},
```

## Licences

`vendor/autoconsent/` (rules and snippets) and `extra-rules.js` come from or are derived from DuckDuckGo's autoconsent, and are under the Mozilla Public License 2.0 (`vendor/autoconsent/LICENSE`).

`vendor/popup-domains/domains.json` is a list of hosts taken from EasyList (GPL-3.0 and CC BY-SA 3.0) and the AdGuard Base filter (GPL-3.0); see `vendor/popup-domains/LICENSE`.