# Turndown pop-up protection: validated design record

Two states are kept apart, as the engineering plan asks:

- **ORIGINAL DESIGN**: v1.2.0, preserved unchanged in `D:\Documents\RameClaude\Turndown-ORIGINAL-v1.2.0`.
  It is the comparison baseline for every test, and nothing writes to it.
- **VALIDATED DESIGN**: this folder (v1.3.0, not released). Every change below is listed against
  the original, with the test that covers it. A change without a passing test doesn't count as
  validated.

## Changes from the original (v1.2.0 → v1.3.0)

| Area | ORIGINAL (v1.2.0) | VALIDATED (v1.3.0) | Covered by (`tools/check-popups.mjs` unless noted) |
|---|---|---|---|
| Start-up | Guard blocked from the first moment | Blocks nothing until `popups.js` has sent this site's settings; if they never come, it never blocks | All cases (the guard only acts once configured) |
| Blocked `window.open` | Returned `null`, which ad scripts detect | Returns a decoy window that stays "open"; if the script sends it to an allowed destination, the real window opens there | "ad script checks whether its pop-up was blocked"; "sign-in window opened blank, then sent to the provider" |
| Sign-in and payment | No special handling | Google, Apple, Microsoft, PayPal, Stripe, Klarna, Mollie, Adyen and others always allowed, plus exception destinations | "sign-in pop-up from a page-wide handler"; "sign-in window reused by name"; "pop-up to an exception destination" |
| Destination check | None | `popup-tabs.js` closes new tabs that land on one of 2,737 known pop-up ad networks; watches until the page has loaded and gone quiet, at most 30 s; trusts the clicked link | "pop-up to a known ad network from a visible button gets closed" |
| Pop-unders | None | The tab sent to an ad network after opening a copy of itself is sent back (scroll position kept); the copy is closed only if you aren't in it | "pop-under: copy of the page in a new tab, this tab sent to an ad network later" |
| Redirect guard | Main world, any cross-site script navigation for 3 s | Isolated world (the page can't remove it); never touches same-site, allowed destinations, form submissions, downloads, reloads, back/forward or user navigation | "page-wide click handler opens a pop-up and redirects"; "tab-under" |
| Invisible layers | `pointer-events: none`, permanent | Original value remembered and restored on request; layers the page keeps putting back are left alone after 3 tries; consent, caption, control and dialog elements excluded; per-site switch | "layer fixing switched off for the site: the layer is restored without a reload"; "invisible link over the player" |
| Failure handling | An error in the guard could reach the page | Every wrapper and listener fails open (the original call runs); background listeners fail open (tab left alone) | "guard fails open when it breaks"; "ad network list broken: pop-up tab is left alone" |
| Detectability | `__turndownPopupGuard` on `window`; plain function wrappers | Nothing on `window`; Proxy wrappers that read as native code (harder to spot, not undetectable) | "nothing of the guard is visible on window"; "wrapped functions still look native" |
| Recovery | None | Popup shows the last blocked pop-up (host, what, why, when; never the full address) with **Open it**, **Trust this site** and **Report a mistake** | "\"Open it\" reopens a blocked pop-up and allows only that destination on the site" |
| False-positive memory | None | **Open it** allows that one destination from that site (narrow). The whole site is only trusted when you choose it. After 2+ restores on a site, the popup suggests it but doesn't do it | same |
| Per-site controls | Turndown on/off per site only | Three independent switches: Turndown, pop-ups and invisible layers. The last two apply without a reload and leave cookie handling on | "site where you allowed pop-ups"; "layer fixing switched off for the site" |
| Exceptions | None | `vendor/popup-domains/exceptions.json` (26 whole-host `@@||host^$popup` exceptions from EasyList/AdGuard) and hand-kept `popup-exceptions.json`, where each entry needs a reason | "pop-up to an exception destination" |
| Messages | Not validated | Types and lengths checked; **Open it** and **Trust this site** are only accepted from the extension's own popup, and **Open it** only reopens the URL Turndown recorded (a page can't make it open an address of its choosing) | code review; "\"Open it\"…" |
| Problem log | None | Popup "Save a log" (**Cookie banner** / **Pop-ups or ads**): per-frame cookie steps and banners still on screen, pop-up guard decisions, layers on top, tab events, settings and a screenshot, saved to Downloads only; addresses cut to origin + path. Recording is passive (ring buffers of 60–80 entries per frame, 40 per tab) and changes no behaviour | `tools/check-log.mjs` (16 checks, incl. no query string in the log); local suite re-run 27/27 |
| Resource use | Overlay scan every 1.5 s forever, in every frame | No scanning in frames without a player; 1.5 s for the first 30 s, then 5 s; tracked tabs and clicks capped at 200 | code review (performance not yet measured, see open items) |

## Test results

### Local suite (`node tools/check-popups.mjs`), 2026-11-11

| Run | Result |
|---|---|
| v1.3.0 | **27/27 pass** |
| Without Turndown | 13/22 pass: all 9 ad-trick cases fail (as they should without protection), all 13 must-keep-working cases pass (the 5 cases that need the extension are skipped) |

Must-keep-working cases include:
- share button and ordinary new-tab link
- link opened by a page-wide handler
- Google sign-in from a page-wide handler
- sign-in window opened blank and messaging back to the site (`postMessage`)
- named sign-in window reused
- print window
- exception destination
- site with pop-ups allowed
- fail-open with a broken guard and with a broken list

### Cookie banners (`tools/check-sites.mjs`)

Spiegel, nu.nl and Marktplaats were still handled after every change. The full 1,000-site
regression sample has not been run yet.

### Real sites (`tools/check-popup-sites.mjs`)

| Run | Status |
|---|---|
| Baseline, no extension, 11,560 candidate sites | **Done** 2026-11-12: 11,354 visited, 1,747 with pop-ups or redirects; 1,655 confirmed after removing parked domains |
| Breakage panel baseline, no extension, 852 ordinary top sites | **Done**: 57 with pop-ups or redirects |
| ORIGINAL v1.2.0 on 1,655 confirmed + 1,500 control + 852 panel sites | Running (stopped at 391 when the session ended, resumed) |
| VALIDATED v1.3.0, same sites | Queued |

## Open items, by plan phase

- **Phase B populations:** ordinary high-traffic sites, sign-in sites, checkout sites, embedded
  apps and a mobile viewport. Only the streaming-type candidates and a random control are
  covered so far.
- **Real payment flows** (PayPal, Stripe, 3-D Secure sandboxes) and real OAuth providers. The
  local tests use stand-ins, because real providers are HSTS-preloaded and can't be served
  locally.
- **Performance:** measure CPU and memory over a long session.
- **Overlay monitoring:** detecting that a click-through layer broke a legitimate interaction,
  and restoring it automatically. Today it's restored by the per-site switch and given up after
  3 fights.
- **Navigation provenance:** a full redirect-chain record per tab. Today each step of a new
  tab's chain is checked against the ad list, but the chain isn't kept.
- **Known pop-up sites list** (phase 4). Deliberately not started: the plan says no more
  aggressive blocking until the baseline is in.
- **Known limitation:** a page can spoof the events between `popups.js` and the guard. That can
  only make the page's own protection stricter or weaker, and can't change settings, open
  windows or reach other sites.

## Release gate status

Not releasable yet: the real-site comparison, the breakage panel and the 1,000-site cookie
regression sample haven't run.
