// Records what the content scripts did per tab (badge + popup status), keeps running totals,
// serves the consent rules (and their page-context snippets) to content scripts, and handles
// pop-up tabs (popup-tabs.js).
importScripts('shared.js', 'vendor/autoconsent/snippets.js', 'extra-rules.js', 'rules-index.js');

let totalUpdate = Promise.resolve();
let ruleIndex = null;

// Chained so reports from several frames at once don't overwrite each other.
function bump(area, key) {
  totalUpdate = totalUpdate.then(async () => {
    const { [key]: count } = await chrome.storage[area].get({ [key]: 0 });
    await chrome.storage[area].set({ [key]: count + 1 });
  });
}

// Loaded once per service-worker lifetime; our own ports come before the downloaded rules.
function getRuleIndex() {
  ruleIndex ||= fetch(chrome.runtime.getURL('vendor/autoconsent/rules.json'))
    .then((res) => res.json())
    .then(({ rules }) => buildRuleIndex([...EXTRA_RULES, ...rules]));
  return ruleIndex;
}

// Runs one of the known snippets (never arbitrary code) in the page's own JavaScript world.
async function runSnippet(name, sender) {
  const func = AUTOCONSENT_SNIPPETS[name];
  if (!func || !sender.tab) return false;
  try {
    const [injection] = await chrome.scripting.executeScript({
      target: { tabId: sender.tab.id, frameIds: [sender.frameId] },
      world: 'MAIN',
      func,
    });
    return !!injection?.result;
  } catch {
    return false;
  }
}

let recentUpdate = Promise.resolve();

// The last few actions, kept across page loads (per-tab state is cleared on navigation).
function logRecent(entry) {
  recentUpdate = recentUpdate.then(async () => {
    const { recent = [] } = await chrome.storage.session.get('recent');
    await chrome.storage.session.set({ recent: [entry, ...recent].slice(0, 50) });
  });
}

function report(msg, sender) {
  if (!sender.tab) return;
  const tabId = sender.tab.id;
  chrome.action.setBadgeBackgroundColor({ tabId, color: msg.method === 'hidden' ? '#757575' : '#2e7d32' });
  chrome.action.setBadgeText({ tabId, text: '✓' });
  chrome.storage.session.set({ [`tab_${tabId}`]: { cmp: msg.cmp, method: msg.method } });
  logRecent({ cmp: msg.cmp, method: msg.method, url: sender.tab.url, frame: sender.url, at: Date.now() });
  bump('local', 'total');
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg?.type) {
    case 'denied':
      report(msg, sender);
      return false;
    case 'rules:forPage':
      getRuleIndex().then((index) => sendResponse(rulesForPage(index, msg.url, msg.top)));
      return true;
    case 'rules:get':
      getRuleIndex().then((index) => sendResponse(msg.ids.map((id) => index[id]?.rule ?? null)));
      return true;
    case 'rules:eval':
      runSnippet(msg.snippet, sender).then(sendResponse);
      return true;
    default:
      return handlePopupMessage(msg, sender, sendResponse) ?? false;
  }
});

chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status !== 'loading' || (keepTabRecordsUntil.get(tabId) || 0) > Date.now()) return;
  chrome.action.setBadgeText({ tabId, text: '' });
  chrome.storage.session.remove([`tab_${tabId}`, `popups_${tabId}`, `lastBlocked_${tabId}`]);
});

chrome.tabs.onRemoved.addListener((tabId) => chrome.storage.session.remove([`tab_${tabId}`, `popups_${tabId}`, `lastBlocked_${tabId}`, `tablog_${tabId}`]));

// Pop-up tabs: destination check, pop-unders and recovery (needs bump() above).
importScripts('popup-tabs.js');
