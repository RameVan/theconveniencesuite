# Turndown pop-up blocking: proposal and plan

> Superseded as the working spec by the "Improved Engineering & Safety Plan" (2026-11-11). What has
> been built against it, the test evidence and the open items are tracked in VALIDATION.md; the
> original v1.2.0 is kept unchanged in `D:\Documents\RameClaude\Turndown-ORIGINAL-v1.2.0`.

Goal: stop the pop-ups, pop-unders and redirects that ad scripts open when you click (mostly on
streaming, anime and file-host sites, where an invisible layer sits over the player), **without
ever breaking what a site is supposed to do**. When the two conflict, keeping the site working
wins, and the missed pop-up is caught afterwards by where it goes.

## What the research says

| Finding | Source | What it means for Turndown |
|---|---|---|
| uBlock Origin's main pop-up defence doesn't touch the page. It lets the new tab open, matches its URL against curated `$popup` lists (known pop-up ad networks), and closes the tab on a match. A tab for the link you just clicked is always trusted. | uBO `src/js/tab.js` | Blocking by **destination** can't break a page, because the page's code never sees anything fail. It should be the main layer, not a fallback. |
| uBO's `no-window-open-if` and AdGuard's `prevent-window-open` are applied **only on sites a filter rule names**. With a delay argument they return a decoy window (a hidden 1×1 frame that reports `closed: false`) rather than `null`. | uBO `scriptlets.js`, AdGuard Scriptlets | A blocked `window.open` must not look blocked. Scripts that see `null` fall back to redirects or "ad blocker detected" walls. Strict, in-page blocking belongs on sites known to need it. |
| uBO's `prevent-navigation` runs in the **isolated** world and only cancels navigations that weren't started by the user. | uBO `prevent-navigation.js` | Tab-under protection should run where the page can't remove it, and never cancel a user's own click. |
| Most breakage comes from rules that are too broad: hiding elements, or blocking scripts a site needs. About 53% of breakage-causing rules hide elements. Blockers find breakage through user reports. | SINBAD (arXiv 2405.05196), uBO issue #1111 | Do as little to the page as possible, keep every intervention reversible, and **measure** breakage automatically rather than wait for complaints. |
| Sign-in pop-ups (Google and others) are the classic false positive of pop-up blocking. | Mozilla support threads, Hacker Noon write-up | Never block sign-in or payment windows. |
| Some sites blame ad blockers for failures caused by their own ad-recovery scripts. | AdGuard blog | Stay invisible to detection: native-looking wrappers, no visible globals. |

## Proposed solution: four layers, from least to most invasive

The rule throughout: **the more invasive a layer, the more certain it must be.** Anything a layer
isn't sure about is allowed and left to the layer below it.

### Layer 1: destination check (background, can't break pages)
- Every new tab opened from a page is watched for 8 seconds, through all its redirects, and closed
  if it lands on a known pop-up ad network (about 2,700 hosts from EasyList and AdGuard Base,
  refreshed with `tools/update-popup-domains.mjs`).
- A tab whose URL matches the link you just clicked is never closed.
- *To add:* pop-under detection. When a page opens a copy of itself in a new tab and the original
  tab then goes to an ad network, close the ad tab and switch back to the copy.
- *To add:* an `about:blank` pop-up that a script fills in afterwards gets the same check when it
  navigates (it already does through `onBeforeNavigate`; cover it with a test).

### Layer 2: in-page guard, only for high-certainty patterns
Block a pop-up in the page only when one of these is clearly true:
1. The click landed on an **invisible layer**: transparent, positioned, covering a player or a
   large part of the page, and not part of the player itself.
2. The pop-up goes to **another site**, is opened by a **page-wide** click handler (on `window`,
   `document` or `<body>`), and you didn't click a link to that site.
3. The site is on the **known pop-up sites** list (to add): the 5,000+ sites that uBO and AdGuard
   already have pop-up rules for. Only there, any cross-site pop-up you didn't click a link for
   is blocked. Elsewhere, ambiguous cases are allowed and left to layer 1.

How it blocks, so the page can't tell:
- It returns a decoy window, never `null`.
- The wrappers are Proxies of the originals, so they read as native code.
- *To do:* the `__turndownPopupGuard` marker on `window` should become a module-scoped `WeakSet`,
  so pages can't see it.

### Layer 3: invisible layers over players (one CSS change, reversible)
- An invisible layer is only made click-through (`pointer-events: none`) when it covers at least
  half of a `<video>` or `<iframe>` player and isn't part of that player.
- The page is never hidden, removed or restyled beyond that.
- *To add:* if the page removes our change and re-adds the layer more than three times, stop
  fighting it. A site that insists probably depends on the layer, and layer 2 still guards the
  click.

### Layer 4: tab-under guard (isolated world)
- For 3 seconds after a blocked pop-up or a click on an invisible layer, a script-started
  navigation of the tab to another site is cancelled.
- User-initiated navigations (`userInitiated`), reloads and back/forward are never touched.

### Safety valves (keep sites working at all times)
- **Always allowed:** sign-in and payment windows (Google, Apple, Microsoft, PayPal, Stripe,
  Klarna, Mollie, Adyen and others), even from page-wide handlers.
- **Per-site switch (done):** "Block pop-ups on this site" in the popup, separate from turning
  Turndown off for the site, so cookie handling keeps working (`popupAllowedSites`).
- **One-click undo (done):** the popup shows the last blocked pop-up on the tab with an "Open it"
  button. Opening blocked pop-ups twice on a site allows pop-ups there, and the popup says so.
- **Fail open (done):** every wrapper decides inside `try`/`catch`; if the guard throws, the
  original function runs. The guard leaves nothing on `window`.
- **Shipped exceptions (done):**
  - `vendor/popup-domains/exceptions.json`: 26 whole-host `@@||host^$popup` exceptions from
    EasyList and AdGuard. Narrower ones (a path, or from one site only) are left out, because
    applied to a whole host they would let ads through (`ad.doubleclick.net`, streamtape.to).
  - `popup-exceptions.json`: kept by hand, with a reason for each entry (`allowTo`
    destinations, `allowFrom` sites where the in-page guard stays off). It starts with Disqus
    sign-in and is filled from the breakage reports below, like uBO's `unbreak` list.

## Plan

### Phase 1: v1.3.0, already built (not yet released)
- [x] Decoy window instead of `null`
- [x] Sign-in and payment allowlist
- [x] Proxy wrappers that look native
- [x] Tab-under guard moved to the isolated world
- [x] Destination check against EasyList and AdGuard pop-up hosts, trusting the clicked link
- [x] Local suite `tools/check-popups.mjs`: 19 cases, all passing (7 fail without Turndown)
- [x] Safety valves: per-site switch, "Open it" with two-strikes allow, fail-open wrappers, no global marker, shipped exceptions
- [x] Real-site tools `check-popup-sites.mjs` and `compare-popup-runs.mjs`

### Phase 2: measure (running now)
1. Baseline without Turndown on 11,560 candidate sites (in progress). After 1,120 sites: 118 open
   pop-ups or redirects, plus 27 parked domains that are left out. 49 of the 118 have a player,
   and on 33 the first click landed inside a frame.
2. Run v1.2.0 and v1.3.0 on the confirmed pop-up sites, plus a random sample of 1,500 sites that
   didn't show pop-ups (to look for breakage).
3. **Breakage panel:** about 1,000 ordinary popular sites (CrUX top, not streaming), plus scripted
   flows that must keep working:
   - "Sign in with Google", Apple and Microsoft
   - PayPal and Stripe checkout (test or sandbox pages)
   - Share buttons (X, Facebook, WhatsApp)
   - YouTube and Vimeo embeds, a payment 3-D Secure window, a print window
4. Read the misses: what was clicked, and where the pop-up went.

### Phase 3: close the gaps found in phase 2
- Known pop-up sites list (layer 2, point 3), generated from the uBO and AdGuard rules by a new
  `tools/update-popup-sites.mjs`.
- Pop-under detection (layer 1).
- Give-up rule for layers the page keeps putting back (layer 3).
- Add every miss and every breakage found in phase 2 as a local test case.

### Phase 4: release gates
Release only when all of these hold:

| Check | Target |
|---|---|
| Local suite | 100% pass |
| Confirmed pop-up sites with no pop-up or redirect left | ≥ 90% (parked domains excluded) |
| Pop-ups that reach a visible ad-network tab | ≤ 2% of the baseline count |
| Breakage panel: a visible link or same-site click that stops working | 0, after checking each report by hand |
| Breakage panel: sites with new script errors caused by Turndown | 0 |
| Scripted sign-in, payment, share and embed flows | all still work |
| Cookie-banner regression sample (`check-sites.mjs`, 1,000 sites) | ≥ 97.5% still handled |

Then:
- Bump to v1.3.0.
- Rebuild `turndown-1.3.0.zip` with `build-downloads.ps1` and update the link in `index.html`.
- Note the new `webNavigation` permission on the site.

### Phase 5: keep it working
- Refresh the host lists monthly (`update-popup-domains.mjs`, `update-popup-sites.mjs`).
- Re-run the confirmed pop-up sites and the breakage panel after every change to the guard.
- Any site reported as broken gets a test case before it gets a fix.
