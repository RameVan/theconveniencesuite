// Turndown pop-up guard. Runs in the page's own JavaScript world (manifest "world": "MAIN") in
// every frame, before the page's scripts, so it can wrap window.open and friends.
//
// Blocks the pop-ups and redirects that ad scripts open when you click, mostly on streaming
// sites where an invisible layer sits on top of the video player. It only acts on strong
// evidence; anything less is allowed and left to background.js, which closes pop-up tabs that
// land on a known pop-up ad network.
//   - Invisible layers (transparent, positioned, covering a video or iframe player, not part of
//     the player) are made click-through, so the first click reaches the player. The change is
//     one CSS property, remembered and undone on request; layers the page keeps putting back
//     are left alone.
//   - A click that lands on an invisible layer can't open a pop-up or follow a link elsewhere.
//   - Pop-ups to another site opened by a page-wide click handler (on window, document or body:
//     the "first click anywhere opens an ad" trick) are blocked, unless you clicked a link to
//     that same site or the destination is a sign-in, payment or other allowed destination.
//   - A blocked pop-up returns a fake window rather than null, so the ad script doesn't notice
//     and fall back to redirecting this tab. If the script then points that window at an allowed
//     destination (a sign-in window opened blank first), the real window is opened after all.
// The guard blocks nothing until popups.js (isolated world) has sent this site's settings, and
// every wrapper falls back to the original function if the guard itself fails.
(() => {
  'use strict';

  const PRESS_MS = 1500;       // how long a click counts as "the click that caused this"
  const SUSPECT_MS = 3000;     // how long after a blocked pop-up a cross-site redirect is refused
  const SCAN_GAP_MS = 400;     // min gap between overlay scans triggered by DOM changes
  const SCAN_FAST_MS = 1500;   // scan this often for the first FAST_FOR_MS (ads add layers on timers)
  const SCAN_SLOW_MS = 5000;   // and this often after that
  const FAST_FOR_MS = 30000;
  const GIVE_UP_AFTER = 3;     // the page put a layer back this often: leave it alone
  const MEDIA = 'video, iframe, embed, object';

  const native = {
    open: window.open,
    addEventListener: EventTarget.prototype.addEventListener,
    dispatchEvent: EventTarget.prototype.dispatchEvent,
    click: HTMLElement.prototype.click,
    contentWindow: Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, 'contentWindow').get,
  };
  const listen = (target, type, fn, opts) => native.addEventListener.call(target, type, fn, opts);
  const startedAt = performance.now();

  let blocking = false;   // pop-up blocking (off until popups.js says otherwise)
  let overlays = false;   // making invisible layers click-through
  let lastPress = null;   // { target, time, overlay }
  let suspectUntil = 0;
  const neutralized = new Map(); // layer -> { value, priority, fights }
  const givenUp = new WeakSet();
  const patchedWindows = new WeakSet([window]);
  const allowedHosts = new Set(); // destinations that must always open (from popups.js)

  // Never let a mistake in the guard break the page: if it throws, do what the page asked.
  const safely = (fn) => { try { return fn(); } catch { return false; } };

  // Settings for this site, from popups.js. Repeated when the user changes them in the popup,
  // so they apply without a reload.
  listen(window, 'turndown:popups-config', (e) => safely(() => {
    const config = e.detail || {};
    blocking = !!config.popups;
    overlays = !!config.overlays;
    for (const host of Array.isArray(config.allowTo) ? config.allowTo : []) allowedHosts.add(String(host));
    if (overlays) queueScan();
    else restoreOverlays();
  }));

  // --- Problem log ---------------------------------------------------------------------------
  // What the guard decided is passed to popups.js (isolated world), which keeps the last few
  // for the popup's "Save a log". Addresses are cut to origin + path (no query strings).
  function cleanUrl(url) {
    const d = parse(url);
    if (!d) return '';
    return /^https?:$/.test(d.protocol) ? (d.origin + d.pathname).slice(0, 200) : d.protocol;
  }
  function describe(el) {
    if (!el || el.nodeType !== 1) return el === window ? 'window' : el === document ? 'document' : String(el?.nodeName || el);
    const cls = typeof el.className === 'string' && el.className.trim() ? '.' + el.className.trim().split(/\s+/).slice(0, 4).join('.') : '';
    return `${el.tagName.toLowerCase()}${el.id ? '#' + el.id : ''}${cls}`.slice(0, 120);
  }
  function trace(what, detail) {
    safely(() => native.dispatchEvent.call(window, new CustomEvent('turndown:trace', { detail: { what, ...detail } })));
  }

  // What is on top at a point, from the top down, and whether the guard counts it as an
  // invisible layer: shows why a click went to an ad.
  function stackAt(x, y) {
    return document.elementsFromPoint(x, y).slice(0, 5).map((el) => {
      const cs = getComputedStyle(el);
      const r = el.getBoundingClientRect();
      const link = el.closest('a[href]');
      return {
        el: describe(el),
        box: [Math.round(r.x), Math.round(r.y), Math.round(r.width), Math.round(r.height)],
        position: cs.position,
        zIndex: cs.zIndex,
        opacity: cs.opacity,
        pointerEvents: cs.pointerEvents,
        transparent: safely(() => isTransparent(el)),
        invisibleLayer: !!safely(() => invisibleLayer(el, true)),
        fixedByTurndown: neutralized.has(el),
        link: link ? cleanUrl(link.href) : undefined,
        clickHandler: typeof el.onclick === 'function' || el.hasAttribute('onclick') || undefined,
      };
    });
  }

  function diagnose() {
    const media = [...document.querySelectorAll(MEDIA)].slice(0, 8).map((m) => {
      const r = m.getBoundingClientRect();
      return { el: describe(m), src: cleanUrl(m.src || m.data || ''), box: [Math.round(r.x), Math.round(r.y), Math.round(r.width), Math.round(r.height)] };
    });
    const points = [];
    for (const m of document.querySelectorAll(MEDIA)) {
      const r = m.getBoundingClientRect();
      if (r.width >= 120 && r.height >= 80 && r.bottom > 0 && r.top < innerHeight) points.push(['player centre', r.left + r.width / 2, r.top + r.height / 2]);
      if (points.length >= 4) break;
    }
    points.push(['page centre', innerWidth / 2, innerHeight / 2], ['top left', innerWidth * 0.2, innerHeight * 0.2], ['bottom right', innerWidth * 0.8, innerHeight * 0.8]);
    return {
      blocking,
      overlays,
      allowedDestinations: allowedHosts.size,
      viewport: [innerWidth, innerHeight],
      players: media,
      layersFixed: [...neutralized].map(([layer, rec]) => ({ el: describe(layer), connected: layer.isConnected, fights: rec.fights })),
      onTop: points.map(([where, x, y]) => ({ where, at: [Math.round(x), Math.round(y)], stack: safely(() => stackAt(x, y)) || [] })),
      // Big positioned elements anywhere on the page: candidates for an ad layer the guard missed.
      bigPositioned: [...document.querySelectorAll('body *')].filter((el) => {
        const cs = getComputedStyle(el);
        if (cs.position !== 'fixed' && cs.position !== 'absolute') return false;
        const r = el.getBoundingClientRect();
        return r.width * r.height >= 0.2 * innerWidth * innerHeight;
      }).slice(0, 12).map((el) => {
        const cs = getComputedStyle(el);
        const r = el.getBoundingClientRect();
        return { el: describe(el), box: [Math.round(r.x), Math.round(r.y), Math.round(r.width), Math.round(r.height)], zIndex: cs.zIndex, opacity: cs.opacity, pointerEvents: cs.pointerEvents, transparent: safely(() => isTransparent(el)), invisibleLayer: !!safely(() => invisibleLayer(el, true)), link: el.closest('a[href]') ? cleanUrl(el.closest('a[href]').href) : undefined };
      }),
    };
  }
  // popups.js asks; the answer comes back synchronously in the same dispatch.
  listen(window, 'turndown:diagnose-request', (e) => safely(() => {
    native.dispatchEvent.call(window, new CustomEvent('turndown:diagnose', { detail: JSON.stringify(diagnose()) }));
  }));

  function report(kind, reason, url) {
    const dest = url == null ? null : parse(url);
    const detail = { kind, reason, url: dest && /^https?:$/.test(dest.protocol) ? dest.href : '' };
    native.dispatchEvent.call(window, new CustomEvent('turndown:popup-blocked', { detail }));
  }

  // For a few seconds the page may not send this tab to another site (enforced by popups.js,
  // in the isolated world where the page can't remove the listener).
  function suspect() {
    suspectUntil = performance.now() + SUSPECT_MS;
    native.dispatchEvent.call(window, new CustomEvent('turndown:suspect', { detail: Date.now() + SUSPECT_MS }));
  }

  // Wrappers are Proxies of the originals, so they read as native code to a page that checks.
  // (That makes them harder to spot, not impossible: the local tests check it, nothing more.)
  const wrap = (fn, apply) => new Proxy(fn, { apply });

  // Sign-in and payment windows are never blocked, even from a page-wide click handler. More
  // destinations come from the exceptions (allowedHosts).
  const TRUSTED_POPUP_SITES = new Set([
    'google.com', 'apple.com', 'microsoft.com', 'microsoftonline.com', 'live.com', 'facebook.com',
    'github.com', 'gitlab.com', 'twitter.com', 'x.com', 'linkedin.com', 'paypal.com', 'stripe.com',
    'discord.com', 'twitch.tv', 'amazon.com', 'yahoo.com', 'okta.com', 'auth0.com', 'klarna.com',
    'mollie.com', 'adyen.com', 'steampowered.com', 'steamcommunity.com', 'reddit.com', 'spotify.com',
    'dropbox.com', 'slack.com', 'zoom.us', 'patreon.com', 'ko-fi.com',
  ]);

  // --- Sites -------------------------------------------------------------------------------

  // "Site" as in registrable domain, approximately: the last two labels, or three when the
  // second-to-last is short (example.co.uk, example.com.br). Same as siteOf() in shared.js.
  function siteOf(host) {
    const parts = (host || '').toLowerCase().replace(/\.$/, '').split('.');
    if (parts.length <= 2 || /^\d+$/.test(parts[parts.length - 1])) return parts.join('.');
    const n = parts[parts.length - 2].length <= 3 && parts[parts.length - 1].length === 2 ? 3 : 2;
    return parts.slice(-n).join('.');
  }

  function parse(url) {
    try { return new URL(url == null || url === '' ? 'about:blank' : String(url), location.href); } catch { return null; }
  }

  // about:blank, javascript: and friends count as "elsewhere": ad scripts open a blank window
  // and point it at the ad afterwards.
  function isOtherSite(dest) {
    if (!dest || !/^https?:$/.test(dest.protocol)) return true;
    return siteOf(dest.hostname) !== siteOf(location.hostname);
  }

  function isAllowedDestination(dest) {
    if (!dest || !/^https?:$/.test(dest.protocol)) return false;
    if (TRUSTED_POPUP_SITES.has(siteOf(dest.hostname))) return true;
    for (let h = dest.hostname.toLowerCase(); h.includes('.'); h = h.slice(h.indexOf('.') + 1)) if (allowedHosts.has(h)) return true;
    return false;
  }

  // --- Decoy window --------------------------------------------------------------------------

  // What a blocked pop-up returns instead of null. Ad scripts that get null, or a window that is
  // already closed, fall back to redirecting this tab or to an "ad blocker detected" wall; this
  // fake window takes whatever they do to it and stays "open". If the script sends it to an
  // allowed destination (sign-in and payment windows are often opened blank, then pointed at
  // the provider), the real window opens there and the fake one forwards to it from then on.
  function decoy(args) {
    let real = null;
    const upgrade = (url) => {
      const dest = parse(url);
      if (!real && isAllowedDestination(dest)) real = Reflect.apply(native.open, window, [dest.href, args[1] ?? '', args[2] ?? '']);
      return real;
    };
    const doc = document.implementation.createHTMLDocument('');
    const loc = {
      get href() { return real ? real.location.href : 'about:blank'; },
      set href(url) { upgrade(url); },
      assign(url) { upgrade(url); },
      replace(url) { upgrade(url); },
      reload() {},
      toString() { return this.href; },
    };
    const fake = new Proxy({}, {
      get(_, prop) {
        if (real) {
          const value = Reflect.get(real, prop);
          return typeof value === 'function' ? value.bind(real) : value;
        }
        switch (prop) {
          case 'closed': return false;
          case 'location': return loc;
          case 'document': return doc;
          case 'opener': return window;
          case 'name': return String(args[1] ?? '');
          case 'innerWidth': case 'outerWidth': return 800;
          case 'innerHeight': case 'outerHeight': return 600;
          case 'screenX': case 'screenY': case 'scrollX': case 'scrollY': return 0;
          case 'window': case 'self': case 'top': case 'parent': return fake;
          case Symbol.toPrimitive: case 'then': return undefined;
          default: return () => {}; // focus(), blur(), close(), postMessage(), moveTo(), print(), ...
        }
      },
      set(_, prop, value) {
        if (real) return Reflect.set(real, prop, value);
        if (prop === 'location') upgrade(value);
        return true;
      },
    });
    return fake;
  }

  // --- Invisible layers ------------------------------------------------------------------------

  function isTransparent(el) {
    let opacity = 1;
    for (let e = el; e && e.nodeType === 1; e = e.parentElement) opacity *= Number(getComputedStyle(e).opacity) || 0;
    if (opacity < 0.1) return true;
    const cs = getComputedStyle(el);
    const bg = cs.backgroundColor.match(/[\d.]+/g);
    const clearBg = !bg || (bg.length === 4 && Number(bg[3]) < 0.1);
    if (!clearBg || cs.backgroundImage !== 'none' || (el.innerText || '').trim()) return false;
    // Anything visible inside (an image, a button with a border) makes it a real control.
    for (const child of el.querySelectorAll('img, svg, video, canvas, picture, input, button')) {
      const r = child.getBoundingClientRect();
      if (r.width > 16 && r.height > 16 && getComputedStyle(child).visibility !== 'hidden') return false;
    }
    return !(parseFloat(cs.borderTopWidth) > 0 && cs.borderTopStyle !== 'none' && !/rgba\(.*,\s*0\)/.test(cs.borderTopColor));
  }

  // A player's own click layer sits next to its <video>; an ad's sits on top from elsewhere.
  function isPlayerPart(el) {
    for (let e = el, i = 0; e && i < 4; e = e.parentElement, i++) if (e.querySelector?.('video')) return true;
    return false;
  }

  // Things that look like layers but must keep working: controls, dialogs, consent banners.
  const NOT_AN_AD = '[role], [aria-label], [aria-modal], dialog, [id*="consent" i], [class*="consent" i], [id*="cookie" i], [class*="cookie" i], [class*="caption" i], [class*="subtitle" i], [class*="control" i]';

  function coversMedia(rect) {
    for (const m of document.querySelectorAll(MEDIA)) {
      const r = m.getBoundingClientRect();
      if (r.width < 120 || r.height < 80) continue;
      const w = Math.min(rect.right, r.right) - Math.max(rect.left, r.left);
      const h = Math.min(rect.bottom, r.bottom) - Math.max(rect.top, r.top);
      if (w > 0 && h > 0 && w * h >= 0.5 * r.width * r.height) return true;
    }
    return false;
  }

  // The invisible layer the element belongs to, if any. `broad` also accepts a big layer that
  // covers no player (judged only when a click on it tries to open a pop-up).
  function invisibleLayer(el, broad) {
    const viewport = innerWidth * innerHeight;
    for (let e = el, i = 0; e && e.nodeType === 1 && i < 5; e = e.parentElement, i++) {
      if (e === document.body || e === document.documentElement) return null;
      if (e.matches(MEDIA + ', input, select, textarea, label, button')) return null;
      const position = getComputedStyle(e).position;
      if (position !== 'fixed' && position !== 'absolute') continue;
      const rect = e.getBoundingClientRect();
      const area = rect.width * rect.height;
      const link = e.closest('a[href]');
      const big = area >= (link ? 0.1 : 0.2) * viewport;
      if (!(coversMedia(rect) || (broad && big))) continue;
      if (e.querySelector(MEDIA) || isPlayerPart(e) || !isTransparent(e)) return null;
      if (!link && e.matches(NOT_AN_AD)) return null;
      return e;
    }
    return null;
  }

  // Makes a layer click-through; returns true when that changed something.
  function neutralize(layer) {
    if (!overlays || !layer || givenUp.has(layer)) return false;
    const record = neutralized.get(layer);
    if (record) {
      if (layer.style.getPropertyValue('pointer-events') === 'none') return false;
      // The page put it back. It may need it: after a few times, leave it alone (clicks on it
      // are still guarded).
      if (++record.fights >= GIVE_UP_AFTER) {
        trace('layer given up', { layer: describe(layer), note: 'the page kept putting it back' });
        givenUp.add(layer);
        neutralized.delete(layer);
        return false;
      }
    } else {
      neutralized.set(layer, { value: layer.style.getPropertyValue('pointer-events'), priority: layer.style.getPropertyPriority('pointer-events'), fights: 0 });
    }
    layer.style.setProperty('pointer-events', 'none', 'important');
    if (!record) trace('layer fixed', { layer: describe(layer) });
    return !record;
  }

  // Undoes every change (the user switched layer fixing off for this site).
  function restoreOverlays() {
    for (const [layer, { value, priority }] of neutralized) {
      if (value) layer.style.setProperty('pointer-events', value, priority);
      else layer.style.removeProperty('pointer-events');
    }
    neutralized.clear();
  }

  // Looks at what's on top of each player and makes invisible layers there click-through.
  function scan() {
    for (const layer of neutralized.keys()) if (!layer.isConnected) neutralized.delete(layer);
    if (!overlays || !document.body) return;
    const points = [];
    for (const m of document.querySelectorAll(MEDIA)) {
      const r = m.getBoundingClientRect();
      if (r.width < 120 || r.height < 80 || r.bottom < 0 || r.top > innerHeight) continue;
      points.push([r.left + r.width / 2, r.top + r.height / 2], [r.left + r.width * 0.25, r.top + r.height * 0.75]);
    }
    for (const [x, y] of points) {
      for (let i = 0; i < 5; i++) {
        const top = document.elementFromPoint(x, y);
        if (!top || top.matches(MEDIA)) break;
        const layer = invisibleLayer(top, false);
        if (!layer) break;
        if (neutralize(layer)) report('overlay', 'invisible layer over the player');
        else if (layer.style.getPropertyValue('pointer-events') !== 'none') break;
      }
    }
  }

  let scanQueued = false;
  function queueScan() {
    if (scanQueued) return;
    scanQueued = true;
    setTimeout(() => { scanQueued = false; safely(scan); }, SCAN_GAP_MS);
  }

  // --- Clicks ----------------------------------------------------------------------------------

  function pressed(e) {
    if (!e.isTrusted || !blocking) return;
    const target = e.composedPath?.()[0] || e.target;
    if (!(target instanceof Element)) return;
    if (lastPress && lastPress.target === target && performance.now() - lastPress.time < PRESS_MS) {
      lastPress.time = performance.now();
      return;
    }
    lastPress = { target, time: performance.now(), overlay: invisibleLayer(target, true) };
    if (e.type !== 'click') trace('press', { on: describe(target), invisibleLayer: lastPress.overlay ? describe(lastPress.overlay) : '' });
  }
  for (const type of ['pointerdown', 'mousedown', 'touchstart', 'click']) {
    listen(window, type, (e) => safely(() => pressed(e)), { capture: true, passive: true });
  }

  // A click straight on an invisible link to another site.
  listen(window, 'click', (e) => safely(() => {
    if (!e.isTrusted || !blocking) return;
    const target = e.composedPath?.()[0] || e.target;
    const link = target instanceof Element && target.closest('a[href]');
    if (!link || !isOtherSite(parse(link.href)) || isAllowedDestination(parse(link.href))) return;
    const layer = invisibleLayer(link, true);
    if (!layer) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    neutralize(layer);
    suspect();
    trace('blocked invisible link', { to: cleanUrl(link.href), layer: describe(layer) });
    report('link', 'invisible link', link.href);
  }), { capture: true });

  function recentPress() {
    return lastPress && performance.now() - lastPress.time < PRESS_MS ? lastPress : null;
  }

  function isPageWide(target) {
    return target === window || target === document || target === document.documentElement || target === document.body;
  }

  // Why a pop-up (or a new-tab link click made by script) to `url` should be blocked, or '' when
  // it shouldn't.
  function blockReason(url) {
    if (!blocking) return '';
    const dest = parse(url);
    const event = window.event;
    const pageWide = !event || isPageWide(event.currentTarget);
    if (!isOtherSite(dest)) {
      // Same site is fine, but a page-wide handler opening it may be about to redirect this tab.
      if (pageWide && recentPress()) suspect();
      return '';
    }
    if (isAllowedDestination(dest)) return '';
    const press = recentPress();
    if (press?.overlay) return 'opened from an invisible layer';
    const link = press?.target.closest?.('a[href]');
    if (link && dest && /^https?:$/.test(dest.protocol) && siteOf(parse(link.href)?.hostname) === siteOf(dest.hostname)) return '';
    if (event) return pageWide ? 'opened by a page-wide click handler' : '';
    // Called outside an event (after a timer or a promise): allow only right after a click on
    // a visible button or link.
    const control = press?.target.closest?.('a[href], button, [role="button"], input[type="button"], input[type="submit"]');
    return !control || invisibleLayer(control, true) ? 'opened without a click on a button or link' : '';
  }

  function blocked(kind, reason, url) {
    suspect();
    const press = recentPress();
    if (press?.overlay) neutralize(press.overlay);
    report(kind, reason, url);
  }

  // Every wrapper decides inside safely(): if the guard itself fails, the page gets the real thing.
  const guardOpen = (original, owner) => wrap(original, (target, _this, args) => {
    const reason = blocking && safely(() => blockReason(args[0]));
    safely(() => trace('window.open', { to: cleanUrl(args[0]), blocked: reason || '', guardOn: blocking, during: window.event?.type || 'no event (timer/promise)', handlerOn: window.event ? describe(window.event.currentTarget) : '' }));
    if (reason) {
      safely(() => blocked('popup', reason, args[0]));
      const fake = safely(() => decoy(args));
      if (fake) return fake;
    }
    return Reflect.apply(target, owner, args);
  });

  window.open = guardOpen(native.open, window);

  // Ad scripts borrow open() from a fresh iframe to get around a wrapped window.open.
  Object.defineProperty(HTMLIFrameElement.prototype, 'contentWindow', {
    configurable: true,
    enumerable: true,
    get: wrap(native.contentWindow, (target, frame, args) => {
      const win = Reflect.apply(target, frame, args);
      try {
        if (win && !patchedWindows.has(win)) {
          patchedWindows.add(win);
          win.open = guardOpen(win.open, win);
        }
      } catch { /* cross-origin frame: it has its own guard */ }
      return win;
    }),
  });

  // Links clicked by script (a.click(), or a dispatched click event) can open new tabs too.
  function scriptedLinkClick(el) {
    const link = el instanceof Element && el.closest('a[href], area[href]');
    if (!link) return false;
    const newTab = link.target && link.target !== '_self' && link.target !== '_top' && link.target !== '_parent';
    if (!newTab && performance.now() > suspectUntil && !recentPress()?.overlay) return false;
    const reason = blockReason(link.href);
    trace('link clicked by script', { to: cleanUrl(link.href), newTab, blocked: reason || '' });
    if (!reason) return false;
    blocked('popup', reason, link.href);
    return true;
  }

  HTMLElement.prototype.click = wrap(native.click, (target, el, args) => {
    if (blocking && safely(() => scriptedLinkClick(el))) return undefined;
    return Reflect.apply(target, el, args);
  });

  EventTarget.prototype.dispatchEvent = wrap(native.dispatchEvent, (target, el, args) => {
    if (blocking && args[0]?.type === 'click' && el instanceof Element && safely(() => scriptedLinkClick(el))) return false;
    return Reflect.apply(target, el, args);
  });

  // --- Start -----------------------------------------------------------------------------------

  // Scans are cheap and skip frames without a player; still, they slow down after a while.
  function scanLoop() {
    if (document.visibilityState === 'visible') safely(scan);
    setTimeout(scanLoop, performance.now() - startedAt < FAST_FOR_MS ? SCAN_FAST_MS : SCAN_SLOW_MS);
  }

  function start() {
    new MutationObserver(() => overlays && queueScan()).observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(scanLoop, SCAN_FAST_MS);
  }
  if (document.documentElement) start();
  else listen(document, 'readystatechange', start, { once: true });
})();
