// Pop-up handling in the background (loaded by background.js). The page-side guard
// (popup-guard.js) stops pop-ups by how they were opened; this file checks them by where they
// go, which can't break a page because the page never sees anything fail:
//   - A new tab opened from a page is watched while it loads and redirects (event-driven, at
//     most POPUP_WATCH_MS) and closed when it lands on a known pop-up ad network
//     (vendor/popup-domains/domains.json, from EasyList and AdGuard; like uBlock Origin's
//     $popup filters). A tab for the link you just clicked is left alone.
//   - Pop-unders: a page opens a copy of itself in a new tab, then sends the original tab to an
//     ad network. The original tab is sent back, and the copy closed if you haven't switched to it.
// Recovery, so a mistake never sticks:
//   - The popup shows the last blocked pop-up on a tab (host, reason, time) with "Open it".
//     Opening it allows that destination from that site from then on (a narrow exception).
//     Trusting the whole site is a separate, explicit choice in the popup.
//   - Exceptions: destinations that must always open and sites whose own pop-ups are legitimate
//     (vendor/popup-domains/exceptions.json and the hand-kept popup-exceptions.json).
// Every listener fails open: if something goes wrong here, the tab is left alone.

const POPUP_WATCH_MS = 30000;   // longest a new tab is watched
const POPUP_QUIET_MS = 5000;    // stop watching this long after it finished loading a normal page
const POPUNDER_MS = 15000;      // a pop-under redirect must follow the new tab this closely
const MAX_TRACKED = 200;        // bound on watched tabs and remembered clicks
const MAX_PAIRS_PER_SITE = 50;  // bound on destinations allowed per site by "Open it"

const lastClicked = new Map();   // opener tab -> { href, at }
const watchedPopups = new Map(); // new tab -> { opener, until, loadedAt }
const recentOpens = new Map();   // opener tab -> { tabId, at, openerUrl }
const keepTabRecordsUntil = new Map(); // tab sent back from a pop-under: keep its 'blocked' record (background.js)
let popupLists = null;

function getPopupLists() {
  const json = (path) => fetch(chrome.runtime.getURL(path)).then((res) => res.json());
  popupLists ||= Promise.all([json('vendor/popup-domains/domains.json'), json('vendor/popup-domains/exceptions.json'), json('popup-exceptions.json')])
    .then(([hosts, listed, own]) => ({
      hosts: new Set(hosts),
      allowTo: [...new Set([...listed.allowTo, ...own.allowTo])],
      allowFrom: own.allowFrom,
    }))
    .catch((e) => {
      popupLists = null; // try again next time; meanwhile nothing is closed
      throw e;
    });
  return popupLists;
}

// The host or one of its parent domains is in the set.
function hostIn(set, host) {
  for (let h = (host || '').toLowerCase(); h.includes('.'); h = h.slice(h.indexOf('.') + 1)) if (set.has(h)) return true;
  return false;
}

function hostOfUrl(url) {
  try {
    const { protocol, hostname } = new URL(url);
    return /^https?:$/.test(protocol) ? normalizeHost(hostname) : '';
  } catch {
    return '';
  }
}

// --- Problem log ------------------------------------------------------------------------------
// Per tab, what happened with the tabs it opened (kept across page loads in the tab, removed when
// the tab closes). Only read by the popup's "Save a log". Addresses: origin + path only.
const TAB_LOG_MAX = 40;
let tabLogUpdate = Promise.resolve();
function cleanUrl(url) {
  try {
    const u = new URL(url);
    return /^https?:$/.test(u.protocol) ? (u.origin + u.pathname).slice(0, 200) : u.protocol;
  } catch {
    return '';
  }
}
function tabLog(tabId, what, detail = {}) {
  if (!Number.isInteger(tabId) || tabId < 0) return;
  tabLogUpdate = tabLogUpdate.then(async () => {
    const key = `tablog_${tabId}`;
    const { [key]: log = [] } = await chrome.storage.session.get(key);
    const prev = log[log.length - 1];
    if (prev && prev.what === what && prev.to === detail.to && prev.tab === detail.tab) return; // same step seen by several listeners
    await chrome.storage.session.set({ [key]: [...log, { at: Date.now(), what, ...detail }].slice(-TAB_LOG_MAX) });
  }).catch(() => {});
}

// Everything the background knows about a tab, for the popup's "Save a log".
async function backgroundLog(tabId) {
  const keys = [`tab_${tabId}`, `popups_${tabId}`, `lastBlocked_${tabId}`, `tablog_${tabId}`, 'recent'];
  const stored = await chrome.storage.session.get(keys);
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  const settings = await chrome.storage.sync.get(COOKIE_DENIER_DEFAULTS);
  const host = hostOfUrl(tab?.url);
  const { popups, overlays, allowTo, lists } = await popupSettingsFor(host);
  const { popupPairs = {}, popupRestores = {}, total = 0, popupTotal = 0 } = await chrome.storage.local.get(['popupPairs', 'popupRestores', 'total', 'popupTotal']);
  const last = stored[`lastBlocked_${tabId}`];
  const site = siteOf(host);
  return {
    settings,
    forThisSite: { popups, overlays, allowedDestinations: allowTo.length, openItAllowed: popupPairs[site] || [], restores: popupRestores[site] || 0, adNetworkHostsLoaded: lists.hosts.size },
    cookieResult: stored[`tab_${tabId}`] || null,
    popupsBlockedOnPage: stored[`popups_${tabId}`] || 0,
    lastBlocked: last ? { host: last.host, kind: last.kind, reason: last.reason, secondsAgo: Math.round((Date.now() - last.at) / 1000) } : null,
    tabEvents: stored[`tablog_${tabId}`] || [],
    recentCookieActionsOnSite: (stored.recent || []).filter((r) => hostOfUrl(r.url) === host).slice(0, 10).map((r) => ({ cmp: r.cmp, method: r.method, frame: cleanUrl(r.frame), secondsAgo: Math.round((Date.now() - r.at) / 1000) })),
    watchedNow: watchedPopups.size,
    totals: { bannersDenied: total, popupsBlocked: popupTotal },
  };
}

// Keeps a Map below MAX_TRACKED entries by dropping the oldest.
function bounded(map) {
  while (map.size > MAX_TRACKED) map.delete(map.keys().next().value);
}

// --- Settings for a site --------------------------------------------------------------------

async function popupSettingsFor(host) {
  const settings = await chrome.storage.sync.get(COOKIE_DENIER_DEFAULTS);
  const lists = await getPopupLists().catch(() => ({ hosts: new Set(), allowTo: [], allowFrom: [] }));
  const on = settings.enabled && settings.blockPopups && !(host && isSiteDisabled(host, settings.disabledSites));
  const { popupPairs = {} } = await chrome.storage.local.get('popupPairs');
  const site = siteOf(normalizeHost(host));
  return {
    popups: on && !(host && (isSiteDisabled(host, settings.popupAllowedSites) || isSiteDisabled(host, lists.allowFrom))),
    overlays: on && !(host && isSiteDisabled(host, settings.overlayAllowedSites)),
    allowTo: [...lists.allowTo, ...(popupPairs[site] || [])],
    lists,
  };
}

// What popups.js passes to the in-page guard.
async function popupConfig(host) {
  const { popups, overlays, allowTo } = await popupSettingsFor(typeof host === 'string' ? host : '');
  return { popups, overlays, allowTo };
}

// --- Counting and recovery ------------------------------------------------------------------

function countBlockedPopup(tabId, kind, reason, url) {
  bump('session', `popups_${tabId}`);
  bump('local', 'popupTotal');
  const host = hostOfUrl(url);
  if (host) chrome.storage.session.set({ [`lastBlocked_${tabId}`]: { url, host, kind, reason, at: Date.now() } });
  tabLog(tabId, 'blocked', { kind, reason, to: cleanUrl(url) });
}

// "Open it" in the popup: opens the last blocked pop-up of a tab after all, and allows that
// destination from that site from then on. Only the URL Turndown recorded can be opened.
async function openBlockedPopup(tabId) {
  const key = `lastBlocked_${tabId}`;
  const last = (await chrome.storage.session.get(key))[key];
  if (!last || !/^https?:\/\//.test(last.url)) return { opened: false };
  const opener = await chrome.tabs.get(tabId).catch(() => null);
  await chrome.tabs.create({ url: last.url, openerTabId: opener ? tabId : undefined, index: opener ? opener.index + 1 : undefined });
  await chrome.storage.session.remove(key);
  const site = siteOf(hostOfUrl(opener?.url));
  if (!site) return { opened: true };
  const { popupPairs = {}, popupRestores = {} } = await chrome.storage.local.get(['popupPairs', 'popupRestores']);
  const allowed = new Set(popupPairs[site] || []);
  allowed.add(last.host);
  popupPairs[site] = [...allowed].slice(-MAX_PAIRS_PER_SITE);
  popupRestores[site] = (popupRestores[site] || 0) + 1;
  await chrome.storage.local.set({ popupPairs, popupRestores });
  return { opened: true, host: last.host, restoresOnSite: popupRestores[site] };
}

// "Trust this site" in the popup: no pop-up blocking there any more.
async function trustPopupSite(host) {
  host = normalizeHost(host);
  if (!host) return false;
  const { popupAllowedSites } = await chrome.storage.sync.get(COOKIE_DENIER_DEFAULTS);
  if (!isSiteDisabled(host, popupAllowedSites)) await chrome.storage.sync.set({ popupAllowedSites: [...popupAllowedSites, host] });
  return true;
}

// Messages about pop-ups, from the content scripts and the popup. Returns undefined for other
// message types, so background.js can handle those.
function handlePopupMessage(msg, sender, sendResponse) {
  // Only the extension's own pages (the popup) have an extension URL; content scripts report the page's.
  const fromPopup = sender.id === chrome.runtime.id && sender.url?.startsWith(chrome.runtime.getURL(''));
  switch (msg?.type) {
    case 'popup':
      if (sender.tab) countBlockedPopup(sender.tab.id, String(msg.kind).slice(0, 40), String(msg.reason || '').slice(0, 120), typeof msg.url === 'string' ? msg.url.slice(0, 2048) : '');
      return false;
    case 'popup:clicked':
      if (sender.tab && typeof msg.href === 'string') {
        lastClicked.set(sender.tab.id, { href: msg.href, at: Date.now() });
        bounded(lastClicked);
      }
      return false;
    case 'popup:config':
      popupConfig(msg.host).then(sendResponse, () => sendResponse(null));
      return true;
    case 'popup:openAnyway':
      if (!fromPopup || !Number.isInteger(msg.tabId)) return false;
      openBlockedPopup(msg.tabId).then(sendResponse, () => sendResponse({ opened: false }));
      return true;
    case 'log:background':
      if (!fromPopup || !Number.isInteger(msg.tabId)) return false;
      backgroundLog(msg.tabId).then(sendResponse, (e) => sendResponse({ error: String(e?.message || e) }));
      return true;
    case 'popup:trustSite':
      if (!fromPopup) return false;
      trustPopupSite(String(msg.host || '')).then(sendResponse, () => sendResponse(false));
      return true;
    default:
      return undefined;
  }
}

// --- Destination check ----------------------------------------------------------------------

async function checkPopupTab(tabId, url) {
  const watch = watchedPopups.get(tabId);
  if (!watch) return;
  if (Date.now() > watch.until) return watchedPopups.delete(tabId);
  const host = hostOfUrl(url);
  if (!host) return;
  const { hosts, allowTo } = await getPopupLists();
  if (!hostIn(hosts, host) || hostIn(new Set(allowTo), host)) {
    tabLog(watch.opener, 'watched tab went to', { tab: tabId, to: cleanUrl(url), knownAdNetwork: hostIn(hosts, host), exception: hostIn(new Set(allowTo), host) });
    return;
  }
  watchedPopups.delete(tabId);
  await chrome.tabs.remove(tabId);
  countBlockedPopup(watch.opener, 'ad network', 'pop-up landed on a known pop-up ad network', url);
}

const failOpen = (fn) => (...args) => Promise.resolve().then(() => fn(...args)).catch(() => {});

chrome.webNavigation.onCreatedNavigationTarget.addListener(failOpen(async ({ sourceTabId, tabId, url }) => {
  const opener = await chrome.tabs.get(sourceTabId).catch(() => null);
  const openerHost = hostOfUrl(opener?.url);
  const { popups } = await popupSettingsFor(openerHost);
  if (!popups) {
    tabLog(sourceTabId, 'new tab opened (pop-up blocking off here)', { to: cleanUrl(url) });
    return;
  }
  recentOpens.set(sourceTabId, { tabId, at: Date.now(), openerUrl: opener?.url || '' });
  bounded(recentOpens);
  const click = lastClicked.get(sourceTabId);
  if (click && Date.now() - click.at < 3000 && click.href === url) {
    tabLog(sourceTabId, 'new tab for the link you clicked (left alone)', { to: cleanUrl(url) });
    return;
  }
  tabLog(sourceTabId, 'new tab opened, watching where it goes', { tab: tabId, to: cleanUrl(url) });
  watchedPopups.set(tabId, { opener: sourceTabId, until: Date.now() + POPUP_WATCH_MS, loadedAt: 0 });
  bounded(watchedPopups);
  await checkPopupTab(tabId, url);
}));

chrome.webNavigation.onBeforeNavigate.addListener(failOpen(({ tabId, frameId, url }) => frameId === 0 && checkPopupTab(tabId, url)));
chrome.webNavigation.onCommitted.addListener(failOpen(async ({ tabId, frameId, url, transitionType, transitionQualifiers }) => {
  if (frameId !== 0) return;
  await checkPopupTab(tabId, url);
  await checkPopunder(tabId, url, transitionType, transitionQualifiers);
}));
chrome.tabs.onUpdated.addListener(failOpen(async (tabId, info, tab) => {
  if (info.url) await checkPopupTab(tabId, info.url);
  // Event-driven end of watching: a normal page finished loading and stayed quiet.
  const watch = watchedPopups.get(tabId);
  if (watch && info.status === 'complete' && hostOfUrl(tab?.url)) {
    watch.until = Math.min(watch.until, Date.now() + POPUP_QUIET_MS);
  }
}));
chrome.tabs.onRemoved.addListener((tabId) => {
  lastClicked.delete(tabId);
  watchedPopups.delete(tabId);
  recentOpens.delete(tabId);
  keepTabRecordsUntil.delete(tabId);
});

// --- Pop-unders ----------------------------------------------------------------------------

// The tab that opened a pop-up shortly before is now on a pop-up ad network, and not because you
// typed an address or reloaded: send it back, and close the copy it opened unless you're in it.
async function checkPopunder(tabId, url, transitionType, qualifiers = []) {
  const open = recentOpens.get(tabId);
  if (!open || Date.now() - open.at > POPUNDER_MS) return;
  if (['typed', 'auto_bookmark', 'reload', 'generated', 'keyword'].includes(transitionType) || qualifiers.includes('from_address_bar') || qualifiers.includes('forward_back')) return;
  const host = hostOfUrl(url);
  const { hosts, allowTo } = await getPopupLists();
  if (!host || !hostIn(hosts, host) || hostIn(new Set(allowTo), host)) return;
  recentOpens.delete(tabId);
  keepTabRecordsUntil.set(tabId, Date.now() + 5000);
  bounded(keepTabRecordsUntil);
  try {
    await chrome.tabs.goBack(tabId);
  } catch {
    if (open.openerUrl) await chrome.tabs.update(tabId, { url: open.openerUrl });
  }
  const copy = await chrome.tabs.get(open.tabId).catch(() => null);
  if (copy && !copy.active && siteOf(hostOfUrl(copy.url || copy.pendingUrl)) === siteOf(hostOfUrl(open.openerUrl))) {
    await chrome.tabs.remove(copy.id).catch(() => {});
  }
  await chrome.tabs.update(tabId, { active: true }).catch(() => {});
  countBlockedPopup(tabId, 'pop-under', 'this tab was sent to a pop-up ad network', url);
}
