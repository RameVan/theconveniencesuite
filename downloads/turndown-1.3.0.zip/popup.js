const $ = (id) => document.getElementById(id);

function hostOf(url) {
  try {
    const { protocol, hostname } = new URL(url);
    return /^https?:$/.test(protocol) ? normalizeHost(hostname) : null;
  } catch {
    return null;
  }
}

function describe({ cmp, method }) {
  const banner = cmp ? `the ${cmp} banner` : 'a cookie banner';
  if (method === 'preferences') return `Switched off every purpose, vendor and legitimate interest in ${banner}.`;
  if (method === 'hidden') return `Hid ${banner} (it had no reject option).`;
  return `Rejected ${banner} on this page.`;
}

async function save(changes) {
  await chrome.storage.sync.set(changes);
  $('hint').hidden = false;
}

const REPORT_TO = 'rame@theconveniencesuite.com';

const BLOCKED_KINDS = {
  popup: 'Pop-up blocked in the page',
  link: 'Invisible link blocked',
  redirect: 'Redirect blocked',
  'ad network': 'Pop-up tab closed',
  'pop-under': 'Pop-under undone',
};

function ago(at) {
  const s = Math.round((Date.now() - at) / 1000);
  return s < 60 ? `${s} s ago` : `${Math.round(s / 60)} min ago`;
}

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const host = hostOf(tab?.url);
  const settings = await chrome.storage.sync.get(COOKIE_DENIER_DEFAULTS);

  // Pop-up and layer settings apply to the open page right away, no reload needed.
  async function saveForPage(changes) {
    await chrome.storage.sync.set(changes);
    if (tab?.id != null) chrome.tabs.sendMessage(tab.id, { type: 'popup:settingsChanged' }).catch(() => {});
  }

  // Adds or removes the current site in one of the per-site lists.
  async function toggleSite(listName, on, saver) {
    const lists = await chrome.storage.sync.get(COOKIE_DENIER_DEFAULTS);
    const others = lists[listName].filter((site) => !isSiteDisabled(host, [site]));
    await saver({ [listName]: on ? others : [...others, host] });
  }

  $('enabled').checked = settings.enabled;
  $('thorough').checked = settings.thorough;
  $('hideFallback').checked = settings.hideFallback;
  $('blockPopups').checked = settings.blockPopups;
  if (host) {
    $('site').textContent = host;
    for (const el of document.querySelectorAll('.siteName')) el.textContent = host;
    $('siteEnabled').checked = !isSiteDisabled(host, settings.disabledSites);
    $('sitePopups').checked = !isSiteDisabled(host, settings.popupAllowedSites);
    $('siteOverlays').checked = !isSiteDisabled(host, settings.overlayAllowedSites);
  } else {
    $('siteRow').hidden = true;
  }
  $('sitePopupRows').hidden = !host || !settings.blockPopups;

  $('enabled').addEventListener('change', (e) => save({ enabled: e.target.checked }));
  $('thorough').addEventListener('change', (e) => save({ thorough: e.target.checked }));
  $('hideFallback').addEventListener('change', (e) => save({ hideFallback: e.target.checked }));
  $('blockPopups').addEventListener('change', (e) => {
    $('sitePopupRows').hidden = !host || !e.target.checked;
    saveForPage({ blockPopups: e.target.checked });
  });
  $('siteEnabled').addEventListener('change', (e) => toggleSite('disabledSites', e.target.checked, save));
  // These two leave cookie handling (and each other) on.
  $('sitePopups').addEventListener('change', (e) => toggleSite('popupAllowedSites', e.target.checked, saveForPage));
  $('siteOverlays').addEventListener('change', (e) => toggleSite('overlayAllowedSites', e.target.checked, saveForPage));

  const { total, popupTotal } = await chrome.storage.local.get({ total: 0, popupTotal: 0 });
  $('total').textContent = total;
  $('popupTotal').textContent = popupTotal;

  const key = `tab_${tab?.id}`;
  const result = (await chrome.storage.session.get(key))[key];
  if (result) $('status').textContent = describe(result);

  const popupKey = `popups_${tab?.id}`;
  const lastKey = `lastBlocked_${tab?.id}`;
  const stored = await chrome.storage.session.get([popupKey, lastKey]);
  const popups = stored[popupKey];
  if (popups) {
    $('popupCount').textContent = `Blocked ${popups} pop-up${popups === 1 ? '' : 's'}, redirect${popups === 1 ? '' : 's'} or invisible link${popups === 1 ? '' : 's'} on this page.`;
    $('popupStatus').hidden = false;
  }

  // The last blocked pop-up, in case it was one you wanted. Only its host is shown, never the
  // full address (it can hold sign-in or payment details).
  const last = stored[lastKey];
  if (!last?.host) return;
  $('lastBlockedHost').textContent = last.host;
  $('lastBlockedWhy').textContent = `${BLOCKED_KINDS[last.kind] || 'Blocked'}${last.reason ? `: ${last.reason}` : ''}, ${ago(last.at)}`;
  $('lastBlocked').hidden = false;
  $('popupStatus').hidden = false;
  $('trustSite').hidden = !host;

  $('openBlocked').addEventListener('click', async () => {
    $('openBlocked').disabled = true;
    const opened = await chrome.runtime.sendMessage({ type: 'popup:openAnyway', tabId: tab.id });
    if (!opened?.opened) return;
    $('openBlocked').hidden = true;
    $('popupNote').textContent = opened.restoresOnSite >= 2
      ? `Opened. Pop-ups to ${opened.host} are allowed on ${host} from now on. You've opened ${opened.restoresOnSite} blocked pop-ups here; if they're all ones you want, choose "Trust this site".`
      : `Opened. Pop-ups to ${opened.host} are allowed on ${host} from now on.`;
    $('popupNote').hidden = false;
  });

  $('trustSite').addEventListener('click', async () => {
    await chrome.runtime.sendMessage({ type: 'popup:trustSite', host });
    if (tab?.id != null) chrome.tabs.sendMessage(tab.id, { type: 'popup:settingsChanged' }).catch(() => {});
    $('sitePopups').checked = false;
    $('trustSite').disabled = true;
    $('popupNote').textContent = `Pop-ups are allowed on ${host} now. Switch "Block pop-ups on ${host}" back on to undo this.`;
    $('popupNote').hidden = false;
  });

  // A prefilled e-mail with what was blocked (host and reason only), for a false positive.
  const body = [
    `Turndown ${chrome.runtime.getManifest().version} blocked something I wanted.`,
    '',
    `Site: ${host || '(unknown)'}`,
    `Blocked: ${last.host}`,
    `What: ${BLOCKED_KINDS[last.kind] || last.kind}${last.reason ? ` (${last.reason})` : ''}`,
    '',
    'What I was trying to do:',
  ].join('\n');
  $('reportBlocked').href = `mailto:${REPORT_TO}?subject=${encodeURIComponent(`Turndown blocked a pop-up on ${host || 'a site'}`)}&body=${encodeURIComponent(body)}`;
  $('reportBlocked').target = '_blank';
}

// --- Problem log ---------------------------------------------------------------------------------
// "Save a log": everything Turndown saw and did on this page, from every frame, plus a screenshot,
// saved as one JSON file in the Downloads folder (nothing is sent anywhere). Addresses are cut to
// origin + path, so query strings with sign-in or payment details never end up in it.

function cleanUrl(url) {
  try {
    const u = new URL(url);
    return /^https?:$/.test(u.protocol) ? (u.origin + u.pathname).slice(0, 300) : u.protocol;
  } catch {
    return '';
  }
}

// Runs in each frame's isolated world, where content.js and popups.js keep their diagnostics.
function collectFrame() {
  const run = (fn, missing) => {
    if (typeof fn !== 'function') return missing;
    try { return fn(); } catch (e) { return `error: ${e?.message || e}`; }
  };
  return {
    cookies: run(window.__turndownCookieDiagnose, 'Turndown is not running in this frame'),
    popups: run(window.__turndownPopupDiagnose, 'Turndown is not running in this frame'),
  };
}

async function buildLog(tab, problem, note) {
  const [background, injected, frames, screenshot] = await Promise.all([
    chrome.runtime.sendMessage({ type: 'log:background', tabId: tab.id }).then((r) => r ?? { error: 'no answer' }, (e) => ({ error: String(e?.message || e) })),
    chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: collectFrame })
      .catch((e) => [{ frameId: 0, error: String(e?.message || e) }]),
    chrome.webNavigation.getAllFrames({ tabId: tab.id }).catch(() => []),
    chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 70 }).catch((e) => `no screenshot: ${e?.message || e}`),
  ]);
  const byId = new Map((frames || []).map((f) => [f.frameId, f]));
  return {
    turndownLog: 1,
    problem,
    note,
    savedAt: new Date().toISOString(),
    version: chrome.runtime.getManifest().version,
    browser: navigator.userAgent,
    page: { url: cleanUrl(tab.url), title: (tab.title || '').slice(0, 200) },
    background,
    frames: (injected || []).map((r) => ({
      frameId: r.frameId,
      parentFrameId: byId.get(r.frameId)?.parentFrameId,
      url: cleanUrl(byId.get(r.frameId)?.url || ''),
      ...(r.error ? { error: r.error } : r.result || { error: 'no answer' }),
    })),
    // Frames the scripts couldn't reach (blank or sandboxed frames, for example).
    otherFrames: (frames || []).filter((f) => !(injected || []).some((r) => r.frameId === f.frameId))
      .map((f) => ({ frameId: f.frameId, parentFrameId: f.parentFrameId, url: cleanUrl(f.url) })),
    screenshot,
  };
}

function saveFile(name, text) {
  const url = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}

async function setupLog() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const host = hostOf(tab?.url);
  if (!host) {
    $('logBox').hidden = true;
    return;
  }
  const save = async (problem) => {
    for (const b of [$('logCookie'), $('logPopup')]) b.disabled = true;
    $('logNote').classList.remove('done');
    $('logNote').textContent = 'Collecting…';
    try {
      const log = await buildLog(tab, problem, $('logNoteInput').value.trim().slice(0, 300));
      const stamp = log.savedAt.replace(/[-:]/g, '').replace('T', '-').slice(0, 15);
      const name = `turndown-log-${problem}-${host.replace(/[^a-z0-9.-]/gi, '_')}-${stamp}.json`;
      saveFile(name, JSON.stringify(log, null, 1));
      $('logNote').textContent = `Saved ${name} to your Downloads folder.`;
      $('logNote').classList.add('done');
    } catch (e) {
      $('logNote').textContent = `Couldn't save the log: ${e?.message || e}`;
    } finally {
      for (const b of [$('logCookie'), $('logPopup')]) b.disabled = false;
    }
  };
  $('logCookie').addEventListener('click', () => save('cookie-banner'));
  $('logPopup').addEventListener('click', () => save('popups'));
}

// --- Updates -------------------------------------------------------------------------------------
// Turndown is installed unpacked from a zip, so the browser can't update it by itself. When the
// popup opens it reads one small file from the website (no data is sent with it) and offers the
// newer zip; after unzipping it over the old folder, "Reload Turndown" loads the new files.

const UPDATE_FEED = 'https://theconveniencesuite.com/downloads/turndown-latest.json';
const UPDATE_CHECK_MS = 60 * 60 * 1000; // ask the website at most once an hour

function isNewer(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0);
  return false;
}

// Only a well-formed answer that points at a zip on the suite's own site is used.
function validFeed(feed) {
  if (!feed || !/^\d+\.\d+\.\d+$/.test(feed.version)) return null;
  try {
    const url = new URL(feed.url);
    if (url.protocol !== 'https:' || url.hostname !== 'theconveniencesuite.com' || !/^\/downloads\/turndown-\d+\.\d+\.\d+\.zip$/.test(url.pathname)) return null;
    return { version: feed.version, url: url.href };
  } catch {
    return null;
  }
}

async function latestRelease() {
  const { updateCheck } = await chrome.storage.local.get('updateCheck');
  if (updateCheck && Date.now() - updateCheck.at < UPDATE_CHECK_MS) return updateCheck.feed;
  const res = await fetch(UPDATE_FEED, { cache: 'no-store', credentials: 'omit', signal: AbortSignal.timeout(5000) });
  const feed = res.ok ? validFeed(await res.json()) : null;
  await chrome.storage.local.set({ updateCheck: { at: Date.now(), feed } });
  return feed;
}

async function setupUpdate() {
  const current = chrome.runtime.getManifest().version;
  $('version').textContent = current;
  $('reloadButton').addEventListener('click', () => chrome.runtime.reload());
  // An unpacked install picks up changed files on a reload, so the button is always useful there.
  const self = await chrome.management?.getSelf?.().catch(() => null);
  if (self?.installType === 'development') $('reloadButton').hidden = false;

  const feed = await latestRelease().catch(() => null);
  if (!feed) return;
  if (!isNewer(feed.version, current)) {
    $('updateStatus').textContent = `Turndown ${current} · up to date`;
    return;
  }
  $('updateStatus').textContent = `Turndown ${feed.version} is available (you have ${current})`;
  $('update').classList.add('available');
  $('updateButton').hidden = false;
  $('updateButton').addEventListener('click', () => {
    chrome.tabs.create({ url: feed.url, active: false });
    $('updateButton').textContent = 'Downloading…';
    $('updateButton').disabled = true;
    $('updateSteps').hidden = false;
    $('reloadButton').hidden = false;
  });
}

init();
setupLog();
setupUpdate();
