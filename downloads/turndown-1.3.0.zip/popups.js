// Isolated-world side of the pop-up guard (popup-guard.js runs in the page's own world, where it
// can't read the extension's settings). Passes the guard this site's settings and the
// destinations that must always open (again whenever they change, so no reload is needed),
// refuses redirects right after a blocked pop-up (here the page can't remove the listener),
// tells the background script which link was really clicked, and reports what was blocked.
(() => {
  'use strict';
  if (window.__turndownPopupsLoaded) return;
  window.__turndownPopupsLoaded = true;

  let config = { popups: false, overlays: false, allowTo: [] };
  let suspectUntil = 0;

  function send(msg) {
    try {
      return chrome.runtime.sendMessage(msg)?.catch?.(() => null);
    } catch { /* extension was reloaded; nothing to report to */ }
    return Promise.resolve(null);
  }

  // The guard's recent decisions, for the popup's "Save a log" (never sent anywhere else).
  const TRACE_MAX = 60;
  const trace = [];
  const loadedAt = Date.now();
  function note(what, detail) {
    trace.push({ ms: Date.now() - loadedAt, what, ...detail });
    if (trace.length > TRACE_MAX) trace.shift();
  }
  addEventListener('turndown:trace', (e) => {
    try {
      const d = e.detail || {};
      const entry = {};
      for (const [k, v] of Object.entries(d)) if (k !== 'what') entry[k] = typeof v === 'string' ? v.slice(0, 200) : typeof v === 'boolean' || typeof v === 'number' ? v : String(v);
      note(String(d.what).slice(0, 40), entry);
    } catch { /* ignore a malformed entry */ }
  });

  // Called by the popup through chrome.scripting (isolated world: the page can't call it).
  window.__turndownPopupDiagnose = () => {
    let guard = null;
    const take = (e) => { guard = e.detail; };
    addEventListener('turndown:diagnose', take);
    try {
      dispatchEvent(new CustomEvent('turndown:diagnose-request'));
    } finally {
      removeEventListener('turndown:diagnose', take);
    }
    let parsed = null;
    try { parsed = typeof guard === 'string' ? JSON.parse(guard) : null; } catch { /* leave null */ }
    return {
      frame: (location.origin + location.pathname).slice(0, 200),
      top: window === window.top,
      config: { popups: config.popups, overlays: config.overlays, allowTo: config.allowTo.length },
      redirectGuardUntil: suspectUntil > Date.now() ? suspectUntil - Date.now() : 0,
      guard: parsed || 'the in-page guard did not answer (not running in this frame?)',
      trace: trace.slice(),
    };
  };

  addEventListener('turndown:popup-blocked', (e) => {
    const { kind, reason, url } = e.detail || {};
    note('reported blocked', { kind: String(kind), reason: String(reason || ''), to: typeof url === 'string' ? url.split(/[?#]/)[0].slice(0, 200) : '' });
    send({ type: 'popup', kind: String(kind), reason: String(reason || ''), url: typeof url === 'string' ? url : '' });
  });
  addEventListener('turndown:suspect', (e) => {
    suspectUntil = Math.max(suspectUntil, Math.min(Number(e.detail) || 0, Date.now() + 5000));
  });

  // A new tab that matches the link you clicked is never closed by the background script.
  addEventListener('click', (e) => {
    if (!e.isTrusted) return;
    const link = (e.composedPath?.()[0] || e.target)?.closest?.('a[href]');
    if (link) send({ type: 'popup:clicked', href: link.href });
  }, { capture: true, passive: true });

  function hostAllowed(host) {
    if (POPUP_TRUSTED_SITES.includes(siteOf(host))) return true;
    for (let h = host.toLowerCase(); h.includes('.'); h = h.slice(h.indexOf('.') + 1)) if (config.allowTo.includes(h)) return true;
    return false;
  }

  // After a blocked pop-up, don't let the page send this tab to another site instead. Same-site,
  // sign-in, payment and other allowed destinations, form submissions, downloads, reloads and
  // back/forward are never touched, nor is anything the user started.
  if (window === window.top && window.navigation) {
    navigation.addEventListener('navigate', (e) => {
      try {
        const to = new URL(e.destination.url);
        if (!e.userInitiated && !e.hashChange && /^https?:$/.test(to.protocol) && siteOf(to.hostname) !== siteOf(location.hostname)) {
          note('script sent this tab to another site', { to: (to.origin + to.pathname).slice(0, 200), type: e.navigationType, guardActive: Date.now() <= suspectUntil });
        }
      } catch { /* not a URL */ }
      if (!config.popups || e.userInitiated || !e.cancelable || e.hashChange || e.downloadRequest || e.formData) return;
      if (e.navigationType === 'traverse' || e.navigationType === 'reload' || Date.now() > suspectUntil) return;
      let dest;
      try { dest = new URL(e.destination.url); } catch { return; }
      if (/^https?:$/.test(dest.protocol) && (siteOf(dest.hostname) === siteOf(location.hostname) || hostAllowed(dest.hostname))) return;
      e.preventDefault();
      note('blocked redirect', { to: (dest.origin + dest.pathname).slice(0, 200) });
      send({ type: 'popup', kind: 'redirect', reason: 'redirect right after a blocked pop-up', url: dest.href });
    });
  }

  // The background script knows the settings and the exceptions for this site. Until it answers
  // (or if it can't), the guard blocks nothing.
  async function applyConfig() {
    const answer = await send({ type: 'popup:config', host: topHostname() });
    config = answer && typeof answer === 'object'
      ? { popups: !!answer.popups, overlays: !!answer.overlays, allowTo: Array.isArray(answer.allowTo) ? answer.allowTo : [] }
      : { popups: false, overlays: false, allowTo: [] };
    dispatchEvent(new CustomEvent('turndown:popups-config', { detail: config }));
  }
  applyConfig();

  // The popup changed a setting for this site.
  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg?.type === 'popup:settingsChanged') applyConfig();
      return false;
    });
  } catch { /* extension was reloaded */ }
})();
