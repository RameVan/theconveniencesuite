// Settings shared by the content script and the popup.
const COOKIE_DENIER_DEFAULTS = {
  enabled: true,
  thorough: true,     // on vendor / "legitimate interest" banners, refuse everything in the preferences
  hideFallback: true, // hide known banners that offer no way to reject
  blockPopups: true,  // block pop-ups and redirects from invisible layers and page-wide click handlers
  popupAllowedSites: [], // hostnames (without "www.") where pop-ups are allowed; cookie handling stays on
  overlayAllowedSites: [], // hostnames where invisible layers over players are left as they are
  disabledSites: [],  // hostnames (without "www.") where the extension does nothing
};

function normalizeHost(host) {
  return (host || '').toLowerCase().replace(/^www\./, '');
}

// "example.com" in the list also covers its subdomains.
function isSiteDisabled(host, disabledSites) {
  host = normalizeHost(host);
  return disabledSites.some((site) => host === site || host.endsWith('.' + site));
}

// The hostname of the tab's top page, also from inside (cross-origin) frames.
function topHostname() {
  if (window === window.top) return location.hostname;
  const origins = location.ancestorOrigins;
  if (origins?.length) {
    try { return new URL(origins[origins.length - 1]).hostname; } catch { /* fall through */ }
  }
  try { return window.top.location.hostname; } catch { return location.hostname; }
}

// "Site" as in registrable domain, approximately: the last two labels, or three when the
// second-to-last is short (example.co.uk, example.com.br). popup-guard.js has its own copy.
function siteOf(host) {
  const parts = (host || '').toLowerCase().replace(/\.$/, '').split('.');
  if (parts.length <= 2 || /^\d+$/.test(parts[parts.length - 1])) return parts.join('.');
  const n = parts[parts.length - 2].length <= 3 && parts[parts.length - 1].length === 2 ? 3 : 2;
  return parts.slice(-n).join('.');
}

// Sign-in and payment sites: pop-ups and redirects to them are never blocked. popup-guard.js
// (page world, no access to this file) has the same list; keep the two in step.
const POPUP_TRUSTED_SITES = [
  'google.com', 'apple.com', 'microsoft.com', 'microsoftonline.com', 'live.com', 'facebook.com',
  'github.com', 'gitlab.com', 'twitter.com', 'x.com', 'linkedin.com', 'paypal.com', 'stripe.com',
  'discord.com', 'twitch.tv', 'amazon.com', 'yahoo.com', 'okta.com', 'auth0.com', 'klarna.com',
  'mollie.com', 'adyen.com', 'steampowered.com', 'steamcommunity.com', 'reddit.com', 'spotify.com',
  'dropbox.com', 'slack.com', 'zoom.us', 'patreon.com', 'ko-fi.com',
];
