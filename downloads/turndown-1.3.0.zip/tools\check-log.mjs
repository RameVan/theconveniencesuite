// Checks the popup's "Save a log" (popup.js buildLog / saveFile): a local page with a cookie
// banner Turndown can't refuse (it only has "Accept"), an invisible ad layer over a player and a
// page-wide "first click opens an ad" handler. Clicks with real mouse events, builds the log and
// checks what's in it, including that no query string leaks into it.
//
// Usage: node tools/check-log.mjs [--keep <dir>]   (--keep saves the log there to look at)
// Uses Chrome, or Microsoft Edge when Chrome isn't installed; CHROME_PATH overrides.
import { spawn } from 'node:child_process';
import { createServer } from 'node:http';
import { existsSync } from 'node:fs';
import { mkdtemp, mkdir, writeFile, readdir, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { StringDecoder } from 'node:string_decoder';

const extDir = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const keep = process.argv.includes('--keep') ? process.argv[process.argv.indexOf('--keep') + 1] : null;
const chromePath = process.env.CHROME_PATH || ['C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe'].find((p) => existsSync(p));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const server = createServer((req, res) => {
  res.setHeader('content-type', 'text/html');
  if (req.url === '/player') return res.end('<!doctype html><body style="margin:0;background:#222;height:100vh"><video style="width:100%;height:100%"></video></body>');
  if (req.url.startsWith('/ad')) return res.end('<!doctype html><title>ad</title>ad');
  res.end(`<!doctype html><html><head><title>Log test</title></head><body style="margin:0;height:1200px">
<h1>Episode 1</h1>
<iframe id="player" src="/player" style="position:absolute;left:100px;top:100px;width:640px;height:360px;border:0"></iframe>
<div id="adlayer" style="position:absolute;left:0;top:0;width:100%;height:100%;z-index:9;background:transparent"></div>
<div id="cookie-notice" style="position:fixed;bottom:0;left:0;right:0;z-index:20;background:#eee;padding:16px">
  We use cookies to improve your experience. <a href="/privacy">Learn more</a> <button>Accept</button>
</div>
<button id="next" style="position:absolute;left:100px;top:540px;padding:10px">Next episode</button>
<script>document.addEventListener('click', () => window.open('http://localhost:' + location.port + '/ad2?x=secret-token'));
adlayer.onclick = () => window.open('http://localhost:${port}/ad?id=secret-token');</script>
</body></html>`);
});
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const port = server.address().port;

const profile = await mkdtemp(join(tmpdir(), 'turndown-log-'));
const outDir = keep || profile;
await mkdir(outDir, { recursive: true });
const proc = spawn(chromePath, [
  '--headless=new', '--remote-debugging-pipe', '--enable-unsafe-extension-debugging',
  `--user-data-dir=${profile}`, '--no-first-run', '--no-default-browser-check', '--window-size=1000,800', 'about:blank',
], { stdio: ['ignore', 'ignore', 'ignore', 'pipe', 'pipe'] });
const pending = new Map();
let nextId = 1;
const decoder = new StringDecoder('utf8');
let buffer = '';
proc.stdio[4].on('data', (chunk) => {
  buffer += decoder.write(chunk);
  let end;
  while ((end = buffer.indexOf('\0')) >= 0) {
    const msg = JSON.parse(buffer.slice(0, end));
    buffer = buffer.slice(end + 1);
    const waiter = msg.id && pending.get(msg.id);
    if (!waiter) continue;
    pending.delete(msg.id);
    msg.error ? waiter.reject(new Error(msg.error.message)) : waiter.resolve(msg.result);
  }
});
function send(method, params = {}, sessionId) {
  const id = nextId++;
  proc.stdio[3].write(JSON.stringify({ id, method, params, sessionId }) + '\0');
  return new Promise((res, rej) => {
    pending.set(id, { resolve: res, reject: rej });
    setTimeout(() => pending.has(id) && (pending.delete(id), rej(new Error(`${method} timed out`))), 30000);
  });
}
async function evaluate(sessionId, expression) {
  const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true }, sessionId);
  if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails).slice(0, 500));
  return r.result.value;
}

let failures = 0;
const check = (ok, what) => { console.log(`${ok ? 'PASS' : 'FAIL'}  ${what}`); if (!ok) failures++; };

try {
  const { id: extId } = await send('Extensions.loadUnpacked', { path: extDir });
  await sleep(1000);
  const { targetInfos } = await send('Target.getTargets');
  const worker = targetInfos.find((t) => t.type === 'service_worker' && t.url.startsWith(`chrome-extension://${extId}/`));
  const { sessionId: ws } = await send('Target.attachToTarget', { targetId: worker.targetId, flatten: true });
  // Banner with no reject option: keep it on screen instead of hiding it.
  await evaluate(ws, `chrome.storage.sync.set({ hideFallback: false })`);

  const { targetId } = await send('Target.createTarget', { url: `http://127.0.0.1:${port}/watch` });
  const { sessionId: ps } = await send('Target.attachToTarget', { targetId, flatten: true });
  await sleep(4000);
  for (const type of ['mouseMoved', 'mousePressed', 'mouseReleased']) {
    await send('Input.dispatchMouseEvent', { type, x: 420, y: 280, button: 'left', clickCount: 1 }, ps);
  }
  await sleep(500);
  for (const type of ['mouseMoved', 'mousePressed', 'mouseReleased']) {
    await send('Input.dispatchMouseEvent', { type, x: 140, y: 555, button: 'left', clickCount: 1 }, ps);
  }
  await sleep(1500);

  const tabId = await evaluate(ws, `chrome.tabs.query({}).then((t) => t.find((x) => (x.url || '').includes('/watch')).id)`);
  const { targetId: popupTarget } = await send('Target.createTarget', { url: `chrome-extension://${extId}/popup.html`, newWindow: true });
  const { sessionId: pops } = await send('Target.attachToTarget', { targetId: popupTarget, flatten: true });
  await sleep(1500);
  const log = await evaluate(pops, `chrome.tabs.get(${tabId}).then((tab) => buildLog(tab, 'popups', 'test note'))`);
  if (keep) await writeFile(join(outDir, 'log.json'), JSON.stringify(log, null, 1));

  const text = JSON.stringify(log);
  const top = log.frames.find((f) => f.frameId === 0);
  check(log.turndownLog === 1 && log.problem === 'popups' && log.note === 'test note', 'log header');
  check(log.page.url === `http://127.0.0.1:${port}/watch` && log.page.title === 'Log test', 'page address without query, title');
  check(!text.includes('secret-token'), 'no query strings anywhere in the log');
  check(log.frames.length >= 2, `frames collected: ${log.frames.length}`);
  check(top?.cookies?.bannersOnScreen?.some((b) => b.el.includes('cookie-notice') && b.buttons.some((x) => x.label === 'accept')), 'cookie banner still on screen, with its buttons');
  check(Array.isArray(top?.cookies?.trace) && top.cookies.trace.length > 0, 'cookie trace present');
  check(top?.popups?.trace?.some((t) => t.what === 'window.open' && t.blocked), 'blocked window.open in the pop-up trace');
  check(top?.cookies?.knownPlatformsOnScreen?.length > 0 && top.cookies.handled === false, 'banner seen, not handled (no reject button)');
  check(log.frames.some((f) => f.popups?.trace?.some((t) => t.what === 'press' && t.on === 'video')), 'click reached the player (layer was fixed first)');
  check(top?.popups?.trace?.some((t) => t.what === 'window.open' && t.handlerOn === 'document' && /page-wide/.test(t.blocked)), 'page-wide handler pop-up blocked, with reason');
  check(top?.popups?.guard?.players?.length === 1, 'player listed');
  check(top?.popups?.guard?.layersFixed?.some((l) => l.el.includes('adlayer')), 'fixed layer listed');
  check(log.background?.tabEvents?.some((e) => e.what === 'blocked'), 'background tab events');
  check(log.background?.popupsBlockedOnPage >= 1, 'blocked count');
  check(typeof log.screenshot === 'string' && log.screenshot.startsWith('data:image/jpeg'), `screenshot (${String(log.screenshot).slice(0, 40)})`);

  // The file itself: saveFile() downloads it.
  const dl = join(outDir, 'downloads');
  await send('Browser.setDownloadBehavior', { behavior: 'allow', downloadPath: dl });
  await evaluate(pops, `saveFile('turndown-log-test.json', JSON.stringify({ ok: 1 }))`);
  await sleep(1500);
  const files = await readdir(dl).catch(() => []);
  check(files.includes('turndown-log-test.json') && (await readFile(join(dl, 'turndown-log-test.json'), 'utf8')).includes('"ok"'), `download saved (${files.join(', ')})`);
  // Edge keeps an unpacked extension's sync settings across throwaway profiles: put them back.
  await evaluate(ws, 'chrome.storage.sync.clear()');
} catch (e) {
  console.log('ERROR', e.stack || e);
  failures++;
} finally {
  proc.kill();
  server.close();
  await sleep(500);
  await rm(profile, { recursive: true, force: true }).catch(() => {});
}
console.log(failures ? `${failures} failed` : 'all passed');
process.exit(failures ? 1 : 0);
