// Clicks around real sites the way a visitor would and records what pop-ups and redirects that
// causes, with or without the extension, in throwaway headless Chrome profiles. Compare a run
// --no-extension with a run with it (tools/compare-popup-runs.mjs) to see what the pop-up guard
// blocks and whether it changes anything else (a link that no longer opens, new script errors).
//
// Usage: node tools/check-popup-sites.mjs [options] [<url-or-domain> ...]
//   --file <path>       read sites from a file (one per line), in addition to any given
//   --out <dir>         where results.jsonl goes
//   --parallel <n>      browsers visiting sites at the same time (default 1)
//   --wait <seconds>    time a page gets to load before the first click (default 6)
//   --clicks <n>        clicks per page (default 4)
//   --no-extension      baseline run without the extension
//   --extension <dir>   test this copy of the extension instead of the one this tool is in
//   --resume            keep the results already in --out and visit only the sites not in them
// Downloads are refused. Needs Chrome; set CHROME_PATH if it isn't in the default location.
import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { appendFile, mkdtemp, mkdir, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { StringDecoder } from 'node:string_decoder';
import { fileURLToPath } from 'node:url';

const args = process.argv.slice(2);
const option = (name, fallback) => {
  const i = args.indexOf(name);
  return i >= 0 ? args.splice(i, 2)[1] : fallback;
};
const flag = (name) => {
  const i = args.indexOf(name);
  return i >= 0 && !!args.splice(i, 1);
};
const outDir = resolve(option('--out', join(tmpdir(), 'turndown-popup-check')));
const waitMs = Number(option('--wait', 6)) * 1000;
const clickCount = Number(option('--clicks', 4));
const parallel = Math.max(1, Number(option('--parallel', 1)));
const listFile = option('--file', null);
const withExtension = !flag('--no-extension');
const extOption = option('--extension', null);
const resume = flag('--resume');
const sites = [...args];
if (listFile) sites.push(...(await readFile(listFile, 'utf8')).split(/\r?\n/).map((l) => l.trim()).filter(Boolean));
const toUrl = (s) => (/^https?:\/\//.test(s) ? s : `https://${s}/`);

const extDir = extOption ? resolve(extOption) : resolve(dirname(fileURLToPath(import.meta.url)), '..');
// Chrome if it's installed, else Microsoft Edge (same engine, always there on Windows).
const chromePath = process.env.CHROME_PATH || ['C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe'].find((p) => existsSync(p));
const RESTART_EVERY = 60;
const AFTER_CLICK_MS = 2200;
const VISIT_TIMEOUT_MS = waitMs + clickCount * (AFTER_CLICK_MS + 4000) + 40000;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

if (!sites.length) {
  console.error('Usage: node tools/check-popup-sites.mjs [--file <path>] [--parallel <n>] [--no-extension] <site> ...');
  process.exit(1);
}

// Registrable domain, approximately (same rule as popup-guard.js).
function siteOf(host) {
  const parts = (host || '').toLowerCase().replace(/\.$/, '').split('.');
  if (parts.length <= 2 || /^\d+$/.test(parts[parts.length - 1])) return parts.join('.');
  const n = parts[parts.length - 2].length <= 3 && parts[parts.length - 1].length === 2 ? 3 : 2;
  return parts.slice(-n).join('.');
}
const siteOfUrl = (url) => { try { return siteOf(new URL(url).hostname); } catch { return ''; } };

// --- DevTools protocol over a pipe ----------------------------------------------------------

class Browser {
  async launch() {
    this.profile = await mkdtemp(join(tmpdir(), 'turndown-popsite-'));
    this.pending = new Map();
    this.listeners = new Set();
    this.nextId = 1;
    this.proc = spawn(chromePath, [
      '--headless=new', '--remote-debugging-pipe', '--enable-unsafe-extension-debugging',
      `--user-data-dir=${this.profile}`, '--no-first-run', '--no-default-browser-check', '--mute-audio',
      '--window-size=1280,900',
      '--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36',
      'about:blank',
    ], { stdio: ['ignore', 'ignore', 'ignore', 'pipe', 'pipe'] });
    const decoder = new StringDecoder('utf8');
    let buffer = '';
    this.proc.stdio[4].on('data', (chunk) => {
      buffer += decoder.write(chunk);
      let end;
      while ((end = buffer.indexOf('\0')) >= 0) {
        const msg = JSON.parse(buffer.slice(0, end));
        buffer = buffer.slice(end + 1);
        if (msg.method) for (const fn of this.listeners) fn(msg);
        const waiter = msg.id && this.pending.get(msg.id);
        if (!waiter) continue;
        this.pending.delete(msg.id);
        msg.error ? waiter.reject(new Error(msg.error.message)) : waiter.resolve(msg.result);
      }
    });
    this.proc.stdio[3].on('error', () => {});
    if (withExtension) await this.send('Extensions.loadUnpacked', { path: extDir });
    await this.send('Target.setDiscoverTargets', { discover: true });
    await this.send('Browser.setDownloadBehavior', { behavior: 'deny' }).catch(() => {});
  }

  send(method, params = {}, sessionId) {
    const id = this.nextId++;
    this.proc.stdio[3].write(JSON.stringify({ id, method, params, sessionId }) + '\0');
    return new Promise((res, rej) => {
      this.pending.set(id, { resolve: res, reject: rej });
      setTimeout(() => this.pending.has(id) && (this.pending.delete(id), rej(new Error(`${method} timed out`))), 20000);
    });
  }

  async evaluate(sessionId, expression) {
    const { result, exceptionDetails } = await this.send('Runtime.evaluate', { expression, returnByValue: true }, sessionId);
    if (exceptionDetails) throw new Error(exceptionDetails.text);
    return result.value;
  }

  async close() {
    if (this.proc?.pid && process.platform === 'win32') {
      await new Promise((r) => spawn('taskkill', ['/pid', String(this.proc.pid), '/T', '/F'], { stdio: 'ignore' }).on('exit', r).on('error', r));
    } else {
      this.proc?.kill();
    }
    await sleep(500);
    await rm(this.profile, { recursive: true, force: true }).catch(() => {});
  }
}

// Where to click: the biggest player (video or iframe) on screen, else the middle of the page.
const CLICK_POINTS = `(() => {
  let best = null;
  for (const m of document.querySelectorAll('video, iframe, embed, object')) {
    const r = m.getBoundingClientRect();
    const w = Math.min(r.right, innerWidth) - Math.max(r.left, 0), h = Math.min(r.bottom, innerHeight) - Math.max(r.top, 0);
    if (w < 250 || h < 140) continue;
    if (!best || w * h > best.area) best = { area: w * h, x: Math.max(r.left, 0) + w / 2, y: Math.max(r.top, 0) + h / 2 };
  }
  const mid = { x: innerWidth / 2, y: Math.min(innerHeight / 2, 450) };
  return { player: !!best, points: best ? [best, best, mid, best] : [mid, mid, { x: innerWidth / 2, y: innerHeight * 0.3 }, mid] };
})()`;

// What is under the pointer: a frame, a link (and whether it's visible), or something else.
const UNDER = (x, y) => `(() => {
  const el = document.elementFromPoint(${x}, ${y});
  if (!el) return { kind: 'none' };
  if (el.tagName === 'IFRAME') return { kind: 'iframe', src: el.src.slice(0, 120) };
  const a = el.closest('a[href]');
  let opacity = 1;
  for (let e = el; e && e.nodeType === 1; e = e.parentElement) opacity *= Number(getComputedStyle(e).opacity) || 0;
  const cs = getComputedStyle(el);
  const r = el.getBoundingClientRect();
  return {
    kind: a ? 'link' : el.tagName.toLowerCase(),
    href: a ? a.href.slice(0, 160) : null,
    target: a ? a.target : null,
    positioned: cs.position === 'fixed' || cs.position === 'absolute',
    big: r.width * r.height > 0.2 * innerWidth * innerHeight,
    faint: opacity < 0.1,
  };
})()`;

async function visit(browser, site) {
  const url = toUrl(site);
  const entry = { site, url };
  let targetId;
  const extraTabs = new Set();
  const tabUrls = new Map();
  const errors = [];
  let onEvent;
  try {
    ({ targetId } = await browser.send('Target.createTarget', { url: 'about:blank' }));
    const { sessionId } = await browser.send('Target.attachToTarget', { targetId, flatten: true });
    await browser.send('Page.enable', {}, sessionId);
    await browser.send('Runtime.enable', {}, sessionId);
    let clicking = false;
    onEvent = (msg) => {
      if (msg.method === 'Target.targetCreated' && msg.params.targetInfo.type === 'page' && msg.params.targetInfo.openerId === targetId) {
        extraTabs.add(msg.params.targetInfo.targetId);
        tabUrls.set(msg.params.targetInfo.targetId, msg.params.targetInfo.url);
      }
      if (msg.method === 'Target.targetInfoChanged' && extraTabs.has(msg.params.targetInfo.targetId)) tabUrls.set(msg.params.targetInfo.targetId, msg.params.targetInfo.url);
      if (msg.method === 'Runtime.exceptionThrown' && msg.sessionId === sessionId && clicking) errors.push((msg.params.exceptionDetails.exception?.description || msg.params.exceptionDetails.text || '').split('\n')[0].slice(0, 160));
    };
    browser.listeners.add(onEvent);
    await browser.send('Page.navigate', { url }, sessionId);
    await sleep(waitMs);
    entry.landed = await browser.evaluate(sessionId, 'location.href');
    entry.title = (await browser.evaluate(sessionId, 'document.title').catch(() => '')).slice(0, 80);
    const startSite = siteOfUrl(entry.landed);
    const { player, points } = await browser.evaluate(sessionId, CLICK_POINTS);
    entry.player = player;
    entry.clicks = [];
    clicking = true;
    for (const { x, y } of points.slice(0, clickCount)) {
      const before = new Set(extraTabs);
      const under = await browser.evaluate(sessionId, UNDER(x, y)).catch(() => ({ kind: 'error' }));
      for (const type of ['mouseMoved', 'mousePressed', 'mouseReleased']) {
        await browser.send('Input.dispatchMouseEvent', { type, x, y, button: 'left', clickCount: type === 'mouseMoved' ? 0 : 1 }, sessionId);
      }
      await sleep(AFTER_CLICK_MS);
      const now = await browser.evaluate(sessionId, 'location.href').catch(() => null);
      const opened = [...extraTabs].filter((id) => !before.has(id)).map((id) => tabUrls.get(id) || '');
      const click = { under, opened: opened.map((u) => u.slice(0, 160)) };
      if (now && now !== entry.landed) click.navigated = now.slice(0, 160);
      entry.clicks.push(click);
      // Close the pop-ups so they can't pile up; stop once this tab has left the page.
      for (const id of extraTabs) await browser.send('Target.closeTarget', { targetId: id }).catch(() => {});
      if (click.navigated && siteOfUrl(click.navigated) !== startSite) break;
      if (click.navigated) break;
    }
    entry.errors = errors.slice(0, 10);
    entry.errorCount = errors.length;
  } catch (e) {
    entry.error = e.message;
  } finally {
    if (onEvent) browser.listeners.delete(onEvent);
    for (const id of extraTabs) await browser.send('Target.closeTarget', { targetId: id }).catch(() => {});
    if (targetId) await browser.send('Target.closeTarget', { targetId }).catch(() => {});
  }
  // Summary: pop-ups to another site, and redirects of this tab to another site.
  const start = siteOfUrl(entry.landed || url);
  entry.popups = (entry.clicks || []).reduce((n, c) => n + c.opened.filter((u) => siteOfUrl(u) !== start).length, 0);
  entry.redirects = (entry.clicks || []).filter((c) => c.navigated && siteOfUrl(c.navigated) !== start && !(c.under?.kind === 'link' && siteOfUrl(c.under.href) === siteOfUrl(c.navigated))).length;
  return entry;
}

// --- Run ---------------------------------------------------------------------------------------

await mkdir(outDir, { recursive: true });
const resultsFile = join(outDir, 'results.jsonl');
const done = new Set();
if (resume) {
  const old = await readFile(resultsFile, 'utf8').catch(() => '');
  for (const line of old.split('\n')) if (line) try { done.add(JSON.parse(line).site); } catch { /* partial line */ }
}
const queue = [...new Set(sites)].filter((s) => !done.has(s));
console.log(`${queue.length} sites to visit (${done.size} already done), ${parallel} at a time, ${withExtension ? 'with' : 'without'} the extension`);
let finished = 0;
let withPopups = 0;
const startedAt = Date.now();

async function worker() {
  let browser = null;
  let visits = 0;
  while (queue.length) {
    const site = queue.shift();
    if (!browser || visits >= RESTART_EVERY) {
      await browser?.close();
      browser = new Browser();
      try { await browser.launch(); } catch (e) { console.error('launch failed', e.message); await browser.close(); browser = null; queue.push(site); await sleep(3000); continue; }
      visits = 0;
    }
    visits++;
    const entry = await Promise.race([visit(browser, site), sleep(VISIT_TIMEOUT_MS).then(() => ({ site, url: toUrl(site), error: 'visit timed out' }))]);
    if (entry.error === 'visit timed out') { await browser.close(); browser = null; }
    await appendFile(resultsFile, JSON.stringify(entry) + '\n');
    finished++;
    if (entry.popups || entry.redirects) withPopups++;
    if (finished % 50 === 0) {
      const rate = finished / ((Date.now() - startedAt) / 3600000);
      console.log(`${finished} done, ${withPopups} with pop-ups or redirects, ${Math.round(rate)}/h, ${queue.length} left`);
    }
  }
  await browser?.close();
}

await Promise.all(Array.from({ length: parallel }, worker));
console.log(`finished: ${finished} visited, ${withPopups} with pop-ups or redirects`);
process.exit(0);
