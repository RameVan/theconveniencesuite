// Tests the pop-up guard on local pages that copy what ad scripts on streaming sites do.
// Pages are served from 127.0.0.1 and the "ads" from localhost, which counts as another site.
// Each case clicks with real (trusted) mouse events through the DevTools protocol, then checks
// how many new tabs opened, whether this tab was sent elsewhere, and whether the player got
// the click.
//
// Usage: node tools/check-popups.mjs [--no-extension]
// Needs Chrome installed; set CHROME_PATH if it isn't in the default location.
import { spawn } from 'node:child_process';
import { createServer } from 'node:http';
import { existsSync } from 'node:fs';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { StringDecoder } from 'node:string_decoder';
import { fileURLToPath } from 'node:url';

const withExtension = !process.argv.includes('--no-extension');
const extDir = resolve(dirname(fileURLToPath(import.meta.url)), '..');
// Chrome if it's installed, else Microsoft Edge (same engine, always there on Windows).
const chromePath = process.env.CHROME_PATH || ['C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe'].find((p) => existsSync(p));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// --- Test pages --------------------------------------------------------------------------

let port;
const ad = (name) => `http://localhost:${port}/ad-${name}`;
// A host from the pop-up ad network list; the browser resolves it (and every other outside host)
// to this machine, so nothing is fetched from the internet.
const adNetwork = JSON.parse(await readFile(join(extDir, 'vendor', 'popup-domains', 'domains.json'), 'utf8')).find((h) => /^[a-z]/.test(h));
const player = `<iframe id="player" src="/player" style="position:absolute;left:100px;top:100px;width:640px;height:360px;border:0"></iframe>`;
const page = (body, script = '') => `<!doctype html><html><body style="margin:0;height:1200px">${body}<script>${script}</script></body></html>`;

const CASES = [
  {
    name: 'invisible link over the player',
    html: () => page(player, `setTimeout(() => {
      const a = document.createElement('a');
      a.href = '${ad('overlay')}'; a.target = '_blank';
      a.style.cssText = 'position:absolute;left:100px;top:100px;width:640px;height:360px;z-index:9;opacity:0';
      document.body.append(a);
    }, 300);`),
    click: [420, 280],
    expect: { tabs: 0, played: true },
  },
  {
    name: 'transparent layer with an onclick over the player',
    html: () => page(player + `<div id="layer" style="position:absolute;left:0;top:0;width:100%;height:100%;z-index:9;background:transparent"></div>`,
      `layer.onclick = () => window.open('${ad('layer')}');`),
    click: [420, 280],
    expect: { tabs: 0, played: true },
  },
  {
    name: 'invisible full-page layer (no player under it)',
    html: () => page(`<button id="btn" style="margin:300px">Play</button><div style="position:fixed;inset:0;z-index:9;opacity:0.01" onclick="window.open('${ad('fullpage')}')"></div>`),
    click: [330, 310],
    expect: { tabs: 0 },
  },
  {
    name: 'page-wide click handler opens a pop-up and redirects',
    html: () => page(`<button id="btn" style="margin:300px;padding:20px">Play</button>`,
      `document.addEventListener('click', () => { if (!window.w) { window.w = window.open('${ad('pagewide')}'); if (!window.w) location.href = '${ad('fallback')}'; } });`),
    click: [340, 320],
    expect: { tabs: 0, stayed: true },
  },
  {
    name: 'tab-under (opens this page again, sends this tab to the ad)',
    html: () => page(`<button style="margin:300px;padding:20px">Play</button>`,
      `document.addEventListener('click', () => { window.open(location.href); location.href = '${ad('tabunder')}'; }, { once: true });`),
    click: [340, 320],
    expect: { tabs: 1, stayed: true },
  },
  {
    name: 'window.open borrowed from a fresh iframe (Chrome blocks this one too)',
    html: () => page(`<button style="margin:300px;padding:20px">Play</button>`,
      `window.onclick = () => { const f = document.createElement('iframe'); f.style.display = 'none'; document.body.append(f); f.contentWindow.open('${ad('borrowed')}'); };`),
    click: [340, 320],
    expect: { tabs: 0 },
  },
  {
    name: 'script clicks a new-tab link',
    html: () => page(`<button style="margin:300px;padding:20px">Play</button>`,
      `document.body.addEventListener('mousedown', () => { const a = document.createElement('a'); a.href = '${ad('anchor')}'; a.target = '_blank'; a.click(); });`),
    click: [340, 320],
    expect: { tabs: 0 },
  },
  {
    name: 'share button opens a pop-up (should be allowed)',
    html: () => page(`<button id="share" style="margin:300px;padding:20px">Share</button>`,
      `share.addEventListener('click', () => window.open('${ad('share')}', 'share', 'width=500,height=400'));`),
    click: [340, 320],
    expect: { tabs: 1 },
  },
  {
    name: 'ordinary new-tab link (should be allowed)',
    html: () => page(`<a href="${ad('link')}" target="_blank" style="display:inline-block;margin:300px;padding:20px">Visit</a>`),
    click: [340, 320],
    expect: { tabs: 1 },
  },
  {
    name: 'page-wide handler opening the link you clicked (should be allowed)',
    html: () => page(`<a class="share" href="${ad('delegated')}" style="display:inline-block;margin:300px;padding:20px">Tweet</a>`,
      `document.addEventListener('click', (e) => { const a = e.target.closest('a.share'); if (a) { e.preventDefault(); window.open(a.href); } });`),
    click: [340, 320],
    expect: { tabs: 1 },
  },
  {
    name: 'ad script checks whether its pop-up was blocked',
    html: () => page(`<button style="margin:300px;padding:20px">Play</button>`,
      `document.title = 'ok'; document.addEventListener('click', () => { const w = window.open('${ad('detect')}'); if (!w || w.closed || typeof w.closed === 'undefined') { document.title = 'blocker detected'; location.href = '${ad('detected')}'; } else { w.location = '${ad('detect2')}'; } }, { once: true });`),
    click: [340, 320],
    expect: { tabs: 0, stayed: true, title: 'ok' },
  },
  {
    name: 'sign-in pop-up from a page-wide handler (should be allowed)',
    html: () => page(`<button class="google" style="margin:300px;padding:20px">Sign in with Google</button>`,
      `document.addEventListener('click', (e) => { if (e.target.closest('.google')) window.open('https://accounts.google.com/o/oauth2/v2/auth?client_id=test', 'signin', 'width=500,height=600'); });`),
    click: [340, 320],
    expect: { tabs: 1, left: 1 },
  },
  {
    name: 'pop-up to a known ad network from a visible button gets closed',
    html: () => page(`<button id="go" style="margin:300px;padding:20px">Download</button>`,
      `go.addEventListener('click', () => window.open('http://${adNetwork}:${port}/'));`),
    click: [340, 320],
    expect: { tabs: 1, left: withExtension ? 0 : 1 },
  },
  {
    name: 'wrapped functions still look native',
    html: () => page(`<p style="margin:300px">text</p>`,
      `const native = (f) => /\\{\\s*\\[native code\\]\\s*\\}$/.test(Function.prototype.toString.call(f)); document.title = String(native(window.open) && native(HTMLElement.prototype.click) && native(EventTarget.prototype.dispatchEvent));`),
    click: [340, 320],
    expect: { title: 'true' },
  },
  // --- Safety valves ---
  {
    name: 'nothing of the guard is visible on window',
    html: () => page(`<p style="margin:300px">text</p>`,
      `document.title = String(Object.getOwnPropertyNames(window).some((n) => /turndown/i.test(n)));`),
    click: [340, 320],
    expect: { title: 'false' },
  },
  {
    name: 'pop-up to an exception destination from a page-wide handler (should be allowed)',
    html: () => page(`<button style="margin:300px;padding:20px">Comment</button>`,
      `document.addEventListener('click', () => window.open('https://disqus.com/next/login/', 'login', 'width=500,height=600'), { once: true });`),
    click: [340, 320],
    expect: { tabs: 1 },
  },
  {
    name: 'site where you allowed pop-ups (should be allowed)',
    extensionOnly: true,
    setup: `chrome.storage.sync.set({ popupAllowedSites: ['127.0.0.1'] }).then(() => true)`,
    cleanup: `chrome.storage.sync.set({ popupAllowedSites: [] }).then(() => true)`,
    html: () => page(`<button style="margin:300px;padding:20px">Play</button>`,
      `document.addEventListener('click', () => window.open('${ad('allowedsite')}'), { once: true });`),
    click: [340, 320],
    expect: { tabs: 1 },
  },
  {
    name: 'guard fails open when it breaks (page gets a real pop-up, no error)',
    html: () => page(`<button style="margin:300px;padding:20px">Play</button>`,
      `Object.defineProperty(window, 'event', { configurable: true, get() { throw new Error('boom'); } });
      document.addEventListener('click', () => { try { window.open('${ad('failopen')}'); document.title = 'no error'; } catch { document.title = 'threw'; } }, { once: true });`),
    click: [340, 320],
    expect: { tabs: 1, title: 'no error' },
  },
  {
    name: '"Open it" reopens a blocked pop-up and allows only that destination on the site',
    extensionOnly: true,
    html: () => page(`<button style="margin:300px;padding:20px">Play</button>`,
      `document.addEventListener('click', () => window.open('${ad('undo')}'), { once: true });`),
    click: [340, 320],
    worker: `(async () => {
      const [tab] = await chrome.tabs.query({ url: '*://127.0.0.1/case-*' });
      const key = 'lastBlocked_' + tab.id;
      const last = (await chrome.storage.session.get(key))[key];
      const opened = await openBlockedPopup(tab.id);
      const { popupPairs } = await chrome.storage.local.get('popupPairs');
      const { popupAllowedSites } = await chrome.storage.sync.get(COOKIE_DENIER_DEFAULTS);
      const config = await popupConfig('127.0.0.1');
      return [last.host === 'localhost' && !!last.reason, opened.opened, popupPairs['127.0.0.1'].includes('localhost'), popupAllowedSites.length === 0, config.popups && config.allowTo.includes('localhost')].join(' ');
    })()`,
    cleanup: `chrome.storage.local.set({ popupPairs: {}, popupRestores: {} }).then(() => true)`,
    expect: { tabs: 0, worker: 'true true true true true' },
  },
  // --- Sign-in, payment and other windows that must keep working ---
  {
    // Real providers are HSTS-preloaded (always https), so this stands in with an allowed
    // destination of its own: signin.example, allowed for this site the way "Open it" would.
    name: 'sign-in window opened blank, then sent to the provider (should open and message back)',
    setup: `chrome.storage.local.set({ popupPairs: { '127.0.0.1': ['signin.example'] } }).then(() => true)`,
    cleanup: `chrome.storage.local.set({ popupPairs: {} }).then(() => true)`,
    html: () => page(`<button class="login" style="margin:300px;padding:20px">Sign in</button>`,
      `addEventListener('message', (e) => { if (e.data === 'auth-ok') document.title = 'signed in'; });
      document.addEventListener('click', (e) => { if (!e.target.closest('.login')) return; const w = window.open('', 'signin', 'width=500,height=600'); w.location = 'http://signin.example:${port}/auth-callback'; });`),
    click: [340, 320],
    wait: 2500,
    expect: { tabs: 1, title: 'signed in' },
  },
  {
    name: 'sign-in window reused by name (one window, should be allowed)',
    html: () => page(`<button class="login" style="margin:300px;padding:20px">Sign in</button>`,
      `document.addEventListener('click', (e) => { if (!e.target.closest('.login')) return; window.open('https://accounts.google.com/a', 'auth'); window.open('https://accounts.google.com/b', 'auth'); });`),
    click: [340, 320],
    expect: { tabs: 1 },
  },
  {
    name: 'print window from a button (should be allowed)',
    html: () => page(`<button id="printButton" style="margin:300px;padding:20px">Print</button>`,
      `printButton.addEventListener('click', () => { const w = window.open('', '', 'width=600,height=600'); w.document.write('<p>Receipt</p>'); w.document.close(); });`),
    click: [340, 320],
    expect: { tabs: 1 },
  },
  // --- More ad tricks ---
  {
    name: 'ad pop-up opened a moment after the click',
    html: () => page(`<p style="margin:300px;padding:20px">Episode 1</p>`,
      `document.addEventListener('click', () => setTimeout(() => window.open('${ad('delayed')}'), 300), { once: true });`),
    click: [340, 320],
    expect: { tabs: 0 },
  },
  {
    name: 'several ad pop-ups from one click',
    html: () => page(`<button style="margin:300px;padding:20px">Play</button>`,
      `document.addEventListener('click', () => { for (let i = 0; i < 3; i++) window.open('${ad('many')}' + i); }, { once: true });`),
    click: [340, 320],
    expect: { tabs: 0 },
  },
  {
    name: 'pop-under: copy of the page in a new tab, this tab sent to an ad network later',
    extensionOnly: true,
    html: () => page(`<button style="margin:300px;padding:20px">Play</button>`,
      `document.addEventListener('click', () => { window.open(location.href); setTimeout(() => { location.href = 'http://${adNetwork}:${port}/'; }, 4000); }, { once: true });`),
    click: [340, 320],
    wait: 6000,
    // This tab is sent back (scroll position kept); the copy stays, as you may be using it.
    worker: `(async () => {
      const tabs = await chrome.tabs.query({ url: '*://127.0.0.1/case-*' });
      const records = await chrome.storage.session.get(tabs.map((t) => 'lastBlocked_' + t.id));
      return Object.values(records).some((r) => r.kind === 'pop-under') ? 'pop-under undone' : 'nothing recorded';
    })()`,
    expect: { tabs: 1, left: 1, pageClosed: false, stayed: true, worker: 'pop-under undone' },
  },
  // --- Fault injection ---
  {
    name: 'ad network list broken: pop-up tab is left alone (fail open)',
    extensionOnly: true,
    setup: `(() => { popupLists = Promise.reject(new Error('broken list')); popupLists.catch(() => {}); return true; })()`,
    cleanup: `(() => { popupLists = null; return true; })()`,
    html: () => page(`<button id="go" style="margin:300px;padding:20px">Download</button>`,
      `go.addEventListener('click', () => window.open('http://${adNetwork}:${port}/'));`),
    click: [340, 320],
    expect: { tabs: 1, left: 1 },
  },
  {
    name: 'layer fixing switched off for the site: the layer is restored without a reload',
    extensionOnly: true,
    html: () => page(player + `<a id="layer" href="${ad('restore')}" target="_blank" style="position:absolute;left:100px;top:100px;width:640px;height:360px;z-index:9;opacity:0"></a>`),
    click: null,
    before: `getComputedStyle(document.getElementById('layer')).pointerEvents`,
    worker: `(async () => {
      await chrome.storage.sync.set({ overlayAllowedSites: ['127.0.0.1'] });
      const [tab] = await chrome.tabs.query({ url: '*://127.0.0.1/case-*' });
      await chrome.tabs.sendMessage(tab.id, { type: 'popup:settingsChanged' }).catch(() => {});
      await new Promise((r) => setTimeout(r, 500));
      return 'done';
    })()`,
    after: `getComputedStyle(document.getElementById('layer')).pointerEvents`,
    cleanup: `chrome.storage.sync.set({ overlayAllowedSites: [] }).then(() => true)`,
    expect: { before: 'none', after: 'auto', worker: 'done' },
  },
];

const server = createServer((req, res) => {
  res.setHeader('content-type', 'text/html');
  // Stands in for a sign-in provider's callback page (accounts.google.com resolves to this server).
  if (req.url === '/auth-callback') {
    return res.end(`<!doctype html><body>Signed in<script>opener && opener.postMessage('auth-ok', '*');</script></body>`);
  }
  if (req.url === '/player') {
    return res.end(`<!doctype html><body style="margin:0;background:#222;height:100vh" onclick="parent.postMessage('played','*')"><video style="width:100%;height:100%"></video></body>`);
  }
  const index = Number(req.url.match(/^\/case-(\d+)/)?.[1]);
  res.end(CASES[index] ? CASES[index].html() : '<!doctype html><title>other</title>other page');
});
await new Promise((r) => server.listen(0, '127.0.0.1', r));
port = server.address().port;

// --- Browser (DevTools protocol over a pipe) ---------------------------------------------------

const profile = await mkdtemp(join(tmpdir(), 'turndown-popups-'));
const proc = spawn(chromePath, [
  '--headless=new', '--remote-debugging-pipe', '--enable-unsafe-extension-debugging',
  `--user-data-dir=${profile}`, '--no-first-run', '--no-default-browser-check', '--window-size=1000,800',
  '--host-resolver-rules=MAP * 127.0.0.1, EXCLUDE localhost', 'about:blank',
], { stdio: ['ignore', 'ignore', 'ignore', 'pipe', 'pipe'] });
const pending = new Map();
const listeners = [];
let nextId = 1;
const decoder = new StringDecoder('utf8');
let buffer = '';
proc.stdio[4].on('data', (chunk) => {
  buffer += decoder.write(chunk);
  let end;
  while ((end = buffer.indexOf('\0')) >= 0) {
    const msg = JSON.parse(buffer.slice(0, end));
    buffer = buffer.slice(end + 1);
    if (msg.method) listeners.forEach((fn) => fn(msg));
    const waiter = msg.id && pending.get(msg.id);
    if (!waiter) continue;
    pending.delete(msg.id);
    msg.error ? waiter.reject(new Error(msg.error.message)) : waiter.resolve(msg.result);
  }
});
function send(method, params = {}, sessionId) {
  const id = nextId++;
  proc.stdio[3].write(JSON.stringify({ id, method, params, sessionId }) + '\0');
  return new Promise((res, rej) => {
    pending.set(id, { resolve: res, reject: rej });
    setTimeout(() => pending.has(id) && (pending.delete(id), rej(new Error(`${method} timed out`))), 15000);
  });
}
async function evaluate(sessionId, expression) {
  const { result } = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true }, sessionId);
  return result.value;
}

const extId = withExtension ? (await send('Extensions.loadUnpacked', { path: extDir })).id : null;
await send('Target.setDiscoverTargets', { discover: true });

let failures = 0;
let ran = 0;
// Runs code in the extension's service worker (to change settings or call its functions).
let workerSession = null;
async function inWorker(expression) {
  if (!withExtension) return null;
  if (!workerSession) {
    const { targetInfos } = await send('Target.getTargets');
    const worker = targetInfos.find((t) => t.type === 'service_worker' && t.url.startsWith(`chrome-extension://${extId}/`));
    ({ sessionId: workerSession } = await send('Target.attachToTarget', { targetId: worker.targetId, flatten: true }));
  }
  return evaluate(workerSession, expression);
}

for (const [i, test] of CASES.entries()) {
  if (test.extensionOnly && !withExtension) continue;
  const url = `http://127.0.0.1:${port}/case-${i}`;
  if (test.setup) await inWorker(test.setup);
  const { targetId } = await send('Target.createTarget', { url: 'about:blank' });
  const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true });
  await send('Page.enable', {}, sessionId);
  await send('Page.navigate', { url }, sessionId);
  await sleep(2500);
  await evaluate(sessionId, `window.__played = false; addEventListener('message', (e) => { if (e.data === 'played') window.__played = true; }); true`);

  const opened = [];
  const closed = new Set();
  const onTarget = (msg) => {
    if (msg.method === 'Target.targetCreated' && msg.params.targetInfo.type === 'page' && msg.params.targetInfo.openerId === targetId) opened.push(msg.params.targetInfo.targetId);
    if (msg.method === 'Target.targetDestroyed') closed.add(msg.params.targetId);
  };
  listeners.push(onTarget);
  if (test.click) {
    const [x, y] = test.click;
    for (const type of ['mouseMoved', 'mousePressed', 'mouseReleased']) {
      await send('Input.dispatchMouseEvent', { type, x, y, button: 'left', clickCount: type === 'mouseMoved' ? 0 : 1 }, sessionId);
    }
    await sleep(test.wait ?? 1500);
    // A second click: whatever was in the way should be gone now.
    if (test.expect.played) {
      for (const type of ['mousePressed', 'mouseReleased']) await send('Input.dispatchMouseEvent', { type, x, y, button: 'left', clickCount: 1 }, sessionId);
      await sleep(800);
    }
  }
  if (test.expect.left !== undefined) await sleep(1500); // give the background script time to close it
  listeners.splice(listeners.indexOf(onTarget), 1);

  const pageClosed = closed.has(targetId);
  const inPage = (expression, fallback) => (pageClosed ? Promise.resolve(fallback) : evaluate(sessionId, expression).catch(() => fallback));
  const got = {
    tabs: opened.length,
    left: opened.filter((id) => !closed.has(id)).length,
    pageClosed,
    stayed: (await inPage('location.href', 'navigated')) === url,
    played: await inPage('window.__played === true', false),
    title: await inPage('document.title', null),
  };
  if (test.before) got.before = await inPage(test.before, null);
  if (test.worker) got.worker = await inWorker(test.worker).catch((e) => `error: ${e.message}`);
  if (test.after) got.after = await inPage(test.after, null);
  const ok = Object.entries(test.expect).every(([k, v]) => got[k] === v);
  if (!ok) failures++;
  ran++;
  const extra = Object.keys(test.expect).filter((k) => !['tabs', 'left', 'stayed', 'played'].includes(k)).map((k) => `${k} ${JSON.stringify(got[k])}`);
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${test.name}  (new tabs ${got.tabs}, still open ${got.left}, stayed ${got.stayed}, player clicked ${got.played}${extra.length ? ', ' + extra.join(', ') : ''})`);
  for (const id of opened) await send('Target.closeTarget', { targetId: id }).catch(() => {});
  await send('Target.closeTarget', { targetId }).catch(() => {});
  if (test.cleanup) await inWorker(test.cleanup);
}

console.log(`\n${ran - failures}/${ran} passed${withExtension ? '' : ' (without the extension)'}`);
if (process.platform === 'win32') await new Promise((r) => spawn('taskkill', ['/pid', String(proc.pid), '/T', '/F'], { stdio: 'ignore' }).on('exit', r));
else proc.kill();
server.close();
await sleep(500);
await rm(profile, { recursive: true, force: true }).catch(() => {});
process.exit(failures ? 1 : 0);
