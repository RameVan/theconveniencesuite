// Compares a baseline run of tools/check-popup-sites.mjs (--no-extension) with one or more runs
// with the extension: how many of the pop-ups and redirects seen without it still happen, and
// signs that it broke something (a visible link that no longer opens, a same-site click that no
// longer navigates, new script errors).
//
// Usage: node tools/compare-popup-runs.mjs <baseline.jsonl> <name>=<run.jsonl> [<name>=<run.jsonl> ...] [--json out.json]
import { readFileSync, writeFileSync } from 'node:fs';

const args = process.argv.slice(2);
const jsonOut = args.includes('--json') ? args.splice(args.indexOf('--json'), 2)[1] : null;
const [baseFile, ...runSpecs] = args;
if (!baseFile || !runSpecs.length) {
  console.error('Usage: node tools/compare-popup-runs.mjs <baseline.jsonl> <name>=<run.jsonl> ...');
  process.exit(1);
}

const load = (file) => {
  const bySite = new Map();
  for (const line of readFileSync(file, 'utf8').split('\n')) {
    if (!line) continue;
    try { const r = JSON.parse(line); bySite.set(r.site, r); } catch { /* partial line */ }
  }
  return bySite;
};

function siteOf(host) {
  const parts = (host || '').toLowerCase().replace(/\.$/, '').split('.');
  if (parts.length <= 2 || /^\d+$/.test(parts[parts.length - 1])) return parts.join('.');
  const n = parts[parts.length - 2].length <= 3 && parts[parts.length - 1].length === 2 ? 3 : 2;
  return parts.slice(-n).join('.');
}
const siteOfUrl = (url) => { try { return siteOf(new URL(url).hostname); } catch { return ''; } };

// Parked or for-sale domains whose whole page is a search-ads frame: clicking anything there is
// clicking a visible ad, which isn't what the guard is for.
const isParked = (r) => /^ww\d+\./.test(new URL(r.landed || r.url).hostname)
  || (r.clicks || []).some((c) => /SAFEFRAME|searchresults|parking|sedo|bodis|domain.*sale/i.test(c.under?.src || ''))
  || /domain (is )?for sale|buy this domain|parked/i.test(r.title || '');

// A click on something a person would knowingly click: a visible, ordinary link.
const visibleLink = (u) => u?.kind === 'link' && !u.faint && !(u.positioned && u.big);

const pct = (a, b) => (b ? `${((100 * a) / b).toFixed(1)}%` : '-');
const base = load(baseFile);
const report = { baseline: baseFile, runs: {} };

const baseOk = [...base.values()].filter((r) => !r.error && r.clicks?.length);
const confirmed = baseOk.filter((r) => r.popups || r.redirects);
const parked = confirmed.filter(isParked);
const real = confirmed.filter((r) => !isParked(r));
console.log(`Baseline: ${base.size} sites, ${baseOk.length} loaded and clicked, ${confirmed.length} opened pop-ups or redirected (${parked.length} of them parked domains, left out below)`);
console.log(`  pop-up sites: ${real.length}  (player on the page: ${real.filter((r) => r.player).length}; first click inside a frame: ${real.filter((r) => r.clicks[0]?.under?.kind === 'iframe').length})`);
console.log(`  pop-ups: ${real.reduce((n, r) => n + r.popups, 0)}, redirects: ${real.reduce((n, r) => n + r.redirects, 0)}`);
report.baselineSummary = { sites: base.size, loaded: baseOk.length, confirmed: confirmed.length, parked: parked.length, real: real.length };

for (const spec of runSpecs) {
  const [name, file] = spec.includes('=') ? spec.split('=') : [spec, spec];
  const run = load(file);
  const both = real.filter((r) => run.get(r.site) && !run.get(r.site).error && run.get(r.site).clicks?.length);
  const popupsBefore = both.reduce((n, r) => n + r.popups, 0);
  const redirectsBefore = both.reduce((n, r) => n + r.redirects, 0);
  const popupsAfter = both.reduce((n, r) => n + run.get(r.site).popups, 0);
  const redirectsAfter = both.reduce((n, r) => n + run.get(r.site).redirects, 0);
  const clean = both.filter((r) => !run.get(r.site).popups && !run.get(r.site).redirects);
  const misses = both.filter((r) => run.get(r.site).popups || run.get(r.site).redirects);

  // Breakage signs, over every site both runs could click (not only pop-up sites).
  const pairs = baseOk.filter((r) => !isParked(r)).map((r) => [r, run.get(r.site)]).filter(([, e]) => e && !e.error && e.clicks?.length);
  const lostLinks = [];
  const lostNav = [];
  const moreErrors = [];
  for (const [b, e] of pairs) {
    const start = siteOfUrl(b.landed);
    for (let i = 0; i < Math.min(b.clicks.length, e.clicks.length); i++) {
      const bc = b.clicks[i];
      const ec = e.clicks[i];
      // Same thing under the pointer in both runs, so the click meant the same.
      if (bc.under?.kind !== ec.under?.kind || (bc.under?.href || '') !== (ec.under?.href || '')) continue;
      if (visibleLink(bc.under) && bc.opened.length && !ec.opened.length && !ec.navigated) lostLinks.push({ site: b.site, href: bc.under.href });
      if (bc.navigated && siteOfUrl(bc.navigated) === start && !ec.navigated && !ec.opened.length) lostNav.push({ site: b.site, to: bc.navigated, under: bc.under?.kind });
    }
    if ((e.errorCount || 0) > (b.errorCount || 0) + 1) {
      const fresh = (e.errors || []).filter((m) => !(b.errors || []).includes(m));
      if (fresh.length) moreErrors.push({ site: b.site, errors: fresh.slice(0, 3) });
    }
  }

  // What the misses look like.
  const missKinds = {};
  for (const r of misses) {
    const e = run.get(r.site);
    for (const c of e.clicks) {
      if (!c.opened.some((u) => siteOfUrl(u) !== siteOfUrl(e.landed)) && !(c.navigated && siteOfUrl(c.navigated) !== siteOfUrl(e.landed))) continue;
      const k = c.under?.kind === 'iframe' ? 'click inside a frame' : visibleLink(c.under) ? 'visible link' : c.under?.faint || c.under?.positioned ? 'invisible/positioned layer' : `page (${c.under?.kind})`;
      missKinds[k] = (missKinds[k] || 0) + 1;
    }
  }
  const missHosts = {};
  for (const r of misses) for (const c of run.get(r.site).clicks) for (const u of c.opened) { const h = siteOfUrl(u) || u.slice(0, 20); missHosts[h] = (missHosts[h] || 0) + 1; }

  console.log(`\n${name}: ${both.length} pop-up sites visited`);
  console.log(`  no pop-up or redirect at all: ${clean.length} (${pct(clean.length, both.length)})`);
  console.log(`  pop-ups: ${popupsBefore} -> ${popupsAfter} (${pct(popupsBefore - popupsAfter, popupsBefore)} fewer); redirects: ${redirectsBefore} -> ${redirectsAfter}`);
  console.log(`  what still got through, by what was clicked: ${JSON.stringify(missKinds)}`);
  console.log(`  where it went (top 10): ${JSON.stringify(Object.entries(missHosts).sort((a, b) => b[1] - a[1]).slice(0, 10))}`);
  console.log(`  breakage signs over ${pairs.length} sites: visible links that stopped opening ${lostLinks.length}, same-site clicks that stopped navigating ${lostNav.length}, sites with new script errors ${moreErrors.length}`);
  report.runs[name] = {
    visited: both.length, clean: clean.length, popupsBefore, popupsAfter, redirectsBefore, redirectsAfter,
    missKinds, missHosts, breakage: { comparedSites: pairs.length, lostLinks, lostNav, moreErrors },
    misses: misses.map((r) => ({ site: r.site, clicks: run.get(r.site).clicks })),
  };
}

if (jsonOut) writeFileSync(jsonOut, JSON.stringify(report, null, 1));
