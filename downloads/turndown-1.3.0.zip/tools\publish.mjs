// Releases the version in manifest.json on theconveniencesuite.com:
//   node tools/publish.mjs            (needs git with push access to the site repo)
//   node tools/publish.mjs --dry-run  (does everything except committing and pushing)
//
// 1. Refuses unless VALIDATION.md's release gate status says the build is releasable, and the local
//    suites (tools/check-popups.mjs, tools/check-log.mjs) pass. A failing gate is never skipped.
// 2. Zips the extension (without tools/ and the design documents) as downloads/turndown-<v>.zip,
//    writes downloads/turndown-latest.json (what the popup's update check reads), removes the
//    older Turndown zips and updates the Turndown card on the homepage (version, link).
// 3. Commits and pushes that to the site's main branch, from a temporary worktree of origin/main,
//    so whatever branch or work in progress the site folder has is never touched or pushed.
// TURNDOWN_SITE_DIR points at another checkout of the site repo.
import { createHash } from 'node:crypto';
import { existsSync, mkdtempSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync, copyFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';

const ext = resolve(import.meta.dirname, '..');
const siteRepo = process.env.TURNDOWN_SITE_DIR ? resolve(process.env.TURNDOWN_SITE_DIR) : resolve(ext, '../TheConvenienceSuite');
const dryRun = process.argv.includes('--dry-run');
const version = JSON.parse(readFileSync(join(ext, 'manifest.json'), 'utf8')).version;
const zipName = `turndown-${version}.zip`;
const SITE = 'https://theconveniencesuite.com';

// Thrown, so the worktree below is still removed (finally) before the process exits.
const stop = (msg) => { throw Object.assign(new Error(msg), { stop: true }); };
process.on('uncaughtException', (e) => {
  console.error(e.stop ? `Not published: ${e.message}` : e);
  process.exit(1);
});
const run = (cmd, args, opts = {}) => spawnSync(cmd, args, { encoding: 'utf8', ...opts });

// --- 1. Gates ------------------------------------------------------------------------------------

const validation = readFileSync(join(ext, 'VALIDATION.md'), 'utf8');
const gate = validation.split(/^## Release gate status\s*$/m)[1]?.split(/^## /m)[0]?.trim() || '';
if (!gate) stop('VALIDATION.md has no "## Release gate status" section.');
if (/not releasable/i.test(gate) || !/^releasable/im.test(gate)) {
  stop(`VALIDATION.md says:\n  ${gate.split('\n').join('\n  ')}\nWhen every gate passes, start that section with "Releasable" and say which runs show it.`);
}
for (const suite of ['check-popups.mjs', 'check-log.mjs']) {
  console.log(`Running tools/${suite}…`);
  const r = run(process.execPath, [join(ext, 'tools', suite)], { stdio: 'inherit' });
  if (r.status) stop(`tools/${suite} failed.`);
}

// --- 2. Build into a worktree of the site's main ---------------------------------------------------

if (!existsSync(join(siteRepo, '.git'))) stop(`${siteRepo} is not the site's git checkout.`);
const git = (dir, ...args) => {
  const r = run('git', ['-C', dir, ...args]);
  if (r.status) stop(`git ${args.join(' ')} failed:\n${r.stderr}`);
  return r.stdout.trim();
};
git(siteRepo, 'fetch', '-q', 'origin', 'main');
const work = mkdtempSync(join(tmpdir(), 'turndown-site-'));
rmSync(work, { recursive: true, force: true });
git(siteRepo, 'worktree', 'add', '-q', '--detach', work, 'origin/main');

try {
  const downloads = join(work, 'downloads');
  if (existsSync(join(downloads, zipName))) stop(`${zipName} is already on the site. Bump the version in manifest.json first.`);

  // Everything the extension needs; not the tools, the plan or the validation record.
  const LEAVE_OUT = new Set(['tools', 'plan.md', 'VALIDATION.md', '.claude', '.git']);
  const items = readdirSync(ext).filter((name) => !LEAVE_OUT.has(name) && !name.endsWith('.log')).map((name) => join(ext, name));
  const zip = join(downloads, zipName);
  // .NET's ZipFile with "/" in entry names (Compress-Archive in Windows PowerShell writes "\",
  // which unzips into odd file names on macOS and Linux).
  const quote = (p) => `'${p.replace(/'/g, "''")}'`;
  const ps = run('powershell', ['-NoProfile', '-Command', [
    'Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem',
    `$root = ${quote(ext)}`,
    `$zip = [IO.Compression.ZipFile]::Open(${quote(zip)}, 'Create')`,
    'try {',
    `  foreach ($item in @(${items.map(quote).join(',')})) {`,
    '    $files = if (Test-Path $item -PathType Container) { Get-ChildItem $item -Recurse -File } else { Get-Item $item }',
    '    foreach ($f in $files) {',
    "      $name = $f.FullName.Substring($root.Length + 1).Replace('\\', '/')",
    "      [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $f.FullName, $name, 'Optimal')",
    '    }',
    '  }',
    '} finally { $zip.Dispose() }',
  ].join('\n')]);
  if (ps.status || !existsSync(zip)) stop(`zipping failed:\n${ps.stderr}`);

  for (const old of readdirSync(downloads).filter((f) => /^turndown-\d+\.\d+\.\d+\.zip$/.test(f) && f !== zipName)) git(work, 'rm', '-q', join('downloads', old));
  const bytes = readFileSync(zip);
  const feed = {
    version,
    url: `${SITE}/downloads/${zipName}`,
    sha256: createHash('sha256').update(bytes).digest('hex'),
    size: bytes.length,
    released: new Date().toISOString().slice(0, 10),
  };
  writeFileSync(join(downloads, 'turndown-latest.json'), JSON.stringify(feed, null, 2) + '\n');
  copyFileSync(join(ext, 'icons', 'turndown.svg'), join(work, 'assets', 'turndown.svg'));

  // The homepage card: found by id="turndown", or (the first time) by its icon, which gets the id.
  const page = join(work, 'index.html');
  let html = readFileSync(page, 'utf8');
  let start = html.indexOf('<article class="app" id="turndown"');
  if (start < 0) {
    const icon = html.indexOf('src="assets/turndown.svg" alt="" width="60"');
    start = icon < 0 ? -1 : html.lastIndexOf('<article class="app"', icon);
    if (start < 0) stop('no Turndown card in index.html.');
    html = html.slice(0, start) + html.slice(start).replace('<article class="app"', '<article class="app" id="turndown"');
  }
  const end = html.indexOf('</article>', start);
  const v = String.raw`\d+\.\d+\.\d+`;
  const card = html.slice(start, end)
    .replace(new RegExp(String.raw`downloads/turndown-${v}\.zip`, 'g'), `downloads/${zipName}`)
    .replace(new RegExp(String.raw`v${v} · `), `v${version} · `);
  writeFileSync(page, html.slice(0, start) + card + html.slice(end));

  git(work, 'add', '-A', 'downloads', 'assets/turndown.svg', 'index.html');
  console.log(git(work, 'status', '--short'));
  if (dryRun) {
    console.log(`Dry run: ${zipName} (${Math.ceil(bytes.length / 1024)} KB) built and the homepage updated in ${work}; nothing committed or pushed.`);
  } else {
    git(work, 'commit', '-q', '-m', `Turndown ${version} on the homepage`);
    git(work, 'push', '-q', 'origin', 'HEAD:main');
    console.log(`Published Turndown ${version}: ${feed.url}. Popups of installed copies offer it within an hour.`);
  }
} finally {
  if (!dryRun) {
    run('git', ['-C', siteRepo, 'worktree', 'remove', '--force', work]);
  } else {
    console.log(`Remove the dry-run worktree with: git -C "${siteRepo}" worktree remove --force "${work}"`);
  }
}
