// Summarises a problem log saved with the popup's "Save a log" and writes its screenshot next to
// it as a .jpg. With no argument it reads the newest turndown-log-*.json in the Downloads folder.
//
// Usage: node tools/read-log.mjs [path/to/turndown-log-....json] [--all]
//   --all  also prints frames where nothing happened
import { readdir, readFile, stat, writeFile } from 'node:fs/promises';
import { homedir } from 'node:os';
import { join } from 'node:path';

const args = process.argv.slice(2);
const all = args.includes('--all');
let file = args.find((a) => !a.startsWith('--'));
if (!file) {
  // Browsers' download folders: the default one, the owner's Dia folder, and TURNDOWN_LOG_DIR.
  const dirs = [process.env.TURNDOWN_LOG_DIR, join(homedir(), 'Downloads'), 'D:\\Downloads\\BrowserDownloads'].filter(Boolean);
  const dated = [];
  for (const dir of dirs) {
    const names = await readdir(dir).catch(() => []);
    for (const f of names.filter((n) => /^turndown-log-.*\.json$/.test(n))) dated.push([(await stat(join(dir, f))).mtimeMs, join(dir, f)]);
  }
  if (!dated.length) {
    console.log(`No turndown-log-*.json in ${dirs.join(' or ')}. Save one from the Turndown popup first.`);
    process.exit(1);
  }
  file = dated.sort((a, b) => b[0] - a[0])[0][1];
}

const log = JSON.parse(await readFile(file, 'utf8'));
const line = (s = '') => console.log(s);
const j = (v) => JSON.stringify(v);

line(`${file}`);
line(`Problem: ${log.problem}${log.note ? ` — "${log.note}"` : ''}`);
line(`Page: ${log.page?.url} (${log.page?.title})`);
line(`Saved ${log.savedAt}, Turndown ${log.version}`);

const bg = log.background || {};
if (bg.error) line(`Background: error ${bg.error}`);
else {
  line(`Settings: ${j(bg.settings)}`);
  line(`For this site: ${j(bg.forThisSite)}`);
  line(`Cookie result on this page: ${j(bg.cookieResult)}; pop-ups blocked on this page: ${bg.popupsBlockedOnPage}`);
  if (bg.lastBlocked) line(`Last blocked: ${j(bg.lastBlocked)}`);
  if (bg.tabEvents?.length) {
    line('Tab events:');
    for (const e of bg.tabEvents) line(`  ${new Date(e.at).toISOString().slice(11, 19)} ${e.what} ${j({ ...e, at: undefined, what: undefined })}`);
  }
}

for (const f of log.frames || []) {
  const c = typeof f.cookies === 'object' ? f.cookies : null;
  const p = typeof f.popups === 'object' ? f.popups : null;
  const interesting = f.frameId === 0 || f.error || c?.bannersOnScreen?.length || c?.otherConsentElements?.length || c?.handled
    || p?.trace?.length || p?.guard?.layersFixed?.length || p?.guard?.players?.length;
  if (!interesting && !all) continue;
  line();
  line(`== Frame ${f.frameId}${f.parentFrameId >= 0 ? ` (in ${f.parentFrameId})` : ''}: ${f.url}`);
  if (f.error) line(`  error: ${f.error}`);
  if (typeof f.cookies === 'string') line(`  cookies: ${f.cookies}`);
  if (c) {
    line(`  cookies: ${c.handled ? 'handled' : 'not handled'}, ${c.running ? 'still looking' : 'stopped'}; known platforms on screen: ${j(c.knownPlatformsOnScreen)}; rules: ${j(c.rules)}`);
    for (const b of c.bannersOnScreen || []) {
      line(`  banner ${b.el} ${j(b.box)} tcf=${b.vendorsOrLegitimateInterest} settings=${j(b.settingsButton)}`);
      line(`    text: ${b.text.slice(0, 200)}`);
      line(`    buttons: ${b.buttons.map((x) => `${x.label}${x.kind ? `[${x.kind}]` : ''}${x.navigates ? '[link]' : ''}`).join(' | ')}`);
    }
    for (const o of c.otherConsentElements || []) line(`  other consent element ${o.el} ${j(o.box)} overlay=${o.overlay}: ${o.text.slice(0, 120)}`);
    if (c.consentLikeButtons?.length) line(`  consent-like buttons: ${c.consentLikeButtons.map((x) => `${x.label}${x.consentRoot ? '' : '[no consent root]'}`).join(' | ')}`);
    for (const fr of c.consentFrames || []) line(`  consent frame ${fr.src} shown=${fr.shown}`);
    if (c.trace?.length) line(`  cookie steps: ${c.trace.map((t) => `${(t.ms / 1000).toFixed(1)}s ${t.step}`).join(' / ').slice(0, 1500)}`);
  }
  if (typeof f.popups === 'string') line(`  pop-ups: ${f.popups}`);
  if (p) {
    const g = typeof p.guard === 'object' ? p.guard : null;
    line(`  pop-ups: blocking=${p.config?.popups} layers=${p.config?.overlays}${g ? '' : ` guard: ${p.guard}`}`);
    if (g?.players?.length) line(`  players: ${g.players.map((m) => `${m.el} ${j(m.box)} ${m.src}`).join(' | ')}`);
    if (g?.layersFixed?.length) line(`  layers made click-through: ${j(g.layersFixed)}`);
    for (const t of g?.onTop || []) {
      const top = t.stack[0];
      if (top) line(`  on top at ${t.where}: ${t.stack.slice(0, 3).map((s) => `${s.el}${s.invisibleLayer ? '[INVISIBLE LAYER]' : ''}${s.link ? `[link ${s.link}]` : ''}${s.pointerEvents === 'none' ? '[click-through]' : ''}`).join(' > ')}`);
    }
    for (const b of g?.bigPositioned || []) if (b.transparent || b.link) line(`  big transparent/linked layer: ${j(b)}`);
    for (const t of p.trace || []) line(`  ${(t.ms / 1000).toFixed(1)}s ${t.what} ${j({ ...t, ms: undefined, what: undefined })}`);
  }
}
for (const f of log.otherFrames || []) line(`(frame ${f.frameId} not reachable: ${f.url})`);

if (typeof log.screenshot === 'string' && log.screenshot.startsWith('data:image/')) {
  const out = file.replace(/\.json$/, '.jpg');
  await writeFile(out, Buffer.from(log.screenshot.split(',')[1], 'base64'));
  line();
  line(`Screenshot: ${out}`);
} else if (log.screenshot) {
  line(`Screenshot: ${log.screenshot}`);
}
